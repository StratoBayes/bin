# StratoSegment

Version 0.1.1 includes small correctness/performance fixes to the initial DP engine.

**StratoSegment** is an R package for **fast fixed-K multivariate change-point detection** in depth-indexed well logs.

## Model

- common/shared change points across all curves
- within each segment and curve: `y ~ depth` by ordinary least squares
- objective: minimize summed residual sum of squares across curves
- optimizer: exact dynamic programming

This is the practical **v1 fast engine** discussed in the design conversation: a deterministic segmentation core suitable for roughly 1,000 rows and 1--7 curves.

## Main function

```r
StratoSegment(
  y,
  depth = NULL,
  K = 1,
  minSegLen = 20,
  standardize = TRUE,
  slopePenalty = 0
)
```

`y` may be a numeric matrix, `data.frame`, or a **numeric vector** (one curve). If `depth` is `NULL`, depth defaults to `seq_len(nrow(y))` (row index) and rows are left in their original order.

If you pass a non-`NULL` `depth` vector, rows are **sorted by non-decreasing depth** before fitting; the returned fit object (`y`, `depth`, fitted values, segment summaries) uses that same order. **Duplicate depths are allowed** (ties are ordered by original row number).

For a data frame with a depth column (first column, or `DEPTH` if present), use `StratoSegmentData(data, ...)`.

## Example

```r
library(StratoSegment)

sim <- simulate_welllog_trend(n = 1000, p = 3, changepoints = c(280, 610), seed = 1)
fit <- StratoSegment(sim$y, depth = sim$depth, K = 2, minSegLen = 30)

# Single curve as a vector (uses row index as depth if depth is NULL)
# fit_gr <- StratoSegment(df$GR, depth = df$DEPTH, K = 2)

print(fit)
predict(fit, type = "segments")
plot(fit)
```

## Notes

- `K` is fixed in this v1 engine.
- Curves are coupled by **shared breakpoints**, not by full residual covariance.
- This package source was generated in an environment without R installed, so it has **not** been run through `R CMD check` here.
