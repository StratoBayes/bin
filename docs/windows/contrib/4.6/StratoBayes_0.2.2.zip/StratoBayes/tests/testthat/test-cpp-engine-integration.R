# Integration tests for engine = "cpp" path in RunStratModel
#
# Verifies that the C++ MCMC engine produces valid output across different
# model configurations. Does NOT test bit-for-bit reproducibility against
# engine = "R" because the C++ engine draws from R's RNG in a different
# order than the R loop.

# ── Helper ────────────────────────────────────────────────────────────────────

run_engine_test <- function(data_name, model_name, nIter = 30, nChains = 4,
                            label = NULL) {
  data(list = data_name, package = "StratoBayes", envir = environment())
  data(list = model_name, package = "StratoBayes", envir = environment())

  sData <- get(data_name)
  sModel <- get(model_name)

  td <- file.path(tempdir(), paste0("engine_test_", data_name))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(8372)
  result <- RunStratModel(
    stratObject = sData,
    stratModel = sModel,
    nIter = nIter,
    nChains = nChains,
    seed = 1,
    quiet = TRUE,
    visualise = FALSE,
    modelDir = td,
    modelName = paste0("cpp_", data_name),
    engine = "cpp"
  )

  # T-131: read from binary RDS (preferred) or TSV fallback
  rds_file <- file.path(td, paste0("cpp_", data_name, "_binarysamples_run_1.rds"))
  tsv_file <- file.path(td, paste0("cpp_", data_name, "_samples_run_1.txt"))

  if (file.exists(rds_file)) {
    mat <- readRDS(rds_file)
    cn  <- colnames(mat)
    logpost <- mat[, "posterior"]
    accept  <- mat[, "proposal_accepted"]
    nsamples <- nrow(mat)
  } else {
    samples <- read.delim(tsv_file, header = FALSE, stringsAsFactors = FALSE)
    header <- as.character(samples[1, ])
    data_rows <- samples[-1, , drop = FALSE]
    logpost <- as.numeric(data_rows[, which(header == "posterior")])
    accept  <- as.numeric(data_rows[, which(header == "proposal_accepted")])
    nsamples <- nrow(data_rows)
  }

  # Clean up
  unlink(td, recursive = TRUE)

  list(
    result = result,
    logpost = logpost,
    accept = accept,
    nsamples = nsamples,
    label = label %||% paste(data_name, model_name, sep = " + ")
  )
}


# ── Test: stratData1 + stratModel1 (height/site, sigmaFixed) ────────────────

test_that("C++ engine works with stratData1 (height/site)", {
  res <- run_engine_test("stratData1", "stratModel1")

  expect_s3_class(res$result, "StratPosterior")
  expect_equal(res$nsamples, 30)  # nIter data rows
  expect_true(all(is.finite(res$logpost)))
  expect_true(any(res$accept == 1))  # at least some acceptance
})


# ── Test: stratData2 + stratModel2 (age/site, ties, multi-signal) ───────────

test_that("C++ engine works with stratData2 (age/site, ties)", {
  res <- run_engine_test("stratData2", "stratModel2")

  expect_s3_class(res$result, "StratPosterior")
  expect_equal(res$nsamples, 30)
  expect_true(all(is.finite(res$logpost)))
})


# ── Test: stratData3 + stratModel3 (height/partition, sigmaFixed=FALSE) ─────

test_that("C++ engine works with stratData3 (partition, sigma estimated)", {
  res <- run_engine_test("stratData3", "stratModel3")

  expect_s3_class(res$result, "StratPosterior")
  expect_equal(res$nsamples, 30)
  expect_true(all(is.finite(res$logpost)))
})


# ── Test: stratData0 + stratModel0 (smallest dataset) ──────────────────────

test_that("C++ engine works with stratData0 (minimal)", {
  res <- run_engine_test("stratData0", "stratModel0", nIter = 20)

  expect_s3_class(res$result, "StratPosterior")
  expect_true(all(is.finite(res$logpost)))
})


# ── Test: Output structure matches R engine ─────────────────────────────────

test_that("C++ engine output has same structure as R engine", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td_r <- file.path(tempdir(), "struct_R")
  td_cpp <- file.path(tempdir(), "struct_cpp")
  dir.create(td_r, showWarnings = FALSE, recursive = TRUE)
  dir.create(td_cpp, showWarnings = FALSE, recursive = TRUE)

  set.seed(1234)
  res_r <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td_r, modelName = "R",
    engine = "R"
  )

  set.seed(1234)
  res_cpp <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td_cpp, modelName = "cpp",
    engine = "cpp"
  )

  # Same class
  expect_s3_class(res_cpp, "StratPosterior")

  # Same sample array dimensions
  expect_equal(dim(res_r$samples), dim(res_cpp$samples))

  # Same column names in samples array
  expect_equal(colnames(res_r$samples), colnames(res_cpp$samples))

  # Clean up
  unlink(td_r, recursive = TRUE)
  unlink(td_cpp, recursive = TRUE)
})


# ── Test: MCMC checkpoint is saved correctly ────────────────────────────────

test_that("C++ engine saves valid MCMC checkpoint", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "ckpt_test")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(5678)
  RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "ckpt",
    engine = "cpp"
  )

  # Check MCMC RDS file exists
  mcmc_file <- file.path(td, "ckpt_mcmc_run_1.rds")
  expect_true(file.exists(mcmc_file))

  mcmc <- readRDS(mcmc_file)

  # Verify recent state
  expect_true(!is.null(mcmc[["recentState"]]))
  state <- mcmc[["recentState"]]
  expect_equal(length(state), 4)  # nChains

  # Each chain should have metro, gibbs, age sub-lists
  for (ch in seq_along(state)) {
    expect_true(all(c("metro", "gibbs", "age") %in% names(state[[ch]])))
    expect_true(is.numeric(state[[ch]][["metro"]][["logPost"]]))
    expect_true(is.finite(state[[ch]][["metro"]][["logPost"]]))
  }

  unlink(td, recursive = TRUE)
})
