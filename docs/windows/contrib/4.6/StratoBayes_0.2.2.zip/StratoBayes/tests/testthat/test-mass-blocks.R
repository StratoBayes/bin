test_that(".BuildMassBlocks returns all 1x1 for minimal model", {
  model <- list(parametersLengthNotFixed = 3L)
  blocks <- StratoBayes:::.BuildMassBlocks(model)
  expect_length(blocks, 3)
  for (b in blocks) {
    expect_equal(b$k, 1L)
    expect_equal(b$cholMat, 1)
    expect_equal(b$invMat, 1)
  }
  # All free params covered exactly once
  all_idx <- unlist(lapply(blocks, `[[`, "idx"))
  expect_equal(sort(all_idx), 1:3)
})


test_that(".BuildMassBlocks creates 2x2 blocks for site model", {
  skip_on_cran()
  # 3-site height-scale "site" model: alpha at 1,2 gamma at 3,4
  # All 4 are free, no gaps
  model <- list(
    parametersLengthNotFixed = 4L,
    parametersLength = 4L,
    ind = list(
      paramNotFixed = 1:4,
      alpha = c(1L, 2L),
      gamma = c(3L, 4L),
      sedModel = "site"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  # Should have 2 blocks of size 2: (alpha1,gamma1) and (alpha2,gamma2)
  expect_length(blocks, 2)
  expect_equal(blocks[[1]]$k, 2L)
  expect_equal(blocks[[2]]$k, 2L)
  # First block: alpha idx 1 → free 1, gamma idx 3 → free 3
  expect_equal(blocks[[1]]$idx, c(1L, 3L))
  # Second block: alpha idx 2 → free 2, gamma idx 4 → free 4
  expect_equal(blocks[[2]]$idx, c(2L, 4L))
  # All indices covered
  all_idx <- sort(unlist(lapply(blocks, `[[`, "idx")))
  expect_equal(all_idx, 1:4)
})


test_that(".BuildMassBlocks handles fixed parameters", {
  skip_on_cran()
  # 3-site model, but gamma_1 is fixed (param 3 missing from paramNotFixed)
  model <- list(
    parametersLengthNotFixed = 3L,
    parametersLength = 4L,
    ind = list(
      paramNotFixed = c(1L, 2L, 4L),  # alpha1, alpha2, gamma2
      alpha = c(1L, 2L),
      gamma = c(3L, 4L),
      sedModel = "site"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  # alpha1 has no free gamma partner → 1x1 block

  # alpha2 + gamma2 → 2x2 block
  sizes <- vapply(blocks, `[[`, 0L, "k")
  expect_true(2L %in% sizes)
  expect_true(1L %in% sizes)
  # All 3 free params covered
  all_idx <- sort(unlist(lapply(blocks, `[[`, "idx")))
  expect_equal(all_idx, 1:3)
})


test_that(".BuildMassBlocks stays diagonal for partition model", {
  skip_on_cran()
  model <- list(
    parametersLengthNotFixed = 5L,
    parametersLength = 5L,
    ind = list(
      paramNotFixed = 1:5,
      alpha = c(1L, 2L),
      gamma = c(3L, 4L, 5L),
      sedModel = "partition"  # alpha/gamma lengths differ
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)
  # All 1x1 because "partition" model doesn't have 1:1 alpha-gamma pairing
  for (b in blocks) {
    expect_equal(b$k, 1L)
  }
  expect_length(blocks, 5)
})


test_that(".MassSampleMomentum produces correct distribution for 1x1 blocks", {
  skip_on_cran()
  set.seed(8172)
  nFree <- 3
  # Mass matrix: diag(4, 9, 1) → chol = diag(2, 3, 1)
  blocks <- list(
    list(idx = 1L, cholMat = 2, invMat = 0.25, k = 1L),
    list(idx = 2L, cholMat = 3, invMat = 1/9, k = 1L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L)
  )
  # Sample many times and check variance
  samples <- replicate(5000, .MassSampleMomentum(blocks, nFree))
  # p ~ N(0, M), so var(p_i) = M_ii
  expect_equal(var(samples[1, ]), 4, tolerance = 0.5)
  expect_equal(var(samples[2, ]), 9, tolerance = 1.0)
  expect_equal(var(samples[3, ]), 1, tolerance = 0.3)
})


test_that(".MassSampleMomentum produces correlated samples for 2x2 blocks", {
  skip_on_cran()
  set.seed(3947)
  nFree <- 2
  # M = [[4, 2], [2, 3]], L = lower cholesky
  M <- matrix(c(4, 2, 2, 3), 2, 2)
  L <- t(chol(M))
  Minv <- solve(M)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(L),
         invMat = as.vector(Minv), k = 2L)
  )
  samples <- replicate(10000, .MassSampleMomentum(blocks, nFree))
  # Check covariance ≈ M
  emp_cov <- cov(t(samples))
  expect_equal(emp_cov[1, 1], 4, tolerance = 0.5)
  expect_equal(emp_cov[2, 2], 3, tolerance = 0.5)
  expect_equal(emp_cov[1, 2], 2, tolerance = 0.5)
})


test_that(".MassKineticEnergy is correct for diagonal blocks", {
  skip_on_cran()
  p <- c(2, 3, 1)
  # M^{-1} = diag(0.5, 0.25, 1)
  blocks <- list(
    list(idx = 1L, cholMat = sqrt(2), invMat = 0.5, k = 1L),
    list(idx = 2L, cholMat = 2, invMat = 0.25, k = 1L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L)
  )
  K <- .MassKineticEnergy(p, blocks)
  expected <- 0.5 * (4 * 0.5 + 9 * 0.25 + 1 * 1)
  expect_equal(K, expected)
})


test_that(".MassKineticEnergy is correct for 2x2 block", {
  skip_on_cran()
  p <- c(1, 2)
  M <- matrix(c(4, 1, 1, 2), 2, 2)
  Minv <- solve(M)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M))),
         invMat = as.vector(Minv), k = 2L)
  )
  K <- .MassKineticEnergy(p, blocks)
  expected <- 0.5 * drop(p %*% Minv %*% p)
  expect_equal(K, expected, tolerance = 1e-10)
})


test_that(".MassInvMultiply is correct for mixed blocks", {
  skip_on_cran()
  p <- c(1, 2, 3)
  M2 <- matrix(c(4, 1, 1, 2), 2, 2)
  M2inv <- solve(M2)

  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M2))),
         invMat = as.vector(M2inv), k = 2L),
    list(idx = 3L, cholMat = sqrt(5), invMat = 0.2, k = 1L)
  )
  result <- .MassInvMultiply(p, blocks, 3L)
  expected <- c(drop(M2inv %*% c(1, 2)), 3 * 0.2)
  expect_equal(result, expected, tolerance = 1e-10)
})


test_that(".MassBlocksToDiag extracts diagonal correctly", {
  skip_on_cran()
  M2 <- matrix(c(4, 1, 1, 2), 2, 2)
  M2inv <- solve(M2)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M2))),
         invMat = as.vector(M2inv), k = 2L),
    list(idx = 3L, cholMat = 1, invMat = 0.5, k = 1L)
  )
  diag_vec <- .MassBlocksToDiag(blocks, 3)
  expect_equal(diag_vec[1], M2inv[1, 1], tolerance = 1e-10)
  expect_equal(diag_vec[2], M2inv[2, 2], tolerance = 1e-10)
  expect_equal(diag_vec[3], 0.5)
})


test_that(".AdaptMassBlocks produces correct block covariance", {
  skip_on_cran()
  set.seed(4519)
  n <- 1000
  # Generate correlated data for a 2x2 block
  Sigma <- matrix(c(4, 2, 2, 3), 2, 2)
  L <- t(chol(Sigma))
  samples <- matrix(rnorm(n * 2), ncol = 2) %*% t(L)
  # Add a third independent column
  freeHistory <- cbind(samples, rnorm(n, sd = 2))

  blocks <- list(
    list(idx = c(1L, 2L), cholMat = c(1, 0, 0, 1),
         invMat = c(1, 0, 0, 1), k = 2L,
         wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L,
         wMean = 0, wM2 = 0, wN = 0L)
  )

  # Welford: accumulate then adapt
  blocks <- .WelfordUpdateBlocks(blocks, freeHistory)
  adapted <- .AdaptMassBlocks(blocks)

  # Block 1: should recover Sigma approximately
  L_adapted <- matrix(adapted[[1]]$cholMat, 2, 2)
  M_adapted <- L_adapted %*% t(L_adapted)
  expect_equal(M_adapted[1, 1], 4, tolerance = 0.5)
  expect_equal(M_adapted[2, 2], 3, tolerance = 0.5)
  expect_equal(M_adapted[1, 2], 2, tolerance = 0.5)

  # Block 2: should recover variance ≈ 4
  expect_equal(adapted[[2]]$cholMat^2, 4, tolerance = 1.0)
})


test_that("Block-diagonal leapfrog matches diagonal for 1x1 blocks", {
  skip_on_cran()
  set.seed(6201)
  nFree <- 3
  massMatInv <- c(0.5, 0.25, 1.0)
  massMat <- 1.0 / massMatInv
  blocks1x1 <- list(
    list(idx = 1L, cholMat = sqrt(massMat[1]), invMat = massMatInv[1], k = 1L),
    list(idx = 2L, cholMat = sqrt(massMat[2]), invMat = massMatInv[2], k = 1L),
    list(idx = 3L, cholMat = sqrt(massMat[3]), invMat = massMatInv[3], k = 1L)
  )
  q <- rnorm(3)
  p <- rnorm(3)
  grad <- rnorm(3)
  # A simple gradient function (quadratic potential)
  gradFn <- function(params) {
    freeP <- params[1:3]
    list(logPost = -0.5 * sum(freeP^2), grad = -freeP, ok = TRUE)
  }
  fullParams <- q  # trivial case: freeIdx = 1:3

  res_diag <- .HMCLeapfrog(q, p, grad, 0.1, 5L, massMatInv,
                             gradFn, 1:3, fullParams, 1.0)
  res_block <- .HMCLeapfrog(q, p, grad, 0.1, 5L, NULL,
                              gradFn, 1:3, fullParams, 1.0,
                              massBlocks = blocks1x1)
  expect_equal(res_diag$q, res_block$q, tolerance = 1e-10)
  expect_equal(res_diag$p, res_block$p, tolerance = 1e-10)
  expect_equal(res_diag$logPost, res_block$logPost, tolerance = 1e-10)
})
