# Tests for temperature-scaled covariance inheritance in .UpdateProposal
# (mcmcFunctions.R Fix 1: near-zero MVN acceptance on cold chains).
#
# Root cause: when a cold chain has < 3 unique history rows it inherits the
# next hotter chain's cluster covariance verbatim.  The hot chain's covariance
# reflects T_hot-flattened posterior (wider by ~T_hot), so steps for the cold
# chain are sqrt(T_hot/T_cold) too large → near-zero acceptance.
#
# Fix: scale each inherited covariance matrix by T_cold / T_hot.
#
# These tests call .UpdateProposal via the package namespace and use a minimal
# mcmc / model mock so they run without a compiled C++ engine.

.ns <- loadNamespace("StratoBayes")

# ─── Helper: minimal 2-chain mcmc mock ──────────────────────────────────────
.mv_make_mcmc <- function(cov_hot, T_cold, T_hot, histSize1 = 2L) {
  nFree <- ncol(cov_hot)
  histLen <- 50L

  # Build fake chain history: chain 1 = histSize1 rows (< 3 unique triggers fallback)
  # chain 2 = 10 rows (fine)
  mk_hist <- function(n) matrix(rnorm(n * (nFree + 1L)), n, nFree + 1L)

  list(
    nChains     = 2L,
    currentIter = 10L,
    endAdapting = 100L,
    startAdapting = 1L,
    # .UpdateProposal uses names(mcmc[["propose"]])[prop] — value unused
    propose     = setNames(vector("list", 1L), "Multivariate"),
    temper      = list(temperatures = c(T_cold, T_hot, NA_real_),
                       tempering    = TRUE),
    metro       = list(
      historySize              = c(histSize1, 10L),
      historyLength            = histLen,
      historyRingPos           = c(1L, 1L),
      enableRingBuffer         = FALSE,
      clustWithParametersMCMC  = TRUE,
      clustMethodMCMC          = "proto",
      clustMaxMCMC             = 5L,
      clustMinPtsMCMC          = 5L,
      nProposals               = c(1L, 1L),
      proposalValid            = matrix(
        c(FALSE, TRUE), nrow = 2L, ncol = 1L,
        dimnames = list(NULL, "Multivariate")),
      proposalProbability      = matrix(
        c(0, 0.5), nrow = 2L, ncol = 1L,
        dimnames = list(NULL, "Multivariate")),
      proposalArgs = list(
        chain1 = list(Multivariate = NULL),
        chain2 = list(Multivariate = list(
          list(rep(0, nFree), cov_hot)   # one cluster: (center, cov)
        ))
      ),
      adaptProposal = c(TRUE, TRUE),
      chainHistory  = list(mk_hist(histSize1), mk_hist(10L))
    )
  )
}

# minimal model mock — only the fields .UpdateProposal uses
.mv_make_model <- function(nFree) {
  list(
    parametersLength         = nFree,
    parametersLengthNotFixed = nFree,
    ind = list(paramNotFixed = seq_len(nFree))
  )
}

# ─── Tests ───────────────────────────────────────────────────────────────────

test_that(".UpdateProposal scales inherited covariance by T_cold / T_hot", {
  skip_if_not(
    existsMethod <- exists(".UpdateProposal", envir = .ns, mode = "function"),
    ".UpdateProposal not in namespace"
  )
  upd <- get(".UpdateProposal", envir = .ns)

  T_cold <- 1.0; T_hot <- 4.0
  nFree  <- 3L
  # hot-chain covariance: T_hot × I
  cov_hot <- diag(nFree) * T_hot

  set.seed(111)
  mcmc  <- .mv_make_mcmc(cov_hot, T_cold, T_hot, histSize1 = 2L)
  model <- .mv_make_model(nFree)

  result_metro <- upd(data = list(), model = model, mcmc = mcmc,
                      chain = 1L, inLateAdaptation = FALSE)

  # After fix: chain 1 should have covariance = cov_hot * (T_cold/T_hot)
  inherited <- result_metro[["proposalArgs"]][["chain1"]][["Multivariate"]][[1L]][[2L]]

  expect_false(is.null(inherited),
               label = "cold chain should have inherited covariance")
  expected <- cov_hot * (T_cold / T_hot)   # = I
  expect_equal(inherited, expected, tolerance = 1e-12,
               label = "covariance should be scaled by T_cold/T_hot")
})

test_that(".UpdateProposal does not amplify covariance when T_cold == T_hot", {
  skip_if_not(
    exists(".UpdateProposal", envir = .ns, mode = "function"),
    ".UpdateProposal not in namespace"
  )
  upd <- get(".UpdateProposal", envir = .ns)

  nFree <- 3L
  cov_ref <- diag(nFree) * 2.5

  set.seed(222)
  mcmc  <- .mv_make_mcmc(cov_ref, T_cold = 1.0, T_hot = 1.0, histSize1 = 2L)
  model <- .mv_make_model(nFree)

  result_metro <- upd(data = list(), model = model, mcmc = mcmc,
                      chain = 1L, inLateAdaptation = FALSE)

  inherited <- result_metro[["proposalArgs"]][["chain1"]][["Multivariate"]][[1L]][[2L]]

  # tRatio = 1.0 → no scaling, covariance unchanged
  expect_equal(inherited, cov_ref, tolerance = 1e-12,
               label = "covariance should not change when T_cold == T_hot")
})

test_that(".UpdateProposal partial T-scaling: T_cold=2, T_hot=4 → ratio=0.5", {
  skip_if_not(
    exists(".UpdateProposal", envir = .ns, mode = "function"),
    ".UpdateProposal not in namespace"
  )
  upd <- get(".UpdateProposal", envir = .ns)

  nFree   <- 2L
  cov_hot <- diag(nFree) * 8.0   # hot-chain covariance

  set.seed(333)
  mcmc  <- .mv_make_mcmc(cov_hot, T_cold = 2.0, T_hot = 4.0, histSize1 = 2L)
  model <- .mv_make_model(nFree)

  result_metro <- upd(data = list(), model = model, mcmc = mcmc,
                      chain = 1L, inLateAdaptation = FALSE)

  inherited <- result_metro[["proposalArgs"]][["chain1"]][["Multivariate"]][[1L]][[2L]]
  expected  <- cov_hot * 0.5   # T_cold/T_hot = 2/4 = 0.5

  expect_equal(inherited, expected, tolerance = 1e-12)
})
