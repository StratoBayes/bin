# T-137: Tests for NUTS/HMC divergence diagnostics surfacing
#
# Verifies that:
#   1. mcmcSummary contains divergence fields when NUTS is used
#   2. summary.StratPosterior includes divergences in general section
#   3. print.summary.StratPosterior displays divergence info
#   4. MH-only runs do NOT include divergence fields

# Helper: run a NUTS model and return StratPosterior
run_nuts_for_diagnostics <- function(engine = "R") {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  # RunStratModel returns a StratPosterior object
  RunStratModel(
    stratObject = stratData1, stratModel = model,
    nIter = 500, nChains = 2, seed = 4817,
    quiet = TRUE, visualise = FALSE, engine = engine
  )
}


test_that("NUTS R engine surfaces divergence diagnostics in mcmcSummary", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true("nGradientTransitions" %in% names(post[["mcmcSummary"]]))
  expect_true("maxTreeDepth" %in% names(post[["mcmcSummary"]]))

  nRun <- post[["nRun"]]
  expect_length(post[[c("mcmcSummary", "nDivergent")]], nRun)
  expect_length(post[[c("mcmcSummary", "nGradientTransitions")]], nRun)

  # NUTS was used, so there should be gradient transitions
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "nDivergent")]] >= 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})

test_that("summary.StratPosterior includes divergences for NUTS", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  expect_true("divergences" %in% names(s[["general"]]))

  divInfo <- s[[c("general", "divergences")]]
  expect_true("nDivergent" %in% names(divInfo))
  expect_true("nGradientTransitions" %in% names(divInfo))
  expect_true("divergenceRate" %in% names(divInfo))
  expect_true("maxTreeDepth" %in% names(divInfo))
  expect_true("perRun" %in% names(divInfo))

  expect_true(divInfo$divergenceRate >= 0 && divInfo$divergenceRate <= 1)
  expect_s3_class(divInfo$perRun, "data.frame")
  expect_equal(nrow(divInfo$perRun), post[["nRun"]])
})

test_that("print.summary.StratPosterior displays divergence info", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")

  expect_true(
    grepl("gradient-based", outputText, ignore.case = TRUE) ||
      grepl("divergent", outputText, ignore.case = TRUE)
  )
})

test_that("MH-only run does NOT include divergence fields", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  post <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 50, nChains = 2, seed = 7291,
    quiet = TRUE, visualise = FALSE
  )

  expect_null(post[[c("mcmcSummary", "nDivergent")]])
  expect_null(post[[c("mcmcSummary", "nGradientTransitions")]])

  s <- summary(post)
  expect_null(s[[c("general", "divergences")]])
})

# ── T-138: Rank-normalized split-chain R-hat tests ───────────────────────────

test_that(".RhatRankNorm returns ~1.0 for converged chains", {
  set.seed(6142)
  # Two chains from the same distribution should give R-hat near 1
  chain1 <- matrix(rnorm(500), ncol = 2)
  chain2 <- matrix(rnorm(500), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  expect_true(all(rhat < 1.1))
  expect_true(all(rhat >= 1.0))
})

test_that(".RhatRankNorm detects non-convergence", {
  set.seed(3974)
  # Two chains from very different distributions
  chain1 <- matrix(rnorm(500, mean = 0), ncol = 2)
  chain2 <- matrix(rnorm(500, mean = 10), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_true(all(rhat > 1.5))
})

test_that(".RhatRankNorm handles constant parameter", {
  chain1 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  chain2 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("const", "varying")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  # Constant parameter: R-hat = 1.0
  expect_equal(unname(rhat[1]), 1.0)
  # Varying parameter: R-hat near 1.0
  expect_true(rhat[2] < 1.2)
})

test_that(".RhatBasic computes standard R-hat correctly", {
  set.seed(8851)
  # 4 identical chains → R-hat = 1
  chains <- matrix(rnorm(400), ncol = 4)
  rhat <- StratoBayes:::.RhatBasic(chains)
  # R-hat should be close to 1 for IID chains (can be slightly below 1)
  expect_true(rhat > 0.95 && rhat < 1.1)
})

test_that("summary.StratPosterior uses rank-normalized R-hat label", {
  skip_on_cran()

  post <- StratoBayes::stratPosterior1
  s <- summary(post)
  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")
  expect_true(grepl("rank-normalized", outputText))
})

test_that("NUTS C++ engine surfaces divergence diagnostics", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "cpp")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})
