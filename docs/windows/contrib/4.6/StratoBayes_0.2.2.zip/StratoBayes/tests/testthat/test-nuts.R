# Tests for NUTS (No-U-Turn Sampler) — Phase E
#
# Verifies:
#   1. U-turn detection (.NUTSUTurn)
#   2. LogSumExp helper
#   3. NUTS default args
#   4. Tree building (.NUTSBuildTree) on a synthetic quadratic target
#   5. RunStratModel integration on stratData1 (R and C++ engines)
#   6. Dual averaging with NUTS
#
# Ties models (stratData2/3) are NOT tested here because each gradient
# evaluation crosses R↔C++ for the ties callback, and NUTS tree doubling
# amplifies this cost.  Ties correctness is covered by existing HMC tests
# (which use fixed trajectory lengths).


# ── Helpers ──────────────────────────────────────────────────────────────

#' Synthetic gradient function for a diagonal-covariance normal target.
#' logPost(q) = -0.5 * sum(q^2 / sigma^2)  =>  grad(q) = -q / sigma^2
make_quadratic_grad <- function(sigma = c(1, 1)) {
  prec <- 1 / sigma^2
  function(fullParams) {
    q <- fullParams
    logP <- -0.5 * sum(prec * q^2)
    g    <- -prec * q
    list(logPost = logP, grad = g, ok = TRUE)
  }
}


# ── Test: U-turn detection ─────────────────────────────────────────────────
#
# Criterion: U-turn when (q_plus - q_minus) . r_minus < 0
#                      OR (q_plus - q_minus) . r_plus  < 0
#
# Physical meaning: at the minus end, r_minus should point toward q_plus
# (the trajectory was built by backward integration, so r_minus pointing
# "forward" along dq = no U-turn).  At the plus end, r_plus should point
# away from q_minus (forward).

test_that(".NUTSUTurn detects U-turns correctly", {
  skip_on_cran()

  UTurn <- StratoBayes:::.NUTSUTurn

  # 2D: both momenta aligned with dq → no U-turn
  expect_false(UTurn(c(0, 0), c(1, 1), c(1, 1), c(1, 1)))

  # Minus end heading backward (away from q_plus) → U-turn
  expect_true(UTurn(c(0, 0), c(1, 1), c(-1, -1), c(1, 1)))

  # Plus end heading backward (toward q_minus) → U-turn
  expect_true(UTurn(c(0, 0), c(1, 1), c(1, 1), c(-0.5, -0.5)))

  # Both heading inward → U-turn
  expect_true(UTurn(c(0, 0), c(1, 1), c(-1, -1), c(-0.5, -0.5)))

  # 1D: no U-turn (both forward)
  expect_false(UTurn(0, 1, 1, 1))

  # 1D: minus end heading left → U-turn
  expect_true(UTurn(0, 1, -1, 1))

  # 1D: plus end heading left → U-turn
  expect_true(UTurn(0, 1, 1, -1))

  # 1D: both heading inward → U-turn
  expect_true(UTurn(0, 1, -1, -1))

  # Identical positions: dq = 0, dot = 0, not < 0 → no U-turn
  expect_false(UTurn(c(1, 1), c(1, 1), c(1, 0), c(0, 1)))
})


# ── Test: LogSumExp helper ─────────────────────────────────────────────────

test_that(".LogSumExp works correctly", {
  skip_on_cran()

  LSE <- StratoBayes:::.LogSumExp
  expect_equal(LSE(0, 0), log(2))
  expect_equal(LSE(log(2), log(3)), log(5))
  expect_equal(LSE(-Inf, 0), 0)
  expect_equal(LSE(-Inf, -Inf), -Inf)
  expect_equal(LSE(1000, 1000), 1000 + log(2))
  expect_equal(LSE(-1000, -1000), -1000 + log(2))
})


# ── Test: NUTS default args ───────────────────────────────────────────────

test_that(".NUTSDefaultArgs produces valid defaults", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  args <- StratoBayes:::.NUTSDefaultArgs(model)

  expect_true(is.numeric(args$massMatInv))
  expect_equal(length(args$massMatInv), model$parametersLengthNotFixed)
  expect_true(all(args$massMatInv == 1.0))
  expect_true(args$stepSize > 0)
  expect_equal(args$maxTreeDepth, 10L)
  expect_equal(args$divergenceMax, 1000)
  expect_true(args$adaptStepSize)
  expect_equal(args$targetAccept, 0.80)

  da <- args$.hmcDA
  expect_true(is.environment(da))
  expect_equal(da$daCounter, 0L)
  expect_equal(da$Hbar, 0)
})


# ── Test: .NUTSBuildTree on synthetic quadratic ──────────────────────────

test_that(".NUTSBuildTree builds correct subtrees on 2D standard normal", {
  skip_on_cran()
  set.seed(4821)

  gradFn <- make_quadratic_grad(sigma = c(1, 1))

  q0 <- c(0.5, -0.3)
  r0 <- c(0.8, 0.6)
  grad0 <- -q0
  logPost0 <- -0.5 * sum(q0^2)
  K0 <- 0.5 * sum(r0^2)
  H0 <- -logPost0 + K0

  # Depth 0: single leapfrog step
  tree0 <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 0L,
    stepSize = 0.1, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_equal(tree0$nLeapfrog, 1L)
  expect_false(tree0$divergent)
  expect_true(tree0$valid)
  expect_true(is.finite(tree0$sumLogWeight))
  expect_equal(length(tree0$q_candidate), 2)
  # Endpoints equal at depth 0 (single leaf)
  expect_equal(tree0$q_minus, tree0$q_plus)

  # Depth 1: two leapfrog steps
  tree1 <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 1L,
    stepSize = 0.1, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_equal(tree1$nLeapfrog, 2L)
  expect_false(tree1$divergent)
  expect_false(all(tree1$q_minus == tree1$q_plus))

  # Depth 3: 8 leapfrog steps — should still be numerically stable
  tree3 <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 3L,
    stepSize = 0.1, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_equal(tree3$nLeapfrog, 8L)
  expect_false(tree3$divergent)
  expect_true(is.finite(tree3$sumLogWeight))
})


test_that(".NUTSBuildTree detects divergence with unstable step size", {
  skip_on_cran()

  gradFn <- make_quadratic_grad(sigma = c(1, 1))

  q0 <- c(0.5, -0.3)
  r0 <- c(0.8, 0.6)
  grad0 <- -q0
  logPost0 <- -0.5 * sum(q0^2)
  K0 <- 0.5 * sum(r0^2)
  H0 <- -logPost0 + K0

  tree <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 3L,
    stepSize = 50.0, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_true(tree$divergent)
})


test_that(".NUTSBuildTree backward direction produces correct leaf count", {
  skip_on_cran()
  set.seed(7193)

  gradFn <- make_quadratic_grad(sigma = c(1, 1))

  q0 <- c(0.5, -0.3)
  r0 <- c(0.8, 0.6)
  grad0 <- -q0
  logPost0 <- -0.5 * sum(q0^2)
  K0 <- 0.5 * sum(r0^2)
  H0 <- -logPost0 + K0

  fwd <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 2L,
    stepSize = 0.1, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  bwd <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = -1L, depth = 2L,
    stepSize = 0.1, massMatInv = c(1, 1),
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_equal(fwd$nLeapfrog, 4L)
  expect_equal(bwd$nLeapfrog, 4L)

  # Forward: q_plus moves away from q0
  expect_false(all(fwd$q_plus == q0))
  # Backward: q_minus moves away from q0
  expect_false(all(bwd$q_minus == q0))
})


test_that(".NUTSBuildTree with anisotropic mass matrix works", {
  skip_on_cran()
  set.seed(2653)

  # Mild anisotropy: sigma = (1, 0.5)
  gradFn <- make_quadratic_grad(sigma = c(1, 0.5))

  q0 <- c(0.5, 0.1)
  grad0 <- -c(q0[1], q0[2] / 0.25)
  logPost0 <- -0.5 * (q0[1]^2 + q0[2]^2 / 0.25)

  # Mass matrix inverse matches target variance: M^{-1} = diag(1, 0.25)
  massMatInv <- c(1, 0.25)
  r0 <- c(0.5, 1.0)
  K0 <- 0.5 * sum(r0^2 * massMatInv)
  H0 <- -logPost0 + K0

  tree <- StratoBayes:::.NUTSBuildTree(
    q0, r0, grad0, logPost0,
    direction = 1L, depth = 2L,
    stepSize = 0.1, massMatInv = massMatInv,
    gradFn = gradFn, freeIdx = 1:2, fullParams = q0,
    temperature = 1, H0 = H0, divergenceMax = 1000
  )

  expect_equal(tree$nLeapfrog, 4L)
  expect_false(tree$divergent)
  expect_true(is.finite(tree$sumLogWeight))
})


# ── Helper: run NUTS via RunStratModel ──────────────────────────────────────

run_nuts_model <- function(sData, sModel, knotRange, nIter = 50,
                           nChains = 2, engine = "R", seed = 8327,
                           nCores = 1L) {
  model <- StratoBayes::StratModel(
    stratData = sData,
    priors = sModel$priors$metro,
    alignmentScale = sModel$alignmentScale,
    sedModel = sModel$sedModel,
    flexibleKnots = FALSE, knotRange = knotRange
  )
  td <- file.path(tempdir(), paste0("nuts_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  result <- RunStratModel(
    stratObject = sData, stratModel = model,
    nIter = nIter, nChains = nChains, seed = seed,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "ntest", engine = engine,
    nCores = nCores
  )

  mcmc <- readRDS(file.path(td, "ntest_mcmc_run_1.rds"))
  # Check that sample files exist (binary preferred, TSV fallback)
  sampleFiles <- list.files(
    td,
    pattern = "_(binarysamples|samples)_run_",
    full.names = TRUE
  )

  list(result = result, mcmc = mcmc, td = td, sampleFiles = sampleFiles)
}


# ── Test: NUTS R engine (stratData1, no ties) ─────────────────────────────

test_that("NUTS R engine runs without error (stratData1, no ties)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 50, engine = "R")
  on.exit(unlink(out$td, recursive = TRUE))

  expect_no_error(out$result)
  mcmc <- out$mcmc

  expect_true("NUTS" %in% names(mcmc$propose))

  nutsIdx <- which(names(mcmc$propose) == "NUTS")
  nutsArgs <- mcmc$metro$proposalArgs[[1]][[nutsIdx]]
  expect_true(!is.null(nutsArgs))
  expect_true(is.numeric(nutsArgs$massMatInv))
  expect_equal(nutsArgs$maxTreeDepth, 10L)

  expect_true(length(out$sampleFiles) > 0)
})


# ── Test: NUTS C++ engine (stratData1, no ties) ──────────────────────────

test_that("NUTS C++ engine runs without error (stratData1, no ties)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 50, engine = "cpp")
  on.exit(unlink(out$td, recursive = TRUE))

  expect_no_error(out$result)
  expect_true("NUTS" %in% names(out$mcmc$propose))
  expect_true(length(out$sampleFiles) > 0)
})


# ── Test: NUTS dual averaging, C++ engine ────────────────────────────────

test_that("NUTS dual averaging produces adapted step size (C++ engine)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 200, nChains = 2, engine = "cpp")
  on.exit(unlink(out$td, recursive = TRUE))

  mcmc <- out$mcmc
  nutsIdx <- which(names(mcmc$propose) == "NUTS")
  finiteChains <- which(is.finite(mcmc$temper$temperatures))

  for (ch in finiteChains) {
    eps <- mcmc$metro$proposalArgs[[ch]][[nutsIdx]][["stepSize"]]
    expect_true(is.finite(eps) && eps > 0,
      info = sprintf("Chain %d: adapted step size should be finite & positive", ch))
  }
})


# ── Test: NUTS dual averaging, R engine ──────────────────────────────────

test_that("NUTS R-engine dual averaging runs without error", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 100, nChains = 2, engine = "R")
  on.exit(unlink(out$td, recursive = TRUE))

  mcmc <- out$mcmc
  nutsIdx <- which(names(mcmc$propose) == "NUTS")

  # After endAdapting, adaptStepSize should be FALSE
  nutsArgs <- mcmc$metro$proposalArgs[[1]][[nutsIdx]]
  expect_false(nutsArgs[["adaptStepSize"]])

  eps <- nutsArgs[["stepSize"]]
  expect_true(is.finite(eps) && eps > 0)
})


# ════════════════════════════════════════════════════════════════════════════
# Phase F: C++ NUTS-specific tests
# ════════════════════════════════════════════════════════════════════════════

# ── Test: C++ NUTS produces different adapted step size than R HMC ─────────
# This confirms the C++ engine is running NUTS tree doubling (with
# targetAccept = 0.80) rather than HMC (targetAccept = 0.65), which
# should yield different adapted step sizes.

test_that("C++ NUTS dual averaging runs during tree doubling", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 200, nChains = 2, engine = "cpp")
  on.exit(unlink(out$td, recursive = TRUE))

  mcmc <- out$mcmc
  nutsIdx <- which(names(mcmc$propose) == "NUTS")
  nutsArgs <- mcmc$metro$proposalArgs[[1]][[nutsIdx]]

  # NUTS should have adapted (step size adaptation was active during warmup)
  # After adaptation, adaptStepSize is FALSE and stepSize is the smoothed value
  expect_false(nutsArgs[["adaptStepSize"]])
  expect_true(is.finite(nutsArgs[["stepSize"]]))
  expect_true(nutsArgs[["stepSize"]] > 0)

  # NUTS-specific fields should be preserved
  expect_equal(nutsArgs[["maxTreeDepth"]], 10L)
  expect_equal(nutsArgs[["divergenceMax"]], 1000)
})


# ── Test: C++ NUTS produces accepting iterations ──────────────────────────
# Verifies that the C++ NUTS engine accepts at least some proposals
# (i.e., the tree doubling actually produces valid candidates).

test_that("C++ NUTS engine accepts proposals (stratData1)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                        nIter = 100, nChains = 2, engine = "cpp")
  on.exit(unlink(out$td, recursive = TRUE))

  rds_file <- file.path(out$td, "ntest_binarysamples_run_1.rds")
  tsv_file <- file.path(out$td, "ntest_samples_run_1.txt")
  expect_true(file.exists(rds_file) || file.exists(tsv_file))
  if (file.exists(rds_file)) {
    samples <- as.data.frame(readRDS(rds_file))
  } else {
    samples <- read.delim(tsv_file)
  }
  expect_true(nrow(samples) > 1)

  # Parameter columns should have variation (some proposals accepted)
  paramCols <- setdiff(names(samples), c("iteration", "chain"))
  if (length(paramCols) > 0) {
    sds <- sapply(samples[paramCols], sd, na.rm = TRUE)
    expect_true(any(sds > 0),
      info = "C++ NUTS should accept at least some proposals")
  }
})


# ── Test: Both engines produce comparable output ──────────────────────────
# R-engine and C++ engine should both produce finite logPost values and
# non-trivial sample variation.  They won't be identical (different RNGs).

test_that("R and C++ NUTS engines produce comparable results", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  out_r <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                          nIter = 100, nChains = 2, engine = "R", seed = 5519)
  on.exit(unlink(out_r$td, recursive = TRUE), add = TRUE)

  out_cpp <- run_nuts_model(stratData1, stratModel1, c(-5, 12),
                            nIter = 100, nChains = 2, engine = "cpp", seed = 5519)
  on.exit(unlink(out_cpp$td, recursive = TRUE), add = TRUE)

  # Both should have NUTS registered
  expect_true("NUTS" %in% names(out_r$mcmc$propose))
  expect_true("NUTS" %in% names(out_cpp$mcmc$propose))

  # Both should produce sample files
  expect_true(length(out_r$sampleFiles) > 0)
  expect_true(length(out_cpp$sampleFiles) > 0)

  # Both should have finite adapted step sizes
  nutsIdx_r <- which(names(out_r$mcmc$propose) == "NUTS")
  nutsIdx_cpp <- which(names(out_cpp$mcmc$propose) == "NUTS")
  eps_r <- out_r$mcmc$metro$proposalArgs[[1]][[nutsIdx_r]]$stepSize
  eps_cpp <- out_cpp$mcmc$metro$proposalArgs[[1]][[nutsIdx_cpp]]$stepSize
  expect_true(is.finite(eps_r) && eps_r > 0)
  expect_true(is.finite(eps_cpp) && eps_cpp > 0)
})
