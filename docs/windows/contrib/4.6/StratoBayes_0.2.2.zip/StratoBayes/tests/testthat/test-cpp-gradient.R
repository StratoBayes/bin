# Tests for gradient computation (HMC infrastructure)
#
# Verifies analytical gradients against finite-difference approximations
# computed via the C++ engine's .sb_eval_logpost export.
#
# The gradient currently supports fixed knots only (flexibleKnots = FALSE).

# ── Helper: create engine from data/model, run short MCMC ────────────────────

make_test_engine <- function(sData, sModel, knotRange = NULL) {
  # If the model uses flexible knots, recreate with fixed knots
  if (sModel$flexibleKnots && !is.null(knotRange)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }

  td <- file.path(tempdir(), paste0("grad_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(7261)
  result <- RunStratModel(
    stratObject = sData,
    stratModel  = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gtest",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gtest_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj,
    state = state_obj, tiesCallback = tiesCallback
  )

  list(
    engine_ptr = engine_ptr,
    data_obj   = data_obj,
    model_obj  = model_obj,
    mcmc_obj   = mcmc_obj,
    state_obj  = state_obj,
    tiesCallback = tiesCallback,
    params     = state_obj[[1]]$metro$parameters,
    free_idx   = model_obj$ind$paramNotFixed,
    td         = td
  )
}


# ── Helper: compute FD gradient via C++ engine ────────────────────────────────

cpp_fd_gradient <- function(setup, h = 1e-5) {
  nFree <- length(setup$free_idx)
  grad_fd <- numeric(nFree)

  for (i in seq_len(nFree)) {
    pidx <- setup$free_idx[i]

    p_plus <- setup$params
    p_plus[pidx] <- p_plus[pidx] + h
    p_minus <- setup$params
    p_minus[pidx] <- p_minus[pidx] - h

    # Fresh engines to avoid state contamination
    ep <- StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    )
    lp_plus <- StratoBayes:::.sb_eval_logpost(ep, 1L, p_plus)

    em <- StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    )
    lp_minus <- StratoBayes:::.sb_eval_logpost(em, 1L, p_minus)

    grad_fd[i] <- (lp_plus - lp_minus) / (2 * h)
  }
  grad_fd
}


# ── Helper: compare gradients with informative failure messages ───────────────

expect_gradients_match <- function(grad_analytical, grad_fd, param_names,
                                    tol = 0.001) {
  for (i in seq_along(grad_analytical)) {
    scale <- max(abs(grad_analytical[i]), abs(grad_fd[i]), 1e-8)
    rel_err <- abs(grad_analytical[i] - grad_fd[i]) / scale
    expect_true(
      rel_err < tol,
      info = sprintf(
        "Param '%s': analytical=%.6e, fd=%.6e, rel_err=%.4e (tol=%.4e)",
        param_names[i], grad_analytical[i], grad_fd[i], rel_err, tol
      )
    )
  }
}


# ── Test: stratData1 (height/site, fixed knots) ──────────────────────────────

test_that("gradient matches FD for stratData1 with fixed knots", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  setup <- make_test_engine(stratData1, stratModel1, knotRange = c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: stratData2 (age/site, with ties) ───────────────────────────────────

test_that("gradient matches FD for stratData2 with ties", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  setup <- make_test_engine(stratData2, stratModel2, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: stratData3 (partition model) ────────────────────────────────────────

test_that("gradient matches FD for stratData3 with partitions", {
  skip_on_cran()

  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")

  setup <- make_test_engine(stratData3, stratModel3, knotRange = c(-5, 15))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: stratData4 (partition model, 2 sites) ──────────────────────────────

test_that("gradient matches FD for stratData4 with partitions and 2 sites", {
  skip_on_cran()

  data(stratData4, package = "StratoBayes")
  data(stratModel4, package = "StratoBayes")

  setup <- make_test_engine(stratData4, stratModel4, knotRange = c(-5, 30))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: flexible knots rejected ────────────────────────────────────────────

test_that("gradient rejects flexible-knots models", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # Use the default flexible-knots model
  td <- file.path(tempdir(), "grad_flex_reject")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4382)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gflex",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gflex_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj, state = state_obj
  )

  expect_error(
    StratoBayes:::.sb_compute_gradient(engine_ptr, 1L),
    "fixed knots"
  )
})
