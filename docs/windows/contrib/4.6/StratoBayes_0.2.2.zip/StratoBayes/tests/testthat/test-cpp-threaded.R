# T-016: Intra-run chain parallelism via std::thread
#
# Verifies that the C++ engine produces valid MCMC output when chain updates
# run in parallel (nThreads > 1). Does NOT test for bit-exact reproducibility
# because per-chain ThreadRNGs produce different streams than sequential mode.

test_that("C++ engine works with nThreads = 2", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "thread_test")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(3841)
  res <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 100, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "threaded",
    engine = "cpp", nThreads = 2L
  )

  expect_s3_class(res, "StratPosterior")

  rds_file <- file.path(td, "threaded_binarysamples_run_1.rds")
  samples_file <- file.path(td, "threaded_samples_run_1.txt")
  expect_true(file.exists(rds_file) || file.exists(samples_file))

  if (file.exists(rds_file)) {
    mat <- readRDS(rds_file)
    n_rows <- nrow(mat)
    logpost <- mat[, "posterior"]
    accept <- mat[, "proposal_accepted"]
  } else {
    samples <- read.delim(samples_file, header = FALSE, stringsAsFactors = FALSE)
    header <- as.character(samples[1, ])
    data_rows <- samples[-1, , drop = FALSE]
    n_rows <- nrow(data_rows)
    post_col <- which(header == "posterior")
    logpost <- as.numeric(data_rows[, post_col])
    accept_col <- which(header == "proposal_accepted")
    accept <- as.numeric(data_rows[, accept_col])
  }

  expect_equal(n_rows, 100)
  expect_true(all(is.finite(logpost)))
  expect_true(any(accept == 1))
})


test_that("C++ engine with nThreads works across model configs", {
  configs <- list(
    list(data = "stratData1", model = "stratModel1", label = "height/site"),
    list(data = "stratData3", model = "stratModel3", label = "partition")
  )

  for (cfg in configs) {
    data(list = cfg$data, package = "StratoBayes", envir = environment())
    data(list = cfg$model, package = "StratoBayes", envir = environment())

    td <- file.path(tempdir(), paste0("thread_", cfg$data))
    dir.create(td, showWarnings = FALSE, recursive = TRUE)

    set.seed(5092)
    res <- RunStratModel(
      stratObject = get(cfg$data), stratModel = get(cfg$model),
      nIter = 50, nChains = 4, seed = 1, quiet = TRUE,
      visualise = FALSE, modelDir = td, modelName = "mt",
      engine = "cpp", nThreads = 2L
    )

    expect_s3_class(res, "StratPosterior")

    rds_file <- file.path(td, "mt_binarysamples_run_1.rds")
    samples_file <- file.path(td, "mt_samples_run_1.txt")
    if (file.exists(rds_file)) {
      mat <- readRDS(rds_file)
      logpost <- mat[, "posterior"]
    } else {
      samples <- read.delim(samples_file, header = FALSE, stringsAsFactors = FALSE)
      data_rows <- samples[-1, , drop = FALSE]
      header <- as.character(samples[1, ])
      post_col <- which(header == "posterior")
      logpost <- as.numeric(data_rows[, post_col])
    }

    expect_true(all(is.finite(logpost)))

    unlink(td, recursive = TRUE)
  }
})


test_that("nThreads = 0 falls back to sequential (no regression)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "seq_fallback")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(8274)
  res <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 30, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "seq",
    engine = "cpp", nThreads = 0L
  )

  expect_s3_class(res, "StratPosterior")
})
