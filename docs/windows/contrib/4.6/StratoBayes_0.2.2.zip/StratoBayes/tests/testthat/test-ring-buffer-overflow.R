# T-069: Ring buffer overflow in batch monitoring
#
# The ring buffer had fixed capacity 1000 records. A batch of nIter × nChains
# records could overflow it, causing only the last ~1000/nChains iterations to
# be returned to R. The fix resizes the buffer at the start of each sb_run_block
# call.
#
# We verify by running a model with enough iterations for the batch to exceed
# the old 1000-record limit (4 chains × 300+ iters = 1200+ records), and
# checking that acceptance monitoring produces valid results.

test_that("C++ engine handles batches exceeding 1000 ring buffer records", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "ring_overflow_test")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(6193)
  # 500 iterations × 4 chains = 2000 records per batch (> old 1000 limit)
  res <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 500, nChains = 4, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "overflow",
    engine = "cpp"
  )

  expect_s3_class(res, "StratPosterior")

  # Read samples and verify all expected rows are present
  rds_file <- file.path(td, "overflow_binarysamples_run_1.rds")
  samples_file <- file.path(td, "overflow_samples_run_1.txt")
  expect_true(file.exists(rds_file) || file.exists(samples_file))

  if (file.exists(rds_file)) {
    mat <- readRDS(rds_file)
    n_rows <- nrow(mat)
    logpost <- mat[, "posterior"]
  } else {
    samples <- read.delim(samples_file, header = FALSE, stringsAsFactors = FALSE)
    header <- as.character(samples[1, ])
    data_rows <- samples[-1, , drop = FALSE]
    n_rows <- nrow(data_rows)
    post_col <- which(header == "posterior")
    logpost <- as.numeric(data_rows[, post_col])
  }

  # Should have 500 rows (one per saved iteration)
  expect_equal(n_rows, 500)

  # All posterior values should be finite (no NA from mislabelled records)
  expect_true(all(is.finite(logpost)))
})
