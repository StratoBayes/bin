## inst/gui/dialog/modelSelectionModal.R
modelSelectionModal <- function() {
  detectedCores <- tryCatch(parallel::detectCores(logical = TRUE), error = function(e) NA_integer_)
  if (is.na(detectedCores) || detectedCores < 1L) detectedCores <- 1L
  defaultThreads <- max(1L, detectedCores - 1L)

  modalDialog(
    title = NULL,
    size = "l",
    fade = FALSE,
    easyClose = FALSE,

    # View 1: Load data screen
    conditionalPanel(
      "output.modalView === 'load'",
      fluidPage(
        tags$div(
          class = "load-data-modal-header",
          tags$h3("Load data", class = "load-data-modal-header-title")
        ),
        fluidRow(
          column(6,
                 # Load options on the left
                 tags$div(
                   style = "margin-bottom: 20px;",
                   # Option 1: Load signal source (always shown)
                   tags$div(
                     style = "margin-bottom: 15px; padding: 10px; background-color: #e8f5e9; border-radius: 5px;",
                     tags$strong("Option 1: Load signal source"),
                     tags$p("Load data from a file or example dataset.", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                     conditionalPanel(
                       "!output.loadedSavedDataset",
                       selectInput("dataSource", "Signal source",
                                  c("Data file" = "file",
                                    "Example dataset 1" = "example-signal-1.csv",
                                    "Example dataset 2" = "00-ohio-3-wells.csv")
                       ),

                      fileInput("dataFile",
                               "Browse CSV or LAS files",
                               accept = c(".csv", ".xls", ".xlsx", ".las"),
                               multiple = TRUE
                       ),

                      # Excel‐options only if it *looks* like Excel
                      conditionalPanel(
                        "input.dataFile && input.dataFile.name.match(/\\.xls[x]?$/)",
                        selectInput("readxl.sheet", "Excel sheet to read:", choices = NULL),
                        numericInput("readxlSkip",     "Skip rows",    min = 0, value = 1),
                        numericInput("readxlSkipCols", "Skip columns", min = 0, value = 1)
                      ),

                       # Add more LAS files: show whenever LAS state is present,
                       # independent of dataSource (so it stays available after
                       # merges / renames / saved-dataset loads).
                       conditionalPanel(
                         "output.showAddLasFiles",
                         tags$div(
                           style = "margin-top: 8px; padding: 8px; background-color: #f0f8ff; border-radius: 4px;",
                           uiOutput("lasWellCount_ui"),
                           fileInput("addLasFiles",
                                     "Add more LAS files",
                                     accept = ".las",
                                     multiple = TRUE)
                         )
                       )
                     ),
                     conditionalPanel(
                       "output.loadedSavedDataset",
                       tags$div(
                         style = "padding: 10px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;",
                         tags$strong("Saved dataset loaded"),
                         br(),
                         tags$p("Current data is from a saved dataset.", style = "font-size: 0.9em; margin-top: 5px;"),
                         actionButton("loadNewSignalSource", "Load New Signal Source",
                                     class = "btn-sm btn-warning",
                                     style = "margin-top: 5px;",
                                     icon = icon("refresh"))
                       )
                     )
                   ),

                   # Option 2: Load saved dataset (only if available)
                   conditionalPanel(
                     "output.savedDatasetsCount > 0",
                     tags$div(
                       style = "margin-bottom: 15px; padding: 10px; background-color: #e3f2fd; border-radius: 5px;",
                       tags$strong("Option 2: Load saved dataset"),
                       tags$p("Load a previously saved dataset with all settings and partitions.", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                       uiOutput("savedDatasetsSelector"),
                       actionButton("loadDataset", "Load Dataset",
                                   class = "btn-sm btn-success",
                                   style = "margin-top: 5px;")
                     )
                   ),

                   # Option 3: Load data from saved result (only if available)
                   conditionalPanel(
                     "output.savedResultsCount > 0",
                     tags$div(
                       style = "margin-bottom: 15px; padding: 10px; background-color: #f3e5f5; border-radius: 5px;",
                       tags$strong("Option 3: Load data from saved result"),
                       tags$p("Load data from a StratPosterior object (e.g., stratPosterior0$data).", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                       uiOutput("savedResultsForDataSelector"),
                       actionButton("loadDataFromResult", "Load Data from Result",
                                   class = "btn-sm btn-info",
                                   style = "margin-top: 5px;")
                     )
                   )
                 )
          ),

          column(6, class = "load-data-column-tight",
                 # Column selection and settings on the right - show when file is selected or data is loaded
                 conditionalPanel(
                   "output.hasDataOrFile",
                   uiOutput("siteColumn_alert_ui"),
                   # dynamic siteColumn
                   uiOutput("siteColumn_ui"),

                   uiOutput("zColumn_alert_ui"),
                   # dynamic zColumn
                   uiOutput("zColumn_ui"),
                   # Prompt when no log curves are selected (kept separate so the
                   # select widget is not re-created on every toggle).
                   uiOutput("signalColumns_alert_ui"),
                   # dynamic signalColumns
                   uiOutput("signalColumns_ui"),
                   
                   # Wells to include (rename wells) – single output keeps one line
                   tags$div(style = "margin-top: 4px;"),
                   uiOutput("wellsToIncludeHeader_ui"),
                   uiOutput("wellsToInclude_ui"),

                   # Vertical axis (depth vs height): compact collapsed summary.
                   tags$details(
                     class = "sb-data-scale-details",
                     style = "margin-top: 10px; padding: 8px; background-color: #f7f7f7; border: 1px solid #ddd; border-radius: 5px; color: #6c757d;",
                     tags$summary(
                       style = "cursor:pointer;",
                       tags$strong("Vertical axis: "),
                       uiOutput("dataScale_summary_ui", inline = TRUE)
                     ),
                     tags$div(
                       style = "margin-top: 8px;",
                       radioButtons(
                         "dataScale",
                         label = NULL,
                         choices = c(
                           "Depth along hole (increases down the well)" = "depth",
                           "Height / elevation (increases upward, e.g. outcrop)" = "height"
                         ),
                         selected = "depth",
                         inline = FALSE
                       )
                     )
                   ),

                    # Performance: collapsed by default so it doesn't clutter
                    # the data-load screen. Expand to tune thinning and threads.
                    tags$details(
                      style = "margin-top: 8px; padding: 8px; background-color: #f7f7f7; border: 1px solid #ddd; border-radius: 5px;",
                      tags$summary(
                        style = "cursor:pointer; max-width:100%;",
                        tags$span(
                          style = "display:inline-flex; align-items:center; gap:6px;",
                          tags$strong("Performance"),
                          tags$span(
                            class = "formations-partitions-tooltip",
                            style = "color:#6c757d; font-size:0.9em;",
                            icon("circle-info", class = "fas"),
                            tags$span(
                              class = "formations-partitions-tooltiptext",
                              "Reduce data points and choose how many worker threads the model run can use."
                            )
                          )
                        ),
                        tags$br(),
                        uiOutput("performanceActiveBadges", inline = TRUE)
                      ),
                      tags$div(
                        style = "margin-top: 6px;",
                        tags$strong("Downsample data"),
                        radioButtons("downsampleMode", NULL,
                                     choices = c("Per site" = "persite",
                                                 "Total"    = "total",
                                                "Off"      = "none"),
                                    selected = "persite", inline = TRUE),
                       conditionalPanel(
                         "input.downsampleMode === 'persite'",
                         sliderInput("downsamplePerSiteN",
                                     "Max points per site",
                                     min = 50, max = 20000, value = 1000, step = 50,
                                     width = "100%")
                       ),
                       conditionalPanel(
                         "input.downsampleMode === 'total'",
                         sliderInput("downsampleTotalN",
                                     "Total points across sites",
                                      min = 100, max = 50000, value = 5000, step = 100,
                                      width = "100%")
                        ),
                        tags$hr(style = "margin: 10px 0;"),
                        checkboxInput("useMultithreading",
                                      "Use multithreading for model runs",
                                      value = TRUE,
                                      width = "100%"),
                        conditionalPanel(
                          "input.useMultithreading",
                          sliderInput("nThreads",
                                      "Worker threads",
                                      min = 1,
                                      max = max(1L, detectedCores),
                                      value = defaultThreads,
                                      step = 1,
                                      width = "100%"),
                          tags$div(
                            style = "font-size:0.85em; color:#666; margin-top:-6px;",
                            sprintf("Detected %s core%s; default leaves one free.",
                                    detectedCores,
                                    if (detectedCores == 1L) "" else "s")
                          )
                        )
                      )
                    ),

                  # Partition setup: source kept in hidden input
                   tags$div(
                     style = "display: none;",
                     selectInput("partitionSource", NULL,
                                 choices = c("No partitions" = "none",
                                             "Auto partitions" = "auto",
                                             "Point & Click" = "interactive"),
                                 selected = "none")
                   ),
                  tags$details(
                    style = "margin-top: 10px; padding: 8px; background-color: #f7f7f7; border: 1px solid #ddd; border-radius: 5px;",
                    tags$summary(
                      style = "cursor:pointer;",
                      tags$strong("Formations / partitions"),
                      tags$span(
                        style = "margin-left:6px; color:#6c757d; font-size:0.9em;",
                        "(default: 2 formations per well)"
                      )
                    ),
                    tags$div(
                      style = "margin-top: 8px; display: flex; align-items: center; gap: 6px;",
                      actionButton("addFormationsPartitions", "Adjust formations / partitions",
                                  icon = icon("layer-group"),
                                  class = "btn-default btn-sm"),
                      tags$span(
                        class = "formations-partitions-tooltip",
                        style = "color: #6c757d; font-size: 0.9em; flex-shrink: 0;",
                        icon("circle-info", class = "fas"),
                        tags$span(
                          class = "formations-partitions-tooltiptext",
                          HTML("Default adds one internal boundary per site (2 formations total). Open this only if you want to change boundaries manually or use more partitions.")
                        )
                      )
                    )
                  ),
                   conditionalPanel(
                     "output.signalValid",
                     div(
                       class = "load-data-next-actions",
                       actionButton(
                         "lookAtData", "View data",
                         class = "btn-info btn-lg load-data-next-primary",
                         icon = icon("eye")
                       ),
                       tags$div(
                         class = "load-data-next-secondary",
                         actionButton(
                           "showSaveData", "Save data",
                           class = "btn-warning btn-sm",
                           icon = icon("save")
                         ),
                         actionButton(
                           "quickRun", "Quick run",
                           class = "btn-success btn-sm",
                           icon = icon("bolt")
                         ),
                         actionButton(
                           "customRun", "Custom run",
                           class = "btn-primary btn-sm",
                           icon = icon("cog")
                         )
                       ),
                       conditionalPanel(
                         "output.showSaveDataField",
                         tags$div(
                           style = "margin-top: 12px; padding: 12px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 5px; text-align: left;",
                           fluidRow(
                             column(8,
                               textInput("saveDataNameInput", "Dataset name:",
                                        value = "",
                                        placeholder = "Enter a name (or leave empty for auto-name)",
                                        width = "100%")
                             ),
                             column(4,
                               actionButton("confirmSaveData", "Save",
                                          class = "btn-primary",
                                          style = "margin-top: 25px; width: 100%;"),
                               actionButton("cancelSaveData", "Cancel",
                                          class = "btn-secondary",
                                          style = "margin-top: 5px; width: 100%;")
                             )
                           )
                         )
                       )
                     )
                   )
                 )
          )
        ),

        # Preview table (full width, scrollable); primary actions follow underneath
        fluidRow(
          column(12,
                 tags$div(
                   style = "display: flex; align-items: baseline; gap: 10px;",
                   tags$h4("Data Preview", style = "margin-right: 6px;"),
                   uiOutput("renameColumns_ui", inline = TRUE)
                 ),
                 uiOutput("renameColumnsPanel_ui"),
                 uiOutput("mergeColumnsPanel_ui"),
                 div(style = "overflow-x: auto; overflow-y: auto; max-height: 400px; width: 100%;",
                     tableOutput("dataHead")
                 )
          )
        ),

      )
    ),

    # View 2: Data preview screen (uses data_view_module)
    conditionalPanel(
      "output.modalView === 'view'",
      fluidPage(
        tags$h3("View Data"),
        helpText("Choose what to display, then run or adjust the model."),
        conditionalPanel(
          "output.signalValid",
          # Module UI (controls + plot)
          data_view_ui("dataview"),
          br(),
          # Bottom-right actions: use unique IDs for view panel buttons
          fluidRow(
            column(12,
                   div(
                     style = "display:flex; justify-content:flex-end; gap:10px;",
                     actionButton("quickRun_view", "Quick Run",
                                 class = "btn-success",
                                 icon = icon("bolt")),
                     actionButton("customRun_view", "Custom Run",
                                 class = "btn-info",
                                 icon = icon("cog"))
                   )
            )
          )
        ),
        conditionalPanel(
          "!output.signalValid",
          tags$p("No valid data to display yet.")
        )
      )
    ),


    # View 3: Custom run panel (no tabs, single view)
    conditionalPanel(
      "output.modalView === 'customRun'",
      fluidPage(
        # Saved model settings selector (moved from load view)
        conditionalPanel(
          "output.savedModelSettingsCount > 0",
          tags$div(
            style = "margin-bottom: 15px; padding: 10px; background-color: #e3f2fd; border-radius: 5px;",
            tags$strong("Load saved model settings"),
            uiOutput("savedModelSettingsSelector"),
            actionButton("loadModelSettings", "Load Settings",
                        class = "btn-sm btn-success",
                        style = "margin-top: 5px;")
          )
        ),

        # Model setup tabs
        tabsetPanel(
          id = "modelTabs",
          tabPanel("Model structure", value = "structure",
                   # Hidden input to set alignmentScale to "height" (only option currently supported)
                   tags$div(style = "display: none;",
                     textInput("alignmentScale", NULL, value = "height")
                   ),
                   fluidRow(
                     column(6,
                            selectInput("sedModel", "Sedimentation model",
                                       c("Site" = "site",
                                         "Partition" = "partition",
                                         "Site × Partition" = "site x partition",
                                         "Site, Partition" = "site, partition")),
                            selectInput("alphaPosition", "Alpha position",
                                       c("Top" = "top",
                                         "Middle" = "middle",
                                         "Bottom" = "bottom",
                                         "Custom" = "custom"),
                                       selected = "middle"),
                            # Conditional panel for custom alpha numeric inputs
                            conditionalPanel(
                              "input.alphaPosition === 'custom'",
                              uiOutput("customAlphaInputs"),
                              actionButton("updateAlphaPositions", "Update alphas",
                                          class = "btn-primary",
                                          style = "margin-top: 10px;")
                            )
                     ),
                     column(6,
                            uiOutput("siteModelNote")
                     )
                   ),
                   br(),
                   plotOutput("structureSignal", height = "420px")
          ),
          tabPanel("Priors", value = "prior",
                   uiOutput("priorUI"),
                   br(),
                   plotOutput("priorSignal", height = "420px")
          ),
          tabPanel("Run", value = "run",
                   uiOutput("runUI"),
                   br(),
                   fluidRow(
                     column(6,
                            numericInput("nRun", "Number of runs", value = 1, min = 1, max = 10, step = 1),
                            numericInput("nIter", "Iterations", value = 1000, min = 100, step = 100),
                            numericInput("nThin", "Thinning", value = 1, min = 1, step = 1)
                     ),
                     column(6,
                            numericInput("nChains", "Chains", value = 8, min = 1, max = 100, step = 1),
                            br(),
                            textInput("saveModelSettingsName", "Save settings as (optional):",
                                    placeholder = "Leave empty for auto-name"),
                            br(),
                            actionButton("runModel", "Run Model",
                                       class = "btn-primary btn-lg",
                                       style = "width: 100%;")
                     )
                   ),
                   br(),
                   uiOutput("runIframeUI")
          )
        )
      )
    ),

    footer = tagList(
      # Previous button - only show when NOT in load view
      conditionalPanel(
        "output.modalView !== 'load'",
        actionButton("previousStep", "Back", class = "btn-secondary", style = "float: left;")
      ),
      # Look at Data button - shown when in customRun view
      conditionalPanel(
        "output.modalView === 'customRun'",
        actionButton("lookAtDataFromModal", "Look at Data",
                    class = "btn-info",
                    style = "float: left; margin-left: 10px;",
                    icon = icon("eye"))
      ),
      # Next button - only show when NOT in load view and NOT in view (View Data) view
      conditionalPanel(
        "output.modalView !== 'load' && output.modalView !== 'view'",
        div(style = "float: right; margin-right: 10px;",
            actionButton("nextStep", "Next", class = "btn-primary")
        )
      ),
      # Close button - always visible, always on the right
      div(style = "float: right;",
          actionButton("closeModal", "Close", class = "btn-default")
      )
    )
  )
}
