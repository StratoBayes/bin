## inst/gui/dialog/partitionModal.R

## Left column content: point & click controls (optional Auto block between Add Partition and Clear/Done)
partitionModalLeftColumn <- function(includeAuto = FALSE) {
  out <- list(
    selectInput("partitionSite", "Select well",
                choices = NULL, width = "100%"),
    uiOutput("manualHeightInput"),
    textInput("partitionName", "Partition Name",
              placeholder = "e.g., Unit A", width = "100%"),
    actionButton("addPartition", "Add Partition",
                 class = "btn-success partition-modal-btn", style = "width: 100%;")
  )
  if (includeAuto) {
    out <- c(out, list(
      tags$div(
        class = "partition-auto-block",
        style = "margin: 8px 0; padding: 8px; border: 1px solid #0dcaf0; border-radius: 6px; background: #cff4fc;",
        uiOutput("partitionOverwriteConfirm_ui", inline = TRUE),
        actionButton("addAutoPartitions", "Auto Partitions",
                     class = "btn-info partition-modal-btn", style = "width: 100%;"),
        numericInput("nStrata", "Number of strata",
                     value = 2, min = 1, max = 8, step = 1, width = "100%"),
        selectInput("distributeMethod", "Distribution method",
                    c("Litho change points" = "StratoSegment",
                      "Equal points" = "points",
                      "Equal height" = "height"),
                    selected = "StratoSegment", width = "100%")
      )
    ))
  }
  out <- c(out, list(
    tags$div(class = "partition-modal-buttons",
      actionButton("clearPartitions", "Clear All",
                   class = "btn-warning partition-modal-btn", style = "width: 100%;"),
      tags$div(style = "margin-top: 8px;"),
      actionButton("donePartitions", "Done",
                   class = "btn-primary partition-modal-btn", style = "width: 100%;")
    )
  ))
  out
}

## Shared body for point & click UI (used in partitionModal and formationsPartitionsModal)
partitionModalBody <- function(includeAuto = FALSE) {
  fluidRow(
    column(3, partitionModalLeftColumn(includeAuto = includeAuto)),
    column(9,
           tags$h4("Click or use height input to set partition tops"),
           plotOutput("partitionPlot",
                     click = "partitionClick",
                     brush = "partitionBrush",
                     height = "500px"),
           br(),
           tags$h5("Current Partition Tops:"),
           tags$p("Edit names in the table; use Done to save.", style = "font-size: 0.9em; color: #666; margin-bottom: 5px;"),
           uiOutput("partitionTable")
    )
  )
}

## Point & Click only (no Auto block)
partitionModal <- function() {
  modalDialog(
    title = "Create Partition Tops - Point & Click",
    size = "xl",
    fade = FALSE,
    easyClose = FALSE,
    fluidPage(partitionModalBody(includeAuto = FALSE)),
    footer = tagList(
      actionButton("previousStep", "Back", class = "btn-secondary", style = "float: left;")
    )
  )
}

## Combined popup: Point & Click with Auto at bottom left; Done leads to save
formationsPartitionsModal <- function() {
  modalDialog(
    title = "Add Formations / Partitions",
    size = "xl",
    fade = FALSE,
    easyClose = FALSE,
    fluidPage(partitionModalBody(includeAuto = TRUE)),
    footer = tagList(
      actionButton("previousStep", "Back", class = "btn-secondary", style = "float: left;")
    )
  )
}
