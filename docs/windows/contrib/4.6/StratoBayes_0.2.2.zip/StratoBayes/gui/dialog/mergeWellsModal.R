## inst/gui/dialog/mergeWellsModal.R
## Merge wells popup – close only this modal (single removeModal), not all popups.
## Shiny does not stack modals, so the calling code is responsible for re-showing
## the Load Data modal after this one closes (see mergeWellsModalClose observer).
mergeWellsModal <- function() {
  modalDialog(
    title = "Merge wells",
    size = "m",
    fade = FALSE,
    easyClose = TRUE,

    tags$p(
      "Select two or more wells to combine into one (outer join on depth). ",
      "Duplicate curve names are coalesced at matching depths or kept with a ",
      "per-well suffix when values differ at the same depth.",
      style = "font-size: 0.9em; color: #666; margin-bottom: 10px;"
    ),
    uiOutput("mergeWellsModalContent_ui"),

    footer = tagList(
      actionButton("mergeWellsModalClose", "Close", class = "btn-default")
    )
  )
}
