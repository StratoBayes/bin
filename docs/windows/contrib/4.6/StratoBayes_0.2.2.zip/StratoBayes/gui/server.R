# inst/gui/server.R

server <- function(input, output, session) {

  logging <- isTRUE(getOption("StratoBayes.logging"))
  serverEnv <- environment()

  logIndent <- 0
  loggingOn <- TRUE
  cmdLogFile <- tempfile("StratoBayes-", fileext = ".R")

  source("constants.R", local = TRUE)
  for (script in list.files(c("R", "dialog"), "\\.R$", full.names = TRUE)) {
    source(script, local = serverEnv)
  }

  # Source partition save modal (needs to be available in data-module scope)
  source("dialog/partitionSaveModal.R", local = serverEnv)
  # Source model progress modal
  source("dialog/modelProgressModal.R", local = serverEnv)
  # Source close confirmation modal
  source("dialog/closeConfirmationModal.R", local = serverEnv)

  r <- reactiveValues(
    dataFiles = 0,
    excelFiles = 0,
    dataFileVisible = TRUE,
    alignment = NULL,
    partitionData = NULL,
    parts_df_basic = NULL,  # Basic partitions from site tops (auto-generated)
    parts_df_added = NULL,  # User-added partitions (auto or point & click)
    modalView = "load",
    savedModelSettings = list(),
    # Persist data and settings across modal opens/closes
    persistedDataset = NULL,
    persistedSiteSelections = NULL,
    persistedColumnSelections = list(siteColumn = NULL, zColumn = NULL, signalColumns = NULL),
    persistedDataSource = NULL,
    persistedPartitionSource = "none",
    persistedDataScale = "depth",
    persistedReferenceSite = NULL,  # Store reference site selection
    savedDatasets = list(),  # Store saved datasets with names
    loadedSavedDataset = FALSE,  # Track if current data is from saved dataset
    currentLoadedDatasetName = NULL,  # Name of currently loaded saved dataset
    lastSavedDataHash = NULL,  # Hash of last saved data to detect changes
    showSaveDataField = FALSE,  # Track if save data field should be visible
    showRenameWellsPanel = FALSE,  # Inline "rename wells" panel (no second modal)
    showRenameColumnsPanel = FALSE,  # Inline "rename columns" panel
    showMergeColumnsPanel = FALSE,  # Inline "merge columns" panel
    mergeColumnsSelected = NULL,     # Columns selected for merge
    mergeColumnsName = NULL,         # Target name for merged column
    mergeColumnsConflictMsg = NULL,  # Conflict warning text (if conflicts found)
    mergeColumnsNeedsPriority = FALSE,  # TRUE when user must pick priority
    mergeColumnsPriority = NULL,     # Chosen priority column
    isRestoringData = FALSE,  # Flag to prevent UpdateData() during data restoration
    savedResults = list(),  # Store saved StratPosterior objects with names
    currentLoadedResultName = NULL,  # Name of currently loaded result
    loadedSavedResult = FALSE,  # Track if current result is from saved results
    isLoadingResult = FALSE,  # Flag to prevent auto-save when loading results
    alphaPriorMeans = list(),  # Store alpha prior means for sites with Normal priors (for prior tab display)
    mergeHistory = list()  # Log of merge operations: list(list(wells=..., merged_name=...), ...)
  )
  priorSettings <- reactiveValues()

  library("StratoBayes")
  if (!requireNamespace("digest", quietly = TRUE)) {
    install.packages("digest")
  }
  library("digest")
  BeginLog()

  # (optional) future/promises
  # library("future"); library("promises"); plan(multisession)

  startOpt <- options("cli.progress_show_after" = 0.1)
  LogMsg("Started server")

  # bind server modules
  data_api   <- data_server(input, output, session, r)
  model_api  <- model_server(input, output, session, data_api, priorSettings, r)
  results_server(input, output, session, data_api, model_api)

  # Compute alpha prior means for sites with Normal priors (for display in prior tab)
  # This reactive updates whenever priorSettings or model indices change
  observe({
    # Access priorSettings to create reactive dependency
    priorSettings_list <- reactiveValuesToList(priorSettings)

    if (data_api$signalValid() && !is.null(model_api) && !is.null(model_api$indices)) {
      tryCatch({
        idx <- model_api$indices()
        if (!is.null(idx) && length(idx$names) > 0) {
          alpha_prior_means <- list()
          # Find all alpha parameters
          alpha_names <- idx$names[grepl("^alpha_", idx$names, ignore.case = TRUE)]
          for (alpha_name in alpha_names) {
            prior <- priorSettings[[alpha_name]]
            if (!is.null(prior) && !is.null(prior$priorType) && prior$priorType == "Normal") {
              # Extract site name from alpha_name (e.g., "alpha_site2" -> "site2")
              site_name <- sub("^alpha_", "", alpha_name)
              if (!is.null(prior$normalMean) && is.finite(prior$normalMean)) {
                alpha_prior_means[[site_name]] <- prior$normalMean
              }
            }
          }
          r$alphaPriorMeans <- alpha_prior_means
        } else {
          r$alphaPriorMeans <- list()
        }
      }, error = function(e) {
        r$alphaPriorMeans <- list()
      })
    } else {
      r$alphaPriorMeans <- list()
    }
  })
  # Mount the View module (namespaced as "dataview")
  data_view_server("dataview", data_api)


  # Expose modal view state to UI
  output$modalView <- reactive(r$modalView)
  outputOptions(output, "modalView", suspendWhenHidden = FALSE)

  # Expose current modelTabs value for conditionalPanel
  output$modelTabsCurrent <- reactive(input$modelTabs)
  outputOptions(output, "modelTabsCurrent", suspendWhenHidden = FALSE)

  # Show/hide navigation buttons based on state
  # Note: Buttons are now conditionally rendered in UI, but we still need to handle
  # Next button visibility in customRun view based on current tab
  observe({
    # Next button - hide in "run" tab of customRun view
    if (r$modalView == "customRun") {
      currentTab <- input$modelTabs
      if (!is.null(currentTab) && currentTab == "run") {
        shinyjs::hide("nextStep")
      } else {
        shinyjs::show("nextStep")
      }
    }
  })

  # Expose saved model settings count
  output$savedModelSettingsCount <- reactive(length(r$savedModelSettings))
  outputOptions(output, "savedModelSettingsCount", suspendWhenHidden = FALSE)

  # Saved model settings selector
  output$savedModelSettingsSelector <- renderUI({
    savedNames <- names(r$savedModelSettings)
    if (length(savedNames) > 0) {
      selectInput("loadModelSettingsSelect", "Select saved settings:",
                  choices = c("", savedNames),
                  selected = "")
    } else {
      tags$p("No saved model settings available.")
    }
  })

  # Saved datasets selector
  output$savedDatasetsSelector <- renderUI({
    savedNames <- names(r$savedDatasets)
    if (length(savedNames) > 0) {
      selectInput("loadDatasetSelect", "Select saved dataset:",
                  choices = c("", savedNames),
                  selected = "")
    } else {
      tags$p("No saved datasets available.")
    }
  })

  # Saved results selector for loading data
  output$savedResultsForDataSelector <- renderUI({
    savedNames <- names(r$savedResults)
    if (length(savedNames) > 0) {
      selectInput("loadDataFromResultSelect", "Select saved result:",
                  choices = c("", savedNames),
                  selected = "")
    } else {
      tags$p("No saved results available.")
    }
  })

  # Saved results selector for loading model
  output$savedResultsForModelSelector <- renderUI({
    savedNames <- names(r$savedResults)
    if (length(savedNames) > 0) {
      selectInput("loadModelFromResultSelect", "Select saved result:",
                  choices = c("", savedNames),
                  selected = "")
    } else {
      tags$p("No saved results available.")
    }
  })

  # Expose saved datasets count
  output$savedDatasetsCount <- reactive(length(r$savedDatasets))
  outputOptions(output, "savedDatasetsCount", suspendWhenHidden = FALSE)

  # Expose whether a saved dataset is loaded
  output$loadedSavedDataset <- reactive(r$loadedSavedDataset)
  outputOptions(output, "loadedSavedDataset", suspendWhenHidden = FALSE)

  # Expose whether save data field should be visible
  output$showSaveDataField <- reactive(r$showSaveDataField)
  outputOptions(output, "showSaveDataField", suspendWhenHidden = FALSE)

  # Expose whether overwrite option should be shown (if a saved dataset is loaded)
  output$showOverwriteOption <- reactive(isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName))
  outputOptions(output, "showOverwriteOption", suspendWhenHidden = FALSE)

  # Expose whether a file has been selected or data is loaded (for showing column selection UI)
  output$hasDataOrFile <- reactive({
    # First check if data is validated - this is the most reliable
    hasValidData <- tryCatch({
      isTRUE(data_api$signalValid())
    }, error = function(e) FALSE)

    if (hasValidData) return(TRUE)

    # Check if raw data exists (even if not yet validated)
    hasRawData <- tryCatch({
      rawData <- data_api$rawdata()
      !is.null(rawData) && (is.data.frame(rawData) || is.matrix(rawData)) &&
      ((is.data.frame(rawData) && nrow(rawData) > 0) || (is.matrix(rawData) && nrow(rawData) > 0))
    }, error = function(e) FALSE)

    if (hasRawData) return(TRUE)

    # Check if example dataset is selected
    hasExample <- !is.null(input$dataSource) &&
                  (input$dataSource == "example-signal-1.csv" ||
                   input$dataSource == "00-ohio-3-wells.csv")
    if (hasExample) return(TRUE)

    # Check if a file has been selected (fileInput returns a list with name, size, type, datapath)
    # Only return TRUE if the file actually has a name (was selected)
    hasFile <- tryCatch({
      !is.null(input$dataFile) &&
      is.list(input$dataFile) &&
      !is.null(input$dataFile$name) &&
      nchar(trimws(input$dataFile$name)) > 0
    }, error = function(e) FALSE)

    hasFile
  })
  outputOptions(output, "hasDataOrFile", suspendWhenHidden = FALSE)

  # LAS mode: show "Add more LAS files" when LAS data is loaded (1 or more wells)
  output$showAddLasFiles <- reactive({
    !is.null(r$lasFolderPath) && !is.null(r$lasFileNames) && length(r$lasFileNames) >= 1L
  })
  outputOptions(output, "showAddLasFiles", suspendWhenHidden = FALSE)

  output$lasWellCount_ui <- renderUI({
    if (is.null(r$lasFileNames)) return(NULL)
    n <- length(r$lasFileNames)
    msg <- if (n < 2L) {
      "1 well loaded. Add more LAS files to proceed (at least 2 wells required)."
    } else {
      paste0(n, " wells loaded.")
    }
    tags$p(style = "margin: 0 0 6px 0; font-size: 0.9em;", msg)
  })

  # Add more LAS files: merge new files with existing and re-read
  observeEvent(input$addLasFiles, {
    addFiles <- input$addLasFiles
    if (is.null(addFiles) || !is.data.frame(addFiles) || nrow(addFiles) == 0) return()
    if (is.null(r$lasFolderPath) || is.null(r$lasFileNames)) {
      showNotification("Load a LAS file first, then add more.", type = "warning")
      return()
    }
    newNames <- addFiles$name
    newPaths <- addFiles$datapath
    if (!all(tolower(tools::file_ext(newNames)) == "las")) {
      showNotification("All added files must be .las format.", type = "error")
      return()
    }
    for (i in seq_along(newPaths)) {
      file.copy(newPaths[i], file.path(r$lasFolderPath, newNames[i]), overwrite = TRUE)
    }
    oldNames <- r$lasFileNames
    allNames <- c(oldNames, newNames)
    r$dataset <- tryCatch(
      .ReadLasAsDataset(folder = r$lasFolderPath, fileNames = allNames),
      error = function(e) {
        showNotification(paste("Failed to read LAS files:", e$message), type = "error")
        r$lasFileNames <- oldNames
        return(NULL)
      }
    )
    if (is.null(r$dataset)) return()
    r$lasFileNames <- allNames

    # Re-apply any prior merge operations so they survive re-reading the LAS
    # folder. Each entry records the original well names + the merged name;
    # if at least one of the wells still exists in the new dataset, we re-run
    # .MergeWellsDataset to collapse them again.
    mergesReapplied <- 0L
    if (length(r$mergeHistory) > 0L) {
      sc <- r$persistedColumnSelections$siteColumn
      zc <- r$persistedColumnSelections$zColumn
      if (!is.null(sc) && !is.null(zc) && nzchar(sc) && nzchar(zc) &&
          sc %in% colnames(r$dataset) && zc %in% colnames(r$dataset)) {
        kept_history <- list()
        for (m in r$mergeHistory) {
          present_wells <- intersect(m$wells,
                                     unique(trimws(as.character(r$dataset[[sc]]))))
          if (length(present_wells) >= 1L) {
            # Include any wells that are already "the merged name" from a prior
            # re-application, plus the originals still present.
            wells_now <- unique(c(present_wells,
                                  if (m$merged_name %in%
                                      unique(trimws(as.character(r$dataset[[sc]]))))
                                    m$merged_name else character(0)))
            if (length(wells_now) >= 2L ||
                (length(wells_now) == 1L && wells_now != m$merged_name)) {
              r$dataset <- tryCatch(
                .MergeWellsDataset(
                  dataset        = r$dataset,
                  site_col       = sc,
                  depth_col      = zc,
                  wells_to_merge = wells_now,
                  merged_name    = m$merged_name
                ),
                error = function(e) {
                  showNotification(paste("Could not re-apply merge '",
                                         m$merged_name, "':", conditionMessage(e)),
                                   type = "warning")
                  r$dataset
                }
              )
              mergesReapplied <- mergesReapplied + 1L
            }
          }
          kept_history[[length(kept_history) + 1L]] <- m
        }
        r$mergeHistory <- kept_history
      }
    }

    # Clear partition state when wells change (new data structure)
    r$partitionData <- NULL
    r$parts_df_basic <- NULL
    r$parts_df_added <- NULL
    r$loadedSavedDataset <- FALSE
    r$currentLoadedDatasetName <- NULL

    # Make sure newly added (or merge-produced) wells get auto-selected in the
    # "Wells to include" list. Keep previously selected wells that still exist,
    # add anything that's new, drop anything that no longer exists.
    sc <- r$persistedColumnSelections$siteColumn
    if (!is.null(sc) && nzchar(sc) && sc %in% colnames(r$dataset)) {
      new_sites <- unique(trimws(as.character(r$dataset[[sc]])))
      prev_sel <- r$persistedSiteSelections
      if (is.null(prev_sel)) {
        updated_sel <- new_sites
      } else {
        kept <- intersect(prev_sel, new_sites)
        fresh <- setdiff(new_sites, prev_sel)
        updated_sel <- c(kept, fresh)
      }
      r$persistedSiteSelections <- updated_sel
      updateCheckboxGroupInput(
        session, "loadSiteSelect",
        choices  = new_sites,
        selected = updated_sel
      )
    }

    data_api$updateDataPreview()
    data_api$datasetId(data_api$datasetId() + 1L)
    data_api$uiTrigger(data_api$uiTrigger() + 1L)
    msg <- paste("Added", length(newNames), "LAS file(s). Total:", length(allNames), "wells.")
    if (mergesReapplied > 0L) {
      msg <- paste0(msg, " Re-applied ", mergesReapplied, " prior merge(s).")
    }
    showNotification(msg, type = "message", duration = 3)
  })

  # Handle show save data button click - just show the inline field
  observeEvent(input$showSaveData, {
    if (!data_api$signalValid()) {
      showNotification("Please provide a valid data set before saving", type = "error")
      return()
    }

    # Show the inline save field
    r$showSaveDataField <- TRUE

    # Pre-fill with suggested name
    suggestedName <- paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
    updateTextInput(session, "saveDataNameInput", value = suggestedName)
  })

  # Handle cancel save data
  observeEvent(input$cancelSaveData, {
    r$showSaveDataField <- FALSE
    updateTextInput(session, "saveDataNameInput", value = "")
  })

  # Handle confirm save data (inline, no modal)
  observeEvent(input$confirmSaveData, {
    if (!data_api$signalValid()) {
      showNotification("Please provide a valid data set before saving", type = "error")
      return()
    }

    # Collect current data state
    dataState <- list(
      dataset = data_api$rawdata(),
      siteColumn = data_api$siteColumn(),
      zColumn = data_api$zColumn(),
      signalColumns = data_api$signalCols(),
      siteSelections = input$loadSiteSelect,
      dataSource = input$dataSource,
      dataScale = input$dataScale,
      partitionSource = input$partitionSource,
      partitionData = r$partitionData,
      parts_df_added = r$parts_df_added,  # Save user-added partitions separately
      parts_df_basic = r$parts_df_basic,  # Save basic partitions (Top_ partitions)
      referenceSite = r$persistedReferenceSite  # Save reference site selection
    )

    # Get save name
    saveName <- if (!is.null(input$saveDataNameInput) && nzchar(input$saveDataNameInput)) {
      input$saveDataNameInput
    } else {
      paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
    }

    r$savedDatasets[[saveName]] <- dataState
    showNotification(paste("Data saved as:", saveName), type = "message")

    # After saving, mark that we're now working with a saved dataset
    r$loadedSavedDataset <- TRUE
    r$currentLoadedDatasetName <- saveName  # Track which saved dataset is current

    # Update hash to prevent auto-save of same data
    r$lastSavedDataHash <- digest::digest(dataState)

    # CRITICAL: Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state and prevents issues with partition source
    shinyjs::delay(200, {
      # Restore all settings from the saved dataset
      if (!is.null(dataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- dataState$siteColumn
      }
      if (!is.null(dataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- dataState$zColumn
      }
      if (!is.null(dataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- dataState$signalColumns
      }
      if (!is.null(dataState$dataset)) {
        r$dataset <- dataState$dataset
        r$persistedDataset <- dataState$dataset
      }
      if (!is.null(dataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
        r$persistedDataScale <- dataState$dataScale
      }
      if (!is.null(dataState$partitionSource) && dataState$partitionSource %in% c("none", "auto", "interactive")) {
        updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
        r$persistedPartitionSource <- dataState$partitionSource
      }
      if (!is.null(dataState$partitionData)) {
        r$partitionData <- dataState$partitionData
      }
      if (!is.null(dataState$parts_df_added)) {
        r$parts_df_added <- dataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }
      # Restore parts_df_basic from saved data, or recalculate if not saved
      if (!is.null(dataState$parts_df_basic)) {
        r$parts_df_basic <- dataState$parts_df_basic
      } else {
        # Recalculate basic partitions from current data
        if (!is.null(dataState$dataset) && !is.null(dataState$siteColumn) && !is.null(dataState$zColumn)) {
          # Need to access createBasicPartitions function - it's in data-module scope
          # For now, just set to NULL and let the observer recalculate it
          r$parts_df_basic <- NULL
        }
      }
          # Restore parts_df_basic from saved data, or recalculate if not saved
          if (!is.null(dataState$parts_df_basic)) {
            r$parts_df_basic <- dataState$parts_df_basic
          } else {
            # Recalculate basic partitions from current data
            if (!is.null(dataState$dataset) && !is.null(dataState$siteColumn) && !is.null(dataState$zColumn)) {
              # Need to access createBasicPartitions function - it's in data-module scope
              # For now, just set to NULL and let the observer recalculate it
              r$parts_df_basic <- NULL
            }
          }
          # Restore reference site if saved
          if (!is.null(dataState$referenceSite)) {
            r$persistedReferenceSite <- dataState$referenceSite
          }
          if (!is.null(dataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
        r$persistedSiteSelections <- dataState$siteSelections
      }
    })

    # Hide the save field
    r$showSaveDataField <- FALSE
    updateTextInput(session, "saveDataNameInput", value = "")
  })

  # Handle load new signal source button (clean slate: no partitions stick to next file)
  observeEvent(input$loadNewSignalSource, {
    r$loadedSavedDataset <- FALSE
    r$currentLoadedDatasetName <- NULL
    r$partitionData <- NULL
    r$parts_df_added <- NULL
    r$parts_df_basic <- NULL
    # Clear persisted dataset to force fresh load
    r$persistedDataset <- NULL
    # Reset partition source
    updateSelectInput(session, "partitionSource", selected = "none")
    # Clear hash to allow new saves
    r$lastSavedDataHash <- NULL
    # Clear persisted column selections
    r$persistedColumnSelections$siteColumn <- NULL
    r$persistedColumnSelections$zColumn <- NULL
    r$persistedColumnSelections$signalColumns <- NULL
    # Clear alignment/results from previous run
    r$alignment <- NULL
  })

  # Handle loading saved data
  observeEvent(input$loadDataset, {
    if (!is.null(input$loadDatasetSelect) && input$loadDatasetSelect != "") {
      if (input$loadDatasetSelect %in% names(r$savedDatasets)) {
        dataState <- r$savedDatasets[[input$loadDatasetSelect]]

        # Mark that we're loading a saved dataset
        r$loadedSavedDataset <- TRUE
        r$currentLoadedDatasetName <- input$loadDatasetSelect  # Track which saved dataset is loaded

        # Restore column selections FIRST so UI can use them when it renders
        if (!is.null(dataState$siteColumn)) {
          r$persistedColumnSelections$siteColumn <- dataState$siteColumn
        }
        if (!is.null(dataState$zColumn)) {
          r$persistedColumnSelections$zColumn <- dataState$zColumn
        }
        if (!is.null(dataState$signalColumns)) {
          r$persistedColumnSelections$signalColumns <- dataState$signalColumns
        }

        # Restore dataset (this will trigger UI updates)
        if (!is.null(dataState$dataset)) {
          r$dataset <- dataState$dataset
          r$persistedDataset <- dataState$dataset
        }

        # Restore partition state immediately so stratData/getPartitionData see correct data on first run
        if (!is.null(dataState$partitionSource) && dataState$partitionSource %in% c("none", "auto", "interactive")) {
          updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
          r$persistedPartitionSource <- dataState$partitionSource
        }
        if (!is.null(dataState$partitionData)) {
          r$partitionData <- dataState$partitionData
          if (nrow(r$partitionData) > 0 && (is.null(dataState$partitionSource) || dataState$partitionSource == "none")) {
            updateSelectInput(session, "partitionSource", selected = "interactive")
            r$persistedPartitionSource <- "interactive"
          }
        }
        if (!is.null(dataState$parts_df_added)) {
          r$parts_df_added <- dataState$parts_df_added
        } else {
          r$parts_df_added <- NULL
        }
        if (!is.null(dataState$parts_df_basic)) {
          r$parts_df_basic <- dataState$parts_df_basic
        } else {
          r$parts_df_basic <- NULL
        }

        # Set dataSource to trigger UpdateData() which will ensure everything is synchronized
        savedDataSource <- if (!is.null(dataState$dataSource)) dataState$dataSource else "file"
        r$persistedDataSource <- savedDataSource
        updateSelectInput(session, "dataSource", selected = savedDataSource)

        # Restore remaining UI state after a short delay so inputs exist
        shinyjs::delay(300, {
          if (!is.null(dataState$dataScale)) {
            updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
            r$persistedDataScale <- dataState$dataScale
          }
          if (!is.null(dataState$referenceSite)) {
            r$persistedReferenceSite <- dataState$referenceSite
          }
          if (!is.null(dataState$siteSelections)) {
            updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
            r$persistedSiteSelections <- dataState$siteSelections
          }
          # Sync column select inputs to persisted values
          all_inputs <- names(session$input)
          if (!is.null(dataState$siteColumn)) {
            site_col_inputs <- all_inputs[grepl("^siteColumn_", all_inputs)]
            if (length(site_col_inputs) > 0) {
              updateSelectInput(session, site_col_inputs[1], selected = dataState$siteColumn)
            }
          }
          if (!is.null(dataState$zColumn)) {
            z_col_inputs <- all_inputs[grepl("^zColumn_", all_inputs)]
            if (length(z_col_inputs) > 0) {
              updateSelectInput(session, z_col_inputs[1], selected = dataState$zColumn)
            }
          }
          if (!is.null(dataState$signalColumns)) {
            sig_col_inputs <- all_inputs[grepl("^signalColumns_", all_inputs)]
            if (length(sig_col_inputs) > 0) {
              updateCheckboxGroupInput(session, sig_col_inputs[1], selected = dataState$signalColumns)
            }
          }
        })

        # Update hash to track this as the last saved state
        r$lastSavedDataHash <- digest::digest(dataState)
        r$currentLoadedDatasetName <- input$loadDatasetSelect  # Track which saved dataset is loaded

        showNotification(paste("Loaded dataset:", input$loadDatasetSelect), type = "message")
      } else {
        showNotification("Failed to load dataset", type = "error")
      }
    }
  })

  # Handle loading data from saved result
  observeEvent(input$loadDataFromResult, {
    if (!is.null(input$loadDataFromResultSelect) && input$loadDataFromResultSelect != "") {
      if (input$loadDataFromResultSelect %in% names(r$savedResults)) {
        result <- r$savedResults[[input$loadDataFromResultSelect]]

        # Check if result has data
        if (is.null(result$data)) {
          showNotification("Selected result does not contain data.", type = "error")
          return()
        }

        # Extract StratData object
        stratData <- result$data

        # Convert StratData to raw data frame
        tryCatch({
          if (inherits(stratData, "StratData")) {
            # Get the raw signal data from StratData
            # StratData contains signal data - extract it
            rawData <- tryCatch({
              # Extract signal data from StratData
              as.data.frame(stratData$signal)
            }, error = function(e) {
              NULL
            })

            if (is.null(rawData)) {
              showNotification("Could not extract data from StratPosterior object. The data structure may not be compatible.", type = "error")
              return()
            }

            # Set the dataset
            r$dataset <- rawData
            r$persistedDataset <- rawData

            # Extract partitions from StratData if available
            if (!is.null(stratData$parts) && nrow(stratData$parts) > 0) {
              # Convert parts to data frame and store
              parts_df <- as.data.frame(stratData$parts)
              r$partitionData <- parts_df
              # Set partition source to interactive so partitions are used
              updateSelectInput(session, "partitionSource", selected = "interactive")
              r$persistedPartitionSource <- "interactive"
              showNotification(paste("Loaded data and", nrow(parts_df), "partitions from result:", input$loadDataFromResultSelect), type = "message", duration = 5)
            } else {
              showNotification(paste("Loaded data from result:", input$loadDataFromResultSelect), type = "message", duration = 5)
            }

            # Mark as loaded from result
            r$loadedSavedDataset <- TRUE
            r$currentLoadedResultName <- paste0("from-result-", input$loadDataFromResultSelect)
          } else {
            showNotification("Result data is not a StratData object.", type = "error")
          }
        }, error = function(e) {
          showNotification(paste("Error loading data from result:", e$message), type = "error")
        })
      } else {
        showNotification("Selected result not found.", type = "error")
      }
    }
  })

  # Handle loading model from saved result
  observeEvent(input$loadModelFromResult, {
    if (!is.null(input$loadModelFromResultSelect) && input$loadModelFromResultSelect != "") {
      if (input$loadModelFromResultSelect %in% names(r$savedResults)) {
        result <- r$savedResults[[input$loadModelFromResultSelect]]

        # Check if result has model
        if (is.null(result$model)) {
          showNotification("Selected result does not contain model settings.", type = "error")
          return()
        }

        # Extract StratModel object
        stratModel <- result$model

        # Extract model settings from StratModel
        tryCatch({
          if (inherits(stratModel, "StratModel")) {
            # Extract model parameters from StratModel
            # Try to extract alignment scale
            if (!is.null(stratModel$alignmentScale)) {
              updateSelectInput(session, "alignmentScale", selected = stratModel$alignmentScale)
            }

            # Try to extract sedModel
            if (!is.null(stratModel$sedModel)) {
              updateSelectInput(session, "sedModel", selected = stratModel$sedModel)
            }

            # Try to extract alphaPosition
            if (!is.null(stratModel$alphaPosition)) {
              updateSelectInput(session, "alphaPosition", selected = stratModel$alphaPosition)
            }

            # Try to extract nKnots
            if (!is.null(stratModel$nKnots)) {
              updateNumericInput(session, "nKnots", value = stratModel$nKnots)
            }

            # Extract priors if available
            if (!is.null(stratModel$priors)) {
              # Load priors into priorSettings
              for (nm in names(stratModel$priors)) {
                priorSettings[[nm]] <- stratModel$priors[[nm]]
              }
            }

            showNotification(paste("Loaded model settings from result:", input$loadModelFromResultSelect), type = "message", duration = 5)
          } else {
            showNotification("Result model is not a StratModel object.", type = "error")
          }
        }, error = function(e) {
          showNotification(paste("Error loading model from result:", e$message), type = "error")
        })
      } else {
        showNotification("Selected result not found.", type = "error")
      }
    }
  })

  # Helper function to check if data or model settings have changed since last save
  hasUnsavedChanges <- function() {
    # Check data changes
    # Wrap in tryCatch to handle cases where data_api might not be ready
    tryCatch({
      if (isTRUE(data_api$signalValid())) {
        currentDataState <- list(
          dataset = data_api$rawdata(),
          siteColumn = data_api$siteColumn(),
          zColumn = data_api$zColumn(),
          signalColumns = data_api$signalCols(),
          siteSelections = input$loadSiteSelect,
          dataSource = input$dataSource,
          dataScale = input$dataScale,
          partitionSource = input$partitionSource,
          partitionData = r$partitionData
        )
        currentDataHash <- digest::digest(currentDataState)

        # If data is from a saved dataset, compare with that saved dataset
        if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
          if (r$currentLoadedDatasetName %in% names(r$savedDatasets)) {
            loadedHash <- digest::digest(r$savedDatasets[[r$currentLoadedDatasetName]])
            if (currentDataHash != loadedHash) {
              return(TRUE)  # Data has changed
            }
          }
        } else if (!is.null(r$lastSavedDataHash) && currentDataHash != r$lastSavedDataHash) {
          return(TRUE)  # Data has changed since last save
        } else if (is.null(r$lastSavedDataHash) && !is.null(data_api$rawdata())) {
          return(TRUE)  # Data exists but never saved
        }
      }
    }, error = function(e) {
      # If data_api is not ready or there's an error, assume no unsaved changes
      # This allows the modal to close when no data is loaded
      return(FALSE)
    })

    # Check model settings changes (if we're in customRun view)
    if (r$modalView == "customRun") {
      # Compare current settings with last saved settings
      currentSettings <- list(
        alignmentScale = input$alignmentScale,
        sedModel = input$sedModel,
        alphaPosition = input$alphaPosition,
        nKnots = input$nKnots,
        nRun = input$nRun,
        nIter = input$nIter,
        nThin = input$nThin,
        nChains = input$nChains,
        priors = reactiveValuesToList(priorSettings)
      )
      currentSettingsHash <- digest::digest(currentSettings)

      # Check against last saved session settings
      if ("_last_session" %in% names(r$savedModelSettings)) {
        savedSettingsHash <- digest::digest(r$savedModelSettings[["_last_session"]])
        if (currentSettingsHash != savedSettingsHash) {
          return(TRUE)  # Model settings have changed
        }
      } else {
        # Settings exist but never saved
        if (!is.null(input$alignmentScale) || !is.null(input$sedModel)) {
          return(TRUE)
        }
      }
    }

    return(FALSE)  # No unsaved changes
  }

  # Helper function to check if data has changed and auto-save if needed
  autoSaveIfChanged <- function() {
    if (!data_api$signalValid()) return()

    # Collect current data state (include parts_df_added for accurate comparison)
    currentDataState <- list(
      dataset = data_api$rawdata(),
      siteColumn = data_api$siteColumn(),
      zColumn = data_api$zColumn(),
      signalColumns = data_api$signalCols(),
      siteSelections = input$loadSiteSelect,
      dataSource = input$dataSource,
      dataScale = input$dataScale,
      partitionSource = input$partitionSource,
      partitionData = r$partitionData,
      parts_df_added = r$parts_df_added  # Include parts_df_added in comparison
    )
    currentHash <- digest::digest(currentDataState)

    # If data is from a saved dataset, compare with that saved dataset
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
      # Check if this is the same saved dataset that's currently loaded
      if (r$currentLoadedDatasetName %in% names(r$savedDatasets)) {
        # Create hash of saved dataset for comparison (include parts_df_added if missing)
        savedState <- r$savedDatasets[[r$currentLoadedDatasetName]]
        if (!"parts_df_added" %in% names(savedState)) {
          savedState$parts_df_added <- NULL
        }
        loadedHash <- digest::digest(savedState)

        # If hashes match, data hasn't changed - don't auto-save
        if (currentHash == loadedHash) {
          # Update lastSavedDataHash to prevent future unnecessary saves
          r$lastSavedDataHash <- currentHash
          return()  # No changes, don't save
        }
      }
    }

    # If we have a lastSavedDataHash, compare with that
    if (!is.null(r$lastSavedDataHash) && currentHash == r$lastSavedDataHash) {
      return()  # No changes since last save, don't save again
    }

    # Data has changed, auto-save
    suggestedName <- paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
    r$savedDatasets[[suggestedName]] <- currentDataState
    r$lastSavedDataHash <- currentHash
    r$currentLoadedDatasetName <- suggestedName  # Track this as the current loaded dataset
    r$loadedSavedDataset <- TRUE
    showNotification(paste("Data auto-saved as:", suggestedName), type = "message", duration = 3)

    # CRITICAL: Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state
    shinyjs::delay(200, {
      if (!is.null(currentDataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- currentDataState$siteColumn
      }
      if (!is.null(currentDataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- currentDataState$zColumn
      }
      if (!is.null(currentDataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- currentDataState$signalColumns
      }
      if (!is.null(currentDataState$dataset)) {
        r$dataset <- currentDataState$dataset
        r$persistedDataset <- currentDataState$dataset
      }
      if (!is.null(currentDataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = currentDataState$dataScale)
        r$persistedDataScale <- currentDataState$dataScale
      }
      if (!is.null(currentDataState$partitionSource)) {
        updateSelectInput(session, "partitionSource", selected = currentDataState$partitionSource)
        r$persistedPartitionSource <- currentDataState$partitionSource
      }
      if (!is.null(currentDataState$partitionData)) {
        r$partitionData <- currentDataState$partitionData
      }
      if (!is.null(currentDataState$parts_df_added)) {
        r$parts_df_added <- currentDataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }
      if (!is.null(currentDataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = currentDataState$siteSelections)
        r$persistedSiteSelections <- currentDataState$siteSelections
      }
    })
  }

  # Handle new action buttons
  observeEvent(input$lookAtData, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    # Save current state before navigating
    if (!is.null(data_api$rawdata())) {
      r$persistedDataset <- data_api$rawdata()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    }
    # Partitions are already in r$partitionData

    if (data_api$signalValid()) {
      # Don't override partition source - use the persisted one
      # Only set it if it's truly missing (none) and we have partition data
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        # Only set partition source if it's "none" - otherwise respect the current/persisted value
        if (is.null(input$partitionSource) || input$partitionSource == "none") {
          # Use persisted partition source if available, otherwise default to "interactive"
          if (!is.null(r$persistedPartitionSource) && r$persistedPartitionSource != "none") {
            updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
          } else {
            updateSelectInput(session, "partitionSource", selected = "interactive")
            r$persistedPartitionSource <- "interactive"
          }
        }
      }

      r$modalView <- "view"
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  # Handle lookAtDataFromModal button (from customRun view)
  observeEvent(input$lookAtDataFromModal, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    # Save current state before navigating
    if (!is.null(data_api$rawdata())) {
      r$persistedDataset <- data_api$rawdata()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    }

    if (data_api$signalValid()) {
      # Don't override partition source - use the persisted one
      # Only set it if it's truly missing (none) and we have partition data
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        # Only set partition source if it's "none" - otherwise respect the current/persisted value
        if (is.null(input$partitionSource) || input$partitionSource == "none") {
          # Use persisted partition source if available, otherwise default to "interactive"
          if (!is.null(r$persistedPartitionSource) && r$persistedPartitionSource != "none") {
            updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
          } else {
            updateSelectInput(session, "partitionSource", selected = "interactive")
            r$persistedPartitionSource <- "interactive"
          }
        }
      }
      # Ensure partition source is set correctly before showing view
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        if (is.null(input$partitionSource) || input$partitionSource != "interactive") {
          updateSelectInput(session, "partitionSource", selected = "interactive")
          r$persistedPartitionSource <- "interactive"
        }
      }

      r$modalView <- "view"
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  observeEvent(input$quickRun, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    if (data_api$signalValid()) {
      # Close the main modal and open progress modal
      removeModal()

      # Show progress modal
      showModal(modelProgressModal())

      # Trigger the quick run functionality (this should be async)
      tryCatch({
        model_api$QuickRun()
        showNotification("Quick run started with default settings.", type = "message", duration = 3)
      }, error = function(e) {
        removeModal()
        showNotification(paste("Error starting quick run:", e$message), type = "error")
      })
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  observeEvent(input$customRun, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    if (data_api$signalValid()) {
      r$modalView <- "customRun"
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  # Observers for view panel buttons (same functionality as load panel buttons)
  observeEvent(input$quickRun_view, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    if (data_api$signalValid()) {
      # Close the main modal and open progress modal
      removeModal()

      # Show progress modal
      showModal(modelProgressModal())

      # Trigger the quick run functionality (this should be async)
      tryCatch({
        model_api$QuickRun()
        showNotification("Quick run started with default settings.", type = "message", duration = 3)
      }, error = function(e) {
        removeModal()
        showNotification(paste("Error starting quick run:", e$message), type = "error")
      })
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  observeEvent(input$customRun_view, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    if (data_api$signalValid()) {
      r$modalView <- "customRun"
    } else {
      showNotification("Please provide a valid data set", type = "error")
    }
  })

  # Handle navigation buttons
  observeEvent(input$previousStep, {
    # Save current state before navigating - this ensures partitions persist
    if (!is.null(data_api$rawdata())) {
      r$persistedDataset <- data_api$rawdata()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    }
    # IMPORTANT: Save dataScale to persist depth/height selection
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }
    # Partitions are already in r$partitionData and will persist

    # Check which view/tab we're currently on
    currentTab <- input$modelTabs

    if (r$modalView == "view") {
      # From view, go back to load
      r$modalView <- "load"
      if (!is.null(r$persistedDataset)) {
        r$dataset <- r$persistedDataset
      }
    } else if (r$modalView == "customRun") {
      # We're in model setup tabs - navigate backwards
      if (is.null(currentTab)) {
        # No tab selected yet - go to load view
      r$modalView <- "load"
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }
      } else if (currentTab == "run") {
        # From run, go to priors
        updateTabsetPanel(session, "modelTabs", selected = "prior")
      } else if (currentTab == "prior") {
        # From priors, go to structure
        updateTabsetPanel(session, "modelTabs", selected = "structure")
      } else if (currentTab == "structure") {
        # From structure, go back to load view
        r$modalView <- "load"
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }
      }
    } else if (r$modalView == "load") {
      # Already in load view - do nothing (button shouldn't be visible anyway)
    }

    # Restore settings after view change
    shinyjs::delay(100, {
      if (!is.null(r$persistedPartitionSource)) {
        updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
      }
      if (!is.null(r$persistedSiteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
      }
      # IMPORTANT: Restore dataScale to persist depth/height selection
      if (!is.null(r$persistedDataScale)) {
        updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
      }
    })
  })

  # Handle nextStepFromView button - navigate from view to customRun
  observeEvent(input$nextStepFromView, {
    # Auto-save if data has changed
    autoSaveIfChanged()

    # Save current state before navigating
    if (!is.null(data_api$rawdata())) {
      r$persistedDataset <- data_api$rawdata()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    }

    if (data_api$signalValid()) {
      r$modalView <- "customRun"
      # Wait a moment for the modal to update, then select structure tab
      shinyjs::delay(200, {
        updateTabsetPanel(session, "modelTabs", selected = "structure")
      })
    } else {
      showNotification("Please provide a valid data set first", type = "error")
    }
  })

  # Handle nextStep button - navigate to next tab in model setup
  observeEvent(input$nextStep, {
    # Check which view/tab we're currently on
    if (r$modalView == "load") {
      # If we're in load view, go to customRun (structure tab)
      if (data_api$signalValid()) {
        r$modalView <- "customRun"
        # Wait a moment for the modal to update, then select structure tab
        shinyjs::delay(200, {
          updateTabsetPanel(session, "modelTabs", selected = "structure")
        })
      } else {
        showNotification("Please provide a valid data set first", type = "error")
      }
    } else if (r$modalView == "customRun") {
      # Navigate to next tab within model setup
      currentTab <- input$modelTabs

      # Force the tab change immediately
      if (is.null(currentTab) || currentTab == "structure") {
        # From structure (or no tab), go to priors
        updateTabsetPanel(session, "modelTabs", selected = "prior")
      } else if (currentTab == "prior") {
        # From priors, go to run
        updateTabsetPanel(session, "modelTabs", selected = "run")
      } else if (currentTab == "run") {
        # From run, stay on run (user can run model from here)
        # Do nothing - button shouldn't be visible anyway
      }
    }
  })

  observeEvent(input$closeModal, {
    # Check if there are unsaved changes
    # Wrap in tryCatch to handle cases where data_api might not be ready
    tryCatch({
      if (hasUnsavedChanges()) {
        # Show confirmation modal
        showModal(closeConfirmationModal())
      } else {
        # No unsaved changes - close directly
        doCloseModal()
      }
    }, error = function(e) {
      # If there's an error checking for unsaved changes (e.g., no data loaded yet),
      # just close the modal directly
      doCloseModal()
    })
  })

  # Handle "Continue Setup" button in confirmation modal
  # Model after auto-partitions save behavior - close confirmation modal, ensure main modal stays open
  observeEvent(input$continueSetup, {
    # Save current state before closing confirmation modal (same as doCloseModal)
    # Save data if available
    tryCatch({
      if (!is.null(data_api$rawdata())) {
        r$persistedDataset <- data_api$rawdata()
      }
    }, error = function(e) {
      # Data not available yet - that's okay
    })

    # Save partition data (this is critical - partitions must persist!)
    if (!is.null(r$partitionData)) {
      # Already saved, but ensure it's persisted
    }

    # Save site selections
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }

    # Save column selections using the siteColumn, zColumn, signalColumns reactives
    tryCatch({
      if (!is.null(data_api$siteColumn())) {
        r$persistedColumnSelections$siteColumn <- data_api$siteColumn()
      }
      if (!is.null(data_api$zColumn())) {
        r$persistedColumnSelections$zColumn <- data_api$zColumn()
      }
      if (!is.null(data_api$signalCols())) {
        r$persistedColumnSelections$signalColumns <- data_api$signalCols()
      }
    }, error = function(e) {
      # Column selections not available yet - that's okay
    })

    # Save data source (if available)
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }

    # Save partition source (ensure it's saved even if partitions exist)
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    } else if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # If we have partition data but no source set, set it to interactive
      r$persistedPartitionSource <- "interactive"
    }

    # Save data scale (critical for preventing prior glitches)
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Close the confirmation modal (topmost modal)
    removeModal()
    # Explicitly ensure main modal is visible (like auto-partitions does)
    # Restore settings after modal is shown
    shinyjs::delay(100, {
      showModal(modelSelectionModal())

      # Restore settings after modal is shown
      shinyjs::delay(200, {
        # Restore dataset
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }

        # Restore partition source
        if (!is.null(r$persistedPartitionSource)) {
          updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
        }

        # Restore column selections - CRITICAL for non-standard column names
        # Use a longer delay to ensure UI is ready, and try to find the input IDs
        shinyjs::delay(300, {
          # Try to find the current datasetId by checking input names
          # The column inputs follow the pattern "siteColumn_N", "zColumn_N", "signalColumns_N"
          allInputs <- reactiveValuesToList(input)
          inputNames <- names(allInputs)

          siteColPattern <- grep("^siteColumn_\\d+$", inputNames, value = TRUE)
          if (length(siteColPattern) > 0 && !is.null(r$persistedColumnSelections$siteColumn)) {
            tryCatch({
              updateSelectInput(session, siteColPattern[1], selected = r$persistedColumnSelections$siteColumn)
            }, error = function(e) {
              # Input might not be ready yet, that's okay
            })
          }

          zColPattern <- grep("^zColumn_\\d+$", inputNames, value = TRUE)
          if (length(zColPattern) > 0 && !is.null(r$persistedColumnSelections$zColumn)) {
            tryCatch({
              updateSelectInput(session, zColPattern[1], selected = r$persistedColumnSelections$zColumn)
            }, error = function(e) {
              # Input might not be ready yet, that's okay
            })
          }

          sigColPattern <- grep("^signalColumns_\\d+$", inputNames, value = TRUE)
          if (length(sigColPattern) > 0 && !is.null(r$persistedColumnSelections$signalColumns)) {
            tryCatch({
              updateSelectInput(session, sigColPattern[1], selected = r$persistedColumnSelections$signalColumns)
            }, error = function(e) {
              # Input might not be ready yet, that's okay
            })
          }
        })

        # Restore site selections
        if (!is.null(r$persistedSiteSelections)) {
          updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
        }

        # Restore data source if available
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        }

        # Restore data scale if available
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
      })
    })
  }, ignoreNULL = TRUE)

  # Handle "Close" button in confirmation modal
  observeEvent(input$confirmCloseModal, {
    removeModal()  # Close the confirmation modal
    doCloseModal()  # Actually close the main modal
  })

  # Function to actually close the modal and save state
  doCloseModal <- function() {
    # Save all current data and settings before closing (if available)
    # Don't require data to exist - just save what's available

    # Save data if available
    tryCatch({
      if (!is.null(data_api$rawdata())) {
        r$persistedDataset <- data_api$rawdata()
      }
    }, error = function(e) {
      # Data not available yet - that's okay
    })

    # Save partition data (this is critical - partitions must persist!)
    if (!is.null(r$partitionData)) {
      # Already saved, but ensure it's persisted
    }

    # Save site selections
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }

    # Save column selections using the siteColumn, zColumn, signalColumns reactives
    tryCatch({
      if (!is.null(data_api$siteColumn())) {
        r$persistedColumnSelections$siteColumn <- data_api$siteColumn()
      }
      if (!is.null(data_api$zColumn())) {
        r$persistedColumnSelections$zColumn <- data_api$zColumn()
      }
      if (!is.null(data_api$signalCols())) {
        r$persistedColumnSelections$signalColumns <- data_api$signalCols()
      }
    }, error = function(e) {
      # Column selections not available yet - that's okay
    })

    # Save data source (if available)
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }

    # Save partition source (ensure it's saved even if partitions exist)
    if (!is.null(input$partitionSource)) {
      r$persistedPartitionSource <- input$partitionSource
    } else if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # If we have partition data but no source set, set it to interactive
      r$persistedPartitionSource <- "interactive"
    }

    # Save data scale (critical for preventing prior glitches)
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Save model settings (if available)
    tryCatch({
      if (data_api$signalValid()) {
        # Get custom alpha values if custom is selected
        # If custom is selected, prefer stored values (from Update button), but if empty, read from inputs
        customAlphaValues <- if (!is.null(input$alphaPosition) && input$alphaPosition == "custom") {
          stored <- tryCatch({
            model_api$storedCustomAlphaValues()
          }, error = function(e) {
            NULL
          })
          # Check if stored values exist and are non-empty
          if (!is.null(stored) && is.list(stored) && length(stored) > 0 && any(!sapply(stored, is.null))) {
            stored
          } else {
            # Read directly from numeric inputs (even if not validated via Update button)
            if (data_api$signalValid()) {
              sd <- data_api$stratData()
              sites <- sd$sites
              alignmentScale <- input$alignmentScale %||% "height"

              if (alignmentScale == "height") {
                inputSites <- sites[-1]
              } else {
                inputSites <- sites
              }

              inputValues <- list()
              for (site in inputSites) {
                inputId <- paste0("customAlpha_", site)
                val <- input[[inputId]]
                if (!is.null(val) && !is.na(val) && is.numeric(val) && is.finite(val)) {
                  inputValues[[site]] <- val
                }
              }

              if (length(inputValues) > 0) {
                inputValues
              } else {
                NULL
              }
            } else {
              NULL
            }
          }
        } else {
          NULL
        }

        settings <- list(
          alignmentScale = input$alignmentScale,
          sedModel = input$sedModel,
          alphaPosition = input$alphaPosition,
          customAlphaValues = customAlphaValues,
          nKnots = input$nKnots,
          nRun = input$nRun,
          nIter = input$nIter,
          nThin = input$nThin,
          nChains = input$nChains,
          priors = reactiveValuesToList(priorSettings)
        )
        r$savedModelSettings[["_last_session"]] <- settings
      }
    }, error = function(e) {
      # Model settings not available yet - that's okay
    })

    removeModal()
  }

  # Prevent default modal close behavior - use our closeModal button instead
  observeEvent(session$input$`shiny-modal-closed`, {
    # This event fires when modal is closed, but we handle it via closeModal button
    # Do nothing here to prevent conflicts
  }, ignoreInit = TRUE)

  # references UI and onStop cleanup
  # output$references <- renderUI({
  #   tagList(tags$h2("References for methods used"),
  #           HTML(SBMethod))
  # })

  onStop(function() {
    options(startOpt)
    if (file.exists(cmdLogFile)) unlink(cmdLogFile)
    if (logging) {
      LogMsg("Session terminated")
      on.exit(close(logMsgFile))
    }
  })

  # optional debug block
  # observe({ ... })

  # Functions to save and load model settings
  saveModelSettings <- function(name, settings) {
    r$savedModelSettings[[name]] <- settings
  }

  loadModelSettings <- function(name) {
    if (name %in% names(r$savedModelSettings)) {
      settings <- r$savedModelSettings[[name]]

      # Update inputs with saved settings
      if (!is.null(settings$alignmentScale)) {
        updateSelectInput(session, "alignmentScale", selected = settings$alignmentScale)
      }
      if (!is.null(settings$sedModel)) {
        updateSelectInput(session, "sedModel", selected = settings$sedModel)
      }
      if (!is.null(settings$alphaPosition)) {
        updateSelectInput(session, "alphaPosition", selected = settings$alphaPosition)

        # If custom alpha position, restore custom values after delays to allow UI to update
        if (settings$alphaPosition == "custom" && !is.null(settings$customAlphaValues) && length(settings$customAlphaValues) > 0) {
          # First delay: wait for alphaPosition dropdown to update
          shinyjs::delay(400, {
            # Second delay: wait for custom alpha inputs UI to render and data to be valid
            shinyjs::delay(400, {
              # First restore the stored values directly (they were already validated when saved)
              model_api$restoreCustomAlphaValues(settings$customAlphaValues)

              # Then restore the numeric inputs to show the values in the UI
              for (site in names(settings$customAlphaValues)) {
                inputId <- paste0("customAlpha_", site)
                updateNumericInput(session, inputId, value = settings$customAlphaValues[[site]])
              }
            })
          })
        }
      }

      # Store Priors tab settings in reactive values (UI will read from these when it renders)
      if (!is.null(settings$nKnots)) {
        model_api$setStoredNKnots(settings$nKnots)
        # Also try to update the input if it exists
        shinyjs::delay(200, {
          updateSliderInput(session, "nKnots", value = settings$nKnots)
        })
      }
      if (!is.null(settings$penaltyMultiplier)) {
        model_api$setStoredPenaltyMultiplier(settings$penaltyMultiplier)
        # Also try to update the input if it exists
        shinyjs::delay(200, {
          updateSliderInput(session, "penaltyMultiplier", value = settings$penaltyMultiplier)
        })
      }
      if (!is.null(settings$bLambdaLog)) {
        model_api$setStoredBLambdaLog(settings$bLambdaLog)
        # Also try to update the input if it exists
        shinyjs::delay(200, {
          shinyjs::runjs(paste0("
            function updateBLambdaSlider() {
              var slider = document.getElementById('bLambdaLog');
              if (slider) {
                slider.value = ", settings$bLambdaLog, ";
                var event = new Event('input', { bubbles: true });
                slider.dispatchEvent(event);
                $(slider).trigger('change');

                // Also update the display value
                var val = parseFloat(slider.value);
                if (!isNaN(val)) {
                  var actualValue = Math.pow(10, val);
                  var displayValue;
                  if (actualValue >= 10000) {
                    var exp = actualValue.toExponential(2);
                    var parts = exp.split('e+');
                    if (parts.length === 2) {
                      displayValue = parseFloat(parts[0]).toFixed(2) + '×10<sup>' + parts[1] + '</sup>';
                    } else {
                      displayValue = actualValue.toFixed(0);
                    }
                  } else if (actualValue >= 1000) {
                    displayValue = Math.round(actualValue).toLocaleString();
                  } else if (actualValue >= 1) {
                    displayValue = actualValue.toFixed(actualValue >= 10 ? 0 : 1);
                  } else {
                    displayValue = actualValue.toFixed(actualValue >= 0.1 ? 1 : 2);
                  }
                  $('#bLambdaValueDisplay').html(displayValue);
                }
                return true;
              }
              return false;
            }
            updateBLambdaSlider();
          "))
        })
      }

      if (!is.null(settings$nRun)) {
        updateNumericInput(session, "nRun", value = settings$nRun)
      }
      if (!is.null(settings$nIter)) {
        updateNumericInput(session, "nIter", value = settings$nIter)
      }
      if (!is.null(settings$nThin)) {
        updateNumericInput(session, "nThin", value = settings$nThin)
      }
      if (!is.null(settings$nChains)) {
        updateNumericInput(session, "nChains", value = settings$nChains)
      }
      if (!is.null(settings$priors)) {
        # Load priors into priorSettings
        for (nm in names(settings$priors)) {
          priorSettings[[nm]] <- settings$priors[[nm]]
        }

        # Force the priors UI to update by triggering the observer that syncs UI controls
        # The observeEvent(activePriorName(), ...) in model-module.R syncs UI with priorSettings
        # We trigger it by temporarily changing activePrior, then changing it back
        shinyjs::delay(500, {
          if (!is.null(model_api) && !is.null(model_api$indices)) {
            tryCatch({
              idx <- model_api$indices()
              if (!is.null(idx) && length(idx$names) > 0) {
                # Get current active prior (or use first one)
                currentPrior <- isolate(input$activePrior)
                if (is.null(currentPrior) || !(currentPrior %in% idx$names)) {
                  currentPrior <- idx$names[1]
                }
                # Temporarily change to a different prior, then change back
                # This will trigger the observer twice, ensuring UI syncs with loaded settings
                if (length(idx$names) > 1) {
                  # Change to a different prior first
                  otherPrior <- idx$names[idx$names != currentPrior][1]
                  updateRadioButtons(session, "activePrior", selected = otherPrior)
                  # Then change back to trigger the observer with the loaded settings
                  shinyjs::delay(100, {
                    updateRadioButtons(session, "activePrior", selected = currentPrior)
                  })
                } else if (length(idx$names) == 1) {
                  # Only one prior - just update it to trigger the observer
                  updateRadioButtons(session, "activePrior", selected = currentPrior)
                }
              }
            }, error = function(e) {
              # If indices aren't ready yet, that's okay - priors will update when tab is opened
            })
          }
        })
      }
      return(TRUE)
    }
    return(FALSE)
  }

  # Handle loading saved model settings
  observeEvent(input$loadModelSettings, {
    if (!is.null(input$loadModelSettingsSelect) && input$loadModelSettingsSelect != "") {
      if (loadModelSettings(input$loadModelSettingsSelect)) {
        showNotification(paste("Loaded model settings:", input$loadModelSettingsSelect), type = "message")
      } else {
        showNotification("Failed to load model settings", type = "error")
      }
    }
  })

  # Handle saving model settings when running
  observeEvent(input$runModel, {
    if (!data_api$signalValid()) {
      showNotification("Please provide a valid data set", type = "error")
      return()
    }

    # Collect current model settings (including custom alpha values if custom is selected)
    # If custom is selected, prefer stored values (from Update button), but if empty, read from inputs
    customAlphaValues <- if (!is.null(input$alphaPosition) && input$alphaPosition == "custom") {
      stored <- tryCatch({
        model_api$storedCustomAlphaValues()
      }, error = function(e) {
        NULL
      })
      # Check if stored values exist and are non-empty
      if (!is.null(stored) && is.list(stored) && length(stored) > 0 && any(!sapply(stored, is.null))) {
        stored
      } else {
        # Read directly from numeric inputs (even if not validated via Update button)
        if (data_api$signalValid()) {
          sd <- data_api$stratData()
          sites <- sd$sites
          alignmentScale <- input$alignmentScale %||% "height"

          if (alignmentScale == "height") {
            inputSites <- sites[-1]
          } else {
            inputSites <- sites
          }

          inputValues <- list()
          for (site in inputSites) {
            inputId <- paste0("customAlpha_", site)
            val <- input[[inputId]]
            if (!is.null(val) && !is.na(val) && is.numeric(val) && is.finite(val)) {
              inputValues[[site]] <- val
            }
          }

          if (length(inputValues) > 0) {
            inputValues
          } else {
            NULL
          }
        } else {
          NULL
        }
      }
    } else {
      NULL
    }

    settings <- list(
      alignmentScale = input$alignmentScale,
      sedModel = input$sedModel,
      alphaPosition = input$alphaPosition,
      customAlphaValues = customAlphaValues,  # Store custom alpha values if applicable
      nKnots = input$nKnots,
      nRun = input$nRun,
      nIter = input$nIter,
      nThin = input$nThin,
      nChains = input$nChains,
      penaltyMultiplier = input$penaltyMultiplier,
      bLambdaLog = input$bLambdaLog,  # Store log scale position
      priors = reactiveValuesToList(priorSettings)
    )

    # Always save settings (as per requirement)
    if (!is.null(input$saveModelSettingsName) && nzchar(input$saveModelSettingsName)) {
      # Custom name provided
      saveModelSettings(input$saveModelSettingsName, settings)
      showNotification(paste("Model settings saved as:", input$saveModelSettingsName), type = "message")
    } else {
      # Auto-generate name
      autoName <- paste0("model-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
      saveModelSettings(autoName, settings)
      showNotification(paste("Model settings saved as:", autoName), type = "message")
    }

    # Proceed with model run
    model_api$Align(useDefaults = FALSE)
  })

  # Show the modal on start
  observe({
    r$modalView <- "load"
    showModal(modelSelectionModal())
  })

  # Handle Load signals button click
  observeEvent(input$loadSignal, {
    # Reset loadedSavedDataset flag when opening load signal (user might want to load new source)
    # Only keep it TRUE if we're explicitly loading a saved dataset
    r$loadedSavedDataset <- FALSE

    # Reset save data field when opening modal
    r$showSaveDataField <- FALSE

    # Restore persisted data if available
    if (!is.null(r$persistedDataset)) {
      r$dataset <- r$persistedDataset
    }
    r$modalView <- "load"
    showModal(modelSelectionModal())

    # Restore settings after modal is shown
    shinyjs::delay(100, {
      if (!is.null(r$persistedDataSource)) {
        updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
      }
      if (!is.null(r$persistedDataScale)) {
        updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
      }
      if (!is.null(r$persistedPartitionSource)) {
        updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
      }
      if (!is.null(r$persistedSiteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
      }
    })
  })

  # Handle Model setup button click
  observeEvent(input$modelSetup, {
    # ALWAYS check if data is valid first - Model Setup requires a loaded dataset
    if (!data_api$signalValid()) {
      # No valid data loaded - must load a dataset first
      if (length(r$savedDatasets) > 0) {
        # Saved datasets exist - prompt user to select one
        showNotification("Please load a dataset first. Model Setup requires a loaded dataset. Select a saved dataset or load a new one.",
                        type = "warning", duration = 8)
      } else {
        # No saved datasets - prompt to load new data
        showNotification("Please load a dataset first. Model Setup requires a loaded dataset.",
                        type = "warning", duration = 8)
      }

      # Always open modal to load tab
      r$modalView <- "load"
      showModal(modelSelectionModal())

      # Try to restore data if available
      shinyjs::delay(300, {
        # If there's a previously loaded saved dataset, auto-select it (but don't auto-load)
        if (!is.null(r$currentLoadedDatasetName) &&
            r$currentLoadedDatasetName %in% names(r$savedDatasets)) {
          # Pre-select the saved dataset in the dropdown for convenience
          updateSelectInput(session, "loadDatasetSelect", selected = r$currentLoadedDatasetName)
        } else if (!is.null(r$persistedDataset)) {
          # If we have persisted data but no saved dataset name, restore it via dataSource
          if (!is.null(r$persistedDataSource)) {
            updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
          } else {
            updateSelectInput(session, "dataSource", selected = "file")
          }
        }
      })
      return()  # Stop here - don't proceed to model setup
    }

    # If we reach here, we have valid data - proceed to model setup

    # If we have valid data, proceed to customRun
    # Ensure persistedDataset is available (should already be, but double-check)
    if (is.null(r$persistedDataset) && !is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }

    # Set dataset immediately so it's available
    if (!is.null(r$persistedDataset)) {
      r$dataset <- r$persistedDataset
    }

    r$modalView <- "customRun"
    showModal(modelSelectionModal())

    # Restore persisted UI settings after modal opens - this will trigger UpdateData()
    shinyjs::delay(300, {
      if (!is.null(r$persistedDataset)) {
        # Restore data source setting first - this will trigger UpdateData() reactive
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        } else {
          # If no persisted source, default to "file" to trigger UpdateData()
          updateSelectInput(session, "dataSource", selected = "file")
        }

        # UpdateData() should trigger automatically when dataSource changes
        # It will check for persistedDataset and restore it

        # Small delay before restoring other settings to allow UpdateData to complete
        shinyjs::delay(300, {
          # Double-check dataset was restored, restore manually if needed
          if (is.null(r$dataset) && !is.null(r$persistedDataset)) {
            r$dataset <- r$persistedDataset
          }

          if (!is.null(r$persistedDataScale)) {
            updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
          }
          if (!is.null(r$persistedPartitionSource)) {
            updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
          }
          if (!is.null(r$persistedSiteSelections)) {
            updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
          }
        })
      }

      # Restore model settings if available (after UI settings and data loading)
      shinyjs::delay(400, {
        if ("_last_session" %in% names(r$savedModelSettings)) {
          loadModelSettings("_last_session")
        }
      })
    })
  })


  # Display outputs for model information
  output$displayAlignmentScale <- renderText({ input$alignmentScale %||% "Not set" })
  output$displaySedModel <- renderText({ input$sedModel %||% "Not set" })
  output$displayAlphaPosition <- renderText({ input$alphaPosition %||% "Not set" })
  output$displayNKnots <- renderText({ input$nKnots %||% "Not set" })

  # refresh alignment
  observeEvent(model_api$alignment(), {
    req(model_api$alignment())

    # Keep a copy of the current posterior in r$alignment for save/export/load operations
    # This ensures r$alignment is always the latest StratPosterior from the last model run
    # But don't update if we're currently loading a result (to prevent triggering auto-save)
    if (!r$isLoadingResult) {
      r$alignment <- model_api$alignment()
    }

    # Update data preview when alignment changes (to show signal data from StratPosterior)
    tryCatch({
      if (!is.null(data_api$updateDataPreview)) {
        data_api$updateDataPreview()
      }
    }, error = function(e) {
      # Function might not be available yet, that's okay
    })

    refresh_posterior_controls(session, data_api, model_api)

    # Ensure partitions persist after model run
    # Partitions are stored in r$partitionData and should already persist
    # But make sure partition source is saved
    if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      r$persistedPartitionSource <- "interactive"
    }
  }, ignoreInit = TRUE)

  # Prevent prior recalculation when dataScale changes unnecessarily
  # Only recalculate if stratData actually changes
  observeEvent(input$dataScale, {
    # When dataScale changes, the stratData will be recalculated
    # This is expected, but we should preserve priors if possible
    # The priors will be recalculated when needed by ensurePriorsInitialized
  }, ignoreInit = TRUE)


  # ============================================================================
  # Results Management: Save/Load/Export/Import
  # ============================================================================

  # Source result modals
  source("dialog/loadResultsModal.R", local = serverEnv)
  source("dialog/exportResultsModal.R", local = serverEnv)
  source("dialog/importResultsModal.R", local = serverEnv)

  # Expose saved results count
  output$savedResultsCount <- reactive(length(r$savedResults))
  outputOptions(output, "savedResultsCount", suspendWhenHidden = FALSE)

  # Automatic saving of results when they become available (only from successful model runs)
  observeEvent(model_api$alignment(), {
    alignm <- model_api$alignment()
    # Only auto-save if results are from a model run, not from loading/importing
    if (!is.null(alignm) && !r$isLoadingResult) {
      # Automatically save results with timestamp
      saveName <- paste0("result-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
      r$savedResults[[saveName]] <- alignm
      r$currentLoadedResultName <- saveName
      r$loadedSavedResult <- TRUE

      # Also update r$alignment to keep it in sync
      r$alignment <- alignm

      showNotification(paste("Results automatically saved as:", saveName), type = "message", duration = 5)
    }
  }, ignoreInit = TRUE)

  # Handle Load Results button
  observeEvent(input$loadResults, {
    showModal(loadResultsModal(r$savedResults))
  })

  # Handle confirm load results
  observeEvent(input$confirmLoadResults, {
    if (is.null(input$loadResultsSelect) || input$loadResultsSelect == "") {
      showNotification("Please select a result to load.", type = "error")
      return()
    }

    if (!input$loadResultsSelect %in% names(r$savedResults)) {
      showNotification("Selected result not found.", type = "error")
      removeModal()
      return()
    }

    # Load the StratPosterior object
    r$isLoadingResult <- TRUE  # Set flag to prevent auto-save
    r$alignment <- r$savedResults[[input$loadResultsSelect]]
    r$currentLoadedResultName <- input$loadResultsSelect
    r$loadedSavedResult <- TRUE

    # Reset flag after a short delay to ensure all observers have processed
    shinyjs::delay(100, {
      r$isLoadingResult <- FALSE
    })

    # Extract data and model from posterior if available
    if (!is.null(r$alignment$data)) {
      # Make data available in load data tab
      # Convert StratData back to raw data frame if possible
      # For now, just store a reference - the data is in r$alignment$data
      # User can access it via "Load from saved result"
    }

    removeModal()
    showNotification(paste("Results loaded:", input$loadResultsSelect), type = "message", duration = 5)

    # Refresh posterior controls
    refresh_posterior_controls(session, data_api, model_api)
  })

  # Handle cancel load results
  observeEvent(input$cancelLoadResults, {
    removeModal()
  })

  # Handle save results button (formerly Export Results)
  observeEvent(input$exportResults, {
    # Use model_api$alignment() as the source of truth (same as results-module.R)
    if (is.null(model_api$alignment())) {
      showNotification("No results available to save. Please run a model first.", type = "error")
      return()
    }
    showModal(exportResultsModal())
  })

  # Save results download handler (formerly Export Results)
  output$exportResultsDownload <- downloadHandler(
    filename = function() {
      name <- trimws(input$exportResultsName)
      if (is.null(name) || nchar(name) == 0) {
        name <- paste0("result-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
      }
      # Ensure .rds extension - remove any existing extension first
      name <- tools::file_path_sans_ext(name)
      paste0(name, ".rds")
    },
    content = function(file) {
      # Use model_api$alignment() as the source of truth (same as results-module.R)
      alignm <- model_api$alignment()
      if (is.null(alignm)) {
        showNotification("No results available to save.", type = "error")
        return()
      }
      # Save as RDS file - use file path directly (saveRDS handles binary mode)
      saveRDS(alignm, file)
    },
    contentType = "application/octet-stream"
  )

  # Handle confirm save results (formerly Export Results)
  observeEvent(input$confirmExportResults, {
    # Use model_api$alignment() as the source of truth (same as results-module.R)
    alignm <- model_api$alignment()
    if (is.null(alignm)) {
      showNotification("No results available to save.", type = "error")
      removeModal()
      return()
    }

    # Close modal first
    removeModal()

    # Wait for modal to close, then trigger download by constructing the URL manually
    shinyjs::delay(300, {
      # Get session ID and construct download URL
      shinyjs::runjs("
        (function() {
          var sessionId = Shiny.shinyapp.config.sessionId;
          var downloadUrl = '/session/' + sessionId + '/download/exportResultsDownload';

          // Create a temporary link element and trigger download
          var link = document.createElement('a');
          link.href = downloadUrl;
          link.download = '';
          link.style.display = 'none';
          document.body.appendChild(link);
          link.click();

          // Clean up after a short delay
          setTimeout(function() {
            document.body.removeChild(link);
          }, 100);
        })();
      ")
    })

    shinyjs::delay(1000, {
      showNotification("Results saved successfully.", type = "message", duration = 5)
    })
  })

  # Handle cancel save results (formerly Export Results)
  observeEvent(input$cancelExportResults, {
    removeModal()
  })

  # Handle Import Results button
  observeEvent(input$importResults, {
    showModal(importResultsModal())
  })

  # Handle confirm import results
  observeEvent(input$confirmImportResults, {
    if (is.null(input$importResultsFile)) {
      showNotification("Please select a file to import.", type = "error")
      return()
    }

    tryCatch({
      # Load the StratPosterior object
      # Use the datapath which is the temporary file location
      file_path <- input$importResultsFile$datapath

      # Debug: Log file info
      if (is.null(file_path) || is.na(file_path) || file_path == "") {
        showNotification("Invalid file path. Please select the file again.", type = "error")
        return()
      }

      # Normalize the file path (important on Windows)
      file_path <- normalizePath(file_path, mustWork = FALSE)

      # Validate file exists and is readable
      if (!file.exists(file_path)) {
        showNotification(paste("Selected file not found at:", file_path), type = "error")
        removeModal()
        return()
      }

      # Check if file is readable
      if (!file.access(file_path, mode = 4) == 0) {
        showNotification("Selected file is not readable. Please check file permissions.", type = "error")
        removeModal()
        return()
      }

      # Check file size (should be > 0)
      file_info <- file.info(file_path)
      if (is.na(file_info$size) || file_info$size == 0) {
        showNotification("Selected file is empty or cannot be read.", type = "error")
        removeModal()
        return()
      }

      # Try to read the RDS file
      # First check if file looks like HTML (common when download fails)
      first_bytes <- readBin(file_path, "raw", n = 100)
      first_chars <- tryCatch({
        rawToChar(first_bytes)
      }, error = function(e) {
        ""  # If conversion fails, it's binary (good for RDS)
      })

      if (grepl("<!DOCTYPE|<html|<!doctype", first_chars, ignore.case = TRUE)) {
        showNotification("The file appears to be HTML, not an RDS file. The export may have failed.", type = "error")
        removeModal()
        return()
      }

      # Try to read the RDS file - handle R version compatibility issues
      importedResult <- tryCatch({
        # Simple direct read - readRDS handles binary mode automatically
        result <- readRDS(file_path)
        result
      }, warning = function(w) {
        # If there's a warning (e.g., version mismatch), try to continue
        # Try reading again
        tryCatch({
          readRDS(file_path, refhook = NULL)
        }, error = function(e) {
          stop(paste("Failed to read RDS file after warning:", w$message, "\nError:", e$message))
        })
      }, error = function(e) {
        error_msg <- e$message

        # Check if it's the "unknown input format" error
        if (grepl("unknown input format", error_msg, ignore.case = TRUE)) {
          # This could be an R version compatibility issue
          # Try reading with explicit binary connection
          tryCatch({
            con <- file(file_path, open = "rb")
            on.exit(close(con), add = TRUE)
            readRDS(con, refhook = NULL)
          }, error = function(e2) {
            # If that also fails, provide helpful error message
            stop(paste("Failed to read RDS file. This might be due to R version incompatibility.",
                      "\nError:", e2$message,
                      "\nFile size:", file_info$size, "bytes",
                      "\n\nPossible solutions:",
                      "\n1. The file may have been created with a different R version",
                      "\n2. Try re-exporting the file from RStudio using: saveRDS(object, 'file.rds', version = 2)",
                      "\n3. Or load it in RStudio and re-save it with your current R version"))
          })
        } else {
          stop(paste("Failed to read RDS file:", error_msg))
        }
      })

      # Validate it's a StratPosterior object
      if (is.null(importedResult)) {
        showNotification("The selected file is empty or corrupted.", type = "error")
        removeModal()
        return()
      }

      if (!inherits(importedResult, "StratPosterior")) {
        showNotification(paste("The selected file does not contain a StratPosterior object. Found class:",
                              paste(class(importedResult), collapse = ", ")), type = "error")
        removeModal()
        return()
      }

      # Get name for the result
      importName <- trimws(input$importResultsName)
      if (is.null(importName) || nchar(importName) == 0) {
        # Use file name without extension
        importName <- tools::file_path_sans_ext(basename(input$importResultsFile$name))
        # If name already exists, append timestamp
        if (importName %in% names(r$savedResults)) {
          importName <- paste0(importName, "-", format(Sys.time(), "%Y%m%d-%H%M%S"))
        }
      }

      # Save to session results
      r$savedResults[[importName]] <- importedResult
      r$currentLoadedResultName <- importName
      r$loadedSavedResult <- TRUE

      # Also set as current alignment
      r$isLoadingResult <- TRUE  # Set flag to prevent auto-save
      r$alignment <- importedResult

      # Reset flag after a short delay to ensure all observers have processed
      shinyjs::delay(100, {
        r$isLoadingResult <- FALSE
      })

      removeModal()
      showNotification(paste("Results imported and saved as:", importName), type = "message", duration = 5)

      # Refresh posterior controls
      refresh_posterior_controls(session, data_api, model_api)

    }, error = function(e) {
      showNotification(paste("Error importing results:", e$message), type = "error", duration = 10)
      # Don't remove modal so user can try again
    })
  })

  # Handle cancel import results
  observeEvent(input$cancelImportResults, {
    removeModal()
  })

  # Model progress modal iframe output
  output$modelProgressIframe <- renderUI({
    # Get model name and mount ID from model_api
    modelName <- model_api$modelNameRV()
    mountId <- model_api$mountId

    if (is.null(modelName)) {
      return(tags$div(
        style = "text-align: center; padding: 50px;",
        tags$h4("Preparing model run..."),
        tags$p("The model will start shortly. Progress will appear here.")
      ))
    }

    scale <- 1
    baseH <- 600

    tags$div(
      style = sprintf(
        "transform: scale(%f);
       transform-origin: 0 0;
       width: calc(100%% / %f);
       height: %fpx;
       overflow: hidden;",
        scale, scale, baseH / scale
      ),
      tags$iframe(
        src    = sprintf("/%s/%s/results.html", mountId, modelName),
        width  = "100%",
        height = as.character(baseH / scale),
        style  = "border:0;"
      )
    )
  })

  # Close progress modal handler
  observeEvent(input$closeProgressModal, {
    removeModal()
  })

  # Watch for model name changes and update progress modal iframe
  observe({
    # Invalidate the iframe output when modelNameRV changes
    modelName <- tryCatch({
      model_api$modelNameRV()
    }, error = function(e) {
      NULL
    })
    if (!is.null(modelName)) {
      # The iframe output will automatically update since it reads modelNameRV
      # Just ensure it doesn't suspend when hidden
      outputOptions(output, "modelProgressIframe", suspendWhenHidden = FALSE)
    }
  })

}


