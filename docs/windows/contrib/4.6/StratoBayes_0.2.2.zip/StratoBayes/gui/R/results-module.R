results_server <- function(input, output, session, data_api, model_api) {

  # User-added named partitions per site (persist when switching wells)
  # Structure: list(siteName = data.frame(name = character(), height = numeric()))
  userPartitionsPerSite <- reactiveValues()

  # Normalize heights: remove duplicates, sort ascending, format as string
  # This ensures consistent ordering and no duplicates
  normalizeHeightsString <- function(raw) {
    if (is.null(raw) || !nzchar(trimws(raw))) return("")
    vals <- suppressWarnings(
      as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(raw)), ",")))
    )
    vals <- vals[is.finite(vals)]
    if (length(vals) == 0) return("")

    # Remove duplicates and sort in ascending order
    vals_rounded <- round(vals, 10)
    unique_indices <- !duplicated(vals_rounded)
    vals_unique <- vals[unique_indices]
    vals_sorted <- sort(vals_unique)

    if (length(vals_sorted) == 0) "" else paste(round(vals_sorted, 5), collapse = ", ")
  }

  # Parse comma-separated heights from a text input. Returns NULL if empty/invalid.
  # Automatically removes duplicate entries and sorts in ascending order.
  parseRefHeightsInput <- function(raw) {
    if (is.null(raw) || !nzchar(trimws(raw))) return(NULL)
    vals <- suppressWarnings(
      as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(raw)), ",")))
    )
    vals <- vals[is.finite(vals)]
    if (length(vals) == 0) return(NULL)

    # Remove duplicates and sort in ascending order
    vals_rounded <- round(vals, 10)
    unique_indices <- !duplicated(vals_rounded)
    vals_unique <- vals[unique_indices]
    vals_sorted <- sort(vals_unique)

    if (length(vals_sorted) == 0) NULL else vals_sorted
  }

  updateRefHeightsIfChanged <- function(value) {
    value <- value %||% ""
    current <- input$refHeights %||% ""
    if (!identical(as.character(current), as.character(value))) {
      updateTextInput(session, "refHeights", value = value)
    }
  }

  # Clamp heights to just inside the site data range to avoid StratMap out-of-bounds
  # errors caused by floating-point boundary values stored in partsAttr$Bound.
  # Strategy:
  #   - Heights significantly outside range (intentional Top_ buffers): preserve as-is
  #   - Heights slightly outside range (floating-point rounding only): snap to boundary
  #   - Heights at or near boundary (within boundary_tolerance): preserve as-is
  #   - Heights clearly inside range: apply epsilon inward nudge for safety
  clampRefHeightsToSite <- function(heights, alignm, sourceSite,
                                    eps_fraction = 1e-4, eps_abs = 1e-6) {
    if (is.null(heights) || length(heights) == 0) return(heights)
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(heights)
    if (is.null(sourceSite)) return(heights)
    tryCatch({
      # Use BoundLow and Bound from partsAttr to match what .AgeConversionGeneral validates against
      # This ensures our clamping matches the validation logic
      data <- alignm$data
      sites <- data$sites
      if (is.null(sites)) return(heights)

      # Convert site name to index if needed
      siteIdx <- if (is.character(sourceSite)) {
        match(sourceSite, sites)
      } else {
        as.integer(sourceSite)
      }
      if (is.na(siteIdx) || siteIdx < 1 || siteIdx > length(sites)) return(heights)

      # Get bounds from partsAttr (same as .AgeConversionGeneral uses)
      boundLow <- data[[c("partsAttr", "BoundLow")]][, siteIdx]
      boundHigh <- data[[c("partsAttr", "Bound")]][, siteIdx]

      # Get valid bounds (non-NA)
      boundLow <- boundLow[is.finite(boundLow)]
      boundHigh <- boundHigh[is.finite(boundHigh)]

      if (length(boundLow) == 0 || length(boundHigh) == 0) return(heights)

      siteMin <- min(boundLow, na.rm = TRUE)
      siteMax <- max(boundHigh, na.rm = TRUE)
      height_range <- siteMax - siteMin

      # Tolerance for floating-point rounding errors only (very tight: 0.001% of range, min 0.0001 units)
      rounding_tolerance <- max(height_range * 0.00001, 0.0001, na.rm = TRUE)

      # Tolerance for "at the boundary" detection — heights this close to siteMax/siteMin
      # are treated as boundary values and NOT nudged inward with epsilon
      boundary_tolerance <- max(height_range * 0.0001, 0.001, na.rm = TRUE)

      # Epsilon for nudging clearly-interior heights slightly away from boundaries
      eps <- max(height_range * eps_fraction, eps_abs)

      # Buffer threshold for intentional buffers (like Top_ partitions): 1% of range or 0.1 units
      buffer_threshold <- max(height_range * 0.01, 0.1, na.rm = TRUE)

      for (i in seq_along(heights)) {
        excess_above <- heights[i] - siteMax
        excess_below <- siteMin - heights[i]

        if (excess_above > buffer_threshold) {
          # Significantly above siteMax (beyond buffer threshold): likely intentional Top_ partition buffer
          # However, .AgeConversionGeneral validates against Bound, so we need to clamp to max(Bound)
          # to ensure validation passes. Top partitions should be stored in Bound anyway.
          heights[i] <- siteMax

        } else if (excess_above > rounding_tolerance) {
          # Moderately above siteMax (between rounding_tolerance and buffer_threshold)
          # Clamp to siteMax to ensure validation passes
          heights[i] <- siteMax

        } else if (excess_above > 0) {
          # Slightly above siteMax (floating-point rounding error only): snap to siteMax
          heights[i] <- siteMax

        } else if (excess_below > buffer_threshold) {
          # Significantly below siteMin: intentional buffer — clamp to siteMin
          heights[i] <- siteMin

        } else if (excess_below > rounding_tolerance) {
          # Moderately below siteMin: clamp to siteMin
          heights[i] <- siteMin

        } else if (excess_below > 0) {
          # Slightly below siteMin (floating-point rounding error only): snap to siteMin
          heights[i] <- siteMin

        } else {
          # Height is within [siteMin, siteMax]
          # If it is AT or very near a boundary, preserve it exactly (no inward nudge)
          at_max <- (siteMax - heights[i]) <= boundary_tolerance
          at_min <- (heights[i] - siteMin) <= boundary_tolerance
          if (!at_max && !at_min) {
            # Clearly interior: nudge slightly inward so StratMap never sees an exact boundary
            heights[i] <- min(heights[i], siteMax - eps)
            heights[i] <- max(heights[i], siteMin + eps)
          }
          # If at_max or at_min: leave exactly as-is
        }
      }

      heights
    }, error = function(e) heights)
  }


  # Convert heights-at-source-well to reference heights for TopsPlot.
  # heightsAtSite must be numeric heights/depths at the well named sourceSite (site index 1 = reference).
  # When sourceSite is the reference well, return as-is; otherwise use StratMap to convert to reference scale.
  refHeightsFromSourceSite <- function(alignm, heightsAtSite, sourceSite) {
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(NULL)
    sites <- alignm$data$sites
    if (is.null(sites) || length(sites) == 0) return(heightsAtSite)
    refIdx <- 1L
    srcIdx <- match(as.character(sourceSite), as.character(sites), nomatch = NA)
    if (is.na(srcIdx)) return(heightsAtSite)
    if (srcIdx == refIdx || length(heightsAtSite) == 0) return(heightsAtSite)
    tryCatch({
      out <- StratoBayes::StratMap(alignm, heightsAtSite, site = sourceSite)[["mean"]]
      if (is.null(out) || any(!is.finite(out))) heightsAtSite else as.numeric(out)
    }, error = function(e) heightsAtSite)
  }

  # Set default refHeights when switching TO the correlation tab.
  # Priority:
  #   1. If partitions exist for the current source site (model-derived or
  #      user-added), use those heights -> correlation plot always colours
  #      partitions when they are available.
  #   2. If the user already typed refHeights, leave them alone.
  #   3. Otherwise fall back to bounds / signal-range defaults.
  observeEvent(input$plotTypeMain, {
    if (!identical(input$plotTypeMain, "correlation")) return()
    alignm <- model_api$alignment()
    if (is.null(alignm) || is.null(alignm$data)) return()
    dataObj <- alignm$data

    # (1) Prefer partitions when they exist.
    partHeights <- tryCatch({
      parts <- combinedPartitions()
      if (is.data.frame(parts) && nrow(parts) > 0) {
        h <- parts$height[is.finite(parts$height)]
        sort(unique(round(h, 10)))
      } else NULL
    }, error = function(e) NULL)
    if (!is.null(partHeights) && length(partHeights) > 0) {
      updateRefHeightsIfChanged(normalizeHeightsString(paste(round(partHeights, 5), collapse = ", ")))
      return()
    }

    # (2) If the user has typed/edited refHeights already, keep them.
    existing <- trimws(input$refHeights %||% "")
    if (nzchar(existing)) {
      existingNums <- suppressWarnings(as.numeric(
        strsplit(existing, "\\s*,\\s*")[[1]]
      ))
      if (any(is.finite(existingNums))) return()
    }

    # (3) Fall back to data-bound defaults.
    defaultRefHeights <- NULL
    if (dataObj[["S"]] == 2) {
      site2Range <- range(c(dataObj[[c("partsAttr", "Bound")]][,2],
                          dataObj[[c("partsAttr", "BoundLow")]][,2]), na.rm = TRUE)
      site2Span <- diff(site2Range)
      refHeightsSite2 <- c(site2Range[1], mean(site2Range), site2Range[2]) + c(0.1, 0, -0.1) * site2Span
      tryCatch({
        defaultRefHeights <- StratoBayes::StratMap(alignm, refHeightsSite2, 2)[["mean"]]
      }, error = function(e) {
        defaultRefHeights <<- NULL
      })
    } else {
      bounds <- unique(c(na.omit(dataObj[[c("partsAttr", "Bound")]][, 1]),
                       na.omit(dataObj[[c("partsAttr", "BoundLow")]][, 1])))
      if (length(bounds) > 2) {
        bounds_sorted <- sort(bounds)
        defaultRefHeights <- bounds_sorted[is.finite(bounds_sorted)]
      } else {
        tryCatch({
          h1 <- StratoBayes::SignalLookUp(dataObj, "height", 1, signal = 1, includeNAsignal = FALSE)
          h1_vals <- c(min(h1, na.rm = TRUE), mean(range(h1, na.rm = TRUE)), max(h1, na.rm = TRUE))
          h1_vals <- h1_vals[is.finite(h1_vals)]
          defaultRefHeights <- if (length(h1_vals) > 0) sort(h1_vals) else c(0, 1, 2)
        }, error = function(e) {
          defaultRefHeights <<- c(0, 1, 2)
        })
      }
    }

    if (is.null(defaultRefHeights) || length(defaultRefHeights) == 0 || any(!is.finite(defaultRefHeights))) {
      defaultRefHeights <- c(0, 1, 2)
    } else {
      defaultRefHeights <- defaultRefHeights[is.finite(defaultRefHeights)]
      if (length(defaultRefHeights) == 0) defaultRefHeights <- c(0, 1, 2)
    }
    defaultRefHeights_normalized <- sort(unique(round(defaultRefHeights, 10)))
    refHeightsStr <- paste(round(defaultRefHeights_normalized, 3), collapse = ", ")
    updateRefHeightsIfChanged(refHeightsStr)
  }, ignoreInit = TRUE)

  # Correlation tab: well selector (heights/depths at this well are mapped to reference and plotted)
  # NOTE: read the current selection inside isolate() — without this, the renderUI
  # depends on the same input it creates, which causes the UI to re-render on every
  # selection change (re-creating the widget DOM and momentarily detaching its
  # input binding from observers downstream).
  output$correlationSourceSite_ui <- renderUI({
    alignm <- model_api$alignment()
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(NULL)
    sites <- alignm$data$sites
    if (is.null(sites) || length(sites) == 0) return(NULL)
    selected <- isolate(input$correlationSourceSite)
    if (is.null(selected) || !selected %in% sites) selected <- sites[1]
    div(
      style = "margin-bottom: 8px;",
      tags$strong("Select Well", style = "display: block; margin-bottom: 4px;"),
      selectInput("correlationSourceSite", NULL, choices = sites, selected = selected, width = "100%")
    )
  })

  # Partitions (name + height) for the currently selected well from alignment data
  correlationPartitions <- reactive({
    alignm <- model_api$alignment()
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(data.frame(name = character(0), height = numeric(0)))
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return(data.frame(name = character(0), height = numeric(0)))
    dataObj <- alignm$data
    sites <- dataObj$sites
    idx <- match(siteName, sites, nomatch = NA)
    if (is.na(idx)) return(data.frame(name = character(0), height = numeric(0)))
    bound <- tryCatch(dataObj[[c("partsAttr", "Bound")]], error = function(e) NULL)
    sedOri <- tryCatch(dataObj[[c("partsAttr", "sedRatesDFOri")]], error = function(e) NULL)
    if (is.null(bound) || !is.matrix(bound) || idx > ncol(bound)) return(data.frame(name = character(0), height = numeric(0)))
    h <- bound[, idx]
    nms <- if (!is.null(sedOri) && is.matrix(sedOri) && idx <= ncol(sedOri))
      as.character(sedOri[, idx]) else rep("", length(h))
    keep <- is.finite(h) & !is.na(h) & !is.na(nms) & nzchar(trimws(nms)) & trimws(nms) != "unconformity-NA"
    if (!any(keep)) return(data.frame(name = character(0), height = numeric(0)))
    out <- data.frame(name = trimws(nms[keep]), height = as.numeric(h[keep]), stringsAsFactors = FALSE)
    out <- out[order(out$height), ]
    out <- out[!duplicated(out$height), ]
    out
  })

  # Combined partitions: model partitions + user-added for current site (persist per site)
  combinedPartitions <- reactive({
    modelParts <- correlationPartitions()
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return(data.frame(name = character(0), height = numeric(0), isUser = logical(0)))
    # `$<-` on a 0-row data.frame with a length-1 RHS errors on newer R; build
    # an isUser column of the right length explicitly.
    modelParts$isUser <- rep(FALSE, nrow(modelParts))
    userParts <- userPartitionsPerSite[[siteName]]
    if (is.null(userParts) || !is.data.frame(userParts) || nrow(userParts) == 0) {
      return(modelParts)
    }
    userParts$isUser <- rep(TRUE, nrow(userParts))
    merged <- rbind(modelParts, userParts[, c("name", "height", "isUser")])
    merged <- merged[order(merged$height), ]
    merged <- merged[!duplicated(round(merged$height, 8)), ]
    merged
  })

  # Correlation tab: heights or depths at selected well + tooltip + partition buttons + add partition
  output$correlationRefHeightsBlock_ui <- renderUI({
    alignm <- model_api$alignment()
    if (is.null(alignm)) return(NULL)
    dataScale <- input$dataScale %||% "depth"
    label <- if (identical(dataScale, "depth")) "Depths at selected well" else "Heights at selected well"
    placeholder <- if (identical(dataScale, "depth")) "e.g. -10, -20, -30" else "e.g. 1, 2, 3"
    heightPlaceholder <- if (identical(dataScale, "depth")) "e.g. -7500" else "e.g. 100"
    parts <- combinedPartitions()
    siteName <- input$correlationSourceSite
    tagList(
      div(
        style = "margin-bottom: 6px; display: flex; align-items: center;",
        tags$label(tags$strong(label), style = "margin: 0 6px 0 0;"),
        tags$span(
          class = "correlation-depths-tooltip",
          style = "color: #6c757d; font-size: 0.85em;",
          icon("circle-info", class = "fas"),
          tags$span(
            class = "correlation-depths-tooltiptext",
            "Comma-separated values; mapped to reference and drawn across all sites."
          )
        )
      ),
      div(
        style = "display: flex; align-items: center; gap: 6px;",
        div(style = "flex: 1 1 auto;",
            textInput("refHeights", NULL, placeholder = placeholder, width = "100%")),
        actionButton("clearRefHeights", "Clear",
                     class = "btn-sm btn-default",
                     style = "flex-shrink: 0;",
                     title = "Remove all correlation lines (plots only, no lines)")
      ),
      div(
        class = "correlation-partitions-block",
        style = "margin-top: 8px; overflow: visible;",
        div(
          style = "display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; margin-bottom: 4px;",
          tags$strong("Boundaries / Partitions", style = "font-size: 0.9em; white-space: nowrap;"),
          tags$span(
            class = "correlation-depths-tooltip",
            style = "color: #6c757d; font-size: 0.85em; flex-shrink: 0;",
            icon("circle-info", class = "fas"),
            tags$span(
              class = "correlation-depths-tooltiptext",
              "Click a partition to add its depth/height to the correlation lines. Add custom named partitions for this well (saved per well)."
            )
          )
        ),
        if (nrow(parts) > 0) {
          div(
            style = "display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px;",
            lapply(seq_len(nrow(parts)), function(i) {
              row <- parts[i, ]
              btn <- tags$button(
                row$name,
                class   = "btn btn-sm btn-default",
                style   = "min-width: 2em;",
                onclick = sprintf(
                  "Shiny.setInputValue('appendPartitionHeight', {height: %s, counter: Math.random()}, {priority: 'event'});",
                  row$height
                )
              )
              if (isTRUE(row$isUser)) {
                div(
                  style = "display: inline-flex; align-items: center; gap: 2px;",
                  btn,
                  tags$button(
                    icon("times", class = "fas"),
                    class = "btn btn-sm btn-default",
                    style = "padding: 2px 6px;",
                    onclick = sprintf(
                      "Shiny.setInputValue('removeUserPartition', {site: '%s', height: %s}, {priority: 'event'});",
                      gsub("'", "\\'", siteName), row$height
                    ),
                    title = "Remove this partition"
                  )
                )
              } else {
                btn
              }
            })
          )
        },
        div(
          style = "display: flex; flex-wrap: wrap; align-items: center; gap: 4px;",
          textInput("newPartitionName", NULL, placeholder = "Name", width = "80px"),
          textInput("newPartitionHeight", NULL, placeholder = heightPlaceholder, width = "70px"),
          actionButton("addUserPartition", "Add", class = "btn-sm btn-primary")
        )
      )
    )
  })

  # Add user partition for current site
  observeEvent(input$addUserPartition, {
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return()
    nm <- trimws(input$newPartitionName %||% "")
    h <- suppressWarnings(as.numeric(input$newPartitionHeight %||% ""))
    if (!nzchar(nm)) {
      showNotification("Enter a partition name.", type = "warning")
      return()
    }
    if (is.na(h) || !is.finite(h)) {
      showNotification("Enter a valid depth or height.", type = "warning")
      return()
    }
    existing <- userPartitionsPerSite[[siteName]]
    if (is.null(existing) || !is.data.frame(existing)) {
      existing <- data.frame(name = character(0), height = numeric(0), stringsAsFactors = FALSE)
    }
    newRow <- data.frame(name = nm, height = h, stringsAsFactors = FALSE)
    combined <- rbind(existing, newRow)
    combined <- combined[order(combined$height), ]
    combined <- combined[!duplicated(round(combined$height, 8)), ]
    userPartitionsPerSite[[siteName]] <- combined
    updateTextInput(session, "newPartitionName", value = "")
    updateTextInput(session, "newPartitionHeight", value = "")
    # Add the new partition's height to refHeights (correlation lines) without clearing existing selection
    current <- trimws(input$refHeights %||% "")
    newVal  <- round(h, 5)
    added   <- if (nzchar(current)) paste(current, newVal, sep = ", ") else as.character(newVal)
    updateRefHeightsIfChanged(normalizeHeightsString(added))
    showNotification(paste("Added partition", nm, "for", siteName), type = "message", duration = 2)
  })

  # Remove user partition
  observeEvent(input$removeUserPartition, {
    site <- input$removeUserPartition$site
    height <- as.numeric(input$removeUserPartition$height)
    if (is.null(site) || is.na(height) || !is.finite(height)) return()
    existing <- userPartitionsPerSite[[site]]
    if (is.null(existing) || !is.data.frame(existing) || nrow(existing) == 0) return()
    tol <- 1e-6
    keep <- abs(existing$height - height) > tol
    if (any(!keep)) {
      userPartitionsPerSite[[site]] <- existing[keep, , drop = FALSE]
      # Remove this partition's height from refHeights (correlation lines) but keep the rest
      currentVals <- parseRefHeightsInput(input$refHeights)
      if (!is.null(currentVals) && length(currentVals) > 0) {
        remaining <- currentVals[abs(currentVals - height) > tol]
        updateRefHeightsIfChanged(normalizeHeightsString(
          if (length(remaining) > 0) paste(round(remaining, 5), collapse = ", ") else ""))
      }
      showNotification("Partition removed", type = "message", duration = 2)
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Keep current partitions (name + height) for append buttons
  correlationPartitionsForAppend <- reactiveVal(data.frame(name = character(0), height = numeric(0)))
  observe({
    correlationPartitionsForAppend(combinedPartitions()[, c("name", "height"), drop = FALSE])
  })

  # Clear button: remove all correlation lines (plot shows signals only)
  observeEvent(input$clearRefHeights, {
    updateRefHeightsIfChanged("")
  }, ignoreInit = TRUE)

  # When switching source well on the correlation tab, reset refHeights to that
  # site's partitions (model + user-added). Skip if no partitions are available.
  observeEvent(input$correlationSourceSite, {
    if (!identical(input$plotTypeMain, "correlation")) return()
    parts <- combinedPartitions()
    if (is.null(parts) || nrow(parts) == 0) return()
    heights <- parts$height[is.finite(parts$height)]
    if (length(heights) == 0) return()
    updateRefHeightsIfChanged(normalizeHeightsString(paste(round(heights, 5), collapse = ", ")))
  }, ignoreInit = TRUE)

  # Partition buttons: a single JS message handler replaces pre-registering N observers.
  # The button's onclick (injected in renderUI below) sends the height value directly.
  observeEvent(input$appendPartitionHeight, {
    height  <- as.numeric(input$appendPartitionHeight$height)
    counter <- input$appendPartitionHeight$counter  # ensures repeated clicks on same button fire
    if (is.null(height) || !is.finite(height)) return()
    current <- trimws(input$refHeights %||% "")
    newVal  <- round(height, 5)
    # Add new value to current string, then normalize (remove duplicates, sort)
    added   <- if (nzchar(current)) paste(current, newVal, sep = ", ") else as.character(newVal)
    normalized <- normalizeHeightsString(added)
    updateRefHeightsIfChanged(normalized)
    # Clamping happens at plot/export time via clampRefHeightsToSite()
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Create a debounced version of refHeights input to wait for user to finish typing
  # This prevents normalization from triggering on every keystroke
  refHeightsDebounced <- debounce(reactive({ input$refHeights }), millis = 750)

  # Observer to normalize heights whenever user manually edits the input
  # This ensures duplicates are removed and values are sorted after user stops typing
  # Debounced to wait 0.75 seconds of inactivity before triggering
  observeEvent(refHeightsDebounced(), {
    current <- trimws(refHeightsDebounced() %||% "")
    if (!nzchar(current)) return()
    normalized <- normalizeHeightsString(current)
    # Only update if normalization changed the value (to avoid infinite loops)
    if (normalized != current) {
      updateRefHeightsIfChanged(normalized)
    }
  }, ignoreInit = TRUE)

  # Export well tops download handler
  output$exportWellTops <- downloadHandler(
    filename = function() {
      paste0("well-tops-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"), ".csv")
    },
    content = function(file) {
      # Get alignment object
      alignm <- model_api$alignment()
      if (is.null(alignm)) {
        showNotification("No results available. Please run a model first.", type = "error")
        return()
      }

      # Build the full list of boundaries to export:
      #   (a) every partition row in stratData$parts (covers partitions at ALL
      #       sites, including ones added via the partitions modal), then
      #   (b) every user-added partition from every site in the correlation
      #       panel (unless subsequently deleted; those entries have already
      #       been removed from userPartitionsPerSite).
      # Each entry is (name, refHeight) where refHeight lives on the reference
      # site's scale. Heights recorded at site X are mapped to reference
      # heights via refHeightsFromSourceSite(). If the same partition name
      # appears at multiple sites, we keep a single row (first occurrence,
      # preferring the reference site if it is present there).
      dataObj   <- alignm$data
      siteList  <- tryCatch(as.character(dataObj$sites), error = function(e) character(0))
      parts_df  <- tryCatch(dataObj$parts, error = function(e) NULL)
      siteColNm <- tryCatch(dataObj$siteColumn, error = function(e) NULL)
      zColNm    <- tryCatch(dataObj$zColumn,    error = function(e) NULL)

      boundarySpec <- data.frame(name = character(0), refHeight = numeric(0),
                                 source = character(0), isUser = logical(0),
                                 stringsAsFactors = FALSE)

      if (!is.null(parts_df) && is.data.frame(parts_df) && nrow(parts_df) > 0L &&
          !is.null(siteColNm) && !is.null(zColNm) &&
          all(c(siteColNm, zColNm) %in% colnames(parts_df))) {
        # Partition name column: "sedRates" is populated by StratData() from
        # partitionColumn, so it's the reliable internal label.
        nameCol <- if ("sedRates" %in% colnames(parts_df)) "sedRates" else
          if ("partition" %in% colnames(parts_df)) "partition" else NA_character_
        if (!is.na(nameCol)) {
          nms     <- trimws(as.character(parts_df[[nameCol]]))
          hts     <- suppressWarnings(as.numeric(parts_df[[zColNm]]))
          sitesAt <- as.character(parts_df[[siteColNm]])
          ok      <- !is.na(nms) & nzchar(nms) & nms != "unconformity-NA" &
                     !is.na(hts) & is.finite(hts) & !is.na(sitesAt) & sitesAt %in% siteList
          if (any(ok)) {
            nms     <- nms[ok]
            hts     <- hts[ok]
            sitesAt <- sitesAt[ok]
            # Convert each partition's own-site height to the reference scale.
            # refHeightsFromSourceSite is vectorised per source-site, so loop
            # over unique source sites for efficiency.
            refH <- numeric(length(hts))
            for (s in unique(sitesAt)) {
              sel <- sitesAt == s
              mapped <- refHeightsFromSourceSite(alignm, hts[sel], s)
              if (is.null(mapped) || length(mapped) != sum(sel)) mapped <- hts[sel]
              refH[sel] <- as.numeric(mapped)
            }
            bs <- data.frame(name = nms, refHeight = refH,
                             source = sitesAt, isUser = FALSE,
                             stringsAsFactors = FALSE)
            # Prefer reference-site rows for disambiguation if duplicate names
            bs$isRef <- bs$source == siteList[1L]
            bs <- bs[order(!bs$isRef), , drop = FALSE]   # ref rows first
            bs <- bs[!duplicated(bs$name), , drop = FALSE]
            bs$isRef <- NULL
            bs <- bs[order(bs$refHeight), , drop = FALSE]
            boundarySpec <- bs
          }
        }
      }

      # Append user-added partitions from the correlation panel (across sites)
      userParts <- tryCatch(reactiveValuesToList(userPartitionsPerSite),
                            error = function(e) list())
      if (length(userParts) > 0L && length(siteList) > 0L) {
        userRows <- do.call(rbind, lapply(names(userParts), function(site) {
          if (!site %in% siteList) return(NULL)
          df <- userParts[[site]]
          if (is.null(df) || !is.data.frame(df) || nrow(df) == 0L) return(NULL)
          if (!all(c("name", "height") %in% colnames(df))) return(NULL)
          heights <- suppressWarnings(as.numeric(df$height))
          ok <- !is.na(heights) & is.finite(heights) & nzchar(trimws(as.character(df$name)))
          if (!any(ok)) return(NULL)
          heights  <- heights[ok]
          namesCol <- trimws(as.character(df$name[ok]))
          refH <- refHeightsFromSourceSite(alignm, heights, site)
          if (is.null(refH) || length(refH) != length(heights)) return(NULL)
          data.frame(name = namesCol, refHeight = as.numeric(refH),
                     source = site, isUser = TRUE,
                     stringsAsFactors = FALSE)
        }))
        if (!is.null(userRows) && nrow(userRows) > 0L) {
          # Don't overwrite model boundaries with a user-added one of the same
          # name: keep the model's position.
          userRows <- userRows[!userRows$name %in% boundarySpec$name, , drop = FALSE]
          userRows <- userRows[!duplicated(userRows$name), , drop = FALSE]
          boundarySpec <- rbind(boundarySpec, userRows)
        }
      }

      if (nrow(boundarySpec) == 0L) {
        showNotification("No partition boundaries found to export.", type = "warning")
        write.csv(data.frame(Error = "No partition boundaries to export"),
                  file = file, row.names = FALSE)
        return()
      }

      # Feed the exact refHeights we built (Tops will compute per-site depths
      # for every one of them). We keep name<->refHeight alignment via row order.
      refHeights <- boundarySpec$refHeight

      # Get alignment selection
      alignmentSel <- input$posteriorAlignments
      clustUnique <- model_api$stratCluster()$clustUnique

      # Convert selected cluster IDs to integers
      selected_clusters <- tryCatch({
        if (is.null(alignmentSel) || length(alignmentSel) == 0) {
          # No selection: default to first 4 (or all if <= 4)
          if (length(clustUnique) <= 4) {
            as.integer(clustUnique)
          } else {
            as.integer(clustUnique[1:4])
          }
        } else {
          # Convert to integers
          as.integer(alignmentSel)
        }
      }, error = function(e) {
        return(integer(0))
      })

      # Filter out invalid cluster IDs
      valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
      valid_clusters <- valid_clusters[!is.na(valid_clusters)]

      # Limit to maximum of 4 alignments
      if (length(valid_clusters) == 0) {
        # No valid clusters: default to first 4 (or all if <= 4)
        if (length(clustUnique) <= 4) {
          alignmentSel <- as.integer(clustUnique)
        } else {
          alignmentSel <- as.integer(clustUnique[1:4])
        }
      } else if (length(valid_clusters) > 4) {
        # More than 4 selected: limit to first 4
        alignmentSel <- valid_clusters[1:4]
      } else {
        alignmentSel <- valid_clusters
      }

      # Get sites
      sites <- input$posteriorSites %||% "all"

      # Calculate quantiles based on confidence level
      confidenceLevel <- input$confidenceLevel %||% 80
      if (confidenceLevel == 0) {
        quantiles <- 0.5
      } else if (confidenceLevel >= 100) {
        quantiles <- c(0.0, 0.5, 1.0)
      } else {
        alpha <- (100 - confidenceLevel) / 100
        lowerQuantile <- alpha / 2
        upperQuantile <- 1 - (alpha / 2)
        quantiles <- c(lowerQuantile, 0.5, upperQuantile)
      }

      # Get stratCluster if needed (always needed when alignmentSel is a vector)
      stratCluster <- model_api$stratCluster()

      # Call Tops function and reshape to a tidy per-well-per-boundary CSV:
      #   wellsite, boundary, depth_median, depth_q<lower>, depth_q<upper>
      # Boundary names come from `boundarySpec` we built above (model +
      # user-added partitions across all sites). Each boundary appears once
      # per wellsite as its own row.
      tryCatch({
        tops_df <- StratoBayes::Tops(
          stratObject = alignm,
          refHeights = refHeights,
          alignment = alignmentSel,
          burnIn = input$posteriorBurn/100,
          stratCluster = stratCluster,
          quantiles = quantiles
        )

        # Match Tops' refHeight column back to our named boundary list.
        # Tops() coerces refHeights to dimnames (character) then back to
        # numeric when rebuilding the data.frame, so exact equality is safe,
        # but we use a tiny tolerance just in case.
        nameFor <- function(h) {
          if (!is.finite(h)) return(NA_character_)
          tol <- max(1e-8, 1e-6 * max(1, abs(h)))
          idx <- which(abs(boundarySpec$refHeight - h) < tol)
          if (length(idx) == 0L) return(NA_character_)
          boundarySpec$name[idx[1]]
        }

        # Identify median / lower / upper quantile columns. Tops() names them
        # "<pct>%" (e.g. "5%", "50%", "95%"); confidenceLevel = 0 gives only
        # a median column, and 100 gives min/median/max.
        knownMeta <- c("site", "refHeight", "mean", "sd")
        qCols     <- setdiff(colnames(tops_df), knownMeta)
        qNumeric  <- suppressWarnings(as.numeric(sub("%$", "", qCols)))
        hasQ      <- !is.na(qNumeric)
        qCols     <- qCols[hasQ]; qNumeric <- qNumeric[hasQ]
        medIdx    <- if (length(qNumeric)) which.min(abs(qNumeric - 50)) else integer(0)
        loIdx     <- if (length(qNumeric) > 1) which.min(qNumeric) else integer(0)
        hiIdx     <- if (length(qNumeric) > 1) which.max(qNumeric) else integer(0)
        if (length(loIdx) && length(medIdx) && loIdx == medIdx) loIdx <- integer(0)
        if (length(hiIdx) && length(medIdx) && hiIdx == medIdx) hiIdx <- integer(0)

        pctLabel <- function(p) {
          if (isTRUE(p == round(p))) sprintf("%02d", as.integer(round(p)))
          else sub("\\.?0+$", "", sprintf("%05.2f", p))
        }

        out <- data.frame(
          wellsite = as.character(tops_df$site),
          boundary = vapply(as.numeric(tops_df$refHeight), nameFor, character(1)),
          stringsAsFactors = FALSE
        )
        if (length(medIdx)) {
          out[["depth_median"]] <- as.numeric(tops_df[[qCols[medIdx]]])
        }
        if (length(loIdx)) {
          out[[paste0("depth_q", pctLabel(qNumeric[loIdx]))]] <-
            as.numeric(tops_df[[qCols[loIdx]]])
        }
        if (length(hiIdx)) {
          out[[paste0("depth_q", pctLabel(qNumeric[hiIdx]))]] <-
            as.numeric(tops_df[[qCols[hiIdx]]])
        }

        # For height-scale alignment, Tops() omits the reference site (the
        # identity transform). Add those rows back so the export covers ALL
        # wellsites. At the reference site the depth is exactly refHeight,
        # with no uncertainty, so all quantile columns are the same value.
        alignmentScale <- tryCatch(
          alignm$model$ind[["alignmentScale"]],
          error = function(e) NULL
        )
        if (identical(alignmentScale, "height") &&
            length(siteList) >= 1L && nrow(boundarySpec) > 0L) {
          refSiteName <- siteList[1L]
          refRows <- data.frame(
            wellsite = rep(refSiteName, nrow(boundarySpec)),
            boundary = boundarySpec$name,
            stringsAsFactors = FALSE
          )
          extraCols <- setdiff(colnames(out), c("wellsite", "boundary"))
          for (cn in extraCols) refRows[[cn]] <- boundarySpec$refHeight
          out <- rbind(out, refRows)
        }

        # Order rows by boundary (in the order we built them: model
        # boundaries in stratigraphic order first, then user-added ones);
        # within each boundary, order by wellsite.
        boundaryOrder <- match(out$boundary, boundarySpec$name)
        ord <- order(boundaryOrder, out$wellsite, na.last = TRUE)
        out <- out[ord, , drop = FALSE]
        rownames(out) <- NULL

        write.csv(out, file = file, row.names = FALSE)
      }, error = function(e) {
        showNotification(paste("Error generating well tops:", e$message), type = "error")
        write.csv(data.frame(Error = e$message), file = file, row.names = FALSE)
      })
    },
    contentType = "text/csv"
  )

  # sync plot types between load and view
  observeEvent(input$sigPlotType_load, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_view", selected = input$sigPlotType_load)
  })
  observeEvent(input$sigPlotType_view, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_load", selected = input$sigPlotType_view)
  })

  # Posterior controls
  # Get sites and signals from alignment result, NOT from current dataset
  output$posteriorSiteSel <- renderUI({
    req(model_api$alignment())
    alignm <- model_api$alignment()
    # Get sites from alignment result's data
    sites <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData")) {
      alignm$data$sites
    } else {
      # Fallback to current dataset if alignment doesn't have data
      if (data_api$signalValid()) {
        data_api$stratData()$sites
      } else {
        character(0)
      }
    }

    # Get current selection to preserve user choices
    currentSelection <- isolate(input$posteriorSites)

    # Default to first 4 sites (or all if 4 or fewer), unless user has already selected
    if (is.null(currentSelection) || length(currentSelection) == 0) {
      if (length(sites) <= 4) {
        selectedSites <- sites
      } else {
        selectedSites <- sites[1:4]
      }
    } else {
      # Preserve user's selection
      selectedSites <- intersect(currentSelection, sites)
      if (length(selectedSites) == 0 && length(sites) > 0) selectedSites <- sites[1]
    }

    checkboxGroupInput("posteriorSites", NULL,
                       choices = sites,
                       selected = selectedSites,
                       inline = TRUE
    )
  })
  # Helper that pulls the available signal names for the loaded posterior.
  # Falls back to the in-progress dataset when the alignment object doesn't
  # carry its own StratData (older saved sessions / partial loads).
  .signalNamesFromAlignment <- function() {
    alignm <- model_api$alignment()
    if (!is.null(alignm) && !is.null(alignm$data) &&
        inherits(alignm$data, "StratData") &&
        !is.null(alignm$data$signalAttr) &&
        !is.null(alignm$data$signalAttr$signalNames)) {
      return(alignm$data$signalAttr$signalNames)
    }
    if (data_api$signalValid()) {
      return(data_api$signalCols())
    }
    character(0)
  }

  # Signal pickers are split into two distinct renderUIs (multi vs. single)
  # backed by two distinct input IDs (posteriorSignals vs.
  # posteriorSignalCorr). Earlier this was a single renderUI that switched the
  # widget type based on input$plotTypeMain — but on the first load with
  # correlation as the default tab, the swap produced a mismatched DOM
  # (radiogroup wrapper around checkbox children) and Shiny's binding
  # reported a NULL value, leaving the plot blank and the settings
  # unresponsive until the user toggled tabs. Keeping each renderUI's widget
  # type stable removes that race entirely.
  output$posteriorSignalSel <- renderUI({
    req(model_api$alignment())
    sigCols <- .signalNamesFromAlignment()
    currentSel <- intersect(isolate(input$posteriorSignals) %||% character(0), sigCols)
    if (length(currentSel) == 0 && length(sigCols) > 0) currentSel <- sigCols[1]
    checkboxGroupInput("posteriorSignals", NULL,
                       choices  = sigCols,
                       selected = currentSel,
                       inline   = TRUE
    )
  })

  output$posteriorSignalSelCorr <- renderUI({
    req(model_api$alignment())
    sigCols <- .signalNamesFromAlignment()
    if (length(sigCols) == 0L) return(NULL)
    currentSel <- isolate(input$posteriorSignalCorr)
    if (is.null(currentSel) || length(currentSel) != 1L || !currentSel %in% sigCols) {
      currentSel <- sigCols[1]
    }
    radioButtons("posteriorSignalCorr", NULL,
                 choices  = setNames(sigCols, sigCols),
                 selected = currentSel,
                 inline   = TRUE
    )
  })

  # Track whether to show all alignments
  showAllAlignments <- reactiveVal(FALSE)

  # Reset show all when plot type changes (do NOT change alignment selection - avoids loops)
  observeEvent(input$plotTypeMain, {
    showAllAlignments(FALSE)
  }, ignoreInit = TRUE)

  # Handle show all alignments button
  observeEvent(input$showAllAlignments, {
    showAllAlignments(TRUE)
  })

  # Debounce alignment selection so plot doesn't re-run on every checkbox click (breaks reactive loops)
  alignmentSelectionDebounced <- debounce(reactive({
    input$posteriorAlignments
  }), millis = 500)

  currentStratCluster <- reactive({
    alignm <- model_api$alignment()
    req(alignm)
    burn <- input$posteriorBurn %||% 50
    burn <- suppressWarnings(as.numeric(burn))
    if (is.na(burn) || burn < 0 || burn > 99) burn <- 50
    tryCatch({
      Cluster(alignm, burnIn = burn / 100)
    }, error = function(e) {
      model_api$stratCluster()
    })
  })

  output$posteriorAlnSel <- renderUI({
    req(currentStratCluster())
    cl <- currentStratCluster()$clustUnique
    nClust <- length(cl)
    cl_char <- as.character(cl)

    # Determine which clusters to show (for Show All / hide beyond 4)
    if (showAllAlignments() || nClust <= 4) {
      clustersToShow <- cl
    } else {
      clustersToShow <- cl[1:4]
    }

    # CRITICAL: Use isolate() so we do NOT create a reactive dependency on these inputs.
    # Otherwise: user clicks -> renderUI runs -> selection used -> widget updates -> renderUI runs again -> loop.
    currentSelection <- isolate(input$posteriorAlignments)
    plotType <- isolate(input$plotTypeMain) %||% "alignment"

    # Restrict to valid cluster IDs only (avoids Shiny errors from selected not in choices)
    currentSelection <- intersect(as.character(currentSelection %||% character(0)), cl_char)

    # Set default ONLY when nothing selected; otherwise keep user's selection as-is (no auto-modify).
    if (length(currentSelection) == 0) {
      if (plotType == "correlation") {
        selectedClusters <- cl_char
      } else {
        selectedClusters <- if (length(cl) <= 4) cl_char else as.character(cl[1:4])
      }
    } else {
      selectedClusters <- currentSelection
    }

    tagList(
      tags$div(
        id = "alignmentSelectorContainer",
        class = "strat-checklist",
        style = "margin-bottom: 10px;",
        checkboxGroupInput("posteriorAlignments", NULL,
                         choices  = setNames(cl_char, cl_char),
                         selected = selectedClusters,
                         inline   = FALSE
        )
      ),
      if (nClust > 4 && !showAllAlignments()) {
        tags$script(HTML(paste0("
          $(document).ready(function() {
            setTimeout(function() {
              var container = $('#alignmentSelectorContainer');
              var checkboxes = container.find('input[type=\"checkbox\"]');
              var clusterValues = ", jsonlite::toJSON(cl_char), ";
              checkboxes.each(function(index) {
                var value = $(this).val();
                var clusterIndex = clusterValues.indexOf(value);
                if (clusterIndex >= 4) {
                  $(this).closest('div.checkbox').hide();
                }
              });
            }, 100);
          });
        ")))
      } else {
        tags$script(HTML("
          $(document).ready(function() {
            setTimeout(function() {
              $('#alignmentSelectorContainer').find('div.checkbox').show();
            }, 100);
          });
        "))
      },
      tags$div(
        style = "display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;",
        actionButton("selectAllAlignments", "Select All",
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        actionButton("deselectAllAlignments", "Deselect All (keep 1)",
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        if (nClust > 4 && !showAllAlignments()) {
          actionButton("showAllAlignments", "Show All Alignments",
                      class = "btn-sm btn-info",
                      style = "font-size: 0.85em; padding: 2px 8px;")
        } else {
          NULL
        }
      )
    )
  })

  output$alignmentSummarySidebar <- renderUI({
    req(currentStratCluster())
    cl <- currentStratCluster()
    if (is.null(cl$clustUnique) || length(cl$clustUnique) == 0) return(NULL)

    tags$div(
      class = "sb-setting-block",
      style = "min-width: 0; width: 100%; white-space: normal;",
      tags$strong("Alignment Summary", style = "display:block; margin-bottom:6px;"),
      tags$p(
        "These percentages show how often each alignment appears in the sampled solutions. Higher percentages mean the model found that alignment more frequently.",
        style = "font-size: 0.85em; color: #555; margin-bottom: 8px;"
      ),
      tableOutput("alignmentSummaryTable")
    )
  })

  output$alignmentSummaryTable <- renderTable({
    req(currentStratCluster())
    cl <- currentStratCluster()
    alnIds <- as.integer(cl$clustUnique)
    counts <- tabulate(match(as.integer(cl$cluster), alnIds), nbins = length(alnIds))
    total <- sum(counts)
    req(length(alnIds) > 0, total > 0)
    props <- counts / total

    out <- data.frame(
      Alignment = ifelse(alnIds == 0, "Remaining samples", paste0("Alignment ", alnIds)),
      `Share of samples` = paste0(sprintf("%.1f", round(props * 100, 1)), "%"),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
    out[order(alnIds == 0, alnIds), , drop = FALSE]
  }, striped = TRUE, hover = TRUE, spacing = "xs", width = "100%")

  # Reactive: selected trace plot parameter (so plot clearly depends on it)
  tracePlotParameter <- reactive({
    p <- input$tracePlotParameter
    if (is.null(p) || !nzchar(trimws(p))) return("log posterior")
    as.character(p)
  })

  # Format parameter names for display (aligned with Prior tab: alpha, gamma/sed rate, zeta, delta)
  formatTraceParamName <- function(name) {
    if (grepl("^gammaLog_", name, ignore.case = TRUE)) {
      sub("^gammaLog_", "relative sed. rate (\u03bd) ", name, ignore.case = TRUE)
    } else if (grepl("^alpha_", name, ignore.case = TRUE)) {
      sub("^alpha_", "correlation anchor (\u03b1) ", name, ignore.case = TRUE)
    } else if (grepl("^gamma_", name, ignore.case = TRUE)) {
      sub("^gamma_", "sed. rate ", name, ignore.case = TRUE)
    } else if (grepl("^zetaLog_", name, ignore.case = TRUE)) {
      sub("^zetaLog_", "sed. rate multiplier (\u03b6) ", name, ignore.case = TRUE)
    } else if (grepl("^zeta_", name, ignore.case = TRUE)) {
      sub("^zeta_", "sed. rate multiplier ", name, ignore.case = TRUE)
    } else if (grepl("^(delta|gap)_", name, ignore.case = TRUE)) {
      sub("^(delta|gap)_", "unconformity ", name, ignore.case = TRUE)
    } else {
      name
    }
  }

  # Trace plot: single-parameter dropdown (log posterior / log prior / log likelihood + model params)
  # Choices use display names (labels) with values = internal names for TracePlot; match selected by value.
  output$tracePlotParameterSel <- renderUI({
    choices <- c(
      "log posterior"  = "log posterior",
      "log prior"      = "log prior",
      "log likelihood" = "log likelihood"
    )
    alignm <- model_api$alignment()
    if (!is.null(alignm) && inherits(alignm, "StratPosterior")) {
      pnames <- alignm[[c("model", "parametersNames")]]
      if (!is.null(pnames) && length(pnames) > 0L) {
        displayNames <- vapply(pnames, formatTraceParamName, character(1))
        choices <- c(choices, setNames(pnames, displayNames))
      }
    }
    choiceValues <- unname(choices)
    current <- isolate(input$tracePlotParameter)
    selected <- if (!is.null(current) && current %in% choiceValues) current else "log posterior"
    selectInput(
      "tracePlotParameter",
      NULL,
      choices  = choices,
      selected = selected,
      width    = "100%"
    )
  })

  # Handle select all alignments (ignoreInit prevents triggering on session init)
  observeEvent(input$selectAllAlignments, {
    req(currentStratCluster())
    cl <- currentStratCluster()$clustUnique
    updateCheckboxGroupInput(session, "posteriorAlignments",
                            selected = as.character(cl))
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Handle deselect all alignments (keep only alignment 1)
  observeEvent(input$deselectAllAlignments, {
    req(currentStratCluster())
    cl <- currentStratCluster()$clustUnique
    if (1 %in% cl) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = "1")
    } else if (length(cl) > 0) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = as.character(cl[1]))
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  observeEvent(input$posteriorSignals, {
    if (!identical(input$plotTypeMain, "alignment")) return()
    if (length(input$posteriorSignals %||% character(0)) <= 1L) return()
    selected <- input$posteriorAlignments %||% character(0)
    if (length(selected) > 1L) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                               selected = selected[1])
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  observeEvent(input$posteriorAlignments, {
    if (!identical(input$plotTypeMain, "alignment")) return()
    if (length(input$posteriorSignals %||% character(0)) <= 1L) return()
    selected <- input$posteriorAlignments %||% character(0)
    if (length(selected) > 1L) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                               selected = selected[1])
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  settingsDetails <- function(title, ..., open = FALSE, wide = FALSE) {
    attrs <- list(
      class = paste(
        "sb-setting-details",
        if (isTRUE(wide)) "sb-setting-details-wide" else ""
      )
    )
    if (isTRUE(open)) attrs$open <- "open"
    do.call(
      tags$details,
      c(attrs, list(
        tags$summary(
          title,
          onclick = "setTimeout(() => { const d = this.parentElement; if (d.open) $(d).siblings('details.sb-setting-details').prop('open', false); }, 0);"
        ),
        tags$div(class = "sb-setting-details-body", ...)
      ))
    )
  }

  .currentInput <- function(id, default) {
    isolate({
      val <- input[[id]]
      if (is.null(val) || length(val) == 0L || anyNA(val)) default else val
    })
  }

  .currentNumericInput <- function(id, default, min = -Inf, max = Inf) {
    val <- suppressWarnings(as.numeric(.currentInput(id, default)))
    if (length(val) != 1L || !is.finite(val) || val < min || val > max) default else val
  }

  .paletteChoices <- c(
    "Dark 3", "Viridis", "Plasma", "Inferno", "Mako",
    "Set 2", "Set 3", "Zissou 1", "Cividis", "Batlow"
  )
  .paletteChoices <- intersect(.paletteChoices, grDevices::hcl.pals())
  if (length(.paletteChoices) == 0L) .paletteChoices <- "Dark 3"

  palettePreviewUI <- function(palette, default, n = 7) {
    selected <- as.character(palette %||% default)
    if (!selected %in% .paletteChoices) selected <- default
    cols <- tryCatch(
      grDevices::hcl.colors(n, palette = selected),
      error = function(e) grDevices::hcl.colors(n, palette = default)
    )
    tags$div(
      style = "display:flex; gap:2px; height:14px; width:180px; margin-top:4px; border:1px solid #ddd;",
      lapply(cols, function(col) {
        tags$span(style = sprintf("flex:1 1 0; background:%s;", col))
      })
    )
  }

  output$posteriorSignalColourScalePreview <- renderUI({
    palettePreviewUI(input$posteriorSignalColourScale, "Dark 3")
  })
  output$correlationSignalColourScalePreview <- renderUI({
    palettePreviewUI(input$correlationSignalColourScale, "Dark 3")
  })
  output$correlationTopsColourScalePreview <- renderUI({
    palettePreviewUI(input$correlationTopsColourScale, "Viridis")
  })

  paletteControl <- function(inputId, label, default, n = 7) {
    selected <- as.character(.currentInput(inputId, default))
    if (!selected %in% .paletteChoices) selected <- default
    tagList(
      selectInput(inputId, label, choices = .paletteChoices,
                  selected = selected, width = "180px"),
      uiOutput(paste0(inputId, "Preview"))
    )
  }

  styleSizeControls <- function() {
    tags$div(
      class = "sb-setting-inline",
      radioButtons("posteriorStyle", NULL,
                   c("Pts" = "p", "Lines" = "l", "Both" = "o"),
                   inline = TRUE, selected = .currentInput("posteriorStyle", "l")),
      sliderInput("posteriorCex", "Point size", min = .5, max = 5,
                  step = .1, value = .currentNumericInput("posteriorCex", 1, .5, 5), width = "110px"),
      sliderInput("posteriorLwd", "Line width", min = .5, max = 5,
                  step = .5, value = .currentNumericInput("posteriorLwd", 2, .5, 5), width = "110px"),
      sliderInput("sitePanelWidth", "Site plot width", min = 100, max = 400,
                  step = 25, value = .currentNumericInput("sitePanelWidth", 200, 100, 400), width = "150px"),
      sliderInput("resultPlotScale", "Text/symbol scale", min = .8, max = 2,
                  step = .1, value = .currentNumericInput("resultPlotScale", 1, .8, 2), width = "150px")
    )
  }

  burnInControl <- function() {
    tags$div(
      tags$div("Discard early chain samples (%)",
               style = "font-weight:600; margin-bottom:4px;"),
      numericInput("posteriorBurn", NULL,
                   .currentNumericInput("posteriorBurn", 50, 0, 99),
                   0, 99, step = 1, width = "110px")
    )
  }

  correlationLineControls <- function() {
    tags$div(
      class = "sb-setting-inline",
      paletteControl("correlationSignalColourScale", "Signal colours", "Dark 3"),
      paletteControl("correlationTopsColourScale", "Correlation line colours", "Viridis")
    )
  }

  # Main plot
  output$plotOptionsUI <- renderUI({
    req(input$plotTypeMain)
    # Gate on the alignment too: without this, plotOptionsUI renders at app boot
    # (suspendWhenHidden = FALSE forces an early evaluation), creating widgets
    # before Shiny's binding pass has settled. The widgets end up in the DOM
    # without live input bindings — clicking them does not invalidate the
    # plot trigger, and refresh_posterior_controls() can prime e.g.
    # input$posteriorSignals before the matching widget exists. Switching tabs
    # forces a re-render which unbinds/rebinds and hides the symptom. By
    # waiting for the alignment, the first (and only-needed) render of this
    # UI happens when the inner uiOutputs are also ready to populate.
    req(model_api$alignment())
    switch(input$plotTypeMain,
           "alignment" = div(class = "sb-settings-row",
                             settingsDetails("Sites", open = FALSE,
                                             tags$div(class = "strat-checklist", uiOutput("posteriorSiteSel"))),
                             settingsDetails("Signals", open = FALSE,
                                             tags$div(class = "strat-checklist", uiOutput("posteriorSignalSel"))),
                             settingsDetails("Alignments", open = FALSE, wide = TRUE,
                                             tags$div(class = "strat-checklist", uiOutput("posteriorAlnSel"))),
                             settingsDetails("Quantile & Burn-in", open = FALSE,
                                             tags$div(class = "sb-setting-inline",
                                               tags$div(tags$strong("q"),
                                                        numericInput("posteriorQuantile", NULL,
                                                                     .currentNumericInput("posteriorQuantile", .5, 0, 1),
                                                                     0, 1, step = .01, width = "100px")),
                                               burnInControl()
                                             )),
                             settingsDetails("Style", open = FALSE, wide = TRUE,
                                              styleSizeControls(),
                                             paletteControl("posteriorSignalColourScale", "Plot colours", "Dark 3"),
                                             radioButtons("alignmentColourBy", "Colour by",
                                                          c("Site" = "site", "Partition" = "partition"),
                                                          inline = TRUE,
                                                          selected = .currentInput("alignmentColourBy", "site")))
           ),
           "traceplot" = div(class = "sb-traceplot-options",
                             style = "position: relative; z-index: 1050; overflow: visible;",
                             div(class = "sb-settings-row",
                               settingsDetails("Parameter", open = FALSE, wide = TRUE,
                                               uiOutput("tracePlotParameterSel")),
                               settingsDetails("Alignments", open = FALSE, wide = TRUE,
                                               tags$div(class = "strat-checklist", uiOutput("posteriorAlnSel"))),
                               settingsDetails("Burn-in", open = FALSE,
                                               burnInControl()),
                               settingsDetails("Style", open = FALSE, wide = TRUE,
                                               styleSizeControls(),
                                               paletteControl("posteriorSignalColourScale", "Trace colours", "Dark 3"))
                             )
           ),
           "correlation" = div(class = "sb-settings-row",
                               settingsDetails("Sites", open = FALSE,
                                               uiOutput("posteriorSiteSel")),
                               settingsDetails("Signal", open = FALSE,
                                               uiOutput("posteriorSignalSelCorr")),
                               settingsDetails("Alignments", open = FALSE, wide = TRUE,
                                               tags$div(class = "strat-checklist", uiOutput("posteriorAlnSel"))),
                               settingsDetails("Depth Display", open = FALSE,
                                               checkboxInput("correlationSameYlim",
                                                             "Same depth/height range",
                                                             value = isTRUE(.currentInput("correlationSameYlim", FALSE)),
                                                             width = "180px")),
                               settingsDetails("Colours", open = FALSE, wide = TRUE,
                                               correlationLineControls()),
                               settingsDetails("Burn-in", open = FALSE,
                                               burnInControl()),
                               settingsDetails("Style", open = FALSE, wide = TRUE,
                                               styleSizeControls())
           )
    )
  })

  # Cached plots for quick tab switching. Cache keys include each tab's plot
  # inputs so changing a setting redraws, while returning to a tab can replay
  # the last identical plot instead of recomputing it.
  mainPlotCache <- reactiveValues()

  .plotCacheKey <- function(tab, state = NULL) {
    alignm <- if (!is.null(state$model)) state$model else model_api$alignment()
    modelTag <- tryCatch({
      nm <- alignm$modelName
      if (is.null(nm) || !nzchar(as.character(nm))) paste0("nsamples:", alignm$nSamples %||% NA_integer_) else as.character(nm)
    }, error = function(e) "unknown-model")

    parts <- list(
      model = modelTag,
      tab = tab
    )

    if (identical(tab, "alignment")) {
      parts <- c(parts, list(
        alignments = state$alignments,
        sites = state$sites,
        signals = state$signals,
        style = state$style,
        cex = state$cex,
        lwd = state$lwd,
        panelWidth = state$panelWidth,
        plotScale = state$plotScale,
        quantile = state$quantile,
        burn = state$burn,
        colourBy = state$colourBy,
        colourScale = state$colourScale
      ))
    } else if (identical(tab, "traceplot")) {
      parts <- c(parts, list(
        alignments = state$alignments,
        style = state$style,
        cex = state$cex,
        lwd = state$lwd,
        panelWidth = state$panelWidth,
        plotScale = state$plotScale,
        burn = state$burn,
        parameter = state$parameter,
        colourScale = state$colourScale
      ))
    } else {
      parts <- c(parts, list(
        alignments = state$alignments,
        sites = state$sites,
        signals = state$signals,
        style = state$style,
        cex = state$cex,
        lwd = state$lwd,
        panelWidth = state$panelWidth,
        plotScale = state$plotScale,
        burn = state$burn,
        refHeights = state$refHeights,
        sourceSite = state$sourceSite,
        confidence = state$confidence,
        sameYlim = state$sameYlim,
        signalColourScale = state$signalColourScale,
        topsColourScale = state$topsColourScale,
        clearRefHeights = input$clearRefHeights,
        partitions = state$partitions
      ))
    }

    jsonlite::toJSON(parts, auto_unbox = TRUE, null = "null", digits = NA)
  }

  .drawMainPlot <- function(plotType, state = list()) {
    # Only run when these exist (prevents the getDims crash inside your plotting fns)
    req(plotType)
    req(model_api$alignment())
    req(currentStratCluster())

    alignm <- state$model %||% model_api$alignment()
    clust  <- state$cluster %||% currentStratCluster()
    .plotScale <- state$plotScale %||% input$resultPlotScale %||% 1
    .plotScale <- suppressWarnings(as.numeric(.plotScale))
    if (is.na(.plotScale) || .plotScale < 0.8 || .plotScale > 2) .plotScale <- 1
    .cex <- (state$cex %||% input$posteriorCex %||% 1) * .plotScale
    .lwd <- (state$lwd %||% input$posteriorLwd %||% 2) * .plotScale
    .signalColourScale <- if (identical(plotType, "correlation")) {
      state$signalColourScale %||% input$correlationSignalColourScale %||% "Dark 3"
    } else {
      state$colourScale %||% input$posteriorSignalColourScale %||% "Dark 3"
    }

    # For the correlation tab: auto-colour by partition when the StratData has
    # real partitions (user specifically asked for this behaviour).
    # For the alignment tab: honour the "Colour by" toggle (default "site",
    # optional "partition") so the user decides.
    .hasPartitions <- tryCatch({
      up <- alignm$data[[c("partsAttr", "uniqueParts")]]
      !is.null(up) && length(up) > 1L
    }, error = function(e) FALSE)
    .colourByCorr <- if (isTRUE(.hasPartitions)) "partition" else "site"
    .colourByAlign <- {
      choice <- state$colourBy %||% input$alignmentColourBy %||% "site"
      if (identical(choice, "partition") && !isTRUE(.hasPartitions)) "site" else choice
    }

    .cacheKey <- .plotCacheKey(plotType, state)
    # The correlation tab uses multi-panel base-R layouts (par(mfrow=...)) and
    # an overlay coordinate system in TopsPlot. recordPlot()/replayPlot() does
    # not capture those reliably, so a cached replay can show a stale plot
    # even when settings have changed. Always redraw for correlation.
    if (!identical(plotType, "correlation")) {
      .cachedPlot <- isolate(mainPlotCache[[.cacheKey]])
      if (!is.null(.cachedPlot)) {
        replayed <- tryCatch({
          replayPlot(.cachedPlot)
          TRUE
        }, error = function(e) FALSE)
        if (isTRUE(replayed)) return(invisible(NULL))
      }
    }

    switch(plotType,
           alignment = {
             alignmentSel <- state$alignments %||% alignmentSelectionDebounced()
             clustUnique <- clust$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]
             multiSignalAlignment <- length(state$signals %||% input$posteriorSignals %||% 1L) > 1L

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (isTRUE(multiSignalAlignment)) {
               # plot.StratPosterior lays out multiple signals or multiple
               # alignments cleanly, but not both at once.
               alignmentSel <- valid_clusters[1]
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- state$sites   %||% input$posteriorSites   %||% "all"
             signals <- state$signals %||% input$posteriorSignals %||% 1
             style   <- state$style   %||% input$posteriorStyle   %||% "p"

             # Validate quantile
             quantile_val <- state$quantile %||% input$posteriorQuantile
             if (is.null(quantile_val) || is.na(quantile_val) ||
                 !is.numeric(quantile_val) || quantile_val < 0 || quantile_val > 1) {
               quantile_val <- 0.5  # Default to median
             }

             .plotArgs <- list(
               x             = alignm,
               alignment     = alignmentSel,
               stratCluster  = clust,
               sites         = sites,
               signal        = signals,
               separateSites = TRUE,
               quantile      = quantile_val,
               burnIn        = (state$burn %||% input$posteriorBurn) / 100,
               type          = style,
               cex           = .cex,
               lwd           = .lwd,
               colourBy      = .colourByAlign,
               colourScale   = .signalColourScale,
               cex.lab       = 1.4 * .plotScale,
               cex.axis      = 1.3 * .plotScale,
               cex.main      = 1.4 * .plotScale
             )
             do.call(plot, .plotArgs)
           },
           traceplot = {
             alignmentSel <- state$alignments %||% alignmentSelectionDebounced()
             clustUnique <- clust$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             style <- state$style %||% input$posteriorStyle %||% "l"
             param <- state$parameter %||% tracePlotParameter()
             # Y-axis label: formatted in Shiny (same as dropdown); add "log " for probability terms
             probTerms <- c("posterior", "prior", "likelihood", "prior_parameters", "prior_overlap", "likelihood_spline", "likelihood_ties")
             ylabTrace <- if (param %in% probTerms) paste("log", param) else formatTraceParamName(param)
             .tpArgs <- list(
               alignm,
               alignment  = alignmentSel,
               parameters = param,
               burnIn     = (state$burn %||% input$posteriorBurn) / 100,
               type       = style,
               cex        = .cex,
               lwd        = .lwd,
               colourScale = .signalColourScale,
               ylab       = ylabTrace,
               cex.lab    = 1.4 * .plotScale,
               cex.axis   = 1.3 * .plotScale,
               cex.main   = 1.4 * .plotScale
             )
             do.call(TracePlot, .tpArgs)
           },
           correlation = {
             alignmentSel <- state$alignments %||% alignmentSelectionDebounced()
             clustUnique <- clust$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- state$sites %||% input$posteriorSites %||% "all"
             # For correlation plot, ensure only one signal is used
             # Get signal columns from alignment result, NOT from current dataset
             alignm <- model_api$alignment()
             sigCols <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData") &&
                            !is.null(alignm$data$signalAttr) && !is.null(alignm$data$signalAttr$signalNames)) {
               alignm$data$signalAttr$signalNames
             } else {
               # Fallback to current dataset if alignment doesn't have data
               if (data_api$signalValid()) {
                 data_api$signalCols()
               } else {
                 character(0)
               }
             }

             # The correlation tab uses a dedicated single-select radio
             # (posteriorSignalCorr); fall back to posteriorSignals only if a
             # legacy caller passed state$signals from there.
             signalSelection <- state$signals %||% input$posteriorSignalCorr %||% input$posteriorSignals
             if (is.null(signalSelection)) {
               signals <- 1
             } else if (is.character(signalSelection) && length(signalSelection) > 0) {
               # If it's a character vector (from radioButtons), convert to index
               sigName <- signalSelection[1]  # Take first one
               if (sigName %in% sigCols) {
                 signals <- match(sigName, sigCols)
               } else {
                 signals <- 1
               }
             } else if (is.numeric(signalSelection)) {
               # If it's numeric, use first one
               signals <- if (length(signalSelection) > 1) {
                 signalSelection[1]
               } else {
                 signalSelection
               }
             } else {
               signals <- 1
             }
             style   <- state$style %||% input$posteriorStyle %||% "p"
            sharedYlim <- NULL
            if (isTRUE(state$sameYlim %||% input$correlationSameYlim)) {
              sharedYlim <- tryCatch({
                dataObj <- alignm$data
                allSites <- dataObj$sites
                plotSitesForY <- if (identical(sites, "all")) {
                  seq_along(allSites)
                } else if (is.numeric(sites)) {
                  as.integer(sites)
                } else {
                  match(as.character(sites), as.character(allSites))
                }
                plotSitesForY <- plotSitesForY[!is.na(plotSitesForY) &
                                                 plotSitesForY >= 1 &
                                                 plotSitesForY <= length(allSites)]
                if (length(plotSitesForY) == 0) plotSitesForY <- seq_along(allSites)
                yvals <- unlist(lapply(plotSitesForY, function(s) {
                  SignalLookUp(dataObj, "height", s, signals, FALSE)
                }), use.names = FALSE)
                rng <- range(yvals[is.finite(yvals)], na.rm = TRUE)
                if (all(is.finite(rng)) && length(rng) == 2) {
                  rng
                } else {
                  NULL
                }
              }, error = function(e) NULL)
            }

             # Parse and clamp heights at selected source site before passing to TopsPlot.
             sourceSite     <- state$sourceSite %||% input$correlationSourceSite %||% alignm$data$sites[1]
             refHeights     <- parseRefHeightsInput(state$refHeights %||% input$refHeights)
             refHeightsSite <- NULL
             if (!is.null(refHeights)) {
               refHeights <- clampRefHeightsToSite(refHeights, alignm, sourceSite)
               # Drop any values that are still NA / non-finite after clamping
               # and any that remain outside the source-site's valid range.
               refHeights <- refHeights[is.finite(refHeights)]
               siteBounds <- tryCatch({
                 data <- alignm$data
                 siteIdx <- match(as.character(sourceSite), as.character(data$sites))
                 if (is.na(siteIdx)) NULL else {
                   bl <- data[[c("partsAttr", "BoundLow")]][, siteIdx]
                   bh <- data[[c("partsAttr", "Bound")]][, siteIdx]
                   bl <- bl[is.finite(bl)]; bh <- bh[is.finite(bh)]
                   if (length(bl) == 0 || length(bh) == 0) NULL
                   else c(min(bl, na.rm = TRUE), max(bh, na.rm = TRUE))
                 }
               }, error = function(e) NULL)
               if (!is.null(siteBounds) && length(refHeights) > 0) {
                 tol <- max(abs(diff(siteBounds)) * 1e-6, 1e-8, na.rm = TRUE)
                 refHeights <- refHeights[refHeights >= siteBounds[1] - tol &
                                          refHeights <= siteBounds[2] + tol]
               }
               if (length(refHeights) == 0) {
                 refHeights     <- NULL
                 refHeightsSite <- NULL
               } else {
                 refHeightsSite <- sourceSite
               }
             }

             # Calculate quantiles based on confidence level
             confidenceLevel <- state$confidence %||% input$confidenceLevel %||% 80
             if (confidenceLevel == 0) {
               # 0% confidence - just median
               quantiles <- 0.5
             } else if (confidenceLevel >= 100) {
               # 100% confidence - full range
               quantiles <- c(0.0, 0.5, 1.0)
             } else {
               # Calculate symmetric quantiles around median
               alpha <- (100 - confidenceLevel) / 100
               lowerQuantile <- alpha / 2
               upperQuantile <- 1 - (alpha / 2)
               quantiles <- c(lowerQuantile, 0.5, upperQuantile)
             }

            # If refHeights is empty (Clear pressed or all invalid), draw the
            # per-site signal panels only — no correlation lines.
            if (is.null(refHeights) || length(refHeights) == 0) {
              tryCatch({
                dataObj   <- alignm$data
                allSites  <- dataObj$sites
                plotSites <- if (identical(sites, "all")) {
                               seq_along(allSites)
                             } else if (is.numeric(sites)) {
                               as.integer(sites)
                             } else {
                               match(as.character(sites), as.character(allSites))
                             }
                plotSites <- plotSites[!is.na(plotSites) &
                                         plotSites >= 1 &
                                         plotSites <= length(allSites)]
                if (length(plotSites) == 0) plotSites <- seq_along(allSites)
                opar <- par(no.readonly = TRUE)
                on.exit(try(par(opar), silent = TRUE))
                par(mfrow = c(1, length(plotSites)),
                    las = 1, mar = c(4.6, 4.6, 1.6, .6))
                ylabZ <- if (identical(dataObj[["zScale"]], "depth")) "depth" else "height"
                for (s in plotSites) {
                  .pargs <- list(
                    x           = dataObj,
                    sites       = s,
                    signal      = signals,
                    overridePar = FALSE,
                    type        = if (identical(style, "p")) "p" else "l",
                    cex         = .cex,
                    lwd         = .lwd,
                    colourBy    = .colourByCorr,
                    colourScale = .signalColourScale,
                    ylab        = ylabZ,
                    cex.lab     = 1.4 * .plotScale,
                    cex.axis    = 1.3 * .plotScale,
                    cex.main    = 1.4 * .plotScale
                  )
                  if (!is.null(sharedYlim)) .pargs$ylim <- sharedYlim
                  do.call(plot, .pargs)
                }
              }, error = function(e) {
                plot(1, 1, type = "n", xlab = "", ylab = "",
                     main = "Signal plot not available")
                text(1, 1, paste("Error:", e$message), cex = 0.8, col = "red")
              })
            } else {
              tryCatch({
                # Correlation plots use an overlay coordinate system for the
                # connecting lines, so brush zoom is intentionally disabled on
                # this tab. Shared y-limits are still passed to the site panels.
                .topsArgs <- list(
                  stratPosterior = alignm,
                  alignment      = alignmentSel,
                  sites          = sites,
                  signal         = signals,
                  burnIn         = (state$burn %||% input$posteriorBurn) / 100,
                  type           = style,
                  cex            = .cex,
                  lwd            = .lwd,
                  refHeights     = refHeights,
                  refHeightsSite = refHeightsSite,
                  colourBy       = .colourByCorr,
                  colourScale    = .signalColourScale,
                  topsColourScale = state$topsColourScale %||% input$correlationTopsColourScale %||% "Viridis",
                  topsLwd        = .lwd,
                  quantiles      = quantiles,
                  cex.lab        = 1.4 * .plotScale,
                  cex.axis       = 1.3 * .plotScale,
                  cex.main       = 1.4 * .plotScale
                )
                if (!is.null(sharedYlim)) .topsArgs$ylim <- sharedYlim
                do.call(TopsPlot, .topsArgs)
              }, error = function(e) {
                # Graceful fallback: show the signal panels without correlation
                # lines so the user still gets a usable plot rather than an error.
                tryCatch({
                  dataObj   <- alignm$data
                  allSites  <- dataObj$sites
                  plotSites <- if (identical(sites, "all")) {
                                 seq_along(allSites)
                               } else if (is.numeric(sites)) {
                                 as.integer(sites)
                               } else {
                                 match(as.character(sites), as.character(allSites))
                               }
                  plotSites <- plotSites[!is.na(plotSites) &
                                           plotSites >= 1 &
                                           plotSites <= length(allSites)]
                  if (length(plotSites) == 0) plotSites <- seq_along(allSites)
                  opar <- par(no.readonly = TRUE)
                  on.exit(try(par(opar), silent = TRUE))
                  par(mfrow = c(1, length(plotSites)),
                      las = 1, mar = c(4.6, 4.6, 1.6, .6))
                  ylabZ <- if (identical(dataObj[["zScale"]], "depth")) "depth" else "height"
                  for (s in plotSites) {
                    .pargs <- list(
                      x           = dataObj,
                      sites       = s,
                      signal      = signals,
                      overridePar = FALSE,
                      type        = if (identical(style, "p")) "p" else "l",
                      cex         = .cex,
                      lwd         = .lwd,
                      colourBy    = .colourByCorr,
                      colourScale = .signalColourScale,
                      ylab        = ylabZ,
                      cex.lab     = 1.4 * .plotScale,
                      cex.axis    = 1.3 * .plotScale,
                      cex.main    = 1.4 * .plotScale
                    )
                    if (!is.null(sharedYlim)) .pargs$ylim <- sharedYlim
                    do.call(plot, .pargs)
                  }
                }, error = function(e2) {
                  plot(1, 1, type = "n", xlab = "", ylab = "",
                       main = "Tops plot not available",
                       sub = "Model may still be running or data not fully loaded")
                  text(1, 1, paste("Error:", e$message), cex = 0.8, col = "red")
                })
              })
            }
           }
    )

    # Cache rendered plot so tab switches can replay without recomputing.
    # Skip caching for the correlation tab — see note at the cache-read site.
    if (!identical(plotType, "correlation")) {
      isolate({
        mainPlotCache[[.cacheKey]] <- recordPlot()
      })
    }
  }

  .validAlignmentSelection <- function() {
    cl <- tryCatch(currentStratCluster()$clustUnique, error = function(e) NULL)
    if (is.null(cl) || length(cl) == 0) return(integer(0))
    selected <- alignmentSelectionDebounced()
    selected <- suppressWarnings(as.integer(selected))
    selected <- selected[selected %in% cl]
    selected <- selected[!is.na(selected)]
    if (length(selected) == 0 || setequal(selected, cl)) {
      selected <- if (length(cl) <= 4) cl else cl[1:4]
    }
    selected[seq_len(min(length(selected), 4L))]
  }

  .plotPanelCount <- function(tab) {
    alignm <- model_api$alignment()
    dataObj <- tryCatch(alignm$data, error = function(e) NULL)
    allSites <- tryCatch(dataObj$sites, error = function(e) character(0))
    selectedSites <- input$posteriorSites
    nSites <- if (is.null(selectedSites) || identical(selectedSites, "all")) {
      length(allSites)
    } else {
      length(selectedSites)
    }
    nSites <- max(1L, nSites)

    nAlignments <- max(1L, length(.validAlignmentSelection()))
    nSignals <- max(1L, length(input$posteriorSignals %||% 1L))

    switch(tab,
           alignment = if (nSignals > 1L) nSignals else if (nAlignments > 1L) nAlignments else nSites,
           traceplot = nAlignments,
           correlation = nSites,
           1L)
  }

  .mainPlotWidth <- function(tab) {
    panelCount <- .plotPanelCount(tab)
    panelWidth <- input$sitePanelWidth %||% 200L
    panelWidth <- suppressWarnings(as.integer(panelWidth))
    if (is.na(panelWidth) || panelWidth < 100L || panelWidth > 400L) panelWidth <- 200L
    if (identical(tab, "traceplot")) {
      max(700L, as.integer(0.85 * panelWidth) * panelCount + 180L)
    } else {
      max(700L, panelWidth * panelCount + 180L)
    }
  }

  alignmentPlotTrigger <- debounce(reactive({
    list(
      model = model_api$alignment(),
      cluster = currentStratCluster(),
      alignments = alignmentSelectionDebounced(),
      sites = input$posteriorSites,
      signals = input$posteriorSignals,
      style = input$posteriorStyle,
      cex = input$posteriorCex,
      lwd = input$posteriorLwd,
      panelWidth = input$sitePanelWidth,
      plotScale = input$resultPlotScale,
      quantile = input$posteriorQuantile,
      burn = input$posteriorBurn,
      colourBy = input$alignmentColourBy,
      colourScale = input$posteriorSignalColourScale
    )
  }), millis = 250)

  tracePlotTrigger <- debounce(reactive({
    list(
      model = model_api$alignment(),
      cluster = currentStratCluster(),
      alignments = alignmentSelectionDebounced(),
      style = input$posteriorStyle,
      cex = input$posteriorCex,
      lwd = input$posteriorLwd,
      panelWidth = input$sitePanelWidth,
      plotScale = input$resultPlotScale,
      burn = input$posteriorBurn,
      parameter = tracePlotParameter(),
      colourScale = input$posteriorSignalColourScale
    )
  }), millis = 250)

  correlationPlotTrigger <- debounce(reactive({
    list(
      model = model_api$alignment(),
      cluster = currentStratCluster(),

      alignments = alignmentSelectionDebounced(),
      sites = input$posteriorSites,
      # correlation tab has its own single-select radio (posteriorSignalCorr).
      signals = input$posteriorSignalCorr,

      style = input$posteriorStyle,
      cex = input$posteriorCex,
      lwd = input$posteriorLwd,
      panelWidth = input$sitePanelWidth,
      plotScale = input$resultPlotScale,

      burn = input$posteriorBurn,
      refHeights = input$refHeights,
      sourceSite = input$correlationSourceSite,
      confidence = input$confidenceLevel,
      sameYlim = input$correlationSameYlim,
      signalColourScale = input$correlationSignalColourScale,
      topsColourScale = input$correlationTopsColourScale,

      # Include partitions because they can change refHeights/buttons/UI.
      partitions = combinedPartitions()
    )
  }), millis = 250)

  output$mainPlotAlignment <- renderPlot({
    state <- alignmentPlotTrigger()
    req(!is.null(state$sites),
        !is.null(state$signals),
        length(state$signals) > 0L,
        !is.null(state$alignments),
        length(state$alignments) > 0L,
        cancelOutput = TRUE)
    isolate(.drawMainPlot("alignment", state))
  },
  height = 600,
  width  = function() .mainPlotWidth("alignment"))

  output$mainPlotTraceplot <- renderPlot({
    state <- tracePlotTrigger()
    req(!is.null(state$alignments),
        length(state$alignments) > 0L,
        !is.null(state$parameter),
        cancelOutput = TRUE)
    isolate(.drawMainPlot("traceplot", state))
  },
  height = 600,
  width  = function() .mainPlotWidth("traceplot"))

  output$mainPlotCorrelation <- renderPlot({
    state <- correlationPlotTrigger()
    req(!is.null(state$sites),
        !is.null(state$signals),
        length(state$signals) > 0L,
        !is.null(state$alignments),
        length(state$alignments) > 0L,
        !is.null(state$sourceSite),
        cancelOutput = TRUE)

    isolate(.drawMainPlot("correlation", state))
  },
  height = 600,
  width  = function() .mainPlotWidth("correlation"))

  outputOptions(output, "mainPlotAlignment", suspendWhenHidden = TRUE)
  outputOptions(output, "mainPlotTraceplot", suspendWhenHidden = TRUE)
  # suspendWhenHidden = FALSE for the correlation plot specifically: with
  # TRUE, Shiny occasionally treats this output as hidden after its first
  # render (likely because the surrounding conditionalPanel toggles display),
  # which suspends it and silently swallows trigger invalidations from plot
  # settings until the user switches tabs and back. Always re-evaluate.
  outputOptions(output, "mainPlotCorrelation", suspendWhenHidden = FALSE)

  # Force these UIs to render even if Shiny initially mis-classifies them as
  # hidden (their containers are inside conditionalPanels that are shown by
  # default on first load). Without this, two reproducible symptoms can occur
  # on the first results-tab load:
  #   - the correlation plot's req() fails because input$correlationSourceSite
  #     was never registered, so the plot stays blank until the user toggles
  #     tabs and forces a re-render;
  #   - the plot stays visible but the settings widgets are unresponsive
  #     because plotOptionsUI has not yet been rendered, so its widgets'
  #     input bindings are not live and don't invalidate the plot trigger.
  outputOptions(output, "plotOptionsUI",               suspendWhenHidden = FALSE)
  outputOptions(output, "correlationSourceSite_ui",    suspendWhenHidden = FALSE)
  outputOptions(output, "correlationRefHeightsBlock_ui", suspendWhenHidden = FALSE)
  outputOptions(output, "posteriorSiteSel",            suspendWhenHidden = FALSE)
  outputOptions(output, "posteriorSignalSel",          suspendWhenHidden = FALSE)
  outputOptions(output, "posteriorSignalSelCorr",      suspendWhenHidden = FALSE)
  outputOptions(output, "posteriorAlnSel",             suspendWhenHidden = FALSE)

  # simple export
  output$download_session <- downloadHandler(
    filename = function() paste0("session-", Sys.Date(), ".rds"),
    content = function(file) {
      saveRDS(list(
        data = list(
          dataset    = r$dataset,
          siteColumn = data_api$siteColumn(),
          zColumn    = data_api$zColumn(),
          signalCols = data_api$signalCols(),
          stratData  = data_api$stratData()
        ),
        model = list(
          indices      = model_api$indices(),
          priors       = model_api$priors(),
          alignment    = model_api$alignment(),
          stratCluster = model_api$stratCluster()
        )
      ), file)
    }
  )
}
