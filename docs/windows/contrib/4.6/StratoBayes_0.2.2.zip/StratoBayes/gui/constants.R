# Define constants used in shiny app

# Default debounce period for input sliders etc.
aJiffy <- 42 # ms
typingJiffy <- 2.5 * aJiffy # slightly slower if might be typing

# Beta cap on the number of wells/sites that can be loaded simultaneously.
# Datasets exceeding this are auto-truncated to the first MAX_LOADED_SITES
# entries with a one-shot notification.
MAX_LOADED_SITES <- 10
