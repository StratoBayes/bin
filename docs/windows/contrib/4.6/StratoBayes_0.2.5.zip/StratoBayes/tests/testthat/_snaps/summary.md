# summary.StratPosterior works with single cluster

    Code
      summary(stratPosterior1)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 19%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01348
        alpha_site_3    1.00445
        gammaLog_site_2 1.01882
        gammaLog_site_3 1.01073
        lambda_value    1.00055
        log prior       1.02065
        log likelihood  1.00967
        log posterior   1.00720
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 300 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 257.2
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.24842 0.09257  6.09046  6.19121  6.24524  6.30028  6.44088
      alpha_site_3     1.70894 0.15928  1.40942  1.60807  1.68959  1.82345  2.03556
      gammaLog_site_2 -0.68108 0.06040 -0.78942 -0.73099 -0.68194 -0.63339 -0.57160
      gammaLog_site_3  0.12529 0.06058  0.02913  0.08339  0.11579  0.16643  0.26354
      lambda_value     2.22315 0.89342  0.76657  1.56200  2.11111  2.76399  4.06484
      log prior       -103.475 2.98399 -109.775 -105.182 -103.619 -102.115 -97.6271
      log likelihood   77.0537 4.00150  68.6035  74.5201  77.6373  79.8330  83.3108
      log posterior   -26.4213 3.74050 -36.1076 -28.5641 -26.0783 -23.7367 -20.5937
                          ess
      alpha_site_2    191.153
      alpha_site_3    238.819
      gammaLog_site_2 246.257
      gammaLog_site_3 245.675
      lambda_value    300.000
      log prior       217.186
      log likelihood  271.361
      log posterior   251.083
      

# print.summary.StratPosterior works with change sigDigits

    Code
      print(summary(stratPosterior1), sigDigits = 2)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 19%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.0
        alpha_site_3    1.0
        gammaLog_site_2 1.0
        gammaLog_site_3 1.0
        lambda_value    1.0
        log prior       1.0
        log likelihood  1.0
        log posterior   1.0
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 300 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 257.2
                        mean      sd     2.5%      25%    50%    75% 97.5%     ess
      alpha_site_2      6.20 9.3e-02     6.10     6.20   6.20   6.30  6.40 1.9e+02
      alpha_site_3      1.70    0.20     1.40     1.60   1.70   1.80  2.00 2.4e+02
      gammaLog_site_2  -0.70   6e-02    -0.80    -0.70  -0.70  -0.60 -0.60 2.5e+02
      gammaLog_site_3   0.10 6.1e-02  2.9e-02  8.3e-02   0.10   0.20  0.30 2.5e+02
      lambda_value      2.20    0.90     0.80     1.60   2.10   2.80  4.10   3e+02
      log prior       -1e+02    3.00 -1.1e+02 -1.1e+02 -1e+02 -1e+02   -98 2.2e+02
      log likelihood      77    4.00       69       75     78     80    83 2.7e+02
      log posterior      -26    3.70      -36      -29    -26    -24   -21 2.5e+02
      

# summary.StratPosterior works with two clusters

    Code
      summary(stratPosterior2)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 400 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.01407
        alpha_site2    1.00087
        alpha_site3    1.03492
        gammaLog_site1 1.01114
        gammaLog_site2 0.99863
        gammaLog_site3 1.02985
        gap_site2_1    1.00541
        lambda_a       1.02734
        lambda_b       1.00334
        log prior      1.00367
        log likelihood 1.00524
        log posterior  1.00917
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 329 samples (82.2%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 222
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.9620 2.06201  9.76692  12.5798  13.9031  15.3969  18.0457
      alpha_site2     29.7970 1.24656  27.2797  28.9692  29.8167  30.6720  32.0047
      alpha_site3     46.2783 3.42754  40.8275  43.7703  45.8601  48.4232  53.7834
      gammaLog_site1  1.39170 0.10218  1.21041  1.31866  1.38947  1.46063  1.59489
      gammaLog_site2  1.01607 0.14616  0.75679  0.91612  1.00785  1.11441  1.31811
      gammaLog_site3 -0.18105 0.31537 -0.76043 -0.38863 -0.17409  0.04866  0.42024
      gap_site2_1     2.54912 1.19732  0.73260  1.60087  2.41987  3.28284  5.20567
      lambda_a        0.74463 0.53280  0.17841  0.35136  0.59870  0.98410  2.25336
      lambda_b        0.93652 0.52116  0.24389  0.61039  0.80654  1.16039  2.43195
      log prior      -139.971 6.55099 -152.630 -144.729 -139.811 -135.669 -126.936
      log likelihood -516.139 8.11103 -532.699 -521.438 -515.179 -510.254 -502.743
      log posterior  -656.110 5.84462 -668.587 -659.952 -655.859 -652.268 -644.603
                         ess
      alpha_site1    113.922
      alpha_site2    247.809
      alpha_site3    68.8302
      gammaLog_site1 89.6566
      gammaLog_site2 236.283
      gammaLog_site3 85.2836
      gap_site2_1    165.295
      lambda_a       192.892
      lambda_b       258.263
      log prior      222.227
      log likelihood 273.927
      log posterior  207.945
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 67 samples (16.8%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 62.5
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.3989 1.83577  10.2073  12.1003  13.5590  14.6188  17.2556
      alpha_site2     29.7134 1.28889  27.3880  28.7402  29.6351  30.5428  32.1005
      alpha_site3     18.1495 1.76152  14.7081  16.9962  18.4699  19.0932  21.2915
      gammaLog_site1  1.35883 0.08961  1.19803  1.30687  1.35360  1.41908  1.52935
      gammaLog_site2  0.92392 0.13854  0.66911  0.84199  0.89998  1.03049  1.19701
      gammaLog_site3  0.80988 0.21282  0.44512  0.69730  0.80124  0.95012  1.18365
      gap_site2_1     2.25587 1.08269  0.47963  1.57361  2.14959  2.74590  4.77134
      lambda_a        0.13498 0.10486  0.02254  0.06283  0.10320  0.16596  0.35036
      lambda_b        0.89466 0.54952  0.25135  0.50894  0.76308  1.08024  2.05796
      log prior      -150.541 6.81976 -163.742 -155.711 -149.628 -144.991 -138.646
      log likelihood -506.961 8.22809 -524.162 -512.372 -505.710 -501.377 -493.168
      log posterior  -657.502 5.20348 -667.974 -661.058 -656.834 -654.229 -647.383
                         ess
      alpha_site1    29.0507
      alpha_site2    50.0855
      alpha_site3    40.6125
      gammaLog_site1 26.8771
      gammaLog_site2 40.0141
      gammaLog_site3 63.4499
      gap_site2_1    67.0000
      lambda_a       49.6238
      lambda_b       49.5617
      log prior      51.2156
      log likelihood 62.2143
      log posterior  67.0000
      
      Summary statistics for 4 samples (1%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 4
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     16.6862 1.73164  15.0430  15.9036  16.3596  17.1423  18.8845
      alpha_site2     28.4737 0.84849  27.4043  28.1579  28.6299  28.9457  29.2776
      alpha_site3     41.9765 8.22180  37.2683  37.9194  38.2109  42.2679  53.0861
      gammaLog_site1  1.69924 0.10879  1.60285  1.60694  1.69485  1.78715  1.80312
      gammaLog_site2  1.37584 0.16771  1.18080  1.28399  1.38900  1.48085  1.54850
      gammaLog_site3  0.11228 0.77220 -0.90521 -0.12171  0.35746  0.59144  0.71296
      gap_site2_1     1.23019 0.40641  0.84217  0.90568  1.22501  1.54952  1.62701
      lambda_a        0.29881 0.30917  0.13947  0.14046  0.14671  0.30506  0.71674
      lambda_b        0.40461 0.29359  0.14477  0.25876  0.33345  0.47930  0.78544
      log prior      -139.857 12.0456 -148.252 -147.561 -144.363 -136.659 -123.804
      log likelihood -531.674 13.6229 -550.096 -533.023 -525.773 -524.423 -523.284
      log posterior  -671.531 2.80021 -674.278 -673.472 -671.818 -669.877 -668.296
                         ess
      alpha_site1    4.00000
      alpha_site2    4.00000
      alpha_site3    4.00000
      gammaLog_site1 4.00000
      gammaLog_site2 4.00000
      gammaLog_site3 4.00000
      gap_site2_1    2.73411
      lambda_a       4.00000
      lambda_b       4.00000
      log prior      4.00000
      log likelihood 4.00000
      log posterior  4.00000
      

# summary.StratPosterior works with no burn-in

    Code
      summary(stratPosterior2, burnIn = 0)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 804 samples (201 per run), discarding no iterations as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.00831
        alpha_site2    0.99932
        alpha_site3    1.05233
        gammaLog_site1 1.00691
        gammaLog_site2 1.00332
        gammaLog_site3 1.05269
        gap_site2_1    1.00894
        lambda_a       1.03996
        lambda_b       1.01107
        log prior      1.03402
        log likelihood 1.00876
        log posterior  1.01357
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 586 samples (72.9%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 311.5
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     14.0351 2.16040  9.93758  12.5072  14.0413  15.4656  18.3524
      alpha_site2     29.7443 1.26810  27.2256  28.9147  29.7680  30.6223  32.0924
      alpha_site3     45.9799 3.61038  39.9330  43.5758  45.5975  48.1162  54.0202
      gammaLog_site1  1.40055 0.11557  1.19782  1.31828  1.39629  1.46745  1.66338
      gammaLog_site2  1.03595 0.16130  0.74432  0.92350  1.02846  1.13436  1.37565
      gammaLog_site3 -0.15245 0.33586 -0.76543 -0.36930 -0.14306  0.07215  0.55720
      gap_site2_1     2.45209 1.17639  0.63488  1.54609  2.29464  3.18015  5.13212
      lambda_a        0.72339 0.52773  0.14722  0.35352  0.58393  0.94286  2.20463
      lambda_b        0.89833 0.54701  0.20359  0.53898  0.76439  1.12456  2.42028
      log prior      -140.462 7.01291 -153.867 -145.116 -140.605 -135.847 -126.551
      log likelihood -516.486 8.37872 -534.818 -522.164 -515.804 -510.550 -502.101
      log posterior  -656.948 6.60791 -670.430 -660.585 -656.424 -652.956 -645.530
                         ess
      alpha_site1    273.227
      alpha_site2    460.297
      alpha_site3    117.133
      gammaLog_site1 233.685
      gammaLog_site2 411.768
      gammaLog_site3 122.173
      gap_site2_1    290.725
      lambda_a       325.650
      lambda_b       387.259
      log prior      327.337
      log likelihood 456.307
      log posterior  271.339
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 211 samples (26.2%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 191.1
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.2905 1.94378  9.48882  12.0088  13.4180  14.6649  16.9857
      alpha_site2     29.6880 1.25969  27.5085  28.7243  29.7145  30.5004  32.2259
      alpha_site3     17.9493 1.81657  14.1406  16.8660  18.1338  19.2279  21.0530
      gammaLog_site1  1.35485 0.09500  1.17881  1.29045  1.35182  1.41596  1.55320
      gammaLog_site2  0.94106 0.14459  0.68280  0.84808  0.92464  1.03699  1.21427
      gammaLog_site3  0.81170 0.20358  0.43748  0.68186  0.81774  0.92009  1.21627
      gap_site2_1     2.36139 1.11317  0.46060  1.62307  2.30567  3.11658  4.76626
      lambda_a        0.12727 0.08834  0.02703  0.06760  0.10753  0.15532  0.31557
      lambda_b        0.98482 0.67301  0.23484  0.49727  0.80326  1.21891  2.99822
      log prior      -151.912 7.65398 -168.666 -156.578 -151.232 -146.528 -139.308
      log likelihood -506.538 8.69674 -526.375 -511.618 -505.454 -500.249 -492.751
      log posterior  -658.451 8.36968 -673.489 -661.316 -657.367 -653.716 -646.927
                         ess
      alpha_site1    81.3546
      alpha_site2    169.305
      alpha_site3    99.9171
      gammaLog_site1 65.9770
      gammaLog_site2 132.908
      gammaLog_site3 105.065
      gap_site2_1    173.208
      lambda_a       123.361
      lambda_b       182.269
      log prior      131.197
      log likelihood 181.981
      log posterior  156.650
      
      Summary statistics for 7 samples (0.9%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 7
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     12.5619 3.68334  8.41135  9.50391  11.5809  16.1337  16.6420
      alpha_site2     28.9274 5.21763  21.1236  26.9596  28.8228  31.7103  35.8349
      alpha_site3     37.6098 13.4447  20.3710  28.9449  33.6663  48.8688  53.9703
      gammaLog_site1  1.41075 0.38304  0.94690  1.14079  1.44131  1.58422  1.99643
      gammaLog_site2  1.36036 0.40391  0.91715  1.15136  1.17994  1.58429  1.96890
      gammaLog_site3  0.21744 1.04518 -0.97654 -0.78274  0.48000  1.09563  1.38235
      gap_site2_1     2.15465 2.14191  0.24853  0.67952  1.53419  3.09974  5.59637
      lambda_a        0.27398 0.36199  0.00001  0.00001  0.00001  0.57767  0.76136
      lambda_b        0.31748 0.46667  0.00001  0.00001  0.00001  0.54928  1.07810
      log prior      -168.622 51.1609 -247.444 -199.260 -158.180 -123.683 -122.567
      log likelihood -804.660 281.187 -1210.63 -998.180 -765.289 -547.896 -540.278
      log posterior  -973.282 315.770 -1383.17 -1218.99 -976.096 -670.941 -663.939
                         ess
      alpha_site1    4.91453
      alpha_site2    4.34563
      alpha_site3    7.00000
      gammaLog_site1 7.00000
      gammaLog_site2 3.35894
      gammaLog_site3 7.00000
      gap_site2_1    7.00000
      lambda_a       7.00000
      lambda_b       7.00000
      log prior      6.92420
      log likelihood 5.06000
      log posterior  4.84792
      

# summary.StratPosterior works with iteration burn-in

    Code
      summary(stratPosterior1, burnIn = 4900)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 12 samples (4 per run), after discarding the first 98% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 0%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    NA
        alpha_site_3    NA
        gammaLog_site_2 NA
        gammaLog_site_3 NA
        lambda_value    NA
        log prior       NA
        log likelihood  NA
        log posterior   NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 2 draws and at least 4 are needed (retained draws per run: 4, 4, 4).
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 12 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 12
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.27105 0.11992  6.09944  6.20010  6.24385  6.37821  6.44012
      alpha_site_3     1.76275 0.16031  1.57468  1.63606  1.72293  1.90019  2.02721
      gammaLog_site_2 -0.66644 0.08883 -0.79164 -0.73610 -0.67036 -0.60114 -0.53809
      gammaLog_site_3  0.16554 0.05856  0.08518  0.12371  0.15639  0.22328  0.25022
      lambda_value     2.71004 1.30351  1.19849  1.48241  2.78841  3.24692  5.07031
      log prior       -104.293 3.76472 -109.715 -106.078 -103.687 -103.215 -97.9552
      log likelihood   76.3495 6.93739  63.9685  72.9399  76.0541  81.7449  84.6481
      log posterior   -27.9438 5.22863 -36.2150 -31.4952 -27.9062 -23.4709 -20.9017
                          ess
      alpha_site_2    10.0896
      alpha_site_3    10.6148
      gammaLog_site_2 5.65704
      gammaLog_site_3 12.0000
      lambda_value    6.68963
      log prior       5.17959
      log likelihood  5.39463
      log posterior   12.0000
      

# summary.StratPosterior works with iterations

    Code
      summary(stratPosterior2, iterations = 500:800)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 28 samples (7 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 7.1%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    NA
        alpha_site2    NA
        alpha_site3    NA
        gammaLog_site1 NA
        gammaLog_site2 NA
        gammaLog_site3 NA
        gap_site2_1    NA
        lambda_a       NA
        lambda_b       NA
        log prior      NA
        log likelihood NA
        log posterior  NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 3 draws and at least 4 are needed (retained draws per run: 7, 7, 7, 7).
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 22 samples (78.6%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 22
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.6240 1.53247  10.4051  12.9611  13.5897  14.3797  16.1694
      alpha_site2     30.0922 0.99251  28.1402  29.5275  30.1532  30.8823  31.3982
      alpha_site3     18.5173 1.31042  16.3892  17.5824  18.3865  19.4355  20.7554
      gammaLog_site1  1.35108 0.08755  1.21215  1.31208  1.33655  1.41847  1.51787
      gammaLog_site2  0.95025 0.15640  0.69339  0.82034  0.96802  1.05197  1.17831
      gammaLog_site3  0.71439 0.18460  0.39342  0.68001  0.75942  0.77873  1.03437
      gap_site2_1     2.54749 0.79079  1.00387  2.07923  2.81755  3.05271  3.52248
      lambda_a        0.11959 0.05997  0.04915  0.07791  0.11435  0.13537  0.25870
      lambda_b        1.13028 0.66141  0.28532  0.63060  1.09418  1.40522  2.51746
      log prior      -151.392 5.09710 -157.683 -156.350 -151.363 -146.327 -143.726
      log likelihood -506.601 8.87673 -524.377 -512.600 -504.996 -500.110 -492.943
      log posterior  -657.993 7.14406 -672.779 -661.002 -657.915 -654.060 -646.232
                         ess
      alpha_site1    10.6741
      alpha_site2    15.4454
      alpha_site3    13.9129
      gammaLog_site1 19.5970
      gammaLog_site2 22.0000
      gammaLog_site3 10.7151
      gap_site2_1    12.7694
      lambda_a       11.0941
      lambda_b       22.0000
      log prior      22.0000
      log likelihood 10.4270
      log posterior  14.3537
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 6 samples (21.4%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 6
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     12.3467 2.31525  8.74207  11.4660  12.8019  14.0001  14.6094
      alpha_site2     29.5121 1.44545  27.2121  29.2728  29.6256  30.5761  30.8454
      alpha_site3     43.8961 2.38747  40.6602  43.1547  43.5024  45.1825  47.0794
      gammaLog_site1  1.32052 0.10887  1.23289  1.23289  1.27386  1.41354  1.46106
      gammaLog_site2  0.97765 0.25067  0.80204  0.80204  0.84561  1.10321  1.36836
      gammaLog_site3  0.11598 0.25418 -0.03586 -0.03267 -0.03267  0.17921  0.53902
      gap_site2_1     2.51915 1.31582  1.49873  2.07136  2.07136  2.28374  4.78253
      lambda_a        0.60562 0.30744  0.28876  0.36409  0.55341  0.81723  1.01767
      lambda_b        1.23375 0.58087  0.72126  0.89660  1.14711  1.22312  2.20231
      log prior      -143.879 5.95045 -153.832 -144.351 -142.216 -141.050 -138.361
      log likelihood -511.411 5.12932 -518.232 -514.921 -510.492 -508.069 -505.573
      log posterior  -655.290 3.62105 -659.999 -657.543 -655.045 -653.182 -650.743
                         ess
      alpha_site1    3.41586
      alpha_site2    6.00000
      alpha_site3    5.82255
      gammaLog_site1 2.83427
      gammaLog_site2 3.14944
      gammaLog_site3 5.46736
      gap_site2_1    5.22043
      lambda_a       6.00000
      lambda_b       6.00000
      log prior      4.36100
      log likelihood 6.00000
      log posterior  6.00000
      

# summary.StratPosterior works with unassigned iterations

    Code
      summary(stratPosterior2, iterations = 1:100, runs = 4)
    Output
      
      Posterior of stratigraphic model from 1 run after 10000 iterations:
      
        Total samples: 201
        Statistics summarise 3 samples (3 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 0%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    NA
        alpha_site2    NA
        alpha_site3    NA
        gammaLog_site1 NA
        gammaLog_site2 NA
        gammaLog_site3 NA
        gap_site2_1    NA
        lambda_a       NA
        lambda_b       NA
        log prior      NA
        log likelihood NA
        log posterior  NA
        NA: too few chain splits are available to compute a split-chain R-hat.
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 3 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 3
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     11.7512 4.61458  7.76082  9.26885  10.9444  13.8302  16.4274
      alpha_site2     24.9521 4.16276  20.5123  23.5132  26.8474  27.3386  27.7807
      alpha_site3     16.1117 3.52756  12.8029  14.3240  16.0142  17.8506  19.5033
      gammaLog_site1  1.17548 0.09182  1.10656  1.12361  1.14254  1.21088  1.27239
      gammaLog_site2  0.89683 0.18827  0.72615  0.79855  0.87899  0.98619  1.08267
      gammaLog_site3  0.93183 0.42528  0.60155  0.69348  0.79562  1.10208  1.37789
      gap_site2_1     3.50667 3.08751  0.26761  2.27219  4.49951  5.23756  5.90182
      lambda_a        0.11226 0.10388  0.00660  0.06588  0.13175  0.16838  0.20135
      lambda_b        0.56539 0.76997  0.01270  0.12692  0.25384  0.84808  1.38289
      log prior      -175.243 34.0662 -208.867 -191.412 -172.017 -157.461 -144.359
      log likelihood -598.687 144.431 -753.123 -643.626 -521.962 -515.386 -509.468
      log posterior  -773.930 176.352 -961.990 -835.038 -693.980 -672.847 -653.827
                         ess
      alpha_site1    3.00000
      alpha_site2    3.00000
      alpha_site3    3.00000
      gammaLog_site1 3.00000
      gammaLog_site2 3.00000
      gammaLog_site3 3.00000
      gap_site2_1    3.00000
      lambda_a       3.00000
      lambda_b       3.00000
      log prior      3.00000
      log likelihood 3.00000
      log posterior  3.00000
      

# summary.StratPosterior works with alignment 2

    Code
      summary(stratPosterior2, alignment = 2)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 400 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.01407
        alpha_site2    1.00087
        alpha_site3    1.03492
        gammaLog_site1 1.01114
        gammaLog_site2 0.99863
        gammaLog_site3 1.02985
        gap_site2_1    1.00541
        lambda_a       1.02734
        lambda_b       1.00334
        log prior      1.00367
        log likelihood 1.00524
        log posterior  1.00917
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 67 samples (16.8%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 62.5
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.3989 1.83577  10.2073  12.1003  13.5590  14.6188  17.2556
      alpha_site2     29.7134 1.28889  27.3880  28.7402  29.6351  30.5428  32.1005
      alpha_site3     18.1495 1.76152  14.7081  16.9962  18.4699  19.0932  21.2915
      gammaLog_site1  1.35883 0.08961  1.19803  1.30687  1.35360  1.41908  1.52935
      gammaLog_site2  0.92392 0.13854  0.66911  0.84199  0.89998  1.03049  1.19701
      gammaLog_site3  0.80988 0.21282  0.44512  0.69730  0.80124  0.95012  1.18365
      gap_site2_1     2.25587 1.08269  0.47963  1.57361  2.14959  2.74590  4.77134
      lambda_a        0.13498 0.10486  0.02254  0.06283  0.10320  0.16596  0.35036
      lambda_b        0.89466 0.54952  0.25135  0.50894  0.76308  1.08024  2.05796
      log prior      -150.541 6.81976 -163.742 -155.711 -149.628 -144.991 -138.646
      log likelihood -506.961 8.22809 -524.162 -512.372 -505.710 -501.377 -493.168
      log posterior  -657.502 5.20348 -667.974 -661.058 -656.834 -654.229 -647.383
                         ess
      alpha_site1    29.0507
      alpha_site2    50.0855
      alpha_site3    40.6125
      gammaLog_site1 26.8771
      gammaLog_site2 40.0141
      gammaLog_site3 63.4499
      gap_site2_1    67.0000
      lambda_a       49.6238
      lambda_b       49.5617
      log prior      51.2156
      log likelihood 62.2143
      log posterior  67.0000
      

# summary.StratPosterior works with no clusters (all it)

    Code
      summary.StratPosterior(stratPosterior2, alignment = "none")
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 400 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.01407
        alpha_site2    1.00087
        alpha_site3    1.03492
        gammaLog_site1 1.01114
        gammaLog_site2 0.99863
        gammaLog_site3 1.02985
        gap_site2_1    1.00541
        lambda_a       1.02734
        lambda_b       1.00334
        log prior      1.00367
        log likelihood 1.00524
        log posterior  1.00917
      
      Summary statistics for the posterior, comprising 400 samples:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 258.1
                         mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site1     13.8949 2.04901  9.88010  12.4914  13.8717  15.2493  18.0444
      alpha_site2     29.7698 1.25522  27.2673  28.9083  29.8039  30.6404  32.0067
      alpha_site3     41.5237 11.0029  16.0911  42.0062  44.9005  47.9406  53.7643
      gammaLog_site1  1.38927 0.10547  1.20879  1.31746  1.38273  1.45531  1.60254
      gammaLog_site2  1.00424 0.15340  0.73970  0.89616  0.99623  1.10418  1.32255
      gammaLog_site3 -0.01213 0.48050 -0.75501 -0.34624 -0.09684  0.22142  1.01809
      gap_site2_1     2.48681 1.18389  0.63656  1.58052  2.34845  3.18190  5.13238
      lambda_a        0.63805 0.53751  0.05488  0.25001  0.48823  0.83932  2.20413
      lambda_b        0.92419 0.52616  0.24343  0.59521  0.79891  1.13672  2.41067
      log prior      -141.740 7.72574 -157.671 -146.727 -141.662 -136.456 -127.698
      log likelihood -514.757 9.01808 -532.359 -520.755 -514.169 -508.757 -498.669
      log posterior  -656.497 5.93111 -669.312 -660.607 -656.035 -652.634 -645.223
                         ess
      alpha_site1    153.694
      alpha_site2    277.554
      alpha_site3    138.849
      gammaLog_site1 154.983
      gammaLog_site2 336.370
      gammaLog_site3 152.947
      gap_site2_1    209.279
      lambda_a       220.610
      lambda_b       328.374
      log prior      236.035
      log likelihood 268.339
      log posterior  263.226
      

# summary.StratPosterior works with new cluster object and many clusters

    Code
      summary.StratPosterior(stratPosterior1, alignment = "all", stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 19%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01348
        alpha_site_3    1.00445
        gammaLog_site_2 1.01882
        gammaLog_site_3 1.01073
        lambda_value    1.00055
        log prior       1.02065
        log likelihood  1.00967
        log posterior   1.00720
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 78 samples (26%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 78
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.23463 0.04952  6.12092  6.20237  6.24185  6.27121  6.32346
      alpha_site_3     1.71140 0.10512  1.55189  1.62979  1.68650  1.80232  1.89494
      gammaLog_site_2 -0.66326 0.03278 -0.71716 -0.68857 -0.66684 -0.63355 -0.60872
      gammaLog_site_3  0.11398 0.03561  0.06227  0.08746  0.10750  0.14017  0.17682
      lambda_value     2.18026 0.90178  0.76417  1.47885  2.08647  2.67731  3.95605
      log prior       -101.910 1.59543 -105.145 -102.217 -102.153 -100.670 -98.9918
      log likelihood   78.1136 3.00924  71.2014  76.4793  78.4167  79.9530  82.9491
      log posterior   -23.7966 2.61788 -29.5543 -24.9305 -23.5272 -22.1978 -19.9104
                          ess
      alpha_site_2    78.0000
      alpha_site_3    62.5744
      gammaLog_site_2 78.0000
      gammaLog_site_3 66.0814
      lambda_value    57.9393
      log prior       70.4689
      log likelihood  72.8590
      log posterior   63.5742
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 29 samples (9.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 29
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.23636 0.05141  6.14016  6.21028  6.23654  6.28166  6.31002
      alpha_site_3     1.68159 0.06562  1.58563  1.64636  1.66334  1.73131  1.81784
      gammaLog_site_2 -0.72737 0.01831 -0.76141 -0.73856 -0.73057 -0.70753 -0.69750
      gammaLog_site_3  0.11862 0.02573  0.07828  0.10266  0.11549  0.13811  0.17287
      lambda_value     2.45128 0.95961  1.13232  1.69569  2.30508  2.99253  4.38208
      log prior       -104.455 1.02448 -105.703 -105.231 -105.179 -103.746 -102.242
      log likelihood   79.5500 2.70809  73.5703  78.3793  79.7809  81.0458  83.9260
      log posterior   -24.9051 2.63642 -30.3746 -26.4426 -25.2923 -22.8197 -21.1915
                          ess
      alpha_site_2    19.9572
      alpha_site_3    29.0000
      gammaLog_site_2 29.0000
      gammaLog_site_3 24.4354
      lambda_value    17.2566
      log prior       17.4585
      log likelihood  29.0000
      log posterior   28.7423
      
      Summary statistics for 193 samples (64.3%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 193
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.25581 0.10873  6.07807  6.16925  6.25042  6.34529  6.45217
      alpha_site_3     1.71206 0.18526  1.39161  1.59055  1.70295  1.84507  2.08046
      gammaLog_site_2 -0.68132 0.06890 -0.79762 -0.73873 -0.68111 -0.62369 -0.56205
      gammaLog_site_3  0.13086 0.07085  0.01495  0.07777  0.12414  0.18024  0.27169
      lambda_value     2.20621 0.87961  0.76428  1.56406  2.10139  2.77095  4.08593
      log prior       -103.960 3.36394 -111.130 -106.517 -103.719 -102.125 -97.6006
      log likelihood   76.2502 4.26471  66.8600  73.7536  76.4048  79.2766  83.0191
      log posterior   -27.7100 3.63473 -36.8818 -29.4500 -27.3072 -25.2629 -21.9408
                          ess
      alpha_site_2    111.237
      alpha_site_3    185.171
      gammaLog_site_2 186.064
      gammaLog_site_3 193.000
      lambda_value    193.000
      log prior       189.125
      log likelihood  156.360
      log posterior   124.415
      

# summary.StratPosterior works with new cluster object and iterations before burnIn

    Code
      summary.StratPosterior(stratPosterior1, stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 3 samples (1 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 19%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    NA
        alpha_site_3    NA
        gammaLog_site_2 NA
        gammaLog_site_3 NA
        lambda_value    NA
        log prior       NA
        log likelihood  NA
        log posterior   NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 1 draw and at least 4 are needed (retained draws per run: 1, 1, 1).
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 2 samples (66.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 2
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.08177 0.01316  6.07293  6.07712  6.08177  6.08643  6.09061
      alpha_site_3     10.4420 0.74464  9.94178  10.1787  10.4420  10.7053  10.9422
      gammaLog_site_2 -0.76376 0.04612 -0.79474 -0.78007 -0.76376 -0.74746 -0.73278
      gammaLog_site_3  0.09587 0.27135 -0.08641 -0.00007  0.09587  0.19180  0.27814
      lambda_value     2.50203 0.62883  2.07961  2.27970  2.50203  2.72435  2.92444
      log prior       -175.064 14.8599 -185.046 -180.318 -175.064 -169.810 -165.082
      log likelihood   74.3450 5.48835  70.6581  72.4045  74.3450  76.2854  78.0318
      log posterior   -100.719 9.37154 -107.015 -104.033 -100.719 -97.4058 -94.4238
                          ess
      alpha_site_2    2.00000
      alpha_site_3    2.00000
      gammaLog_site_2 2.00000
      gammaLog_site_3 2.00000
      lambda_value    2.00000
      log prior       2.00000
      log likelihood  2.00000
      log posterior   2.00000
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 1 samples (33.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): NA
                          mean    sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2    -4.50584 0e+00 -4.50584 -4.50584 -4.50584 -4.50584 -4.50584
      alpha_site_3     1.57574 0e+00  1.57574  1.57574  1.57574  1.57574  1.57574
      gammaLog_site_2 -0.31171 0e+00 -0.31171 -0.31171 -0.31171 -0.31171 -0.31171
      gammaLog_site_3  0.04270 0e+00  0.04270  0.04270  0.04270  0.04270  0.04270
      lambda_value     2.26281 0e+00  2.26281  2.26281  2.26281  2.26281  2.26281
      log prior       -174.702 0e+00 -174.702 -174.702 -174.702 -174.702 -174.702
      log likelihood   68.9304 0e+00  68.9304  68.9304  68.9304  68.9304  68.9304
      log posterior   -105.772 0e+00 -105.772 -105.772 -105.772 -105.772 -105.772
                          ess
      alpha_site_2    1.00000
      alpha_site_3    1.00000
      gammaLog_site_2 1.00000
      gammaLog_site_3 1.00000
      lambda_value    1.00000
      log prior       1.00000
      log likelihood  1.00000
      log posterior   1.00000
      

# summary.StratPosterior works with new cluster object and iterations before burnIn - alignment none

    Code
      summary.StratPosterior(stratPosterior1, alignment = "none", stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 19%.
        'ess' is a measure of effective sample size (Geyer, 1992).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01348
        alpha_site_3    1.00445
        gammaLog_site_2 1.01882
        gammaLog_site_3 1.01073
        lambda_value    1.00055
        log prior       1.02065
        log likelihood  1.00967
        log posterior   1.00720
      
      Summary statistics for the posterior, comprising 300 samples:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 257.2
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     6.24842 0.09257  6.09046  6.19121  6.24524  6.30028  6.44088
      alpha_site_3     1.70894 0.15928  1.40942  1.60807  1.68959  1.82345  2.03556
      gammaLog_site_2 -0.68108 0.06040 -0.78942 -0.73099 -0.68194 -0.63339 -0.57160
      gammaLog_site_3  0.12529 0.06058  0.02913  0.08339  0.11579  0.16643  0.26354
      lambda_value     2.22315 0.89342  0.76657  1.56200  2.11111  2.76399  4.06484
      log prior       -103.475 2.98399 -109.775 -105.182 -103.619 -102.115 -97.6271
      log likelihood   77.0537 4.00150  68.6035  74.5201  77.6373  79.8330  83.3108
      log posterior   -26.4213 3.74050 -36.1076 -28.5641 -26.0783 -23.7367 -20.5937
                          ess
      alpha_site_2    191.153
      alpha_site_3    238.819
      gammaLog_site_2 246.257
      gammaLog_site_3 245.675
      lambda_value    300.000
      log prior       217.186
      log likelihood  271.361
      log posterior   251.083
      

