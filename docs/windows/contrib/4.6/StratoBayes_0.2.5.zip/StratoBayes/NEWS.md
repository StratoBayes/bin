# StratoBayes 0.2.5

* **The default tempering ladder now ends at a finite temperature**,
  `min(1.9^(nChains - 1), 80)`, instead of `T = Inf`. The old ladder reached
  ~5e3 at the default 8 chains and ~1e8 at 24 — a span its rungs could not
  bridge, so adjacent chains exchanged states only 0.008 of the time and a mode
  found by a hot chain could not reach the cold chain the user reports; at 24
  chains such runs did not converge (between-seed R-hat 1.21 against 1.00 for
  every finite-topped ladder). Cold-chain effective samples per second roughly
  double, and every rung is now reachable: the `T = Inf` rung never was, so it
  spent a whole chain on nothing. The hottest chain therefore no longer samples
  the prior, and now adapts its proposals along with the rest; pass
  `temperatures` explicitly, `Inf` at the top included, for the previous
  behaviour. Chain output changes for any tempered run using the default
  ladder.

* **How often the sampler picks each proposal type is now decided by the mixing
  each type actually delivers per second** — squared jump distance in whitened
  parameter coordinates, with a rejected move scoring zero — instead of by how
  close its acceptance rate sits to 0.234. A proposal that rejects almost
  everything cheaply is no longer up-weighted for being cheap, and the
  `Multivariate` proposal's hard-coded 0.2 floor on the cold-chain budget is
  gone. Proposal scale adaptation is unchanged. Chain output changes for any
  run that adapts its proposals.

* The adaptive `Multivariate` proposal now estimates its covariance from the
  genuinely most recent chain states, in two respects: the burn-in trim
  discards the older half of the retained history rather than a random half,
  and the recency window is selected across the whole retained buffer rather
  than within each cluster. Under the default `enableRingBuffer = FALSE` this
  previously left early wide-ranging states in the covariance and formed
  clusters from states spanning the whole run, suppressing acceptance; cluster
  covariances are now substantially tighter, and the proposal accepts moves on
  targets where it previously accepted none. Chain output changes for any run
  that adapts this proposal.

* The lower bound that sampling applies to the spline smoothness parameter
  `lambda` now scales with each signal's magnitude and the spline penalty's
  span in both directions (previously a fixed `1e-6`, then scale-relative but
  still capped at `1e-6`), and `BayesianSpline()` no longer bounds `lambda` at
  all. Large-magnitude signals (e.g. count-valued data) were previously
  over-smoothed once their honest `lambda` fell below the fixed bound;
  conversely, on data whose healthy `lambda` is large (e.g. long height ranges
  carrying small-magnitude signals), the fixed bound sat inside a numerically
  inflated region of the spline marginal, where a run under the default
  `tempering = TRUE` could permanently freeze while reporting a large positive
  log-posterior. Results change for both kinds of data; runs whose `lambda`
  never reaches the computed bound are bit-identical.

* `BayesianSpline()`'s two remaining fixed defaults now scale to the data.
  `lambdaInitial = NULL` seeds the sampler with a smoothing value scaled to the
  signal instead of a fixed `1e-4`: large-magnitude signals (y-scale above
  ~3,000, e.g. count-valued data) previously converged to a severely
  over-smoothed fit, or aborted mid-run with a factorisation error above ~1e5,
  and `StratModel()`'s internally derived `sigmaFixed` inherited the
  distortion. `bSigma = NULL` applies the `min(0.01, 0.01ns^2)` rule
  `StratModel()` already uses per signal to the prior rate on the residual
  variance, instead of a fixed `0.01`: for small-magnitude signals —
  proportions, per-mil values as raw ratios, metre-scale data converted to
  kilometres — the fixed rate outweighed the residual sum of squares, holding
  `sigma` orders of magnitude above the true noise and blurring the fit
  (relative error 0.30 against 0.017 at unit scale, for data scaled by 1e-3).
  Well-scaled data are statistically unchanged, and explicit values behave as
  before.

* A tempering ladder whose hottest chain is finite no longer collapses when
  `adaptTemperatures = TRUE`. Adaptation balanced the top rung against a swap
  link above it that does not exist, setting that temperature to `NA`; the
  non-finite value then spread down the ladder, and because a `NaN`-temperature
  chain rejects every proposal and every swap, every chain but the coldest
  froze — so the run paid for `nChains` chains and sampled with one, reported
  only as a `NaN` ladder under `engine = "cpp"` and as an error under
  `engine = "R"`. The coldest and hottest temperatures are now held fixed and
  only intermediate rungs adapt. Ladders topped with `Inf`, including every
  default ladder, are unaffected; relatedly, the "no effect" warning for
  `adaptTemperatures` now also fires when the only temperature above 1 is the
  hottest one, which nothing can adapt.

* `StratMCMC()` and `RunStratModel()` now warn when `temperingComponents`
  selects a log-posterior component the model does not have: `"ties"` (and
  `"signal+ties"`, which quietly reduces to `"signal"`) on a dataset with no
  absolute-age tie points. Such a run tempered nothing at all — every chain
  sampled the cold posterior and every swap was accepted — while costing
  `nChains` times a single chain, and nothing in the output revealed it.

* `RunStratModel(engine = "R")` no longer redraws or falls back to a different
  proposer when a proposed move fails a support check (extreme sedimentation
  rates, fixed-knot range, or insufficient signal overlap); it now rejects the
  move outright, matching the production C++ engine. Previously this biased the
  sampled posterior away from `pi(x)` toward `pi(x)*Z(x)` near such boundaries.
  Chain output changes for any `engine = "R"` run whose posterior sits near a
  rate/knot/overlap boundary; `engine = "cpp"` (the default) is unaffected.

* `RunStratModel(engine = "R")` now refreshes the cached `H`/`tBy` matrices
  after each Gibbs sweep, so the spline coefficients are drawn from their full
  conditional at the current `sigma` rather than at the previous sweep's. Chain
  output changes for any model with a free `sigma`; fixed-`sigma` models and
  the default `engine = "cpp"` are unaffected.

* `burnIn = "auto"` no longer falls back to discarding half of every run when
  one run ended earlier than the others (three runs or more). Candidate
  burn-ins were capped by the shortest run and had to leave every run some
  rows, so a transient the longer runs needed discarded could be unreachable —
  and was reported as a failure to converge. A run whose draws all precede the
  chosen burn-in is now excluded from the diagnostic and named in the message.
  Separately, a single `NA` iteration label no longer defeats the whole search.

* Continuing a model run is now checked before it starts. A different `nThin`
  warns and keeps the original thinning interval, rather than silently writing
  one run's samples on two schedules; a freshly created `StratMCMC()` object
  fails immediately with an explanatory error instead of later inside the
  sampler; and a samples file whose columns do not match the model being
  continued with, or a supplied `stratModel`/`stratData` that disagrees with
  the stored one, is an error naming the file and the mismatch, instead of
  silently appending mismatched rows. A missing `_data.rds` is reported as a
  missing file.

* `RunStratModel()`'s continuation path and `StratPosterior()`'s from-disk
  compilation now read per-run checkpoint and sample files in numeric run order
  for 10 or more runs, instead of ordering them as strings (1, 10, 11, ..., 2,
  3, ...). Previously, for any model with 10+ runs, a run's checkpoint state or
  samples could be silently read from the wrong run, corrupting per-run
  diagnostics and continuations with no error.

* `StratPosterior()` now refuses a model directory whose sample files and
  `_mcmc_run_*.rds` checkpoints cover different runs — naming the run numbers
  each set holds, so the missing or orphaned file is identifiable — instead of
  returning a posterior that reported more runs than its samples actually held.
  Previously such an object printed per-run sample counts that did not multiply
  out, and `summary()` failed on it with an unrelated "subscript out of bounds"
  or "all iterations were discarded as burn-in".

* `StratData()` now rejects a `parts` table whose top boundary height is
  duplicated by a trailing gap row, instead of silently mis-assigning
  ties/signal data sitting on that height to the wrong partition with no error
  or warning.

* `BayesianSpline()` now sorts its `knots` argument (and rejects non-numeric,
  `NA` or non-finite values) and requires at least two of them, instead of
  passing an unsorted vector to code that assumes ascending order. Previously,
  unsorted knots either produced a silently wrong fit — the penalty matrix was
  built from negative interval widths and was not positive semi-definite, with
  no error or warning — or sent the C++ knot-span search into an
  uninterruptible infinite loop that could only be escaped by killing the
  session.

* `RunStratModel(engine = "cpp")`'s "Prior" proposal now samples a custom
  (`Prior()`-based) parameter using its own `priorsProposals` arguments,
  instead of the corresponding `priors` entry's arguments. Previously, a model
  with a custom prior whose `priorsProposals` argument list differed from its
  `priors` argument list either drew from a silently wrong hybrid distribution
  or crashed with an "unused argument" error partway through sampling. Models
  using only built-in priors, or where `priorsProposals` is left at its default
  (identical to `priors`), are unaffected.

* A bare `Prior()` (not built via `NormalPrior()`, `LogNormalPrior()`, etc.)
  that matched a built-in density function by identity but supplied incomplete
  or out-of-order arguments could be silently mis-evaluated or crash:
  `Prior(rnorm, dnorm, qnorm)` (relying on `dnorm`'s own defaults) threw an
  unrelated "Object was created without names" error, and
  `Prior(rlnorm, dlnorm, qlnorm, sdlog = ..., meanlog = ...)` (named arguments
  supplied out of order) silently swapped `meanlog`/`sdlog` in its log-posterior
  contribution with no error or warning. Such priors are now correctly routed
  to their own R density function instead of a mismatched built-in one.

* `StratModel()` now rejects a `priorsProposals` entry for a parameter marked
  `Fixed` in `priors` unless it is itself `Fixed()` at the identical value,
  instead of silently initialising and holding that parameter at a wrong value
  for the whole run.

* `summary()` now clusters at the same `maxSamples` default as `Cluster()`
  (2500, was 10000), so a posterior with more than 2500 pooled post-burn-in
  samples no longer silently reports fewer/no outliers from `summary()` than an
  equivalent `Cluster()` call on the same object.

* `summary.StratPosterior()` no longer errors on two degenerate-but-valid
  sample states: a run whose selected rows were entirely discarded by
  `burnIn`/`maxSamples` (a documented `CombineModelRuns()` unequal-run-length
  workflow), and a single non-finite (`NA`/`NaN`/`Inf`) retained draw. The
  affected run/parameter now reports `NA` in the relevant statistic instead of
  the whole call erroring.

* `Tops()`/`TopsPlot()` now reject `refHeights` that fall outside the reference
  site's own recorded height range for height-scale alignments, instead of
  silently extrapolating to plausible-looking but meaningless values
  (`StratMap()` already errored on the analogous case).

* `plot.StratData()` now rejects a duplicated `signal` argument with a clear
  error instead of crashing or silently corrupting its returned data, and
  honours `colourBy` when plotting multiple signals at once (`signal = "all"`)
  instead of always colouring by site; `plot.StratPosterior()`'s `quantile`
  argument is now actually checked against its documented `[0, 1]` range and
  numeric type, instead of passing a non-numeric or out-of-range value through
  to fail later with an unrelated, opaque error.

* `plot.StratData()` no longer mis-assigns points to the wrong signal in its
  returned `plotDF` when `signal = c(...)` is supplied out of the dataset's
  natural signal order (e.g. `signal = c("b", "a")`).

* `hist.StratPosterior()` now returns the computed histogram object (with
  `counts`/`density`/`mids`) rather than a bare list when `colourBy = "none"`
  and `display = TRUE`, and its `border` argument now actually takes effect
  (default changed from `"transparent"` to `NULL`).

# StratoBayes 0.2.4

* A trial build's expiry date is now compiled into the binary rather than read
  from the installed `DESCRIPTION`, and is enforced by the MCMC engine as well
  as at load time. The `STRATOBAYES_DISABLE_EXPIRY` environment variable and
  the `stratobayes.disable_expiry` option have been removed: they shipped
  inside every release binary. A build made from source carries no expiry date
  at all, which is what dev and CI builds need.

* `RunStratModel()` gains `convergenceStop`, and **defaults it to `TRUE`**: a
  run now stops once the chains have converged, instead of always sampling to
  `nIter`. At each checkpoint it asks whether some burn-in at or after
  `endAdapting` leaves R-hat at or below `1.02` and effective sample size at or
  above `200`, and stops when that holds at two consecutive checkpoints. The
  ESS threshold does as much work as the R-hat one: without it an easy model
  would stop at its first post-adaptation checkpoint with almost nothing
  retained. Pass a named list to change either threshold, or
  `convergenceStop = FALSE` to sample to `nIter` regardless. Under the default
  `nIter = 1000` only a near-independent target can stop early, and not before
  iteration 700 (800 for a single run: ESS is summed across runs).

* **The NUTS proposal is no longer registered by default.** Previously
  `flexibleKnots = FALSE` added it automatically. Benchmarked on a three-well
  gamma-ray dataset at 8, 14 and 26 free parameters it was 14-24 times *worse*
  on effective samples per second than the Metropolis-only alternatives, on
  every one of 18 paired seeds, while producing hundreds of divergences where
  they produced none. Per-iteration mixing was comparable or better; each
  iteration cost roughly 35 times the wall clock, because trajectories run to
  the `maxTreeDepth` cap. Fixed-knot models now use the same proposal set as
  flexible-knot models, `SiteBlock` and `NeighbourScaled` included.

  **This changes the chains of existing fixed-knot analyses.** To reproduce a
  run from an earlier version, pass `gradientProposals = "on"`. NUTS also
  remains useful as a diagnostic under that setting, since its divergences
  localise regions of pathological posterior geometry.

* The live-MCMC plot no longer warns "Failed to rename live-plot PNG" when a
  panel had nothing to draw (a non-finite axis range). On Linux and macOS the
  cairo `png()` backend writes no file at all in that case, so there was
  nothing to rename and no failure to report.

* `burnIn` now accepts `"auto"` wherever it is available (`summary()`,
  `plot()`, `ExtractParameters()`, `Cluster()`, `TopsPlot()`,
  `PredictSpline()` and the rest). It selects the burn-in maximising effective
  sample size subject to the rank-normalized split-chain R-hat staying at or
  below `getOption("StratoBayes.rHatMax", 1.02)`, and `print(summary())`
  reports what was chosen. The default is unchanged at `0.5`. Two limits are
  documented in `?summary.StratPosterior`: no burn-in earlier than the end of
  proposal adaptation is ever selected, so under default settings the automatic
  value can only be `>= 0.5`; and where nothing satisfies the criterion,
  `"auto"` certifies no draw, so it warns and retains only the last 5% —
  enough to see where the chains have got to, and deliberately too few to
  mistake for a posterior sample. `TracePlot()` is the exception: it discards
  nothing in that case, since a trace is read to judge how far the chains have
  got.
* The MCMC engine now exploits the banded structure of the spline precision
  matrix (banded Cholesky, and the per-sweep matrix inverse deferred to
  checkpoints), making knot-heavy models much faster: measured ~30% less
  wall time at 60 knots and ~60% at 120, with negligible change below ~30
  knots (#116). Results are the same maths in a different floating-point
  order, so posterior samples from a given seed differ from those of
  previous versions (they were already not comparable across versions).
* `StratData()` now downsamples a site to `maxPointsPerSite` by taking rows at
  evenly spaced positions along `zColumn`, always keeping both extremes, where
  it previously took evenly spaced *rows*. The two differ wherever sampling
  density varies along a log, and the new rule measured 6-20% tighter alignment
  posteriors at every retention level tested. It is also the behaviour the
  argument was already documented as having. Runs that relied on the previous
  default will retain a different subset of a variable-density log
  ([#91](https://github.com/StratoBayes/StratoBayes-R-package/issues/91)).
* New `ThinSignal()` reduces a high-resolution `signal` dataset by averaging
  measurements over a fixed length of section, as an alternative to
  `StratData(maxPointsPerSite = )`, which instead discards the rows it does not
  retain. Averaging retains the information of the measurements it
  combines, so at a given retained-point count it gives markedly narrower
  alignment posteriors; the advantage shrinks as residual autocorrelation rises.
  `ThinSignal()` warns when the averaging length exceeds the knot spacing implied
  by a supplied `nKnots`, beyond which averaging suppresses variation the spline
  could otherwise fit ([#91](https://github.com/StratoBayes/StratoBayes-R-package/issues/91)).
* `RunStratModel()` now warns when `nChains`, `saveChains`, or
  `temperingComponents` is supplied on a continued run: these cannot change
  mid-run, and the value was previously accepted but silently ignored in
  favour of the checkpoint's own setting. It also warns when a continuation's
  `gradientProposals` differs from the checkpoint's original setting, since
  `gradientProposals` is not inherited across a continuation and previously
  reset without comment. Supplying a `stratMCMC=` list of the wrong length
  now errors immediately with a clear message, instead of surfacing later as
  a generic "subscript out of bounds".
* `StratModel()`'s `priors` argument now defaults to `NULL`, so it can be
  omitted entirely; priors are then generated from the data with
  `AutoPrior()`. Previously omitting `priors` raised "argument \"priors\" is
  missing, with no default" and `priors = NULL` had to be passed explicitly.
  Unchanged on `alignmentScale = "age"`, which has no automatic priors and
  still requires `priors`.
* `Cluster.StratPosterior()`'s default `maxSamples` is now `2500`, matching
  `maxClusterSamples`. Previously the defaults (`10,000` vs `2,500`) meant a
  typical default call silently took the subsample clustering path, which
  never reports outliers (cluster `0`), so `silCutOff`/outlier detection was
  effectively inactive unless a user manually lowered `maxSamples` or raised
  `maxClusterSamples`.
* Breaking change: `StratMCMC()`'s `timeLimit` argument has been removed. It
  never had any effect (it was declared but never read anywhere in the
  function), so any existing call that passed it was already a no-op and can
  simply drop the argument. Time limits are set via
  `RunStratModel(timeLimit = )`, which is unaffected.
* `CombineModelRuns()` now compares the runs' MCMC settings, which live in the
  per-run mcmc files rather than in `stratModel` and were previously not
  checked at all. Runs recorded at different `nThin` are refused, because they
  share no common set of saved iterations; differing `nChains` or `saveChains`
  warn. Nothing is copied when a combine is refused.
* `CombineModelRuns()` now excludes `sigmaFixed` from the model comparison only
  when both runs fix sigma to a number, as documented. A fixed-sigma run and an
  estimated-sigma run previously compared equal on that component.
* `CombineModelRuns()` now names the combined model's options file so that
  `StratPosterior()` can auto-detect it. Previously a combined model was
  invisible to auto-detection, which could silently return one of the original
  models' posteriors instead.
* `summary()` now reports `burnInPercent` against each run's own iteration
  range. Where runs were recorded at different `nThin`, the reported burn-in
  did not match what was actually discarded.
* `summary()`'s `psrf` is now `NA`, rather than a fabricated number, for a
  parameter whose retained draws are not all finite; and `print()` now states
  why `psrf` is `NA` instead of showing an unexplained `NA`.
* `print()` on a summary no longer collapses per-run sample counts and burn-in
  percentages to the first run's value when the runs differ.
* `StratPosterior()` now reports which run and which file is at fault when a
  sample file contains no complete rows. Previously one such file made the
  whole call fail with "argument must be coercible to non-negative integer" if
  it was header-only, or "values must be length 1, but FUN(X[[2]]) result is
  length 0" if it was 0-byte or otherwise unreadable -- either way losing every
  other run's results as well.
* A gradient-based (HMC/NUTS) iteration that cannot form a proposal now
  performs a complete self-transition: the spline coefficients, `sigma` and
  `lambda` are resampled and the log posterior refreshed, as on any other
  rejection. Previously such an iteration updated nothing at all. This is
  visible only for a model in which every Metropolis parameter is `Fixed()`,
  where the gradient proposal can never move and so took that path on every
  selection; such a model's chains now differ from those of earlier versions.
* **A Metropolis proposal that falls outside the support of the priors is now
  rejected, rather than replaced by a fresh draw.** The same applies to a
  proposal whose sedimentation rates fall outside `ratesRange`, or whose age
  conversion is invalid (including the fixed-knot range and the minimum
  signal-overlap requirement). Previously the sampler drew a replacement
  proposal until one passed, which silently truncated the proposal distribution
  without the compensating correction to the acceptance ratio: the chain then
  explored a density proportional to the posterior multiplied by the probability
  that a proposal from the current position is valid. That factor is 1 except
  within a couple of proposal standard deviations of a hard bound, so interior
  posteriors are unchanged, but against a bound it is substantial — in a
  boundary-pressed test posterior the probability mass within 0.05 of the bound
  was understated by 27%.

  **Analyses whose posterior lies against a hard prior bound will give different,
  and now correct, results** — for example an `alpha` pressed against the edge of
  its `UniformPrior`, or a `gap` near zero. Reported acceptance rates near a
  bound also fall, because proposals that were previously discarded and redrawn
  unseen are now counted as the rejections they are; proposal-scale adaptation
  reacts to that by shrinking the step size where it was too large.

  Because a proposal is now drawn only once, the retry loop is gone: an
  iteration can no longer exhaust its proposal retries, and every rejection —
  including one caused by a failed validity check — resamples the spline
  coefficients, `sigma` and `lambda` and is counted against the proposal that was
  selected. A model whose `ratesRange` cannot be satisfied at all now presents as
  a chain that never moves, rather than as an error.
* Continuing a run under `engine = "cpp"` from one that used `engine = "R"` no
  longer starts from an incorrectly scaled spline cross-product when `sigma` is
  estimated. The R engine records `B'B / sigma^2` before the Gibbs sweep that
  moves `sigma`, and the C++ engine had trusted that value; it now rebuilds the
  cross-products from the basis matrix on import. Runs that stay on one engine
  throughout are unaffected.
* The "`adaptTemperatures = TRUE` has no effect" warning (raised when the
  resolved temperature ladder has no intermediate chain temperature to adapt,
  e.g. `nChains = 2`) is now raised once, at `StratMCMC()`/`RunStratModel()`
  setup, and only when the user explicitly requested temperature adaptation.
  Previously it was raised from `.UpdateTemperatures()` on every adaptation
  window of every run, flooding output with duplicate warnings whenever
  `adaptTemperatures` was left at its default `TRUE`.
* Gradient-based proposals (NUTS/HMC) now work with `flexibleKnots = TRUE`, not
  only with fixed knots. The log-posterior gradient carries the alignment's
  effect on the knot span, and the joint log-posterior carries the
  alignment-dependent spline roughness prior that moving knots imply. The
  previous restriction was documented as a consequence of variable
  dimensionality; that was incorrect — the parameter vector has the same length
  under both settings.
* New `StratMCMC(gradientProposals =)` controls whether the NUTS proposal is
  registered. The default `"auto"` reproduces the previous behaviour exactly
  (NUTS only with fixed knots), so no existing run changes. `"on"` registers
  NUTS regardless, including under `flexibleKnots = TRUE`; note that this
  *replaces* the `SiteBlock` and `NeighbourScaled` proposals, which are never
  registered alongside NUTS. `"on"` requires `engine = "cpp"`.
* `BayesianSpline()` now validates `lambdaFixed`: it must be `FALSE`, or a
  single finite value `>= 0`. Previously any non-numeric value (including
  `TRUE`) was silently ignored and `lambda` was estimated anyway.
* `BayesianSpline()` now conditions the first iteration's spline coefficients on
  `lambdaFixed` rather than on `lambdaInitial`.
* `BayesianSpline()` now reports, rather than silently absorbs, a spline
  coefficient update whose precision matrix cannot be factorised: a recoverable
  case warns once per run, and an unrecoverable one raises an error instead of
  carrying an unsampled coefficient vector into the rest of the chain.
* A ties `densityFun` that returns `NA` now raises an explanatory error instead
  of dropping that tie's contribution or failing with
  "missing value where TRUE/FALSE needed".
* `RunStratModel()`'s Gibbs step no longer substitutes the conditional mean for
  a spline coefficient draw when both of its covariance factorisations fail.
  Such a draw carried no sampling variance, which biased the subsequent `lambda`
  and `sigma` updates; it now recovers a genuine draw where possible and errors
  otherwise.
* Ties log-likelihoods that evaluate to a non-finite value other than `-Inf`
  (possible at a `dbeta` boundary with a shape parameter below 1) are now
  treated consistently as impossible states. Previously the result could depend
  on the order the ties were visited in, and in one order the ties term was
  dropped from the log-posterior altogether.
* `ReadLasFiles()` no longer silently reassigns a later file's data to an
  earlier failed file's name when a mid-folder LAS parse fails. It now warns
  once, listing every file that was skipped, and returns a list whose names
  and data are always correctly paired.
* `ReadLasFiles()` no longer requires two or more LAS files. The "at least two
  sites" rule belongs to `StratData()`, which still enforces it; a single-well
  folder can now be read on its own, so that separate folders can be combined
  with `c(ReadLasFiles(folderA), ReadLasFiles(folderB))`.
* `ReadLasFiles()` now reports how many NULL values it replaced with `NA`.
  The message existed before but could never fire, because the values had
  already been replaced before the count was taken.
* `StratData()` now rejects `parts` with two different partition labels at the
  same boundary height within a site. Such input created a zero-width partition
  and an unconstrained sedimentation-rate parameter. The repeated-boundary
  encoding that `.FillGaps()` produces around a gap is unaffected.
* `StratData()` now warns when downsampling to `maxPointsPerSite`
  disproportionately drops the non-NA values of a sparse signal column.
  Downsampling behaviour itself is unchanged.
* `SignalLookUp()` now errors on a `site` argument that names no site in the
  `StratData` object, instead of silently returning `numeric(0)`. Its error
  for an unspecified `signal` also no longer blames `type = "value"` when
  `type = "height"` raised it.
* `.CalculateRefHeightToHeights()` (used by `Tops()`/`TopsPlot()`) no longer
  crashes with "missing value where TRUE/FALSE needed" for a
  `sedModel = "site, partition"` site with a gap. Reference heights outside
  that site's well-defined partitions are now extrapolated as intended; a site
  with no well-defined partition at all returns `NA` with a warning.
* `RunStratModel()` no longer discards an interrupted run's samples. With the
  default C++ engine a fresh run accumulated its draws in memory and wrote them
  to `<modelName>_binarysamples_run_<n>.rds` only once sampling had finished, so
  an interrupt lost every draw. Resuming such a run then continued from the last
  checkpoint's state while labelling the new draws from iteration 2, silently
  mislabelling the whole resumed trace. That file is now written at every
  checkpoint, so an interrupted run resumes from — and is labelled from — its
  last checkpoint.
* `ExtractIterations()`'s absolute `burnIn` (an integer `>= 1`) now checks
  the saved rows of every selected run, not just the run with the most. A run
  that `burnIn` fully discards now warns naming that run, rather than being
  silently emptied and only surfacing later as an unrelated error.
* `ExtractParameters()`'s out-of-bound `selectRows` check now compares against
  the completed rows of the specific run being extracted, rather than the
  samples array's padded row count, so out-of-range rows for a shorter run
  are rejected instead of silently returning `NA`.
* `Cluster()`/`Cluster.StratPosterior()`'s `runIndex` (and `runs`) output is
  now built in ascending run-number order, matching `cluster`/`clusterList`,
  rather than in the order `runs` happened to be supplied in. Previously a
  non-ascending `runs` argument (e.g. `runs = c(3, 1)`) mislabelled which
  pooled rows belonged to which run.

* Continuing a run with `RunStratModel()` no longer re-opens a fresh
  proposal-adaptation window by default. Previously a continuation recomputed
  `startAdapting`/`endAdapting` relative to the new segment, so retained
  post-continuation samples could be drawn under a still-adapting (non-Markov)
  kernel that the default `burnIn = 0.5` did not exclude, that fraction being
  taken over cumulative completed iterations. The previous run's already-elapsed
  window is now reused unless `adaptProposal`, `startAdapting` or `endAdapting`
  is supplied explicitly. An explicit `adaptTemperatures = TRUE` (or
  `adapt = TRUE`) also counts as asking to keep adapting: proposal and
  temperature adaptation share one window and cannot be re-armed independently.
* Continuation arguments left unspecified now inherit the previous run's setting
  rather than resetting to their `StratMCMC()`/`RunStratModel()` function
  default. `RunStratModel(result, nIter = 500)` previously reset `tempering`,
  `bactrianM`, `nThin`, `adaptTemperatures` and the other shared arguments,
  silently changing the configuration mid-run. Passing an argument explicitly
  still overrides the inherited value. "Left unspecified" is judged from the
  call rather than the value, so writing an argument equal to its own default
  counts as supplying it.
* Together these mean a continued run may sample under a different kernel than
  the same call produced in earlier versions, and is not directly comparable
  with one recorded before this change.

* Administrative version bump (expiry date renewal).

# StratoBayes 0.2.0.9002

## NUTS/HMC: bounded-parameter reparameterisation (#349)

* **NUTS and HMC now sample bounded parameters in an unconstrained space**, so a
  proposal can no longer overshoot a hard prior boundary (e.g. the non-negative
  `gap`/hiatus parameter, or any `Uniform`/`LogNormal`/`TruncNormal`/
  `TruncLogNormal` prior). Previously such boundaries were an "energy cliff" that
  the gradient sampler hit as divergences. The transform is applied *inside the
  C++ NUTS/HMC integrator only*: the posterior target is unchanged and the stored
  `logPost` is byte-identical, so **models with only unbounded (Normal) priors are
  unaffected**. For models with a bounded parameter the NUTS/HMC sample paths (and
  therefore the samples) change; the MH sampler is unchanged.

## Correctness fix — alignment posterior (Metropolis-within-Gibbs)

* **The alignment-parameter posterior is now correct (default C++ engine).** The
  Metropolis step that updates the alignment parameters (per-site `alpha` offsets
  and `gammaLog` inverse sedimentation rates) previously drew fresh spline
  coefficients `beta` from their Gibbs full conditional *and* accepted on the
  joint ratio, omitting the pseudo-marginal Hastings weight for that `beta` draw.
  This broke detailed balance and left the alignment marginal **over-dispersed**
  (missing the `det`-based Occam factor that penalises alignments where `beta` is
  sharply determined). The kernel now accepts on the **beta-marginal** likelihood
  (`beta` integrated out analytically), with one Gibbs sweep of
  `beta, sigma, lambda | a` per iteration. On a converged closed-form calibration
  the alignment posterior sd went from 1.75x the analytic value to within 0.3%.

* **`logPost` traces are now the beta-marginal log-density, not the joint at a
  point value of `beta`.** The `posterior` and `likelihood_spline` columns of the
  MCMC output (C++ engine) therefore change in both value and units and are **not
  comparable to pre-fix traces**. Relative comparisons within a run are unaffected.

* Prior alignment analyses may have reported **over-dispersed** (occasionally
  under-dispersed, configuration-dependent) alignment uncertainty. Re-running
  affected analyses is recommended; pin a released version to reproduce an
  earlier analysis exactly.

* This applies to **both** engines. The default C++ engine was fixed first; the
  opt-in `engine = "R"` reference engine (used for debugging and as the
  correctness oracle) shared the identical bug and now carries the same
  beta-marginal fix, so its alignment MH kernel, its HMC/NUTS paths, and its
  `logPost` traces match the C++ engine's corrected behaviour. Its `logPost`
  traces are likewise now the beta-marginal log-density (not comparable to
  pre-fix `engine = "R"` traces).

## Component-selective ("partial") parallel tempering

* New `temperingComponents` argument in `StratMCMC()`. `"full"` (default) tempers
  the whole posterior (previous behaviour). The **component-selective** options
  temper only a chosen subset of the log-posterior and hold the rest at full
  (T = 1) strength: `"signal"` tempers the signal-fit likelihood only; `"ties"`
  the radiometric ties / absolute-age constraints only; `"signal+ties"` both.
  The idea is to flatten exactly the component(s) that create the multimodality
  barrier — keeping the rest anchored — which can explore multimodal age–depth
  posteriors more efficiently than full tempering when the barrier is
  component-localised (following Kjellson et al. 2026). Choose the subset that
  contains every barrier-contributing component (holding one at T = 1 blocks
  crossing it). Internally a component mask over `logPostSep = [prior, signal,
  ties, overlap]`; `"full"` reproduces whole-posterior tempering exactly.
  **Note:** `"ties"`/`"signal+ties"` are MH-only for now — enabling gradient
  (HMC/NUTS) proposals with them raises an error until component-selective
  gradient tempering lands.

* The **sampled target is the same** under both settings — at T = 1 every
  partial-tempering formula reduces to the full one, so a single cold chain (no
  swaps) produces a bit-identical trace under `"full"` and `"signal"` (verified for
  both MH and NUTS proposals). In a multi-chain run the cold chain receives
  different swapped states, so its samples differ by design; what is unchanged is
  the *cold-chain target*, up to the pragmatic hot-chain approximation below (the
  same approximation class as existing full tempering).

* Implemented across the within-chain MH accept ratio, the prior-independence
  proposal, the replica-swap ratio, and the HMC/NUTS Hamiltonian (C++ engine).
  The hot-chain σ/λ Gibbs draws remain untempered — the same approximation the
  existing full-tempering already makes — so hot chains are the same approximation
  class as before; the exact tempered-(σ,λ) refinement is a documented follow-up.
  Correctness derivation: `dev/red-team/proofs/partial-tempering-correctness.md`.
  Currently supported by the C++ engine only, and now reachable through
  `RunStratModel()` as well as `StratMCMC()`.

* Red-team hardening of the feature (findings RT-302–RT-305):
  - RT-302: the NUTS inner sub-tree recursion dropped the `signalScale`
    argument, so on hot chains (β < 1) the inner half of every tree of depth ≥ 1
    was integrated against the untempered joint — a detailed-balance break (inert
    at T = 1, hence missed by the bit-identity test). Now forwarded.
  - RT-303: a continued run silently reverted `"signal"` → `"full"`; the
    `signalOnly` flag is now carried across continuation.
  - RT-304: temperature-ladder adaptation is now tuned against the same
    signal-only swap energy the replica swap uses under `"signal"`.
  - RT-305: `temperingComponents` is now a `RunStratModel()` argument (was only
    settable via a hand-built `StratMCMC` object).
  - The MH-only restriction on `"ties"`/`"signal+ties"` is rejected when the
    engine is built, not part-way through the run, so an unsupported combination
    fails immediately instead of after the first gradient proposal is drawn.

## MCMC mixing improvements

* Fixed an inverted sign in the adapted HMC/NUTS mass-matrix metric. During
  warm-up the inverse mass matrix `M^{-1}` was set to the *inverse* of the
  empirical parameter covariance (`M^{-1} = Σ^{-1}`) instead of the covariance
  itself (`M^{-1} = Σ`), producing the worst-conditioned metric — tiny leapfrog
  steps in wide posterior dimensions and large steps in narrow ones. The
  stationary distribution was unaffected, so only mixing efficiency was
  degraded; adapted-HMC/NUTS chains will now differ at a fixed seed.

* `onlyMultivariateProposalsAfterAdapt` now defaults to `FALSE`. Previously
  the cold chain was restricted to the Multivariate proposal after
  `endAdapting`, which caused zero acceptance (and frozen chains) when the
  cluster covariance was dominated by burn-in dispersion. With the new default,
  Univariate, ShiftAlphas, NeighbourScaled, and SiteBlock proposals remain
  active post-adapt as a fallback, keeping the chain mobile when the
  Multivariate proposal temporarily over-shoots.

* The minimum Multivariate proposal probability post-adapt is reduced from 50%
  to 20%, giving the working fallback proposals (NeighbourScaled, SiteBlock)
  a larger share of the post-adapt budget when the Multivariate proposal's
  cluster covariance has not yet converged.

* New optional `enablePostAdaptDecay` flag (default `FALSE`) for continuing
  `proposalFactor` adaptation post-`endAdapting` with a `1/sqrt(t)` diminishing
  envelope (Roberts & Rosenthal 2007) and clearing the Multivariate acceptance
  buffer at `endAdapting`. Default behaviour remains the hard freeze of
  `proposalFactor` at `endAdapting`. Comparative runs on real datasets did not
  show a consistent benefit from enabling decay; flag is retained for further
  investigation.

* New optional `enableRingBuffer` flag (default `FALSE`) for storing chain
  history in a chronological ring buffer (oldest entry overwritten first), so
  `recentFraction` in `.ClustInfo` selects the temporally most recent samples.
  Default behaviour remains random-replacement reservoir sampling. Comparative
  runs did not show a consistent benefit from the ring buffer; flag is
  retained for further investigation.

* When `parametersInitial = NULL` (the default), α parameters are now
  initialised by drawing uniformly from the 95% mass interval of their prior
  rather than from the full Normal, avoiding prior-dominated no-overlap basins
  where the log-likelihood is flat and the chain cannot escape.

## Gradient-based proposals (HMC / NUTS)

* New NUTS (No-U-Turn Sampler) proposal type, automatically enabled when
  `flexibleKnots = FALSE`. Uses gradient information to make larger,
  less-correlated moves through parameter space, improving mixing for
  models with many parameters.

* Full C++ NUTS implementation with recursive tree doubling, multinomial
  candidate selection, and U-turn detection — runs natively in the C++
  engine for best performance.

* HMC (fixed-length leapfrog) also available as a proposal type,
  sharing the same gradient infrastructure.

* Dual averaging step-size adaptation for both HMC and NUTS, with
  automatic mass matrix estimation from the adaptation window.

* Analytic gradient of the log-posterior with respect to all free
  parameters, computed via reverse-mode differentiation through the
  age-conversion pipeline. Supports models with ties (tie-point
  gradient handled natively in C++). Custom priors fall back to
  finite-difference gradient.

* `flexibleKnots` and `knotRange` parameters documented in
  `StratModel()` and `RunStratModel()`.

* Cost-aware adaptive proposal weighting: during tuning, per-proposal
  wall-clock time is tracked and used to penalise expensive proposal
  types (sqrt penalty on relative time cost). This allows NUTS to be
  registered alongside MH proposals and automatically downweighted when
  its per-iteration cost outweighs the mixing benefit.

* `.GenerateInitialState()` now errors after 500 failed attempts
  instead of looping indefinitely when `knotRange` is incompatible
  with the prior. The error message advises widening `knotRange` or
  setting `flexibleKnots = TRUE`.

* When `knotRange` is not specified, it is now auto-computed from the
  reference-section data range with 25% symmetric padding. This is
  deterministic and keeps knot density concentrated within the data
  range. Previous versions required `knotRange` to be set manually.

## Bactrian proposal kernels

* Metropolis–Hastings proposals now use Bactrian kernels (Yang &
  Rodríguez, 2013) by default. The Bactrian kernel is a mixture of two
  displaced Gaussians that suppresses near-zero proposal steps, improving
  mixing efficiency. Applied to univariate, multivariate, and all
  alpha-shift proposal types in both R and C++ engines. Gibbs and
  HMC/NUTS proposals are unaffected.

* New `bactrianM` parameter in `StratMCMC()` controls the kernel shape
  (default 0.95). Set `bactrianM = 0` to fall back to standard Gaussian
  proposals.

## C++ MCMC engine

* New persistent C++ MCMC engine (`MCMCEngine.cpp`) replaces the R hot loop,
  with C++ implementations of log-posterior evaluation, proposal generation,
  Gibbs sampling, B-spline design matrix construction, and height–age
  conversion.

* Intra-run chain parallelism via `std::thread` — multiple tempered chains
  execute in parallel within a single `RunStratModel()` call (#236).

* Parallel tempering now works correctly for models with tie-point
  constraints: native C++ density evaluation for Normal, Uniform, LogNormal,
  Gamma, Beta, Cauchy, and Student-t tie densities; unsupported densities
  fall back to per-tie R callbacks.

* Pre-built ties dispatch table eliminates per-iteration `match.fun()` /
  `formals()` overhead.

* Cache B'B and B'y products on the rejection path to avoid redundant
  Gibbs recomputation.

* Early per-site overlap connectivity check rejects proposals before
  spline/Gibbs computation when sites are insufficiently connected.

* Hot-loop timing instrumentation (opt-in) for profiling.

## Dependency reduction

* **Removed from Imports:** `RcppEigen`, `mvnfast`, `EnvStats`, `fda`,
  `msm`, `Rfast`, `collapse`, `MASS`, `doParallel`, `foreach`.

* **Moved to Suggests:** `SDAR`, `ks`, `shiny`, `shinyjs`, `bslib`,
  `mcmcse`, `coda`.

* **Added to Suggests:** `future`, `future.apply` (used for independent
  multi-run parallelism, replacing `doParallel`/`foreach`).

* Internal replacements for removed packages: `.rmvn1()` (MVN sampling),
  `.bsplinepen()` (B-spline penalty matrix), `.rtnorm()` / `.dtnorm()` /
  `.qtnorm()` (truncated normal), `.rlnormTrunc()` / `.qlnormTrunc()`
  (truncated lognormal).

* Custom lightweight linear algebra header (`sb_linalg.h`) replaces
  RcppEigen (#237).

## Bug fixes

* `summary.StratPosterior()` no longer enters infinite recursion on freshly
  created objects (T-089).

* `StratMap()` quantile calculation no longer crashes due to partial argument
  matching (T-082).

* `.PlotParameter()` list indexing now works correctly with non-contiguous
  `plotRuns` (T-083).

* `.AgeConversionBatch()` correctly reorders results for unsorted height
  inputs (T-081).

* Univariate proposal argument length now handled correctly when `Fixed()`
  priors are present (T-106).

* `temperingSwaps` vector sized by `endIter`, not `nIter`, fixing
  out-of-bounds writes in continued runs (T-107).

* `adaptProposal` vector check uses `any()` instead of `isTRUE()` (T-059).

* Seed handling is now consistent for duplicate-seed and parallel-run
  scenarios (T-049).

* Ring buffer in `sb_run_block` resized to fit a full batch (T-069).

* `signalSectionOverlap` included in C++ engine state extraction (T-068).

* `.match.hash` attributes stripped in `rowIndex` comparison (T-105).

## Performance

* `BayesianSpline()` Gibbs loop moved entirely into C++ (`.sb_gibbs_spline`),
  eliminating per-iteration R ↔ C++ overhead. The B-spline design matrix is
  now built by the C++ `.sb_spline_design` routine (replacing
  `splines::splineDesign`), and the `B'B` / `B'y` cross-products are
  precomputed once in `.ModelBspline()` instead of being recomputed every
  iteration (profiling showed `crossprod` was ~33% of self-time). The retained
  R reference (`.GibbsSampleBspline()`) is exercised in the test suite as the
  correctness baseline. End-to-end **~13–19× faster** (e.g. n=100/k=25:
  72 → 5.4 ms; n=300/k=40: 199 → 10.4 ms per fit).

* Gibbs sampler for individual spline pre-fitting (`.GibbsSampleBspline()`)
  rewritten to use a single Cholesky decomposition with triangular solves,
  replacing the previous decompose → invert → re-decompose path. ~14×
  faster per iteration.

* Reduced default `individualSplineIter` from 2000 to 500 in `StratModel()`.
  Profiling showed σ estimates stabilise well within 100 iterations; 500
  provides a comfortable margin while cutting pre-fit time by 75%.

* Adaptation-phase batching in `RunStratModel()`: iterations between
  adaptation checkpoints are now dispatched to the C++ engine in batches
  (up to 50), rather than one at a time. This reduces R ↔ C++ round-trips
  by ~98% during adaptation and allows thread parallelism to take effect
  throughout the run.

* Loop-invariant `mcmc` fields hoisted above the main MCMC loop; ring
  buffer accumulation matrices (acceptance monitoring, timing, tempering
  ratios) extracted into locals before inner loops and written back once.
  Cuts ~4 800 nested-list traversals per batch to ~4.

* `.SaveMCMChistory()` loop-invariant computations hoisted; new C++
  `isDuplicateInHistory()` replaces the R wrapper + two matrix-subsetting
  copies per chain per call.

* Combined effect on a 12-chain, 20 000-iteration age model: **61%
  wall-time reduction** at 2 threads (102 s → 40 s). With the list-access
  and history-save optimizations, a 2 000-iteration benchmark drops a
  further **~56%** (3.2 s → 1.3 s at 2 threads).

## Other changes

* Removed unused `seed` argument from `.InnerRunMCMC()`.

* Spelling corrections and new `WORDLIST` for package spell-checking.
