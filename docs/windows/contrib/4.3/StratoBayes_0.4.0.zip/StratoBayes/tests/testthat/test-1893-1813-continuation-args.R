# #1893: a continuation takes `nRun` from the stored run, so a supplied value is
# discarded and `seed` is validated against a count the caller never gave.

test_that(".CheckSeed names the stored nRun on a continuation", {
  expect_error(
    StratoBayes:::.CheckSeed(c(1, 2, 3), 1, continued = TRUE),
    "3 seeds.*`nRun = 1`.*stored"
  )
  expect_error(
    StratoBayes:::.CheckSeed(c(1, 2, 3), 1),
    "seed must be a numeric of length `nRun`"
  )
})

test_that("RunStratModel warns that a supplied nRun is ignored on a continuation", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 2, nChains = 2, nThreads = 1L, visualise = FALSE,
                      seed = 1, runParallel = FALSE, quiet = TRUE)

  expect_warning(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                  nRun = 3, nIter = 2, nThreads = 1L, visualise = FALSE,
                  quiet = TRUE),
    "`nRun = 3` is ignored.*1 run"
  )
  expect_error(
    RunStratModel(r1, seed = c(1, 2, 3), nIter = 2, nThreads = 1L,
                  visualise = FALSE, quiet = TRUE),
    "`nRun = 1`.*stored"
  )
})

# #1813: a new run has no checkpoint, so nothing but NULL may reach
# `.UpdateMCMCforContinuedRun()`'s `mcmc`, whatever `stratMCMC` holds.
test_that("a new run passes no checkpoint to .UpdateMCMCforContinuedRun", {
  seen <- new.env()
  seen[["calls"]] <- list()
  real <- StratoBayes:::.UpdateMCMCforContinuedRun
  local_mocked_bindings(
    .UpdateMCMCforContinuedRun = function(mcmc, mcmcNew, newRun) {
      seen[["calls"]] <- c(seen[["calls"]],
                             list(list(newRun = newRun, mcmc = mcmc)))
      real(mcmc, mcmcNew, newRun)
    }
  )
  template <- StratMCMC(stratModel1, nIter = 2, nChains = 2, nThreads = 1L)
  RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = template,
                nRun = 1, nThreads = 1L, visualise = FALSE,
                seed = 1, runParallel = FALSE, quiet = TRUE)

  calls <- seen[["calls"]]
  expect_length(calls, 1L)
  expect_true(calls[[1]][["newRun"]])
  expect_null(calls[[1]][["mcmc"]])
})
