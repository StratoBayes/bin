# #1652: the C++ `nuts_u_turn` is the production U-turn criterion, and nothing
# pinned it. Its frozen R twin `.NUTSUTurn` contracts the span with the
# velocity M^-1 r; the C++ criterion uses the raw momentum r and must stay so
# (RT-375). These values discriminate the two.

test_that("C++ nuts_u_turn contracts the span with the raw momentum (#1652)", {
  UTurn <- StratoBayes:::.sb_nuts_u_turn

  # dq = (1, 1), r = (1000, -100): dq . r = 900 > 0, so no U-turn. The
  # velocity metric under M^-1 = diag(0.01, 1) gives dq . v = -90 < 0 and
  # would call a U-turn, as `.NUTSUTurn` does in test-nuts.R.
  r <- c(1000, -100)
  expect_false(UTurn(c(0, 0), c(1, 1), r, r))
  expect_true(StratoBayes:::.NUTSUTurn(c(0, 0), c(1, 1), r, r,
                                       massMatInv = c(0.01, 1)))

  # Either end turning back is enough.
  expect_true(UTurn(c(0, 0), c(1, 1), c(-1, 0), c(1, 1)))
  expect_true(UTurn(c(0, 0), c(1, 1), c(1, 1), c(0, -1)))
  expect_false(UTurn(c(0, 0), c(1, 1), c(1, 1), c(1, 1)))

  # The comparison is strict: an orthogonal end is not a U-turn.
  expect_false(UTurn(c(0, 0), c(1, 1), c(1, -1), c(1, -1)))

  # Every coordinate contributes.
  expect_true(UTurn(c(0, 0, 0), c(1, 1, 1), c(1, 1, -3), c(1, 1, 1)))
  expect_false(UTurn(c(0, 0, 0), c(1, 1, 1), c(1, 1, -1.5), c(1, 1, 1)))

  expect_error(UTurn(c(0, 0), c(1, 1), 1, c(1, 1)), "equal length")
})
