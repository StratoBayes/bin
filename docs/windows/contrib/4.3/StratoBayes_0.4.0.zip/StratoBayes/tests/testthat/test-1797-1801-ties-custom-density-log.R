# A custom tie densityFun is always called with log = TRUE
# (R/ModelFunctions.R). A density that swallows extra args via '...' but has
# no literal 'log' formal silently discards that argument and returns the raw
# (non-log) density instead of erroring (#1797). Separately,
# .GetArgsAfterXBeforeLog() was counting the literal '...' as if it were a
# named argument requiring its own arg* value (#1801).

customTies <- function(densityFun, arg1 = 0.5, arg2 = NA_real_) {
  data.frame(site = "a", height = 5, densityFun = densityFun,
             arg1 = arg1, arg2 = arg2, stringsAsFactors = FALSE)
}

test_that(".CheckTies() rejects a densityFun with '...' but no 'log' formal (#1797)", {
  dDots <- function(x, rate, ...) rate * exp(-rate * (x - 0))
  assign("dDots", dDots, envir = globalenv())
  on.exit(rm("dDots", envir = globalenv()))

  expect_error(
    .CheckTies(customTies("dDots", arg1 = 0.5), "height", "site"),
    "log"
  )
})

test_that(".CheckTies() rejects a densityFun with neither '...' nor 'log' (#1797)", {
  dNoLog <- function(x, rate) rate * exp(-rate * (x - 0))
  assign("dNoLog", dNoLog, envir = globalenv())
  on.exit(rm("dNoLog", envir = globalenv()))

  expect_error(
    .CheckTies(customTies("dNoLog", arg1 = 0.5), "height", "site"),
    "log"
  )
})

test_that(".CheckTies() accepts a one-parameter '...'-using densityFun with a literal 'log' formal (#1797, #1801)", {
  dDotsLog <- function(x, rate, ..., log = FALSE) {
    d <- rate * exp(-rate * (x - 0))
    if (log) base::log(d) else d
  }
  assign("dDotsLog", dDotsLog, envir = globalenv())
  on.exit(rm("dDotsLog", envir = globalenv()))

  # Before #1801's fix, .GetArgsAfterXBeforeLog() returned c("rate", "..."),
  # demanding a non-NA arg2 for the phantom '...' argument and failing this
  # otherwise-valid one-parameter density with "arg2 cannot be NA".
  checked <- .CheckTies(customTies("dDotsLog", arg1 = 0.5, arg2 = NA_real_),
                        "height", "site")
  expect_identical(checked[["densityFun"]], "dDotsLog")
  expect_equal(checked[["arg1"]], 0.5)
})

test_that(".GetArgsAfterXBeforeLog() drops the literal '...' from the required-argument list (#1801)", {
  expect_identical(.GetArgsAfterXBeforeLog(c("x", "rate", "...", "log")),
                   "rate")
  expect_identical(.GetArgsAfterXBeforeLog(c("x", "rate", "...")),
                   "rate")
})
