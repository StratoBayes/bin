# Static checks on CI/build config that plain R CMD check can't catch.
# These files aren't executed by testthat directly; the assertions read
# them as text and pin the specific defects #1824/#1826/#1666/#1668
# reported, since the actual behaviour can only be exercised by a live
# GHA run (see PR body for how each was verified there).
#
# .github/ is .Rbuildignore'd and .Rbuildignore itself is excluded from
# the built package tree by R's own build process, so R CMD check never
# carries either -- only a source-tree devtools::test()/test_file() run
# can see them, hence the skip guard.

.repo_root_file <- function(path) {
  testthat::test_path("..", "..", path)
}

skip_if_repo_root_missing <- function(path) {
  skip_if_not(file.exists(.repo_root_file(path)),
              "not running against the git source tree")
}

test_that("#1824: check-gha's setup-r step doesn't also request use-public-rspm", {
  skip_if_repo_root_missing(".github/workflows/R-CMD-check.yaml")
  lines <- readLines(.repo_root_file(".github/workflows/R-CMD-check.yaml"))
  gha_start <- grep("^  check-gha:", lines)
  gha_end <- grep("^  notify-nightly-failure:", lines)
  block <- lines[gha_start:(gha_end - 1L)]
  expect_true(any(grepl("^\\s*RSPM:", block)))
  expect_false(any(grepl("use-public-rspm", block)))
})

test_that("#1826: check-green's run query paginates", {
  skip_if_repo_root_missing(".github/workflows/build-binaries.yml")
  lines <- readLines(.repo_root_file(".github/workflows/build-binaries.yml"))
  query_line <- grep("R-CMD-check-all-systems\\.yaml/runs\\?head_sha=", lines, value = TRUE)
  expect_length(query_line, 1L)
  expect_true(grepl("--paginate", query_line))
})

test_that("#1666: the non-functional --no-build-vignettes flag is gone", {
  for (wf in c("build-binaries.yml", "build-shiny-binaries.yml")) {
    skip_if_repo_root_missing(file.path(".github/workflows", wf))
    lines <- readLines(.repo_root_file(file.path(".github/workflows", wf)))
    install_line <- grep("R CMD INSTALL --build", lines, value = TRUE)
    expect_length(install_line, 1L)
    expect_false(grepl("--no-build-vignettes", install_line))
  }
})

test_that("#1668: .Rbuildignore has no unanchored regex entries", {
  skip_if_repo_root_missing(".Rbuildignore")
  lines <- readLines(.repo_root_file(".Rbuildignore"))
  lines <- lines[nzchar(lines)]
  anchored <- grepl("^\\^.*\\$$", lines)
  expect_true(all(anchored), info = paste(lines[!anchored], collapse = ", "))
})

test_that("#1668: tightening .Rbuildignore doesn't newly include .lintr-ci", {
  skip_if_repo_root_missing(".Rbuildignore")
  lines <- readLines(.repo_root_file(".Rbuildignore"))
  expect_true(any(grepl("^\\^\\\\\\.lintr-ci\\$$", lines)))
})
