test_that(".BuildFormationSpline refuses fewer basis functions than it builds (#1914)", {
  expect_error(.BuildFormationSpline(0, 10, 3L, 1L), "at least 4")
  expect_equal(.BuildFormationSpline(0, 10, 6L, 1L)[["nBasis"]], 6L)
})

test_that(".CreateSplineS refuses a zero-width flexible-knot age range (#1833)", {
  local_mocked_bindings(
    .EnsurePreExtracted = function(data) data,
    .MetroPriorMedians = function(metroPriors) numeric(0),
    .sb_age_convert = function(data, ind, parameters) {
      list(signal = list(c(5, 5, 5)))
    }
  )
  expect_error(
    .CreateSplineS(6L, NULL, TRUE, list(), list(sedSmooth = FALSE), list()),
    "positive span"
  )
})

test_that("BayesianSpline rejects duplicated knots (#1743)", {
  set.seed(1743)
  x <- c(rep(0, 20), seq(0.5, 10, length.out = 40))
  y <- sin(x) + rnorm(60, 0, 0.2)
  tiedKnots <- quantile(x, seq(0, 1, length.out = 8), names = FALSE)
  expect_error(BayesianSpline(x, y, knots = tiedKnots, nIter = 5),
               "distinct")
  expect_error(BayesianSpline(x, y, knots = c(0, 2, 2, 5, 10), nIter = 5),
               "distinct")
  expect_type(BayesianSpline(x, y, knots = unique(tiedKnots), nIter = 5),
              "list")
})
