# GH #1107, #1108, #1111, #1112, #1113: construction-time validation gaps.

test_that("GH #1107: a partition named after the gap sentinel is rejected", {
  parts <- partsData1
  parts[["partition"]][parts[["partition"]] == "limestone"] <- .GapLabel
  expect_error(StratData(signal = signalData1, parts = parts),
               .GapLabel, fixed = TRUE)
  expect_error(StratData(signal = signalData1, parts = parts),
               "reserved")
})

test_that("GH #1107: a partition name that merely resembles it is fine", {
  parts <- partsData1
  parts[["partition"]][parts[["partition"]] == "limestone"] <- "unconformity"
  expect_s3_class(suppressMessages(StratData(signal = signalData1,
                                             parts = parts)),
                  "StratData")
})

test_that("GH #1112: `.bsplinepen()` rejects degenerate knot vectors", {
  expect_error(.bsplinepen(rep(1, 5)), "positive range")
  expect_error(.bsplinepen(seq(10, 0, length.out = 5)), "non-decreasing")
  expect_silent(.bsplinepen(seq(0, 10, length.out = 5)))
  # repeated knots stay legal: `.CreateSplineBaseBspline()` accepts them
  expect_silent(.bsplinepen(c(0, 0, 5, 10, 10)))
})

test_that("GH #1111: `minSignalOverlap` is validated", {
  Build <- function(...) {
    suppressMessages(
      StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                 sedModel = "site", alphaPosition = "bottom", nKnots = 15,
                 sigmaFixed = 1, ...)
    )
  }
  expect_error(Build(minSignalOverlap = c(2, 3)), "minSignalOverlap")
  expect_error(Build(minSignalOverlap = NULL), "minSignalOverlap")
  expect_error(Build(minSignalOverlap = -5), "positive whole number")
  expect_error(Build(minSignalOverlap = 2.7), "positive whole number")
  expect_s3_class(Build(minSignalOverlap = 2L), "StratModel")
})

test_that("GH #1111: a negative `penaltyMultiplier` is rejected", {
  expect_error(
    suppressMessages(
      StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                 sedModel = "site", alphaPosition = "bottom", nKnots = 15,
                 sigmaFixed = 1, overlapPenalty = TRUE,
                 penaltyMultiplier = -1)
    ),
    "penaltyMultiplier"
  )
})

test_that("GH #1113: `individualSplineIter` must be a whole number", {
  expect_error(
    suppressMessages(
      StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                 sedModel = "site", alphaPosition = "bottom", nKnots = 15,
                 individualSplineIter = 5.5)
    ),
    "whole number"
  )
})

test_that("GH #1113: the spline burn-in discards exactly the first quarter", {
  # A mocked fitter returns sigma = 1, 2, ... nIter, so the mean over the
  # retained window is a closed form: it pins *which* iterations `selectIter`
  # keeps, without asserting anything about a real MCMC run.
  local_mocked_bindings(
    BayesianSpline = function(...) list(sigma = as.numeric(seq_len(list(...)[["nIter"]]))),
    .package = "StratoBayes"
  )
  Sigma <- function(nIter) {
    unname(suppressMessages(
      StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                 sedModel = "site", alphaPosition = "bottom", nKnots = 15,
                 sigmaFixed = TRUE, overlapPenalty = FALSE,
                 individualSplineIter = nIter)
    )[["sigmaFixed"]])
  }
  # mean(126:500); the pre-fix `seq(n/4, n, 1)` kept 125 too, giving 312.5
  expect_equal(Sigma(500), rep(313, length(Sigma(500))))
  # 4 does not divide 6: mean(2:6). The pre-fix `seq(n/4 + 1, n, 1)` counted
  # from 2.5, truncating to 2:5 and losing the last iteration entirely
  expect_equal(Sigma(6), rep(4, length(Sigma(6))))
})

test_that("GH #1108: a `Fixed` `priorsProposals` for a live param errors", {
  priors <- structure(
    list(alpha_site_2 = UniformPrior(min = -6, max = 12),
         alpha_site_3 = UniformPrior(min = -6, max = 12),
         gammaLog_site_2 = NormalPrior(mean = 0, sd = 0.7),
         gammaLog_site_3 = NormalPrior(mean = 0, sd = 0.7)),
    class = c("list", "StratPrior"))
  pp <- priors
  pp[["gammaLog_site_3"]] <- Fixed(0.3)

  expect_error(
    suppressMessages(
      StratModel(stratData1, priors = priors, priorsProposals = pp,
                 alignmentScale = "height", sedModel = "site",
                 alphaPosition = "bottom", nKnots = 15, sigmaFixed = 1)
    ),
    "gammaLog_site_3"
  )
})

test_that("GH #1108: numerically-equal `Fixed` values are accepted", {
  priors <- structure(
    list(alpha_site_2 = UniformPrior(min = -6, max = 12),
         alpha_site_3 = Fixed(5L),
         gammaLog_site_2 = NormalPrior(mean = 0, sd = 0.7),
         gammaLog_site_3 = NormalPrior(mean = 0, sd = 0.7)),
    class = c("list", "StratPrior"))
  pp <- priors
  pp[["alpha_site_3"]] <- Fixed(c(alpha_site_3 = 5))

  expect_s3_class(
    suppressMessages(
      StratModel(stratData1, priors = priors, priorsProposals = pp,
                 alignmentScale = "height", sedModel = "site",
                 alphaPosition = "bottom", nKnots = 15, sigmaFixed = 1)
    ),
    "StratModel"
  )
})

test_that("GH #1108: `parametersInitial` must agree with a `Fixed()` value", {
  priors <- structure(
    list(alpha_site_2 = UniformPrior(min = -6, max = 12),
         alpha_site_3 = Fixed(5),
         gammaLog_site_2 = NormalPrior(mean = 0, sd = 0.7),
         gammaLog_site_3 = NormalPrior(mean = 0, sd = 0.7)),
    class = c("list", "StratPrior"))
  m <- suppressMessages(
    StratModel(stratData1, priors = priors, alignmentScale = "height",
               sedModel = "site", alphaPosition = "bottom", nKnots = 15,
               sigmaFixed = 1))

  expect_error(
    StratMCMC(m, nIter = 2, nChains = 2, nThreads = 1L,
              parametersInitial = c(0, 99, 0, 0)),
    "alpha_site_3"
  )
})
