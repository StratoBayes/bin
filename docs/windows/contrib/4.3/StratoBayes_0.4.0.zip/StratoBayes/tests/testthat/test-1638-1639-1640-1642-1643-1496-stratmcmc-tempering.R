# Remaining validation gaps from red-team round 18 (2026-08-21), fixed after
# #1638 and #1639's other sub-issues were already covered on `main`.

data(stratModel1, package = "StratoBayes", envir = environment())

# ── #1638.1: a non-strict-logical adaptProposal falls between isTRUE()/== ───
# FALSE and silently produces an undocumented third adaptation mode instead
# of erroring, as RT-315 already does for `adapt`.

test_that("#1638: a non-logical adaptProposal errors", {
  expect_error(
    StratMCMC(stratModel1, nIter = 1000, nChains = 4, adaptProposal = 1),
    "adaptProposal"
  )
  expect_error(
    StratMCMC(stratModel1, nIter = 1000, nChains = 4, adaptProposal = "TRUE"),
    "adaptProposal"
  )
})

# ── #1638.3: RT-005's monitor warning tests the raw argument before the ─────
# adaptProposal = FALSE empty-window coercion forces adaptTemperatures
# FALSE, so it never fires when adaptTemperatures was left at its TRUE
# default. Gated on adaptProposal = FALSE, not just a short nIter: RT-628
# already established that a naturally short run's window collapse is silent
# (test-stratmcmc-validation-rt626.R) even with adaptTemperaturesMonitor and
# adaptTemperatures both TRUE (test-rt-lows-resume-continuation.R).

test_that("#1638: adaptTemperaturesMonitor warns when adaptProposal = FALSE empties the window", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 4, tempering = TRUE,
                      adaptProposal = FALSE, adaptTemperaturesMonitor = TRUE),
    "adaptTemperaturesMonitor"
  )
  expect_false(mcmc[[c("temper", "adaptTemperatures")]])
})

test_that("#1638: adaptTemperaturesMonitor does not warn on a naturally short run", {
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 10, nChains = 3, tempering = TRUE,
              adaptTemperatures = TRUE, adaptTemperaturesMonitor = TRUE)
  )
})

# ── #1638.4: the adaptProposal = FALSE continuation branch had no ───────────
# startAdapting <= endAdapting normalisation, unlike the isTRUE(adaptProposal)
# branch's own cap.

test_that("#1638: a continuation past its adaptation window is not inverted", {
  first <- StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                     startAdapting = 10, endAdapting = 200)
  mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 1,
                    stratMCMC = first, completedIter = 5,
                    adaptProposal = FALSE)
  expect_lte(mcmc[["startAdapting"]], mcmc[["endAdapting"]])
})

# ── #1639: -Inf in the hottest slot is not NA/NaN, so it passed validation ──
# and was silently treated as a legitimate rung.

test_that("#1639: -Inf in the top rung errors", {
  expect_error(
    StratMCMC(stratModel1, nIter = 1000, nChains = 4, tempering = TRUE,
              temperatures = c(1, 2, 4, -Inf)),
    "-Inf"
  )
})

# ── #1640: five logical arguments accepted NA unvalidated ───────────────────

test_that("#1640: five logical arguments reject NA", {
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1, saveMCMC = NA))
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         scaleMultivariateProposals = NA))
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         enablePostAdaptDecay = NA))
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         enableRingBuffer = NA))
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         adaptTemperaturesMonitor = NA))
})

# ── #1642: completedIter accepted a fractional value ────────────────────────

test_that("#1642: a fractional completedIter errors", {
  first <- StratMCMC(stratModel1, nIter = 1000, nChains = 1)
  expect_error(
    StratMCMC(stratModel1, nIter = 100, nChains = 1,
              stratMCMC = first, completedIter = 100.5),
    "completedIter"
  )
})

# ── #1643/#1496: a supplied temperatures ladder or adaptTemperaturesMonitor ─
# are silently discarded when tempering = FALSE or nChains == 1.

test_that("#1643: a discarded temperatures ladder warns", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = FALSE,
                      temperatures = c(1, 5, 25, 100)),
    "temperatures"
  )
  expect_equal(mcmc[[c("temper", "temperatures")]], rep(1, 4))
})

test_that("#1496: a discarded adaptTemperaturesMonitor warns", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = FALSE,
                      adaptTemperaturesMonitor = TRUE),
    "adaptTemperaturesMonitor"
  )
  expect_false(mcmc[[c("temper", "adaptTemperaturesMonitor")]])
})

test_that("#1643/#1496: neither warns when there is nothing to discard", {
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = FALSE)
  )
})
