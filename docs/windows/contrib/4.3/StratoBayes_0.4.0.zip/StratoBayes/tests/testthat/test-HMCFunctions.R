# ── .NUTSUTurn: U-turn detection ─────────────────────────────────────────

test_that(".NUTSUTurn detects U-turn when trajectory doubles back", {
  # Momentum opposite to displacement => U-turn
  expect_true(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(-1, 0), r_plus = c(1, 0)
  ))
  expect_true(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(1, 0), r_plus = c(-1, 0)
  ))
})

test_that(".NUTSUTurn returns FALSE when trajectory is still expanding", {
  # Both momenta point in direction of displacement => no U-turn
  expect_false(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(1, 0), r_plus = c(1, 0)
  ))
})

test_that(".NUTSUTurn handles 1D case", {
  expect_false(.NUTSUTurn(q_minus = 0, q_plus = 1, r_minus = 1, r_plus = 1))
  expect_true(.NUTSUTurn(q_minus = 0, q_plus = 1, r_minus = -1, r_plus = 1))
})

# ── .LogSumExp ──────────────────────────────────────────────────────────

test_that(".LogSumExp computes log(exp(a) + exp(b)) accurately", {
  expect_equal(.LogSumExp(0, 0), log(2))
  expect_equal(.LogSumExp(1, 2), log(exp(1) + exp(2)), tolerance = 1e-12)
  # log(1 + 1) = log(2)
  expect_equal(.LogSumExp(log(1), log(1)), log(2), tolerance = 1e-12)
})

test_that(".LogSumExp handles extreme values without overflow", {
  # large values: naive exp(1000) overflows, but LogSumExp should not
  result <- .LogSumExp(1000, 1000)
  expect_equal(result, 1000 + log(2), tolerance = 1e-12)
})

test_that(".LogSumExp handles -Inf", {
  expect_equal(.LogSumExp(-Inf, 0), 0)
  expect_equal(.LogSumExp(0, -Inf), 0)
  expect_equal(.LogSumExp(-Inf, -Inf), -Inf)
})

# RT-345: before the fix, a +Inf input hit `exp(a - m) + exp(b - m)` with
# `m == +Inf`, producing `exp(Inf - Inf) = NaN` for the infinite side and
# hence `log(NaN) = NaN` overall -- no current call site (HMCFunctions.R
# :982, :1156) reaches this, both gate on `is.finite()` first, but the
# function itself should still be robust to a future ungated caller.
test_that(".LogSumExp handles +Inf without producing NaN (RT-345)", {
  expect_equal(.LogSumExp(Inf, 0), Inf)
  expect_equal(.LogSumExp(0, Inf), Inf)
  expect_equal(.LogSumExp(Inf, Inf), Inf)
  expect_equal(.LogSumExp(Inf, -Inf), Inf)
})

# ── .HMCLeapfrog: leapfrog integrator ──────────────────────────────────

test_that(".HMCLeapfrog preserves Hamiltonian for simple harmonic oscillator", {
  # q'' = -q (standard harmonic oscillator)
  # gradFn returns gradient of log-posterior = -q (since logpost = -0.5 q^2)
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }

  q0 <- 1.0
  p0 <- 0.0
  grad0 <- -q0

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 0.01, nSteps = 100,
    massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0
  )

  # Hamiltonian should be approximately conserved
  H0 <- 0.5 * q0^2 + 0.5 * p0^2
  H1 <- 0.5 * result$q^2 + 0.5 * result$p^2
  expect_equal(H0, H1, tolerance = 1e-4)
  expect_false(result$divergent)
})

test_that(".HMCLeapfrog flags divergence when gradient fails", {
  gradFn <- function(fullParams) {
    list(ok = FALSE, grad = NA, logPost = NA)
  }

  result <- .HMCLeapfrog(
    q = 1, p = 0, grad = -1,
    stepSize = 0.1, nSteps = 3,
    massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = 1,
    temperature = 1.0
  )

  expect_true(result$divergent)
  expect_equal(result$logPost, -Inf)
})

test_that(".HMCLeapfrog handles multi-dimensional case", {
  gradFn <- function(fullParams) {
    list(ok = TRUE, grad = -fullParams, logPost = -0.5 * sum(fullParams^2))
  }

  q0 <- c(1, 0.5)
  p0 <- c(0, 0)
  grad0 <- -q0

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 0.01, nSteps = 50,
    massMatInv = c(1, 1),
    gradFn = gradFn,
    freeIdx = 1:2, fullParams = q0,
    temperature = 1.0
  )

  expect_length(result$q, 2)
  expect_length(result$p, 2)
  expect_false(result$divergent)
})

# ── .HMCLeapfrog: Hamiltonian divergence diagnostic (RT-221) ────────────

test_that(".HMCLeapfrog flags energy blow-up (finite logPost) when H0 given", {
  # Harmonic oscillator: logPost = -0.5 q^2, grad = -q. The leapfrog map for a
  # unit oscillator is unstable for stepSize >= 2, so the trajectory blows up
  # while logPost stays finite (never NaN) and the gradient solver never fails.
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }

  q0 <- 1.0
  p0 <- 0.0
  grad0 <- -q0
  H0 <- 0.5 * q0^2 + 0.5 * p0^2  # = -logPost0 + K0 at temperature 1

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 2.5, nSteps = 8L,
    massMatInv = 1.0, gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0,
    H0 = H0, divergenceMax = 1000
  )

  # Not a hard integrator failure, and logPost is finite: this is exactly the
  # energy-blow-up-without-NaN case that the MH step rejects but that used to
  # leave nutsDivergent unset.
  expect_false(result$divergent)
  expect_true(is.finite(result$logPost))
  expect_true(result$hamiltonianDivergent)

  # Without H0 the diagnostic is skipped (backward-compatible default).
  resultNoH0 <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 2.5, nSteps = 8L,
    massMatInv = 1.0, gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0
  )
  expect_false(resultNoH0$divergent)
  expect_false(resultNoH0$hamiltonianDivergent)
})

test_that(".HMCLeapfrog flags NaN-gradient (finite logPost) as divergent", {
  # Failure mode (a): gradient becomes NaN mid-trajectory but logPost stays
  # finite and the solver reports ok = TRUE. Momentum -> NaN -> K_new NaN ->
  # deltaH NaN, caught by the !is.finite(deltaH) branch.
  gradFn <- function(fullParams) {
    list(ok = TRUE, grad = NaN, logPost = -5)
  }

  result <- .HMCLeapfrog(
    q = 1, p = 1, grad = -1,
    stepSize = 0.1, nSteps = 3L,
    massMatInv = 1.0, gradFn = gradFn,
    freeIdx = 1, fullParams = 1,
    temperature = 1.0,
    H0 = 1.0, divergenceMax = 1000
  )

  expect_false(result$divergent)          # solver never hard-failed
  expect_true(is.finite(result$logPost))  # NaN confined to the gradient
  expect_true(result$hamiltonianDivergent)

  # Skipped when H0 is absent.
  resultNoH0 <- .HMCLeapfrog(
    q = 1, p = 1, grad = -1,
    stepSize = 0.1, nSteps = 3L,
    massMatInv = 1.0, gradFn = gradFn,
    freeIdx = 1, fullParams = 1,
    temperature = 1.0
  )
  expect_false(resultNoH0$hamiltonianDivergent)
})

test_that(".HMCLeapfrog does not flag a well-conserved trajectory", {
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }
  q0 <- 1.0
  p0 <- 0.3
  grad0 <- -q0
  H0 <- 0.5 * q0^2 + 0.5 * p0^2

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 0.01, nSteps = 50L,
    massMatInv = 1.0, gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0,
    H0 = H0, divergenceMax = 1000
  )

  expect_false(result$divergent)
  expect_false(result$hamiltonianDivergent)
})

# ── .HMCDefaultArgs ────────────────────────────────────────────────────

test_that(".HMCDefaultArgs creates valid default args", {
  mock_model <- list(parametersLengthNotFixed = 4L)
  args <- .HMCDefaultArgs(mock_model)

  expect_true(is.list(args))
  expect_true("massMatInv" %in% names(args))
  expect_true("stepSize" %in% names(args))
  expect_true("nSteps" %in% names(args))
  expect_true("adaptStepSize" %in% names(args))
  expect_true("targetAccept" %in% names(args))
  expect_true(".hmcDA" %in% names(args))

  expect_length(args$massMatInv, 4)
  expect_equal(args$massMatInv, rep(1.0, 4))
  expect_equal(args$nSteps, 10L)
  expect_true(args$adaptStepSize)
  expect_equal(args$targetAccept, 0.65)
})

test_that(".HMCDefaultArgs scales stepSize with dimension", {
  args2 <- .HMCDefaultArgs(list(parametersLengthNotFixed = 2L))
  args100 <- .HMCDefaultArgs(list(parametersLengthNotFixed = 100L))
  # Larger dimension => smaller initial step size
  expect_true(args2$stepSize > args100$stepSize)
})

test_that(".HMCDefaultArgs dual averaging env has correct initial state", {
  args <- .HMCDefaultArgs(list(parametersLengthNotFixed = 4L))
  da <- args[[".hmcDA"]]
  expect_true(is.environment(da))
  expect_equal(da$daCounter, 0L)
  expect_equal(da$Hbar, 0)
  expect_equal(da$stepSize, args$stepSize)
})

# ── .HMCRestartDualAvg ─────────────────────────────────────────────────

test_that(".HMCRestartDualAvg resets counters", {
  mock_args <- list(
    stepSize = 0.1,
    .hmcDA = new.env(parent = emptyenv())
  )
  da <- mock_args[[".hmcDA"]]
  da$mu <- 5
  da$logEpsBar <- 2
  da$Hbar <- 10
  da$daCounter <- 100L
  da$stepSize <- 0.1

  .HMCRestartDualAvg(mock_args)

  expect_equal(da$daCounter, 0L)
  expect_equal(da$Hbar, 0)
  expect_equal(da$stepSize, 0.1)
  expect_equal(da$mu, log(10 * 0.1))
  expect_equal(da$logEpsBar, log(0.1))
})

test_that(".HMCRestartDualAvg handles NULL .hmcDA gracefully", {
  expect_silent(.HMCRestartDualAvg(list(stepSize = 0.1, .hmcDA = NULL)))
})

# ── .NUTSBuildTree depth-0 (base case) ──────────────────────────────────

test_that(".NUTSBuildTree depth-0 takes one leapfrog step", {
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }

  q0 <- 1.0
  r0 <- 0.5
  grad0 <- -q0
  logPost0 <- -0.5 * q0^2
  H0 <- -logPost0 + 0.5 * r0^2

  result <- .NUTSBuildTree(
    q = q0, r = r0, grad = grad0, logPost = logPost0,
    direction = 1L, depth = 0L,
    stepSize = 0.1, massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0,
    H0 = H0, divergenceMax = 1000
  )

  expect_equal(result$nLeapfrog, 1L)
  expect_false(result$divergent)
  expect_true(result$valid)
  # q should have moved from initial position
  expect_true(result$q_candidate != q0)
})

test_that(".NUTSBuildTree depth-0 flags divergence on bad gradient", {
  gradFn <- function(fullParams) list(ok = FALSE, grad = NA, logPost = NA)

  result <- .NUTSBuildTree(
    q = 1.0, r = 0.5, grad = -1.0, logPost = -0.5,
    direction = 1L, depth = 0L,
    stepSize = 0.1, massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = 1.0,
    temperature = 1.0,
    H0 = 1.0, divergenceMax = 1000
  )

  expect_true(result$divergent)
  expect_false(result$valid)
  expect_equal(result$sumLogWeight, -Inf)
})
