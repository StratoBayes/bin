# #1731: the checkpoint's `nThreads` was consulted only for a `StratMCMC`
# passed back in, so the two ordinary continuation routes ran sequentially.
test_that("continuations inherit the checkpoint's nThreads (#1731)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  checkpointFile <- file.path(td, "thr_mcmc_run_1.rds")

  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20, nChains = 2, seed = 1, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 2L, modelDir = td, modelName = "thr"
  ))
  expect_equal(readRDS(checkpointFile)[["nThreads"]], 2L)

  # By directory; `engine = "R"` shows the threaded switch is applied too.
  expect_message(
    suppressWarnings(RunStratModel(modelDir = td, modelName = "thr",
                                   nIter = 10, engine = "R", quiet = TRUE,
                                   visualise = FALSE)),
    "Switching to"
  )
  expect_equal(readRDS(checkpointFile)[["nThreads"]], 2L)

  # By `StratPosterior`.
  posterior <- StratPosterior(readDir = td, modelName = "thr")
  suppressWarnings(RunStratModel(posterior, nIter = 10, quiet = TRUE,
                                 visualise = FALSE))
  expect_equal(readRDS(checkpointFile)[["nThreads"]], 2L)

  # An explicit count still wins.
  suppressWarnings(RunStratModel(modelDir = td, modelName = "thr", nIter = 10,
                                 nThreads = 1L, quiet = TRUE,
                                 visualise = FALSE))
  expect_equal(readRDS(checkpointFile)[["nThreads"]], 1L)
})

test_that(".ReadMCMC reads the documented file-path input (#1731)", {
  checkpoint <- structure(list(completedIter = 1), class = "StratMCMC")
  path <- withr::local_tempfile(fileext = ".rds")

  saveRDS(list(checkpoint, checkpoint), path)
  expect_identical(.ReadMCMC(path, tempdir(), "none", nRun = 2),
                   list(checkpoint, checkpoint))

  saveRDS(checkpoint, path)
  expect_identical(.ReadMCMC(path, tempdir(), "none"), list(checkpoint))

  saveRDS(data.frame(x = 1), path)
  expect_error(.ReadMCMC(path, tempdir(), "none"), "file path")
  expect_error(.ReadMCMC(file.path(tempdir(), "absent.rds"), tempdir(), "none"),
               "no readable file")
})
