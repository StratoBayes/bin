# GH #1110, #1109: `.PriorsValidity()` must be RNG-neutral, and its `R`-function
# warning handler must not treat the warning text as a `sprintf()` format.

test_that(".PriorsValidity() does not advance the ambient RNG stream", {
  set.seed(1)
  before <- get(".Random.seed", envir = globalenv(), inherits = FALSE)
  expect_true(.PriorsValidity(stratPrior1))
  expect_identical(get(".Random.seed", envir = globalenv(), inherits = FALSE),
                   before)
})

test_that(".PriorsValidity() leaves an uninitialised RNG uninitialised", {
  if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
    old <- get(".Random.seed", envir = globalenv(), inherits = FALSE)
    on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
    rm(".Random.seed", envir = globalenv())
  }
  expect_true(.PriorsValidity(stratPrior1))
  expect_false(exists(".Random.seed", envir = globalenv(), inherits = FALSE))
})

test_that("supplying a matching `priorsProposals` does not change the model", {
  Build <- function(...) {
    set.seed(1)
    suppressMessages(
      StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                 sedModel = "site", alphaPosition = "bottom", nKnots = 15,
                 overlapPenalty = TRUE, sigmaFixed = TRUE, ...)
    )
  }
  omitted <- Build()
  supplied <- Build(priorsProposals = stratPrior1)

  # `identical()` on whole models is not an oracle here: `splineBase$D` and
  # `$ageSpan` are drawn from the ambient stream by design.
  expect_identical(supplied[[c("splineBase", "ageSpan")]],
                   omitted[[c("splineBase", "ageSpan")]])
  expect_identical(supplied[[c("priors", "gibbs", "lambdaMin")]],
                   omitted[[c("priors", "gibbs", "lambdaMin")]])
  expect_identical(supplied[["overlapPenalty"]], omitted[["overlapPenalty"]])
  expect_identical(supplied[["sigmaFixed"]], omitted[["sigmaFixed"]])
})

test_that("a warning containing '%' is reported, not swallowed by sprintf()", {
  noisy <- stratPrior1
  noisy[["alpha_site_2"]][["R"]] <- function(n, ...) {
    warning("rate is 100% of budget")
    0
  }
  expect_error(.PriorsValidity(noisy), "100% of budget", fixed = TRUE)
  expect_error(.PriorsValidity(noisy), "alpha_site_2", fixed = TRUE)
})
