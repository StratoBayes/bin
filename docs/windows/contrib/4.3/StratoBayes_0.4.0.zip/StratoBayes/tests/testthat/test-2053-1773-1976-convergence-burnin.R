# Convergence monitoring and burn-in: #2053, #1773, #1977, #1976.

Rows2053 <- function(iters, nanAt = integer(0), seed = 1L) {
  set.seed(seed)
  mat <- cbind(iteration = iters, chain = 1, a = stats::rnorm(length(iters)),
               b = stats::rnorm(length(iters)))
  mat[iters %in% nanAt, "b"] <- NaN
  mat
}

Checkpoint2053 <- function(store, cap = .kConvergenceMaxDraws,
                           criteria = list(rHat = 1.5, ess = 5)) {
  suppressWarnings(.ConvergenceCheckpoint(
    store, criteria, tempdir(), "m2053", run = 1L, nRun = 1L,
    endAdapting = 0, crossRun = FALSE, useSentinel = FALSE, cap = cap))
}

test_that("an NA draw halved out of the store still vetoes the stop (#2053)", {
  store <- .ConvergenceAppend(.ConvergenceStore(),
                              Rows2053(seq_len(40), nanAt = 12), cols = 3:4)
  for (k in 1:3) {
    store <- Checkpoint2053(store, cap = 20)
    expect_false(isTRUE(store[["met"]]), info = paste("checkpoint", k))
    expect_identical(store[["streak"]], 0L)
  }
  expect_false(12 %in% store[["iters"]])
})

test_that("an NA draw on a row the store's stride skips vetoes the stop (#2053)", {
  store <- .ConvergenceStore()
  store[["thin"]] <- 1L
  store <- .ConvergenceAppend(store, Rows2053(seq_len(40), nanAt = 12),
                              cols = 3:4)
  expect_false(12 %in% do.call(rbind, store[["chunks"]])[, 1L])
  expect_warning(
    .ConvergenceCheckpoint(store, list(rHat = 1.5, ess = 5), tempdir(),
                           "m2053", run = 1L, nRun = 1L, endAdapting = 0,
                           crossRun = FALSE, useSentinel = FALSE),
    "NA/NaN draw of b at iteration 12"
  )
  for (k in 1:3) {
    store <- Checkpoint2053(store)
    expect_false(isTRUE(store[["met"]]), info = paste("checkpoint", k))
  }
})

test_that("the adaptive-thinning rebuild keeps a retained NA's veto (#2053)", {
  store <- .ConvergenceAppend(.ConvergenceStore(),
                              Rows2053(seq_len(40), nanAt = 12), cols = 3:4)
  store <- Checkpoint2053(store)
  # As RunStratModel(): a fresh store from the thinned saved rows, which still
  # hold iteration 12, then only the progress fields copied across.
  segment <- Rows2053(seq(2, 40, by = 2), nanAt = 12)
  rebuilt <- .ConvergenceAppend(.ConvergenceStore(), segment, cols = 3:4)
  rebuilt[["streak"]] <- store[["streak"]]
  rebuilt <- .ConvergenceCollapse(rebuilt)
  expect_no_warning(rebuilt <- .ConvergenceCheckpoint(
    rebuilt, list(rHat = 1.5, ess = 5), tempdir(), "m2053", run = 1L,
    nRun = 1L, endAdapting = 0, crossRun = FALSE, useSentinel = FALSE))
  for (k in 1:3) {
    rebuilt <- Checkpoint2053(rebuilt)
    expect_false(isTRUE(rebuilt[["met"]]), info = paste("checkpoint", k))
  }
})

test_that("a clean store still stops, and an unrecorded column is no damage (#2053)", {
  store <- .ConvergenceAppend(.ConvergenceStore(), Rows2053(seq_len(40)),
                              cols = 3:4)
  store <- Checkpoint2053(Checkpoint2053(store))
  expect_true(store[["met"]])

  unrecorded <- Rows2053(seq_len(40))
  unrecorded[, "b"] <- NA
  store <- .ConvergenceAppend(.ConvergenceStore(), unrecorded, cols = 3:4)
  store <- Checkpoint2053(Checkpoint2053(store))
  expect_true(store[["met"]])
})

test_that("a peer's NA draw vetoes a cross-run stop after halving (#2053)", {
  dir <- withr::local_tempdir()
  Publish <- function(run, nanAt = integer(0)) {
    store <- .ConvergenceAppend(.ConvergenceStore(),
                                Rows2053(seq_len(40), nanAt = nanAt,
                                         seed = run), cols = 3:4)
    store <- .ConvergenceCollapse(store, cap = 20)
    .WriteConvergenceDraws(dir, "m2053x", run, store[["draws"]],
                           store[["iters"]], endAdapting = 0)
  }
  Publish(1L)
  Publish(2L)
  expect_false(is.null(.ConvergenceDrawSet(dir, "m2053x", 1L, 2L)))
  Publish(2L, nanAt = 12)
  expect_null(.ConvergenceDrawSet(dir, "m2053x", 1L, 2L))
})

Iid1773 <- function(n, nRun = 1L) {
  set.seed(1773)
  list(draws = replicate(nRun, cbind(a = stats::rnorm(n), b = stats::rnorm(n)),
                         simplify = FALSE),
       iters = replicate(nRun, seq_len(n), simplify = FALSE))
}

test_that("an ESS target above the search's row cap is reachable (#1773, #1977)", {
  fx <- Iid1773(4096)
  res <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.1, essTarget = 1000,
                         stopAtFirst = TRUE,
                         searchMaxDraws = .kConvergenceSearchDraws)
  expect_identical(res[["status"]], "ok")
  expect_gt(res[["ess"]], 1000)
})

test_that("the ESS burnIn = 'auto' reports is not the decimated proxy (#1773)", {
  fx <- Iid1773(8000, nRun = 2L)
  res <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.1)
  expect_identical(res[["status"]], "ok")
  kept <- Map(function(m, it) m[it > res[["iteration"]], , drop = FALSE],
              fx$draws, fx$iters)
  trueEss <- min(vapply(1:2, function(p) {
    sum(vapply(kept, function(m) .EssFunc(m[, p]), numeric(1)))
  }, numeric(1)))
  expect_equal(res[["ess"]], trueEss)
  expect_identical(res[["drawsAvailable"]], sum(vapply(kept, nrow, integer(1))))
  expect_match(.AutoBurnInMessage(res), paste0("minimum ESS ", round(trueEss)))
})

test_that("a lone run's store holds enough draws for its ESS target (#1773)", {
  set.seed(1773)
  iters <- seq_len(12000)
  mat <- cbind(iteration = iters, chain = 1, a = stats::rnorm(12000),
               b = stats::rnorm(12000))
  criteria <- list(rHat = 1.1, ess = 5000)
  store <- .ConvergenceStore()
  for (chunk in split(seq_len(12000), rep(1:2, each = 6000))) {
    store <- .ConvergenceAppend(store, mat[chunk, , drop = FALSE], cols = 3:4)
    store <- .ConvergenceCheckpoint(store, criteria, tempdir(), "m1773",
                                    run = 1L, nRun = 1L, endAdapting = 0,
                                    crossRun = FALSE, useSentinel = FALSE)
  }
  expect_true(store[["met"]])
  expect_gt(store[["ess"]], 5000)
})

test_that("a -Inf draw on a row the search skips is screened, not fatal (#1773)", {
  fx <- Iid1773(5000, nRun = 2L)
  fx$draws[[1]][4002, "a"] <- -Inf
  res <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.1)
  expect_identical(res[["status"]], "ok")
  res <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.1, essTarget = 10,
                         stopAtFirst = TRUE, searchMaxDraws = 1000L)
  expect_identical(res[["status"]], "ok")
})

test_that("a damaged peer that has stopped is dropped like any other (#2053)", {
  dir <- withr::local_tempdir()
  Publish <- function(run, iters, nanAt = integer(0), final = FALSE) {
    store <- .ConvergenceAppend(.ConvergenceStore(),
                                Rows2053(iters, nanAt = nanAt, seed = run),
                                cols = 3:4)
    store <- .ConvergenceCollapse(store, cap = 20)
    .WriteConvergenceDraws(dir, "m2053f", run, store[["draws"]],
                           store[["iters"]], endAdapting = 0, final = final)
  }
  Publish(1L, seq_len(80))
  Publish(2L, seq_len(80))
  Publish(3L, seq_len(40), nanAt = 12, final = TRUE)
  set <- .ConvergenceDrawSet(dir, "m2053f", 1L, 3L)
  expect_length(set[["drawList"]], 2L)

  # Still sampling: its later draws are not in the posterior, so no verdict.
  Publish(3L, seq_len(80), nanAt = 12)
  expect_null(.ConvergenceDrawSet(dir, "m2053f", 1L, 3L))

  # Two runs: dropping one would leave nothing to compare.
  Publish(2L, seq_len(40), nanAt = 12, final = TRUE)
  expect_null(.ConvergenceDrawSet(dir, "m2053f", 1L, 2L))
})

test_that("thinning that drops the NA row from the samples lifts the veto (#2053)", {
  # As RunStratModel(): the saved samples and the rebuilt store keep the same
  # odd rows, so iteration 12 is no longer where the posterior ends.
  segment <- Rows2053(seq(1, 39, by = 2), nanAt = 12)
  rebuilt <- .ConvergenceCollapse(.ConvergenceAppend(.ConvergenceStore(),
                                                     segment, cols = 3:4))
  expect_identical(.ConvergenceNaIter(rebuilt), Inf)
})

StillAdapting1976 <- function(stopped = 1250) {
  sp <- stratPosterior1
  for (r in 2:3) {
    saveIter <- sp[[c("mcmcSummary", "saveIter")]][[r]]
    sp[["mcmcSummary"]][["saveIter"]][[r]] <- saveIter[saveIter <= stopped]
    sp[["mcmcSummary"]][["completedIter"]][[r]] <- stopped
    sp[["mcmcSummary"]][["completedIterIndex"]][[r]] <- sum(saveIter <= stopped)
  }
  sp
}

test_that("burnIn = 'auto' names a run that never left adaptation (#1976)", {
  sp <- StillAdapting1976()
  msg <- "Run 2 never left the adaptation window.*burnIn = 0"
  expect_error(suppressWarnings(summary(sp, runs = 2, burnIn = "auto")), msg)
  expect_error(suppressWarnings(ExtractParameters(
    sp, parameters = "alpha_site_2", runs = 2, burnIn = "auto")), msg)
  expect_error(suppressWarnings(plot(sp, runs = 2, burnIn = "auto")), msg)
  expect_error(suppressWarnings(summary(sp, runs = 2:3, burnIn = "auto")),
               "Runs 2, 3 never left the adaptation window")

  # The alternatives it offers work.
  expect_no_error(suppressWarnings(summary(sp, runs = 2, burnIn = 0)))
  expect_no_error(suppressWarnings(summary(sp, runs = 1, burnIn = "auto")))
})

test_that("a run that got past adaptation keeps the ordinary burnIn error (#1976)", {
  sp <- StillAdapting1976(stopped = 3500)
  expect_error(summary(sp, runs = 2, burnIn = 4000),
               "all iterations were discarded as burn-in")
  expect_no_error(suppressWarnings(summary(sp, runs = 2, burnIn = "auto")))
})

test_that("the first saved NA/NaN draw is found in the cold chain only (#2071)", {
  cols <- c("iteration", "chain", "a", "b")
  mat <- cbind(rep(1:4, each = 2), rep(1:2, 4), stats::rnorm(8), -Inf)
  expect_null(.FirstNaDraw(mat, 1, cols))
  mat[2, 3] <- NaN
  expect_null(.FirstNaDraw(mat, 1, cols))
  mat[c(5, 7), 3:4] <- NA
  expect_identical(.FirstNaDraw(mat, 1, cols),
                   list(iteration = 3, parameters = c("a", "b")))
  expect_match(.NaDrawMessage(.FirstNaDraw(mat, 1, cols), run = 2),
               "Run 2 stopped: .*of a, b at iteration 3.*defect")
})

NanRun2071 <- function(engine, poisonFrom = 40) {
  dir <- withr::local_tempdir(.local_envir = parent.frame())
  RunStratModel(stratData1, stratModel1, nIter = 200, nChains = 2, nRun = 1,
                seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                modelName = "nan", visualise = FALSE, convergenceStop = FALSE,
                engine = engine)
}

test_that("a C++ run stops at its first saved NaN draw (#2071)", {
  realFlush <- .sb_flush_samples
  local_mocked_bindings(.sb_flush_samples = function(...) {
    out <- realFlush(...)
    m <- out[["sampleMatrix"]]
    if (nrow(m)) m[m[, 1L] >= 40, 3L] <- NaN
    out[["sampleMatrix"]] <- m
    out
  })
  expect_warning(post <- NanRun2071("cpp"),
                 "Run 1 stopped: it saved an NA/NaN draw of .* at iteration")
  expect_lt(post[[c("mcmcSummary", "completedIter")]][[1]], 200)
  expect_lt(max(post[[c("mcmcSummary", "saveIter")]][[1]][
    !is.na(post[["samples"]][, 1, 1, 1])]), 40)
})

test_that("an R-engine run stops at its first saved NaN draw (#2071)", {
  realSave <- .SamplesToSave
  local_mocked_bindings(.SamplesToSave = function(model, state, iteration,
                                                  saveChains, mode = "standard") {
    out <- realSave(model, state, iteration, saveChains, mode)
    if (mode == "plotting" && iteration >= 40) out[, 3L] <- NaN
    out
  })
  expect_warning(post <- NanRun2071("R"),
                 "Run 1 stopped: it saved an NA/NaN draw of .* at iteration 40")
  expect_identical(post[[c("mcmcSummary", "completedIter")]][[1]], 40)
})
