# #2082: an accepted sedSmooth move swaps a new B'B into the chain state, but
# the band factor carried from the last marginal evaluation still described
# the old one. Its lambda/sigma stamps still matched, so the Gibbs sweep drew
# beta from the conditional of the pre-move ages.
#
# The carry exists only to skip a refactorisation, so drawing beta with it and
# without it, from the same state on the same RNG stream, must agree exactly.

test_that("sedSmooth accept: Gibbs beta draw matches a fresh factor (#2082)", {
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE, flexibleKnots = FALSE,
                       knotRange = c(-5, 12))

  td <- tempfile("sedcarry")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "carry"
  ))
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "carry_mcmc_run_1.rds"))
  engine <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
  expect_gte(StratoBayes:::.sb_engine_band_kd(engine), 0L)
  # Each probe starts where a sedSmooth step does in the sampler: after an
  # iteration, which leaves the marginal factor stamped at the current
  # lambda/sigma.
  probes <- lapply(seq_len(60), function(i) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    StratoBayes:::.sb_sed_smooth_gibbs_probe(engine, 1L, i)
  })
  accepted <- vapply(probes, `[[`, logical(1), "accepted")
  carried <- vapply(probes, `[[`, logical(1), "carried")
  betaDiff <- vapply(probes, `[[`, double(1), "maxBetaDiff")

  # Both branches must be exercised: accepts, and rejects that reuse a factor.
  expect_true(any(accepted))
  expect_true(any(carried & !accepted))
  expect_equal(betaDiff[accepted], rep(0, sum(accepted)))
  expect_equal(betaDiff[!accepted], rep(0, sum(!accepted)))
})

# #2093: an accepted sedSmooth move also swapped in the new compact B without
# its per-row column offsets, so every row whose age crossed a knot sat in the
# wrong columns until the next main-MH accept. The sigma and offset draws, the
# joint likelihood and the exported state all read B through those offsets.

test_that("sedSmooth accept keeps B consistent with B'B (#2093)", {
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE, flexibleKnots = FALSE,
                       knotRange = c(-5, 12))

  td <- tempfile("sedcolstart")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "colstart"
  ))
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "colstart_mcmc_run_1.rds"))
  engine <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )

  sedBeta <- NULL
  sedMoves <- 0L
  relErr <- numeric(0)
  for (i in seq_len(40)) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    st <- StratoBayes:::.sb_extract_state(engine)[[1]]
    if (!is.null(sedBeta) && !identical(sedBeta, st$gibbs$sedBeta)) {
      sedMoves <- sedMoves + 1L
    }
    sedBeta <- st$gibbs$sedBeta
    for (m in seq_along(st$metro$H)) {
      H <- st$metro$H[[m]]
      BtB <- crossprod(st$metro$B[[m]]) / st$gibbs$sigma[m]^2
      relErr <- c(relErr, max(abs(BtB - H)) / max(abs(H)))
    }
  }
  expect_gt(sedMoves, 0L)
  expect_lt(max(relErr), 1e-8)
})
