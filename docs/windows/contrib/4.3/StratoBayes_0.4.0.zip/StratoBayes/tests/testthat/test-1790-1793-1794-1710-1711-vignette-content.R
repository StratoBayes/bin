vignDir <- testthat::test_path("..", "..", "vignettes")

test_that("#1790: Age-models.qmd shows construction of stratData4b", {
  skip_if_not(dir.exists(vignDir), "vignettes/ not found (not running against a source tree)")
  lines <- readLines(file.path(vignDir, "Age-models.qmd"))
  expect_true(any(grepl("^stratData4b\\s*<-\\s*StratData\\(", lines)))
})

test_that("#1793: Tie-points.qmd doesn't shadow the shipped tiesData5 dataset", {
  skip_if_not(dir.exists(vignDir), "vignettes/ not found (not running against a source tree)")
  lines <- readLines(file.path(vignDir, "Tie-points.qmd"))
  # the shipped tiesData5 dataset has mean/sd columns; the vignette must not
  # rebind the name to the differently-shaped densityFun/arg1/arg2 form
  expect_false(any(grepl("^tiesData5\\s*<-\\s*data\\.frame", lines)))
})

test_that("#1794: MCMC-algorithm.qmd prose matches the actual prior families, build date and ESJD gate", {
  skip_if_not(dir.exists(vignDir), "vignettes/ not found (not running against a source tree)")
  text <- paste(readLines(file.path(vignDir, "MCMC-algorithm.qmd")), collapse = " ")

  # (1) prior list must not claim truncated uniform/exponential variants
  expect_false(grepl("and their truncated variants", text, fixed = TRUE))

  # (2) build date must be reproducible (commented out like the other vignettes)
  expect_false(any(grepl(
    "^date:\\s*today",
    readLines(file.path(vignDir, "MCMC-algorithm.qmd"))
  )))

  # (3) ESJD gate description must mention the measurable-types clause
  # (collapse whitespace so the check survives line-wrapping)
  collapsed <- gsub("\\s+", " ", text)
  expect_true(grepl(
    "at least five draws exist per type and at least two proposal types have accumulated measurable timing",
    collapsed,
    fixed = TRUE
  ))
})

test_that("#1710: no vignette links into the private repo's docs/r-engine-contract.md", {
  skip_if_not(dir.exists(vignDir), "vignettes/ not found (not running against a source tree)")
  files <- list.files(vignDir, pattern = "\\.qmd$", full.names = TRUE)
  hits <- unlist(lapply(files, function(f) {
    lines <- readLines(f)
    grep("StratoBayes-R-package/blob/main/docs/r-engine-contract\\.md", lines, value = TRUE)
  }))
  expect_length(hits, 0)
})

test_that("#1711: every vignette's VignetteIndexEntry is not a bare file slug", {
  skip_if_not(dir.exists(vignDir), "vignettes/ not found (not running against a source tree)")
  files <- list.files(vignDir, pattern = "\\.qmd$", full.names = TRUE)
  expect_gt(length(files), 0)
  for (f in files) {
    lines <- readLines(f)
    entryLine <- grep("VignetteIndexEntry\\{", lines, value = TRUE)
    if (length(entryLine) == 0) next

    # case-insensitive: a mere case change (e.g. "sedSmooth" vs "SedSmooth")
    # is still an uninformative slug, not a descriptive title
    slug <- tolower(tools::file_path_sans_ext(basename(f)))
    entry <- tolower(sub(".*VignetteIndexEntry\\{([^}]*)\\}.*", "\\1", entryLine))

    expect_false(
      identical(entry, slug),
      info = paste(basename(f), "VignetteIndexEntry is still the file slug")
    )
  }
})
