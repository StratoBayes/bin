# #1977 item 2: continuing from a `StratPosterior` recounted completed rows
# as those non-NA in column 1, where every other route stops at the first row
# with a missing value in any column (#1598).
test_that("a StratPosterior continuation resumes after the first gap (#1977)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()

  posterior <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20, nChains = 1, seed = 1, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L, modelDir = td, modelName = "gap"
  ))
  expect_equal(posterior[["mcmcSummary"]][["saveIter"]][[1]], 1:20)
  posterior[["samples"]][10, 3, 1, 1] <- NA
  file.remove(file.path(td, "gap_samples_run_1.txt"))

  suppressWarnings(RunStratModel(posterior, nIter = 5, quiet = TRUE,
                                 visualise = FALSE, nThreads = 1L))
  expect_equal(readRDS(file.path(td, "gap_mcmc_run_1.rds"))[["startIter"]], 10)
})
