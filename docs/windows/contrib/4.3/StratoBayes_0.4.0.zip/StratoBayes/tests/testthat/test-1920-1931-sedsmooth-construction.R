# sedSmooth formation construction: degenerate formation widths (#1920, #1921,
# #1928) and the role of `sedModel` under sedSmooth (#1922, #1931).

ZeroWidthNonGap <- function() {
  # a deliberate leading hiatus: StratData() keeps partition A of site s2 as a
  # zero-width, non-gap partition below the gap
  set.seed(1)
  h1 <- seq(0, 20, length.out = 60)
  h2 <- seq(0, 15, length.out = 50)
  signal <- rbind(
    data.frame(site = "s1", height = h1,
               value = sin(h1 / 3) + rnorm(60, 0, 0.05)),
    data.frame(site = "s2", height = h2,
               value = sin((h2 + 2) / 3) + rnorm(50, 0, 0.05))
  )
  parts <- data.frame(site = c("s1", "s2", "s2", "s2", "s2"),
                      height = c(20, 0, 0, 15, 15),
                      partition = c("p1", "A", NA, "B", "B"))
  StratData(signal = signal, parts = parts)
}

test_that(".BuildFormationSpline rejects a reversed range (#1928)", {
  expect_error(.BuildFormationSpline(10, 3, 6L, 1L), "hHigh.*above.*hLow")
  expect_error(.BuildFormationSpline(3, 3, 6L, 1L), "hHigh.*above.*hLow")
  expect_error(.BuildFormationSpline(NA, 3, 6L, 1L), "hHigh.*above.*hLow")
})

test_that(".BuildFormationSpline rejects a formation too thin to spline (#1921)", {
  expect_error(.BuildFormationSpline(3, 3 + 1e-12, 6L, 1L), "too thin")
  expect_error(.BuildFormationSpline(3, 3 + 1e-9, 6L, 1L, span = 10), "too thin")
  expect_error(.BuildFormationSpline(0, 1e-12, 6L, 1L, span = 10,
                                     label = "site 'b', partition 2"),
               "site 'b', partition 2")

  # the refused widths are the ones where D stops following width^-3
  unit <- .BuildFormationSpline(0, 1, 6L, 1L)[["D"]]
  thin <- .BuildFormationSpline(3, 3 + 1e-4, 6L, 1L, span = 10)
  expect_equal(thin[["D"]], unit * 1e12, tolerance = 1e-6)
  # a uniformly small unit system is not thin
  small <- .BuildFormationSpline(0, 1e-6, 6L, 1L)
  expect_equal(small[["D"]], unit * 1e18, tolerance = 1e-6)
  # more knots mean narrower knot spans, which is what the penalty feels
  expect_error(.BuildFormationSpline(0, 1e-6, 104L, 1L, span = 10),
               "too thin")
})

test_that("a zero-width non-gap partition gets no formation (#1920)", {
  data <- ZeroWidthNonGap()
  pa <- data[["partsAttr"]]
  expect_equal(pa[["Bound"]][1, 2], pa[["BoundLow"]][1, 2])
  expect_false(is.na(pa[["sedRatesDF"]][1, 2]) || pa[["sedRatesDF"]][1, 2] == 0)

  info <- .SetupSedSmooth(data, "height", 6L)
  expect_true(is.na(info[["betaMap"]][1, 2]))
  expect_equal(info[["nFormations"]], 1L)
  sedNames <- .SedSmoothNames(data, info)
  expect_length(sedNames[["betaNames"]], info[["totalBeta"]])
  expect_length(sedNames[["lambdaNames"]], info[["nFormations"]])

  model <- StratModel(data, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 8)
  expect_equal(model[["sedSmoothInfo"]], info)

  # heights at, just above and away from the zero-width partition map to ages
  # and back
  sedBeta <- seq(-0.3, 0.3, length.out = info[["totalBeta"]])
  params <- c(4, 2)
  heights <- c(0, 1e-9, 5, 15)
  ages <- .CalculateNewAgesSedSmooth(data, model[["ind"]], params, 2L, heights,
                                     info, sedBeta)
  expect_true(all(is.finite(ages)))
  expect_equal(.CalculateRefHeightToHeights(data, model[["ind"]], params, 2L,
                                            ages, info, sedBeta),
               heights, tolerance = 1e-8)

  skip_on_cran()
  result <- RunStratModel(data, stratModel = model, nIter = 200L,
                          nChains = 1L, nThreads = 1L, seed = 1,
                          quiet = TRUE, visualise = FALSE,
                          modelDir = withr::local_tempdir(),
                          convergenceStop = FALSE)
  expect_true(all(is.finite(result[["samples"]][, model[["parametersNames"]], , ])))
})

test_that("sedSmooth says what it makes of sedModel (#1922)", {
  fitted <- StratModel(stratData2, alignmentScale = "height",
                       sedModel = "site, partition", sedSmooth = TRUE)
  for (requested in c("site", "partition", "site x partition")) {
    expect_warning(
      model <- StratModel(stratData2, alignmentScale = "height",
                          sedModel = requested, sedSmooth = TRUE),
      "sedSmooth.*each partition of each site.*shapes only"
    )
    expect_equal(model[["sedSmoothInfo"]], fitted[["sedSmoothInfo"]])
    expect_equal(model[["sedModel"]], requested)
  }
  expect_no_warning(
    StratModel(stratData2, alignmentScale = "height",
               sedModel = "site, partition", sedSmooth = TRUE)
  )
  expect_no_warning(
    constant <- StratModel(stratData1, alignmentScale = "height",
                           sedModel = "site")
  )
  expect_equal(constant[["sedModel"]], "site")
})

test_that(".SetupSedSmooth takes no sedModel (#1931)", {
  expect_false("sedModel" %in% names(formals(.SetupSedSmooth)))
})
