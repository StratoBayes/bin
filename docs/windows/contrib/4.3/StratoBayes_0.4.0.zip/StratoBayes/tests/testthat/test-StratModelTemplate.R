test_that("StratModelTemplate works - 01", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s")
  )
})

test_that("StratModelTemplate works - 02", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s x p",
                       gammaLog = "normal", zetaLog = "truncated normal",
                       gap = "truncated log normal")
  )
})

test_that("StratModelTemplate works - 03", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that("StratModelTemplate works - 04", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alpha = "fixed", gap = "log normal",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that(".FormatAlphaPosition() emits full precision, round-tripping exactly (#1878)", {
  # RT-530 already fixed this ulp-loss class on the *resolving* side
  # (.MatchAlphaPosition); this pins the *emitting* side, which used to rely
  # on paste0()'s default ~15-significant-digit as.character() coercion.
  x <- 1 / 3
  formatted <- .FormatAlphaPosition(x)
  expect_identical(as.numeric(formatted), x)

  # A round value must still print plainly, with no spurious trailing digits.
  expect_identical(.FormatAlphaPosition(100), "100")
})

test_that("StratModelTemplate prints a numeric alphaPosition that round-trips exactly (#1878)", {
  # A non-round alphaPosition applied to every site stays numeric throughout
  # (`.MatchAlphaPosition(toNumeric = FALSE)` never touches a purely-numeric
  # input), so this exercises the same emit path as an overlap midpoint.
  x <- 1 / 3
  template <- utils::capture.output(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       alphaPosition = x)
  )
  alphaLine <- grep("alphaPosition = ", template, value = TRUE)
  printedValue <- as.numeric(sub(".*alphaPosition = ([^,]+),.*", "\\1",
                                 alphaLine))
  expect_identical(printedValue, x)
})

test_that("StratModelTemplate() returns invisible(NULL), matching its documented @return (#1877)", {
  # The function only ever cats its output and falls off the end; it never
  # builds or returns the structured list its old @return claimed.
  out <- NULL
  utils::capture.output(
    out <- StratModelTemplate(stratData1, alignmentScale = "height",
                              sedModel = "s")
  )
  expect_null(out)
})

test_that("StratModelTemplate auto-assigns alignmentScale and sedModel or produces helpful errors", {

  signal <- data.frame(a = 1:4, height = 1:4, site = c("a", "a", "b", "b"))
  # site "b"'s first boundary must sit strictly above its own data minimum
  # (3) or it becomes a phantom zero-width partition (RT-457); 3.5 keeps
  # both site-b partitions non-degenerate.
  parts <- data.frame(height = c(4, 3.5, 4), site = c("a", "b", "b"), partition = c("x", "x", "y"))
  ties <- data.frame(height = 2, site = "a", mean = 1, sd = 1)

  testData <- StratData(signal = signal, signalColumn = "a")
  template1 <- utils::capture.output(StratModelTemplate(testData))
  expect_true(any(grepl('alignmentScale = "height"', template1)))
  expect_true(any(grepl('sedModel = "site"', template1)))

  testData <- StratData(signal = signal, parts = parts, signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*'site', 'partition'")

  testData <- StratData(signal = signal, parts = parts, ties = ties,
                        signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*Valid options are 'height'")

  expect_error(StratModelTemplate(testData, alignmentScale = "a"),
               "*'site', 'partition', 'site x partition', 'site, partition'")

})

test_that("StratModelTemplate errors on an unrecognised dist-type arg (RT-362)", {
  # A misspelled/unsupported distribution type used to fall through
  # printPrior()'s switch() silently, emitting a syntactically broken
  # generated line (e.g. `"alpha_site2" = ,`) rather than erroring at
  # generation time, so the user only discovered it as an opaque parse
  # error in the copied template script.
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       alpha = "gaussian"),
    "`alpha` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       gammaLog = "lognormal"),
    "`gammaLog` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       zetaLog = "truncated-normal"),
    "`zetaLog` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       gap = "expo"),
    "`gap` must be one of"
  )

  # valid types (including case-insensitive matching, as printPrior()'s
  # switch() already relies on) must still pass validation
  template <- utils::capture.output(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       alpha = "Uniform", gammaLog = "NORMAL", gap = "Fixed")
  )
  expect_true(any(grepl("UniformPrior", template)))
})
