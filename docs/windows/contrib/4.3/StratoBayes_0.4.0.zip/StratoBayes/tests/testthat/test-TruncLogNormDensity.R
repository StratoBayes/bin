test_that("TruncLogNormDensity works", {

  # no cut-off (equivalent to log normal)
  result1 = round(TruncLogNormDensity(1,0,1),10)
  result2 = round(dlnorm(1,0,1),10)
  expect_equal(result1, result2)

  # no cut-off (equivalent to log normal) - log density
  result1 = round(TruncLogNormDensity(1,0,1, log = TRUE),10)
  result2 = round(dlnorm(1,0,1, log = TRUE),10)
  expect_equal(result1, result2)

  # no cut-off at 1(should be 2x density of log normal)
  result1 = round(TruncLogNormDensity(1,0,1,min = 1),10)
  result2 = 2*round(dlnorm(1,0,1),10)
  expect_equal(result1, result2)

  # expect error if min > max
  expect_error(TruncLogNormDensity(1,0,1,min = 1, max = 0))

  # RT-024: expect error if min == max (width-zero interval) too, not just
  # min > max -- previously silently produced a density of +Inf via
  # log(Phi(z) - Phi(z)) = log(0) = -Inf normalisation.
  expect_error(TruncLogNormDensity(1, 0, 1, min = 1, max = 1))
})
