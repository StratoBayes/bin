# #1729: a run stopped inside its adaptation window is continued with
# `endAdapting` clamped behind `startIter`, so the `i == endAdapting` switch
# that ends dual averaging is never reached -- and the C++ engine has no cutoff
# of its own.
test_that("continuing a run stopped mid-adaptation stops step-size tuning (#1729)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  # A store this small spends its budget, stopping the run long before
  # `endAdapting`.
  withr::local_options(StratoBayes.maxStore = 1000)

  run1 <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20000, endAdapting = 19000, convergenceStop = FALSE,
    nChains = 2, seed = 1, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "latch", gradientProposals = "on"
  ))
  checkpointFile <- file.path(td, "latch_mcmc_run_1.rds")
  stopped <- readRDS(checkpointFile)
  gradProp <- which(names(stopped[["propose"]]) %in% c("HMC", "NUTS"))
  AdaptStepSize <- function(m) {
    vapply(m[[c("metro", "proposalArgs")]],
           function(a) isTRUE(a[[gradProp]][["adaptStepSize"]]), logical(1))
  }
  expect_lt(stopped[["completedIter"]], 19000)
  expect_true(all(AdaptStepSize(stopped)))

  suppressWarnings(RunStratModel(run1, nIter = 20, gradientProposals = "on",
                                 quiet = TRUE, visualise = FALSE,
                                 nThreads = 1L))
  continued <- readRDS(checkpointFile)
  expect_lt(continued[["endAdapting"]], continued[["startIter"]])
  expect_false(any(AdaptStepSize(continued)))
})

test_that(".CloseElapsedStepSizeAdaptation leaves an open window alone (#1729)", {
  ha <- list(stepSize = 0.1, adaptStepSize = TRUE)
  mcmc <- list(propose = list(Prior = NULL, NUTS = NULL),
               startIter = 101, endAdapting = 200,
               metro = list(proposalArgs = list(list(NULL, ha),
                                                list(NULL, ha))))
  expect_identical(.CloseElapsedStepSizeAdaptation(mcmc), mcmc)

  mcmc[["endAdapting"]] <- 100
  closed <- .CloseElapsedStepSizeAdaptation(mcmc)
  expect_false(closed[[c("metro", "proposalArgs")]][[1]][[2]][["adaptStepSize"]])
  expect_false(closed[[c("metro", "proposalArgs")]][[2]][[2]][["adaptStepSize"]])
  expect_identical(closed[[c("metro", "proposalArgs")]][[1]][[2]][["stepSize"]], 0.1)

  # `adaptProposal = FALSE` opens no window, so there is none to close.
  mcmc[["startIter"]] <- 1
  mcmc[["endAdapting"]] <- 0
  expect_identical(.CloseElapsedStepSizeAdaptation(mcmc), mcmc)
})

test_that("a mid-window stop checkpoints the engine's step size (#1729)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  withr::local_options(StratoBayes.maxStore = 1000)

  # Stops after the first adaptation checkpoint, which reads back the
  # still-unstepped `logEpsBar = 0` as a step size of 1, and before the second.
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20000, startAdapting = 1500, endAdapting = 19000,
    convergenceStop = FALSE, nChains = 2, seed = 1, quiet = TRUE,
    visualise = FALSE, runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "early", gradientProposals = "on"
  ))
  stopped <- readRDS(file.path(td, "early_mcmc_run_1.rds"))
  expect_gt(stopped[["completedIter"]], 1500)
  expect_lt(stopped[["completedIter"]], stopped[[c("metro", "nextAdapt")]])

  gradProp <- which(names(stopped[["propose"]]) %in% c("HMC", "NUTS"))
  stepSizes <- vapply(stopped[[c("metro", "proposalArgs")]],
                      function(a) a[[gradProp]][["stepSize"]], numeric(1))
  expect_true(all(is.finite(stepSizes)))
  expect_true(all(stepSizes != 1))
})
