# Convergence diagnostics and burn-in: #1975, #1953, #1854, #1857, #1855.

TwoRuns1975 <- function(n = 40L, seed = 1L) {
  set.seed(seed)
  lapply(1:2, function(r) cbind(a = stats::rnorm(n), b = stats::rnorm(n)))
}

test_that("an NA draw that vetoes convergenceStop is reported once (#1975)", {
  set.seed(11)
  Rows <- function(iters, nanAt = integer(0)) {
    mat <- cbind(iteration = iters, chain = 1, a = stats::rnorm(length(iters)),
                 b = stats::rnorm(length(iters)))
    mat[iters %in% nanAt, "b"] <- NaN
    mat
  }
  criteria <- list(rHat = 1.5, ess = 5)
  Checkpoint <- function(store) {
    .ConvergenceCheckpoint(store, criteria, tempdir(), "m1975", run = 1L,
                           nRun = 1L, endAdapting = 0, crossRun = FALSE,
                           useSentinel = FALSE)
  }

  store <- .ConvergenceAppend(.ConvergenceStore(),
                              Rows(seq_len(40) * 10, nanAt = 120), cols = 3:4)
  expect_warning(store <- Checkpoint(store),
                 "Run 1 saved an NA/NaN draw of b at iteration 120")
  expect_false(isTRUE(store[["met"]]))

  store <- .ConvergenceAppend(store, Rows(41:60 * 10), cols = 3:4)
  expect_no_warning(store <- Checkpoint(store))
  expect_false(isTRUE(store[["met"]]))

  # The adaptive-thinning rebuild starts a fresh store from the same rows.
  rebuilt <- .ConvergenceCollapse(.ConvergenceAppend(
    .ConvergenceStore(), cbind(store[["iters"]], 1, store[["draws"]]),
    cols = 3:4))
  expect_no_warning(Checkpoint(rebuilt))

  # A column never recorded is not damage.
  unrecorded <- Rows(seq_len(40) * 10)
  unrecorded[, "b"] <- NA
  expect_no_warning(Checkpoint(.ConvergenceAppend(.ConvergenceStore(),
                                                  unrecorded, cols = 3:4)))
})

test_that("a peer without a finite endAdapting imposes no floor (#1953)", {
  dir <- withr::local_tempdir()
  draws <- TwoRuns1975()
  iters <- seq_len(40L) * 10
  .WriteConvergenceDraws(dir, "m1953", 1L, draws[[1]], iters, endAdapting = 100)

  .WriteConvergenceDraws(dir, "m1953", 2L, draws[[2]], iters, endAdapting = Inf)
  set <- .ConvergenceDrawSet(dir, "m1953", 1L, 2L)
  expect_identical(set[["floorIter"]], 100)

  # A legacy or partial checkpoint with no `endAdapting`.
  .WriteConvergenceDraws(dir, "m1953", 2L, draws[[2]], iters, endAdapting = NULL)
  expect_no_error(set <- .ConvergenceDrawSet(dir, "m1953", 1L, 2L))
  expect_identical(set[["floorIter"]], 100)
})

test_that("adaptation-phase NA draws cannot blind the burn-in search (#1854)", {
  draws <- TwoRuns1975()
  iter <- rep(list(seq_len(40L) * 10), 2)
  # Every column damaged, but only below `floorIter`, which no candidate can
  # retain.
  draws[[1]][2, "a"] <- NaN
  draws[[2]][3, "b"] <- NA
  res <- .AutoBurnInCore(draws, iter, floorIter = 50)
  expect_identical(res[["status"]], "ok")
  expect_gte(res[["iteration"]], 50)
})

test_that("stopping rule and burnIn = 'auto' monitor a partial sigma set alike (#1857)", {
  cols <- c("iteration", "chain", "alpha_site2", "sigma_s1", "lambda_s1",
            "lambda_s2", "posterior", "prior_parameters", "likelihood_spline")
  monitored <- cols[.ConvergenceMonitorCols(cols, "alpha_site2", c("s1", "s2"))]
  summarised <- .ConvergenceGate(cols, "alpha_site2", c("s1", "s2"))
  expect_true("sigma_s1" %in% monitored)
  expect_true("sigma_s1" %in% summarised)
  expect_identical(setdiff(monitored, .kLogDensityCols),
                   setdiff(summarised, c("log prior", "log likelihood",
                                         "log posterior")))
})

test_that("multiESS is unknown, not perfect, with too few draws (#1855)", {
  skip_if_not_installed("mcmcse")
  set.seed(5)
  expect_true(is.na(.MultiEssFunc(matrix(stats::rnorm(12), 3, 4))))
  expect_true(is.na(.MultiEssFunc(matrix(stats::rnorm(9), 3, 3))))

  # Three draws of a dozen parameters: no covariance estimate is possible.
  s <- summary(stratPosterior2, iterations = 1:100, runs = 4)
  expect_identical(s[[c("general", "nSamplesUsed")]], 3L)
  expect_true(is.na(s[[c("alignment1", "multiESS")]]))
})
