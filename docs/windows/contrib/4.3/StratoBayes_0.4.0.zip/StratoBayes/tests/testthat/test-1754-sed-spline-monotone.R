# GH #1754: the within-span integral used a Gauss-Legendre rule on
# [spanStart, h], whose nodes move with h, so a steep draw gave ages that fell
# as height rose.

WildSpline <- function() {
  form <- .BuildFormationSpline(0, 10, 8L, 1L)
  info <- list(nFormations = 1L, nBasis = form[["nBasis"]],
               totalBeta = form[["nBasis"]], betaStart = 1L,
               betaMap = matrix(1L), formations = list(form))
  set.seed(7)
  list(info = info, beta = rnorm(form[["nBasis"]], sd = 6))
}

test_that("sedSmooth forward map is monotone for an extreme draw (#1754)", {
  wild <- WildSpline()
  heights <- seq(0, 10, length.out = 20001)
  for (sign in c(1, -1)) {
    ages <- .sb_sed_spline_ages(wild$beta, wild$info, 1L, heights, 0, sign)
    expect_true(all(is.finite(ages)))
    expect_true(all(sign * diff(ages) >= 0))
  }
})

test_that("sedSmooth span ends keep the quadrature totals (#1754)", {
  wild <- WildSpline()
  bounds <- wild$info$formations[[1]][["intervalBounds"]]
  full <- .sb_sed_spline_full_integral(wild$beta, wild$info, 1L)
  ages <- .sb_sed_spline_ages(wild$beta, wild$info, 1L, bounds, 100, 1)
  expect_equal(ages[[1]], 100)
  expect_equal(ages[[length(ages)]], 100 + full)
  expect_equal(diff(ages), vapply(seq_along(bounds[-1]), function(i) {
    .sb_sed_spline_partial_integral(wild$beta, wild$info, 1L,
                                    bounds[[i]], bounds[[i + 1]])
  }, double(1)))
})

test_that("sedSmooth partial integrals agree with the forward map (#1754)", {
  wild <- WildSpline()
  cuts <- c(0.3, 0.31, 2.2, 5.7, 9.99)
  Partial <- function(a, b) {
    .sb_sed_spline_partial_integral(wild$beta, wild$info, 1L, a, b)
  }
  ages <- .sb_sed_spline_ages(wild$beta, wild$info, 1L, cuts, 0, 1)
  for (i in seq_along(cuts)[-1]) {
    expect_equal(Partial(cuts[[1]], cuts[[i]]), ages[[i]] - ages[[1]],
                 tolerance = 1e-12)
  }
  expect_equal(Partial(0.3, 0.31) + Partial(0.31, 2.2), Partial(0.3, 2.2),
               tolerance = 1e-12)
})

test_that("sedSmooth within-span integral matches a reference (#1754)", {
  form <- .BuildFormationSpline(0, 10, 8L, 1L)
  info <- list(nFormations = 1L, nBasis = form[["nBasis"]],
               totalBeta = form[["nBasis"]], betaStart = 1L,
               betaMap = matrix(1L), formations = list(form))
  beta <- sin(seq_len(form[["nBasis"]]))
  Rate <- function(h) .SedSplineRate(beta, info, 1L, h)
  heights <- c(0.37, 1.9, 4.444, 8.01)
  ages <- .sb_sed_spline_ages(beta, info, 1L, heights, 0, 1)
  reference <- vapply(heights, function(h) {
    integrate(Rate, 0, h, rel.tol = 1e-12)$value
  }, double(1))
  expect_equal(ages, reference, tolerance = 1e-5)
})
