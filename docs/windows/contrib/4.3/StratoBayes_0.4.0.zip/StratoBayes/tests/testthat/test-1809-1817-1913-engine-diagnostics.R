# GH #1809: the C++ chain-history snapshot ran after temper_step() swapped
# ChainStates between rungs, so a rung's history held another rung's state and
# accept flag. GH #1817: a gradient that failed at the current state left
# nGradientTransitions/nDivergent untouched. GH #1913: the engine and the
# .sb_sed_spline_* exports parsed sedSmoothInfo separately, neither checking
# shape.

# A two-chain engine from a short R-engine run.
DiagEngine <- function() {
  td <- withr::local_tempdir("diag1809")
  set.seed(1809)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1, nIter = 10,
    nChains = 2L, seed = 1, quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "d", engine = "R"
  )
  model <- result[["model"]]
  if (is.null(model[[".logpost_cpp"]]))
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "d_mcmc_run_1.rds"))
  StratoBayes:::.sb_create_engine(
    data = result[["data"]], model = model, mcmc = mcmc,
    state = mcmc[["recentState"]])
}

test_that("history snapshots record each rung's pre-swap state (#1809)", {
  skip_on_cran()
  eng <- DiagEngine()
  nIter <- 40L
  # Near-equal temperatures make almost every proposed swap accepted.
  StratoBayes:::.sb_update_temperatures(eng, c(1, 1 + 1e-9))
  StratoBayes:::.sb_configure_history(eng, nIter, 1:2)
  StratoBayes:::.sb_get_ring_buffer(eng)
  set.seed(1809)
  StratoBayes:::.sb_run_block(eng, nIter)
  ring <- StratoBayes:::.sb_get_ring_buffer(eng)
  hist <- StratoBayes:::.sb_extract_history(eng)

  expect_true(any(ring[["temperAccept"]]))
  for (ch in 1:2) {
    mine <- ring[["chain"]] == ch
    expect_equal(hist[[ch]][["count"]], nIter)
    expect_equal(hist[[ch]][["logPost"]], ring[["logPost"]][mine])
    expect_equal(hist[[ch]][["accept"]], ring[["accept"]][mine])
    expect_equal(hist[[ch]][["proposalNumber"]],
                 ring[["proposalNumber"]][mine])
  }
})

test_that("a gradient failure at the current state is counted (#1817)", {
  skip_on_cran()
  # The alphaPosition-stamp warning on reusing stratModel1's priors is moot.
  model <- suppressWarnings(StratModel(
    stratData = stratData1, priors = stratModel1[[c("priors", "metro")]],
    alignmentScale = stratModel1[["alignmentScale"]],
    sedModel = stratModel1[["sedModel"]],
    flexibleKnots = FALSE, knotRange = c(-5, 12), sigmaFixed = TRUE
  ))
  td <- withr::local_tempdir("diag1817")
  set.seed(4200)
  RunStratModel(gradientProposals = "on", stratData1, model, nIter = 30,
                nChains = 1, seed = 1, quiet = TRUE, visualise = FALSE,
                nThreads = 1L, modelDir = td, modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))
  if (is.null(model[[".logpost_cpp"]]))
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)

  nIter <- 4L
  nParam <- model[["parametersLength"]]
  for (prop in c("NUTS", "HMC")) {
    m <- mcmc
    if (prop == "HMC") {
      names(m[["propose"]])[names(m[["propose"]]) == "NUTS"] <- "HMC"
      for (fld in c("proposalProbability", "proposalProbabilityWeights")) {
        mm <- m[[c("metro", fld)]]
        if (!is.null(colnames(mm)))
          colnames(mm)[colnames(mm) == "NUTS"] <- "HMC"
        m[[c("metro", fld)]] <- mm
      }
    }
    pp <- m[[c("metro", "proposalProbability")]]
    pp[, ] <- 0
    pp[, colnames(pp) == prop] <- 1
    m[[c("metro", "proposalProbability")]] <- pp

    # Outside alpha_site_2's prior support: the gradient fails where the chain
    # stands, on every iteration.
    state <- m[["recentState"]]
    state[[1]][[c("metro", "parameters")]][["alpha_site_2"]] <- 20

    eng <- StratoBayes:::.sb_create_engine(stratData1, model, m, state)
    StratoBayes:::.sb_configure_monitor(eng, ncol(pp))
    set.seed(1817)
    StratoBayes:::.sb_run_block(eng, nIter)
    mon <- StratoBayes:::.sb_get_monitor(eng)

    expect_identical(mon[["nGradientTransitions"]], nIter, label = prop)
    expect_identical(mon[["nDivergent"]], nIter, label = prop)
    expect_identical(mon[["nDomainFailure"]], nIter, label = prop)
    expect_identical(mon[["maxTreeDepth"]], 0L, label = prop)
    loc <- mon[["divergenceLocations"]]
    expect_equal(nrow(loc), nIter, label = prop)
    expect_true(all(is.nan(loc[, 3])), label = prop)
    expect_equal(unname(loc[1, 3L + seq_len(nParam)]),
                 unname(state[[1]][[c("metro", "parameters")]]),
                 label = prop)
  }
})

SedInfo <- function() {
  form <- .BuildFormationSpline(0, 10, 6L, 1L)
  list(nFormations = 1L, nBasis = form[["nBasis"]],
       totalBeta = form[["nBasis"]], betaStart = 1L,
       betaMap = matrix(1L, 1, 1), formations = list(form))
}

test_that(".sb_sed_spline_* refuse a mis-shaped sedSmoothInfo (#1913)", {
  info <- SedInfo()
  beta <- rep(0, info[["totalBeta"]])
  expect_equal(.sb_sed_spline_full_integral(beta, info, 1L), 10)
  # D is optional to the quadrature.
  noD <- info
  noD[["formations"]][[1]][["D"]] <- NULL
  expect_equal(.sb_sed_spline_full_integral(beta, noD, 1L), 10)

  wide <- info
  basis <- wide[["formations"]][[1]][["basisAtNodes"]]
  wide[["formations"]][[1]][["basisAtNodes"]] <- cbind(basis, 0)
  expect_error(.sb_sed_spline_full_integral(beta, wide, 1L), "basisAtNodes")

  short <- info
  short[["formations"]][[1]][["intervalBounds"]] <-
    short[["formations"]][[1]][["intervalBounds"]][-1]
  expect_error(.sb_sed_spline_ages(beta, short, 1L, 5, 0, 1),
               "intervalBounds")

  typed <- info
  typed[["formations"]][[1]][["nodes"]] <-
    as.character(typed[["formations"]][[1]][["nodes"]])
  expect_error(.sb_sed_spline_full_integral(beta, typed, 1L), "nodes")

  mapped <- info
  mapped[["betaMap"]][1, 1] <- 2L
  expect_error(.sb_sed_spline_full_integral(beta, mapped, 1L), "betaMap")

  starts <- info
  starts[["betaStart"]] <- c(1L, 1L)
  expect_error(.sb_sed_spline_partial_integral(beta, starts, 1L, 0, 1),
               "betaStart")
})

test_that("the engine refuses a mis-shaped sedSmoothInfo (#1913)", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 5)
  td <- withr::local_tempdir("diag1913")
  result <- RunStratModel(stratData1, model, mcmc, engine = "cpp",
                          nThreads = 1L, quiet = TRUE, visualise = FALSE,
                          modelDir = td, modelName = "e")
  engineModel <- result[["model"]]
  if (is.null(engineModel[[".logpost_cpp"]]))
    engineModel[[".logpost_cpp"]] <-
      StratoBayes:::.PrepareLogPostArgs(engineModel)
  run <- readRDS(file.path(td, "e_mcmc_run_1.rds"))
  # Straight to the engine: through RunStratModel() the R-side age
  # conversion's own .sb_sed_spline_* check would refuse first.
  Build <- function(Mutate) {
    m <- engineModel
    m[["sedSmoothInfo"]] <- Mutate(m[["sedSmoothInfo"]])
    StratoBayes:::.sb_create_engine(result[["data"]], m, run,
                                    run[["recentState"]])
  }
  expect_no_error(Build(identity))
  expect_error(Build(function(x) {
    x[["formations"]][[1]][["D"]] <- NULL
    x
  }), "penalty matrix")
  expect_error(Build(function(x) {
    x[["formations"]][[1]][["hLow"]] <- "0"
    x
  }), "hLow")
  expect_error(Build(function(x) {
    x[["formations"]][[1]][["basisAtNodes"]] <-
      cbind(x[["formations"]][[1]][["basisAtNodes"]], 0)
    x
  }), "basisAtNodes")
  expect_error(Build(function(x) {
    x[["betaMap"]] <- x[["betaMap"]][, 1, drop = FALSE]
    x
  }), "betaMap")
})
