# #2049 / #1816: `.CalculateNewAges()` answers in sorted-height order, so
# `.SaveMCMChistory()` must map it back with the inverse permutation.
test_that(".SaveMCMChistory records heights in their original order (#2049)", {
  # Monotone, so sorting inputs sorts outputs; returned in input order, as
  # the real function does.
  local_mocked_bindings(
    .CalculateNewAges = function(data, indices, parameters, site, heights) {
      heights * 2
    }
  )
  h <- c(10, 20, 30, 0)
  model <- list(heightsForClustering = list(h), siteIndices = 1L,
                parametersLength = 2L, ind = list())
  metro <- list(
    historyLength = 4L,
    acceptanceLength = 10L,
    clustWithParametersMCMC = FALSE,
    enableRingBuffer = FALSE,
    historySize = 0L,
    historyRingPos = 1L,
    chainHistory = list(matrix(0, nrow = 4L, ncol = 2L + length(h) + 1L)),
    acceptance = array(NA_real_, dim = c(1L, 10L, 1L)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
  )
  mcmc <- list(temper = list(temperatures = 1), metro = metro)
  state <- list(list(metro = list(parameters = c(1, 2), logPost = -1,
                                  accept = TRUE, proposalNumber = 1L)))

  out <- .SaveMCMChistory(data = NULL, model = model, mcmc = mcmc,
                          state = state, inLateAdaptation = FALSE)

  expect_equal(out[["chainHistory"]][[1]][1, 2L + seq_along(h)], h * 2)
})
