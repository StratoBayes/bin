# #2015: a continuation must not silently append draws from a different
# posterior. `outputParams` is unchanged by every edit below, so the only thing
# standing between them and one samples file holding two posteriors is
# `.CheckModelAgainstStored()`.

.Stored2015 <- function(model = stratModel1) {
  dir <- withr::local_tempdir(.local_envir = parent.frame())
  saveRDS(model, file.path(dir, "m_model.rds"))
  dir
}

test_that("an unchanged real StratModel passes after an .rds round trip", {
  dir <- .Stored2015()
  expect_silent(StratoBayes:::.CheckModelAgainstStored(stratModel1, dir, "m"))
})

test_that("a changed prior warns and names the parameter", {
  dir <- .Stored2015()
  supplied <- stratModel1
  param <- supplied[["parametersNames"]][[1]]
  supplied[[c("priors", "metro")]][[1]] <- UniformPrior(-500, -499)

  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    paste0("priors: ", param)
  )
})

test_that("changed Gibbs hyperpriors, overlap penalty and proposal checks warn", {
  edits <- list(
    gibbsPriors = function(m) {
      m[[c("priors", "gibbs", "aLambda")]] <-
        m[[c("priors", "gibbs", "aLambda")]] * 10
      m
    },
    overlapAdjustments = function(m) {
      m[[c("overlapPenalty", "adjustments")]] <-
        lapply(m[[c("overlapPenalty", "adjustments")]], function(x) x * 4)
      m
    },
    ratesRange = function(m) {
      m[[c("proposeChecks", "ratesMax")]] <- 3
      m
    },
    lambdaMin = function(m) {
      m[[c("priors", "gibbs", "lambdaMin")]] <-
        m[[c("priors", "gibbs", "lambdaMin")]] * 100
      m
    },
    minSignalOverlap = function(m) {
      m[[c("proposeChecks", "overlap")]] <- 7
      m
    }
  )
  expect_true(isTRUE(stratModel1[[c("overlapPenalty", "overlapPenalty")]]))

  for (key in names(edits)) {
    dir <- .Stored2015()
    pattern <- if (key == "lambdaMin") "gibbsPriors" else key
    expect_warning(
      StratoBayes:::.CheckModelAgainstStored(edits[[key]](stratModel1), dir, "m"),
      pattern,
      label = paste("altering", key)
    )
  }
})

test_that("moved fixed knots warn", {
  stored <- stratModel1
  stored[[c("splineBase", "knots")]] <- seq(0, 10, length.out = 5)
  dir <- .Stored2015(stored)
  supplied <- stratModel1
  supplied[[c("splineBase", "knots")]] <- seq(-5, 15, length.out = 5)

  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    "fixedKnots"
  )
})

test_that("a custom prior with a changed density warns", {
  Custom <- function(D) Prior(stats::runif, D, stats::qunif, min = -6, max = 12)
  stored <- stratModel1
  stored[[c("priors", "metro")]][[1]] <- Custom(stats::dunif)
  dir <- .Stored2015(stored)
  supplied <- stratModel1
  supplied[[c("priors", "metro")]][[1]] <- Custom(stats::dlogis)

  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    "priors: "
  )
})

test_that("the warning no longer claims saved samples stay valid", {
  dir <- .Stored2015()
  supplied <- stratModel1
  supplied[["alphaPosition"]] <- "top"
  warnings <- testthat::capture_warnings(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m")
  )
  expect_length(warnings, 1L)
  expect_no_match(warnings, "without invalidating")
  expect_match(warnings, "two posteriors")
})

test_that("a changed Fixed() set is fatal and names the parameters", {
  dir <- .Stored2015()
  supplied <- stratModel1
  free <- supplied[[c("ind", "paramNotFixed")]]
  dropped <- supplied[["parametersNames"]][free[[1]]]
  supplied[[c("ind", "paramNotFixed")]] <- free[-1]

  expect_error(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    paste0("Fixed.*", dropped)
  )
})

test_that("RunStratModel warns when a continuation's prior differs", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 2, nChains = 2, nThreads = 1L, visualise = FALSE,
                      seed = 1, runParallel = FALSE, quiet = TRUE)

  # Discriminator: the unchanged model continues without a word, so the
  # fingerprint survives the stored model's trip through the sampler and .rds.
  expect_no_warning(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                  stratModel = stratModel1, nIter = 2, nThreads = 1L,
                  visualise = FALSE, quiet = TRUE)
  )

  shifted <- stratModel1
  shifted[[c("priors", "metro")]][[1]] <- UniformPrior(-7, 13)
  shifted[["priorsProposals"]][[1]] <- UniformPrior(-7, 13)
  expect_warning(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                  stratModel = shifted, nIter = 2, nThreads = 1L,
                  visualise = FALSE, quiet = TRUE),
    "priors"
  )
})
