# StratData works with a parts duplication

    Code
      summary(StratData(signal = signalDF, parts = sedRatesDF))
    Output
      
      Stratigraphic data from 2 sites:
        1, 2
      
      1 signal: value
        value:
          Points per site: 2, 3
          Signal spans: 1 m, 2 m
          Signal top: 2 m, 5 m
          Signal bottom: 1 m, 3 m
      
      Partitions: sandstone, limestone
        Partitions per site: 1, 1
      
      Ties: none
      

# StratData works with minimal example test-0

    Code
      summary(StratData(testData[["signal"]]))
    Output
      
      Stratigraphic data from 2 sites:
        1, 2
      
      1 signal: value
        value:
          Points per site: 5, 4
          Signal spans: 4 m, 3 m
          Signal top: 4 m, -1 m
          Signal bottom: 0 m, -4 m
      
      Partitions: 1
      
      Ties: none
      

# StratData works with example test-1a

    Code
      summary(StratData(testData[["signal"]], parts = testData[["parts"]], ties = testData[[
        "ties"]]))
    Output
      
      Stratigraphic data from 3 sites:
        1, 2, 3
      
      1 signal: value
        value:
          Points per site: 3, 1, 5
          Signal spans: 43 m, 0 m, 20 m
          Signal top: 23 m, 0 m, 70 m
          Signal bottom: -20 m, 0 m, 50 m
      
      Partitions: 1, 2
        Partitions per site: 1, 1, 2
        Gaps per site: 1, 0, 1
      
      Ties (mean values): 80
      

# StratData works with example test-1b

    Code
      summary(StratData(testData[["signal"]], parts = testData[["parts"]], ties = testData[[
        "ties"]]))
    Output
      
      Stratigraphic data from 3 sites:
        1, 2, 3
      
      1 signal: value
        value:
          Points per site: 3, 1, 5
          Signal spans: 43 m, 0 m, 20 m
          Signal top: 23 m, 0 m, 70 m
          Signal bottom: -20 m, 0 m, 50 m
      
      Partitions: 1, 2
        Partitions per site: 1, 1, 2
        Gaps per site: 1, 0, 1
      
      Ties (likelihood): dnorm(80, 2), dunif(50, 60)
      

# StratData works with selectSites

    Code
      summary(StratData(testData[["signal"]], parts = testData[["parts"]], ties = testData[[
        "ties"]], selectSites = 2:3))
    Output
      
      Stratigraphic data from 2 sites:
        2, 3
      
      1 signal: value
        value:
          Points per site: 1, 5
          Signal spans: 0 m, 20 m
          Signal top: 0 m, 70 m
          Signal bottom: 0 m, 50 m
      
      Partitions: 1, 2
        Partitions per site: 1, 2
        Gaps per site: 0, 1
      
      Ties (likelihood): dunif(50, 60)
      

# StratData works with referenceSites

    Code
      summary(StratData(testData[["signal"]], parts = testData[["parts"]], ties = testData[[
        "ties"]], referenceSite = "2"))
    Output
      
      Stratigraphic data from 3 sites:
        2, 1, 3
      
      1 signal: value
        value:
          Points per site: 1, 3, 5
          Signal spans: 0 m, 43 m, 20 m
          Signal top: 0 m, 23 m, 70 m
          Signal bottom: 0 m, -20 m, 50 m
      
      Partitions: 1, 2
        Partitions per site: 1, 1, 2
        Gaps per site: 0, 1, 1
      
      Ties (likelihood): dnorm(80, 2), dunif(50, 60)
      

# StratData works on depth scale

    Code
      summary(StratData(testData[["signal"]], parts = testData[["parts"]], ties = testData[[
        "ties"]], zColumn = "depth", zScale = "depth"))
    Output
      
      Stratigraphic data from 2 sites:
        1, 2
      
      1 signal: value
        value:
          Points per site: 6, 6
          Signal spans: 5 m, 5 m
          Signal top: 0 m, 5 m
          Signal bottom: -5 m, 0 m
      
      Partitions: 1, 3, 2
        Partitions per site: 1, 2
        Gaps per site: 1, 1
      
      Ties (mean values): 0, 5
      

# StratData works with a data set having two signals

    Code
      summary(StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
      signalColumn = c("a", "b")))
    Output
      
      Stratigraphic data from 2 sites:
        site1, site2
      
      2 signals: a, b
        a:
          Points per site: 74, 40
          Signal spans: 79 m, 50.5 m
          Signal top: 80 m, 50 m
          Signal bottom: 1 m, -0.5 m
        b:
          Points per site: 76, 38
          Signal spans: 79 m, 51.3 m
          Signal top: 80 m, 50.2 m
          Signal bottom: 1 m, -1.2 m
      
      Partitions: part 1.1, part 2.1, part 2.2
        Partitions per site: 1, 2
      
      Ties: none
      

---

    Code
      summary(StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
      signalColumn = c("a", "b")))
    Output
      
      Stratigraphic data from 2 sites:
        site1, site2
      
      2 signals: a, b
        a:
          Points per site: 74, 29
          Signal spans: 79 m, 30.5 m
          Signal top: 80 m, 30 m
          Signal bottom: 1 m, -0.5 m
        b:
          Points per site: 76, 30
          Signal spans: 79 m, 31.3 m
          Signal top: 80 m, 30.2 m
          Signal bottom: 1 m, -1.2 m
      
      Partitions: part 1.1, part 2.1, part 2.2
        Partitions per site: 1, 2
        Gaps per site: 0, 1
      
      Ties: none
      

# StratData works with a data set having two signals and gaps and different site and zColumn names

    Code
      summary(StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
      signalColumn = c("a", "b"), zColumn = "Hight", siteColumn = "SIT"))
    Output
      
      Stratigraphic data from 2 sites:
        site1, site2
      
      2 signals: a, b
        a:
          Points per site: 74, 29
          Signal spans: 79 m, 30.5 m
          Signal top: 80 m, 30 m
          Signal bottom: 1 m, -0.5 m
        b:
          Points per site: 76, 30
          Signal spans: 79 m, 31.3 m
          Signal top: 80 m, 30.2 m
          Signal bottom: 1 m, -1.2 m
      
      Partitions: part 1.1, part 2.1, part 2.2
        Partitions per site: 1, 2
        Gaps per site: 0, 1
      
      Ties: none
      

