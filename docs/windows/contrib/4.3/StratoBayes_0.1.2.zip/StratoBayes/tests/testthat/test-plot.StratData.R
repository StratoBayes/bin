set.seed(0)

## test-0

test_that("plot.StratData can plot StratData - test-1 - signal", {
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, cex = 2)
  vdiffr::expect_doppelganger("plot.StratData-test-1-signal", plot1)
})

test_that("plot.StratData can plot StratData - test-1 - signal - all", {
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, type = "l", signal = "all")
  vdiffr::expect_doppelganger("plot.StratData-test-1-signall-all", plot1)
})

test_that("plot.StratData can plot StratData - test-1 - partition", {
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, show = "partition", colourScale = "Viridis")
  vdiffr::expect_doppelganger("plot.StratData-test-1-partition", plot1)
})

## test-1

testData <- .GenerateTestData(version = "1a")

test_that("plot.StratData can plot StratData - test-1a - partition", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties), show = "partition", ylim = c(-25,100))
  vdiffr::expect_doppelganger("plot.StratData-test-1a-partition", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - select sites", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", sites = c(3,1), colourScale = "Cold", pch = 22)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-select-sites", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - single site", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", sites = 1, colourScale = "Cold", pch = 22)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-single-site", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - all", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", signal = "all", pch = 22, sites = 3:2)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-all", plot1)
})

# test Multi


test_that("plot.StratData can plot StratData - test-multi-1 - signal - all", {
  testDataMulti <- .GenerateTestData("multi",version = "1")
  plot1 <- function() plot(StratData(testDataMulti$signal, parts = testDataMulti$parts, signalColumn = c("a", "b")), signal = "all", sites = "all", pch = 22:24)
  vdiffr::expect_doppelganger("plot.StratData-test-multi-1-signal-all", plot1)
})



test_that("plot.StratData works with depth data - type o", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - type o", function() {
    plot(stratData3, type = "o", colourBy = "p")
  })
})

test_that("plot.StratData works with depth data - type l", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - type l", function() {
    plot(stratData3, type = "l", colourBy = "p")
  })
})

test_that("plot.StratData works with depth data - all in one plot", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - all in one plot", function() {
    plot(stratData3, signal = "all")
  })
})


## test plot return

test_that("signal return works", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plotReturn <- plot(t1, show = "signal", display = FALSE, sites = c(3,1))
  expect_snapshot(plotReturn)
})


test_that("signal return works - two signals", {
  testDataMulti <- .GenerateTestData("multi", version = "1")
  plotReturn <- plot(StratData(testDataMulti[["signal"]],
                               parts = testDataMulti$parts,
                               signalColumn = c("a", "b")), show = "signal",
                     display = FALSE, signal = "all")
  expect_snapshot(plotReturn)
})

test_that("partition return works", {
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plotReturn <- plot(t1, show = "partition", display = FALSE)
  expect_snapshot(plotReturn)
})

test_that("plot.stratData produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({plot(stratData3)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
