test_that(".AgeConversionGeneral works and fails gracefully", {

  expect_error(.AgeConversionGeneral(NULL, 1, 1),
               "`parameters`.* be a numeric")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = 1),
               "`stratPosterior`.* an object")

  expect_error(.AgeConversionGeneral(1, 1, 1),
               "If `stratPosterior` is not supplied, `stratData` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratData = stratData1),
               "If neither `stratPosterior` nor `indices` .* supplied, `stratModel` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* be a numeric of")

  expect_error(.AgeConversionGeneral(data.frame(a = 1:3, b = 1:3), 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* a numeric vector")

  expect_error(.AgeConversionGeneral(1:4, "a", 1,
                                     stratPosterior = stratPosterior1),
               "`heights` .* be numeric")

  expect_error(.AgeConversionGeneral(1:4, 1, "b",
                                     stratPosterior = stratPosterior1),
               "`site` .* be exactly one of the sites")

  expect_equal(.AgeConversionGeneral(stratPosterior1$samples[100, 1:4, 1, 1],
                                     1, 2, stratData = stratData1,
                                     stratModel = stratModel1),
               8.2, tolerance = 0.1)

})

test_that(".AgeConversionGeneral works when sitenames are identical to indices", {
  # Create a StratData object with site names that are numeric
  data_i <- StratData(
    signal = data.frame(
      value = c(1, 2, 2, 2, 3, 1, 1.5, 3, 4, 3),
      well = c(1, 1, 1, 2, 2, 2, 3, 4, 4, 4),
      height = c(10, 15, 16, 20, 30, 35, 40, 20, 21, 22)
    ),
    selectSites = c(1, 2, 4),
    siteColumn = "well")
  stratModel2 <- StratModel(data_i,
                            alignmentScale = "h",
                            sedModel = "s",
                            priors = NULL,
                            individualSplineIter = 4)

  expect_equal(.AgeConversionGeneral(1:4, 21, 3, stratData = data_i,
                        stratModel = stratModel2), 2)

})
