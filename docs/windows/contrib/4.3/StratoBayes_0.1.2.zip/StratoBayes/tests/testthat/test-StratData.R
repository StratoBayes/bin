test_that(".NaPad() works", {
  n <- 4
  expect_equal(.NaPad(NULL, n), rep(NA_real_, n))
  expect_equal(.NaPad(NULL, n, logical), rep(NA, n))
  expect_equal(.NaPad(1, n), c(1, NA, NA, NA))
  expect_equal(.NaPad(1:n, n), 1:n)
})

test_that(".FillGaps() works", {

  parts0 <- data.frame(
    site = c("site a", "site b"),
    height = c(80.0, 10.5),
    partition = c("part 1.1", "part 2.1"),
    stringsAsFactors = FALSE
  )

  parts1 <- data.frame(
    site = c("site1", "site2", "site2", "site2", "site2"),
    height = c(80.0, 10.5, 20.0, 20, 51.0),
    partition = c("part 1.1", "part 2.1", "part2.2", NA, "part 2.2"),
    stringsAsFactors = FALSE
  )

  parts2 <- data.frame(
    site = c("site1", "site2", "site2", "site2", "site2"),
    height = c(80.0, 10.5, 20.0, 30.0, 51.0),
    somethingElse = 1:5,
    partition = c("part 1.1", "part 2.1", NA, NA, "part 2.2"),
    sedRate = c(1,2,NA,NA,3),
    stringsAsFactors = FALSE
  )
  parts2complete <- data.frame(
    site = c("site1", "site2", "site2", "site2", "site2", "site2", "site2"),
    height = c(80.0, 10.5, 20.0,20.0, 30.0, 30.0, 51.0),
    somethingElse = c(1,2,5,3,5,4,5),
    partition = c("part 1.1", "part 2.1", "part 2.2", NA, "part 2.2", NA, "part 2.2"),
    sedRate = c(1,2,3,NA,3,NA,3),
    stringsAsFactors = FALSE
  )
    parts3 <- data.frame(
    site = c("site1","site1", "site2", "site2", "site2", "site2"),
    height = c(79,80.0, 10.5, 20.0, 30.0, 51.0),
    partition = c(NA,"part 1.1", "part 2.1", NA, NA, "part 2.2"),
    stringsAsFactors = FALSE
  )

  parts3complete <- data.frame(
      site = c("site1","site1", "site1", "site2", "site2", "site2", "site2", "site2", "site2"),
      height = c(79, 79, 80.0, 10.5, 20.0,20.0, 30.0, 30.0, 51.0),
      partition = c("part 1.1", NA, "part 1.1", "part 2.1", "part 2.2", NA, "part 2.2", NA, "part 2.2"),
      stringsAsFactors = FALSE
    )

  expect_equal(parts0, .FillGaps(parts0))
  expect_equal(parts1, .FillGaps(parts1))
  expect_equal(parts2complete, .FillGaps(parts2))
  expect_equal(parts3complete, .FillGaps(parts3))
})

### test-0


test_that("StratData() works with test-0", {
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  expect_true(is.list(t0))
  expect_true(all(c("sites", "S", "zScale", "signalAttr", "signal", "partsAttr", "parts") %in% names(t0)))

  # Check for specific components
  expect_true(is.character(t0$sites))
  expect_length(t0$sites, 2)
  expect_true(is.numeric(t0$S))
  expect_equal(t0$zScale, "height")
  expect_equal(t0$zColumn, "height")
  expect_true(is.list(t0$signalAttr))

  # check some of signalAttr
  expect_true(is.numeric(t0$signalAttr$signalN))
  expect_true(is.numeric(t0$signalAttr$Nall))
  expect_equal(t0$signalAttr$maxN, 5)

  # Check signalPartsB
  expect_true(is.vector(t0$signalAttr$signalPartsB))
  expect_equal(length(t0$signalAttr$signalPartsB), 9)
  expect_equal(t0$signalAttr$signalPartsB[[5]], 1)

  # Check siteInd
  expect_true(is.list(t0$signalAttr$siteInd))
  expect_length(t0$signalAttr$siteInd, 2)
  expect_equal(t0$signalAttr$siteInd[[1]], 1:5)
  expect_equal(t0$signalAttr$siteInd[[2]], 6:9)

  # Check boundWsignal
  expect_true(is.list(t0$signalAttr$boundWsignal))
  expect_length(t0$signalAttr$boundWsignal, 2)
  expect_equal(t0$signalAttr$boundWsignal[[1]], 1)
  expect_equal(t0$signalAttr$boundWsignal[[2]], 1)

  # Check signalBind
  expect_true(is.list(t0$signalAttr$signalBind))
  expect_length(t0$signalAttr$signalBind, 2)
  expect_equal(t0$signalAttr$signalBind[[1]], matrix(c(1, 5), nrow = 2))
  expect_equal(t0$signalAttr$signalBind[[2]], matrix(c(1, 4), nrow = 2))

  # Validate signal
  expect_true(is.data.frame(t0$signal))
  expect_true(is.numeric(t0$signal$value))
  expect_equal(t0$signal$value, c(-2, 0, 2, 4, 2, -3, -1, 1, 3))
  expect_true(is.numeric(t0$signalAttr$sigs$value$signalInd))
  expect_equal(t0$signalAttr$sigs$value$signalInd, 1:9)

  expect_true(is.list(t0$signalAttr$sigs$value$signalIndSite))
  expect_true(is.numeric(t0$signalAttr$sigs$value$signalIndSite$`1`))
  expect_equal(t0$signalAttr$sigs$value$signalIndSite$`1`, 1:5)
  expect_true(is.numeric(t0$signalAttr$sigs$value$signalIndSite$`2`))
  expect_equal(t0$signalAttr$sigs$value$signalIndSite$`2`, 6:9)

  expect_equal(t0$signalAttr$nPerSignal[[1]], 9)

  # Validate parts
  expect_true(is.numeric(t0$partsAttr$nBound))
  expect_equal(t0$partsAttr$nBound, c(1, 1))
  expect_true(is.numeric(t0$partsAttr$nSedRates))
  expect_equal(t0$partsAttr$nSedRates, c(1, 1))

  # Check matrices and their dimensions
  expect_true(is.matrix(t0$partsAttr$sedRatesDFOri))
  expect_equal(dim(t0$partsAttr$sedRatesDFOri), c(1, 2))
  expect_equal(t0$partsAttr$sedRatesDFOri, matrix(c(1, 1), nrow = 1))

  # Check for unique and numeric parts
  expect_true(is.numeric(t0$partsAttr$uniqueParts))
  expect_equal(t0$partsAttr$uniqueParts, 1,
               ignore_attr = TRUE # fmatch hash in attributes
               )
  expect_true(is.numeric(t0$partsAttr$numericParts))
  expect_equal(t0$partsAttr$numericParts, 1)

})

test_that("StratData fails with inappropriate input", {
  # NA input
  expect_error(StratData(NA),
               "signal must be a data frame")
  # only one site
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "a"))
  expect_error(StratData(signal1, zColumn = "x"),
               "signal data needs to be from at least two sites, but `site` has less than two unique values.")

  # wrong selectSites
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "b"))
  expect_error(StratData(signal1, zColumn = "x", selectSites = c("a", "b", "c")),
               "selectSites must be NULL or")

  # wrong referenceSite
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "b"))
  expect_error(StratData(signal1, zColumn = "x", referenceSite = c("a", "b")),
               "referenceSite needs to be a single")

  # different sites
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "c"))
  parts1 <- data.frame(x = 2:4, partition = c("a", "b", "b"), site = c("a", "b", "c"))
  expect_error(StratData(signal1, parts = parts1, zColumn = "x"),
               "sites in `parts` must also occur in `signal`")

  # different sites
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "b"))
  parts1 <- data.frame(x = 2:4, partition = c("a", "b", "b"), site = c("a", "b", "b"))
  ties1 <- data.frame(x = 2:4, mean = 1:3, sd = c(1,2,3), site = c("a", "b", "c"))

  expect_error(StratData(signal1, parts = parts1, ties = ties1, zColumn = "x"),
               "sites in `ties` must also occur in `signal` and `parts`")

  # NAs in zColumn
  signal1 <- data.frame(x = c(1,1,NA), value = 1:3, site = c("a", "a", "b"))
  parts1 <- data.frame(x = 2:4, partition = c("a", "b", "b"), site = c("a", "b", "b"))
  ties1 <- data.frame(x = 2:4, mean = 1:3, sd = c(1,2,3), site = c("a", "b", "b"))

  expect_error(StratData(signal1, parts = parts1, ties = ties1, zColumn = "x"),
               "signal has NA values in the following columns: x")

  # only NAs in second site
  signal1 <- data.frame(x = c(1,2,2,2), value = c(1,1,NA,NA),
                        value2 = c(1,1,2,1), site = c("a", "a", "b", "c"))
  parts1 <- data.frame(x = c(1.5,1.5,2,3,3), partition = c("a", NA, "d", "b", "c"), site = c("a", "a", "a", "b", "c"))
  ties1 <- data.frame(x = c(1,1,1), mean = 1:3, sd = c(1,2,3), site = c("a", "b", "b"))

  expect_error(StratData(signal1, parts = parts1, ties = ties1, zColumn = "x",
                         signalColumn = c("value", "value2")),
               "at least two sites for each signalColumn need to have non-NA values")

  # signal site doesn't occur in parts
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "b", "c"))
  parts1 <- data.frame(x = c(1,3,4), partition = c("1", "2", "3"), site = c("a", "a", "b"))

  expect_error(StratData(signal1, parts = parts1, zColumn = "x"),
               "sites in `signal` must also occur in `parts`")

  # signal heights above partition tops
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "c"))
  parts1 <- data.frame(x = c(1,1.5,4), partition = c("1", "2", "3"), site = c("a", "a", "c"))

  expect_error(
    StratData(signal1, parts = parts1, zColumn = "x"),
    "Site 'a' in `signal`.* heights greater than.* maximum.* in `parts`"
  )

  # tie heights above partition tops
  signal1 <- data.frame(x = 1:3, value = 1:3, site = c("a", "a", "c"))
  parts1 <- data.frame(x = c(1,2,3), partition = c("1", "2", "3"), site = c("a", "a", "c"))
  ties1 <- data.frame(x = c(1,4), site = c("c","c"),
                      densityFun = c("dnorm", "dnorm"), arg1 = 1:2, arg2 = c(1,1) )
  expect_error(
    StratData(signal1, parts = parts1, ties = ties1, zColumn = "x"),
    "Site 'c' in `ties` .*heights greater than.* maximum.* in `parts`")
})


test_that("StratData works with a parts duplication", {
  signalDF <- data.frame(
    height = 1:5,
    site = c(1, 1, 2, 2, 2),
    value = seq(-2, 2, length.out = 5)
  )
  sedRatesDF <- data.frame(
    height = c(1, 2, 5),
    site = c(1, 1, 2),
    partition = c("sandstone", "sandstone", "limestone")
  )
  expect_snapshot(summary(
    StratData(signal = signalDF, parts = sedRatesDF)
  ))
})


test_that("StratData works with minimal example test-0", {
  testData <- .GenerateTestData(version = "1")

  expect_snapshot(
    summary(StratData(testData[["signal"]]))
  )
})


test_that("StratData works with example test-1a", {
  testData <- .GenerateTestData(version = "1a")

  expect_snapshot(
    summary(StratData(testData[["signal"]], parts = testData[["parts"]],
                      ties = testData[["ties"]]))
  )
})


test_that("StratData works with example test-1b", {
  testData <- .GenerateTestData(version = "1b")

  expect_snapshot(
    summary(StratData(testData[["signal"]], parts = testData[["parts"]],
                      ties = testData[["ties"]]))
  )
})

test_that("StratData works with selectSites", {
  testData <- .GenerateTestData(version = "1b")

  expect_snapshot(
    summary(StratData(testData[["signal"]], parts = testData[["parts"]],
                      ties = testData[["ties"]], selectSites = 2:3))
  )
})

test_that("StratData works with referenceSites", {
  testData <- .GenerateTestData(version = "1b")

  expect_snapshot(
    summary(StratData(testData[["signal"]], parts = testData[["parts"]],
                      ties = testData[["ties"]], referenceSite = "2"))
  )
})

test_that("StratData works on depth scale", {
  testData <- .GenerateTestData(testdata = "depth")

  expect_snapshot(
    summary(StratData(testData[["signal"]], parts = testData[["parts"]],
                      ties = testData[["ties"]],
                      zColumn = "depth", zScale = "depth"))
  )
})

test_that("StratData works with a data set having two signals", {
  testDataMulti <- .GenerateTestData("multi", version = "1")

  expect_snapshot(summary(
    StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
              signalColumn = c("a", "b"))
  ))
})

test_that("StratData works with a data set having two signals and gaps and different site and zColumn names", {
  testDataMulti <- .GenerateTestData("multi", version = "gap-names")

  expect_snapshot(summary(
    StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
              signalColumn = c("a", "b"), zColumn = "Hight",
              siteColumn = "SIT")
  ))
})

test_that("StratData works with a data set having two signals", {
  testDataMulti <- .GenerateTestData("multi", version = "gap")

  expect_snapshot(summary(
    StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
              signalColumn = c("a", "b"))
  ))
})

test_that("StratData works with reading CSV files", {
  stratData1a <- StratData(
    signal = signalData1,
    ties = tiesData1,
    parts = partsData1)

  stratData1b <- StratData(
    signal = system.file("extdata", "signalData1.csv", package = "StratoBayes"),
    ties = system.file("extdata", "tiesData1.csv", package = "StratoBayes"),
    parts = system.file("extdata", "partsData1.csv", package = "StratoBayes"))

  expect_equal(stratData1a, stratData1b, ignore_attr = TRUE)
})


test_that("SignalLookUp works", {
  testDataMulti <- .GenerateTestData("multi", version = "gap")

  tm <- StratData(testDataMulti$signal, parts = testDataMulti$parts, signalColumn = c("a", "b"))
  expect_error(SignalLookUp(stratData = tm, type = "height", site = 1, includeNAsignal = FALSE))
  expect_error(SignalLookUp(stratData = tm, type = "value", site = "all"))

  expect_equal(length(SignalLookUp(stratData = tm, type = "height", site = 2)),64)
  expect_equal(SignalLookUp(stratData = tm, type = "height", site = "all"),
  SignalLookUp(stratData = tm, type = "height", site = "all", signal = 1))
  expect_equal(length(SignalLookUp(stratData = tm, type = "height", signal = "a", site = 2,
                                    includeNAsignal = FALSE)),
               length(SignalLookUp(stratData = tm, type = "value", signal = "a", site = 2,
                                    includeNAsignal = FALSE)))
  expect_equal(length(SignalLookUp(stratData = tm, type = "value", signal = "a", site = "all",
                                    includeNAsignal = FALSE)), length(which(!is.na(tm$signal$a))))
})
