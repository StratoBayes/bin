test_that("BeanPlot works", {
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 1", function() {
    set.seed(1)
    BeanPlot(stratPosterior1)
  })
})

test_that("BeanPlot works with custom settings", {
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 2", function() {
    set.seed(1)
    BeanPlot(stratPosterior2, parameters = c(3:5, "posterior"),
            alignment = 1:2, col = c("blue", "red"),
            iterations = 4000:5000, runs = 1:2,
            xlab = expression(alpha[3], log~gamma[1], log~gamma[2], "posterior"),
            cex.axis = 1.2, cex.lab = 1.2,
            ylab = c("alpha", "log gamma", "log posterior"),
            border = "green")
  })
})


## Disabled due to change in BeanPlot return value! - Todo: replace test
# # to test on Github (vdiffr fails due to minute differences):
# test_that("BeanPlot returns correct values", {
#     set.seed(1)
#     values <- BeanPlot(stratPosterior2, parameters = c(3:5, "posterior"),
#              alignment = 1:2, col = c("blue", "red"),
#              iterations = 4000:5000, runs = 1:2,
#              xlab = expression(alpha[3], log~gamma[1], log~gamma[2], "posterior"),
#              cex.axis = 1.2, cex.lab = 1.2,
#              ylab = c("alpha", "log gamma", "log posterior"),
#              border = "green")
#     expect_equal(round(values[[1]], 3),
#                  round(ExtractParameters(stratPosterior2, alignment = 1:2,
#                                    iterations = 4000:5000, runs = 1:2,
#                                    parameters = "alpha_site3"),3))
#
# })


test_that("BeanPlot works with new cluster object and
          iterations before burnIn", {
            skip_on_ci()

            clustNew <- Cluster(stratPosterior1, iterations = 100:200)

            vdiffr::expect_doppelganger("BeanPlot 3", function() {
              BeanPlot(stratPosterior1, alignment = 1,
                      stratCluster = clustNew, type = "o")
            })})


test_that("BeanPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({BeanPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
