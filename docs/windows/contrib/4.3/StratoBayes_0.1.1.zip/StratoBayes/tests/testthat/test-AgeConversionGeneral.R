test_that(".AgeConversionGeneral works and fails gracefully", {

  expect_error(.AgeConversionGeneral(NULL, 1, 1),
               "`parameters`.* be a numeric")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = 1),
               "`stratPosterior`.* an object")

  expect_error(.AgeConversionGeneral(1, 1, 1),
               "If `stratPosterior` is not supplied, `stratData` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratData = stratData1),
               "If neither `stratPosterior` nor `indices` .* supplied, `stratModel` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* be a numeric of")

  expect_error(.AgeConversionGeneral(data.frame(a = 1:3, b = 1:3), 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* a numeric vector")

  expect_error(.AgeConversionGeneral(1:4, "a", 1,
                                     stratPosterior = stratPosterior1),
               "`heights` .* be numeric")

  expect_error(.AgeConversionGeneral(1:4, 1, "b",
                                     stratPosterior = stratPosterior1),
               "`site` .* be exactly one of the sites")

  expect_equal(.AgeConversionGeneral(stratPosterior1$samples[100, 1:4, 1, 1],
                                     1, 2, stratData = stratData1,
                                     stratModel = stratModel1),
               8.2, tolerance = 0.1)

})
