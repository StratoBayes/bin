## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE
)


## ----library------------------------------------------------------------------
library("StratoBayes")
set.seed(0)


## ----plot-signalData4, echo = FALSE-------------------------------------------
# Plot the modified data
par(mfrow = c(1, 3))
plot(stratData4, colourBy = "p", overridePar = F, sites = 1, ylab = "height (m)")
plot(stratData4, colourBy = "p", overridePar = F, sites = 2, ylab = "height (m)")
abline(h = 3/2 * pi, lwd = 2, lty = 3)
plot.new()
legend(
          x = par("usr")[1] * 0.99,
          y = par("usr")[4],
          legend = c(stratData4$partsAttr$uniqueParts, "hiatus"),
          title = "partitions",
          pch = c(21, 22, 23, NA),
          lty = c(NA, NA, NA, 3),
          lwd = c(NA, NA, NA, 2),
          pt.bg = c(hcl.colors(3, "Dark 3", alpha = 0.75), NA),
          bty = "n",
          xpd = TRUE
        )


## ----signalData---------------------------------------------------------------
# Determine the maximum recorded height for each site.
site1Max <- max(signalData4$height[signalData4$site == "site1"])
site2Max <- max(signalData4$height[signalData4$site == "site2"])
hiatus <- 3/2 * pi
site2BottomPartitionTop <- hiatus # hiatus height needs to appear twice

# construct the partition dataframe
partsData4 <- data.frame(
  site = c("site1", "site2", "site2", "site2"),
  height = c(site1Max, site2Max, hiatus, site2BottomPartitionTop), 
  partition = c("partition site 1", "top partition, site 2", NA, "bottom partition, site 2"))

# print dataframe
partsData4


## ----StratData----------------------------------------------------------------
stratData4 <- StratData(signal = signalData4, parts = partsData4)


## ----plot-StratData-----------------------------------------------------------
plot(stratData4, show = "partition", ylab = "height (m)")


## ----plot-signal-data---------------------------------------------------------
plot(stratData4, colourBy = "partition", ylab = "height (m)")


## ----PriorTemplate------------------------------------------------------------
StratModelTemplate(
  stratData4,
  alignmentScale = "height",
  sedModel = "partition",
  alphaPosition = "middle",
  alpha = "uniform",
  gammaLog = "normal"
)


## ----priors-------------------------------------------------------------------
site1Min <- min(signalData4$height[signalData4$site == "site1"])
site1Max <- max(signalData4$height[signalData4$site == "site1"])

stratPrior4 <- structure(list(
  "alpha_site2" = UniformPrior(min = site1Min, max = site1Max),
  "gammaLog_bottom part., site 2" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_top part., site 2" = NormalPrior(mean = 0, sd = log(2)),
  "gap_site2_1" = ExponentialPrior(rate = 1/4)),
  class = c("StratPrior", "list"))


## ----model-run, eval = FALSE--------------------------------------------------
# stratModel4 <- StratModel(stratData = stratData4,
#                     priors = stratPrior4,
#                     alignmentScale = "height",
#                     sedModel = "partition",
#                     alphaPosition = "middle",
#                     nKnots = 15,
#                     sigmaFixed = T)
# 
# stratPosterior4 <- RunStratModel(stratObject = stratData4,
#                         stratModel = stratModel4,
#                         nRun = 3,
#                         nIter = 1000,
#                         nThin = 25,
#                         runParallel = TRUE)


## ----plot---------------------------------------------------------------------
plot(stratPosterior4, alignment = 1, colourBy = "partition", ylab = "reference height (m)")


## ----summary------------------------------------------------------------------
summary(stratPosterior4)[[c("alignment1", "summary")]]


## ----BeanPlot-----------------------------------------------------------------
BeanPlot(stratPosterior4, parameters = 1:4)

