test_that("StratModelTemplate works - 01", {
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s")
  )
})

test_that("StratModelTemplate works - 02", {
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s x p",
                       gammaLog = "normal", zetaLog = "truncated normal",
                       gap = "truncated log normal")
  )
})

test_that("StratModelTemplate works - 03", {
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that("StratModelTemplate works - 04", {
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alpha = "fixed", gap = "log normal",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that("StratModelTemplate auto-assigns alignmentScale and sedModel or produces helpful errors", {

  signal <- data.frame(a = 1:4, height = 1:4, site = c("a", "a", "b", "b"))
  parts <- data.frame(height = c(4,2,4), site = c("a", "b", "b"), partition = c("x", "x", "y"))
  ties <- data.frame(height = 2, site = "a", mean = 1, sd = 1)

  testData <- StratData(signal = signal, signalColumn = "a")
  template1 <- utils::capture.output(StratModelTemplate(testData))
  expect_true(any(grepl('alignmentScale = "height"', template1)))
  expect_true(any(grepl('sedModel = "site"', template1)))

  testData <- StratData(signal = signal, parts = parts, signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*'site', 'partition'")

  testData <- StratData(signal = signal, parts = parts, ties = ties,
                        signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*Valid options are 'height'")

  expect_error(StratModelTemplate(testData, alignmentScale = "a"),
               "*'site', 'partition', 'site x partition', 'site, partition'")

})

