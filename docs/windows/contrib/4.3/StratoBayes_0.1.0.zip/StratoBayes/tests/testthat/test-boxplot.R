test_that("boxplot works", {
  set.seed(1)
  vdiffr::expect_doppelganger("boxplot 1", function() {
    boxplot(stratPosterior1)
  })})

test_that("boxplot works with custom settings", {
  vdiffr::expect_doppelganger("boxplot 2", function() {

    boxplot(stratPosterior2, parameters = c(2:3, "lambda"),
                alignment = 2, pch = 21, bg = "red", col = "blue",
            iterations = 4000:5000, xlab = c("a1", "a2", "l1", "l2"),
            ylab = c(expression(alpha), expression(lambda)))
  })})

test_that("boxplot works with different xlab and ylab settings", {
  vdiffr::expect_doppelganger("boxplot 3", function() {

    boxplot(stratPosterior3, parameters = 1,
           xlab = c("alpha[1]"), ylab = "value")
  })})

test_that("boxplot works with different xlab and ylab settings", {
  vdiffr::expect_doppelganger("boxplot 4", function() {

    boxplot(stratPosterior3, parameters = c(1,3),
            xlab = c("alpha[1]", "gamma[1]"), ylab = "value", srt = 0,
            adj = 0.5)
  })})

test_that("boxplot works with fixed parameters", {
  vdiffr::expect_doppelganger("boxplot 5", function() {

    boxplot(stratPosterior3, parameters = c(1:3))
  })})


test_that("boxplot works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior1, iterations = 100:250)

            vdiffr::expect_doppelganger("boxplot 6", function() {
              boxplot(stratPosterior1, alignment = 1,
                          stratCluster = clustNew, type = "o")
            })})


test_that("boxplot.StratPosterior produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({boxplot(stratPosterior1)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
