
test_that("plot.StratPosterior throws errors", {
  expect_error(plot(stratPosterior1, alignment = 2),
               "`alignment`.* must consist of whole numbers between 1 and 1")

  expect_error(plot(stratPosterior1, iterations = 15000),
               "No iterations")

  expect_error(plot(stratPosterior1, sites = 4),
               "`sites` may contain")
})

test_that("plot.StratPosterior works - 1", {

  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 1", function() {
    parOri <- par()
    par(col = "darkgreen", bg = rgb(0.9, 0.8, 0.8, 1), cex = 0.8, lwd = 3,
        mfrow = c(2, 2))
    plot(stratPosterior1, overridePar = FALSE)
    plot(stratPosterior1, separateSites = FALSE, overridePar = FALSE)
    par(parOri[c("col", "bg", "cex", "lwd", "mfrow")])
  })})

test_that("plot.StratPosterior works - 3", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 3", function() {
    plot(stratPosterior2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 4", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 4", function() {
    plot(stratPosterior2, signal = 1:2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 5", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 5", function() {
    plot(stratPosterior2, signal = 2,
         colourBy =  "partition", col = 1:4)
  })})


test_that("plot.StratPosterior works - 6", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 6", function() {
    plot(stratPosterior2, iterations = 25:125, signal = 1:2)
  })
})

test_that("plot.StratPosterior works with depth data - 7", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior depth", function() {
    plot(stratPosterior3, type = "l", colourBy = "p")
  })
})

test_that("plot.StratPosterior works with custom parameters - 8", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 8", function() {
    plot(stratPosterior3, type = "l", colourBy = "p",
         parameters = c(-1, 2, -1, 0))
  })
})

test_that("plot.StratPosterior works with multi alignments in one plot - 9", {
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior multi", function() {
    plot(stratPosterior2, type = "l", colourBy = "s", alignment = 1:2)
  })
})

test_that("plot.StratPosterior works with overridePar = FALSE", {
  vdiffr::expect_doppelganger("plot posterior override", function() {
    set.seed(1)
    par(mfrow = c(3, 1))
    plot(stratPosterior1, overridePar = FALSE)
  })
})

test_that(
  "plot.StratPosterior works with new cluster object and iterations before burnIn",
  {
    set.seed(0)
    clustNew <- Cluster(stratPosterior1, iterations = 100:200)
    vdiffr::expect_doppelganger("plot posterior clustNew", function() {
      plot(stratPosterior1, colourBy = "site",
           stratCluster = clustNew, type = "o")
    })
  }
)

test_that("plot.stratPosterior produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  expect_error({plot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
  unlink(tmpFile)
})
