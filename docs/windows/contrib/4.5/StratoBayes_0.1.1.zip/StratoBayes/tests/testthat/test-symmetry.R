test_that("Matrix symmetric", {
  mat <- matrix(c(0.00, 1.01, 2.01, 3.01,
                  1.00, 0.00, 4.01, 5.01,
                  2.00, 4.00, 0.00, 6.01,
                  3.00, 5.00, 6.00, 0.00), 4, 4)
  orderInd <- which(Rfast::lower_tri(rep(2+2,2)), arr.ind = TRUE)
  mat <- .MakeSymmetric(mat,orderInd)
  expect_equal(t(mat)[lower.tri(mat)], mat[lower.tri(mat)])
})
