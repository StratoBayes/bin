test_that("ExtractIterations works", {

  # errors
  expect_error(ExtractIterations(stratPosterior1, runs = 4),
               "runSelect needs")
  expect_error(ExtractIterations(stratPosterior1, burnIn = -1),
               "burnIn must")
  # trigger edge case were last iterations are not saved
  stratPosterior1modified <- stratPosterior1
  stratPosterior1modified$mcmcSummary$saveIter[[1]] <- stratPosterior1modified[[c("mcmcSummary", "saveIter")]][[1]][-201]
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 4999, runs = 1),
               "all iterations were discarded")
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 0.999),
               "all iterations were discarded")
  # burnIn
  iter <- ExtractIterations(stratPosterior1, burnIn = 0.9999)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, burnIn = 1)
  expect_equal(sapply(iter,length),
               rep(length(stratPosterior1[[c("mcmcSummary", "saveIter")]][[1]]) - 1,3))

  # iterations
  iter <- ExtractIterations(stratPosterior1, iterations = 25)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, iterations = 1:100)
  expect_equal(sapply(iter,length), c(5,5,5))
  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, 1))
  expect_equal(sapply(iter,length), c(5,3,1))

  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, NULL))
  expect_equal(sapply(iter,length), c(5,3,0))

  # runSelect
  iter <- ExtractIterations(stratPosterior1, iterations = 25,
                             runs = c(1,3))
  expect_equal(sapply(iter,length), c(1,0,1))

  # cut iterations to maxSamples
  iter <- ExtractIterations(stratPosterior1, iterations = 1:1000,
                             maxSamples = 5)
  expect_equal(sum(sapply(iter,length)), 5)

  # alignment
  iter <- ExtractIterations(stratPosterior2, alignment = 0:2)
  expect_equal(sapply(iter,length), rep(100, 4), tolerance = 0.1)

  iter <- ExtractIterations(stratPosterior2, alignment = 1, iterations = 100:200)
  iterN <- sum(sapply(iter,length))
  expect_true(iterN >= 1 && iterN <= 12)

  clustNew <- Cluster(stratPosterior1, runs = 2:3, iterations = 3900:4000)
  expect_true(any(
    ExtractIterations(stratPosterior1, alignment = 1, stratCluster = clustNew, burnIn = 0.95)[[2]]
    %in% 157:161))
  expect_equal(
    ExtractIterations(stratPosterior1, alignment = "all", stratCluster = clustNew, burnIn = 0.95)[[2]],
    192:201)
})

