## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE
)


## ----library------------------------------------------------------------------
library("StratoBayes")


## ----set-seed-----------------------------------------------------------------
set.seed(0)


## ----signalData---------------------------------------------------------------
head(signalData0)


## ----StratData----------------------------------------------------------------
stratData0 <- StratData(signal = signalData0)


## ----csv----------------------------------------------------------------------
csvPath <- system.file("extdata", "signalData0.csv", package = "StratoBayes")
stratData0 <- StratData(signal = csvPath)


## ----plot.StratData, fig.width=7, fig.height=3.5------------------------------
plot(stratData0)


## ----PriorTemplate------------------------------------------------------------
StratModelTemplate(
  stratData0,
  alignmentScale = "height",
  sedModel = "site",
  alphaPosition = "middle",
  alpha = "uniform",
  gammaLog = "normal"
)


## ----priors-------------------------------------------------------------------
stratPrior0 <- structure(list(
  "alpha_site2" = UniformPrior(min = 0.25, max = 18.7),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
  class = c("StratPrior", "list"))


## ----model--------------------------------------------------------------------
stratModel0 <- StratModel(stratData = stratData0,
                    priors = stratPrior0,
                    alignmentScale = "height",
                    sedModel = "site",
                    alphaPosition = "middle",
                    nKnots = 10)


## ----checkParallel------------------------------------------------------------
runParallel <- requireNamespace("doParallel", quietly = TRUE) &&
  parallel::detectCores() > 1
runParallel


## ----eval = TRUE, echo = FALSE------------------------------------------------
result <- StratoBayes::stratPosterior0


## ----eval = FALSE-------------------------------------------------------------
# result <- RunStratModel(stratObject = stratData0,
#                         stratModel = stratModel0,
#                         nRun = 3,
#                         nIter = 1000,
#                         nThin = 10,
#                         runParallel = runParallel)


## ----print.StratPosterior-----------------------------------------------------
result


## ----first-traceplot-code, eval = FALSE---------------------------------------
# TracePlot(result, parameters = 1:2)


## ----plot-first-trace, fig.width = 5, fig.height = 4, echo = FALSE------------
par(mar = c(4.1, 4.1, 1, 1))
TracePlot(result, parameters = 1:2)


## ----plot.StratPosterior, fig.width = 4, fig.height = 4.5---------------------
plot(result, alignment = "all")


## ----summary.StratPosterior---------------------------------------------------
summary(result)


## ----StratMap-----------------------------------------------------------------
StratMap(result, heights = 1, site = "site2")


## ----stratmapplot-code, eval = FALSE------------------------------------------
# StratMapPlot(result, site = "site2")


## ----plot-stratmapplot, fig.width = 3, fig.height = 2.9, echo = FALSE---------
par(mar = c(4.1, 4.1, 1, 1))
StratMapPlot(result, site = "site2")

