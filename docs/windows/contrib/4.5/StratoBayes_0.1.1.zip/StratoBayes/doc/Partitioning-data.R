## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE
)

## ----library------------------------------------------------------------------
library("StratoBayes")
set.seed(0)

## ----modify data, fig.width = 5, fig.height = 4, echo = TRUE------------------
# Remove rows from site2 where height is between 6 and 10 (hiatus)
signalData0b <- signalData0[!(signalData0$site == "site2" & 
                                 signalData0$height > 6 & signalData0$height < 10), ]
# For site2 rows with heights greater than 10, reduce sedimentation rates above gap by a factor of 2.
signalData0b$height[signalData0b$site == "site2" & signalData0b$height > 10] <-
    6 + (signalData0b$height[signalData0b$site == "site2" & signalData0b$height > 10] - 10) / 2
# Plot the modified data
plot(StratData(signalData0b))

## ----signalData---------------------------------------------------------------
# Determine the maximum recorded height for each site.
site1Max <- max(signalData0b$height[signalData0b$site == "site1"])
site2Max <- max(signalData0b$height[signalData0b$site == "site2"])

# construct the partition dataframe
partsData0b <- data.frame(
  site = c("site1", "site2", "site2", "site2"),
  height = c(site1Max, site2Max, 5, 5), 
  partition = c("partition 1", "partition 2a", NA, "partition 2b"))
# print dataframe
partsData0b

