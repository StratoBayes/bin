test_that("summary.StratPosterior works with single cluster", {
  expect_snapshot(summary(stratPosterior1))
})

test_that("print.summary.StratPosterior works with change sigDigits", {
  expect_snapshot(print(summary(stratPosterior1), sigDigits = 2))
})

test_that("summary.StratPosterior works with two clusters", {
  expect_snapshot(summary(stratPosterior2))
})

test_that("summary.StratPosterior works with no burn-in", {
  expect_snapshot(summary(stratPosterior2, burnIn = 0))
})

test_that("summary.StratPosterior works with iteration burn-in", {
  expect_snapshot(summary(stratPosterior1, burnIn = 4900))
})

test_that("summary.StratPosterior works with iterations", {
  expect_snapshot(summary(stratPosterior2, iterations = 500:800))
})

test_that("summary.StratPosterior works with unassigned iterations", {
  expect_snapshot(summary(stratPosterior2, iterations = 1:100, runs = 4))
})

test_that("summary.StratPosterior works with alignment 2", {
  expect_snapshot(summary(stratPosterior2, alignment = 2))
})

test_that("summary.StratPosterior works with no clusters (all it)", {
  expect_snapshot(
    summary.StratPosterior(stratPosterior2, alignment = "none")
  )
})

test_that("summary.StratPosterior works with new cluster object and many clusters", {
  clustNew <- Cluster(stratPosterior1, clusterMethod = "hdbscan")

  expect_snapshot(
    summary.StratPosterior(stratPosterior1, alignment = "all",
                           stratCluster = clustNew)
  )
})


test_that("summary.StratPosterior works with new cluster object and iterations before burnIn", {
  clustNew <- Cluster(stratPosterior1, iterations = 100)

  expect_snapshot(
    summary.StratPosterior(stratPosterior1,
                           stratCluster = clustNew)
  )

})

test_that("summary.StratPosterior works with new cluster object and iterations before burnIn - alignment none", {
            clustNew <- Cluster(stratPosterior1, iterations = 100)

            expect_snapshot(
              summary.StratPosterior(stratPosterior1, alignment = "none",
                                     stratCluster = clustNew)
            )


          })

# hit NA line in .RoundToSigDigits
test_that(".RoundToSigDigits deals with NA", {
expect_equal(.RoundToSigDigits(NA)[[1]], "NA")
})
