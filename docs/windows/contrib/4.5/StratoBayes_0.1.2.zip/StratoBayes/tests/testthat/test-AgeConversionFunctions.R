{ # Initialize
  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  testDataMulti$ties <- rbind(testDataMulti$ties,
                              c("site2", 12, 30, 3, "dnorm"),
                              c("site2", 25, 22, 3, "dnorm"))

  tmulti <-
    StratData(
      testDataMulti$signal,
      parts = testDataMulti$parts,
      ties = testDataMulti$ties,
      signalColumn = c("a", "b"),
      zColumn = "Hight",
      siteColumn = "SIT"
    )
}


test_that(".AgeConversionStratData works with a - s - b", {
  alScale <- "age"
  sedMod <- "s"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )

  # ras <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(ras,iterations = 500),3)
  parameters1 <- c(40.1, 34.3, 39.3, 1.25, 0.914, 0.409, 1.63)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(ras,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 29.6, 25.8, 24.2))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(34.3, 30.8, 22.4, 20.1))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(40.1, 17.2))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(29.0, 22.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), c(34.0, 30.8, 22.4, 20.1))

})


test_that(".AgeConversionStratData works with a - s - t", {
  alScale <- "age"
  sedMod <- "s"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"
  tmulti$tiesAttr$arg1[1, 3] <- 24
  tmulti$tiesAttr$arg2[1, 3] <- 1

  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 15, max  = 25),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 0.5),
      "gap_site2_1" = NormalPrior(mean = 2, sd = 1)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )

  # rasb <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasb,iterations = 500),3)
  parameters1 <- c(18, 19.3, 21.8, 1.31, 1.03, 0.355, 3.52)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  #   plot(rasb,iterations = 500, colourBy = "partition",overridePar = F)
  #   abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  #   abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  #   abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 30.1, 26.7, 23.2))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(34.3, 31.2, 21.6, 19.6))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.6, 18.0))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(29.6, 21.4))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(25.3))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})



test_that(".AgeConversionStratData works with a - p - b", {
  alScale <- "age"
  sedMod <- "p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )
  #
  # rap <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rap,iterations = 500),3)
  parameters1 <- c(39.8, 35.7, 38.6, 1.6, 1.65, 1.31, 1.23, 2.32)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rap,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(35.7, 33.5, 30.9, 28.6))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(35.7, 27.4, 25.8))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.8, 23.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.1, 27.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(32.8))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with a - p - t", {
  alScale <- "age"
  sedMod <- "p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 15, max  = 25),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 0.5),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #
  # rapt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rapt,iterations = 500),3)
  parameters1 <- c(20.9, 23.6, 23.4, 1.61, 1.44, 2.49, 0.598, 4.79)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rapt,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(32.9, 30.1, 29.3, 24.5))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(32.9, 24.1, 23.7))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(36.9, 20.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(30.0, 24.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.1))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with a - s x p - b", {
  alScale <- "age"
  sedMod <- "s x p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 1),
      "zetaLog_site2" = Fixed(1.4),
      "zetaLog_site3" = Fixed(0.85),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )
  #
  # rasxp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasxp,iterations = 500),3)
  parameters1 <-
    c(40.3, 33.9, 39.3, 1.31, 0.468,-0.664,-0.409, 1.4, 0.85, 4.26)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  # plot(rasxp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(33.9, 32.1, 27.5, 23.3))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(33.9, 21.1, 18.4))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(40.3, 18.7))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(31.4, 20.9))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.4))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})



test_that(".AgeConversionStratData works with a - s x p - t", {
  alScale <- "age"
  sedMod <- "s x p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 20, max  = 25),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 0.5),
      "zetaLog_site2" = Fixed(1.4),
      "zetaLog_site3" = Fixed(0.85),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #
  # rasxpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasxpt,iterations = 500),3)
  parameters1 <-
    c(22.6, 23.7, 24.8, 2.13, 0.546, 0.496, 0.461, 1.4, 0.85, 1.25)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  # plot(rasxpt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(29.7, 28.0, 26.6, 25.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(29.7, 24.7, 23.8))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(32.1, 22.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(27.8, 24.6))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.1))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with a - s, p - b", {
  alScale <- "age"
  sedMod <- "s, p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )

  #
  # rasp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasp,iterations = 500),3)
  parameters1 <- c(39.6, 34.3, 37.9, 1.29, 0.859, 1.2, 1.01, 1.03)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rasp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 29.4, 26.5, 25.5))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(34.3, 24.1, 22.4))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.6, 17.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(28.9, 24.0))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(30.6))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})



test_that(".AgeConversionStratData works with a - s, p - t", {
  alScale <- "age"
  sedMod <- "s, p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 20, max  = 25),
      "gammaLog_part 1.1_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )

  #
  # raspt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(raspt,iterations = 500),3)
  parameters1 <- c(17.8, 22.8, 23.1, 1.14, 0.536,
               1.44, 0.283, 2.85)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(raspt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(37.3, 30.5, 28.3, 25.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(37.3, 24.3, 23.0))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(43.4, 17.8))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(30.2, 24.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.9))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


###
###
### Height scale
###
###

test_that(".AgeConversionStratData works with h - s - b", {
  alScale <- .MatchAlignmentScale("h")
  sedMod <- "site"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <- .CreateIndices(
    tmulti,
    alignmentScale = alScale,
    sedModel = sedMod,
    alphaPosition = alphaPos
  )
  #rhs <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  #signif(ExtractParams(rhs,iterations = 500),3)
  parameters1 <- c(19.5, 4.87, -0.316, -0.151, 5.38)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <- .AgeConversionStratData(tmulti, ind1, parameters1,
                                         returnAlphas = TRUE)
  # plot(rhs,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(agesAgeSite$alphas[[2]],
               c(19.5, 35.5, 48.5, 53.9), tolerance = 0.01)
  expect_equal(agesAgeSite$signal[[2]][c(1, 33, 58, 64)],
               c(19.5, 31.4, 60.1, 67.9), tolerance = 0.01)
  expect_equal(agesAgeSite$ties[[2]], c(37.6, 60.8), tolerance = 0.01)
  expect_equal(agesAgeSite$ties[[3]], c(28.1), tolerance = 0.01)
  expect_equal(.AgeConversionGeneral(
    parameters1, SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
    site = 2, stratData = tmulti, indices = ind1),
    agesAgeSite$signal[[2]][c(2, 33, 58, 64)],
    tolerance = 0.01
  )
})


test_that(".AgeConversionStratData works with h - s - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "site"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #rhst <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  #signif(ExtractParams(rhst,iterations = 500),3)
  parameters1 <- c(60.6, 80.8,-0.138,-1.21, 2.41)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhst,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.3, 34.7, 45.6, 48.0))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(21.3, 31.2, 53.1, 59.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(36.4, 53.7))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(64))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with h - p - b", {
  alScale <- "h"
  sedMod <- "p"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhp,iterations = 500),3)
  parameters1 <- c(17.7, 3.29,-0.735, 0.132,-0.669, 3.64)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(17.7, 42.0, 50.4, 54.0))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(17.7, 57.9, 62.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(43.3, 58.4))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(42.3))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))

})


test_that(".AgeConversionStratData works with h - p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhpt,iterations = 500),3)
  parameters1 <- c(56.4, 74.5, 0.0413, 0.561,-1.12, 11.7)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhpt,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.8, 33.0, 38.4, 50.1))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(21.8, 52.7, 55.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.9, 53.0))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(59.2))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))

})

test_that(".AgeConversionStratData works with h - s x p - b", {
  alScale <- "h"
  sedMod <- "s x p"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "zetaLog_site3" = NormalPrior(mean  = 1, sd  = 0.1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsxp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsxp,iterations = 500),3)
  parameters1 <- c(22.6, 2.15, 0.373,-0.63,-1.78, 1.08, 6.24)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsxp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(22.6, 30.6, 48.5, 54.7))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(22.6, 63.1, 73.8))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(2.15, 15.1))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.5, 64.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(42.4))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with h - s x p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "s x p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "zetaLog_site3" = NormalPrior(mean  = 1, sd  = 0.1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsxpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsxpt,iterations = 500),3)
  parameters1 <- c(60.6, 73.6,-0.0275, 0.0786,-2.16, 1.03, 9.21)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsxpt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(20.4, 32.4, 41.2, 50.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(20.4, 54.6, 59.8))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(-3.79,  16.1))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.8, 55.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(58.1))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))
})


test_that(".AgeConversionStratData works with h - s,p - b", {
  alScale <- "h"
  sedMod <- "s, p"
  alphaPos <- "bottom"
  #StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsp,iterations = 500),3)
  parameters1 <- c(20.9, 2.65,-0.19,-0.279,-0.752, 5.14)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(20.9, 35.0, 47.6, 52.7))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(20.9, 31.4, 58.6, 66.2))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(2.65, 16.3))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(37.0, 59.3))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(45.1))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))

})



test_that(".AgeConversionStratData works with h - s,p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 1
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "s, p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhspt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhspt,iterations = 500),3)
  parameters1 <- c(59.1, 87.6, 0.0609,-0.0905,-1.31, 4.31)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhspt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.4, 32.3, 42.7, 47.1))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(21.4, 29.5, 52.0, 58.2))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(-5.05,  18.8))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(34.0, 52.5))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(69.1))
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)],
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))

})
