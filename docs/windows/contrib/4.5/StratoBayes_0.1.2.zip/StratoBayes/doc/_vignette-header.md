> StratoBayes is an R package for correlating and dating geological data. Installation instructions and more documentation are available at [https://stratobayes.github.io/](https://stratobayes.github.io/).
For a basic introduction to StratoBayes, see the [StratoBayes vignette](https://stratobayes.github.io/vignettes/StratoBayes.html)
