library(shinytest2)

test_that("{shinytest2} recording: load-data-01", {
  app <- AppDriver$new(
    name   = "load-data-01",
    seed   = 1,
    height = 945,
    width  = 1619
  )

  # ❌ REMOVE: recorder added these, but fileInput cannot be set this way
  # app$set_inputs(dataFile = character(0))
  # app$set_inputs(partitionFile = character(0))

  # --- Core user flow ---------------------------------------------------------
  app$set_inputs(modelTabs = "structure")
  app$click("loadNewSignalSource")
  app$click("loadDataset")
  app$click("loadDataFromResult")
  app$click("addAutoPartitions")
  app$click("createPartitions")
  app$click("showSaveData")
  app$click("confirmSaveData")
  app$click("cancelSaveData")
  app$click("lookAtData")
  app$click("quickRun")
  app$click("customRun")
  app$click("quickRun_view")
  app$click("customRun_view")
  app$click("nextStepFromView")
  app$click("loadModelSettings")
  app$click("updateAlphaPositions")
  app$click("runModel")
  app$click("previousStep")
  app$click("lookAtDataFromModal")
  app$click("nextStep")
  app$click("closeModal")

  # --- Data-source settings ---------------------------------------------------
  app$set_inputs(dataSource = "file")
  app$set_inputs(readxl.sheet = "")
  app$set_inputs(partitionSource = "none")
  app$set_inputs(distributeMethod = "points")
  app$set_inputs(alignmentScale = "height")
  app$set_inputs(sedModel = "site")
  app$set_inputs(alphaPosition = "top")
  app$set_inputs(dataScale = "depth")
  app$set_inputs(loadSiteSelect = character(0))
  app$set_inputs(readxlSkip = 1)
  app$set_inputs(readxlSkipCols = 1)
  app$set_inputs(nStrata = 2)
  app$set_inputs(nRun = 1)
  app$set_inputs(nIter = 1000)
  app$set_inputs(nThin = 1)
  app$set_inputs(nChains = 1)
  app$set_inputs(nKnots = 20)
  app$set_inputs(saveDataNameInput = "")
  app$set_inputs(saveModelSettingsName = "")

  # --- Proper file upload -----------------------------------------------------
  data_path <- system.file("extdata", "signalData0.csv", package = "StratoBayes")
  app$upload_file(dataFile = data_path)
  app$wait_for_idle()

  # --- Stable snapshot: ONLY outputs & exports -------------------------------
  app$expect_values(
    input  = FALSE,
    output = TRUE,
    export = TRUE
  )

  # --- Switch to example dataset ---------------------------------------------
  app$set_inputs(dataSource = "signalData0.csv")
  app$click("lookAtData")
  app$click("previousStep")
  app$click("closeModal")

  # ❌ Removed: this element does not exist; leaving it makes tests fail
  # app$click("continueSetup")
  # app$click("confirmCloseModal")
  # app$click("confirmCloseModal")
})
