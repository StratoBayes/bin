test_that("ReadLasFiles works with folder path", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  # Read all LAS files in folder
  result <- suppressMessages(ReadLasFiles(lasFolder))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 3)  # Should have 3 files
  expect_named(result)

  # Check that all elements are data.frames
  expect_true(all(vapply(result, is.data.frame, logical(1))))

  # Check names (should be filenames without extension)
  expectedNames <- c("0500106234_2769043", "0500106234_2769044", "0500106234_2769045")
  expect_equal(sort(names(result)), sort(expectedNames))
})

test_that("ReadLasFiles works with fileNames parameter", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  # Read specific files
  fileNames <- c("0500106234_2769043.las", "0500106234_2769044.las")
  result <- suppressMessages(ReadLasFiles(lasFolder, fileNames = fileNames))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 2)
  expect_named(result)

  # Check names
  expectedNames <- c("0500106234_2769043", "0500106234_2769044")
  expect_equal(sort(names(result)), sort(expectedNames))
})

test_that("ReadLasFiles handles fileNames without extension", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  # Read specific files without .las extension
  fileNames <- c("0500106234_2769043", "0500106234_2769044")
  result <- suppressMessages(ReadLasFiles(lasFolder, fileNames = fileNames))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 2)
  expect_named(result)
})

test_that("ReadLasFiles errors on invalid folder", {
  skip_if_not_installed("SDAR")

  expect_error(ReadLasFiles("nonexistent_folder"), "does not exist")
})

test_that("ReadLasFiles errors on missing files", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  fileNames <- c("nonexistent_file.las", "0500106234_2769043.las")
  expect_error(ReadLasFiles(lasFolder, fileNames = fileNames), "were not found")
})

test_that("ReadLasFiles errors on single file", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  fileNames <- c("0500106234_2769043.las")
  expect_error(ReadLasFiles(lasFolder, fileNames = fileNames), "at least two")
})

test_that("ReadLasFiles errors on duplicate fileNames resolving to the same file", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  # With and without extension resolve to the same underlying file
  fileNames <- c("0500106234_2769043", "0500106234_2769043.las")
  expect_error(ReadLasFiles(lasFolder, fileNames = fileNames), "duplicate")
})

