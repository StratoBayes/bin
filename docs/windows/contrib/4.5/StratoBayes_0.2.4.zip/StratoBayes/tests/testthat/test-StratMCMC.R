test_that("bactrianM validation", {
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = -0.1),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = 1),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = "a"),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = c(0.5, 0.5)),
               "bactrianM")
  # Valid values should not error
  m0 <- StratMCMC(stratModel = stratModel1, bactrianM = 0)
  expect_equal(m0$metro$bactrianM, 0)
  m95 <- StratMCMC(stratModel = stratModel1, bactrianM = 0.95)
  expect_equal(m95$metro$bactrianM, 0.95)
})

test_that("StratMCMC parameter validation", {
  # writeMCMCfile: FALSE/0 (off) and values in (0, 1] are OK; outside that range errors
  m_off <- StratMCMC(stratModel = stratModel1, writeMCMCfile = FALSE)
  expect_identical(m_off$writeMCMCiterations, FALSE)
  m_off0 <- StratMCMC(stratModel = stratModel1, writeMCMCfile = 0)
  expect_identical(m_off0$writeMCMCiterations, FALSE)
  m_one <- StratMCMC(stratModel = stratModel1, writeMCMCfile = 1)
  expect_true(is.numeric(m_one$writeMCMCiterations))
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = 1.5),
               "writeMCMCfile")
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = -1),
               "writeMCMCfile")
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = 2),
               "writeMCMCfile")

  # acceptanceHistoryLength: must be a positive integer
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 0),
               "acceptanceHistoryLength")
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = -1),
               "acceptanceHistoryLength")
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 1.5),
               "acceptanceHistoryLength")
  m_ahl <- StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 10)
  expect_equal(m_ahl$metro$acceptanceLength, 10)

  # adaptTemperaturesIntervall: must be NULL or a positive integer
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 0),
               "adaptTemperaturesIntervall")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = -1),
               "adaptTemperaturesIntervall")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 10.5),
               "adaptTemperaturesIntervall")
  m_ati <- StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 10)
  expect_equal(m_ati$temper$adaptTemperaturesIntervall, 10)

  # startAdapting / endAdapting: must be NULL or positive integers (integer-ness only, RT-205)
  expect_error(StratMCMC(stratModel = stratModel1, startAdapting = 1.5),
               "startAdapting")
  expect_error(StratMCMC(stratModel = stratModel1, endAdapting = 1.5),
               "endAdapting")
})

test_that("StratMCMC methods work", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratMCMC1))

  expect_equal(.PrettyNumber(NULL), numeric(0))
  expect_equal(.PrettyNumber(1 / 3), 0.333)
  expect_snapshot(summary(stratMCMC1))

  # print mcmc from run with completed iterations
  stratMCMC1$completedIter <- 100
  expect_snapshot(print(stratMCMC1))

  # check that summary.StratMCMC produces valid output
  output <- utils::capture.output(summary.StratMCMC(stratMCMC1))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Probability", output[[4]])))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Multivariate", output[[6]])))
  expect_true(any(grepl("4", output[[6]])))

})

test_that("RT-206: endAdapting is capped at nIter so kept samples are post-adaptation", {
  # Regression for RT-206. A user-supplied `endAdapting > nIter` used to be
  # stored uncapped, leaving the adaptation condition `i <= endAdapting` TRUE
  # for the entire run: proposal + temperature adaptation kept firing to the
  # last iteration and every "post-adaptation" sample was actually drawn under
  # a still-adapting (non-Markov) kernel. `StratMCMC()` now caps the stored
  # value at `endIter` (equivalent to capping user `endAdapting` at `nIter`)
  # and warns.
  #
  # Review findings (verified against source): the cap arithmetic is exact for
  # both new and continued runs -- the `startIter - 1` offset makes `endIter`
  # the correct bound and `completedIter` cancels; the strict `>` preserves the
  # legal `endAdapting == nIter` boundary; and this is the only path that can
  # produce `endAdapting > endIter`. Reader caveat: capping `nIter+1 -> nIter`
  # does NOT turn kept samples into post-adaptation draws -- both are pure
  # warm-ups with zero post-adapt samples; the cap's value is the warning plus
  # keeping stored `endAdapting` inside `[startIter, endIter]`. Cases (d)/(e)
  # add continued-run coverage -- exactly where the offset could hide an
  # off-by-one.

  # Records whether the specific RT-206 warning is emitted while forcing `expr`.
  rt206WarningFired <- function(expr) {
    fired <- FALSE
    withCallingHandlers(
      force(expr),
      warning = function(w) {
        if (grepl("endAdapting", conditionMessage(w)) &&
            grepl("exceeds", conditionMessage(w))) {
          fired <<- TRUE
        }
        invokeRestart("muffleWarning")
      }
    )
    fired
  }

  # (a) Bug case: endAdapting one past the end. Warning fires and the stored
  #     value is pulled back to exactly endIter (not endIter + 1).
  expect_warning(
    mBug <- StratMCMC(stratModel = stratModel1, nIter = 100,
                      endAdapting = 101, nThreads = 2L),
    "endAdapting.*exceeds"
  )
  expect_equal(mBug[["endAdapting"]], mBug[["endIter"]])
  expect_equal(mBug[["endAdapting"]], 100)  # new run: endIter == nIter

  # (b) Boundary case: endAdapting == nIter is a legal request (adapt right up
  #     to the final iteration, zero post-adaptation samples). It must NOT be
  #     warned or altered, and adaptation must end exactly at the last
  #     iteration (endIter) -- not one-before, not one-past.
  mBoundary <- NULL
  expect_false(rt206WarningFired(
    mBoundary <- StratMCMC(stratModel = stratModel1, nIter = 100,
                           endAdapting = 100, nThreads = 2L)
  ))
  expect_equal(mBoundary[["endAdapting"]], mBoundary[["endIter"]])
  expect_equal(mBoundary[["endAdapting"]], 100)

  # (c) Normal in-range usage is completely unaffected: no warning, stored value
  #     equals the user request offset by (startIter - 1), which is 0 for a new
  #     run.
  mInRange <- NULL
  expect_false(rt206WarningFired(
    mInRange <- StratMCMC(stratModel = stratModel1, nIter = 100,
                          endAdapting = 40, nThreads = 2L)
  ))
  expect_equal(mInRange[["endAdapting"]], 40)  # 40 + startIter(1) - 1
  expect_true(mInRange[["endAdapting"]] < mInRange[["endIter"]])

  # (d) Continued run: the cap must respect the `startIter - 1` offset, so the
  #     bound is `endIter` (= completedIter + nIter), NOT a naive `nIter`.
  #     Continue a 100-iteration run for another 100 (completedIter = 100,
  #     startIter = 101, endIter = 200). `endAdapting` one past THIS run's
  #     length (101) must warn and be pulled to endIter == 200 -- a naive `nIter`
  #     cap would wrongly store 100. This is the case an off-by-one would break.
  mPrior <- StratMCMC(stratModel = stratModel1, nIter = 100, nThreads = 2L)
  expect_warning(
    mBugCont <- StratMCMC(stratModel = stratModel1, stratMCMC = mPrior,
                          completedIter = 100, nIter = 100, endAdapting = 101,
                          nThreads = 2L),
    "endAdapting.*exceeds"
  )
  expect_equal(mBugCont[["endIter"]], 200)  # completedIter(100) + nIter(100)
  expect_equal(mBugCont[["endAdapting"]], mBugCont[["endIter"]])
  expect_equal(mBugCont[["endAdapting"]], 200)  # capped to endIter, not nIter

  # (e) Continued-run boundary: endAdapting == nIter (100) is legal for a
  #     continued run too -- stored as endIter (200) and left un-warned.
  mBoundaryCont <- NULL
  expect_false(rt206WarningFired(
    mBoundaryCont <- StratMCMC(stratModel = stratModel1, stratMCMC = mPrior,
                               completedIter = 100, nIter = 100,
                               endAdapting = 100, nThreads = 2L)
  ))
  expect_equal(mBoundaryCont[["endAdapting"]], mBoundaryCont[["endIter"]])
  expect_equal(mBoundaryCont[["endAdapting"]], 200)
})
