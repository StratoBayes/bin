test_that(".ValidateAlignment() works", {
  expect_equal(.ValidateAlignment("all", 1:2), 1:2)
  expect_equal(.ValidateAlignment("ALL",0:2), 0:2)
  expect_equal(.ValidateAlignment("none",2:4), 2:4)
  expect_equal(.ValidateAlignment(1:2,0:3), 1:2)
  expect_equal(.ValidateAlignment(2,0:3), 2)
  expect_equal(.ValidateAlignment(1,1), 1)

  expect_error(.ValidateAlignment(NULL, 1), "cannot be NULL")
  expect_error(.ValidateAlignment("fail",1), "`alignment` must be")
  expect_error(.ValidateAlignment(1), "clustUnique")
  expect_error(.ValidateAlignment(1:2,2:4), "must consist of whole")
  expect_error(.ValidateAlignment(character(0), 1:2), "empty")
  # non-integer doubles must not be silently truncated (as.integer(1.9) -> 1L)
  expect_error(.ValidateAlignment(c(1.9, 3.0), 0:3), "`alignment` must be")
  expect_equal(.ValidateAlignment(c(1, 3), 0:3), c(1L, 3L))
})

test_that(".ValidateParams() succeeds", {
  expect <- as.data.frame(matrix(1:2, nrow = 1), optional = TRUE)
  expect_equal(.ValidateParams(NULL, 1, "NULL"), "NULL")
  expect_equal(.ValidateParams(1:2, 2), expect)
  expect_error(.ValidateParams(1:2, 3), "vector of length 3")
  mat6 <- matrix(1:6, 3, 2)
  expect6 <- as.data.frame(mat6, optional = TRUE)
  expect_equal(.ValidateParams(mat6, 2), expect6)
  expect_error(.ValidateParams(mat6, 3), "vector of length 3")
  expect_equal(.ValidateParams(expect6, 2), expect6)
  expect_error(.ValidateParams(expect6, 3), "vector of length 3")
})

test_that(".ValidateModelParams works", {

  expect_error(.ValidateModelParams("", stratPosterior1),
               "parameters must be atomic")

  expect_error(.ValidateModelParams(stratModel1, 1),
               "object needs to be of class")

  expect_error(.ValidateModelParams(stratPosterior1, ""),
               "`parameters` may not be empty")

  expect_error(.ValidateModelParams(stratPosterior1, "sigma"),
               "Invalid names specified for parameters")

  expect_error(.ValidateModelParams(stratPosterior1, 5),
               "Invalid number '5' specified for `parameters`")

  expect_equal(.ValidateModelParams(stratPosterior1, "probability"),
               c("posterior", "prior_parameters", "prior_overlap",
                 "likelihood_spline"))

  expect_equal(.ValidateModelParams(stratPosterior1, "log posterior"),
               "posterior")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_parameters"),
               "prior_parameters")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_overlap"),
               "prior_overlap")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood_spline"),
               "likelihood_spline")

  expect_equal(.ValidateModelParams(stratPosterior2, "log likelihood_ties"),
               "likelihood_ties")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood"),
               "likelihood")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior"),
               "prior")

  expect_equal(.ValidateModelParams(stratPosterior1, "beta")[5:6],
               c("beta_value_5", "beta_value_6"))

  expect_equal(.ValidateModelParams(stratPosterior2, "beta_b")[1:3],
               c("beta_b_1", "beta_b_2", "beta_b_3"))

})

# --- .ValidateRunSelect ---

test_that(".ValidateRunSelect accepts valid inputs", {
  expect_equal(.ValidateRunSelect("all", 3), 1:3)
  expect_equal(.ValidateRunSelect("ALL", 5), 1:5)
  expect_equal(.ValidateRunSelect(1, 3), 1L)
  expect_equal(.ValidateRunSelect(c(1, 3), 3), c(1L, 3L))
})

test_that(".ValidateRunSelect rejects invalid inputs", {
  expect_error(.ValidateRunSelect(NULL, 3), "cannot be NULL")
  expect_error(.ValidateRunSelect(0, 3), "whole numbers between 1")
  expect_error(.ValidateRunSelect(4, 3), "whole numbers between 1 and 3")
  expect_error(.ValidateRunSelect(-1, 3), "whole numbers between 1")
  expect_error(.ValidateRunSelect(character(0), 3), "empty")
})

# --- %safein% ---

test_that("%safein% matches same-type values", {
  expect_equal(1:3 %safein% c(2, 3, 4), c(FALSE, TRUE, TRUE))
  expect_equal(c("a", "b") %safein% c("b", "c"), c(FALSE, TRUE))
})

test_that("%safein% treats integer and double as compatible", {
  expect_equal(1L %safein% c(1, 2), TRUE)
  expect_equal(1.0 %safein% 1L, TRUE)
})

test_that("%safein% returns FALSE when types differ (char vs numeric)", {
  expect_equal("1" %safein% 1, FALSE)
  expect_equal(1 %safein% "1", FALSE)
  expect_equal(c("1", "2") %safein% 1:2, c(FALSE, FALSE))
})

# --- .ValidateSites ---

test_that(".ValidateSites accepts site names", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites("site_1", data), 1L)
  result <- .ValidateSites(c("site_1", "site_3"), data)
  expect_equal(result, c(1L, 3L))
})

test_that(".ValidateSites accepts 'all'", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites("all", data), 1:3)
})

test_that(".ValidateSites accepts integer indices", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites(c(1, 2), data), c(1, 2))
})

test_that(".ValidateSites rejects out-of-range", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSites(5, data), "integers from 1 to")
})

test_that(".ValidateSites rejects NULL or empty input instead of silently selecting nothing", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSites(NULL, data), "cannot be NULL or an empty vector")
  expect_error(.ValidateSites(character(0), data), "cannot be NULL or an empty vector")
})

# --- .ValidateSignal ---

test_that(".ValidateSignal accepts signal names", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal("value", data)
  expect_equal(result$signal, "value")
  expect_false(result$allSignals)
})

test_that(".ValidateSignal accepts 'all'", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal("all", data)
  expect_true(result$allSignals)
})

test_that(".ValidateSignal accepts integer index", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal(1L, data)
  expect_equal(result$signal, "value")
})

test_that(".ValidateSignal rejects invalid names", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSignal("nonexistent", data), "signal must be")
})

test_that(".ValidateSignal rejects empty input", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSignal(character(0), data), "empty")
})

# --- .ValidateShow ---

test_that(".ValidateShow works for valid inputs", {
  expect_equal(.ValidateShow("signal"), "signal")
  expect_equal(.ValidateShow("partition"), "partition")
  # partial matching
  expect_equal(.ValidateShow("sig"), "signal")
  expect_equal(.ValidateShow("par"), "partition")
})

test_that(".ValidateShow rejects invalid inputs", {
  expect_error(.ValidateShow("invalid"), "must be.*signal.*or.*partition")
})

test_that(".ValidateShow rejects empty input", {
  expect_error(.ValidateShow(character(0)), "empty")
})

# --- .ValidateColourBy ---

test_that(".ValidateColourBy works for alignment plot type", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateColourBy("site", data, "alignment"), "site")
  expect_equal(.ValidateColourBy("partition", data, "alignment"), "partition")
})

test_that(".ValidateColourBy works for hist plot type", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateColourBy("alignment", data, "hist"), "alignment")
  expect_equal(.ValidateColourBy("run", data, "hist"), "run")
  expect_equal(.ValidateColourBy("none", data, "hist"), "none")
})

test_that(".ValidateColourBy rejects cross-type mismatches", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateColourBy("alignment", data, "data"), "must be one of")
  expect_error(.ValidateColourBy("site", data, "hist"), "must be one of")
})

test_that(".ValidateColourBy defaults to partition when multiple partitions", {
  data <- StratData(signal = signalData1)
  result <- .ValidateColourBy(NULL, data, "data")
  # With 1 unique partition, should default to "site"
  expect_true(result %in% c("site", "partition"))
})

test_that(".ValidateColourBy rejects empty input", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateColourBy(character(0), data, "data"), "empty")
})

# --- .CreateColourMaps ---

test_that(".CreateColourMaps rejects empty `col` instead of silently producing all-NA colours", {
  expect_error(
    .CreateColourMaps(
      data = list(), colourScale = "Dark 3", nParts = 3, nSect = 2,
      args = list(col = character(0))
    ),
    "empty"
  )
})

# --- .ValidateQuantiles ---

test_that(".ValidateQuantiles accepts valid quantiles", {
  expect_equal(.ValidateQuantiles(c(0.025, 0.5, 0.975)), c(0.025, 0.5, 0.975))
  expect_equal(.ValidateQuantiles(c(0, 0.5, 1)), c(0, 0.5, 1))
})

test_that(".ValidateQuantiles rejects out-of-range", {
  expect_error(.ValidateQuantiles(c(-0.1, 0.5, 0.9)), "between 0 and 1")
  expect_error(.ValidateQuantiles(c(0.1, 0.5, 1.1)), "between 0 and 1")
})

test_that(".ValidateQuantiles rejects non-numeric", {
  expect_error(.ValidateQuantiles(NULL), "must be a numeric")
  expect_error(.ValidateQuantiles(NA), "must be a numeric")
  expect_error(.ValidateQuantiles("a"), "must be a numeric")
})

test_that(".ValidateQuantiles requires length 3 ascending", {
  expect_equal(.ValidateQuantiles(c(0.05, 0.5, 0.95)),
               c(0.05, 0.5, 0.95))
  expect_error(.ValidateQuantiles(c(0.5, 0.95)),
               "length 3")
  expect_error(.ValidateQuantiles(c(0.95, 0.5, 0.05)),
               "ascending order")
})

# --- .IsNumeric ---

test_that(".IsNumeric correctly identifies numeric-coercible values", {
  expect_true(.IsNumeric(1))
  expect_true(.IsNumeric("1.5"))
  expect_true(.IsNumeric(c("1", "2", "3")))
  expect_false(.IsNumeric("abc"))
  expect_false(.IsNumeric(c("1", "abc")))
})

test_that(".IsNumeric rejects NULL and empty vectors instead of a false TRUE", {
  expect_false(.IsNumeric(NULL))
  expect_false(.IsNumeric(character(0)))
  expect_false(.IsNumeric(numeric(0)))
})

# --- .IsColour ---

test_that(".IsColour recognises valid R colours", {
  expect_true(.IsColour("red"))
  expect_true(.IsColour("#FF0000"))
  expect_true(.IsColour("blue"))
  expect_false(.IsColour("notacolour"))
  expect_false(.IsColour("definitely_not_a_colour_xyz"))
})

# --- .AddLogPrefix ---

test_that(".AddLogPrefix adds log to probability terms", {
  expect_equal(.AddLogPrefix("posterior"), "log posterior")
  expect_equal(.AddLogPrefix("likelihood"), "log likelihood")
  expect_equal(.AddLogPrefix("alpha_site_1"), "alpha_site_1")
  expect_equal(
    .AddLogPrefix(c("posterior", "alpha_site_1")),
    c("log posterior", "alpha_site_1")
  )
})
