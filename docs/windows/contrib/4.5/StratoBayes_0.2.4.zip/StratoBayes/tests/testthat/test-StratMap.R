test_that("StratMap works", {

expect_error(StratMap(1, 2, 2), "stratObject needs to be")

expect_equal(as.numeric(StratMap(stratPosterior1, 2, 2)),
             c(2, 10.3, 0.5, 9.7, 10.3, 11.6), tolerance = 0.1)

expect_s3_class(StratMap(stratPosterior3, 2, 2), "data.frame")

})

test_that("StratMap works with prior", {
  set.seed(1)
  h1 <- StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1)
  expect_equal(h1$mean, mean(unlist(stratModel1$priors$metro$alpha_site_2$args)), tolerance = 0.5)
  })

test_that("StratMap works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior2, iterations = 3500:4000)
            expect_true(
              StratMap(stratPosterior2,
                             heights = 1,
                             site = 3,
                                      stratCluster = clustNew,
                                      alignment = 1)[ , "sd"]
              <
                StratMap(stratPosterior2,
                         heights = 1,
                         site = 3,
                         stratCluster = clustNew,
                         alignment = "all")[ , "sd"]

             )
          })

test_that("StratMap preserves height-result alignment for unsorted input (T-081)", {
  # Sorted and unsorted input must produce the same mapping per height
  sorted   <- StratMap(stratPosterior1, heights = c(0.5, 1.0, 1.5), site = "site_2")
  unsorted <- StratMap(stratPosterior1, heights = c(1.5, 0.5, 1.0), site = "site_2")

  # Row 1 of unsorted (height 1.5) should match row 3 of sorted (height 1.5)
  expect_equal(unsorted[1, "mean"], sorted[3, "mean"])
  # Row 2 of unsorted (height 0.5) should match row 1 of sorted (height 0.5)
  expect_equal(unsorted[2, "mean"], sorted[1, "mean"])
  # Row 3 of unsorted (height 1.0) should match row 2 of sorted (height 1.0)
  expect_equal(unsorted[3, "mean"], sorted[2, "mean"])
})

test_that("StratMap quantiles = 'samples' works with partial match (T-082)", {
  full <- StratMap(stratPosterior1, heights = 2, site = 2, quantiles = "samples")
  partial <- StratMap(stratPosterior1, heights = 2, site = 2, quantiles = "sam")
  expect_equal(full, partial)
  expect_true("height" %in% colnames(full))
  expect_true(ncol(full) > 2)
})

test_that("StratMap(quantiles = NULL) errors clearly instead of crashing (RT-192)", {
  expect_error(
    StratMap(stratPosterior1, heights = 2, site = 2, quantiles = NULL),
    "quantiles must not be NULL"
  )
})

test_that("StratMap(quantiles = numeric(0)) errors clearly instead of crashing (RT-193)", {
  expect_error(
    StratMap(stratPosterior1, heights = 2, site = 2, quantiles = numeric(0)),
    "quantiles must not be empty"
  )
})

test_that("StratMap with a single quantile returns one row per height (RT-041)", {
  h <- c(0.5, 1.0, 1.5)
  out1 <- StratMap(stratPosterior1, heights = h, site = 2, quantiles = 0.5)
  # Before the fix, a length-1 `quantiles` collapsed the output to a single
  # garbage row (t() of a vector), so nrow() was 1 instead of length(h).
  expect_equal(nrow(out1), length(h))
  expect_identical(colnames(out1), c("height", "mean", "sd", "50%"))
  expect_equal(out1[["height"]], h)
  # multi-quantile output must remain nHeights x (3 + nQuantiles)
  out3 <- StratMap(stratPosterior1, heights = h, site = 2,
                   quantiles = c(0.025, 0.5, 0.975))
  expect_equal(dim(out3), c(length(h), 6))
})
