test_that("Traceplots works", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("traceplot 1", function() {
    TracePlot(stratPosterior1)
  })})

test_that("Traceplots works with alignment", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 2", function() {
    set.seed(2)
    cluster <- Cluster(stratPosterior1, clusterMethod = "hdbscan")
    TracePlot(stratPosterior1, stratCluster = cluster, colourBy = "alignment",
              type = "o", alpha = 1, colourScale = "Warm", pch = 1:25,
              alignment = seq_len(min(c(3,cluster$nClust))))
  })
})

test_that("Traceplots works with different parameter", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 3", function() {
    TracePlot(stratPosterior2, parameters = c("lambda", 3),
              alignment = 1:2, iterations = 4000:5000,
              type = "o")
  })
})

test_that("Traceplots works with likelihood parameter", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 4", function() {
    TracePlot(stratPosterior2, parameters = c("likelihood"),
              iterations = 3000:4000, colourBy = "none",
              runs = 3, type = "o")
  })
})

test_that("Traceplots works with selecting iter and run", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 4b", function() {
    TracePlot(stratPosterior2, parameters = c("likelihood"),
             iterations = list(NULL, NULL, 3000:4000, NULL),
              colourBy = "run", type = "o")
  })
})

test_that(".PlotSegmentedLines fails when given different lengths", {
 expect_error(.PlotSegmentedLines(1:2, 2:3, 3:5, c("black"), NULL),
              "The length")
})

test_that("TracePlot produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  on.exit(unlink(tmpFile))
  expect_error(TracePlot(stratPosterior1),
               "The plot window is too small for the specified margins")
  dev.off()
})

test_that("TracePlot works with new cluster object and iterations before burnIn", {
  skip_if_not_snapshot_os()
  set.seed(5)
  clustNew <- Cluster(stratPosterior1, iterations = 100:200)

  vdiffr::expect_doppelganger("traceplot 5", function() {
    TracePlot(stratPosterior1, colourBy = "alignment",
              stratCluster = clustNew, type = "o")
  })
})

test_that("TracePlot errors clearly when a custom stratCluster yields all-empty rows (RT-139)", {
  # When a custom stratCluster bypasses ExtractIterations and every run has
  # zero rows, `runSelect` used to become integer(0), and downstream code
  # accessed `plotIter[[runSelect[1]]]` (`runSelect[1]` == NA) -> subscript
  # error, instead of a readable message.
  nRun <- stratPosterior1[["nRun"]]
  emptyCluster <- list(rowIndex = replicate(nRun, integer(0), simplify = FALSE))

  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(
    TracePlot(stratPosterior1, stratCluster = emptyCluster, colourBy = "alignment"),
    "No iterations available to plot"
  )
})
