# Regression tests for the propose-from-prior Hastings correction (RT-270).
#
# The default "Prior" proposal is an INDEPENDENCE proposal: it redraws the whole
# metro vector from the priors, q(x*|x) = g(x*). Its MH acceptance therefore
# needs the Hastings factor g(x)/g(x*). Omitting it makes the kernel reversible
# w.r.t. prior^2 * L (the prior counted twice), so the posterior shrinks toward
# the prior and comes out under-dispersed.
#
# The existing recovery tests cannot see this: they check medians at true values
# that sit at the prior means, where shrink-to-prior leaves the median unmoved.
# These tests use analytic ground truth (a 1-D conjugate posterior) where the
# bias is unmistakable in both the mean and the sd.


# ── SBC-style ground truth through the real .AcceptProposal ──────────────────
# 1-D conjugate: prior g = N(0, 1), likelihood N(y = 3; theta, 1).
#   True posterior          : N(mean = 1.5,  sd = sqrt(0.5)  = 0.7071)
#   prior^2 * L (no Hastings): N(mean = 1.0,  sd = sqrt(1/3)  = 0.5774)
# Propose from the prior, accept via the package's own .AcceptProposal.

test_that("propose-from-prior recovers the true posterior with the Hastings term (RT-270)", {
  logPost <- function(theta) {
    dnorm(theta, 0, 1, log = TRUE) + dnorm(3, theta, 1, log = TRUE)
  }
  logG <- function(theta) dnorm(theta, 0, 1, log = TRUE)  # proposal density = prior

  run <- function(useHastings, n = 1.2e5) {
    x <- 0; lpx <- logPost(x); keep <- numeric(n)
    for (i in seq_len(n)) {
      xs  <- rnorm(1, 0, 1)                       # independence draw from prior
      lps <- logPost(xs)
      lh  <- if (useHastings) logG(x) - logG(xs) else 0
      if (.AcceptProposal(lpx, lps, 1, logHastings = lh)) { x <- xs; lpx <- lps }
      keep[i] <- x
    }
    keep[-seq_len(n %/% 6)]                        # drop burn-in
  }

  set.seed(20270712)
  corrected <- run(TRUE)
  expect_equal(mean(corrected), 1.5,    tolerance = 0.05)
  expect_equal(sd(corrected),   0.7071, tolerance = 0.03)

  # Omitting the correction (logHastings = 0, the pre-fix behaviour) reproduces
  # the known biased result: mean pulled toward the prior and ~18% too narrow.
  uncorrected <- run(FALSE)
  expect_equal(mean(uncorrected), 1.0,    tolerance = 0.05)
  expect_equal(sd(uncorrected),   0.5774, tolerance = 0.03)

  # The correction must actually widen the posterior (not a no-op).
  expect_gt(sd(corrected), sd(uncorrected) + 0.05)
})


# ── .AcceptProposal API: default keeps symmetric proposals unchanged ─────────

test_that(".AcceptProposal logHastings defaults to the symmetric case", {
  # Equal log-posterior, no Hastings: exp(0) = 1 > runif(1) is always TRUE.
  expect_true(.AcceptProposal(-10, -10, 1))
  # An impossible reverse move (-Inf Hastings) forces rejection.
  expect_false(.AcceptProposal(-10, -10, 1, logHastings = -Inf))
  # A dominant Hastings term flips a move that the posterior ratio alone rejects.
  expect_true(.AcceptProposal(0, log(0.5), 1, logHastings = 10))
})


# ── .MetroProposalLog evaluates g against priorsProposals, not the priors ────

test_that(".MetroProposalLog uses priorsProposals and matches priors by default (RT-270)", {
  mkPrior <- function(mean, sd) {
    list(R = stats::rnorm, D = stats::dnorm, Q = stats::qnorm,
         args = list(mean = mean, sd = sd))
  }
  priorList <- list(a = mkPrior(0, 1), b = mkPrior(2, 0.5))
  x <- c(a = 0.3, b = 1.7)

  # Default: priorsProposals == priors, so proposal and prior densities agree.
  mDefault <- list(priors = list(metro = priorList), priorsProposals = priorList)
  expect_equal(.MetroProposalLog(mDefault, x), .MetroPriorLog(mDefault, x))
  expect_equal(unname(.MetroProposalLog(mDefault, x)),
               c(dnorm(0.3, 0, 1, log = TRUE), dnorm(1.7, 2, 0.5, log = TRUE)))

  # Custom priorsProposals: .MetroProposalLog must follow the *proposal*, so it
  # diverges from the prior density on the parameters that differ.
  propList <- list(a = mkPrior(5, 1), b = mkPrior(2, 0.5))
  mCustom  <- list(priors = list(metro = priorList), priorsProposals = propList)
  expect_false(isTRUE(all.equal(.MetroProposalLog(mCustom, x),
                                .MetroPriorLog(mCustom, x))))
  expect_equal(unname(.MetroProposalLog(mCustom, x)),
               c(dnorm(0.3, 5, 1, log = TRUE), dnorm(1.7, 2, 0.5, log = TRUE)))
})

test_that("the Prior-move Hastings term is zero when unchanged and correctly signed", {
  mkPrior <- function(mean, sd) {
    list(R = stats::rnorm, D = stats::dnorm, Q = stats::qnorm,
         args = list(mean = mean, sd = sd))
  }
  m <- list(priors = list(metro = list(a = mkPrior(0, 1), b = mkPrior(2, 0.5))),
            priorsProposals = list(a = mkPrior(0, 1), b = mkPrior(2, 0.5)))
  hastings <- function(xOld, xNew) {
    sum(.MetroProposalLog(m, xOld)) - sum(.MetroProposalLog(m, xNew))
  }

  x <- c(a = 0.3, b = 1.7)
  expect_equal(hastings(x, x), 0)                 # no move -> no correction

  xHigh <- c(a = 0, b = 2)                         # at the proposal modes: high g
  xLow  <- c(a = 3, b = 0)                         # deep in the tails:   low g
  # Moving to a higher-g state down-weights (g(new) > g(old) => term < 0).
  expect_lt(hastings(xLow, xHigh), 0)
  expect_gt(hastings(xHigh, xLow), 0)
})

# Note: a full simulation-based-calibration sweep across replications on the
# live engines (R and C++) is the recommended heavy-test follow-up (see
# dev/red-team). It is intentionally out of the unit suite: the engines draw
# from R's RNG in different orders, so cross-engine reproducibility is not
# asserted here (cf. test-cpp-engine-integration.R).
