test_that("UniformPrior works", {

  expect_error(UniformPrior(2,1), "min needs to be < max")

  expect_s3_class(UniformPrior(1,2), "Prior")

})

test_that("Fixed works", {

  expect_error(Fixed(2,1), "unused argument")

  expect_s3_class(Fixed(1), "Prior")

})

test_that("ExponentialPrior works", {

  expect_error(ExponentialPrior(-1), "rate needs to be")

  expect_s3_class(ExponentialPrior(1), "Prior")

})

test_that("NormalPrior works", {

  expect_error(NormalPrior(-1, 0), "sd needs to be")

  expect_s3_class(NormalPrior(2,2), "Prior")

})

test_that("LogNormalPrior works", {

  expect_error(LogNormalPrior(-2, -1), "sdlog needs to be")

  expect_s3_class(LogNormalPrior(-2,2), "Prior")

})

test_that("TruncNormalPrior works", {

  expect_error(TruncNormalPrior(0, 0, 1, 2), "sd needs to be")
  expect_error(TruncNormalPrior(0, 1, 3, 2), "lower needs to be")

  expect_s3_class(TruncNormalPrior(0,1,2,3), "Prior")

})

test_that("TruncLogNormalPrior works", {
  expect_error(TruncLogNormalPrior(0, 0, 1, 2), "sdlog needs to be")
  expect_error(TruncLogNormalPrior(0, 1, 3, 2), "lower needs to be")
  expect_error(TruncLogNormalPrior(0, 1, -1, 2), "lower must be >= 0")

  expect_s3_class(TruncLogNormalPrior(0, 1, 0, 3), "Prior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 2, 3), "Prior")

})

test_that("Fixed Q function returns value, not 1", {
  pri <- Fixed(42)
  result <- do.call(pri$Q, c(list(p = c(0.25, 0.5, 0.75)), pri$args))
  expect_equal(result, rep(42, 3))
})

# ── RT-244: deep-tail underflow in truncated sampling / quantile inversion ────

test_that("RT-244: deep-tail TruncNormalPrior draws are finite and in range", {
  set.seed(1)
  pri <- TruncNormalPrior(mean = 0, sd = 0.01, lower = 1, upper = 2)
  x <- do.call(pri$R, c(list(n = 100), pri$args))
  expect_true(all(is.finite(x)))
  expect_true(all(x >= 1 & x <= 2))
})

test_that("RT-244: deep-tail TruncLogNormalPrior draws are finite and in range", {
  set.seed(1)
  pri <- TruncLogNormalPrior(meanlog = 0, sdlog = 0.1, lower = 5, upper = 6)
  x <- do.call(pri$R, c(list(n = 100), pri$args))
  expect_true(all(is.finite(x)))
  expect_true(all(x >= 5 & x <= 6))
})

test_that("RT-244: .qtnorm/.qlnormTrunc return finite quantiles in deep tails", {
  p <- seq(0, 1, length.out = 51)
  qn <- .qtnorm(p, mean = 0, sd = 0.01, lower = 1, upper = 2)
  expect_true(all(is.finite(qn)))
  expect_true(all(qn >= 1 & qn <= 2))
  ql <- .qlnormTrunc(p, meanlog = 0, sdlog = 0.1, min = 5, max = 6)
  expect_true(all(is.finite(ql)))
  expect_true(all(ql >= 5 & ql <= 6))
})

test_that("RT-244: quantile endpoints p=0 / p=1 return exactly lower / upper", {
  # Moderate bounds (span branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 1, lower = -2, upper = 2), -2)
  expect_identical(.qtnorm(1, mean = 0, sd = 1, lower = -2, upper = 2), 2)
  # Deep-tail bounds (upper-tail branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 0.01, lower = 1, upper = 2), 1)
  expect_identical(.qtnorm(1, mean = 0, sd = 0.01, lower = 1, upper = 2), 2)
  # Deep left-tail bounds (lower-tail branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 0.01, lower = -2, upper = -1), -2)
  expect_identical(.qtnorm(1, mean = 0, sd = 0.01, lower = -2, upper = -1), -1)
  # Log-normal, exact on the exponentiated scale
  expect_identical(.qlnormTrunc(0, 0, 0.1, min = 5, max = 6), 5)
  expect_identical(.qlnormTrunc(1, 0, 0.1, min = 5, max = 6), 6)
})

test_that("RT-244: stable rewrite matches naive formula where naive is valid", {
  p <- seq(0, 1, length.out = 101)
  # One-sided upper-tail regime, moderate enough that the naive form is a
  # trustworthy oracle (no underflow) yet still exercises the tail branch.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = 1, upper = 3),
               qnorm(pnorm(1) + p * (pnorm(3) - pnorm(1))),
               tolerance = 1e-9)
  # Lower-tail branch oracle.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = -3, upper = -1),
               qnorm(pnorm(-3) + p * (pnorm(-1) - pnorm(-3))),
               tolerance = 1e-9)
  # Log-normal upper-tail branch (log(min) > meanlog => upper tail).
  expect_equal(.qlnormTrunc(p, 0, 1, min = 2, max = 5),
               qlnorm(plnorm(2) + p * (plnorm(5) - plnorm(2))),
               tolerance = 1e-9)
  # Span branch: identical to the pre-fix naive computation.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = -2, upper = 2),
               qnorm(pnorm(-2) + p * (pnorm(2) - pnorm(-2))),
               tolerance = 1e-12)
})

test_that("RT-244: distribution unchanged in non-degenerate regime (KS test)", {
  set.seed(42)
  pri <- TruncNormalPrior(mean = 0, sd = 1, lower = -2, upper = 2)
  x <- do.call(pri$R, c(list(n = 5000), pri$args))
  # Theoretical truncated-normal CDF on [-2, 2].
  ptrunc <- function(q) {
    (pnorm(q) - pnorm(-2)) / (pnorm(2) - pnorm(-2))
  }
  expect_gt(suppressWarnings(ks.test(x, ptrunc)$p.value), 0.01)
  # Sample mean of a symmetric truncated normal should be ~0.
  expect_equal(mean(x), 0, tolerance = 0.05)
})

test_that("RT-245: bare truncated log-normal helpers reject min < 0", {
  expect_error(.rlnormTrunc(5, meanlog = 0, sdlog = 1, min = -1, max = 2),
               "lower must be >= 0")
  expect_error(.qlnormTrunc(0.5, meanlog = 0, sdlog = 1, min = -1, max = 2),
               "lower must be >= 0")
  # min == 0 must still succeed (log-normal support boundary).
  expect_silent(.qlnormTrunc(0.5, meanlog = 0, sdlog = 1, min = 0, max = 2))
})

test_that("NormalToLogNormal works", {

  expect_error(NormalToLogNormal(-1,0),
               "mu and sigma must be positive")

  a <- 0.5
  b <- 0.3
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)

  a <- 21
  b <- 2
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)
  }

          )
