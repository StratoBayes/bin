test_that("BeanPlot works", {
  skip_if_not_snapshot_os()
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 1", function() {
    set.seed(1)
    BeanPlot(stratPosterior1)
  })
})

test_that("BeanPlot works with custom settings", {
  skip_if_not_snapshot_os()
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 2", function() {
    set.seed(1)
    BeanPlot(stratPosterior2, parameters = c(3:5, "posterior"),
            alignment = 1:2, col = c("blue", "red"),
            iterations = 4000:5000, runs = 1:2,
            xlab = expression(alpha[3], log~gamma[1], log~gamma[2], "posterior"),
            cex.axis = 1.2, cex.lab = 1.2,
            ylab = c("alpha", "log gamma", "log posterior"),
            border = "green")
  })
})


test_that("BeanPlot returns valid kde objects", {
  set.seed(1)
  png(tempfile())
  values <- BeanPlot(stratPosterior2, parameters = c(3:5, "posterior"),
           alignment = 1:2, col = c("blue", "red"),
           iterations = 4000:5000, runs = 1:2,
           xlab = expression(alpha[3], log~gamma[1], log~gamma[2], "posterior"),
           cex.axis = 1.2, cex.lab = 1.2,
           ylab = c("alpha", "log gamma", "log posterior"),
           border = "green")
  dev.off()

  # Returns a list with one element per parameter group
  expect_type(values, "list")
  # Parameters 3:5 are alpha_site3, gammaLog_site2, gammaLog_site3 → 2 groups
  # Plus "posterior" → 3 groups total
  expect_length(values, 3)

  # Each element is a list of kde objects
  for (i in seq_along(values)) {
    expect_type(values[[i]], "list")
    for (j in seq_along(values[[i]])) {
      kde <- values[[i]][[j]]
      expect_s3_class(kde, "kde")
      expect_true(is.numeric(kde$estimate))
      expect_true(all(kde$estimate >= 0))
      expect_true(length(kde$eval.points) > 0)
    }
  }
})


test_that("BeanPlot works with new cluster object and
          iterations before burnIn", {
            skip_if_not_snapshot_os()
            skip_on_ci()

            clustNew <- Cluster(stratPosterior1, iterations = 100:200)

            vdiffr::expect_doppelganger("BeanPlot 3", function() {
              BeanPlot(stratPosterior1, alignment = 1,
                      stratCluster = clustNew, type = "o")
            })})


test_that("BeanPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({BeanPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("BeanPlot does not crash when a selection yields a single sample", {
  set.seed(1)
  png(tempfile())
  expect_no_error(values <- BeanPlot(stratPosterior1, maxSamples = 1))
  dev.off()

  expect_type(values, "list")
  for (group in values) {
    for (dens in group) {
      expect_true(isTRUE(dens[["singlePoint"]]))
    }
  }
})
