test_that(".SafeWriteSamplesForPlotting and .LockFileExists/.RemoveLockFile agree on the same lock file (RT-065)", {
  # Before the fix, the reader (.LockFileExists) appended a second ".lock"
  # extension onto the path it was passed, so it checked for
  # "<fileName>.lock.lock" -- a file the writer never creates. Reader and
  # writer must coordinate on the exact same "<fileName>.lock" path.
  tmpDir <- tempfile("locktest")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  modelName <- "locktestmodel"
  run <- 1
  fileName <- paste0(modelName, "_plot_samples", "_run_", run)
  rdsPath <- file.path(tmpDir, sprintf("%s.rds", fileName))
  lockPath <- file.path(tmpDir, sprintf("%s.lock", fileName))

  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, modelName, run, matrix(1:4, 2, 2))
  expect_true(file.exists(rdsPath))
  # lock is released again once the write completes
  expect_false(file.exists(lockPath))

  # the reader checks the SAME physical path the writer used, not a
  # double-extensioned "<fileName>.lock.lock"
  expect_false(StratoBayes:::.LockFileExists(lockPath))
  # .LockFileExists acquires the lock as a side effect
  expect_true(file.exists(lockPath))

  # mutual exclusion: while the reader holds the lock, the writer must skip
  # writing rather than rename over the file mid-read
  before <- readRDS(rdsPath)
  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, modelName, run, matrix(9:12, 2, 2))
  expect_equal(readRDS(rdsPath), before)

  # release the reader's lock; the writer can now proceed again
  StratoBayes:::.RemoveLockFile(lockPath)
  expect_false(file.exists(lockPath))
  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, modelName, run, matrix(9:12, 2, 2))
  expect_equal(as.vector(readRDS(rdsPath)), 9:12)
})

test_that("a stale lock file is detected and cleared rather than blocking forever (RT-065)", {
  tmpDir <- tempfile("locktest")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  modelName <- "locktestmodel"
  run <- 1
  fileName <- paste0(modelName, "_plot_samples", "_run_", run)
  rdsPath <- file.path(tmpDir, sprintf("%s.rds", fileName))
  lockPath <- file.path(tmpDir, sprintf("%s.lock", fileName))

  # simulate a lock left behind by a crashed writer/reader
  file.create(lockPath)
  Sys.setFileTime(lockPath, Sys.time() - (StratoBayes:::.plotLockStaleSecs + 5))
  expect_true(StratoBayes:::.IsLockStale(lockPath))

  # the writer must be able to proceed past a stale lock rather than being
  # permanently blocked
  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, modelName, run, matrix(5:8, 2, 2))
  expect_true(file.exists(rdsPath))
  expect_equal(as.vector(readRDS(rdsPath)), 5:8)
  expect_false(file.exists(lockPath))

  # the reader must likewise treat a stale lock as clear, not as "busy forever"
  file.create(lockPath)
  Sys.setFileTime(lockPath, Sys.time() - (StratoBayes:::.plotLockStaleSecs + 5))
  expect_false(StratoBayes:::.LockFileExists(lockPath))

  # a fresh lock (just created) must NOT be treated as stale
  file.create(lockPath)
  expect_false(StratoBayes:::.IsLockStale(lockPath))
})
