{ # Initialize test objects
  set.seed(1)
  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- matrix(c(1, 0, 0.7, 0,
                   0, 1, 0.1, 0.1,
                   0.7, 0.1, 1, -0.5,
                   0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- matrix(c(0.7, 0, 0.4, 0,
                   0, 0.6, 0.5, 0.1,
                   0.4, 0.1, 0.75, -0.5,
                   0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4 * matrix(c(0.7, 0, -0.4, 0,
                         0, 0.6, 0.5, 0.1,
                         -0.4, 0.1, 0.75, 0.5,
                         0, 0.1, 0.5, 0.7), nrow = 4)
  data1 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1)
    ))

  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data2 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1)))
  if (interactive()) {
    plot(data2)
  }


  data3 <- data.frame(
    V1 = c(97.56527, 102.54420, 101.53206, 101.53206, 101.53206, 101.38620, 101.38620,
           100.94047, 100.94047, 99.57210, 100.33106, 100.18833, 99.34119, 99.34119,
           99.43087, 99.33477, 101.38620, 101.38620, 100.94047, 100.94047),
    V2 = c(103.02928, 108.00821, 118.25200, 109.04995, 103.32610, 103.18024, 100.84177,
           106.35769, 100.64825, 104.47125, 107.99137, 105.84992, 101.93326, 89.97386,
           87.70621, 94.24024, 103.18024, 100.84177, 106.35769, 100.64825),
    V3 = c(-0.05652142, -0.05652142, -0.04776534, -0.04776534, -0.04776534, -0.04776534,
           -0.04776534, -0.02732213, -0.02732213, -0.02991628, -0.01460799, -0.02466896,
           -0.01819302, -0.01819302, -0.01644947, -0.01931594, -0.04776534, -0.04776534,
           -0.02732213, -0.02732213),
    V4 = c(0.3448458, 0.3448458, 0.1349495, 0.1349495, 0.1349495, 0.1349495, 0.1349495,
           0.2623913, 0.2623913, 0.4074241, 0.1234816, 0.2380531, 0.4972773, 0.4972773,
           0.5936869, 0.6173871, 0.1349495, 0.1349495, 0.2623913, 0.2623913)
  )


  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(40, 9, 1)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data4 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1))
  )
}

test_that("Cluster.default data1 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
    cl1 <- Cluster(data1)
    # most of the first 400 should be cluster 1
    testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.1)
    # most of the following 90 should be cluster 2
    testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.1)
})

test_that("Cluster.default data1 - proto, higher outlier", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data1, silOutlierThreshold = 0.3)
  # most of the last 10 should be cluster 0
  testthat::expect_equal(sum(abs(diff(cl1[491:500]) > 0))+10, 10, tolerance = 0.2)
})

test_that("Cluster.default data1 - pam", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "pam")
  # most of the first 400 should be cluster 1
  testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.05)
  # most of the following 90 should be cluster 2
  testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.05)
})

test_that("Cluster.default data1 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "hdbscan", minPts = 4)
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))>0)+50, 50, tolerance = 0.2)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0)+100, 100, tolerance = 0.25)
})

test_that("Cluster.default data2 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "proto",
                 silOutlierThreshold = 0.1)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))>0)+50, 50, tolerance = 0.2)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0)+100, 100, tolerance = 0.25)
})

test_that("Cluster.default data2 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(cl1Table[length(cl1Table) - c(1, 0)], c(90, 400), tolerance = 0.1)
})

test_that("Cluster.default data3 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) >  3)
})

test_that("Cluster.default data3 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "proto", silOutlierThreshold = 0)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) <=  3)
})

test_that("Cluster.default data4 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data4, clusterMethod = "proto")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[41:49]))), 0, tolerance = 3)
  testthat::expect_equal(sum(abs(diff(cl1[1:40]))), 0, tolerance = 4)
  })

test_that("Cluster.StratPosterior - proto default", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1)
  # Should find at least 1 cluster
  testthat::expect_true(any(cl1[["cluster"]] > 0))
  testthat::expect_equal(cl1[["options"]][["clusterMethod"]], "proto")
})

test_that("Cluster.StratPosterior - hdbscan explicit", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1, clusterMethod = "hdbscan")[["cluster"]]
  # HDBSCAN should find at least 1 cluster
  testthat::expect_true(any(cl1 > 0))
})

test_that("Cluster.StratPosterior falls back to single cluster when all noise", {
  # Use very high burnIn so few samples remain; minPts forces all-noise in hdbscan
  cl <- Cluster(stratPosterior1, burnIn = 0.99,
                clusterMethod = "hdbscan", minPts = 50)
  expect_equal(cl[["nClust"]], 1L)
  expect_false(0L %in% cl[["clustUnique"]])
  expect_true(1L %in% cl[["clustUnique"]])
  # alignment = 1 (default) should now be valid
  expect_silent(.ValidateAlignment(1, clustUnique = cl[["clustUnique"]]))
})

test_that("Cluster.StratPosterior - StratPosterio2", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior2, burnIn = 0.9)[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  # Allow noise (cluster 0) in addition to the two modes
  condition3 <- all(cl1 %in% c(0, 1, 2))

  testthat::expect_true(all(condition1, condition2, condition3))
})

test_that("Cluster.StratPosterior - hdbscan finds multiple modes", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1, clusterMethod = "hdbscan")[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  testthat::expect_true(all(condition1, condition2))
})

test_that("Cluster.StratPosterior - hdbscan with maxSamples", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior2, maxSamples = 100,
                 clusterMethod = "hdbscan")$cluster

  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  # Allow noise (cluster 0) alongside the two modes
  condition3 <- all(cl1 %in% c(0, 1, 2))

  testthat::expect_true(all(condition1, condition2, condition3))
})


test_that("Cluster.StratPosterior can deal with runSelect and selectRows", {
  set.seed(1)
  expect_error(Cluster(stratPosterior1, selectRows = list(102:101, 100:101)),
               "selectRows")
  expect_error(Cluster(stratPosterior1, runs = c(4,2),
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  expect_error(Cluster(stratPosterior1, runs = 3:1,
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = list(102:101, 100:101, NULL))[["cluster"]],
               c(1, 2))
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = 102:101)[["cluster"]],
               c(1, 2))
  # With only 4 data points, should find 2 clusters with pairs grouped together
  cl_small <- Cluster(stratPosterior1, runs = c(3, 1),
                      selectRows = 102:101)[["cluster"]]
  expect_equal(cl_small[1], cl_small[2])
  expect_equal(cl_small[3], cl_small[4])
  expect_false(cl_small[1] == cl_small[3])
  expect_equal(Cluster(stratPosterior1, runs = c(3, 1),
                       selectRows = list(102:101, 100))[["runIndex"]],
               c(3, 3, 1))
  })

test_that("Cluster.StratPosterior returns Cluster Data", {
  set.seed(1)
  its <- 4950:5000
  selectedSamples <- length(which(its %in% stratPosterior2[[c("mcmcSummary", "saveIter")]][[1]])) * stratPosterior2$nRun
    cluster1 <- Cluster(stratPosterior2, iterations = its, returnClusterData = TRUE)
    expect_equal(dim(cluster1$clusterData), c(selectedSamples, length(unlist(stratPosterior2$model$heightsForClustering))))
})

test_that("Cluster.StratPosterior - proto finds single cluster for unimodal posterior", {
  # stratPosterior0 and stratPosterior5b are known unimodal cases where
  # hdbscan over-splits; proto should conservatively call them 1 cluster
  cl0 <- Cluster(stratPosterior0)
  expect_equal(cl0[["nClust"]], 1L)

  cl5b <- Cluster(stratPosterior5b)
  expect_equal(cl5b[["nClust"]], 1L)
})

test_that("Cluster.StratPosterior - proto finds two clusters for bimodal posterior", {
  cl2 <- Cluster(stratPosterior2, burnIn = 0.9)
  expect_equal(cl2[["nClust"]], 2L)
  expect_true(all(cl2[["cluster"]] %in% c(0, 1, 2)))
})

test_that("Cluster.StratPosterior - proto finds three clusters for trimodal posterior", {
  cl5a <- Cluster(stratPosterior5a)
  expect_equal(cl5a[["nClust"]], 3L)
})

test_that(".ProtoClusterSubsample agrees with full .ProtoCluster on small data", {
  set.seed(3817)
  # With n < maxClusterSamples, subsample path should produce identical results
  mat <- rbind(
    matrix(rnorm(100 * 4, mean = 0), nrow = 100),
    matrix(rnorm(100 * 4, mean = 5), nrow = 100)
  )
  cl_full <- .ProtoCluster(mat, clustMax = 12)
  cl_sub  <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  expect_identical(cl_full, cl_sub)
})

test_that(".ProtoClusterSubsample handles 1D data with n > maxClusterSamples (RT-057)", {
  set.seed(4711)
  mat <- matrix(c(rnorm(1500, mean = 0), rnorm(1500, mean = 10)), ncol = 1)
  cl <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  expect_length(cl, nrow(mat))
  expect_true(all(cl %in% c(0L, 1L, 2L)))
})

test_that(".ProtoClusterFast returns k=1 for degenerate all-identical input (RT-126)", {
  cl <- .ProtoClusterFast(matrix(1, 8, 3), clustMax = 6)
  expect_identical(cl, rep.int(1L, 8))
})

test_that(".IsPositiveDefinite works", {
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3))))
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,NA,2,3,6,7,8,9), nrow = 3))))
  expect_true(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3)) + diag(3) / 1000))
})
