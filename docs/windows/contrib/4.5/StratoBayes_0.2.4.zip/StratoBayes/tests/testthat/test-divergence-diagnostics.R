# T-137: Tests for NUTS/HMC divergence diagnostics surfacing
#
# Verifies that:
#   1. mcmcSummary contains divergence fields when NUTS is used
#   2. summary.StratPosterior includes divergences in general section
#   3. print.summary.StratPosterior displays divergence info
#   4. MH-only runs do NOT include divergence fields

# Helper: run a NUTS model and return StratPosterior
run_nuts_for_diagnostics <- function(engine = "R") {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  # RunStratModel returns a StratPosterior object
  RunStratModel(
    stratObject = stratData1, stratModel = model,
    nIter = 500, nChains = 2, seed = 4817,
    quiet = TRUE, visualise = FALSE, engine = engine
  )
}


test_that("NUTS R engine surfaces divergence diagnostics in mcmcSummary", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true("nGradientTransitions" %in% names(post[["mcmcSummary"]]))
  expect_true("maxTreeDepth" %in% names(post[["mcmcSummary"]]))

  nRun <- post[["nRun"]]
  expect_length(post[[c("mcmcSummary", "nDivergent")]], nRun)
  expect_length(post[[c("mcmcSummary", "nGradientTransitions")]], nRun)

  # NUTS was used, so there should be gradient transitions
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "nDivergent")]] >= 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})

test_that("summary.StratPosterior includes divergences for NUTS", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  expect_true("divergences" %in% names(s[["general"]]))

  divInfo <- s[[c("general", "divergences")]]
  expect_true("nDivergent" %in% names(divInfo))
  expect_true("nGradientTransitions" %in% names(divInfo))
  expect_true("divergenceRate" %in% names(divInfo))
  expect_true("maxTreeDepth" %in% names(divInfo))
  expect_true("perRun" %in% names(divInfo))

  expect_true(divInfo$divergenceRate >= 0 && divInfo$divergenceRate <= 1)
  expect_s3_class(divInfo$perRun, "data.frame")
  expect_equal(nrow(divInfo$perRun), post[["nRun"]])
})

test_that("print.summary.StratPosterior displays divergence info", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")

  expect_true(
    grepl("gradient-based", outputText, ignore.case = TRUE) ||
      grepl("divergent", outputText, ignore.case = TRUE)
  )
})

test_that("MH-only run does NOT include divergence fields", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  post <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 50, nChains = 2, seed = 7291,
    quiet = TRUE, visualise = FALSE
  )

  expect_null(post[[c("mcmcSummary", "nDivergent")]])
  expect_null(post[[c("mcmcSummary", "nGradientTransitions")]])

  s <- summary(post)
  expect_null(s[[c("general", "divergences")]])
})

# ── T-138: Rank-normalized split-chain R-hat tests ───────────────────────────

test_that(".RhatRankNorm returns ~1.0 for converged chains", {
  set.seed(6142)
  # Two chains from the same distribution should give R-hat near 1
  chain1 <- matrix(rnorm(500), ncol = 2)
  chain2 <- matrix(rnorm(500), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  expect_true(all(rhat < 1.1))
  expect_true(all(rhat >= 1.0))
})

test_that(".RhatRankNorm detects non-convergence", {
  set.seed(3974)
  # Two chains from very different distributions
  chain1 <- matrix(rnorm(500, mean = 0), ncol = 2)
  chain2 <- matrix(rnorm(500, mean = 10), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_true(all(rhat > 1.5))
})

test_that(".RhatRankNorm handles constant parameter", {
  chain1 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  chain2 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("const", "varying")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  # Constant parameter: R-hat = 1.0
  expect_equal(unname(rhat[1]), 1.0)
  # Varying parameter: R-hat near 1.0
  expect_true(rhat[2] < 1.2)
})

test_that(".RhatBasic computes standard R-hat correctly", {
  set.seed(8851)
  # 4 identical chains → R-hat = 1
  chains <- matrix(rnorm(400), ncol = 4)
  rhat <- StratoBayes:::.RhatBasic(chains)
  # R-hat should be close to 1 for IID chains (can be slightly below 1)
  expect_true(rhat > 0.95 && rhat < 1.1)
})

test_that("summary.StratPosterior uses rank-normalized R-hat label", {
  skip_on_cran()

  post <- StratoBayes::stratPosterior1
  s <- summary(post)
  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")
  expect_true(grepl("rank-normalized", outputText))
})

test_that("NUTS C++ engine surfaces divergence diagnostics", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "cpp")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})

# ── RT-007: MonitorAccum gradient-diagnostic data race ───────────────────────
#
# recordGradient() runs inside pool.dispatch() on worker threads. Before the
# fix it mutated three shared scalars (nGradientTransitions/nDivergent/
# maxTreeDepth) with unsynchronized ++ / conditional-max — a C++ data race that
# silently *drops* increments under nThreads > 1.
#
# A full RunStratModel run is NOT reproducible in nThreads: the R-side NUTS /
# cost-aware schedule re-weights proposals between blocks off wall-clock timing,
# so gradient counts vary run-to-run even sequentially. We therefore drive the
# engine directly — .sb_run_block for a SINGLE monitor window with a NUTS-only
# proposal set. With one block there is no between-block re-weighting, so a fixed
# per-chain RNG seed makes the sampling — and the true gradient counts — bit-for-
# bit deterministic in nThreads. A sequential (nThreads = 0) block is the race-
# free ground truth; a parallel (nThreads = 2) block of the same seed must
# reproduce all three counters exactly. Under the race the parallel counters fall
# below the baseline (lost increments). nThreads is capped at 2 (CI convention);
# nChains = 4 > nThreads so chains queue across the workers, widening the race
# window. The reliable many-rep reproducer lives in
# dev/red-team/heavy-tests/RT-007-monitoraccum-race.R.

# Build a NUTS-only engine setup: run a short R chain to obtain fully-initialised
# state (incl. NUTS dual-averaging), then force the proposal set to NUTS only
# (0 * anyweight = 0, so no other proposal is ever selected).
.rt007_setup <- function(nChains = 4L) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("rt007_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  RunStratModel(stratData1, model, nIter = 30, nChains = nChains, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, which(colnames(pp) == "NUTS")] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  list(data = stratData1, model = model, mcmc = mcmc, state = mcmc$recentState)
}

# Run one NUTS-only block at nThreads and return the three diagnostic counters.
# A fresh engine each call starts from the same initial state; set.seed fixes the
# per-chain RNG seeds drawn at the start of .sb_run_block.
.rt007_grad_counts <- function(s, nThreads, nIter, seed) {
  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc, s$state)
  if (nThreads > 1L) StratoBayes:::.sb_set_threads(eng, as.integer(nThreads))
  StratoBayes:::.sb_configure_monitor(eng, s$mcmc[[c("metro", "nProposals")]][[1L]])
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, as.integer(nIter))
  mon <- StratoBayes:::.sb_get_monitor(eng)
  c(nGradientTransitions = mon$nGradientTransitions,
    nDivergent           = mon$nDivergent,
    maxTreeDepth          = mon$maxTreeDepth)
}

test_that("RT-007: parallel NUTS gradient diagnostics have no data race", {
  skip_on_cran()

  s <- .rt007_setup(nChains = 4L)
  nIter <- 400L
  baseline <- .rt007_grad_counts(s, nThreads = 0L, nIter = nIter, seed = 99L)

  # Must-hold invariants, independent of the race: the NUTS path ran and the
  # counters are internally consistent.
  expect_gt(baseline[["nGradientTransitions"]], 0L)
  expect_gte(baseline[["nDivergent"]], 0L)
  expect_lte(baseline[["nDivergent"]], baseline[["nGradientTransitions"]])
  expect_gte(baseline[["maxTreeDepth"]], 1L)

  # Race check: same seed + single block => deterministic in nThreads, so the
  # parallel counters must equal the sequential baseline exactly. Repeat to give
  # a reintroduced race more chances to drop an increment.
  for (rep in seq_len(5L)) {
    parCounts <- .rt007_grad_counts(s, nThreads = 2L, nIter = nIter, seed = 99L)
    expect_equal(parCounts[["nGradientTransitions"]],
                 baseline[["nGradientTransitions"]])
    expect_equal(parCounts[["nDivergent"]], baseline[["nDivergent"]])
    expect_equal(parCounts[["maxTreeDepth"]], baseline[["maxTreeDepth"]])
  }
})
