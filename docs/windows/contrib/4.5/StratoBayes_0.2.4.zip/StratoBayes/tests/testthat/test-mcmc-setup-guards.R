# Guards for silent MCMC-setup misconfigurations.
#
# RT-273: .UpdateState() selects a proposal type with
#   sample.int(prob = proposalProbabilityWeights[chain, ] * proposalProbability[chain, ]).
# StratMCMC() guarantees the Prior weight (column 1) is positive, so the weights
# alone can never be all-zero -- but the *product* with the adapted proposal
# probabilities can be, e.g. when onlyMultivariateProposalsAfterAdapt zeros every
# proposalProbability but Multivariate and the user also set the Multivariate
# weight to 0. sample.int() then aborts with the opaque base-R error
# "too few positive probabilities". The guard turns that into an actionable stop().
#
# RT-272: on the C++ engine, a model that needs R callbacks (custom prior
# densities or tie densities not natively supported in C++) has
# canParallelize = FALSE, so chains run sequentially even when nThreads > 1.
# .sb_set_threads() now emits a message so the requested speed-up is not silently
# dropped.

# ── RT-273: proposal-selection guard ─────────────────────────────────────────

test_that("RT-273: .UpdateState errors clearly when no proposal has positive probability", {
  nProp <- 3L
  # weights x probability = c(1,0,1) * c(0,1,0) = c(0,0,0)
  mcmc <- list(metro = list(
    nProposals                 = list(nProp),
    proposalProbabilityWeights = matrix(c(1, 0, 1), nrow = 1),
    proposalProbability        = matrix(c(0, 1, 0), nrow = 1)
  ))
  expect_error(
    .UpdateState(NULL, NULL, mcmc, NULL, 1L),
    "no MCMC proposal has positive selection probability"
  )
})

test_that("RT-273: guard does not fire when at least one proposal has positive probability", {
  nProp <- 3L
  # product = c(1,2,0) * c(0.5,0.5,0) = c(0.5,1,0): positive, must pass the guard.
  mcmc <- list(metro = list(
    nProposals                 = list(nProp),
    proposalProbabilityWeights = matrix(c(1, 2, 0), nrow = 1),
    proposalProbability        = matrix(c(0.5, 0.5, 0), nrow = 1)
  ))
  # The call continues past the guard and fails downstream (no propose/model),
  # so the only thing asserted is that it is NOT the RT-273 guard error.
  msg <- tryCatch({
    .UpdateState(NULL, NULL, mcmc, NULL, 1L)
    NA_character_
  }, error = function(e) conditionMessage(e))
  expect_false(isTRUE(grepl("no MCMC proposal has positive selection", msg)))
})

# ── RT-272: silent-sequential warning on the C++ engine ──────────────────────

test_that("RT-272: cpp engine warns when R callbacks force sequential execution despite nThreads > 1", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  # A custom D closure (not a built-in density) makes .InferPriorType() return
  # "" -> PT_CUSTOM -> the engine needs an R callback -> canParallelize = FALSE.
  customD <- function(x, mean, sd, log = TRUE) dnorm(x, mean = mean, sd = sd, log = log)
  cp <- Prior(R = function(n, mean, sd) rnorm(n, mean = mean, sd = sd),
              D = customD, Q = qnorm, mean = 0, sd = 10)
  stratModel1$priors$metro[[1]]  <- cp
  stratModel1$priorsProposals[[1]] <- cp

  td <- file.path(tempdir(), paste0("rt272_", sample.int(1e6, 1)))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mcmc <- StratMCMC(stratModel1, nIter = 6, nChains = 2, nThreads = 2)

  expect_message(
    RunStratModel(stratData1, stratModel1, mcmc, seed = 1, quiet = TRUE,
                  visualise = FALSE, modelDir = td, modelName = "rt272",
                  engine = "cpp"),
    "running chains sequentially despite"
  )
})
