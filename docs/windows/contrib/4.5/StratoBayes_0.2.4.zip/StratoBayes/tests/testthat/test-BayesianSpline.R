test_that("BayesianSpline() works with custom knots", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   testSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.25))

   burnin <- floor(0.5 * nrow(testSpline$beta))

   Bmat  <- splines::splineDesign(
      testSpline$model$splineBase$ext_knots, c(0, 4, 12), sparse = FALSE)

   mean_beta <- apply(testSpline$beta[(burnin + 1):nrow(testSpline$beta), ],
                       2, mean)

   pred <- round(.MatrixVectorMult(Bmat, mean_beta), 3)

   expect_equal(pred, c(0.363, 1.147, 5.313), tolerance = 0.01)

   predSp1 <- PredictSpline(testSpline)
   expect_equal(nrow(predSp1), 49)

   predSp2 <- PredictSpline(testSpline, at = c(2, 9), burnIn = 80)

   expect_equal(predSp2$mu, c(1.4, 4.7), tolerance = 0.2)
})

test_that("BayesianSpline() rejects data outside the knot range (RT-246, RT-247)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   # RT-247: data extends above the knot range -> silent right-boundary
   # extrapolation in .sb_spline_design() without this guard.
   expect_error(
      BayesianSpline(x, y, knots = seq(0, 10, 0.5)),
      "must lie within the spline knot range")

   # RT-246: data extends below the knot range -> unkillable find_span() hang
   # in .sb_spline_design() without this guard. The R-side check errors before
   # any x reaches C++, so this test cannot hang.
   expect_error(
      BayesianSpline(x, y, xMin = 2, xMax = 12),
      "must lie within the spline knot range")

   # data fully covered by the knots -> no range error
   expect_error(
      BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 50),
      NA)
})

test_that("PredictSpline() handles thinned-chain burnIn edge cases (RT-114, RT-186)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   # RT-114 / RT-186 mode 1: fractional burnIn with nIter = 1, nThin = 1 ->
   # nRows = 1, ceiling(1 * 0.5) + 1 = 2 > nRows = 1 -> reversed sequence
   # (2:1) and subscript OOB without the fix.
   smallSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                  nIter = 1, nThin = 1)
   expect_error(PredictSpline(smallSpline, at = c(2, 9), burnIn = 0.5))

   # RT-186 mode 2: fractional burnIn selecting exactly one stored row
   # (selectRows collapses to a length-1 index) -> without drop = FALSE the
   # beta subset becomes a vector and apply() errors; with the fix, a single
   # row is a valid (if unusual) prediction, not a crash.
   thinnedSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                    nIter = 2000, nThin = 100)
   expect_error(
      PredictSpline(thinnedSpline, at = c(2, 9), burnIn = 0.95),
      NA)

   # RT-186 mode 3 / RT-115: integer burnIn exceeding the last stored
   # iteration under nThin > 1 -> validated against nIter (100) passes the
   # old check (burnIn = 99 < 100) but no saved iteration exceeds it, giving
   # an empty selectRows and silent NaN output without the fix.
   gappySpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                  nIter = 100, nThin = 5)
   expect_error(PredictSpline(gappySpline, at = c(2, 9), burnIn = 99))
})
