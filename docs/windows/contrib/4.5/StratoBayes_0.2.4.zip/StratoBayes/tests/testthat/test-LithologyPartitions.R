test_that("Partitions() fails gracefully", {
  expect_error(Partitions(2, 2),
               "data.frame")
  expect_error(Partitions(data.frame(height = 2), 2),
               "column.*site")
  expect_error(Partitions(data.frame(site = 2), 2),
               "column.*height")
  expect_error(Partitions(data.frame(site = 2, height = 2),
                                   2, distribute = "invalid"),
               "distribute` must be")
  expect_error(Partitions(data.frame(site = 2, height = 2), "2"),
               "nStrata` must be")
})

test_that("Partitions() works", {
  test <- data.frame(site = c(rep("a", 12), rep("b", 25)),
                     signal = rnorm(37),
                     height = c(1:6, rep(6, 6 ) + seq(0.1, 0.6, 0.1), 1:25))
  aRange <- range(test[test$site == "a", "height"])
  bRange <- range(test[test$site == "b", "height"])
  expect_equal(
    Partitions(test, 2, distribute = "height"),
    data.frame(site = c("a", "a", "b", "b"),
               height = c(aRange[1] + (aRange[2] - aRange[1]) / 2,
                          aRange[2],
                          bRange[1] + (bRange[2] - bRange[1]) / 2,
                          bRange[2]),
               partition = 1:4
    )
  )

  expect_equal(
    Partitions(test, 3, distribute = "points")$height,
    c(5,6.3, 6.6, 9, 17, 25), tolerance = .01
    )

  # depth scale
  testDataDepth <- .GenerateTestData(testdata = "depth", version = "1")
  expect_equal(Partitions(testDataDepth$signal, 3, distribute = "points",
                                   zColumn = "depth", zScale = "depth")$depth,
               c(3,1,0,-2,-4,-5), tolerance = .01)

})

test_that("Partitions() rejects nStrata that would produce degenerate strata (RT-196)", {
  # distribute = "points": nStrata >= number of points at a site previously
  # produced duplicate/degenerate (zero-width) boundaries silently.
  test <- data.frame(site = rep("a", 5), height = 1:5)
  expect_error(
    Partitions(test, nStrata = 5, distribute = "points"),
    "must be less than the number of points"
  )
  expect_error(
    Partitions(test, nStrata = 10, distribute = "points"),
    "must be less than the number of points"
  )
  # one below the limit still works
  expect_no_error(Partitions(test, nStrata = 4, distribute = "points"))
})

test_that("Partitions() with distribute = 'StratoSegment' segments each site", {
  skip_if_not_installed("StratoSegment")
  set.seed(1)
  # Construct a clean piecewise-constant signal with an obvious break per site.
  heightA <- seq(0, 20, length.out = 60)
  signalA <- c(rep(0, 30), rep(5, 30)) + rnorm(60, sd = 0.01)
  heightB <- seq(0, 40, length.out = 80)
  signalB <- c(rep(10, 40), rep(-2, 40)) + rnorm(80, sd = 0.01)
  dat <- data.frame(
    site = c(rep("A", 60), rep("B", 80)),
    height = c(heightA, heightB),
    value = c(signalA, signalB)
  )

  out <- Partitions(dat, nStrata = 2, distribute = "StratoSegment",
                    signalColumn = "value")
  expect_s3_class(out, "data.frame")
  expect_equal(colnames(out), c("site", "height", "partition"))
  expect_equal(nrow(out), 4L)
  # Break for site A should sit near the middle of heightA (~10).
  aHeights <- out$height[out$site == "A"]
  expect_true(abs(aHeights[1] - heightA[30]) < diff(range(heightA)) * 0.1)
  expect_equal(aHeights[2], max(heightA))
  # Break for site B should sit near heightB[40].
  bHeights <- out$height[out$site == "B"]
  expect_true(abs(bHeights[1] - heightB[40]) < diff(range(heightB)) * 0.1)
  expect_equal(bHeights[2], max(heightB))
})

test_that("Partitions() default is StratoSegment and auto-detects signal columns", {
  skip_if_not_installed("StratoSegment")
  set.seed(2)
  heights <- seq(0, 30, length.out = 60)
  signalA <- c(rep(0, 30), rep(3, 30)) + rnorm(60, sd = 0.01)
  dat <- data.frame(
    site = rep("A", 60),
    value = signalA,
    height = heights
  )
  out <- Partitions(dat, nStrata = 2)
  expect_equal(nrow(out), 2L)
  expect_equal(out$site, c("A", "A"))
  expect_true(abs(out$height[1] - heights[30]) < diff(range(heights)) * 0.1)
})

test_that("Partitions() falls back to points when no signal columns exist", {
  dat <- data.frame(site = rep("A", 10), height = seq_len(10))
  expect_message(
    out <- Partitions(dat, nStrata = 2),
    "falling back"
  )
  expect_equal(nrow(out), 2L)
})

test_that("Partitions() StratoSegment respects depth scale", {
  skip_if_not_installed("StratoSegment")
  set.seed(3)
  depth <- seq(1, 20, length.out = 60)
  value <- c(rep(0, 30), rep(5, 30)) + rnorm(60, sd = 0.01)
  dat <- data.frame(site = rep("A", 60), depth = depth, value = value)
  out <- Partitions(dat, nStrata = 2, distribute = "StratoSegment",
                    zColumn = "depth", zScale = "depth",
                    signalColumn = "value")
  expect_equal(colnames(out), c("site", "depth", "partition"))
  # On depth scale the returned partition tops are sorted descending: the
  # shallow top of the shallow segment comes last.
  expect_equal(out$depth[2], min(depth))
})

test_that("StratData() accepts partitions from Partitions() on height scale", {
  skip_if_not_installed("StratoSegment")
  set.seed(4)
  heightA <- seq(0, 40, length.out = 40)
  heightB <- seq(0, 20, length.out = 20)
  valueA <- c(rep(0, 20), rep(2, 20)) + rnorm(40, sd = 0.05)
  valueB <- c(rep(1, 10), rep(-1, 10)) + rnorm(20, sd = 0.05)
  dat <- data.frame(
    site   = c(rep("A", 40), rep("B", 20)),
    height = c(heightA, heightB),
    value  = c(valueA, valueB)
  )

  for (dist in c("StratoSegment", "points", "height")) {
    out <- Partitions(dat, nStrata = 2, distribute = dist,
                      signalColumn = "value")
    sd_obj <- expect_silent(StratData(dat, parts = out))
    expect_s3_class(sd_obj, "StratData")
    # Every signal point must be covered by a partition for each site.
    for (s in unique(dat$site)) {
      maxSignal <- max(dat$height[dat$site == s])
      maxPart   <- max(out$height[out$site == s])
      expect_gte(maxPart, maxSignal)
    }
  }
})

test_that("StratData() accepts partitions from Partitions() on depth scale", {
  skip_if_not_installed("StratoSegment")
  set.seed(5)
  depthA <- seq(0, 40, length.out = 40)
  depthB <- seq(0, 20, length.out = 20)
  valueA <- c(rep(0, 20), rep(2, 20)) + rnorm(40, sd = 0.05)
  valueB <- c(rep(1, 10), rep(-1, 10)) + rnorm(20, sd = 0.05)
  dat <- data.frame(
    site  = c(rep("A", 40), rep("B", 20)),
    depth = c(depthA, depthB),
    value = c(valueA, valueB)
  )

  for (dist in c("StratoSegment", "points", "depth")) {
    out <- Partitions(dat, nStrata = 2, distribute = dist,
                      zColumn = "depth", zScale = "depth",
                      signalColumn = "value")
    # When both `Partitions()` and `StratData()` are told the data are on
    # the depth scale, the workflow must succeed end-to-end.
    sd_obj <- expect_silent(
      StratData(dat, parts = out, zColumn = "depth", zScale = "depth")
    )
    expect_s3_class(sd_obj, "StratData")
    expect_equal(sd_obj$zScale, "depth")
    # `Partitions()` places the top partition at the shallowest depth of each
    # site (minimum of the original depth column) so that, after `StratData()`
    # flips to the internal height scale, the partition top covers the full
    # signal extent.
    for (s in unique(dat$site)) {
      expect_equal(min(out$depth[out$site == s]),
                   min(dat$depth[dat$site == s]))
    }
  }
})

test_that("StratData() flags zScale mismatch when parts come from depth scale", {
  skip_if_not_installed("StratoSegment")
  set.seed(6)
  depthA <- seq(0, 40, length.out = 40)
  depthB <- seq(0, 20, length.out = 20)
  valueA <- c(rep(0, 20), rep(2, 20)) + rnorm(40, sd = 0.05)
  valueB <- c(rep(1, 10), rep(-1, 10)) + rnorm(20, sd = 0.05)
  dat <- data.frame(
    site  = c(rep("A", 40), rep("B", 20)),
    depth = c(depthA, depthB),
    value = c(valueA, valueB)
  )
  out <- Partitions(dat, nStrata = 2, distribute = "StratoSegment",
                    zColumn = "depth", zScale = "depth",
                    signalColumn = "value")
  # Forgetting `zScale = "depth"` in StratData() used to produce a cryptic
  # error; it should now include a hint about the missing zScale argument.
  expect_error(
    StratData(dat, parts = out, zColumn = "depth"),
    "zScale"
  )
})

test_that("Partitions() distribute = 'height' spaces boundaries by age when ties are supplied (RT-214)", {
  # ties encode a sedimentation rate that changes partway up the section:
  # slow near the base (0-10), faster in the middle (10-90), slow again near
  # the top (90-100). Equal-age boundaries should therefore differ from
  # equal-height boundaries.
  signal <- data.frame(site = rep("a", 6), height = c(0, 20, 40, 60, 80, 100))
  ties <- data.frame(
    site = "a",
    height = c(0, 10, 90, 100),
    densityFun = "dnorm",
    arg1 = c(100, 95, 15, 0),
    arg2 = 1
  )

  noTies <- Partitions(signal, nStrata = 4, distribute = "height")
  withTies <- Partitions(signal, nStrata = 4, distribute = "height", ties = ties)

  expect_equal(noTies$height, c(25, 50, 75, 100))
  expect_equal(withTies$height, c(30, 55, 80, 100))
  expect_false(isTRUE(all.equal(noTies$height, withTies$height)))
})

test_that("Partitions() ignores ties for distribute = 'points' and 'StratoSegment' (RT-214)", {
  # A monotonic age transform cannot change which sample point a nearest-rank
  # (type = 1) quantile selects, so `ties` has no effect on `"points"`; this
  # is a deliberate, documented scope decision (see @param ties), not a bug.
  signal <- data.frame(site = rep("a", 8), height = 1:8)
  ties <- data.frame(site = "a", height = c(1, 8), densityFun = "dnorm",
                     arg1 = c(100, 1), arg2 = 1)

  expect_identical(
    Partitions(signal, nStrata = 3, distribute = "points")$height,
    Partitions(signal, nStrata = 3, distribute = "points", ties = ties)$height
  )
})

test_that("Partitions() falls back to height space when a site has fewer than two tie points (RT-214)", {
  signal <- data.frame(site = rep("a", 3), height = c(0, 50, 100))
  ties <- data.frame(site = "a", height = 0, densityFun = "dnorm",
                     arg1 = 100, arg2 = 1)

  expect_message(
    out <- Partitions(signal, nStrata = 2, distribute = "height", ties = ties),
    "fewer than two"
  )
  expect_equal(out$height, c(50, 100))
})

test_that("Partitions() rejects non-integer nStrata (RT-043)", {
  test <- data.frame(site = rep("a", 5), height = 1:5)
  expect_error(
    Partitions(test, nStrata = 2.5, distribute = "points"),
    "whole number"
  )
})

test_that("Partitions() rejects NA in siteColumn instead of injecting bogus rows (RT-286)", {
  test <- data.frame(site = c("a", "a", "a", "b", "b", NA),
                     height = c(1, 2, 3, 1, 2, 3))
  expect_error(
    Partitions(test, nStrata = 2, distribute = "points"),
    "NA"
  )
})

test_that("Partitions() coerces factor signal columns via labels, not level codes (RT-287)", {
  skip_if_not_installed("StratoSegment")
  set.seed(7)
  height <- seq(0, 20, length.out = 60)
  value <- c(rep(0, 30), rep(5, 30)) + rnorm(60, sd = 0.01)
  # Factor levels are sorted alphabetically ("-2.5" < "0.01" < ... < "5.02"),
  # so as.numeric() on the factor (level codes) would scramble the signal
  # order entirely, while as.numeric(as.character(.)) preserves it.
  test <- data.frame(site = rep("a", 60), height = height, value = factor(value))
  out <- Partitions(test, nStrata = 2, distribute = "StratoSegment",
                    signalColumn = "value")
  expect_equal(nrow(out), 2L)
  # Break should sit near the middle of height (~10), as in the equivalent
  # numeric-column StratoSegment test above.
  expect_true(abs(out$height[1] - height[30]) < diff(range(height)) * 0.1)
  expect_equal(out$height[2], max(height))
})

test_that("Partitions(distribute = 'height') ignores NA heights via na.rm instead of erroring (RT-288)", {
  test <- data.frame(site = rep("a", 5), height = c(1, 2, NA, 4, 5))
  out <- expect_no_error(Partitions(test, nStrata = 2, distribute = "height"))
  expect_equal(out$height, c(3, 5))
})

test_that("Partitions(distribute = 'height') rejects degenerate single-point/duplicate-height sites (RT-289/RT-044)", {
  singlePoint <- data.frame(site = "a", height = 5)
  expect_error(
    Partitions(singlePoint, nStrata = 1, distribute = "height"),
    "must be less than the number of points"
  )

  duplicateHeight <- data.frame(site = rep("a", 3), height = c(5, 5, 5))
  expect_error(
    Partitions(duplicateHeight, nStrata = 3, distribute = "height"),
    "must be less than the number of points"
  )
})


