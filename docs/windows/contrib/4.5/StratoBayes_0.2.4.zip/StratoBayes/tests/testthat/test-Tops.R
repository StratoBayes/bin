test_that("Tops works", {

   expect_error(Tops(1, 2, 2), "stratObject must be")

  tops6 <- Tops(stratPosterior1, 6)
  tops6Site2 <- round(tops6[1,"50%"])
  expect_equal(tops6Site2, 0)

  tops6Site3 <- round(tops6[2,"50%"])
  expect_equal(tops6Site3, 5)

  expect_s3_class(Tops(stratPosterior3, 2), "data.frame")

})

#
test_that("Tops works with prior", {
   #set.seed(1)
   h1 <- Tops(stratModel1, refHeights = 6, stratData = stratData1)

   prior2Q25 <- round(h1[1, "2.5%"]/10)
   prior3Q25 <- round(h1[2, "2.5%"]/10)
   prior2Q500 <- round(h1[1, "50%"]/2 - 0.1)
   prior3Q500 <- round(h1[2, "50%"]/2 - 0.1)

   expect_equal(prior2Q25, -1)
   expect_equal(prior3Q25, -1)
   expect_equal(prior2Q500, 1)
   expect_equal(prior3Q500, 1)

})

test_that("Tops works with returning samples", {
  #set.seed(1)
  # RT-195: quantiles = "samples" now returns wide format (one row per
  # refHeight x site, one column per sample) to match StratMap()'s wide
  # output, rather than the previous long (ref x site x sample) format.
  t1 <- Tops(stratPosterior1, refHeights = 6,
             quantiles = "samples", iterations = c(100, 150), runs = 1)

  expect_equal(nrow(t1), 2)
  expect_equal(ncol(t1), 4)
  expect_equal(names(t1)[1:2], c("refHeight", "site"))
  expect_equal(names(t1)[-(1:2)], c("sample_1", "sample_2"))
})

test_that("Tops() quantiles = 'samples' wide output matches StratMap() shape (RT-195)", {
  tSamples <- Tops(stratPosterior1, refHeights = c(1, 6),
                    quantiles = "samples", iterations = c(100, 150), runs = 1)
  nRef   <- 2
  nSites <- length(unique(tSamples$site))
  nSamp  <- ncol(tSamples) - 2

  expect_equal(nrow(tSamples), nRef * nSites)
  expect_true(all(vapply(tSamples[-(1:2)], is.numeric, logical(1))))

  # shape parity with StratMap(quantiles = "samples"): first column is the
  # height/refHeight axis, remaining columns are one per retained sample.
  mapSamples <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                          quantiles = "samples", iterations = c(100, 150), runs = 1)
  expect_equal(ncol(mapSamples) - 1, nSamp)
})


test_that("Tops works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              Tops(stratPosterior3,
                       refHeights = -1,
                       stratCluster = clustNew,
                       alignment = 1)[ , "sd"]
              <
                Tops(stratPosterior3,
                         refHeights = -1,
                         stratCluster = clustNew,
                         alignment = "all")[ , "sd"]

            )
          })

test_that("Tops works with default refHeights", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              round(Tops(stratPosterior1)[4, "50%"]) == 4)
          })
