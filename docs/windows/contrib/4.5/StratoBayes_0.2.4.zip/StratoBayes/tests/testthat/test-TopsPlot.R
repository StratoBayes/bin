
test_that("TopsPlot works", {
  skip_if_not_snapshot_os()
  expect_error(TopsPlot(1, 2, 2), "'stratPosterior' must be")

  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 1", function() {
    TopsPlot(stratPosterior1)
  })})

test_that("TopsPlot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 2", function() {

    TopsPlot(stratPosterior1, alignment = 1, sites = 3:1,
                 burnIn = 0.95, topsColourScale = "Viridis",
                 colourScale = "Dark 2", topsAlpha = 1,
                 lwd = 2)
  })})

test_that("TopsPlot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 3", function() {

    TopsPlot(stratPosterior0, alignment = 1, sites = 2:1,
             burnIn = 0.95, topsColourScale = "Viridis",
             colourScale = "Dark 2", topsAlpha = 1, refHeights = c(8, 11),
             topsLwd = 3, topsLty = c(2,3,1,4,5), quantiles = c(0.1, 0.2, 0.3, 0.4, 0.9),
             ylim = c(5, 15), xlim = c(0, 2), ylab = "height (m) ", pch = 1:2)
  })})



test_that("TopsPlot works on depth scale", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 4", function() {

    TopsPlot(stratPosterior3, xlab = "depth (m)", alignment = 1, refHeights = c(-3, -1, 0))
  })})

# priors TopsPlot not yet implemented
#
# test_that("TopsPlot can plot prior", {
  skip_if_not_snapshot_os()
#   vdiffr::expect_doppelganger("StratMapPlot 4", function() {
#     set.seed(1)
#     StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 100)
#   })})

# test_that("TopsPlot can plot posterior and prior", {
  skip_if_not_snapshot_os()
#   vdiffr::expect_doppelganger("StratMapPlot 5", function() {
#
#     set.seed(1)
#     StratMapPlot(stratPosterior2, prior = TRUE, col = 2:3, tiesColour = 4,
#                  sites = 1:2, pch = 2, cex = 2, lwd = 2)
#   })})


test_that("TopsPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({TopsPlot(stratPosterior1)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("TopsPlot works with refHeightsSite (pseudo-ref site)", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 5 - refHeightsSite site 2", function() {
    TopsPlot(stratPosterior1,
             refHeights = c(0.1, 1, 1.5),
             refHeightsSite = 2,
             alignment = 1,
             quantiles = c(0.1, 0.5, 0.9))
  })
})

test_that("TopsPlot works with refHeightsSite and multiple sites", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 6 - refHeightsSite with all sites", function() {
    TopsPlot(stratPosterior1,
             refHeights = c(0.1, 3, 4),
             refHeightsSite = 3,
             sites = c(1,3),
             alignment = 1,
             quantiles = c(0.1, 0.5, 0.9),
             topsLwd = 2)
  })
})

test_that("TopsPlot refHeightsSite returns correct data structure", {
  set.seed(1)
  result <- TopsPlot(stratPosterior1,
                      refHeights = c(1, 2),
                      refHeightsSite = 2,
                      alignment = 1,
                      quantiles = c(0.1, 0.5, 0.9),
                      display = FALSE)

  # Check that result is a data frame
  expect_s3_class(result, "data.frame")

  # Check required columns
  expect_true(all(c("refHeight", "site", "quantile", "top") %in% names(result)))

  # Get site names from the data
  sites <- unique(result$site)
  expect_true(length(sites) >= 2)  # Should have at least 2 sites

  # Find input site (site 2) - should be the site that's not "site_1"
  inputSiteName <- sites[sites != "site_1"][1]
  refSiteName <- "site_1"

  # Check that input site (site 2) has same top value for all quantiles per refHeight
  # (all quantiles should equal the input refHeights)
  if (!is.na(inputSiteName)) {
    inputSiteData <- result[result$site == inputSiteName, ]
    if (nrow(inputSiteData) > 0) {
      # Group by refHeight and check that all quantiles have same value
      for (rh in unique(inputSiteData$refHeight)) {
        rhData <- inputSiteData[inputSiteData$refHeight == rh, ]
        if (nrow(rhData) > 1) {
          # All quantiles should have the same top value (the input refHeight)
          uniqueTops <- unique(round(rhData$top, 10))
          expect_equal(length(uniqueTops), 1,
                       info = paste("Input site should have same top value for all quantiles at refHeight", rh))
        }
      }
    }
  }

  # Check that reference site has quantiles (different values from StratMap)
  refSiteData <- result[result$site == refSiteName, ]
  if (nrow(refSiteData) > 0 && length(unique(refSiteData$quantile)) > 1) {
    # For same refHeight, different quantiles should have different top values
    # (these come from StratMap quantiles)
    refHeightGroups <- split(refSiteData$top, refSiteData$refHeight)
    for (rh in names(refHeightGroups)) {
      group <- refHeightGroups[[rh]]
      if (length(group) > 1) {
        # Should have variation across quantiles (StratMap quantiles)
        uniqueVals <- unique(round(group, 8))
        expect_true(length(uniqueVals) > 1,
                    info = paste("Reference site should have different top values across quantiles for refHeight", rh))
      }
    }
  }

  # Verify that reference site quantiles match StratMap output
  set.seed(1)
  stratMapResult <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                              alignment = 1, quantiles = c(0.1, 0.5, 0.9))
  stratMapQuantiles <- as.matrix(stratMapResult[, c("10%", "50%", "90%")])

  # Check that reference site top values match StratMap quantiles
  for (rhIdx in seq_along(c(1, 2))) {
    refHeight <- c(1, 2)[rhIdx]
    refSiteRhData <- refSiteData[refSiteData$refHeight == refHeight, ]
    if (nrow(refSiteRhData) > 0) {
      # Get quantile values from result
      resultQuantiles <- refSiteRhData$top[order(refSiteRhData$quantile)]
      stratMapQuantilesForRh <- as.numeric(stratMapQuantiles[rhIdx, ])

      # Values should match (within rounding)
      expect_equal(round(resultQuantiles, 6), round(stratMapQuantilesForRh, 6),
                   info = paste("Reference site quantiles should match StratMap output for refHeight", refHeight))
    }
  }
})

test_that("TopsPlot refHeightsSite validates input correctly", {
  # Test invalid site
  expect_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 4),
               "must be NULL, a valid site name, or a valid site index")

  # Test invalid site name
  expect_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = "invalid_site"),
               "must be NULL, a valid site name, or a valid site index")

  # Test that refHeightsSite = NULL works (original behavior)
  set.seed(1)
  expect_no_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = NULL, display = FALSE))

  # Test that refHeightsSite = 1 works (reference site)
  set.seed(1)
  expect_no_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 1, display = FALSE))
})

test_that("TopsPlot(quantiles = numeric(0)) errors clearly instead of crashing (RT-197)", {
  expect_error(
    TopsPlot(stratPosterior1, quantiles = numeric(0), display = FALSE),
    "must be a non-empty numeric vector"
  )
})

test_that(".DefaultRefHeightsSite2() survives trailing NA from unequal partition counts (RT-194)", {
  # Regression for RT-194: with a 2-site model, site 2's Bound/BoundLow
  # columns can have trailing NA when site 1 has more partitions than site 2
  # (unequal partition counts). range() without na.rm = TRUE returned
  # c(NA, NA), which propagated into StratMap(heights = c(NA,NA,NA)) and
  # crashed before the later fallback guard.
  dataObj <- list(
    partsAttr = list(
      Bound    = cbind(site1 = c(10, 20, 30), site2 = c(5, 15, NA)),
      BoundLow = cbind(site1 = c(0, 10, 20),  site2 = c(0, 5, NA))
    )
  )

  result <- .DefaultRefHeightsSite2(dataObj)

  expect_true(all(is.finite(result)))
  expect_length(result, 3)
  expect_equal(sort(result)[2], mean(range(c(5, 15, 0, 5))))
})

test_that(".ApplyMarginFrac() insets panel x-bounds by marginFrac of panel width (RT-213)", {
  pltX <- c(0.2, 0.8)
  noMargin <- .ApplyMarginFrac(pltX, 0)
  expect_equal(noMargin, pltX)

  withMargin <- .ApplyMarginFrac(pltX, 0.1)
  expect_false(isTRUE(all.equal(withMargin, pltX)))
  expect_equal(withMargin, pltX + c(1, -1) * 0.1 * diff(pltX))
  expect_true(withMargin[1] > pltX[1])
  expect_true(withMargin[2] < pltX[2])

  # larger marginFrac -> larger inset (measurable effect, RT-213)
  widerMargin <- .ApplyMarginFrac(pltX, 0.2)
  expect_true(diff(widerMargin) < diff(withMargin))
})
