# Value-level equivalence between the two C++ log-posterior implementations
# (red-team finding RT-274).
#
# The core log-posterior (prior + signal likelihood + overlap penalty, plus
# ties) is implemented TWICE in C++:
#
#   * `.sb_logpost` (src/LogPost.cpp) — used by the R engine via
#     R/ModelFunctions.R `.LogPost`, which adds ties through `.LogLikTies`.
#   * `compute_logpost` (src/MCMCEngine.cpp) — used by the C++ engine, reachable
#     from R through `.sb_eval_logpost(engine_ptr, chain, params)`.
#
# The existing tests/testthat/test-cpp-engine-integration.R only checks that the
# C++ engine yields FINITE log-posteriors with the same-shaped output as the R
# engine — never that the two AGREE IN VALUE. These tests close that gap: for
# several bundled dataset x model pairs and prior types (including a TruncNormal
# prior — historically the one place the two paths used different code, until
# RT-274's fix routed both through the shared ThreadRNG::log_diff_pnorm_std),
# they assert that the total AND per-component log-posterior computed by the
# R-engine path equals the C++-engine path at MATCHED parameters and matched
# Gibbs state (beta, sigma, B).
#
# Matching the Gibbs state: both paths are fed the SAME `recentState` produced
# by a short deterministic R-engine run. `.LogPost` reads beta/sigma/B directly
# from that state; `.sb_create_engine` imports the same state into the engine,
# and `.sb_eval_logpost` holds beta/sigma fixed while recomputing B from the
# params via `update_spline_state` (an independent C++ re-derivation of the same
# basis the R path computes with `splines::splineDesign`). The comparison is
# therefore NOT tautological — a future asymmetric edit to either implementation
# will surface here.

# ── Helper: prepared data/model/mcmc/state + engine at a fixed initial state ──
#
# Mirrors the setup RunStratModel performs internally (see R/RunStratModel.R
# ~934-1013): run a short R-engine MCMC to obtain fully-prepared `data`/`model`
# objects and a `recentState` in the R-native format `.LogPost`/`.LogLikTies`
# expect, then build the C++ engine from that same state.
#
# The setup run MUST use engine = "R" (nThreads = 1L): RunStratModel auto-
# switches to the C++ engine when nThreads > 1, and a C++-engine recentState is
# stored in a form the R-side `.LogLikTies` dispatch does not consume. A single
# thread is within the project's 2L cap, and the engine we build below defaults
# to one thread (we never call `.sb_set_threads`).

equiv_setup <- function(sData, sModel, seed = 7261, nChains = 2L) {
  td <- file.path(tempdir(),
                  paste0("equiv_", paste(sample(c(letters, 0:9), 10L, TRUE),
                                         collapse = "")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = nChains, seed = 1,
    quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "equiv", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "equiv_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  # Dispatch caches that RunStratModel sets on the working model (needed by
  # `.LogPost` / `.LogLikTies` on the R side).
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  if (is.null(model_obj$.tiesDispatch))
    model_obj$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(data_obj, model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj,
    state = state_obj, tiesCallback = tiesCallback
  )

  list(data = data_obj, model = model_obj, mcmc = mcmc_obj,
       state = state_obj, engine = engine_ptr, td = td)
}

# Rebuild a bundled model with fixed knots (and optional prior overrides) so we
# can exercise specific prior families. Fixed knots keep the initial-state
# geometry stable across the two engines; the default flexible-knot path is
# covered separately by the stratData1 case below.
rebuild_model <- function(sData, sModel, knotRange, prior_overrides = NULL) {
  priors <- sModel$priors$metro
  if (!is.null(prior_overrides)) {
    for (nm in names(prior_overrides)) priors[[nm]] <- prior_overrides[[nm]]
  }
  StratModel(
    stratData      = sData,
    priors         = priors,
    alignmentScale = sModel$alignmentScale,
    sedModel       = sModel$sedModel,
    flexibleKnots  = FALSE,
    knotRange      = knotRange
  )
}

# ── Assertion: R-path and C++-path log-posteriors agree at the matched state ──
#
# `.LogPost` returns c(logPrior, logLikSignal, logLikTies, logLikOverlap); the
# engine's `logPostSep` (from compute_logpost) uses the identical component
# order, so we can compare component-by-component (strictly stronger than the
# total alone and far better for diagnosing which duplicated block drifted).

expect_logpost_equiv <- function(setup, tol = 1e-8, tag = "") {
  components <- c("logPrior", "logLikSignal", "logLikTies", "logLikOverlap")
  for (ch in seq_along(setup$state)) {
    params <- setup$state[[ch]]$metro$parameters
    r_comp <- StratoBayes:::.LogPost(setup$data, setup$model, setup$state[[ch]])
    cpp <- StratoBayes:::.sb_eval_logpost(setup$engine, ch, params, debug = TRUE)

    expect_true(isTRUE(cpp$ok),
      info = sprintf("%s chain %d: engine reached compute_logpost", tag, ch))

    for (k in seq_len(4L)) {
      expect_equal(cpp$logPostSep[k], r_comp[k], tolerance = tol,
        info = sprintf("%s chain %d component %s: R=%.12g cpp=%.12g",
                       tag, ch, components[k], r_comp[k], cpp$logPostSep[k]))
    }

    r_total <- sum(r_comp, na.rm = TRUE)
    expect_equal(cpp$logPost, r_total, tolerance = tol,
      info = sprintf("%s chain %d total: R=%.12g cpp=%.12g",
                     tag, ch, r_total, cpp$logPost))
  }
}


# ── stratData1 (height/site) — default FLEXIBLE knots, Normal + Uniform priors ─
# Exercises the real default code path (flexibleKnots = TRUE) end to end.

test_that("R- and C++-engine log-posteriors agree: stratData1 (flexible knots)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  setup <- equiv_setup(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  expect_logpost_equiv(setup, tag = "stratData1/flexible")
})


# ── stratData2 (age/site, ties, multi-signal) — fixed knots ──────────────────
# Adds the ties component (R `.LogLikTies` vs the engine's native tie densities).

test_that("R- and C++-engine log-posteriors agree: stratData2 (ties)", {
  skip_on_cran()
  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  sModel <- rebuild_model(stratData2, stratModel2, knotRange = c(0, 100))
  setup <- equiv_setup(stratData2, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  expect_logpost_equiv(setup, tag = "stratData2/ties")
})


# ── stratData3 (partition, sigma estimated) — fixed knots ────────────────────

test_that("R- and C++-engine log-posteriors agree: stratData3 (partition)", {
  skip_on_cran()
  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")

  sModel <- rebuild_model(stratData3, stratModel3, knotRange = c(-5, 15))
  setup <- equiv_setup(stratData3, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  expect_logpost_equiv(setup, tag = "stratData3/partition")
})


# ── TruncNormal prior (central branch) ───────────────────────────────────────
# The TruncNormal normalisation is where the two paths historically differed;
# since RT-274 both call the shared ThreadRNG::log_diff_pnorm_std. With bounds a
# few sigma from the mean it takes the central branch (direct log(Phi_U - Phi_L))
# and agrees to machine precision. This guards the realistic zeta-style prior.

test_that("R- and C++-engine agree with a TruncNormal prior (central branch)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  alpha_nm <- names(stratModel1$priors$metro)[1]
  sModel <- rebuild_model(
    stratData1, stratModel1, knotRange = c(-5, 12),
    prior_overrides = setNames(
      list(TruncNormalPrior(mean = 0, sd = 2, lower = -5, upper = 5)),
      alpha_nm)
  )
  setup <- equiv_setup(stratData1, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  # confirm the override took effect
  expect_identical(setup$model$.logpost_cpp$priorTypes[1], "TruncNormalPrior")
  expect_logpost_equiv(setup, tag = "stratData1/truncNormal-central")
})


# ── TruncLogNormalPrior at its upper boundary (RT-181/023/116) ───────────────
# `.sb_logpost` (LogPost.cpp) and the C++ engine's `compute_logpost`/
# `check_prior_bounds` (MCMCEngine.cpp) are two SEPARATE implementations of the
# same TruncLogNormalPrior boundary check (see the file banner above). Before
# the fix, TruncLogNormalPrior used a CLOSED-interval check (`x <= lower ||
# x >= upper`) while its sibling TruncNormalPrior used an OPEN one (`x < lower
# || x > upper`) — a parameter sitting exactly on the truncation boundary got
# -Inf from every C++ path (LogPost.cpp AND the default engine="cpp" path)
# while the R reference (TruncLogNormDensity()) returned a finite density.
#
# `RunStratModel` defaults to `engine = "cpp"`, so testing only `.sb_logpost`
# (as test-cpp-trunclognormal-boundary.R does) would leave the production
# default path — MCMCEngine.cpp's `compute_logpost` and `check_prior_bounds`,
# plus the HMC/NUTS gradient in Gradient_impl.h — unverified. This block
# exercises that path through the same equiv_setup()/rebuild_model() harness
# used above, exactly as RT-019's follow-up caught the same "R-only fix, cpp
# engine still broken" gap for a different prior family.

test_that("R- and C++-engine agree with a TruncLogNormalPrior at its upper bound", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  alpha_nm <- names(stratModel1$priors$metro)[1]
  upper <- 5
  sModel <- rebuild_model(
    stratData1, stratModel1, knotRange = c(-5, 12),
    prior_overrides = setNames(
      list(TruncLogNormalPrior(meanlog = 0, sdlog = 1, lower = 0.1, upper = upper)),
      alpha_nm)
  )
  setup <- equiv_setup(stratData1, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  # confirm the override took effect
  expect_identical(setup$model$.logpost_cpp$priorTypes[1], "TruncLogNormalPrior")

  # Set alpha_site_2 exactly on the upper truncation boundary (chain 1's
  # sampled value is age-conversion-valid across the whole model's range; only
  # the parameter under test needs to sit exactly at `upper`).
  st <- setup$state[[1]]
  st$metro$parameters[1] <- upper

  r_comp <- StratoBayes:::.LogPost(setup$data, setup$model, st)
  cpp <- StratoBayes:::.sb_eval_logpost(setup$engine, 1L, st$metro$parameters,
                                        debug = TRUE)

  expect_true(isTRUE(cpp$ok))
  expect_true(is.finite(r_comp[1]))
  expect_true(is.finite(cpp$logPostSep[1]))
  expect_equal(cpp$logPostSep[1], r_comp[1], tolerance = 1e-8)
})


# ── -Inf prior short-circuit: both engines return the -1e30 sentinel ─────────
# When a parameter falls outside a bounded prior's support the log-prior is
# -Inf and both paths collapse to the shared -1e30 sentinel (`.sb_logpost`
# returns c(-1e30, NA, NA) -> `.LogPost` sums to -1e30 with na.rm; compute_logpost
# returns {-1e30,0,0,0} -> summed to -1e30).
#
# The out-of-support value MUST remain age-conversion-valid. `.sb_eval_logpost`
# runs age_convert_and_validate BEFORE evaluating the prior: an out-of-support
# value that ALSO breaks age conversion makes the engine return -Inf (age-fail)
# instead of the -1e30 prior sentinel, which is a *different*, legitimate
# rejection path — not the prior short-circuit under test here. We therefore use
# a narrow Uniform prior on a gammaLog parameter and a value just outside it
# (0.6 in [-0.5, 0.5]): out of support, but a mild sed-rate that age conversion
# still accepts.

test_that("-Inf prior short-circuit yields the -1e30 sentinel in both engines", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # gammaLog is the 3rd parameter of stratModel1 (alpha, alpha, gammaLog, ...).
  gamma_nm <- names(stratModel1$priors$metro)[3]
  sModel <- rebuild_model(
    stratData1, stratModel1, knotRange = c(-5, 12),
    prior_overrides = setNames(list(UniformPrior(min = -0.5, max = 0.5)), gamma_nm)
  )
  setup <- equiv_setup(stratData1, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  st <- setup$state[[1]]
  st$metro$parameters[3] <- 0.6  # outside [-0.5, 0.5] but age-conversion-valid

  r_comp  <- StratoBayes:::.LogPost(setup$data, setup$model, st)
  r_total <- sum(r_comp, na.rm = TRUE)
  cpp <- StratoBayes:::.sb_eval_logpost(setup$engine, 1L,
                                        st$metro$parameters, debug = TRUE)

  # Engine reached the prior short-circuit (age conversion succeeded).
  expect_true(isTRUE(cpp$ok))
  # Both paths agree on the shared sentinel value.
  expect_equal(r_total, -1e30)
  expect_equal(cpp$logPost, -1e30)
  expect_equal(cpp$logPostSep[1], -1e30)
})


# ── Deep-tail TruncNormal: shared helper is accurate AND value-identical (RT-274)
# The truncated-normal normalisation is the one place the two C++ log-posterior
# paths ever used different code, and the deep tail is where it is hardest: for
# bounds many sigma into a tail, log(Phi(zU) - Phi(zL)) must be formed in log
# space. RT-274's DEFINITIVE FIX routes BOTH paths through the single shared
# helper ThreadRNG::log_diff_pnorm_std (accurate log(0.5*erfc(-z/sqrt2)) down to
# z ~ -37, then a 4-term Mills asymptotic below), replacing:
#
#   * the engine's OLD 2-term Mills asymptotic cut in at z < -6 (wrong by up to
#     ~1e-3 in log Phi across -37 < z < -6), and
#   * LogPost.cpp's duplicated inline R::pnorm 3-branch (accurate, but a second
#     copy, and R::pnorm is not thread-safe so the engine could never share it).
#
# An earlier version of this test *characterised* the resulting ~1.1e-4
# divergence. That divergence is gone; this test now pins three properties that
# replace it:
#
#   (1) ACCURACY, C++ engine (vs an independent R reference, ~1e-8): the shared
#       helper must match R's full-precision, log-space pnorm(..., log.p = TRUE)
#       — the property RT-274's deep tail actually violated. The reference is
#       built from log-space pnorm, NOT the naive pnorm(zU) - pnorm(zL) (which
#       itself loses tail precision and would make the reference inaccurate).
#   (2) ACCURACY, R engine (vs the SAME reference, ~1e-8): anchors the
#       LogPost.cpp path to the oracle INDEPENDENTLY, so neither engine relies on
#       the other for its correctness. (Without this, only the C++ path is pinned
#       to the reference and the R path's correctness rests on (3) alone.)
#   (3) DE-DUPLICATION INVARIANT (tight, ~1e-12): the two paths must be
#       value-identical because both now call the one shared helper. Fails iff a
#       second implementation is re-introduced (e.g. LogPost.cpp reverting to its
#       own R::pnorm branch). Post-unification this is no longer a correctness
#       check — (1) and (2) are — but a tripwire against re-divergence.
#
# The 1e-8 tolerance (not machine-tight) absorbs any platform-libm erfc delta
# while still catching the ~1e-3..1e-4 class of bug RT-274 was. Cases span the
# erfc band (z ~ -7 .. -15) and cross the erfc -> asymptotic branch switch at
# z ~ -37; the deep tail is reached by offsetting the MEAN (which does not affect
# age conversion) far from the age-conversion-valid parameter value alpha = 0.

# Independent full-precision R reference for a TruncNormal log-prior density.
# logC uses R's log-space pnorm so the reference stays accurate deep in the tail.
r_truncnorm_logprior_ref <- function(x, mean, sd, lower, upper) {
  zL <- (lower - mean) / sd
  zU <- (upper - mean) / sd
  logN <- dnorm(x, mean, sd, log = TRUE)
  logC <- if (zU < 0) {
    lpL <- pnorm(zL, log.p = TRUE); lpU <- pnorm(zU, log.p = TRUE)
    lpU + log1p(-exp(lpL - lpU))
  } else if (zL > 0) {
    lsL <- pnorm(zL, lower.tail = FALSE, log.p = TRUE)
    lsU <- pnorm(zU, lower.tail = FALSE, log.p = TRUE)
    lsL + log1p(-exp(lsU - lsL))
  } else {
    log(pnorm(zU) - pnorm(zL))
  }
  logN - logC
}

# Independent R reference for the WHOLE log-prior (logPostSep[1] sums over every
# parameter, not just the overridden TruncNormal one). Non-truncated families are
# computed with base R densities and match the C++ paths to machine precision, so
# any 1e-8-scale discrepancy isolates a TruncNormal normalisation error.
r_full_logprior_ref <- function(priorTypes, priorArgs, params) {
  total <- 0
  for (p in seq_along(params)) {
    a <- priorArgs[[p]]; x <- params[p]
    lp <- switch(priorTypes[p],
      "UniformPrior"     = if (x < a$min || x > a$max) -Inf else -log(a$max - a$min),
      "NormalPrior"      = dnorm(x, a$mean, a$sd, log = TRUE),
      "TruncNormalPrior" = r_truncnorm_logprior_ref(x, a$mean, a$sd, a$lower, a$upper),
      "Fixed"            = 0,
      stop("r_full_logprior_ref: unhandled prior type ", priorTypes[p]))
    total <- total + lp
  }
  unname(total)  # params is a named vector; drop the inherited name
}

test_that("deep-tail TruncNormal: shared helper is accurate and value-identical (RT-274)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  alpha_nm <- names(stratModel1$priors$metro)[1]

  # x = 0 throughout; z-scores at the bounds shown per case.
  cases <- list(
    list(mean =  8, sd = 1, lo = -1, up = 1),  # z in [-9, -7]    erfc band
    list(mean = 14, sd = 1, lo = -1, up = 1),  # z in [-15, -13]  erfc band, deeper
    list(mean = 38, sd = 1, lo = -1, up = 1)   # z in [-39, -37]  asymptotic branch
  )

  for (cfg in cases) {
    zL <- (cfg$lo - cfg$mean) / cfg$sd; zU <- (cfg$up - cfg$mean) / cfg$sd
    tag <- sprintf("TruncNormal(mean=%g) z in [%.0f, %.0f]", cfg$mean, zL, zU)

    sModel <- rebuild_model(
      stratData1, stratModel1, knotRange = c(-5, 12),
      prior_overrides = setNames(
        list(TruncNormalPrior(mean = cfg$mean, sd = cfg$sd,
                              lower = cfg$lo, upper = cfg$up)),
        alpha_nm)
    )
    setup <- equiv_setup(stratData1, sModel)

    st <- setup$state[[1]]
    st$metro$parameters[1] <- 0  # in-support and age-conversion-valid

    r_comp <- StratoBayes:::.LogPost(setup$data, setup$model, st)
    cpp <- StratoBayes:::.sb_eval_logpost(setup$engine, 1L,
                                          st$metro$parameters, debug = TRUE)
    expect_true(isTRUE(cpp$ok), info = tag)

    r_prior   <- r_comp[1]
    cpp_prior <- cpp$logPostSep[1]
    ref_prior <- r_full_logprior_ref(setup$model$.logpost_cpp$priorTypes,
                                     setup$model$.logpost_cpp$priorArgs,
                                     st$metro$parameters)
    expect_true(is.finite(r_prior) && is.finite(cpp_prior) && is.finite(ref_prior),
                info = tag)

    # (1) accuracy, C++ path: shared helper matches full-precision R (RT-274's
    #     deep tail violated this by ~1.1e-4 with the old 2-term Mills).
    expect_equal(cpp_prior, ref_prior, tolerance = 1e-8,
      info = sprintf("%s C++ vs R ref: cpp=%.12g ref=%.12g d=%.3e",
                     tag, cpp_prior, ref_prior, abs(cpp_prior - ref_prior)))
    # (2) accuracy, R path: anchor LogPost.cpp to the SAME oracle independently,
    #     so neither engine relies on the other for its correctness.
    expect_equal(r_prior, ref_prior, tolerance = 1e-8,
      info = sprintf("%s R-engine vs R ref: r=%.12g ref=%.12g d=%.3e",
                     tag, r_prior, ref_prior, abs(r_prior - ref_prior)))
    # (3) de-duplication invariant: both C++ paths now call the one shared
    #     helper, so they must be value-identical. Fails iff a second
    #     implementation is re-introduced (not a correctness check post-fix).
    expect_equal(cpp_prior, r_prior, tolerance = 1e-12,
      info = sprintf("%s de-dup invariant: R=%.12g cpp=%.12g", tag, r_prior, cpp_prior))

    unlink(setup$td, recursive = TRUE)
  }
})
