# Tests for C++ proposal functions (Propose.cpp)

test_that("sb_prior_sample matches R for standard prior types", {
  priorTypes <- c("UniformPrior", "NormalPrior", "LogNormalPrior",
                   "ExponentialPrior", "Fixed")
  priorArgs <- list(
    list(min = 0, max = 10),
    list(mean = 5, sd = 2),
    list(0.5, 0.3),
    list(rate = 0.1),
    list(value = 42)
  )
  rCustomFns <- list()

  for (seed in c(1001, 2002, 3003)) {
    set.seed(seed)
    cpp <- .sb_prior_sample(priorTypes, priorArgs, rCustomFns)

    # Reconstruct R samples
    priors_R <- list(
      UniformPrior(0, 10),
      NormalPrior(5, 2),
      LogNormalPrior(0.5, 0.3),
      ExponentialPrior(0.1),
      Fixed(42)
    )
    set.seed(seed)
    r_out <- vapply(priors_R, function(pr) {
      do.call(pr[["R"]], c(n = 1, pr[["args"]]))
    }, numeric(1))

    expect_equal(as.numeric(cpp), r_out,
                 tolerance = 1e-14,
                 info = paste("seed =", seed))
  }
})

test_that("sb_prior_sample Fixed type always returns the value", {
  priorTypes <- c("Fixed", "Fixed", "Fixed")
  priorArgs <- list(list(value = 1.5), list(value = -3.0), list(value = 0.0))
  rCustomFns <- list()

  result <- .sb_prior_sample(priorTypes, priorArgs, rCustomFns)
  expect_equal(as.numeric(result), c(1.5, -3.0, 0.0))
})

test_that("sb_propose_univariate matches R bit-for-bit (bactrianM = 0)", {
  # With bactrianM = 0, Bactrian falls back to standard Gaussian
  params <- c(1, 2, 3, 4, 5)
  proposeArg <- c(0.1, 0.2, 0.3, 0.4, 0.5)
  factor <- 1.5
  notFixed <- c(1L, 2L, 4L)

  for (seed in c(4004, 5005, 6006)) {
    set.seed(seed)
    cpp <- .sb_propose_univariate(params, proposeArg, factor, notFixed, 5L,
                                   bactrianM = 0)

    set.seed(seed)
    zeroOne <- as.numeric(1:5 %in% notFixed)
    r_out <- params + zeroOne * rnorm(5, 0, factor * proposeArg)

    expect_equal(as.numeric(cpp), r_out, tolerance = 1e-14,
                 info = paste("seed =", seed))
  }
})

test_that("sb_propose_univariate Bactrian kernel has expected bimodal shape", {
  # With bactrianM = 0.95, draws should avoid near-zero values
  params <- rep(0, 3)
  proposeArg <- rep(1, 3)
  notFixed <- 1:3

  set.seed(8294)
  draws <- replicate(2000, {
    .sb_propose_univariate(params, proposeArg, 1.0, notFixed, 3L,
                            bactrianM = 0.95)
  })
  # Each row is a parameter; perturbations should have bimodal shape
  deltas <- draws[1, ]
  # Near-zero density should be low: few draws near zero relative to |m| = 0.95
  near_zero <- mean(abs(deltas) < 0.2)
  expect_lt(near_zero, 0.15)
})

test_that("sb_propose_univariate leaves fixed params unchanged", {
  params <- c(10, 20, 30, 40, 50)
  notFixed <- c(2L, 4L)
  result <- .sb_propose_univariate(params, rep(1, 5), 1.0, notFixed, 5L)
  expect_equal(result[c(1, 3, 5)], c(10, 30, 50))
})

test_that("sb_propose_shift_alphas Bactrian kernel has bimodal shape", {
  params <- rep(0, 5)
  alphaInd <- 1:3
  alphaNotFixed <- 1:3

  set.seed(7312)
  shifts <- replicate(2000, {
    r <- .sb_propose_shift_alphas(params, 1.0, 1.0, alphaInd,
                                   alphaNotFixed, 5L, bactrianM = 0.95)
    r[1]  # all free alphas get the same shift
  })
  near_zero <- mean(abs(shifts) < 0.2)
  expect_lt(near_zero, 0.15)
})

test_that("sb_propose_shift_alphas applies shared shift to free alphas", {
  params <- c(1, 2, 3, 4, 5)
  alphaInd <- c(1L, 2L, 3L)
  alphaNotFixed <- c(1L, 3L)  # alpha at position 2 is fixed

  set.seed(7007)
  result <- .sb_propose_shift_alphas(params, 1.0, 0.5, alphaInd,
                                      alphaNotFixed, 5L)

  # Params 4, 5 (non-alpha) should be unchanged

  expect_equal(result[4:5], c(4, 5))
  # Alpha at position 2 (fixed) should be unchanged
  expect_equal(result[2], 2)
  # Free alphas should have the same shift
  shift1 <- result[1] - params[1]
  shift3 <- result[3] - params[3]
  expect_equal(shift1, shift3)
  # Shift should be non-zero
  expect_true(abs(shift1) > 0)
})

test_that("sb_propose_multivariate changes only free params", {
  params <- c(1, 2, 3, 4, 5)
  notFixed <- c(1L, 3L, 5L)
  # One cluster centered at (1, 3, 5) with identity covariance
  proposeArg <- list(list(c(1, 3, 5), diag(3)))

  result <- .sb_propose_multivariate(params, proposeArg, 1.0, 1.0, notFixed)

  # Fixed params unchanged
  expect_equal(result[c(2, 4)], c(2, 4))
  # Free params changed
  expect_false(all(result[c(1, 3, 5)] == c(1, 3, 5)))
})

test_that("sb_propose_multivariate selects nearest cluster", {
  params <- c(0, 0, 0, 0)
  notFixed <- 1:4

  # Two clusters: one at origin (tight), one far away (wide)
  clust1 <- list(c(0, 0, 0, 0), diag(4) * 0.01)  # near, tight
  clust2 <- list(c(100, 100, 100, 100), diag(4) * 100)  # far, wide

  set.seed(8008)
  results <- replicate(50, {
    .sb_propose_multivariate(params, list(clust1, clust2), 1.0,
                              2.38^2 / 4, notFixed)
  })

  # Should use cluster 1 (near) → small deviations
  max_dev <- max(abs(results))
  expect_true(max_dev < 5,
    info = paste("Expected small deviations from cluster 1; max =", max_dev))
})

test_that("sb_propose_multivariate uses standard-normal z (no Bactrian avoidance of zero)", {
  # If Bactrian were still used in z-space, each free-parameter delta would
  # avoid zero: |delta_j| ≈ 0.95 * ||L_j|| > 0 always.
  # With standard-normal z, small deltas near zero are common.
  # We verify that the distribution of per-parameter steps has density near
  # zero (i.e., small steps occur with reasonable frequency).
  params <- rep(0, 4)
  notFixed <- 1:4
  cov4 <- diag(4)  # identity covariance → L = I → delta_j = z_j ~ N(0,1)
  proposeArg <- list(list(c(0, 0, 0, 0), cov4))

  set.seed(4242)
  deltas <- replicate(2000, {
    r <- .sb_propose_multivariate(params, proposeArg, 1.0, 1.0, notFixed,
                                   bactrianM = 0.95)
    r[1]  # first free parameter
  })

  # With standard-normal z, ~38% of draws fall in (-0.5, 0.5)
  near_zero_frac <- mean(abs(deltas) < 0.5)
  # With Bactrian z and identity covariance, this fraction would be < 0.05
  expect_gt(near_zero_frac, 0.20,
            label = paste("near-zero fraction:", round(near_zero_frac, 3)))
})

test_that("sb_propose_shift_alphas_rand_joint selects random subset", {
  params <- rep(0, 10)
  alphaInd <- 1:5
  alphaNotFixed <- 1:5

  set.seed(9009)
  results <- replicate(100, {
    r <- .sb_propose_shift_alphas_rand_joint(params, 1.0, 1.0, alphaInd,
                                              alphaNotFixed, 10L)
    # Non-alpha params (6:10) should be unchanged
    expect_equal(r[6:10], rep(0, 5))
    # Modified alphas should share the same shift
    shifted <- which(r[1:5] != 0)
    if (length(shifted) > 1) {
      diffs <- diff(r[shifted])
      expect_true(all(abs(diffs) < 1e-14))
    }
    length(shifted)
  })

  # Should see varying subset sizes
  expect_true(length(unique(results)) > 1)
})

test_that("sb_propose_shift_alphas_rand_separate gives independent shifts", {
  params <- rep(0, 10)
  alphaInd <- 1:5
  alphaNotFixed <- 1:5

  set.seed(1234)
  result <- .sb_propose_shift_alphas_rand_separate(params, 1.0, 1.0, alphaInd,
                                                    alphaNotFixed, 10L)
  # Non-alpha params unchanged
  expect_equal(result[6:10], rep(0, 5))

  # If multiple alphas were shifted, they should NOT all be the same
  shifted <- result[1:5][result[1:5] != 0]
  if (length(shifted) > 1) {
    expect_false(all(shifted == shifted[1]),
      info = "Independent shifts should differ")
  }
})

test_that("sb_prior_sample truncated normal is in bounds", {
  priorTypes <- rep("TruncNormalPrior", 100)
  priorArgs <- replicate(100, list(mean = 5, sd = 3, lower = 2, upper = 8),
                          simplify = FALSE)
  rCustomFns <- list()

  result <- .sb_prior_sample(priorTypes, priorArgs, rCustomFns)
  expect_true(all(result >= 2))
  expect_true(all(result <= 8))
})

test_that("sb_prior_sample truncated lognormal is in bounds", {
  priorTypes <- rep("TruncLogNormalPrior", 100)
  priorArgs <- replicate(100, list(meanlog = 0, sdlog = 1, min = 0.5, max = 5),
                          simplify = FALSE)
  rCustomFns <- list()

  result <- .sb_prior_sample(priorTypes, priorArgs, rCustomFns)
  expect_true(all(result >= 0.5))
  expect_true(all(result <= 5))
})

# ── RT-244: deep-tail underflow in the C++ prior sampler ────────────────────
# Both bounds far into the same tail previously made pL == pU (both underflow
# to 0 / round to 1), so every draw collapsed to +/-Inf. The stable core now
# interpolates in log-probability space.

test_that("sb_prior_sample: deep-tail TruncNormalPrior is finite and in bounds", {
  priorTypes <- rep("TruncNormalPrior", 200)
  priorArgs <- replicate(200, list(mean = 0, sd = 0.01, lower = 1, upper = 2),
                          simplify = FALSE)
  result <- .sb_prior_sample(priorTypes, priorArgs, list())
  expect_true(all(is.finite(result)))
  expect_true(all(result >= 1 & result <= 2))
})

test_that("sb_prior_sample: deep left-tail TruncNormalPrior is finite/in bounds", {
  priorTypes <- rep("TruncNormalPrior", 200)
  priorArgs <- replicate(200, list(mean = 0, sd = 0.01, lower = -2, upper = -1),
                          simplify = FALSE)
  result <- .sb_prior_sample(priorTypes, priorArgs, list())
  expect_true(all(is.finite(result)))
  expect_true(all(result >= -2 & result <= -1))
})

test_that("sb_prior_sample: deep-tail TruncLogNormalPrior is finite/in bounds", {
  priorTypes <- rep("TruncLogNormalPrior", 200)
  priorArgs <- replicate(200,
                         list(meanlog = 0, sdlog = 0.1, min = 5, max = 6),
                         simplify = FALSE)
  result <- .sb_prior_sample(priorTypes, priorArgs, list())
  expect_true(all(is.finite(result)))
  expect_true(all(result >= 5 & result <= 6))
})

test_that("sb_prior_sample: TruncLogNormalPrior with min = 0 is finite/in bounds", {
  # min = 0 => log(0) = -Inf lower bound; exercises the -Inf branch of the core.
  priorTypes <- rep("TruncLogNormalPrior", 200)
  priorArgs <- replicate(200, list(meanlog = 0, sdlog = 1, min = 0, max = 3),
                          simplify = FALSE)
  result <- .sb_prior_sample(priorTypes, priorArgs, list())
  expect_true(all(is.finite(result)))
  expect_true(all(result >= 0 & result <= 3))
})

test_that("sb_prior_sample: non-degenerate truncated draw is RNG-aligned with R", {
  # The stable core consumes exactly one uniform deviate (runif(0,1)); this pins
  # RNG-stream alignment with the R sampler. Post RT-244 unification the core is
  # Acklam + a Halley polish rather than a bit-for-bit R::qnorm reimplementation,
  # so the mean-straddling draw matches R's qnorm to ~machine precision (~1e-14)
  # rather than identically — comfortably within the 1e-12 tolerance below.
  priorTypes <- "TruncNormalPrior"
  priorArgs <- list(list(mean = 5, sd = 3, lower = 2, upper = 8))
  set.seed(9151)
  cpp <- as.numeric(.sb_prior_sample(priorTypes, priorArgs, list()))
  set.seed(9151)
  u <- runif(1)
  pL <- pnorm((2 - 5) / 3); pU <- pnorm((8 - 5) / 3)
  r_ref <- 5 + 3 * qnorm(pL + u * (pU - pL))
  expect_equal(cpp, r_ref, tolerance = 1e-12)
})
