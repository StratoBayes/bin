test_that("summary.StratPosterior works with single cluster", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior1))
})

test_that("print.summary.StratPosterior works with change sigDigits", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(summary(stratPosterior1), sigDigits = 2))
})

test_that("summary.StratPosterior works with two clusters", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2))
})

test_that("summary.StratPosterior works with no burn-in", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, burnIn = 0))
})

test_that("summary.StratPosterior works with iteration burn-in", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior1, burnIn = 4900))
})

test_that("summary.StratPosterior works with iterations", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, iterations = 500:800))
})

test_that("summary.StratPosterior works with unassigned iterations", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, iterations = 1:100, runs = 4))
})

test_that("summary.StratPosterior works with alignment 2", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, alignment = 2))
})

test_that("summary.StratPosterior works with no clusters (all it)", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    summary.StratPosterior(stratPosterior2, alignment = "none")
  )
})

test_that("summary.StratPosterior works with new cluster object and many clusters", {
  skip_if_not_snapshot_os()
  clustNew <- Cluster(stratPosterior1, clusterMethod = "hdbscan")

  expect_snapshot(
    summary.StratPosterior(stratPosterior1, alignment = "all",
                           stratCluster = clustNew)
  )
})


test_that("summary.StratPosterior works with new cluster object and iterations before burnIn", {
  skip_if_not_snapshot_os()
  clustNew <- Cluster(stratPosterior1, iterations = 100)

  expect_snapshot(
    summary.StratPosterior(stratPosterior1,
                           stratCluster = clustNew)
  )

})

test_that("summary.StratPosterior works with new cluster object and iterations before burnIn - alignment none", {
            skip_if_not_snapshot_os()
            clustNew <- Cluster(stratPosterior1, iterations = 100)

            expect_snapshot(
              summary.StratPosterior(stratPosterior1, alignment = "none",
                                     stratCluster = clustNew)
            )


          })

# hit NA line in .RoundToSigDigits
test_that(".RoundToSigDigits deals with NA", {
expect_equal(.RoundToSigDigits(NA)[[1]], "NA")
})

test_that("summary.StratPosterior includes sigma rows when sigma is estimated (RT-180)", {
  # stratPosterior3 has an estimated sigma_value column in object[["samples"]];
  # the containsSigma lookup previously always failed due to a paste() sep
  # mismatch ("sigma value" vs "sigma_value"), so sigma was silently omitted.
  s <- summary(stratPosterior3)
  expect_true("sigma_value" %in% rownames(s[[1]][["summary"]]))
})

test_that("summary.StratPosterior reports correct per-run sample count for a run subset (RT-117)", {
  # Previously nSamplesUsedPerRun used the full-length (nRun) lengths(selectRows)
  # vector unindexed, so summary(..., runs = 2) reported 0 samples for run 2
  # (the count for unselected run 1 instead).
  s <- summary(stratPosterior2, runs = 2)
  expect_equal(s[["general"]][["nSamplesUsedPerRun"]], 100)
  expect_length(s[["general"]][["nSamplesUsedPerRun"]], 1)
})
