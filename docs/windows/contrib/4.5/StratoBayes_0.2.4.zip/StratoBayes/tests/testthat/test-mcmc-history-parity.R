# Regression tests for MCMC history / covariance-adaptation internals.
#
# RT-224: .BulkSaveMCMChistory (C++-engine bulk path) must apply the same
#   duplicate filter as .SaveMCMChistory (R-engine single-iteration path), so
#   rejected/duplicate states are not injected into chainHistory (which feeds
#   the Multivariate adaptive-proposal covariance).
#
# RT-223: .UpdateMCMCforContinuedRun must transfer the *chronologically most
#   recent* acceptance entries when a continued run shrinks acceptanceLength,
#   not an arbitrary positional slice of the raw ring buffer.

# ---- shared minimal fixture helpers -----------------------------------------

# Minimal model exercising the clustWithParametersMCMC = TRUE path (heights are
# zero-length, so a history row is just c(parameters, logPost)).
.make_model <- function(parametersLength) {
  list(
    heightsForClustering = list(),
    siteIndices = integer(0),
    parametersLength = parametersLength
  )
}

# Fresh metro with an empty history/acceptance buffer.
.make_metro <- function(parametersLength, historyLength, acceptanceLength,
                        nProposals = 1L, enableRingBuffer = TRUE) {
  ncolHist <- parametersLength + 1L  # + logPost (no heights)
  list(
    historyLength = historyLength,
    acceptanceLength = acceptanceLength,
    clustWithParametersMCMC = TRUE,
    enableRingBuffer = enableRingBuffer,
    historySize = 0L,
    historyRingPos = 1L,
    chainHistory = list(matrix(0, nrow = historyLength, ncol = ncolHist)),
    acceptance = array(NA_real_, dim = c(1L, acceptanceLength, nProposals)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = nProposals)
  )
}

test_that("RT-224: bulk save filters duplicates identically to per-iteration save", {
  parametersLength <- 2L
  model <- .make_model(parametersLength)

  # State sequence with two rejected (duplicate) iterations: 3 and 5 repeat the
  # immediately-preceding accepted state, exactly as a rejected MH step does.
  params <- rbind(
    c(1, 1),   # 1 accepted -> stored
    c(2, 2),   # 2 accepted -> stored
    c(2, 2),   # 3 rejected -> duplicate of 2, must be dropped
    c(3, 3),   # 4 accepted -> stored
    c(3, 3)    # 5 rejected -> duplicate of 4, must be dropped
  )
  logPost <- c(-10, -9, -9, -8, -8)
  accept  <- c(TRUE, TRUE, FALSE, TRUE, FALSE)
  propNum <- rep(1L, 5)
  n <- nrow(params)

  # --- R engine: one .SaveMCMChistory call per iteration ---
  mcmcR <- list(
    temper = list(temperatures = 1),
    metro = .make_metro(parametersLength, historyLength = 20L,
                        acceptanceLength = 10L)
  )
  for (k in seq_len(n)) {
    state <- list(list(metro = list(
      parameters = params[k, ],
      logPost = logPost[k],
      accept = accept[k],
      proposalNumber = propNum[k]
    )))
    mcmcR[["metro"]] <- .SaveMCMChistory(data = NULL, model = model,
                                         mcmc = mcmcR, state = state,
                                         inLateAdaptation = FALSE)
  }

  # --- C++ engine: one .BulkSaveMCMChistory call for the whole block ---
  mcmcB <- list(
    temper = list(temperatures = 1),
    metro = .make_metro(parametersLength, historyLength = 20L,
                        acceptanceLength = 10L)
  )
  historyData <- list(list(
    count = n,
    parameters = params,
    logPost = logPost,
    accept = accept,
    proposalNumber = propNum
  ))
  mcmcB[["metro"]] <- .BulkSaveMCMChistory(model = model, mcmc = mcmcB,
                                           historyData = historyData,
                                           inLateAdaptation = FALSE)

  # Only 3 unique states should have been stored (2 rejections dropped).
  expect_equal(mcmcB[["metro"]][["historySize"]], 3L)

  # Engine parity: bulk path matches per-iteration path exactly.
  expect_identical(mcmcB[["metro"]][["chainHistory"]],
                   mcmcR[["metro"]][["chainHistory"]])
  expect_identical(mcmcB[["metro"]][["historySize"]],
                   mcmcR[["metro"]][["historySize"]])
  expect_identical(mcmcB[["metro"]][["historyRingPos"]],
                   mcmcR[["metro"]][["historyRingPos"]])
  # Acceptance tracking stays unconditional (all 5 iterations recorded).
  expect_identical(mcmcB[["metro"]][["acceptance"]],
                   mcmcR[["metro"]][["acceptance"]])
  expect_identical(mcmcB[["metro"]][["acceptanceIndex"]],
                   mcmcR[["metro"]][["acceptanceIndex"]])

  # The stored rows are exactly the three distinct states.
  stored <- mcmcB[["metro"]][["chainHistory"]][[1]][seq_len(3L), , drop = FALSE]
  expect_equal(stored, rbind(c(1, 1, -10), c(2, 2, -9), c(3, 3, -8)),
               ignore_attr = TRUE)
})

test_that("RT-223: acceptance transfer keeps most-recent entries when length shrinks", {
  # Old run: full, wrapped acceptance ring of length 25, next-write = 13.
  oldAcceptanceLength <- 25L
  newAcceptanceLength <- 10L
  # Trace value = physical row index, so chronology is easy to verify.
  oldAcc <- array(as.numeric(seq_len(oldAcceptanceLength)),
                  dim = c(1L, oldAcceptanceLength, 1L))
  nextWrite <- 13L

  histLen <- 25L
  ncolHist <- 3L  # 2 params + logPost

  mcmc <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      historyLength = histLen,
      acceptanceLength = oldAcceptanceLength,
      historySize = 0L,          # keep history transfer trivial / out of scope
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = oldAcc,
      acceptanceIndex = matrix(nextWrite, nrow = 1L, ncol = 1L)
    )
  )

  mcmcNew <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      adaptProposal = TRUE,
      historyLength = histLen,
      acceptanceLength = newAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = array(NA_real_, dim = c(1L, newAcceptanceLength, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    ),
    recentState = NULL
  )

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  # Chronological order (oldest->newest) with next-write = 13 is physical rows
  # 13,14,...,25,1,...,12; the most recent 10 are physical rows 3..12.
  expect_equal(as.numeric(out[[c("metro", "acceptance")]][1, , 1]),
               as.numeric(3:12))
  # Buffer is now exactly full -> next write wraps to 1.
  expect_identical(out[[c("metro", "acceptanceIndex")]][1, 1], 1L)

  # Guard against the old bug: a raw positional slice would have copied physical
  # rows 16:25 and set the index to (13-1) %% 10 + 1 = 3.
  expect_false(isTRUE(all.equal(
    as.numeric(out[[c("metro", "acceptance")]][1, , 1]), as.numeric(16:25))))
})

test_that("RT-223: acceptance transfer is unchanged when length grows or is equal", {
  # Growing acceptanceLength must preserve the safe pre-existing behaviour:
  # verbatim physical copy + index remap.
  oldAcceptanceLength <- 10L
  newAcceptanceLength <- 25L
  oldAcc <- array(as.numeric(seq_len(oldAcceptanceLength)),
                  dim = c(1L, oldAcceptanceLength, 1L))
  nextWrite <- 4L
  histLen <- 25L
  ncolHist <- 3L

  mcmc <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      historyLength = histLen,
      acceptanceLength = oldAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = oldAcc,
      acceptanceIndex = matrix(nextWrite, nrow = 1L, ncol = 1L)
    )
  )
  mcmcNew <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      adaptProposal = TRUE,
      historyLength = histLen,
      acceptanceLength = newAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = array(NA_real_, dim = c(1L, newAcceptanceLength, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    ),
    recentState = NULL
  )

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  # Physical rows copied verbatim into rows 1:oldAcceptanceLength.
  expect_equal(as.numeric(out[[c("metro", "acceptance")]][1, 1:oldAcceptanceLength, 1]),
               as.numeric(1:oldAcceptanceLength))
  # Remaining rows stay NA.
  expect_true(all(is.na(
    out[[c("metro", "acceptance")]][1, (oldAcceptanceLength + 1L):newAcceptanceLength, 1])))
  # Index remapped as (oldIndex - 1) %% newLen + 1 = 4 (legacy path returns a
  # double, unchanged by this fix -> compare by value).
  expect_equal(out[[c("metro", "acceptanceIndex")]][1, 1], 4)
})
