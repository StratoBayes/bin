# Tests for RT-132: .ClusterCovariancesAreDegenerate was defined but never
# wired into .UpdateProposal's Multivariate branch (R/mcmcFunctions.R).
#
# Root cause: Haario regularization (0.001 * avgDiag * I) keeps a cluster
# covariance positive-definite but does not bound its condition number.  A
# cluster of near-collinear samples can therefore produce a PD covariance
# with a huge condition number, which slips straight into the Multivariate
# proposer's Cholesky factorization and yields near-zero acceptance.
#
# Fix: call .ClusterCovariancesAreDegenerate on the covariances returned by
# .ClustInfo before assigning them to proposalArgs; on degeneracy, fall back
# to inheriting a hotter chain's (T-scaled) covariance, or mark
# proposalValid[chain, "Multivariate"] <- FALSE if no valid hotter chain
# exists — mirroring the existing NULL-ClustInfo fallback in the same branch.

.ns <- loadNamespace("StratoBayes")

test_that(".ClusterCovariancesAreDegenerate flags a near-collinear cluster covariance", {
  isDegenerate <- get(".ClusterCovariancesAreDegenerate", envir = .ns)

  # Near-collinear samples: second column is the first plus tiny noise, so
  # the empirical covariance is PD but has a huge condition number.
  set.seed(1)
  nFree <- 2L
  x <- rnorm(20)
  degenerateCov <- cov(cbind(x, x + rnorm(20, sd = 1e-9)))
  clustInfoDegenerate <- list(list(rep(0, nFree), degenerateCov))

  expect_true(isDegenerate(clustInfoDegenerate))
})

test_that(".ClusterCovariancesAreDegenerate accepts a well-conditioned covariance", {
  isDegenerate <- get(".ClusterCovariancesAreDegenerate", envir = .ns)

  wellConditioned <- list(list(c(0, 0), diag(2)))
  expect_false(isDegenerate(wellConditioned))
})

# ─── Helper: minimal 2-chain mcmc mock with enough unique history rows to ───
# ─── take the clustering path (not the < 3 unique rows fallback) ───────────
.rt132_make_mcmc <- function(hotCov, T_cold = 1.0, T_hot = 4.0,
                             hotValid = TRUE, nFree = 2L) {
  histLen <- 50L
  mk_hist <- function(n) matrix(rnorm(n * (nFree + 1L)), n, nFree + 1L)

  list(
    nChains     = 2L,
    currentIter = 10L,
    endAdapting = 100L,
    startAdapting = 1L,
    propose     = setNames(vector("list", 1L), "Multivariate"),
    temper      = list(temperatures = c(T_cold, T_hot, NA_real_),
                       tempering    = TRUE),
    metro       = list(
      historySize              = c(10L, 10L),
      historyLength            = histLen,
      historyRingPos           = c(1L, 1L),
      enableRingBuffer         = FALSE,
      clustWithParametersMCMC  = TRUE,
      clustMethodMCMC          = "proto",
      clustMaxMCMC             = 5L,
      clustMinPtsMCMC          = 5L,
      nProposals               = c(1L, 1L),
      proposalValid            = matrix(
        c(FALSE, hotValid), nrow = 2L, ncol = 1L,
        dimnames = list(NULL, "Multivariate")),
      proposalProbability      = matrix(
        c(0, 0.5), nrow = 2L, ncol = 1L,
        dimnames = list(NULL, "Multivariate")),
      proposalArgs = list(
        chain1 = list(Multivariate = NULL),
        chain2 = list(Multivariate = list(
          list(rep(0, nFree), hotCov)
        ))
      ),
      adaptProposal = c(TRUE, TRUE),
      chainHistory  = list(mk_hist(10L), mk_hist(10L))
    )
  )
}

.rt132_make_model <- function(nFree) {
  list(
    parametersLength         = nFree,
    parametersLengthNotFixed = nFree,
    ind = list(paramNotFixed = seq_len(nFree))
  )
}

test_that(".UpdateProposal falls back to hotter chain when cluster covariance is degenerate", {
  skip_if_not(
    exists(".UpdateProposal", envir = .ns, mode = "function"),
    ".UpdateProposal not in namespace"
  )
  upd <- get(".UpdateProposal", envir = .ns)

  nFree <- 2L
  set.seed(444)
  x <- rnorm(20)
  degenerateCov <- cov(cbind(x, x + rnorm(20, sd = 1e-9)))
  degenerateClustInfo <- list(list(rep(0, nFree), degenerateCov))

  T_cold <- 1.0; T_hot <- 4.0
  hotCov <- diag(nFree) * T_hot

  testthat::local_mocked_bindings(
    .ClustInfo = function(...) degenerateClustInfo,
    .package = "StratoBayes"
  )

  mcmc  <- .rt132_make_mcmc(hotCov, T_cold, T_hot, hotValid = TRUE, nFree = nFree)
  model <- .rt132_make_model(nFree)

  result_metro <- upd(data = list(), model = model, mcmc = mcmc,
                      chain = 1L, inLateAdaptation = FALSE)

  inherited <- result_metro[["proposalArgs"]][["chain1"]][["Multivariate"]][[1L]][[2L]]

  # The degenerate covariance must NOT have been used directly.
  expect_false(isTRUE(all.equal(inherited, degenerateCov)))

  # Instead chain 1 should have inherited chain 2's covariance, T-scaled.
  expect_equal(inherited, hotCov * (T_cold / T_hot), tolerance = 1e-12)
  expect_true(result_metro[["proposalValid"]][1L, "Multivariate"])
})

test_that(".UpdateProposal marks Multivariate invalid when covariance is degenerate and no hotter chain is available", {
  skip_if_not(
    exists(".UpdateProposal", envir = .ns, mode = "function"),
    ".UpdateProposal not in namespace"
  )
  upd <- get(".UpdateProposal", envir = .ns)

  nFree <- 2L
  set.seed(555)
  x <- rnorm(20)
  degenerateCov <- cov(cbind(x, x + rnorm(20, sd = 1e-9)))
  degenerateClustInfo <- list(list(rep(0, nFree), degenerateCov))

  testthat::local_mocked_bindings(
    .ClustInfo = function(...) degenerateClustInfo,
    .package = "StratoBayes"
  )

  # hotValid = FALSE: the hotter chain has no valid Multivariate proposal
  # either, so chain 1 has nothing safe to inherit.
  mcmc  <- .rt132_make_mcmc(diag(nFree), hotValid = FALSE, nFree = nFree)
  model <- .rt132_make_model(nFree)

  result_metro <- upd(data = list(), model = model, mcmc = mcmc,
                      chain = 1L, inLateAdaptation = FALSE)

  expect_false(result_metro[["proposalValid"]][1L, "Multivariate"])
})
