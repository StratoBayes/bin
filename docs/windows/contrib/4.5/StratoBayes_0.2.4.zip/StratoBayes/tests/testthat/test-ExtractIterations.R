test_that("ExtractIterations works", {

  # errors
  expect_error(ExtractIterations(stratPosterior1, runs = 4),
               "runSelect needs")
  expect_error(ExtractIterations(stratPosterior1, burnIn = -1),
               "burnIn must")
  # trigger edge case were last iterations are not saved
  stratPosterior1modified <- stratPosterior1
  stratPosterior1modified$mcmcSummary$saveIter[[1]] <- stratPosterior1modified[[c("mcmcSummary", "saveIter")]][[1]][-201]
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 4999, runs = 1),
               "all iterations were discarded")
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 0.999),
               "all iterations were discarded")
  # burnIn
  iter <- ExtractIterations(stratPosterior1, burnIn = 0.9999)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, burnIn = 1)
  expect_equal(sapply(iter,length),
               rep(length(stratPosterior1[[c("mcmcSummary", "saveIter")]][[1]]) - 1,3))

  # iterations
  iter <- ExtractIterations(stratPosterior1, iterations = 25)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, iterations = 1:100)
  expect_equal(sapply(iter,length), c(5,5,5))
  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, 1))
  expect_equal(sapply(iter,length), c(5,3,1))

  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, NULL))
  expect_equal(sapply(iter,length), c(5,3,0))

  # runSelect
  iter <- ExtractIterations(stratPosterior1, iterations = 25,
                             runs = c(1,3))
  expect_equal(sapply(iter,length), c(1,0,1))

  # cut iterations to maxSamples
  iter <- ExtractIterations(stratPosterior1, iterations = 1:1000,
                             maxSamples = 5)
  expect_equal(sum(sapply(iter,length)), 5)

  # alignment
  iter <- ExtractIterations(stratPosterior2, alignment = 0:2)
  expect_equal(sapply(iter,length), rep(100, 4), tolerance = 0.1)

  iter <- ExtractIterations(stratPosterior2, alignment = 1, iterations = 100:200)
  iterN <- sum(sapply(iter,length))
  expect_true(iterN >= 1 && iterN <= 12)

  clustNew <- Cluster(stratPosterior1, runs = 2:3, iterations = 3900:4000)
  expect_true(any(
    ExtractIterations(stratPosterior1, alignment = 1, stratCluster = clustNew, burnIn = 0.95)[[2]]
    %in% 157:161))
  expect_equal(
    ExtractIterations(stratPosterior1, alignment = "all", stratCluster = clustNew, burnIn = 0.95)[[2]],
    192:201)
})

# The shipped data fixtures predate the lazy `.cache` environment, so they
# carry `.cache = NULL` and a precomputed `stratCluster` element. Real objects
# from the StratPosterior constructor always have a `.cache` env; we attach one
# here to exercise the memoisation path the way a live object would. samples
# <= maxClusterSamples, so proto clustering is deterministic.
.WithClusterCache <- function(stratPosterior) {
  ce <- new.env(parent = emptyenv())
  ce$stratCluster <- .subset2(stratPosterior, "stratCluster")
  ce$summary <- NULL
  ce$clusterCache <- list()
  stratPosterior[[".cache"]] <- ce
  stratPosterior
}

test_that(".ClusterInternal memoises clustering on the object's .cache", {
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]
  runSelect <- seq_len(nRun)
  sr <- ExtractIterations(sp, "all", burnIn = 0.9, NULL, 2000, runSelect)

  cached <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, sr)
  # entry was stored on the object's cache
  expect_length(ce$clusterCache, 1)

  # cached result matches a fresh computation with the same inputs (compare the
  # meaningful components; a non-deterministic fastmatch .match.hash attribute
  # on $options$runSelect makes whole-object identity comparison unreliable)
  direct <- Cluster.StratPosterior(sp, burnIn = 0.9, iterations = NULL,
                                   maxSamples = 2000, runs = runSelect, selectRows = sr)
  expect_equal(cached[["cluster"]], direct[["cluster"]])
  expect_equal(cached[["rowIndex"]], direct[["rowIndex"]])
  expect_equal(cached[["nClust"]], direct[["nClust"]])

  # second call with identical inputs returns the stored object (hit path)
  cached2 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, sr)
  expect_identical(cached2, cached)
  expect_length(ce$clusterCache, 1)
})

test_that(".ClusterInternal with NULL selectRows is keyed on burnIn", {
  # Regression: a NULL-selectRows cache keyed only on selectRows would serve a
  # stale clustering when burnIn changes (e.g. the GUI burn-in slider).
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]
  runSelect <- seq_len(nRun)

  cLow  <- StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2000, runSelect, NULL)
  cHigh <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, NULL)
  # different burn-in selects different rows, so the clustering must differ
  expect_false(identical(cLow[["rowIndex"]], cHigh[["rowIndex"]]))
  expect_length(ce$clusterCache, 2)

  # repeating burnIn = 0.9 hits the cache rather than recomputing
  cHigh2 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, NULL)
  expect_identical(cHigh2, cHigh)
  expect_length(ce$clusterCache, 2)
})

test_that("proportional burnIn discards the requested fraction per run regardless of nThin (RT-190)", {
  # Run A: nThin = 100 -> 10 saved rows over 1000 iterations.
  # Run B: nThin = 10  -> 100 saved rows over 1000 iterations.
  # A row-index-based burn-in (computed from the shortest run, A) applied
  # verbatim to B under-discards B's warm-up when B has more saved rows.
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(seq(100, 1000, by = 100), seq(10, 1000, by = 10)),
      completedIter = c(1000, 1000)
    )
  )

  selectRows <- ExtractIterations(fakePosterior, burnIn = 0.5, runs = "all")

  # Run A (10 rows): expect exactly the last 50% (5 rows) retained.
  expect_length(selectRows[[1]], 5)
  # Run B (100 rows): expect exactly the last 50% (50 rows) retained, not the
  # ~5% that the row-index bug produced.
  expect_length(selectRows[[2]], 50)

  # Both runs should discard iterations <= 500 (the absolute 50% threshold).
  saveIterA <- fakePosterior[[c("mcmcSummary", "saveIter")]][[1]]
  saveIterB <- fakePosterior[[c("mcmcSummary", "saveIter")]][[2]]
  expect_true(all(saveIterA[selectRows[[1]]] > 500))
  expect_true(all(saveIterB[selectRows[[2]]] > 500))
})

test_that(".ClusterInternal cache key ignores fastmatch .match.hash on runSelect", {
  # Each production plotting function builds its own runSelect, which picks up
  # a non-deterministic .match.hash from %fin%. The cache key must normalise it
  # or every cross-call lookup would miss and silently recompute.
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]
  freshRunSelect <- function() {
    rs <- seq_len(nRun)
    fastmatch::fmatch(1L, rs)        # attaches .match.hash to rs (the table)
    rs
  }
  rs1 <- freshRunSelect()
  rs2 <- freshRunSelect()
  # precondition: raw vectors are NOT identical (distinct hash tables), so an
  # un-normalised key would store two entries
  expect_false(identical(rs1, rs2))

  c1 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, rs1, NULL)
  c2 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, rs2, NULL)
  # second call HIT despite the differing attribute -> still one cache entry
  expect_length(ce$clusterCache, 1)
  expect_identical(c2, c1)
})

