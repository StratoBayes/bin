
test_that("StratMapPlot works", {
  skip_if_not_snapshot_os()
  expect_error(StratMapPlot(1, 2, 2), "stratObject must be an object of class")

  set.seed(1)
  vdiffr::expect_doppelganger("StratMapPlot 1", function() {
    StratMapPlot(stratPosterior1)
  })})

test_that("StratMapPlot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("StratMapPlot 2", function() {

    StratMapPlot(stratPosterior2, alignment = 2, sites = 3:1,
             burnIn = 0.95, tiesColour = "orange", col = rgb(0.5,0,0,1),
             lwd = 2)
  })})

test_that("StratMapPlot works on depth scale", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("StratMapPlot 3", function() {

    StratMapPlot(stratPosterior3, xlab = "depth (m) at 2")
  })})

test_that("StratMapPlot can plot prior", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("StratMapPlot 4", function() {
    set.seed(1)
    StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 100)
  })})

test_that("StratMapPlot can plot posterior and prior", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("StratMapPlot 5", function() {

    set.seed(1)
    StratMapPlot(stratPosterior2, prior = TRUE, col = 2:3, tiesColour = 4,
                 sites = 1:2, pch = 2, cex = 2, lwd = 2)
  })})


test_that("StratMapPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({StratMapPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("StratMapPlot preserves both prior and posterior in the return value", {
  png(tempfile())
  set.seed(1)
  out <- StratMapPlot(stratPosterior2, prior = TRUE, sites = 1:2)
  dev.off()

  expect_length(out, 2)
  for (site in out) {
    expect_named(site, c("prior", "posterior"))
    expect_true(is.data.frame(site$prior))
    expect_true(is.data.frame(site$posterior))
  }
})

test_that("StratMapPlot computes a finite default ylim (RT-046)", {
  # The default ylim is range(c(ages[, 4], ages[, 6])). `ages` (from StratMap)
  # is NA-initialised and only filled for heights that map into a partition, so
  # without na.rm = TRUE an NA on a partition boundary makes range() return
  # c(NA, NA) and plot() errors on non-finite ylim. Smoke test the ylim path on
  # a null device (the vdiffr tests above skip off the snapshot OS).
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  expect_error(StratMapPlot(stratPosterior1), NA)
})

test_that("StratMapPlot handles a multi-colour col vector on a ties overlay (RT-296)", {
  # `if (!is.null(stratData[["ties"]]) & !is.na(tiesColourTemp))` used `&`,
  # which evaluates and recycles both sides unconditionally. A user `col`
  # vector of length > 1 outside the priorAndPosterior branch (default
  # prior = FALSE here) leaves `tiesColourTemp` uncollapsed, making
  # `!is.na(tiesColourTemp)` a vector; with `&&` (R >= 4.2) that's a hard
  # error unless collapsed first, and this only exercises the collapse when
  # `stratData$ties` is non-NULL, since `&&` short-circuits otherwise.
  # stratPosterior2's data has ties (stratPosterior1's does not).
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  expect_error(StratMapPlot(stratPosterior2, col = c("red", "blue")), NA)
})

test_that("StratMapPlot xlab fallback uses real site names, not self-indexed sites (RT-129/RT-049)", {
  # `xlabs <- sites[sites]` self-indexed the integer site vector (e.g.
  # c(2,3)[c(2,3)] -> c(3, NA)). When the user supplies an xlab of the wrong
  # length for the requested sites, the fallback `xlabs[m]` is used, and could
  # be NA. Capture the xlab actually reaching plot.default by mocking the
  # internal `.ExtractRelevantArgs` (the last step before the plot call) --
  # NOT graphics::plot()/plot.default directly: R's generic-dispatch inline
  # cache means trace()-ing or mocking those silently stops firing the moment
  # any *other* plot() call has already run earlier in the session (as one
  # does, in the full suite), even though the real plotting keeps working.
  siteSubset <- 2:3
  siteNames <- stratPosterior2[["data"]][["sites"]][siteSubset]

  capturedXlabs <- character(0)
  originalExtract <- StratoBayes:::.ExtractRelevantArgs
  testthat::local_mocked_bindings(
    .ExtractRelevantArgs = function(args, funcName) {
      if (identical(funcName, "plot.default")) {
        capturedXlabs <<- c(capturedXlabs, args[["xlab"]])
      }
      originalExtract(args, funcName)
    },
    .package = "StratoBayes"
  )

  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  # xlab has length 1, mismatching length(sites) == 2, so the fallback is used
  # for both sites.
  StratMapPlot(stratPosterior2, sites = siteSubset, xlab = "custom")

  expect_false(anyNA(capturedXlabs))
  expect_equal(capturedXlabs, siteNames)
})
