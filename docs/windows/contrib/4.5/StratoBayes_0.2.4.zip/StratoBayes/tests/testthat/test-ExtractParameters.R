test_that("ExtractParameters works", {
  # errors
  expect_error(ExtractParameters(stratPosterior1,
                                   selectRows = list(NULL, NULL, NULL)),
                 "Parameter selection")
  expect_error(ExtractParameters(stratPosterior1,
                                   runs = 4),
                 "runSelect needs")

  # example
  params <- ExtractParameters(stratPosterior1)
  expect_s3_class(params, "data.frame")
  expect_equal(dim(params), c(300, 4))
})

test_that("'likelihood' works when likelihood ties don't exist", {
  params <-  ExtractParameters(stratPosterior1, parameters = "likelihood")
  expect_s3_class(params, "data.frame")

  params <-  ExtractParameters(stratPosterior1, parameters = "all")
  expect_equal(ncol(params), 28)

  params <-  ExtractParameters(stratPosterior1)
  expect_equal(ncol(params), 4)
})

test_that("selectRows can be a vector or a list", {
  expect_equal(dim(ExtractParameters(stratPosterior1, selectRows = 100:201)),
               c(102 * 3, 4))
  expect_equal(ExtractParameters(stratPosterior1, runs = 2:3,
                                 parameters = "alpha_site_3",
                                 selectRows = 100:102)[, 1],
               c(stratPosterior1$samples[100:102,2,2:3,1]),
               tolerance = 0.01)
  expect_equal(dim(ExtractParameters(stratPosterior1, runs = 2,
                                     selectRows = list(100:201))),
               c(102, 4))
  # A `selectRows` list is indexed by run number (length nRun), not by position
  # within `runs`. Here run 1 -> rows 100:101, run 3 -> rows 102:101 (run 2 unused).
  # RT-035: tight tolerance so a run-number/position mis-mapping (RT-034) can no
  # longer be masked.
  expect_equal(ExtractParameters(stratPosterior1, runs = c(3, 1),
                                 parameters = "alpha_site_3",
                                 selectRows = list(100:101, NULL, 102:101))[, 1],
               as.numeric(c(stratPosterior1$samples[102:101,2,3,1], stratPosterior1$samples[100:101,2,1,1])),
               tolerance = 1e-6)
})

test_that("ExtractParameters keeps run-number indexing for gapped runs (RT-034)", {
  # Auto-selection path (selectRows = NULL) with an unequal number of completed
  # iterations per run: run 3 is shorter, so its selected rows differ from run 1.
  # Before the RT-034 fix, `ExtractIterations(...)[runSelect]` collapsed the
  # run-number-indexed list to a positional one, and the `[[runR]]` loop then
  # fed run 1's row indices to run 3 (wrong rows, wrong row count, NAs).
  spA <- stratPosterior1
  spA$mcmcSummary$completedIter <- c(5000, 5000, 2000)

  it <- ExtractIterations(spA, runs = c(1, 3))
  n1 <- length(it[[1]])
  n3 <- length(it[[3]])
  expect_true(n1 != n3)  # asymmetry is what exposes the bug

  gapped <- ExtractParameters(spA, runs = c(1, 3), parameters = "alpha_site_3")
  run3   <- ExtractParameters(spA, runs = 3,       parameters = "alpha_site_3")

  expect_equal(nrow(gapped), n1 + n3)
  expect_false(anyNA(gapped))
  # the run-3 block must be exactly what runs = 3 alone returns
  expect_equal(gapped[(n1 + 1):(n1 + n3), 1], run3[, 1], tolerance = 1e-6)
})


test_that("ExtractParameters works with new cluster object and
          iterations before burnIn", {
            # works only with this specific generation of stratPosterior1
            clustNew <- Cluster(stratPosterior1, iterations = 500)
              expect_equal(
                class(ExtractParameters(stratPosterior1,
                        stratCluster = clustNew,
                        alignment = 1)[,2]), "numeric")
})
