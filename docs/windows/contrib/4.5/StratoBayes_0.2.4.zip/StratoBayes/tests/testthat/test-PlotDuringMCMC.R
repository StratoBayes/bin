.MakeDuringMCMCFixture <- function(stratPosterior, run = 1, iterationRow = 1) {
  model <- stratPosterior[["model"]]
  data <- stratPosterior[["data"]]
  paramNames <- model[["outputParams"]]
  allNames <- c("iteration", "chain", paramNames)

  lastVals <- stratPosterior[["samples"]][201, , run, 1]

  samples <- array(NA_real_, dim = c(1, length(allNames), 1, 1))
  dimnames(samples) <- list(NULL, allNames, "run1", "chain1")
  samples[iterationRow, "iteration", 1, 1] <- 201
  samples[iterationRow, "chain", 1, 1] <- 1
  samples[iterationRow, paramNames, 1, 1] <- lastVals

  nSect <- data[["S"]]
  sectionCol <- hcl.colors(nSect, "Dark 3", alpha = 1)
  allowedSymbols <- 21:25
  sectionSymbol <- allowedSymbols[(1:nSect - 1) %% length(allowedSymbols) + 1]

  list(data = data, model = model, mcmc = list(nIter = 5000), samples = samples,
       sectionCol = sectionCol, sectionSymbol = sectionSymbol)
}

test_that(".PlotSignal skips plotting instead of crashing for an all-NA signal column", {
  fixture <- .MakeDuringMCMCFixture(stratPosterior1)
  fixture$data[["signal"]][["value"]] <- NA_real_

  png(tempfile())
  result <- expect_no_error(
    suppressWarnings(
      StratoBayes:::.PlotSignal(fixture$data, fixture$model, fixture$mcmc,
                                fixture$samples, run = 1, sig = 1,
                                plotIterRowAll = 1L,
                                fixture$sectionCol, fixture$sectionSymbol, 1)
    )
  )
  dev.off()

  expect_null(result)
})

test_that(".PlotDuringMCMC's non-parallel run selection excludes runs with all-NA samples", {
  # mirrors the filtering logic at the top of .PlotDuringMCMC: in the
  # non-parallel branch, runsForSignalPlot must skip a run whose
  # plotIterRowAll entry is not finite (e.g. an all-NA sample array from an
  # I/O failure), just like the parallel branch already does.
  plotIterRowAll <- c(-Inf, 42)

  run <- 1
  runsForSignalPlot <- if (is.finite(plotIterRowAll[run])) run else integer(0)
  expect_length(runsForSignalPlot, 0L)

  run <- 2
  runsForSignalPlot <- if (is.finite(plotIterRowAll[run])) run else integer(0)
  expect_equal(runsForSignalPlot, 2)
})

test_that("a .PlotDuringMCMC failure does not kill the MCMC run (RT-062)", {
  # RT-062: previously .PlotDuringMCMC was called with no tryCatch, so any
  # plotting error (closed device, all-NA state, etc.) propagated all the way
  # up and terminated the run. It must now be caught and merely warned about.
  callCount <- 0
  testthat::local_mocked_bindings(
    .PlotDuringMCMC = function(...) {
      callCount <<- callCount + 1
      stop("simulated plot failure")
    },
    .package = "StratoBayes"
  )

  warnMessages <- character(0)
  r1 <- withCallingHandlers(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                  nChains = 2, visualise = TRUE, seed = 1),
    warning = function(w) {
      warnMessages <<- c(warnMessages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  expect_s3_class(r1, "StratPosterior")
  expect_gt(callCount, 0)
  expect_true(any(grepl("Plot update failed during MCMC", warnMessages, fixed = TRUE)))
})
