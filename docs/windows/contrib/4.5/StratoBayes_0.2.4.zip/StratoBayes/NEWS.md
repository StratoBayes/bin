# StratoBayes 0.2.0.9002

## MCMC mixing improvements

* `onlyMultivariateProposalsAfterAdapt` now defaults to `FALSE`. Previously
  the cold chain was restricted to the Multivariate proposal after
  `endAdapting`, which caused zero acceptance (and frozen chains) when the
  cluster covariance was dominated by burn-in dispersion. With the new default,
  Univariate, ShiftAlphas, NeighbourScaled, and SiteBlock proposals remain
  active post-adapt as a fallback, keeping the chain mobile when the
  Multivariate proposal temporarily over-shoots.

* The minimum Multivariate proposal probability post-adapt is reduced from 50%
  to 20%, giving the working fallback proposals (NeighbourScaled, SiteBlock)
  a larger share of the post-adapt budget when the Multivariate proposal's
  cluster covariance has not yet converged.

* New optional `enablePostAdaptDecay` flag (default `FALSE`) for continuing
  `proposalFactor` adaptation post-`endAdapting` with a `1/sqrt(t)` diminishing
  envelope (Roberts & Rosenthal 2007) and clearing the Multivariate acceptance
  buffer at `endAdapting`. Default behaviour remains the hard freeze of
  `proposalFactor` at `endAdapting`. Comparative runs on real datasets did not
  show a consistent benefit from enabling decay; flag is retained for further
  investigation.

* New optional `enableRingBuffer` flag (default `FALSE`) for storing chain
  history in a chronological ring buffer (oldest entry overwritten first), so
  `recentFraction` in `.ClustInfo` selects the temporally most recent samples.
  Default behaviour remains random-replacement reservoir sampling. Comparative
  runs did not show a consistent benefit from the ring buffer; flag is
  retained for further investigation.

* When `parametersInitial = NULL` (the default), α parameters are now
  initialised by drawing uniformly from the 95% mass interval of their prior
  rather than from the full Normal, avoiding prior-dominated no-overlap basins
  where the log-likelihood is flat and the chain cannot escape.

## Gradient-based proposals (HMC / NUTS)

* New NUTS (No-U-Turn Sampler) proposal type, automatically enabled when
  `flexibleKnots = FALSE`. Uses gradient information to make larger,
  less-correlated moves through parameter space, improving mixing for
  models with many parameters.

* Full C++ NUTS implementation with recursive tree doubling, multinomial
  candidate selection, and U-turn detection — runs natively in the C++
  engine for best performance.

* HMC (fixed-length leapfrog) also available as a proposal type,
  sharing the same gradient infrastructure.

* Dual averaging step-size adaptation for both HMC and NUTS, with
  automatic mass matrix estimation from the adaptation window.

* Analytic gradient of the log-posterior with respect to all free
  parameters, computed via reverse-mode differentiation through the
  age-conversion pipeline. Supports models with ties (tie-point
  gradient handled natively in C++). Custom priors fall back to
  finite-difference gradient.

* `flexibleKnots` and `knotRange` parameters documented in
  `StratModel()` and `RunStratModel()`.

* Cost-aware adaptive proposal weighting: during tuning, per-proposal
  wall-clock time is tracked and used to penalise expensive proposal
  types (sqrt penalty on relative time cost). This allows NUTS to be
  registered alongside MH proposals and automatically downweighted when
  its per-iteration cost outweighs the mixing benefit.

* `.GenerateInitialState()` now errors after 500 failed attempts
  instead of looping indefinitely when `knotRange` is incompatible
  with the prior. The error message advises widening `knotRange` or
  setting `flexibleKnots = TRUE`.

* When `knotRange` is not specified, it is now auto-computed from the
  reference-section data range with 25% symmetric padding. This is
  deterministic and keeps knot density concentrated within the data
  range. Previous versions required `knotRange` to be set manually.

## Bactrian proposal kernels

* Metropolis–Hastings proposals now use Bactrian kernels (Yang &
  Rodríguez, 2013) by default. The Bactrian kernel is a mixture of two
  displaced Gaussians that suppresses near-zero proposal steps, improving
  mixing efficiency. Applied to univariate, multivariate, and all
  alpha-shift proposal types in both R and C++ engines. Gibbs and
  HMC/NUTS proposals are unaffected.

* New `bactrianM` parameter in `StratMCMC()` controls the kernel shape
  (default 0.95). Set `bactrianM = 0` to fall back to standard Gaussian
  proposals.

## C++ MCMC engine

* New persistent C++ MCMC engine (`MCMCEngine.cpp`) replaces the R hot loop,
  with C++ implementations of log-posterior evaluation, proposal generation,
  Gibbs sampling, B-spline design matrix construction, and height–age
  conversion.

* Intra-run chain parallelism via `std::thread` — multiple tempered chains
  execute in parallel within a single `RunStratModel()` call (#236).

* Parallel tempering now works correctly for models with tie-point
  constraints: native C++ density evaluation for Normal, Uniform, LogNormal,
  Gamma, Beta, Cauchy, and Student-t tie densities; unsupported densities
  fall back to per-tie R callbacks.

* Pre-built ties dispatch table eliminates per-iteration `match.fun()` /
  `formals()` overhead.

* Cache B'B and B'y products on the rejection path to avoid redundant
  Gibbs recomputation.

* Early per-site overlap connectivity check rejects proposals before
  spline/Gibbs computation when sites are insufficiently connected.

* Hot-loop timing instrumentation (opt-in) for profiling.

## Dependency reduction

* **Removed from Imports:** `RcppEigen`, `mvnfast`, `EnvStats`, `fda`,
  `msm`, `Rfast`, `collapse`, `MASS`, `doParallel`, `foreach`.

* **Moved to Suggests:** `SDAR`, `ks`, `shiny`, `shinyjs`, `bslib`,
  `mcmcse`, `coda`.

* **Added to Suggests:** `future`, `future.apply` (used for independent
  multi-run parallelism, replacing `doParallel`/`foreach`).

* Internal replacements for removed packages: `.rmvn1()` (MVN sampling),
  `.bsplinepen()` (B-spline penalty matrix), `.rtnorm()` / `.dtnorm()` /
  `.qtnorm()` (truncated normal), `.rlnormTrunc()` / `.qlnormTrunc()`
  (truncated lognormal).

* Custom lightweight linear algebra header (`sb_linalg.h`) replaces
  RcppEigen (#237).

## Bug fixes

* `summary.StratPosterior()` no longer enters infinite recursion on freshly
  created objects (T-089).

* `StratMap()` quantile calculation no longer crashes due to partial argument
  matching (T-082).

* `.PlotParameter()` list indexing now works correctly with non-contiguous
  `plotRuns` (T-083).

* `.AgeConversionBatch()` correctly reorders results for unsorted height
  inputs (T-081).

* Univariate proposal argument length now handled correctly when `Fixed()`
  priors are present (T-106).

* `temperingSwaps` vector sized by `endIter`, not `nIter`, fixing
  out-of-bounds writes in continued runs (T-107).

* `adaptProposal` vector check uses `any()` instead of `isTRUE()` (T-059).

* Seed handling is now consistent for duplicate-seed and parallel-run
  scenarios (T-049).

* Ring buffer in `sb_run_block` resized to fit a full batch (T-069).

* `signalSectionOverlap` included in C++ engine state extraction (T-068).

* `.match.hash` attributes stripped in `rowIndex` comparison (T-105).

## Performance

* `BayesianSpline()` Gibbs loop moved entirely into C++ (`.sb_gibbs_spline`),
  eliminating per-iteration R ↔ C++ overhead. The B-spline design matrix is
  now built by the C++ `.sb_spline_design` routine (replacing
  `splines::splineDesign`), and the `B'B` / `B'y` cross-products are
  precomputed once in `.ModelBspline()` instead of being recomputed every
  iteration (profiling showed `crossprod` was ~33% of self-time). The retained
  R reference (`.GibbsSampleBspline()`) is exercised in the test suite as the
  correctness baseline. End-to-end **~13–19× faster** (e.g. n=100/k=25:
  72 → 5.4 ms; n=300/k=40: 199 → 10.4 ms per fit).

* Gibbs sampler for individual spline pre-fitting (`.GibbsSampleBspline()`)
  rewritten to use a single Cholesky decomposition with triangular solves,
  replacing the previous decompose → invert → re-decompose path. ~14×
  faster per iteration.

* Reduced default `individualSplineIter` from 2000 to 500 in `StratModel()`.
  Profiling showed σ estimates stabilise well within 100 iterations; 500
  provides a comfortable margin while cutting pre-fit time by 75%.

* Adaptation-phase batching in `RunStratModel()`: iterations between
  adaptation checkpoints are now dispatched to the C++ engine in batches
  (up to 50), rather than one at a time. This reduces R ↔ C++ round-trips
  by ~98% during adaptation and allows thread parallelism to take effect
  throughout the run.

* Loop-invariant `mcmc` fields hoisted above the main MCMC loop; ring
  buffer accumulation matrices (acceptance monitoring, timing, tempering
  ratios) extracted into locals before inner loops and written back once.
  Cuts ~4 800 nested-list traversals per batch to ~4.

* `.SaveMCMChistory()` loop-invariant computations hoisted; new C++
  `isDuplicateInHistory()` replaces the R wrapper + two matrix-subsetting
  copies per chain per call.

* Combined effect on a 12-chain, 20 000-iteration age model: **61%
  wall-time reduction** at 2 threads (102 s → 40 s). With the list-access
  and history-save optimizations, a 2 000-iteration benchmark drops a
  further **~56%** (3.2 s → 1.3 s at 2 threads).

## Other changes

* Removed unused `seed` argument from `.InnerRunMCMC()`.

* Spelling corrections and new `WORDLIST` for package spell-checking.
