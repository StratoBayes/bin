"use strict";
window.onload = function() {
  const placeholderSrc = document.getElementById("img_placeholder").src;
  const plots = document.getElementById("plots_table").getElementsByTagName("img");

  // Initialize each image with the placeholder and set data-loaded to false
  for (let i = 0; i < plots.length; i++) {
    let img = plots[i];
    img.src = placeholderSrc;
    img.setAttribute('data-loaded', 'false'); // mark as not loaded
    img.setAttribute('data-good-src', placeholderSrc); // initialize good-src as placeholder

    // On successful load, mark as loaded only if not the placeholder
    img.onload = function() {
      if (img.src !== placeholderSrc) {
        img.setAttribute('data-loaded', 'true');
        img.setAttribute('data-good-src', img.src); // Update good-src
      }
    };

    // On error, revert to placeholder only if not loaded before
    img.onerror = function() {
      if (img.getAttribute('data-loaded') === 'false') {
        img.src = placeholderSrc;
        console.error(`Failed to load image: ${img.getAttribute('data-src')}`);
      }
      // If data-loaded is true, do nothing to keep the last loaded PNG
    };
  }

  if (plots.length === 0) return;

  // Without a user-supplied visualiseDir the PNGs are deleted when the run
  // ends, so polling stops once every image has been missing for this many
  // consecutive rounds after any was seen.
  const maxMissedRounds = 30;
  let seenAny = false;
  let missedRounds = 0;

  // Set up the refresher to update images every second
  const refresher = setInterval(function() {
    let pending = plots.length;
    let foundAny = false;
    const settle = function() {
      pending -= 1;
      if (pending > 0) return;
      if (foundAny) {
        seenAny = true;
        missedRounds = 0;
      } else if (seenAny && ++missedRounds >= maxMissedRounds) {
        clearInterval(refresher);
      }
    };
    for (let i = 0; i < plots.length; i++) {
      let img = plots[i];
      let src = img.getAttribute('data-src');
      let timestamp = new Date().getTime();
      let newSrc = src + '?t=' + timestamp; // cache-busting

      // Create a new Image object to test if the PNG exists
      let testImage = new Image();
      testImage.onload = function() {
        img.src = newSrc; // Update the image src to the PNG with timestamp
        img.setAttribute('data-loaded', 'true'); // Mark as loaded
        img.setAttribute('data-good-src', newSrc); // Update good-src
        foundAny = true;
        settle();
      };
      // A missing PNG keeps the last loaded image: before its first frame and
      // after the run ends, absence is expected.
      testImage.onerror = settle;
      testImage.src = newSrc; // Start loading the test image
    }
  }, 1000); // Refresh every 1 second; adjust as needed
};
