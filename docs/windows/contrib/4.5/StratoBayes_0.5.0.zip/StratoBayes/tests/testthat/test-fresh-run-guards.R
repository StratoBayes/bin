RunArgs <- function(runParallel = FALSE, ...) {
  list(nThreads = 1L, quiet = TRUE, visualise = FALSE,
       runParallel = runParallel, ...)
}

FreshRun <- function(modelDir, modelName = "b", nIter = 30, nChains = 2L,
                     ...) {
  do.call(
    RunStratModel,
    c(
      list(stratData1, stratModel1, nIter = nIter, nChains = nChains,
           seed = 1,
           modelDir = modelDir, modelName = modelName),
      RunArgs(...)
    )
  )
}

NewDir <- function() {
  dir <- tempfile("fresh")
  dir.create(dir)
  dir
}

test_that("a refused fresh run leaves the existing run usable (#2357)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  FreshRun(dir)
  checkpoint <- file.path(dir, "b_mcmc_run_1.rds")
  expect_true(file.exists(checkpoint))

  expect_error(FreshRun(dir, nIter = "60"), "nIter")
  expect_error(FreshRun(dir, saveChains = c(1, 1)))
  expect_error(
    suppressWarnings(
      FreshRun(dir, temperingComponents = "ties", gradientProposals = "on")
    )
  )
  expect_true(file.exists(checkpoint))
  expect_true(file.exists(file.path(dir, "b_binarysamples_run_1.rds")))

  cont <- do.call(
    RunStratModel, c(list(modelDir = dir, modelName = "b", nIter = 5),
                     RunArgs())
  )
  expect_equal(dim(cont$samples)[1], 35)
})

test_that("a character nIter does not claim an infinite budget (#2357)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  expect_no_warning(
    expect_error(FreshRun(dir, nIter = "60", convergenceStop = FALSE), "nIter"),
    message = "no stopping rule"
  )
})

test_that("timeLimit is validated before the directory is touched (#2357)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  FreshRun(dir)
  checkpoint <- file.path(dir, "b_mcmc_run_1.rds")
  for (bad in list(NA, 0, -1, "1", list(1), c(1, 2))) {
    expect_error(FreshRun(dir, timeLimit = bad), "timeLimit")
  }
  expect_true(file.exists(checkpoint))
})

test_that("a live writer blocks a fresh run and keeps its marker (#2357)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  skip_on_os("windows")
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  FreshRun(dir)
  # The sleeper must not hold the pipe open, or `intern = TRUE` waits it out.
  sleeper <- system("sleep 30 > /dev/null 2>&1 & echo $!", intern = TRUE)
  expect_true(.ProcessAlive(as.integer(sleeper)))
  on.exit(system2("kill", sleeper, stderr = FALSE), add = TRUE)
  marker <- .WriterMarkerPath(dir, "b")
  writeLines(c(Sys.info()[["nodename"]], sleeper), marker)

  expect_error(FreshRun(dir), "still being written")
  expect_true(file.exists(file.path(dir, "b_mcmc_run_1.rds")))
  expect_identical(readLines(marker)[2], sleeper)
  expect_error(.MarkWriter(dir, "b"), "being written")
  expect_identical(readLines(marker)[2], sleeper)
})

test_that("a stale StratPosterior does not continue a replacing run (#2357)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  r1 <- FreshRun(dir, modelName = "m", nIter = 30)
  FreshRun(dir, modelName = "m", nIter = 20, nChains = 3L)
  expect_error(
    do.call(RunStratModel, c(list(r1, nIter = 5), RunArgs())),
    "different run of the same name"
  )
})

test_that("a continued older handle of the same lineage is still allowed", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  r1 <- FreshRun(dir, modelName = "m", nIter = 30)
  r2 <- do.call(RunStratModel, c(list(r1, nIter = 5), RunArgs()))
  expect_no_warning(
    r3 <- do.call(RunStratModel, c(list(r1, nIter = 5), RunArgs()))
  )
  expect_equal(dim(r3$samples)[1], 40)
})

test_that("a used checkpoint cannot start a fresh run (#2471)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  r <- FreshRun(dir, modelName = "src", saveMCMC = TRUE)
  used <- r$mcmc$mcmc_run1
  expect_s3_class(used, "StratMCMC")
  target <- NewDir()
  on.exit(unlink(target, recursive = TRUE), add = TRUE)
  expect_error(
    do.call(
      RunStratModel,
      c(list(stratData1, stratModel1, stratMCMC = used, modelDir = target,
             modelName = "t"), RunArgs())
    ),
    "already been run"
  )
  expect_length(list.files(target), 0L)
})

test_that("seeds must be whole numbers in integer range (#2461)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  for (bad in list(c(1.2, 1.7), 3e9)) {
    expect_error(
      do.call(
        RunStratModel,
        c(list(stratData1, stratModel1, nIter = 10, nChains = 2L,
               nRun = length(bad), seed = bad, modelDir = dir,
               modelName = "s"), RunArgs())
      ),
      "whole numbers"
    )
  }
  expect_length(list.files(dir), 0L)
})

test_that("parallel workers seed in the session's RNG kind (#2461)", {
  skip_on_cran()
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  oldKind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(oldKind)), add = TRUE)
  RNGkind("L'Ecuyer-CMRG")
  Go <- function(parallel) {
    dir <- NewDir()
    on.exit(unlink(dir, recursive = TRUE))
    do.call(
      RunStratModel,
      c(
        list(stratData1, stratModel1, nIter = 20, nChains = 2L, nRun = 2L,
             seed = c(11, 12), modelDir = dir, modelName = "p",
             nCores = 2L),
        RunArgs(runParallel = parallel)
      )
    )$samples
  }
  expect_equal(Go(TRUE), Go(FALSE))
})

test_that("a changed ties set is reported on continuation (#2459)", {
  data(stratData2, package = "StratoBayes", envir = environment())
  Mod <- function(...) {
    StratModel(stratData2, alignmentScale = "height", sedModel = "site",
               alphaPosition = "bottom", nKnots = 8, ...,
               residualCorrelation = "none")
  }
  base <- Mod()
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  do.call(
    RunStratModel,
    c(list(stratData2, base, nIter = 20, nChains = 2L, seed = 1,
           modelDir = dir, modelName = "m"), RunArgs())
  )
  expect_warning(
    do.call(
      RunStratModel,
      c(list(modelDir = dir, modelName = "m",
             stratModel = Mod(disableTies = list(site3 = 1)), nIter = 5),
        RunArgs())
    ),
    "tiesActive"
  )
})

test_that("a finite supplied StratMCMC is not called infinite (#2410)", {
  data(stratData1, stratModel1, package = "StratoBayes", envir = environment())
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  mc <- StratMCMC(stratModel1, nIter = 20, nChains = 2L, nThreads = 1L)
  expect_no_warning(
    do.call(
      RunStratModel,
      c(list(stratData1, stratModel1, stratMCMC = mc, nRun = 1,
             convergenceStop = FALSE, modelDir = dir, modelName = "w"),
        RunArgs())
    ),
    message = "no stopping rule"
  )
  expect_warning(
    tryCatch(
      do.call(
        RunStratModel,
        c(list(stratData1, stratModel1, nIter = Inf, convergenceStop = FALSE,
               modelDir = dir, modelName = "w", colourScale = "notAPalette"),
          RunArgs())
      ),
      error = function(e) NULL
    ),
    "no stopping rule"
  )
})

test_that("a missing ties density leaves the existing run intact (#2357)", {
  data(stratData2, package = "StratoBayes", envir = environment())
  Mod <- function(d) {
    StratModel(d, alignmentScale = "height", sedModel = "site",
               alphaPosition = "bottom", nKnots = 8,
               residualCorrelation = "none")
  }
  dir <- NewDir()
  on.exit(unlink(dir, recursive = TRUE))
  RunB <- function(d) {
    do.call(
      RunStratModel,
      c(list(d, Mod(d), nIter = 10, nChains = 2L, seed = 1, modelDir = dir,
             modelName = "m"), RunArgs())
    )
  }
  RunB(stratData2)
  broken <- stratData2
  broken[[c("tiesAttr", "densityFun")]][] <- "noSuchDensityFunction"
  expect_error(RunB(broken), "noSuchDensityFunction")
  expect_true(file.exists(file.path(dir, "m_mcmc_run_1.rds")))
})
