sigDf <- function() {
  data.frame(site = rep(c("A", "B"), each = 5), height = rep(1:5, 2),
             value = sin(1:10))
}

test_that("a mixed-scheme ties CSV with blank cells is accepted", {
  f <- tempfile(fileext = ".csv")
  on.exit(unlink(f))
  writeLines(c("site,height,mean,sd,densityFun,arg1,arg2",
               "A,2,10,1,,,",
               "A,4,,,dlnorm,2,0.5"), f)
  d <- StratData(sigDf(), ties = f)
  expect_equal(d$ties$densityFun, c("dnorm", "dlnorm"))
  expect_equal(d$ties$arg1, c(10, 2))
  expect_equal(d$ties$arg2, c(1, 0.5))
})

test_that("StratData accepts its own $ties output", {
  d <- StratData(sigDf(),
                 ties = data.frame(site = "A", height = 2, mean = 10, sd = 1))
  d2 <- StratData(sigDf(), ties = d$ties)
  expect_equal(d2$ties$arg1, 10)
  # a row that only labels itself dnorm
  d3 <- StratData(sigDf(), ties = data.frame(site = "A", height = 2, mean = 10,
                                             sd = 1, densityFun = "dnorm",
                                             arg1 = NA_real_))
  expect_equal(d3$ties$arg2, 1)
  disagree <- data.frame(site = "A", height = 2, mean = 10, sd = 1,
                         densityFun = "dnorm", arg1 = 11, arg2 = 1)
  expect_error(StratData(sigDf(), ties = disagree), "mutually exclusive")
  stray <- data.frame(site = "A", height = 2, mean = 10, sd = 1,
                      densityFun = "dexp", arg1 = NA_real_)
  expect_error(StratData(sigDf(), ties = stray), "also sets")
})

test_that("a dt tie's ncp reaches the central age and the plot args", {
  ties <- data.frame(site = "A", height = 2, densityFun = "dt", arg1 = 5,
                     arg2 = 3)
  expect_warning(ages <- .TieCentralAges(.CheckTies(ties, "height", "site")),
                 NA)
  expect_equal(ages, stats::qt(0.5, 5, 3))
  d <- StratData(sigDf(), ties = ties)
  expect_equal(.CollectArgs(d, 1, 1), c(5, 3))
})

test_that("duplicate column names in signal and parts are refused", {
  sig <- data.frame(site = rep(c("a", "b"), each = 20), height = rep(1:20, 2),
                    v = sin(1:40))
  expect_error(StratData(cbind(sig, v = cos(1:40)), signalColumn = "v"),
               "`signal` has duplicate column names")
  parts <- cbind(data.frame(site = c("a", "a", "b", "b"),
                            height = c(10, 20, 10, 20),
                            partition = c("A", "B", "A", "B")), height = 25)
  expect_error(StratData(sig, parts = parts, signalColumn = "v"),
               "`parts` has duplicate column names")
})

test_that("tiesAttr$tiesN is unnamed", {
  d <- StratData(sigDf(),
                 ties = data.frame(site = "A", height = 2, mean = 10, sd = 1))
  expect_null(names(d$tiesAttr$tiesN))
})
