
# StratData0
# StratModelTemplate(stratData0)
r1 <- range(SignalLookUp(stratData0, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData0, type = "height", site = 2))
d2 <- diff(r2)

min_i <- r1[1] - d2
max_i <- r1[2] + d2

sd_i <- (max_i - min_i) / (2 * 1.96)

alphaPositionSite <- .MatchAlphaPosition(c(NA, "middle"),
                                         stratData0, "height")[2]

# relative position within site 2
relAlphaPos <- (alphaPositionSite - r2[1]) / (r2[2] - r2[1])

# same relative position mapped into reference section
m_i <- r1[1] + diff(r1) * relAlphaPos


prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" =
    NormalPrior(mean = 0, sd = log(2))
),
class = c("StratPrior", "list"))
stampPos <- .MatchAlphaPosition("middle", stratData0, "height",
                                toNumeric = TRUE)
attr(prior0a, "alphaPosition") <- stats::setNames(stampPos, stratData0$sites)

prior0b <- AutoPrior(
  stratData = stratData0,
  alignmentScale = "height",
  sedModel = "site",
  alphaPosition = "middle",
  customPriors = NULL
)

test_that("AutoPrior() creates the correct priors", {
  expect_equal(prior0a, prior0b)
})

# custom prior
gammaPrior <- NormalPrior(mean = 0, sd = 3)
prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = 3)
),
class = c("StratPrior", "list"))
stampPos <- .MatchAlphaPosition("middle", stratData0, "height",
                                toNumeric = TRUE)
attr(prior0a, "alphaPosition") <- stats::setNames(stampPos, stratData0$sites)

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     customPriors = list(gammaLog_site2 = gammaPrior))

test_that("AutoPrior() creates the correct priors with added custom prior", {
  expect_equal(prior0a, prior0b)
})

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData2, type = "height", site = 2))
r3 <- range(SignalLookUp(stratData2, type = "height", site = 3))

d2 <- diff(r2)
d3 <- diff(r3)

min_2 <- r1[1] - d2
max_2 <- r1[2] + d2
min_3 <- r1[1] - d3
max_3 <- r1[2] + d3


sd_2 <- (max_2 - min_2) / (2 * 1.96)
sd_3 <- (max_3 - min_3) / (2 * 1.96)

alphaPositions <-  c(10, 20, 0)

relAlphaPos2 <- (alphaPositions[2] - r2[1]) / (r2[2] - r2[1])
relAlphaPos3 <- (alphaPositions[3] - r3[1]) / (r3[2] - r3[1])

m_2 <- r1[1] + diff(r1) * relAlphaPos2
m_3 <- r1[1] + diff(r1) * relAlphaPos3

prior2a <- structure(
  list(
    "alpha_site2" = NormalPrior(mean = m_2, sd = sd_2),
    "alpha_site3" = NormalPrior(mean = m_3, sd = sd_3),
    "gammaLog_part 2.1" =
      NormalPrior(mean = 0, sd = log(2)),
    "gammaLog_part 2.2" =
      NormalPrior(mean = 0, sd = log(2)),
    "gammaLog_part 3.1" =
      NormalPrior(mean = 0, sd = log(2)),
    "gap_site2_1" =
      ExponentialPrior(rate = 4 / diff(r1))
  ),
  class = c("StratPrior", "list")
)
stampPos <- .MatchAlphaPosition(alphaPositions, stratData2, "height",
                                toNumeric = TRUE)
attr(prior2a, "alphaPosition") <- stats::setNames(stampPos, stratData2$sites)
prior2b <- AutoPrior(
  stratData = stratData2,
  alignmentScale = "height",
  sedModel = "p",
  alphaPosition = alphaPositions,
  customPriors = NULL,
  delta_rate = NULL
)
test_that("AutoPrior() creates the correct priors for stratData2", {
  expect_equal(prior2a, prior2b)
})

# bulk overwrite sd / rates of prior parameters

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData2, type = "height", site = 2))
r3 <- range(SignalLookUp(stratData2, type = "height", site = 3))

d2 <- diff(r2)
d3 <- diff(r3)

min_2 <- r1[1] - d2
max_2 <- r1[2] + d2
min_3 <- r1[1] - d3
max_3 <- r1[2] + d3


sd_2 <- (max_2 - min_2) / (2 * 1.96)
sd_3 <- (max_3 - min_3) / (2 * 1.96)

alphaPositions <-  c(10, 20, 0)

relAlphaPos2 <- (alphaPositions[2] - r2[1]) / (r2[2] - r2[1])
relAlphaPos3 <- (alphaPositions[3] - r3[1]) / (r3[2] - r3[1])

m_2 <- r1[1] + diff(r1) * relAlphaPos2
m_3 <- r1[1] + diff(r1) * relAlphaPos3


prior2a <- structure(
  list(
    "alpha_site2" = NormalPrior(mean = m_2, sd = 7),
    "alpha_site3" = NormalPrior(mean = m_3, sd = 7),
    "gammaLog_part 2.1" = NormalPrior(mean = 0, sd = 3),
    "gammaLog_part 2.2" = NormalPrior(mean = 0, sd = 4),
    "gammaLog_part 3.1" = NormalPrior(mean = 0, sd = 3),
    "zetaLog_site3" = NormalPrior(mean = 0, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.1)
  ),
  class = c("StratPrior", "list")
)
stampPos <- .MatchAlphaPosition(alphaPositions, stratData2, "height",
                                toNumeric = TRUE)
attr(prior2a, "alphaPosition") <- stats::setNames(stampPos, stratData2$sites)

customGammaLog_part_2.2 <- NormalPrior(mean = 0, sd = 4)
prior2b <- AutoPrior(
  stratData = stratData2,
  alignmentScale = "height",
  sedModel = "s x p",
  alphaPosition = alphaPositions,
  alpha_sd = 7,
  gammaLog_sd = 3,
  zetaLog_sd = 1,
  delta_rate = 0.1,
  customPriors = list('gammaLog_part 2.2' = customGammaLog_part_2.2)
)
test_that(
  "AutoPrior() creates the correct priors for stratData2 with bulk overwrites",
  {
    expect_equal(prior2a, prior2b)


    model2b <-
      StratModel(stratData2, priors = prior2b, alphaPosition = alphaPositions,
                 alignmentScale = "height", sedModel =  "s x p")

    expect_equal(round(model2b$alphaPosition), c(NA, 20, 0))
  }
)


# RT-025 / RT-182: a site whose signal heights are all identical has
# hi[2] - hi[1] == 0, so `relAlphaPos` divides by zero and AutoPrior() used to
# silently build a NormalPrior(mean = NaN) that freezes the MCMC chain later
# (every logPrior evaluates to NaN/-Inf) instead of failing at construction
# time.
test_that("AutoPrior() errors clearly on a site with zero height range", {
  degenerateData <- data.frame(
    site   = rep(c("site1", "site2"), c(10, 5)),
    height = c(seq(0, 9, length.out = 10), rep(3, 5)),
    value  = rnorm(15)
  )
  degenerateStrat <- StratData(degenerateData)

  expect_error(
    AutoPrior(stratData = degenerateStrat,
              alignmentScale = "height",
              sedModel = "site"),
    regexp = "zero height range"
  )
})

# RT-026 / RT-183: the *reference* site (site 1, not a correlated site) with
# all-identical signal heights has diff(h1) == 0. Before the fix, this
# silently produced gap_i ~ ExponentialPrior(rate = 4 / diff(h1) = Inf) --
# passes the rate > 0 guard, but assigns all probability mass to exactly 0,
# silently disallowing every stratigraphic gap with no error. It would also
# NaN-poison the alpha_i mean/sd computation, which is keyed off the same
# h1 range. Both are the same root cause as RT-025/RT-182 (division by a
# zero-width height range) but at the reference-site call site instead of a
# correlated site.
test_that(
  "AutoPrior() errors clearly on a zero-range reference site (RT-026/RT-183)",
  {
    degenerateData <- data.frame(
      site   = rep(c("site1", "site2"), c(5, 10)),
      height = c(rep(3, 5), seq(0, 9, length.out = 10)),
      value  = rnorm(15)
    )
    degenerateStrat <- StratData(degenerateData)

    expect_error(
      AutoPrior(stratData = degenerateStrat,
                alignmentScale = "height",
                sedModel = "site"),
      regexp = "zero height range"
    )
  }
)

# test_that("AutoPrior() gives correct alpha priors for the no-overlap case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(2, 4, length.out = n1)
#   h2 <- seq(0, 0.1, length.out = n2)
#
#   testdata8a <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8a)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean) == 3)
#
#   smod1 <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod1$alphaPosition, 2), c(NA, 0.05))
#
#   smod2 <- StratModel(sdat, priors = NULL,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod2$alphaPosition, 2), c(NA, 0.05))
#
#
# })
#
# test_that("AutoPrior() gives correct alpha priors for the partial-overlap
# case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(0,   1.0, length.out = n1)
#   h2 <- seq(0.9, 2.4, length.out = n2)
#
#   testdata8b <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8b)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean, 2) == 0.95)
#
#   smod <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod$alphaPosition, 2), c(NA, 0.95))
#
# })
#
# test_that("AutoPrior() gives correct alpha priors for full overlap case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(0,   1.0, length.out = n1)
#   h2 <- seq(-1, 2.5, length.out = n2)
#
#   testdata8b <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8b)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean, 1) == 0.5)
#
#   smod <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod$alphaPosition, 1), c(NA, 0.5))
#
# })

# #93: `priors` defaults to NULL, so omitting it entirely (not just passing
# NULL) routes through AutoPrior() on the height scale.
test_that("StratModel() builds automatic priors when `priors` is omitted", {
  omitted <- StratModel(stratData = stratData0, alignmentScale = "height",
                        sedModel = "site", nKnots = 5)
  explicit <- StratModel(stratData = stratData0, priors = NULL,
                         alignmentScale = "height", sedModel = "site",
                         nKnots = 5)
  omittedPriors <- omitted[["priors"]][["metro"]]
  explicitPriors <- explicit[["priors"]][["metro"]]

  expect_equal(names(omittedPriors), names(explicitPriors))
  expect_equal(lapply(omittedPriors, `[[`, "args"),
               lapply(explicitPriors, `[[`, "args"))

  # The age scale has no automatic priors, so omission must still error.
  expect_error(
    StratModel(stratData = stratData0, alignmentScale = "age",
               sedModel = "site", nKnots = 5),
    "'priors' must be provided"
  )
})

test_that(
  "an unnamed `customPriors` element is rejected, not discarded (#1234)",
  {
    # Pre-fix, `priors[names(customPriors)] <- customPriors` was
    # `priors[NULL] <- ...`, a base-R no-op: the override vanished silently and
    # the auto-derived prior below was returned unchanged.
    auto <- AutoPrior(stratData0)[["alpha_site2"]][["args"]][["mean"]]

    expect_error(
      AutoPrior(stratData0, customPriors = list(NormalPrior(999, 1))),
      "must be named"
    )

    # A partially named list was worse: the "" entry was *appended* as a
    # spurious element rather than replacing anything.
    expect_error(
      AutoPrior(stratData0, customPriors = stats::setNames(
                                                           list(NormalPrior(
                                                             999, 1
                                                           ), NormalPrior(
                                                             1, 1
                                                           )),
                                                           c("alpha_site2",
                                                             ""))),
      "must be named"
    )

    # Control: a fully named override still replaces the auto-derived prior,
    # and an empty list is still a no-op.
    named <- AutoPrior(stratData0,
                       customPriors = list(alpha_site2 = NormalPrior(999, 1)))
    expect_equal(named[["alpha_site2"]][["args"]][["mean"]], 999)
    expect_false(isTRUE(all.equal(auto, 999)))
    expect_equal(
      AutoPrior(stratData0,
                customPriors = list())[["alpha_site2"]][["args"]][["mean"]],
      auto
    )
  }
)

test_that(
  "alphaPosition resolves against the signal, not the parts, span (#1233)",
  {
    # stratData2's `parts` extend beyond its samples: site 3 is sampled over
    # [0, 10] but partitioned to 20; site 1 is sampled over [1, 104] but its
    # ties reach down to 0.
    expect_equal(range(SignalLookUp(stratData2, "height", 3)), c(0, 10))
    expect_equal(max(stratData2[[c("partsAttr", "Bound")]][, 3], na.rm = TRUE),
                 20)
    sampled2 <- range(SignalLookUp(stratData2, "height", 2))

    expect_equal(.MatchAlphaPosition("middle", stratData2, "height"),
                 c(NA, mean(sampled2), 5))
    expect_equal(.MatchAlphaPosition("top", stratData2, "height"),
                 c(NA, sampled2[[2]], 10))
    expect_equal(.MatchAlphaPosition("bottom", stratData2, "height"),
                 c(NA, sampled2[[1]], 0))
    expect_equal(.MatchAlphaPosition("bottom", stratData2, "age"),
                 c(1, sampled2[[1]], 0))

    # Reference site 1 is sampled over [1, 104]: "middle" sits at relative
    # position 0.5, i.e. 1 + 103 / 2, as ?AutoPrior documents.
    alphaMean <- function(pos) {
      AutoPrior(stratData2,
                alphaPosition = pos)[[c("alpha_site3", "args", "mean")]]
    }
    expect_equal(alphaMean("middle"), 52.5)
    expect_equal(alphaMean("top"), 104)
    expect_equal(alphaMean("bottom"), 1)

    model <- StratModel(stratData2, priors = NULL, alignmentScale = "height",
                        sedModel = "site", alphaPosition = "middle", nKnots = 5)
    expect_equal(model[["alphaPosition"]][[3]], 5)
    expect_equal(model[[c("priors", "metro", "alpha_site3", "args", "mean")]],
                 52.5)

    expect_error(.MatchAlphaPosition(c(NA, 20, 15), stratData2, "height"),
                 "`alphaPosition[3]` (15) must be >= 0 and <= 10", fixed = TRUE)
  }
)

test_that(
  "an age-scale model anchors alpha within the sampled extent (#1233)",
  {
    model <- StratModel(stratData = stratData2, priors = stratPrior2,
                        alignmentScale = "age", sedModel = "site",
                        alphaPosition = c("top", "middle", "bottom"),
                        nKnots = 5, sigmaFixed = TRUE)
    expect_equal(model[["alphaPosition"]],
                 c(104, mean(range(SignalLookUp(stratData2, "height", 2))), 0))
    expect_equal(model[["ind"]][["alphaPosition"]], model[["alphaPosition"]])
  }
)

# #2424: a single-height site has no alpha prior to generate; the stops must
# not fire when the user supplies the prior they ask for.
SingleHeightSiteData <- function(s3Rows = 1L) {
  s3Height <- if (s3Rows == 1L) 4 else c(4, NA, NA)
  suppressWarnings(StratData(data.frame(
    site = rep(c("s1", "s2", "s3"), c(40, 40, s3Rows)),
    height = c(seq(0, 9, length.out = 40), seq(1, 10, length.out = 40),
               s3Height),
    value = rnorm(80 + s3Rows)
  )))
}

test_that("AutoPrior() accepts a custom alpha prior for a zero-range site", {
  set.seed(2424)
  for (s3Rows in c(1L, 3L)) {
    d <- SingleHeightSiteData(s3Rows)
    expect_error(
      AutoPrior(d, alignmentScale = "height", sedModel = "site"),
      "alpha_s3"
    )
    expect_no_error(
      p <- AutoPrior(d, alignmentScale = "height", sedModel = "site",
                     customPriors = list(alpha_s3 = NormalPrior(4, 1)))
    )
    expect_equal(p[["alpha_s3"]], NormalPrior(4, 1))
    expect_no_error(
      StratModel(d, alignmentScale = "height", sedModel = "site",
                 priors = list(alpha_s3 = NormalPrior(4, 1)))
    )
  }
})

test_that("AutoPrior() zero-range reference site needs every h1 prior", {
  d <- StratData(data.frame(
    site = rep(c("s1", "s2"), c(5, 10)),
    height = c(rep(3, 5), seq(0, 9, length.out = 10)),
    value = rnorm(15)
  ))
  expect_error(
    AutoPrior(d, alignmentScale = "height", sedModel = "site"),
    "zero height range"
  )
  expect_equal(
    AutoPrior(d, alignmentScale = "height", sedModel = "site",
              customPriors = list(alpha_s2 = NormalPrior(3, 1)))[["alpha_s2"]],
    NormalPrior(3, 1)
  )
})
