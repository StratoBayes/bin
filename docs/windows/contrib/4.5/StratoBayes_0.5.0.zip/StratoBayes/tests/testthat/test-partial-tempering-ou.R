# Partial tempering under the default OU residuals (#2834). A hot rung whose
# mask tempers the signal or the prior moves lambda and sigma by an MH step on
# the beta-marginal tempered energy, then draws beta from its T = 1
# conditional; a mask tempering neither keeps the T = 1 Gibbs draws. Under OU
# every one of these reads the whitened B'QB, B'Qy and y'Qy. With the alignment
# frozen and swaps off, a hot rung's stationary law is known in closed form
# from a dense Q, built independently of the engine's bidiagonal whitening.
# These are the sigma-sampled laws (integrateSigma = FALSE); test-2810 checks
# the integrated ones.

.HotOuFixture <- function() {
  # Building the model draws random spline fits.
  withr::local_seed(2834)
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12), individualSplineIter = 40, corLength = 1.5,
    integrateSigma = FALSE
  ))
  td <- withr::local_tempdir("ou-pt")
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 50, nChains = 2L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE, modelDir = td,
    modelName = "oupt"
  ))
  model <- result[["model"]]
  model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  rc <- model[["residualCorrelation"]]
  expect_identical(rc[["type"]], "ou")
  expect_true(all(rc[["corLength"]] == 1.5))
  expect_false(model[["sigmaFixed"]])

  data <- result[["data"]]
  rows <- data[[c("signalAttr", "sigs")]][[1]][["signalInd"]]
  z <- data[["signal"]][[data[["zColumn"]]]][rows]
  site <- match(data[["signal"]][[data[["siteColumn"]]]][rows], data[["sites"]])
  y <- data[[c("signalAttr", "signalValuesVec")]][[1]]
  list(model = model, data = data,
       mcmc = readRDS(file.path(td, "oupt_mcmc_run_1.rds")),
       y = y, Q = solve(.OuDenseR(z, site, rep(1.5, length(y)))),
       D = model[[c("splineBase", "D")]],
       priors = model[[c("priors", "gibbs")]])
}

# Chain 2 at `temperature` under `mask`. No swaps, and a point knot window that
# no proposal's ages can satisfy, so every alignment proposal is rejected while
# the Gibbs sweep still runs.
.HotOuRun <- function(fx, mask, temperature, nIter, seed = 2834L) {
  mcmc <- fx[["mcmc"]]
  mcmc[[c("temper", "nSwaps")]] <- 0L
  mcmc[[c("temper", "mask")]] <- mask
  model <- fx[["model"]]
  model[[c("splineBase", "knotRange")]] <-
    rep(mean(model[[c("splineBase", "knotRange")]]), 2)
  withr::local_seed(seed)
  engine <- StratoBayes:::.sb_create_engine(
    fx[["data"]], model, mcmc, mcmc[["recentState"]], tiesCallback = NULL
  )
  StratoBayes:::.sb_update_temperatures(engine, c(1, temperature))
  Step <- function() {
    StratoBayes:::.sb_run_block(engine, 1L)
    StratoBayes:::.sb_extract_state(engine)[[2]]
  }
  first <- Step()
  p <- ncol(first[[c("metro", "B")]][[1]])
  run <- list(B = first[[c("metro", "B")]][[1]], lambda = numeric(nIter),
              sigma = numeric(nIter), beta = matrix(0, nIter, p))
  state <- first
  for (i in seq_len(nIter)) {
    if (i > 1L) state <- Step()
    run[["lambda"]][[i]] <- state[[c("gibbs", "lambda")]]
    run[["sigma"]][[i]] <- state[[c("gibbs", "sigma")]]
    run[["beta"]][i, ] <- state[[c("gibbs", "beta")]][[1]]
  }
  expect_identical(state[[c("metro", "parameters")]],
                   first[[c("metro", "parameters")]])
  run
}

# log of the hot rung's (log lambda, log sigma) density: the tempered
# beta-marginal energy with the engine's dropped constants, plus the Jacobian.
.HotOuTarget <- function(fx, B, Q, wSignal, wPrior) {
  y <- fx[["y"]]
  gp <- fx[["priors"]]
  BtQB <- crossprod(B, Q %*% B)
  BtQy <- drop(crossprod(B, Q %*% y))
  yQy <- drop(crossprod(y, Q %*% y))
  n <- length(y)
  p <- ncol(B)
  function(u, v) {
    lambda <- exp(u)
    sigma <- exp(v)
    if (lambda < gp[["lambdaMin"]]) return(-Inf)
    U <- tryCatch(chol(BtQB / sigma^2 + lambda * fx[["D"]]),
                  error = function(e) NULL)
    if (is.null(U)) return(-Inf)
    w <- backsolve(U, BtQy / sigma^2, transpose = TRUE)
    logMarginal <- -n * v - 0.5 * yQy / sigma^2 + 0.5 * (p - 2) * u +
      0.5 * sum(w^2) - sum(log(diag(U)))
    logPrior <- dgamma(lambda, shape = gp[["aLambda"]],
                       scale = gp[["bLambda"]], log = TRUE) +
      dgamma(1 / sigma^2, shape = gp[["aSigma"]], rate = gp[["bSigma"]],
             log = TRUE) + log(2) - 3 * v
    wSignal * logMarginal + wPrior * logPrior + u + v
  }
}

.GridMoments <- function(logDensity, start, nGrid = 121L) {
  fit <- optim(start, function(x) -logDensity(x[[1]], x[[2]]), hessian = TRUE)
  mode <- fit[["par"]]
  halfWidth <- 9 * sqrt(diag(solve(fit[["hessian"]])))
  u <- seq(mode[[1]] - halfWidth[[1]], mode[[1]] + halfWidth[[1]],
           length.out = nGrid)
  v <- seq(mode[[2]] - halfWidth[[2]], mode[[2]] + halfWidth[[2]],
           length.out = nGrid)
  logGrid <- outer(u, v, Vectorize(logDensity))
  w <- exp(logGrid - max(logGrid))
  w <- w / sum(w)
  pu <- rowSums(w)
  pv <- colSums(w)
  mu <- sum(pu * u)
  mv <- sum(pv * v)
  c(meanLogLambda = mu, meanLogSigma = mv,
    sdLogLambda = sqrt(sum(pu * (u - mu)^2)),
    sdLogSigma = sqrt(sum(pv * (v - mv)^2)),
    edgeMass = sum(w[c(1, nGrid), ]) + sum(w[, c(1, nGrid)]))
}

# Batch means: 20 batches, each far longer than the lambda chain's
# autocorrelation time (about 40 iterations here).
.BatchSe <- function(x, nBatch = 20L) {
  size <- length(x) %/% nBatch
  sd(colMeans(matrix(x[seq_len(size * nBatch)], size))) / sqrt(nBatch)
}

.ChainMoments <- function(run, keep) {
  u <- log(run[["lambda"]][keep])
  v <- log(run[["sigma"]][keep])
  list(
    value = c(meanLogLambda = mean(u), meanLogSigma = mean(v),
              sdLogLambda = sd(u), sdLogSigma = sd(v)),
    se = c(.BatchSe(u), .BatchSe(v),
           .BatchSe((u - mean(u))^2) / (2 * sd(u)),
           .BatchSe((v - mean(v))^2) / (2 * sd(v)))
  )
}

# M^(1/2)'(beta - mu) for the M and mu that the draw at `iter` conditioned on,
# which is the state's own lambda and sigma (`lag = 0`) on a hot rung, and the
# previous state's (`lag = 1`) under the T = 1 Gibbs order.
.BetaZ <- function(fx, run, Q, iter, lag) {
  B <- run[["B"]]
  BtQB <- crossprod(B, Q %*% B)
  BtQy <- drop(crossprod(B, Q %*% fx[["y"]]))
  t(vapply(iter, function(i) {
    sigma <- run[["sigma"]][[i - lag]]
    U <- chol(BtQB / sigma^2 + run[["lambda"]][[i - lag]] * fx[["D"]])
    mu <- backsolve(U, backsolve(U, BtQy / sigma^2, transpose = TRUE))
    drop(U %*% (run[["beta"]][i, ] - mu))
  }, numeric(ncol(B))))
}

# Largest standardised departure of the columns of z from iid N(0, 1), over
# means and variances.
.MaxZDeparture <- function(z) {
  n <- nrow(z)
  max(abs(colMeans(z)) * sqrt(n), abs(apply(z, 2, var) - 1) * sqrt(n / 2))
}

test_that("an OU hot rung samples the tempered lambda/sigma law and beta", {
  skip_on_cran()
  fx <- .HotOuFixture()
  temperature <- 4
  nIter <- 40000L
  keep <- -seq_len(1000L)
  # (wSignal, wPrior) per mask: "signal" holds the prior at T = 1.
  weights <- list(signal = c(1 / temperature, 1),
                  full = c(1 / temperature, 1 / temperature))
  masks <- c(signal = 2L, full = 15L)
  identityQ <- diag(length(fx[["y"]]))
  runs <- list()
  for (tc in names(masks)) {
    run <- .HotOuRun(fx, masks[[tc]], temperature, nIter)
    runs[[tc]] <- run
    chain <- .ChainMoments(run, keep)
    start <- chain[["value"]][c("meanLogLambda", "meanLogSigma")]
    Oracle <- function(Q, w) {
      .GridMoments(.HotOuTarget(fx, run[["B"]], Q, w[[1]], w[[2]]), start)
    }
    Score <- function(oracle) {
      max(abs(chain[["value"]] - oracle[names(chain[["value"]])]) /
            chain[["se"]])
    }
    oracle <- Oracle(fx[["Q"]], weights[[tc]])
    expect_lt(oracle[["edgeMass"]], 1e-4, label = tc)
    expect_lt(Score(oracle), 4, label = tc)

    # The oracle must be able to fail for the reasons #2834 names: unwhitened
    # statistics, an untempered conditional, or the other mask's weights.
    expect_gt(Score(Oracle(identityQ, weights[[tc]])), 10, label = tc)
    expect_gt(Score(Oracle(fx[["Q"]], c(1, 1))), 10, label = tc)
    other <- setdiff(names(weights), tc)
    expect_gt(Score(Oracle(fx[["Q"]], weights[[other]])), 10, label = tc)

    # On a hot rung beta is drawn after lambda and sigma, from their own
    # values, so each z is a fresh N(0, I).
    thinned <- seq(1001L, nIter, by = 4L)
    expect_lt(.MaxZDeparture(.BetaZ(fx, run, fx[["Q"]], thinned, 0L)), 4.5,
              label = tc)
    expect_gt(.MaxZDeparture(.BetaZ(fx, run, identityQ, thinned, 0L)), 20,
              label = tc)
  }

  # "signal+ties" tempers the same lambda/sigma components as "signal", and
  # stratData1 has no ties, so the two chains coincide draw for draw.
  both <- .HotOuRun(fx, 6L, temperature, 500L)
  expect_identical(both[["lambda"]], runs[["signal"]][["lambda"]][1:500])
  expect_identical(both[["sigma"]], runs[["signal"]][["sigma"]][1:500])
  expect_identical(both[["beta"]], runs[["signal"]][["beta"]][1:500, ])
})

test_that("a ties-only mask keeps the whitened T = 1 Gibbs draws when hot", {
  skip_on_cran()
  # Each draw is exact given the state it conditioned on, so its probability
  # integral transform is iid U(0, 1) however slowly the chain mixes.
  fx <- .HotOuFixture()
  nIter <- 20000L
  run <- .HotOuRun(fx, 4L, 4, nIter)
  gp <- fx[["priors"]]
  y <- fx[["y"]]
  B <- run[["B"]]
  p <- ncol(B)
  iter <- 1001:nIter
  SigmaPit <- function(Q) vapply(iter, function(i) {
    r <- y - drop(B %*% run[["beta"]][i, ])
    pgamma(1 / run[["sigma"]][[i]]^2, shape = gp[["aSigma"]] + length(y) / 2,
           rate = gp[["bSigma"]] + 0.5 * drop(crossprod(r, Q %*% r)))
  }, 0)
  lambdaPit <- vapply(iter, function(i) {
    b <- run[["beta"]][i, ]
    Cdf <- function(x) {
      pgamma(x, shape = gp[["aLambda"]] + (p - 2) / 2,
             rate = 1 / gp[["bLambda"]] +
               0.5 * drop(crossprod(b, fx[["D"]] %*% b)))
    }
    floor <- Cdf(gp[["lambdaMin"]])
    (Cdf(run[["lambda"]][[i]]) - floor) / (1 - floor)
  }, 0)
  UniformZ <- function(pit) {
    n <- length(pit)
    max(abs(mean(pit) - 0.5) / sqrt(1 / (12 * n)),
        abs(var(pit) - 1 / 12) / sqrt(1 / (180 * n)))
  }
  expect_lt(UniformZ(SigmaPit(fx[["Q"]])), 4.5)
  expect_gt(UniformZ(SigmaPit(diag(length(y)))), 20)
  expect_lt(UniformZ(lambdaPit), 4.5)
  thinned <- seq(1001L, nIter, by = 2L)
  expect_lt(.MaxZDeparture(.BetaZ(fx, run, fx[["Q"]], thinned, 1L)), 4.5)
  expect_gt(.MaxZDeparture(.BetaZ(fx, run, diag(length(y)), thinned, 1L)), 20)
})
