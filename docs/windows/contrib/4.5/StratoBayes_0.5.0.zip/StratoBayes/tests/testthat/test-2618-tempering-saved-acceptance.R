# #2618: a tempering swap moves states between rungs after each kernel has
# run, so the cold chain's saved `proposal_accepted`/`proposal_number` must
# still describe the cold kernel's own move. The acceptance monitor records
# that move before the swap, so over the monitored window the saved columns
# must tally with it exactly when every iteration is saved.

SavedVsMonitored <- function(engine) {
  data("stratData1", package = "StratoBayes", envir = environment())
  data("stratModel1", package = "StratoBayes", envir = environment())
  td <- tempfile("sb2618_")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE))
  # A close ladder so that swaps are accepted often.
  result <- RunStratModel(
    stratData1, stratModel1, nIter = 400L, nThin = 1L, nChains = 2L,
    temperatures = c(1, 1.05), adaptTemperatures = FALSE,
    nThreads = 1L, runParallel = FALSE, seed = 77L, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "m", engine = engine
  )
  monitor <- readRDS(file.path(td, "m_mcmc_run_1.rds"))[[
    c("metro", "acceptanceMonitor")
  ]]
  coldRows <- result[["samples"]][, , 1L, 1L]
  monitored <- as.integer(rownames(coldRows)) >= monitor[["startMonitoring"]]
  proposal <- factor(coldRows[monitored, "proposal_number"],
                     seq_len(ncol(monitor[["proposalTotal"]])))
  list(
    savedProposals = as.vector(table(proposal)),
    monitorProposals = unname(monitor[["proposalTotal"]][1L, ]),
    savedAccepts = unname(vapply(
      split(coldRows[monitored, "proposal_accepted"], proposal), sum, 0
    )),
    monitorAccepts = unname(monitor[["acceptanceTotal"]][1L, ])
  )
}

test_that("Saved cold-chain acceptance is the cold kernel's own (C++)", {
  skip_on_cran()
  tally <- SavedVsMonitored("cpp")
  expect_equal(tally[["savedProposals"]], tally[["monitorProposals"]])
  expect_equal(tally[["savedAccepts"]], tally[["monitorAccepts"]])
})

test_that("Saved cold-chain acceptance is the cold kernel's own (R)", {
  skip_on_cran()
  tally <- SavedVsMonitored("R")
  expect_equal(tally[["savedProposals"]], tally[["monitorProposals"]])
  expect_equal(tally[["savedAccepts"]], tally[["monitorAccepts"]])
})

test_that(".PermuteChainStates() keeps accept and proposalNumber per slot", {
  state <- list(
    list(metro = list(parameters = 1, accept = TRUE, proposalNumber = 2L)),
    list(metro = list(parameters = 2, accept = FALSE, proposalNumber = 5L))
  )
  swapped <- .PermuteChainStates(state, c(2L, 1L))
  expect_equal(swapped[[1]][[c("metro", "parameters")]], 2)
  expect_true(swapped[[1]][[c("metro", "accept")]])
  expect_equal(swapped[[1]][[c("metro", "proposalNumber")]], 2L)
  expect_equal(swapped[[2]][[c("metro", "parameters")]], 1)
  expect_false(swapped[[2]][[c("metro", "accept")]])
  expect_equal(swapped[[2]][[c("metro", "proposalNumber")]], 5L)
})
