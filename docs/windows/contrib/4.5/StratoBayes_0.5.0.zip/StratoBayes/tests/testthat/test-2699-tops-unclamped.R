# GH #2699: with `refHeightsSite = k`, each draw's reference height is composed
# onward unclamped; only the reference panel's drawing is held to its range.

Draws2699 <- function(n) {
  data("stratPosterior1", package = "StratoBayes", envir = environment())
  selectRows <- ExtractIterations(stratPosterior1, alignment = "all",
                                  burnIn = 0.5, maxSamples = 2500)
  as.matrix(ExtractParameters(stratPosterior1, parameters = "parameters",
                              selectRows = selectRows))[seq_len(n), ]
}

Site3Quantiles <- function(res, ref) {
  rows <- res[res$site == "site_3" & res$refId == ref, ]
  unname(rows$top[order(rows$quantile)])
}

test_that("horizons beyond the reference range keep distinct bands", {
  data("stratPosterior1", package = "StratoBayes")
  res <- suppressWarnings(
    TopsPlot(stratPosterior1, refHeights = c(2.10, 2.19), refHeightsSite = 2,
             quantiles = c(0.1, 0.5, 0.9), parameters = Draws2699(60),
             display = FALSE)
  )
  # under the clamp both horizons collapsed onto the reference top
  expect_true(all(Site3Quantiles(res, 2) > Site3Quantiles(res, 1)))
})

test_that("the reference panel reports unclamped quantiles", {
  data("stratPosterior1", package = "StratoBayes")
  res <- suppressWarnings(
    TopsPlot(stratPosterior1, refHeights = 2.19, refHeightsSite = 2,
             quantiles = c(0.1, 0.5, 0.9), parameters = Draws2699(60),
             display = FALSE)
  )
  refRange <- .RefSiteHeightRange(stratPosterior1[["data"]], 1)
  expect_true(all(res$top[res$site == "site_1"] > refRange[2]))
})

test_that("extrapolation is announced for default refHeights too", {
  data("stratPosterior1", package = "StratoBayes")
  expect_warning(
    TopsPlot(stratPosterior1, refHeightsSite = 2, maxSamples = 60,
             display = FALSE),
    "extrapolated beyond the reference section"
  )
})

test_that("in-range horizons are unchanged", {
  data("stratPosterior1", package = "StratoBayes")
  expect_no_warning(
    res <- TopsPlot(stratPosterior1, refHeights = c(0.5, 1),
                    refHeightsSite = 2, quantiles = c(0.1, 0.5, 0.9),
                    parameters = Draws2699(40), display = FALSE)
  )
  # values recorded before #2699
  expect_equal(
    signif(res$top[res$site != "site_2"], 8),
    c(7.185174, 7.2473971, 7.2909442, 8.1402855, 8.2331849, 8.3194827,
      6.0139778, 6.2237758, 6.4749482, 7.1063525, 7.32895, 7.6854932)
  )
})

test_that("drawing survives low and unconverted reference quantiles", {
  data("stratPosterior1", package = "StratoBayes")
  convert <- .AgeConversionBatch
  # horizon 1 lands below the reference site; horizon 2 falls in no partition
  local_mocked_bindings(.AgeConversionBatch = function(...) {
    r <- convert(...)
    r[1, ] <- r[1, ] - 20
    r[2, ] <- NA
    r
  })
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  res <- suppressWarnings(
    TopsPlot(stratPosterior1, refHeights = c(1, 1.5), refHeightsSite = 2,
             parameters = Draws2699(20))
  )
  refTop <- res$top[res$site == "site_1"]
  refId <- res$refId[res$site == "site_1"]
  expect_true(all(refTop[refId == 1] < 0))
  expect_true(all(is.na(refTop[refId == 2])))
})
