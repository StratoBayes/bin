# With sigma sampled and both the prior and the signal tempered, a rung at T
# has a proper sigma target only while T < n - 1 + 2 * aSigma (#2817).
# stratModel3 samples sigma on one signal of 12 observations: bound 11.02.

test_that(".SigmaTemperatureBound is 2 * shapeSigma - 1 at its smallest", {
  expect_equal(.SigmaTemperatureBound(stratModel3, 15L), 11.02)
  twoSignals <- list(sigmaFixed = FALSE, priors = list(gibbs = list(
    aSigma = c(0.01, 0.01), shapeSigma = c(59.01, 75.51)
  )))
  expect_equal(.SigmaTemperatureBound(twoSignals, 15L), 117.02)
})

test_that("no bound where no rung can reach it", {
  expect_identical(.SigmaTemperatureBound(stratModel1, 15L), Inf)
  for (mask in c(2L, 4L, 6L)) {
    expect_identical(.SigmaTemperatureBound(stratModel3, mask), Inf)
  }
})

test_that("the automatic ladder tops out below the sigma bound", {
  mcmc <- StratMCMC(stratModel3, nIter = 10, nChains = 8)
  temperatures <- mcmc[[c("temper", "temperatures")]]
  expect_equal(temperatures[[8]], .kSigmaCeiling * 11.02)
  expect_true(all(temperatures < 11.02))
  expect_false(is.unsorted(temperatures, strictly = TRUE))
})

test_that("too few observations for any default ladder stop", {
  tiny <- stratModel3
  tiny[[c("priors", "gibbs", "shapeSigma")]][] <- 2.01
  expect_error(StratMCMC(tiny, nIter = 10, nChains = 8),
               "only below temperature 3.02")
})

test_that("an explicit ladder reaching the sigma bound is refused", {
  expect_error(
    StratMCMC(stratModel3, nIter = 10, nChains = 4,
              temperatures = c(1, 3, 6, 11.03)),
    "no proper target for sigma.*n = 12"
  )
  expect_silent(StratMCMC(stratModel3, nIter = 10, nChains = 4,
                          temperatures = c(1, 3, 6, 11)))
  # With no finite top, adaptation would carry the interior rungs past it.
  expect_error(StratMCMC(stratModel3, nIter = 10, nChains = 4,
                         temperatures = c(1, 3, 6, Inf)),
               "`temperatures` has an infinite top rung")
})

test_that("a mask holding the prior at T = 1 is not bounded", {
  mcmc <- StratMCMC(stratModel3, nIter = 10, nChains = 8,
                    temperingComponents = "signal")
  expect_identical(mcmc[[c("temper", "temperatures")]][[8]], 80)
  expect_silent(StratMCMC(stratModel3, nIter = 10, nChains = 4,
                          temperingComponents = "signal",
                          temperatures = c(1, 10, 40, Inf)))
})

test_that("a fixed sigma is not bounded", {
  expect_silent(StratMCMC(stratModel1, nIter = 10, nChains = 4,
                          temperatures = c(1, 10, 40, 1e6)))
})

test_that("a continuation is bounded by the run's own mask", {
  signalRun <- StratMCMC(stratModel3, nIter = 10, nChains = 4,
                         temperingComponents = "signal",
                         temperatures = c(1, 10, 40, 80))
  # Rebuilt at the default mask, as a continuation is; the run's "signal"
  # mask holds the prior at T = 1, so its ladder stands.
  expect_silent(StratMCMC(stratModel3, stratMCMC = signalRun, nIter = 10,
                          completedIter = 10,
                          temperatures = c(1, 10, 40, 80)))
  fullRun <- signalRun
  fullRun[[c("temper", "mask")]] <- 15L
  expect_error(
    StratMCMC(stratModel3, stratMCMC = fullRun, nIter = 10,
              completedIter = 10, temperatures = c(1, 10, 40, 80)),
    "ladder of this continued run reaches 80"
  )
})

test_that("a ladder the bound does not reach is built as before", {
  Build <- function(model, nChains) {
    set.seed(2817)
    StratMCMC(model, nIter = 10, nChains = nChains)
  }
  # Enough observations to put the cap above the default top of 80.
  larger <- stratModel3
  larger[[c("priors", "gibbs", "shapeSigma")]][] <- 40 / .kSigmaCeiling + 2
  # Two chains top out at 1.9, below stratModel3's cap of 0.3 * 11.02.
  for (case in list(list(larger, 8), list(stratModel3, 2))) {
    withBound <- Build(case[[1]], case[[2]])
    withoutBound <- with_mocked_bindings(
      Build(case[[1]], case[[2]]),
      .SigmaTemperatureBound = function(...) Inf
    )
    expect_identical(withBound, withoutBound)
  }
})
