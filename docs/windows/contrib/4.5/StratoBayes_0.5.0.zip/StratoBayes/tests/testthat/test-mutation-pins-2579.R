# Pins for mutants that survived the suite (#2579). Each fails with the
# mutation named in its test applied.

test_that("the run hands the timer its free and posterior columns (#2531)", {
  seen <- new.env()
  orig <- .AdaptTimerCheckpoint
  spy <- function(store, essShare, spent) {
    seen$roles <- store[c("free", "posterior")]
    orig(store, essShare, spent)
  }
  run <- function() {
    RunStratModel(stratData1, stratModel1, nIter = 400, nChains = 2L, seed = 1,
                  quiet = TRUE, nThreads = 1L, runParallel = FALSE,
                  modelDir = withr::local_tempdir(), visualise = FALSE,
                  convergenceStop = FALSE)
  }
  with_mocked_bindings(run(), .AdaptTimerCheckpoint = spy)
  expect_length(seen$roles[["free"]],
                length(stratModel1[[c("ind", "paramNotFixed")]]))
  expect_length(seen$roles[["posterior"]], 1L)
})

TwoSignalTauFixture <- function() {
  set.seed(2541)
  n <- 25
  h <- seq(0, 10, length.out = n)
  signal <- data.frame(
    site = rep(c("s1", "s2"), each = n),
    height = c(h, h),
    zbig = 1000 * (c(sin(h), sin(h) + 4) + rnorm(2 * n, 0, 0.1)),
    asmall = c(cos(h), cos(h) - 4) + rnorm(2 * n, 0, 0.1)
  )
  data <- StratData(
    signal = signal, signalColumn = c("zbig", "asmall"),
    group = data.frame(site = c("s1", "s2"), group = c("A", "B"))
  )
  priors <- structure(
    list(alpha_s2 = NormalPrior(mean = 0, sd = 0.05),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.05)),
    class = c("list", "StratPrior")
  )
  model <- suppressWarnings(suppressMessages(StratModel(
    data, priors, alignmentScale = "height", sedModel = "site", nKnots = 8,
    signalOffsets = TRUE, sigmaFixed = FALSE
  )))
  list(data = data, model = model)
}

test_that("hot rungs draw each signal's tau from its own prior rate (#2557)", {
  fix <- TwoSignalTauFixture()
  post <- suppressWarnings(RunStratModel(
    stratObject = fix$data, stratModel = fix$model, nIter = 400, nThin = 1,
    nChains = 2L, saveChains = 1:2, seed = 2541, quiet = TRUE,
    visualise = FALSE, convergenceStop = FALSE, nThreads = 1L, nCores = 1L,
    runParallel = FALSE
  ))
  draws <- ExtractParameters(post, parameters = c("tau_zbig", "tau_asmall"),
                             burnIn = 0.5, alignment = "all", chain = "chain2")
  expect_equal(stats::median(draws[["tau_zbig"]]) /
                 stats::median(draws[["tau_asmall"]]), 1000, tolerance = 0.5)
})

test_that("a hot chain that never adapts keeps its initial step size", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  RunStratModel(stratData1, stratModel1, nIter = 300, nChains = 2L, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = dir,
                modelName = "s", gradientProposals = "on", nThreads = 1L,
                runParallel = FALSE, convergenceStop = FALSE)
  mcmc <- readRDS(file.path(dir, "s_mcmc_run_1.rds"))
  gradient <- which(colnames(mcmc[[c("metro", "proposalProbability")]]) ==
                      "NUTS")
  step <- vapply(mcmc[[c("metro", "proposalArgs")]],
                 function(args) args[[gradient]][["stepSize"]], numeric(1))
  expect_lt(step[[1]], 0.01)
  expect_equal(step[[2]], sqrt(0.005), tolerance = 1e-6)
})

test_that(".MultiEssFunc refuses runs too short for the covariance", {
  skip_if_not_installed("mcmcse")
  set.seed(1)
  ar1 <- function(n, p) {
    draw <- function(j) as.numeric(stats::arima.sim(list(ar = 0.9), n))
    vapply(seq_len(p), draw, numeric(n))
  }
  for (n in 5:7) {
    expect_true(is.na(.MultiEssFunc(ar1(n, 3L))), info = as.character(n))
  }
})

test_that(".MultiEssFunc is silent on a constant column (#2409)", {
  skip_if_not_installed("mcmcse")
  set.seed(1)
  x <- cbind(stats::rnorm(200), 1, stats::rnorm(200))
  expect_silent(out <- .MultiEssFunc(x))
  expect_identical(out, NA_real_)
})

test_that("AutoPrior validates gammaLog_sd as it does zetaLog_sd (#2536)", {
  for (bad in list(-1, 0, NA_real_, Inf, "a", c(1, 2))) {
    expect_error(AutoPrior(stratData1, gammaLog_sd = bad), "gammaLog_sd")
  }
})

test_that("TruncLogNormDensity rejects non-finite meanlog and sdlog (#2536)", {
  expect_error(TruncLogNormDensity(1, meanlog = Inf),
               "'meanlog' must be finite")
  expect_error(TruncLogNormDensity(1, meanlog = -Inf),
               "'meanlog' must be finite")
  expect_error(TruncLogNormDensity(1, sdlog = Inf),
               "'sdlog' must be positive and finite")
})

test_that(".ValidateRunSelect parses numeric strings (#2536)", {
  expect_identical(.ValidateRunSelect(c("1", "3"), 3L), c(1L, 3L))
  expect_error(.ValidateRunSelect("1.5", 3L), "whole numbers")
  expect_error(.ValidateRunSelect("run", 3L), "whole numbers")
  expect_error(.ValidateRunSelect("4", 3L), "between 1 and 3")
})

test_that("a tie callback is demanded only for ties that are active (#2536)", {
  skip_on_cran()
  set.seed(1)
  n1 <- 30L
  n2 <- 20L
  h1 <- seq(0, 10, length.out = n1)
  h2 <- seq(0, 6, length.out = n2)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(n1, 0, 0.1)),
    data.frame(site = "s2", height = h2,
               value = sin(h2 + 1) + rnorm(n2, 0, 0.1))
  )
  ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                     densityFun = "dnorm", arg1 = 2, arg2 = 3)
  data <- StratData(signal = signal, ties = ties, siteColumn = "site",
                    zColumn = "height", signalColumn = "value")
  priors <- structure(
    list(alpha_s2 = UniformPrior(min = -5, max = 5),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list")
  )
  model <- StratModel(data, priors, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "middle", nKnots = 6,
                      sigmaFixed = 1, flexibleKnots = FALSE,
                      knotRange = c(-15, 25))
  dir <- withr::local_tempdir()
  run <- RunStratModel(data, model, nIter = 10, nChains = 1L, seed = 1,
                       nThreads = 1L, quiet = TRUE, visualise = FALSE,
                       modelDir = dir, modelName = "t",
                       gradientProposals = "off", engine = "cpp")
  mcmc <- readRDS(file.path(dir, "t_mcmc_run_1.rds"))
  model <- run$model
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  build <- function(active) {
    model$tiesActive[] <- active
    .sb_create_engine(run$data, model, mcmc, mcmc$recentState, NULL)
  }

  expect_error(build(c(TRUE, TRUE)), "active ties but no `tiesCallback`")
  expect_error(build(c(FALSE, TRUE)), "active ties but no `tiesCallback`")
  expect_no_error(build(c(FALSE, FALSE)))
  # The reference site's tie is never scored on the height scale.
  expect_no_error(build(c(TRUE, FALSE)))
})
