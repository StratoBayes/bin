Build <- function(...) {
  StratMCMC(stratModel1, nIter = 20, nThreads = 1L, ...)
}

test_that("saveChains must be numeric (#512)", {
  expect_error(Build(saveChains = "1"), "saveChains")
  expect_error(Build(saveChains = TRUE), "saveChains")
  expect_no_error(Build(saveChains = 1))
  expect_no_error(Build(nChains = 2, saveChains = c(1, 2)))
  expect_identical(typeof(Build(saveChains = 1)[["saveChains"]]), "integer")
  expect_identical(Build(nChains = 2, saveChains = c(1, 2))[["saveChains"]],
                   1:2)
})

test_that("nChains and nThin reject logical input (#512)", {
  expect_error(Build(nChains = TRUE), "nChains")
  expect_error(Build(nThin = TRUE), "nThin")
})

test_that("nThreads rejects non-integer values (#514)", {
  expect_error(.ValidateNThreads(2.9), "nThreads")
  expect_error(.ValidateNThreads("2.9"), "nThreads")
  expect_error(.ValidateNThreads(Inf), "nThreads")
  expect_error(StratMCMC(stratModel1, nIter = 20, nThreads = 2.9), "nThreads")
  expect_identical(.ValidateNThreads(2), 2L)
  expect_identical(.ValidateNThreads(2L), 2L)
  expect_identical(.ValidateNThreads("10"), 10L)
})

test_that("a fractional mc.cores option still builds (#514)", {
  withr::local_options(mc.cores = 2.5)
  mcmc <- StratMCMC(stratModel1, nIter = 20, nThreads = NULL)
  expect_identical(mcmc[["nThreads"]], 2L)
})

test_that("a continuation whose nThin stores no new iteration warns (#798)", {
  m1 <- StratMCMC(stratModel1, nIter = 100, nChains = 2, nThin = 10,
                  nThreads = 1L)
  Continue <- function(...) {
    StratMCMC(stratModel1, stratMCMC = m1, completedIter = 100,
              nThreads = 1L, ...)
  }
  expect_warning(Continue(nIter = 10, nThin = 50), "nThin")
  expect_no_warning(Continue(nIter = 10, nThin = 5))
  expect_no_warning(Continue(nIter = Inf, nThin = 50))
})
