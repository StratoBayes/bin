test_that("the survivor floor is the search's, not the candidate's", {
  set.seed(2354)
  iters <- list(1:300, 1:280)
  draws <- lapply(iters, function(it) {
    matrix(rnorm(length(it)), ncol = 1, dimnames = list(NULL, "a"))
  })

  # At 240 the runs keep 60/40 rows and the 40-row run vetoes under the 50-row
  # floor. The next candidate, 255, keeps 45/25: it must not fall back to the
  # 8-row floor and pass a weaker test than the one just refused.
  result <- .AutoBurnInCore(draws, iters, floorIter = 240, grid = 0)
  expect_equal(result[["status"]], "insufficientDraws")
  result <- .AutoBurnInCore(draws, iters, floorIter = 240)
  expect_equal(result[["status"]], "insufficientDraws")

  # The stopping rule judges the rows its store keeps, and must reach the
  # verdict the summary later gives at the same floor.
  Stored <- function(floorIter) {
    stores <- Map(function(it, m) {
      .ConvergenceCollapse(.ConvergenceAppend(
        .ConvergenceStore(), cbind(it, 1, m, deparse.level = 0), cols = 3L,
        floorIter = floorIter
      ))
    }, iters, draws)
    list(lapply(stores, `[[`, "draws"), lapply(stores, `[[`, "iters"))
  }
  for (floorIter in c(240, 255)) {
    store <- Stored(floorIter)
    expect_equal(
      .AutoBurnInCore(draws, iters, floorIter = floorIter, grid = 0),
      .AutoBurnInCore(store[[1]], store[[2]], floorIter = floorIter, grid = 0),
      info = paste("floorIter", floorIter)
    )
  }
  result <- .AutoBurnInCore(draws, iters, floorIter = 255)
  expect_equal(result[["status"]], "ok")

  result <- .AutoBurnInCore(draws, iters)
  expect_equal(result[["status"]], "ok")
  expect_gte(result[["minRunRows"]], 50L)
})

test_that("the stop and the summary agree at a 50-row floor (#2704)", {
  set.seed(2704)
  iters <- list(1:300, 1:300)
  draws <- lapply(iters, function(it) {
    matrix(rnorm(length(it)), ncol = 1, dimnames = list(NULL, "a"))
  })
  stores <- Map(function(it, m) {
    .ConvergenceCollapse(.ConvergenceAppend(
      .ConvergenceStore(), cbind(it, 1, m, deparse.level = 0), cols = 3L,
      floorIter = 250
    ))
  }, iters, draws)
  inRun <- .AutoBurnInCore(lapply(stores, `[[`, "draws"),
                           lapply(stores, `[[`, "iters"),
                           floorIter = 250, stopAtFirst = TRUE)
  postHoc <- .AutoBurnInCore(draws, iters, floorIter = 250, stopAtFirst = TRUE)
  expect_identical(postHoc[["status"]], "ok")
  expect_identical(postHoc[["iteration"]], 250)
  expect_identical(postHoc[["minRunRows"]], 50L)
  expect_identical(inRun[c("status", "iteration", "minRunRows")],
                   postHoc[c("status", "iteration", "minRunRows")])
})
