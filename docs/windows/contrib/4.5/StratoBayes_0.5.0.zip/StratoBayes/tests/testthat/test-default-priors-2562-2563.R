# Default priors scale with the data: bLambda = 1e4 * lambdaStar both ways,
# lambdaStar from within-site (within-group under offsets) variance (#2562);
# bSigma = half the pooled per-site spline noise variance (#2563).

kKnots <- 10L
kHeights <- list(s1 = seq(0, 50, length.out = 60),
                 s2 = seq(0, 50, length.out = 40),
                 s3 = seq(0, 50, length.out = 10))

# Deterministic stand-in for noise, uncorrelated with the heights.
Jitter <- function(n) 0.6 * ((seq_len(n) * 7919L) %% 97L / 97 - 0.5)

PriorSignal <- function(k = 1, hMul = 1, shift = c(0, 0, 0)) {
  values <- Map(function(h, phase, s) sin(h / 8 + phase) +
                  Jitter(length(h)) + s,
                kHeights, c(0, 1, 2), shift)
  data.frame(site = rep(names(kHeights), lengths(kHeights)),
             height = unlist(kHeights, use.names = FALSE) * hMul,
             value = k * unlist(values, use.names = FALSE))
}

PriorData <- function(signal, group = NULL) {
  suppressMessages(StratData(signal, group = group))
}

PriorModel <- function(data, ...) {
  suppressMessages(
    StratModel(data, alignmentScale = "height", sedModel = "site",
               nKnots = kKnots, flexibleKnots = FALSE, ...,
               residualCorrelation = "none")
  )
}

# Pooled within-group variance: a one-point group contributes no information.
WithinVariance <- function(y, groups) {
  sum((y - stats::ave(y, groups))^2) / (length(y) - length(unique(groups)))
}

HandLambdaStar <- function(model, y, groups) {
  base <- model[["splineBase"]]
  unname(base[["num_basis"]] /
           (WithinVariance(y, groups) * sum(diag(base[["D"]]))))
}

# Residual variance of an unpenalised cubic B-spline with `nKnots` equally
# spaced knots over the site's own range, independent of the package's basis.
OlsFit <- function(x, y, nKnots = kKnots) {
  inner <- seq(min(x), max(x), length.out = nKnots)[-c(1, nKnots)]
  fit <- stats::lm(y ~ splines::bs(x, knots = inner, intercept = TRUE) - 1)
  c(rss = sum(stats::residuals(fit)^2), df = fit[["df.residual"]])
}

PooledNoise <- function(signal, nKnots = kKnots) {
  fits <- lapply(split(signal, signal[["site"]]), function(s) {
    if (nrow(s) < nKnots + 2L + 5L) return(NULL)
    OlsFit(s[["height"]], s[["value"]], nKnots)
  })
  fits <- do.call(rbind, fits)
  sum(fits[, "rss"]) / sum(fits[, "df"])
}

test_that("default bLambda is 1e4 * lambdaStar in every unit (#2562)", {
  ratios <- numeric(0)
  stars <- numeric(0)
  for (k in c(1e-3, 1, 1e3)) for (hMul in c(1e-2, 1, 1e2)) {
    model <- PriorModel(PriorData(PriorSignal(k, hMul)), sigmaFixed = 1)
    gibbs <- model[[c("priors", "gibbs")]]
    star <- gibbs[["lambdaMin"]] / .LambdaFloorRel
    ratios <- c(ratios, gibbs[["bLambda"]] / star)
    stars <- c(stars, star)
  }
  expect_equal(unname(ratios), rep(1e4, length(ratios)))
  # Two-way: units that put lambdaStar below 0.1 lower bLambda below 1000.
  expect_true(any(1e4 * stars < 1000))
})

test_that("an explicit bLambda is untouched by the scale rule (#2562)", {
  model <- PriorModel(PriorData(PriorSignal(1e3)), sigmaFixed = 1,
                      bLambda = 1000)
  expect_identical(model[[c("priors", "gibbs", "bLambda")]], 1000)
})

test_that("lambdaStar ignores between-site levels (#2562)", {
  flat <- PriorData(PriorSignal())
  shifted <- PriorData(PriorSignal(shift = c(0, 100, -40)))
  modelFlat <- PriorModel(flat, sigmaFixed = 1)
  modelShifted <- PriorModel(shifted, sigmaFixed = 1)
  expect_equal(modelShifted[[c("priors", "gibbs", "lambdaMin")]],
               modelFlat[[c("priors", "gibbs", "lambdaMin")]])
  sig <- PriorSignal(shift = c(0, 100, -40))
  expect_equal(
    unname(modelShifted[[c("priors", "gibbs", "lambdaMin")]]) /
      .LambdaFloorRel,
    HandLambdaStar(modelShifted, sig[["value"]], sig[["site"]])
  )
})

test_that("under signalOffsets lambdaStar centres within offset groups (#2562)",
          {
            group <- data.frame(site = names(kHeights),
                                group = c("A", "A", "B"))
            sig <- PriorSignal(shift = c(0, 0, 100))
            modelShifted <- PriorModel(PriorData(sig, group),
                                       sigmaFixed = 1, signalOffsets = TRUE)
            modelFlat <- PriorModel(PriorData(PriorSignal(), group),
                                    sigmaFixed = 1, signalOffsets = TRUE)
            expect_equal(modelShifted[[c("priors", "gibbs", "lambdaMin")]],
                         modelFlat[[c("priors", "gibbs", "lambdaMin")]])
            expect_equal(
              unname(modelShifted[[c("priors", "gibbs", "lambdaMin")]]) /
                .LambdaFloorRel,
              HandLambdaStar(modelShifted, sig[["value"]],
                             ifelse(sig[["site"]] == "s3", "B", "A"))
            )
          })

test_that("default bSigma is half the pooled spline noise variance (#2563)", {
  for (k in c(1e-3, 1, 1e3)) {
    sig <- PriorSignal(k)
    model <- PriorModel(PriorData(sig), sigmaFixed = 1)
    # s3's 10 points cannot fit a 12-function basis with 5 to spare
    expect_equal(model[[c("priors", "gibbs", "bSigma")]],
                 PooledNoise(sig) / 2)
  }
})

test_that("seeding splines take their own site's noise, or the pool (#2563)", {
  record <- new.env()
  local_mocked_bindings(
    BayesianSpline = function(x, y, nKnots, nIter, aLambda, bLambda, aSigma,
                              bSigma) {
      record[["seen"]] <- rbind(record[["seen"]],
                                c(n = length(x), bSigma = bSigma))
      list(sigma = rep(0.1, nIter))
    }
  )
  sig <- PriorSignal(1e2)
  PriorModel(PriorData(sig))
  seen <- record[["seen"]]
  own <- vapply(split(sig, sig[["site"]])[c("s1", "s2")], function(s) {
    fit <- OlsFit(s[["height"]], s[["value"]])
    fit[["rss"]] / fit[["df"]] / 2
  }, numeric(1))
  expect_equal(unname(seen[seen[, "n"] == 60, "bSigma"]), own[["s1"]])
  expect_equal(unname(seen[seen[, "n"] == 40, "bSigma"]), own[["s2"]])
  expect_equal(unname(seen[seen[, "n"] == 10, "bSigma"]), PooledNoise(sig) / 2)
})

test_that("with no site large enough, bSigma falls back on differences (#2563)",
          {
            sig <- PriorSignal()
            sig <- sig[sig[["site"]] == "s3" |
                         ave(seq_len(nrow(sig)), sig[["site"]],
                             FUN = seq_along) <= 12L, ]
            model <- PriorModel(PriorData(sig), sigmaFixed = 1)
            rice <- lapply(split(sig, sig[["site"]]), function(s) {
              diff(s[["value"]][order(s[["height"]])])
            })
            expected <- sum(unlist(rice)^2) /
              (2 * sum(lengths(rice))) / 2
            expect_equal(model[[c("priors", "gibbs", "bSigma")]], expected)
          })

test_that("user bSigma and the constant-signal fallback are kept (#2563)", {
  model <- PriorModel(PriorData(PriorSignal()), sigmaFixed = 1, bSigma = 0.5)
  expect_identical(model[[c("priors", "gibbs", "bSigma")]], 0.5)

  constant <- .ModelBspline(data.frame(x = 1:30, y = rep(2, 30)), kKnots,
                            NULL, 1, NULL, 1, 1000, NULL, FALSE, NULL, NULL)
  expect_identical(constant[[c("priors", "gibbs", "bSigma")]], 0.01)
})

test_that("BayesianSpline's default bSigma is half its OLS noise (#2563)", {
  x <- kHeights[["s1"]]
  y <- sin(x / 8) + Jitter(length(x))
  for (k in c(1e-3, 1e3)) {
    model <- .ModelBspline(data.frame(x = x, y = k * y), kKnots, NULL, 1,
                           NULL, 1, 1000, NULL, FALSE, NULL, NULL)
    fit <- OlsFit(x, k * y)
    expect_equal(model[[c("priors", "gibbs", "bSigma")]],
                 fit[["rss"]] / fit[["df"]] / 2)
  }
})

test_that("the Gibbs lambda seed is centred as the floor is (#2562)", {
  data <- PriorData(PriorSignal(shift = c(0, 1e4, -1e4)))
  model <- PriorModel(data, sigmaFixed = 1)
  state <- list(gibbs = list(lambda = list(1), beta = list(0)),
                age = list(signalFlat = data[["signal"]][["height"]]))
  local_mocked_bindings(.UpdateSigma = function(data, model, state, m) state)
  seed <- .InitializeGibbs(data, model, state)[[c("gibbs", "lambda")]][[1]]
  expect_equal(seed,
               model[[c("priors", "gibbs", "lambdaMin")]][[1]] /
                 .LambdaFloorRel, ignore_attr = TRUE)
})

test_that("an exactly fitted signal still gets a scaled bSigma (#2563)", {
  rates <- vapply(c(1e-3, 1, 1e3), function(k) {
    sig <- PriorSignal()
    sig[["value"]] <- k * (sig[["height"]] / 10 + (sig[["site"]] == "s2"))
    PriorModel(PriorData(sig), sigmaFixed = 1)[[c("priors", "gibbs",
                                                  "bSigma")]]
  }, numeric(1))
  expect_equal(rates / c(1e-3, 1, 1e3)^2, rep(rates[[2]], 3))
  expect_gt(rates[[2]], 0)
  expect_false(rates[[2]] == 0.01)
})
