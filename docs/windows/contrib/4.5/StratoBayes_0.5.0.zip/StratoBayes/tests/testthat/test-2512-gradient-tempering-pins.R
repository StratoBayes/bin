# The C++ HMC/NUTS accept steps and their beta-marginal refresh; the MH accept
# step and the swaps under signal-only tempering.
#
# Invariants, not trajectories: the engine's own output is not bit-reproducible
# across platforms (#1477), so each pin is an identity (a stored logPost equals
# a fresh evaluation; a swap decision equals the Metropolis rule on the
# recorded energies) or a coarse property of a T = 1e8 rung, whose target is
# flat over the support under full tempering but keeps every untempered
# component under signal-only tempering.

GradientWarmStart2512 <- function(priors, nChains, components, gradient,
                                  seed) {
  data(list = c("stratData1", "stratModel1"), package = "StratoBayes",
       envir = environment())
  model <- StratModel(stratData1, priors = priors,
                      alignmentScale = stratModel1[["alignmentScale"]],
                      sedModel = stratModel1[["sedModel"]],
                      sigmaFixed = FALSE, flexibleKnots = FALSE,
                      knotRange = c(-12, 20),
                      # Gradient proposals need sigma sampled, not integrated
                      # out (#2810).
                      integrateSigma = FALSE)
  td <- tempfile("grad2512")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 150L,
    nChains = nChains, tempering = nChains > 2L,
    temperingComponents = components, gradientProposals = gradient,
    quiet = TRUE, visualise = FALSE, nThreads = 1L, nRun = 1L, seed = seed,
    modelDir = td, modelName = "s"
  ))
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))
  model <- result[["model"]]
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  list(data = result[["data"]], model = model, mcmc = mcmc)
}

FreePriors2512 <- function() {
  list(alpha_site_2 = UniformPrior(-6, 12), alpha_site_3 = UniformPrior(-2, 8),
       gammaLog_site_2 = NormalPrior(0, 0.5),
       gammaLog_site_3 = NormalPrior(0, 0.5))
}

# Every iteration runs `proposal`. `gradientProposals = "on"` registers NUTS
# only; HMC is reached by renaming that slot, which is what the engine keys on,
# and giving it HMC's own arguments.
OnlyGradient2512 <- function(fx, proposal) {
  mcmc <- fx[["mcmc"]]
  slot <- which(names(mcmc[["propose"]]) == "NUTS")
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, slot] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  mcmc[[c("metro", "proposalValid")]][, slot] <- TRUE
  if (proposal == "HMC") {
    names(mcmc[["propose"]])[slot] <- "HMC"
    for (field in c("proposalProbability", "proposalProbabilityWeights",
                    "proposalFactor", "proposalValid")) {
      m <- mcmc[[c("metro", field)]]
      if (!is.null(colnames(m))) colnames(m)[slot] <- "HMC"
      mcmc[[c("metro", field)]] <- m
    }
    for (ch in seq_along(mcmc[[c("metro", "proposalArgs")]])) {
      mcmc[[c("metro", "proposalArgs")]][[ch]][[slot]] <-
        .HMCDefaultArgs(fx[["model"]])
    }
  }
  fx[["mcmc"]] <- mcmc
  fx
}

NewEngine2512 <- function(fx) {
  .sb_create_engine(fx[["data"]], fx[["model"]], fx[["mcmc"]],
                    fx[["mcmc"]][["recentState"]])
}

# One iteration at a time, recording each chain's parameters, accept flag and
# stored logPost beside a fresh evaluation of the beta-marginal at its state.
Drive2512 <- function(engine, nIter, nChains) {
  stored <- fresh <- matrix(NA_real_, nIter, nChains)
  accept <- matrix(NA, nIter, nChains)
  params <- vector("list", nChains)
  for (i in seq_len(nIter)) {
    .sb_run_block(engine, 1L)
    state <- .sb_extract_state(engine)
    for (ch in seq_len(nChains)) {
      metro <- state[[ch]][["metro"]]
      stored[i, ch] <- metro[["logPost"]]
      fresh[i, ch] <- .sb_eval_logpost(engine, ch, metro[["parameters"]],
                                       marginal = TRUE)
      accept[i, ch] <- isTRUE(metro[["accept"]])
      params[[ch]] <- rbind(params[[ch]], metro[["parameters"]])
    }
  }
  list(stored = stored, fresh = fresh, accept = accept, params = params)
}

test_that("NUTS and HMC accept, and refresh the stored logPost (#2512)", {
  set.seed(2512)
  fx <- GradientWarmStart2512(FreePriors2512(), 2L, "full", "on", seed = 11L)
  start <- vapply(fx[[c("mcmc", "recentState")]],
                  function(s) s[[c("metro", "logPost")]], numeric(1))
  for (proposal in c("NUTS", "HMC")) {
    engine <- NewEngine2512(OnlyGradient2512(fx, proposal))
    set.seed(1)
    run <- Drive2512(engine, 300L, 2L)
    # The trajectory's start must be scored on the joint at the current beta,
    # as its end is; scoring it on the stored beta-marginal rejects them all.
    expect_gt(sum(run[["accept"]]), 0)
    # Without the post-step refresh the stored value is the joint, nats away
    # from the beta-marginal that the next MH ratio and every swap read.
    expect_equal(run[["stored"]], run[["fresh"]], tolerance = 1e-8,
                 label = paste(proposal, "stored logPost"))
    # From a warm start a valid kernel holds its chains' logPost within a few
    # nats; flipping the kinetic-energy sign drains it by tens to hundreds.
    expect_gt(min(colMeans(run[["stored"]][201:300, ]) - start), -12,
              label = paste(proposal, "logPost drift"))
  }
})

test_that("gradient proposals run on the cold rung only (#2545)", {
  # Hot rungs take the tempered (lambda, sigma) step instead of a gradient
  # trajectory, so an HMC-only kernel never accepts there, at any temperature;
  # the cold rung still does, and keeps its stored logPost fresh.
  set.seed(2512)
  fx <- GradientWarmStart2512(FreePriors2512(), 3L, "full", "on", seed = 11L)
  engine <- NewEngine2512(OnlyGradient2512(fx, "HMC"))
  .sb_update_temperatures(engine, c(1, 10, 1e8))
  set.seed(1)
  run <- Drive2512(engine, 300L, 3L)

  expect_gt(sum(run[["accept"]][, 1]), 0)
  expect_identical(sum(run[["accept"]][, -1]), 0L)
  expect_equal(run[["stored"]][, 1], run[["fresh"]][, 1], tolerance = 1e-8)
})

test_that("a gradient self-transition refreshes the stored logPost (#2512)", {
  # With every alignment parameter Fixed() there is nothing to integrate, so
  # each NUTS iteration is a self-transition: a Gibbs sweep, then a refresh.
  priors <- list(alpha_site_2 = Fixed(5), alpha_site_3 = Fixed(5),
                 gammaLog_site_2 = Fixed(0), gammaLog_site_3 = Fixed(0))
  set.seed(2512)
  fx <- GradientWarmStart2512(priors, 1L, "full", "on", seed = 3L)
  expect_identical(fx[[c("model", "parametersLengthNotFixed")]], 0L)
  engine <- NewEngine2512(OnlyGradient2512(fx, "NUTS"))
  set.seed(1)
  run <- Drive2512(engine, 5L, 1L)

  expect_false(any(run[["accept"]]))
  # Non-vacuous: the sweep moves logPost, so a missing refresh leaves it stale.
  expect_gt(length(unique(run[["fresh"]])), 1L)
  expect_equal(run[["stored"]], run[["fresh"]], tolerance = 1e-8)
})

test_that("signal-only tempering swaps and accepts on its own energy (#2512)", {
  set.seed(2512)
  fx <- GradientWarmStart2512(FreePriors2512(), 3L, "signal", "off",
                              seed = 11L)
  nChains <- 3L
  temperatures <- c(1, 1.1, 1.2)

  # Decisions: `temper_step` draws R's uniforms, in this order: the pair, then
  # the accept test. Replaying them against the energies the engine recorded
  # for the swap must reproduce every decision. A single block is run, so the
  # only other draws are the per-chain seeds the first block takes.
  engine <- NewEngine2512(fx)
  .sb_update_temperatures(engine, temperatures)
  set.seed(1)
  .sb_run_block(engine, 300L)
  ring <- .sb_get_ring_buffer(engine)
  energy <- matrix(ring[["swapEnergy"]], ncol = nChains, byrow = TRUE)
  swapOrder <- ring[["temperSwapOrder"]]
  swapAccept <- ring[["temperAccept"]]
  pairs <- fx[[c("mcmc", "temper", "swapIndices")]]
  expect_identical(ncol(swapAccept), nrow(pairs))

  set.seed(1)
  stats::runif(nChains)
  replayed <- matrix(FALSE, nrow(swapAccept), ncol(swapAccept))
  replayedOrder <- matrix(NA_integer_, nrow(swapOrder), ncol(swapOrder))
  for (i in seq_len(nrow(swapOrder))) {
    e <- energy[i, ]
    pool <- seq_len(ncol(swapAccept))
    for (s in seq_len(ncol(swapOrder))) {
      n <- length(pool)
      pick <- min(floor(stats::runif(1L) * n) + 1L, n)
      pair <- pool[[pick]]
      pool[[pick]] <- pool[[n]]
      pool <- pool[-n]
      replayedOrder[i, s] <- pair
      c1 <- pairs[pair, 1L]
      c2 <- pairs[pair, 2L]
      ratio <- exp((e[[c2]] - e[[c1]]) *
                     (1 / temperatures[[c1]] - 1 / temperatures[[c2]]))
      replayed[i, pair] <- stats::runif(1L) < ratio
      if (swapAccept[i, pair]) e[c(c1, c2)] <- e[c(c2, c1)]
    }
  }
  # Non-vacuous: the ladder both swaps and refuses swaps, and the energies are
  # finite and not the full logPost.
  expect_true(all(is.finite(energy)))
  expect_gt(sum(swapAccept), 0L)
  expect_lt(sum(swapAccept), length(swapOrder))
  expect_gt(mean(abs(energy - matrix(ring[["logPost"]], ncol = nChains,
                                     byrow = TRUE))), 1)
  expect_identical(replayedOrder, unname(swapOrder))
  expect_identical(replayed, unname(swapAccept))

  # Execution: an accepted swap moves the states between rungs, and the energy
  # recorded for each is its signal term alone.
  engine <- NewEngine2512(fx)
  .sb_update_temperatures(engine, temperatures)
  set.seed(2)
  moved <- recorded <- held <- signal <- fresh <- numeric()
  for (i in seq_len(100L)) {
    .sb_run_block(engine, 1L)
    ring <- .sb_get_ring_buffer(engine)
    from <- seq_len(nChains)
    for (pair in ring[["temperSwapOrder"]][1, ]) {
      if (ring[["temperAccept"]][1, pair]) {
        from[pairs[pair, ]] <- from[rev(pairs[pair, ])]
      }
    }
    state <- .sb_extract_state(engine)
    moved <- c(moved, sum(from != seq_len(nChains)))
    recorded <- c(recorded, ring[["logPost"]][from])
    held <- c(held, vapply(state, function(s) s[[c("metro", "logPost")]], 1))
    signal <- c(signal, ring[["swapEnergy"]][from])
    for (ch in seq_len(nChains)) {
      fresh <- c(fresh, .sb_eval_logpost(
        engine, ch, state[[ch]][[c("metro", "parameters")]],
        debug = TRUE, marginal = TRUE
      )[["logPostSep"]][[2]])
    }
  }
  expect_gt(sum(moved), 0)
  expect_identical(held, recorded)
  expect_equal(signal, fresh, tolerance = 1e-8)

  # MH: at T = 1e8 a signal-tempered rung still scores its untempered
  # components at T = 1, so it rejects many proposals; tempering every
  # component instead leaves only the support checks to reject them.
  engine <- NewEngine2512(fx)
  .sb_update_temperatures(engine, c(1, 1e8, 1e8))
  set.seed(1)
  run <- Drive2512(engine, 300L, nChains)
  expect_lt(mean(run[["accept"]][, -1]), 0.67)
  expect_equal(run[["stored"]][, 1], run[["fresh"]][, 1], tolerance = 1e-8)
})
