test_that(".StopSentinelExists() returns a logical before and after a write", {
  dir <- withr::local_tempdir()
  expect_false(.StopSentinelExists(dir, "m"))
  expect_null(.WriteStopSentinel(dir, "m"))
  expect_true(.StopSentinelExists(dir, "m"))
  expect_null(.ClearStopSentinel(dir, "m"))
  expect_false(.StopSentinelExists(dir, "m"))
})
