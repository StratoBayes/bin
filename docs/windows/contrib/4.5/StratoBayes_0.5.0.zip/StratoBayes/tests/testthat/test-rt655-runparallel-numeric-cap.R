# Targeted regression test for RT-655
# (see https://github.com/StratoBayes/StratoBayes-R-package/issues/836).
#
# `nCores` is a local inside RunStratModel()'s body, not something returned
# to the caller, so both cases below observe its derived value indirectly
# via the oversubscription warning at RunStratModel.R:924-932 (also
# exercised by RT-352 in test-rt347-348-351-352-runstratmodel-guards.R).
# With `.AvailableCores()` mocked to 1 and `nThreads = 1L`, a numeric
# `runParallel = 1` caps `nCores` at `min(nRun, runParallel) = 1`, giving
# 1 x 1 = 1 thread -- not > 1 available, so no warning. An explicit
# `nCores = 2L` overrides that cap, giving 2 x 1 = 2 threads -- warns.
.MuffleParallellyWarning <- function(expr) {
  withCallingHandlers(expr, warning = function(w) {
    if (grepl("localhost parallel workers", conditionMessage(w),
              fixed = TRUE)) {
      invokeRestart("muffleWarning")
    }
  })
}

test_that("RT-655: numeric runParallel caps nCores", {
  skip_if_not_installed("future.apply")
  testthat::local_mocked_bindings(
    .AvailableCores = function() 1L
  )

  .MuffleParallellyWarning(
    expect_no_warning(
      RunStratModel(
        stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
        nChains = 2, nThreads = 1L, visualise = FALSE, seed = 1:2,
        runParallel = 1, quiet = TRUE
      )
    )
  )
})

test_that("RT-655: explicit nCores overrides numeric runParallel", {
  skip_if_not_installed("future.apply")
  testthat::local_mocked_bindings(
    .AvailableCores = function() 1L
  )

  .MuffleParallellyWarning(
    expect_warning(
      RunStratModel(
        stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
        nChains = 2, nThreads = 1L, visualise = FALSE, seed = 1:2,
        runParallel = 1, nCores = 2L, quiet = TRUE
      ),
      "oversubscribe available CPU cores"
    )
  )
})
