MakeUnif <- function(R = function(n, a, b) runif(n, a, b),
                     D = function(x, a, b, log = FALSE) {
                       dunif(x, a, b, log = log)
                     },
                     Q = function(p, a, b) qunif(p, a, b)) {
  structure(list(a = Prior(R, D, Q, a = 0, b = 10)), class = "StratPrior")
}

test_that("a warning in a prior function is reported once, no 'Error in'", {
  Message <- function(priors) {
    tryCatch(.PriorsValidity(priors), error = conditionMessage)
  }
  expect_identical(
    Message(MakeUnif(R = function(n, a, b) {
      warning("boom")
      runif(n, a, b)
    })),
    "Warning in R function of prior 'a': boom"
  )
  expect_identical(
    Message(MakeUnif(Q = function(p, a, b) {
      warning("boom")
      qunif(p, a, b)
    })),
    "Warning in Q function of prior 'a': boom"
  )
  expect_identical(
    Message(MakeUnif(D = function(x, a, b, log = FALSE) {
      warning("boom")
      dunif(x, a, b, log = log)
    })),
    "Warning in D function of prior 'a': boom"
  )
})

test_that("an error in a prior function keeps the single 'Error in' wrapper", {
  expect_error(
    .PriorsValidity(MakeUnif(R = function(n, a, b) stop("boom"))),
    "^Error in R function of prior 'a': boom$"
  )
})

test_that("a NULL-valued prior argument is validated as production calls it", {
  nullSd <- structure(
    list(a = Prior(rnorm, dnorm, qnorm, mean = 0, sd = NULL)),
    class = "StratPrior"
  )
  expect_error(.PriorsValidity(nullSd), "prior 'a'")

  expect_true(.PriorsValidity(structure(
    list(a = Prior(rnorm, dnorm, qnorm, mean = 0, sd = 1)),
    class = "StratPrior"
  )))
  expect_true(.PriorsValidity(MakeUnif()))
})

test_that("a prior whose R ignores n is rejected at validation", {
  set.seed(1)
  scalarR <- MakeUnif(R = function(n, a, b) a + (b - a) * runif(1))
  expect_error(.PriorsValidity(scalarR), "prior 'a' returned 1 value")
  expect_true(.PriorsValidity(MakeUnif()))
})

test_that("the package's own prior constructors return n draws", {
  priors <- list(
    NormalPrior(0, 1), TruncNormalPrior(0, 1, -2, 2), LogNormalPrior(0, 1),
    UniformPrior(0, 1), ExponentialPrior(1), Fixed(2)
  )
  for (pri in priors) {
    expect_length(do.call(pri[["R"]], c(list(n = 2L), pri[["args"]])), 2L)
  }
})
