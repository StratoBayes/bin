.LasFolder <- function() {
  system.file("extdata", "lasData", package = "StratoBayes", mustWork = TRUE)
}
