# The default model has OU-correlated residuals and a sampled sigma, and falls
# back to independent residuals where OU is unsupported (signal offsets, the R
# engine) unless OU was asked for explicitly.

.DefaultRun <- function(..., envir = parent.frame()) {
  data("stratData0", package = "StratoBayes", envir = environment())
  RunStratModel(
    stratObject = stratData0, alignmentScale = "height", sedModel = "site",
    nKnots = 10, individualSplineIter = 40, nIter = 20, nChains = 2,
    nThreads = 1L, seed = 1, quiet = TRUE, visualise = FALSE,
    convergenceStop = FALSE,
    modelDir = withr::local_tempdir("ou-default", .local_envir = envir), ...
  )
}

test_that("StratModel() defaults to OU residuals with a sampled sigma", {
  data("stratData0", package = "StratoBayes", envir = environment())
  model <- suppressMessages(StratModel(
    stratData0, alignmentScale = "height", sedModel = "site", nKnots = 10,
    individualSplineIter = 40
  ))
  expect_identical(model$residualCorrelation$type, "ou")
  expect_false(model$sigmaFixed)
})

test_that("signalOffsets uses independent residuals unless 'ou' is explicit", {
  data("signalData0", package = "StratoBayes", envir = environment())
  grouped <- StratData(signal = signalData0,
                       group = c(site1 = "G1", site2 = "G2"))
  Build <- function(...) StratModel(
    grouped, alignmentScale = "height", sedModel = "site", nKnots = 10,
    individualSplineIter = 40, signalOffsets = TRUE, ...
  )
  expect_message(model <- Build(),
                 "`signalOffsets = TRUE` needs independent residuals",
                 fixed = TRUE)
  expect_null(model$residualCorrelation)
  expect_true(is.numeric(model$sigmaFixed))
  expect_error(Build(residualCorrelation = "ou"),
               "does not support `signalOffsets`", fixed = TRUE)
})

test_that("RunStratModel() builds the default model and forwards arguments", {
  ou <- suppressMessages(.DefaultRun())$model
  expect_identical(ou$residualCorrelation$type, "ou")
  expect_false(ou$sigmaFixed)

  given <- suppressMessages(.DefaultRun(corLength = 2, sigmaFixed = 0.5))$model
  expect_true(all(given$residualCorrelation$corLength == 2))
  expect_equal(unname(given$sigmaFixed), 0.5)

  none <- suppressMessages(.DefaultRun(residualCorrelation = "none"))$model
  expect_null(none$residualCorrelation)
  expect_true(is.numeric(none$sigmaFixed))
})

test_that("only engine R makes RunStratModel() use independent residuals", {
  expect_message(rEngine <- .DefaultRun(engine = "R"),
                 "`engine = \"R\"` needs independent residuals", fixed = TRUE)
  expect_null(rEngine$model$residualCorrelation)

  expect_no_message(nuts <- .DefaultRun(gradientProposals = "on"),
                    message = "needs independent residuals")
  expect_identical(nuts$model$residualCorrelation$type, "ou")

  expect_error(suppressMessages(.DefaultRun(engine = "R",
                                            residualCorrelation = "ou")),
               "C++ engine only", fixed = TRUE)
})

test_that("a prebuilt OU model with the R engine names the fix", {
  data("stratData0", package = "StratoBayes", envir = environment())
  model <- suppressMessages(StratModel(
    stratData0, alignmentScale = "height", sedModel = "site", nKnots = 10,
    individualSplineIter = 40
  ))
  expect_error(
    RunStratModel(stratData0, model, nIter = 20, nChains = 2, quiet = TRUE,
                  visualise = FALSE, convergenceStop = FALSE, engine = "R",
                  modelDir = withr::local_tempdir("ou-default")),
    "StratModel(residualCorrelation = \"none\")", fixed = TRUE
  )
})
