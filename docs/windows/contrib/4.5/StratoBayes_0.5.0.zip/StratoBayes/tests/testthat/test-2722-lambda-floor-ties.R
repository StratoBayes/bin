# The lambda floor under flexibleKnots is keyed to the signal-age span that
# precise ties identify, not to the span at the prior medians (#2722).

kRate <- 100
kAlpha <- c(s1 = 10, s2 = 10.1)
kTieHeights <- c(5, 45)

FloorSignal <- function() {
  set.seed(11)
  h1 <- sort(runif(80, 0, 50))
  h2 <- sort(runif(80, 0, 50))
  ages <- c(kAlpha[["s1"]] - h1 / kRate, kAlpha[["s2"]] - h2 / kRate)
  data.frame(site = rep(c("s1", "s2"), each = 80), height = c(h1, h2),
             value = sin(2 * pi * ages / 0.15) + 2 * (ages - 9.8) +
               rnorm(160, 0, 0.15))
}

FloorTies <- function(sd = 0.05, sites = c("s1", "s2"), heights = kTieHeights) {
  data.frame(
    site = rep(sites, each = length(heights)),
    height = heights,
    densityFun = "dnorm",
    arg1 = rep(kAlpha[sites], each = length(heights)) - heights / kRate,
    arg2 = sd
  )
}

FloorData <- function(ties = FloorTies(), gapHeight = NULL,
                      splitHeight = NULL) {
  parts <- data.frame(site = rep(c("s1", "s2"), each = 2), height = c(0, 50),
                      partition = rep(c("a", "b"), each = 2))
  if (!is.null(splitHeight)) {
    parts <- rbind(parts, data.frame(site = "s1", height = splitHeight,
                                     partition = c("a", "c")))
    parts[["partition"]][parts[["site"]] == "s1" & parts[["height"]] == 50] <-
      "c"
    parts <- parts[order(parts[["site"]], parts[["height"]]), ]
  }
  if (!is.null(gapHeight)) {
    parts <- rbind(parts, data.frame(site = "s1", height = gapHeight,
                                     partition = c("a", NA)))
    parts <- parts[order(parts[["site"]], parts[["height"]]), ]
  }
  StratData(signal = FloorSignal(), parts = parts, ties = ties,
            signalColumn = "value", zColumn = "height", siteColumn = "site",
            partitionColumn = "partition")
}

FloorModel <- function(data, logRateMedian = log(kRate), gap = FALSE, ...) {
  ratePrior <- NormalPrior(logRateMedian, 3)
  priors <- list(alpha_s1 = UniformPrior(0, 100),
                 alpha_s2 = UniformPrior(0, 100),
                 gammaLog_s1 = ratePrior, gammaLog_s2 = ratePrior)
  if (gap) {
    priors[["gap_s1_1"]] <- UniformPrior(0, 4)
  }
  priors <- structure(priors, class = c("list", "StratPrior"))
  suppressMessages(StratModel(data, priors, alignmentScale = "age",
                              sedModel = "site", alphaPosition = "bottom",
                              ...))
}

# The floor as built before #2722: keyed to D at the prior medians.
PriorMedianFloor <- function(model, data) {
  .LambdaFloor(model[["splineBase"]],
               .EnsurePreExtracted(data)[[c("signalAttr", "signalValuesVec")]],
               .LambdaStarGroups(data, FALSE))
}

test_that("precise ties make the floor independent of the rate prior", {
  data <- FloorData()
  atTruth <- FloorModel(data, log(kRate))
  offCentre <- FloorModel(data, 0)
  expect_gt(offCentre[[c("splineBase", "ageSpan")]] /
              atTruth[[c("splineBase", "ageSpan")]], 50)
  expect_equal(offCentre[[c("priors", "gibbs", "lambdaMin")]],
               atTruth[[c("priors", "gibbs", "lambdaMin")]],
               tolerance = 1e-12)
})

test_that("ties that bracket a hiatus still key the floor", {
  data <- FloorData(FloorTies(), gapHeight = 25)
  floorPath <- c("priors", "gibbs", "lambdaMin")
  expect_equal(FloorModel(data, 0, gap = TRUE)[[floorPath]],
               FloorModel(data, log(kRate), gap = TRUE)[[floorPath]],
               tolerance = 1e-12)
})

test_that("under partition rates, ties must bracket every partition boundary", {
  floorPath <- c("priors", "gibbs", "lambdaMin")
  BuildFloor <- function(data, logRateMedian) {
    ratePrior <- NormalPrior(logRateMedian, 3)
    priors <- structure(
      list(alpha_s1 = UniformPrior(0, 100), alpha_s2 = UniformPrior(0, 100),
           gammaLog_a = ratePrior, gammaLog_b = ratePrior,
           gammaLog_c = ratePrior),
      class = c("list", "StratPrior")
    )
    model <- suppressMessages(StratModel(data, priors, alignmentScale = "age",
                                         sedModel = "partition",
                                         alphaPosition = "bottom"))
    c(model[[floorPath]], PriorMedianFloor(model, data))
  }
  above <- FloorData(splitHeight = 46)
  expect_identical(BuildFloor(above, 0)[[1]], BuildFloor(above, 0)[[2]])
  between <- FloorData(splitHeight = 25)
  expect_equal(BuildFloor(between, 0)[[1]],
               BuildFloor(between, log(kRate))[[1]], tolerance = 1e-12)
})

test_that("the floor is lambda* at the ties' signal-age span", {
  data <- FloorData()
  model <- FloorModel(data, 0)
  heights <- .EnsurePreExtracted(data)[[c("signalAttr", "siteHeights")]]
  # two equally precise ties per site interpolate the true age line exactly
  tieSpan <- diff(range(kAlpha[["s1"]] - range(heights[["s1"]]) / kRate,
                        kAlpha[["s2"]] - range(heights[["s2"]]) / kRate))
  ageSpan <- model[[c("splineBase", "ageSpan")]]
  expect_equal(model[[c("priors", "gibbs", "lambdaMin")]],
               PriorMedianFloor(model, data) * (tieSpan / ageSpan)^3,
               tolerance = 1e-10)
})

test_that("the floor keeps its prior-median key without precise ties", {
  ExpectUnchanged <- function(data, ...) {
    model <- FloorModel(data, 0, ...)
    expect_identical(model[[c("priors", "gibbs", "lambdaMin")]],
                     PriorMedianFloor(model, data))
  }
  # rate's relative SE = sqrt(2) * 0.5 / 0.4 = 1.8
  ExpectUnchanged(FloorData(FloorTies(sd = 0.5)))
  ExpectUnchanged(FloorData(FloorTies(heights = 25)))
  # a span over the tied site alone would sit ~50x too short
  ExpectUnchanged(FloorData(FloorTies(sites = "s1")))
  ExpectUnchanged(FloorData(FloorTies()), flexibleKnots = FALSE)
  # sedSmooth strips the gammaLog_ priors, with a warning
  suppressWarnings(ExpectUnchanged(FloorData(FloorTies()), sedSmooth = TRUE))
  # the ties at 5 and 45 cannot see a hiatus at 46
  ExpectUnchanged(FloorData(FloorTies(), gapHeight = 46), gap = TRUE)
  ExpectUnchanged(FloorData(FloorTies()),
                  disableTies = list(s1 = 1, s2 = 2))
})

test_that("the floor keeps its key on the height scale", {
  data <- FloorData(ties = NULL)
  model <- suppressMessages(StratModel(data, alignmentScale = "height",
                                       sedModel = "site"))
  expect_identical(model[[c("priors", "gibbs", "lambdaMin")]],
                   PriorMedianFloor(model, data))
})

test_that(".TieSignalAgeSpan() needs a precise line at every signal site", {
  ties <- data.frame(height = c(0, 10), age = c(2, 1), spread = 0.01)
  heights <- list(c(0, 10), c(0, 20))
  expect_equal(.TieSignalAgeSpan(list(ties, ties), heights), 2)
  expect_identical(.TieSignalAgeSpan(list(ties, NULL), heights), NA_real_)
  vague <- transform(ties, spread = 1)
  expect_identical(.TieSignalAgeSpan(list(ties, vague), heights), NA_real_)
  # a site without signal needs no line
  expect_equal(.TieSignalAgeSpan(list(ties, NULL), list(c(0, 10), NA)), 1)
  # a tie of unknown spread is left out of its site's line
  unknown <- rbind(ties, data.frame(height = 5, age = 100, spread = NA))
  expect_equal(.TieSignalAgeSpan(list(unknown, ties), heights), 2)
  # ties that miss their line by far more than their spreads are imprecise
  bent <- data.frame(height = c(0, 10, 20), age = c(2, 1.95, 0.1),
                     spread = 0.01)
  expect_identical(.TieSignalAgeSpan(list(bent, ties), heights), NA_real_)
  rising <- transform(ties, age = c(1, 2))
  expect_identical(.TieSignalAgeSpan(list(rising, ties), heights), NA_real_)
  expect_identical(.TieSignalAgeSpan(list(ties, ties), heights,
                                     list(NULL, 15)), NA_real_)
  expect_equal(.TieSignalAgeSpan(list(ties, ties), heights, list(5, 20)), 2)
  expect_identical(.TieSignalAgeSpan(NULL, heights), NA_real_)
  expect_identical(.TieSignalAgeSpan(list(ties), list(c(3, 3))), NA_real_)
})
