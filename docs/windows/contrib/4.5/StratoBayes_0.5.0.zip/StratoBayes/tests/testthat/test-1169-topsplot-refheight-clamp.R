# GH #1169: `TopsPlot()` recovered the horizon index by matching reference
# heights, so two heights at the same bound both matched the first index.

test_that(paste0("an out-of-range reference height is extrapolated, ",
                 "with a warning"), {
            data("stratPosterior1", package = "StratoBayes")

            expect_warning(
              res <- TopsPlot(stratPosterior1, refHeights = 2.19,
                              refHeightsSite = 2,
                              display = FALSE),
              "extrapolated beyond the reference section"
            )

            refSite <- levels(res$site)[1]
            medianTop <- function(site) {
              res$top[res$site == site & res$quantile == 0.5]
            }
            expect_gt(medianTop(refSite), 10)
          })

test_that(paste0("two reference heights beyond the same bound stay ",
                 "distinct horizons"), {
            data("stratPosterior1", package = "StratoBayes")

            expect_warning(
              res <- TopsPlot(stratPosterior1, refHeights = c(2.18, 2.19),
                              refHeightsSite = 2, display = FALSE),
              "extrapolated beyond the reference section"
            )

            expect_setequal(unique(res$refHeight), c(2.18, 2.19))
            # one row per (site, horizon, quantile): the two horizons must be
            # represented equally, not collapsed onto the first
            expect_equal(unname(table(res$refId)[["1"]]),
                         unname(table(res$refId)[["2"]]))
            expect_equal(res$refHeight, c(2.18, 2.19)[res$refId])
          })

test_that("in-range reference heights neither warn nor change", {
  data("stratPosterior1", package = "StratoBayes")
  expect_no_warning(
    res <- TopsPlot(stratPosterior1, refHeights = c(0.5, 1), refHeightsSite = 2,
                    display = FALSE)
  )
  expect_setequal(unique(res$refHeight), c(0.5, 1))
})
