# RT-136: the auto-generated modelName seed in RunStratModel() was derived
# solely from the current time (millisecond resolution), so two processes
# reaching it in the same millisecond drew the same 12-character modelName and
# silently collided on a shared modelDir. The seed now mixes in Sys.getpid().
# Forcing two real processes into one millisecond is not feasible in a unit
# test, so the guard is that the naming code still reads the pid.

test_that(paste0("RunStratModel's auto-naming block actually includes ",
                 "Sys.getpid() (RT-136)"), {
            # Guards against the fix being silently reverted/removed: the seed
            # construction for the auto-generated modelName must reference
            # Sys.getpid() so same-millisecond seeds from different processes
            # diverge.
            src <- paste(deparse(body(RunStratModel)), collapse = "\n")
            expect_true(grepl("Sys\\.getpid\\(\\)", src))
          })
