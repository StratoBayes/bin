test_that(".log_diff_pnorm() names an NA bound", {
  expect_error(.log_diff_pnorm(NA_real_, 1), "`zL` and `zU` must not be NA")
  expect_error(.log_diff_pnorm(0, NaN), "`zL` and `zU` must not be NA")
})

test_that(".log_diff_pnorm() rejects reversed bounds", {
  expect_error(.log_diff_pnorm(2, 1), "`zL` must not exceed `zU`")
})

test_that(".log_diff_pnorm() is unchanged for valid and equal bounds", {
  expect_equal(.log_diff_pnorm(-Inf, Inf), 0)
  expect_equal(.log_diff_pnorm(-1, 1), log(pnorm(1) - pnorm(-1)))
  expect_identical(.log_diff_pnorm(1, 1), -Inf)
})
