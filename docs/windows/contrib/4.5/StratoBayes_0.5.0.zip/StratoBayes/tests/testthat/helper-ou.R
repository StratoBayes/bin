# Shared by test-residual-correlation-ou.R and test-partial-tempering-ou.R.
#
# Dense OU correlation for rows in signal order, with the engine's segment
# rule: a new site or a tied height starts an independent segment.
.OuDenseR <- function(z, site, ell) {
  n <- length(z)
  seg <- cumsum(c(TRUE, site[-1] != site[-n] | diff(z) == 0))
  outer(seq_len(n), seq_len(n), function(i, j) {
    ifelse(seg[i] == seg[j], exp(-abs(z[i] - z[j]) / ell[i]), 0)
  })
}
