# #2573: a vague tie stretched the automatic age-scale knotRange to its median.
# #2574: follow-ups to #2530.

# vignette "Age-models" configuration in ka
KaTies <- function(extra = NULL) {
  ties <- data.frame(site = "site1", height = c(2.5, 6.5) * pi,
                     densityFun = "dnorm", arg1 = c(12000, 10000),
                     arg2 = c(100, 50))
  rbind(ties, extra)
}

KaPriors <- function() {
  structure(
    list(
      alpha_site1 = NormalPrior(11000, 1000),
      alpha_site2 = NormalPrior(11000, 1000),
      "gammaLog_partition site 1" = NormalPrior(log(2 * pi / 1000), 0.5),
      "gammaLog_bottom part., site 2" = NormalPrior(log(2 * pi / 1000), 0.5),
      "gammaLog_top part., site 2" = NormalPrior(log(2 * pi / 1000), 0.5),
      gap_site2_1 = ExponentialPrior(1 / 1000)
    ),
    class = c("StratPrior", "list")
  )
}

KaModel <- function(extra = NULL, ...) {
  data <- StratData(signalData4, ties = KaTies(extra), parts = partsData4)
  StratModel(data, KaPriors(), alignmentScale = "age",
             sedModel = "partition", alphaPosition = c(4.5 * pi, "middle"),
             nKnots = 15, ...)
}

KaKnotRange <- function(extra = NULL) {
  model <- suppressWarnings(suppressMessages(
    KaModel(extra, flexibleKnots = FALSE)
  ))
  model[[c("splineBase", "knotRange")]]
}

Site2Tie <- function(densityFun, arg1, arg2) {
  data.frame(site = "site2", height = 1, densityFun = densityFun,
             arg1 = arg1, arg2 = arg2)
}

test_that("a vague tie leaves the automatic knotRange alone (#2573)", {
  plain <- KaKnotRange()
  # "site 2's base is older than 12 ka": never binds, median far beyond data
  expect_equal(KaKnotRange(Site2Tie("dunif", 12000, 30000)), plain)
  expect_equal(KaKnotRange(Site2Tie("dunif", 5000, 1e5)), plain)
  # narrower than the data, but its probable ages overlap them
  expect_equal(KaKnotRange(Site2Tie("dunif", 12000, 18000)), plain)
})

test_that("a precise tie beyond the data still extends knotRange (#2573)", {
  plain <- KaKnotRange()
  far <- KaKnotRange(Site2Tie("dnorm", 20000, 100))
  # signal ages to 20000 - 100, padded by a quarter of the span
  signalLow <- plain[[1]] + diff(plain) / 6
  expect_equal(far, c(signalLow, 19900) + c(-1, 1) * (19900 - signalLow) / 4)
})

test_that("a tie pulls the range by where it pulls the signal (#2573)", {
  Ties <- function(densityFun, arg1, arg2, age, spread) {
    data.frame(age = age, spread = spread, densityFun = densityFun,
               arg1 = arg1, arg2 = arg2)
  }
  signal <- c(47, 52)
  # vaguer than the signal span, but far beyond it: the signal must move
  expect_equal(.TieRangeAges(Ties("dnorm", 85, 8, 85, 8), signal), 77)
  # a precise tie still widens a signal that converts to a single age
  expect_equal(.TieRangeAges(Ties("dnorm", 60, 1, 60, 1), c(7, 7)), 59)
  # a bound clear of the signal reaches past its own edge
  expect_gt(.TieRangeAges(Ties("dunif", 60, 80, 70, 6.8), signal), 60)
  # within one sd: content where it is
  expect_length(.TieRangeAges(Ties("dnorm", 52.5, 1, 52.5, 1), signal), 0)
  # no quantile function: its central age, as before
  expect_equal(.TieRangeAges(Ties("dnorm", 85, 8, 85, NA), signal), 85)
})

test_that("the knotRange message counts the knots within the signal", {
  expect_equal(.KnotsWithin(c(0, 14), 15L, c(2, 6.5)), 5L)
  expect_message(
    suppressWarnings(KaModel(Site2Tie("dnorm", 20000, 100),
                             flexibleKnots = FALSE)),
    "and the tie ages, 25% padding; [0-9]+ of 15 knots within the signal"
  )
})

test_that("the strip warning says gammaLog medians seed the start (#2574)", {
  warnings <- capture_warnings(suppressMessages(KaModel(sedSmooth = TRUE)))
  expect_match(warnings, "does not sample.*medians still set its starting",
               all = FALSE)
})

test_that("two ties set the start rate whatever their spreads (#2574)", {
  # two points fix a line, so weighting cannot favour the precise tie: a
  # vague top tie sets the start rate as fully as a precise one
  Rate <- function(topSd) {
    ties <- data.frame(site = "site1", height = c(2.5, 6.5) * pi,
                       mean = c(12000, 11900), sd = c(100, topSd))
    .TieLogInverseRate(.SiteTieAges(
      StratData(signalData4, ties = ties, parts = partsData4)
    ))[[1]]
  }
  expect_equal(Rate(3000), log(100 / (4 * pi)))
  expect_equal(Rate(3000), Rate(10))
})
