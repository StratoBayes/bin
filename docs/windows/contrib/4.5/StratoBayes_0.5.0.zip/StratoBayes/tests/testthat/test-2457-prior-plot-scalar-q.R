LaplacePrior <- function() {
  qlap <- function(p, m, b) {
    if (p < 0.5) m + b * log(2 * p) else m - b * log(2 - 2 * p)
  }
  dlap <- function(x, m, b, log = FALSE) {
    d <- -log(2 * b) - abs(x - m) / b
    if (log) d else exp(d)
  }
  rlap <- function(n, m, b) {
    u <- runif(n) - 0.5
    m - b * sign(u) * log(1 - 2 * abs(u))
  }
  Prior(rlap, dlap, qlap, m = 0, b = 10)
}

test_that("prior plots accept a Q that is not vectorised (#2457)", {
  post <- stratPosterior2
  post$model$priors$metro$alpha_site2 <- LaplacePrior()

  pdf(NULL)
  on.exit(dev.off())
  expect_no_warning(
    plot(post$model$priors$metro, parameters = "alpha_site2")
  )
  expect_no_warning(
    hist(post, parameters = "alpha_site2", prior = TRUE)
  )

  prior <- post$model$priors$metro$alpha_site2
  xRange <- .FindXRange(prior[["D"]], prior[["Q"]], prior[["args"]], 1)
  expect_true(all(is.finite(xRange)))
  expect_gt(diff(xRange), 0)
})
