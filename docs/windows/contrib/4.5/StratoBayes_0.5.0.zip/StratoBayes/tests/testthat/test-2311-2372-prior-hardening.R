PriorsOf <- function(...) structure(list(...), class = c("StratPrior", "list"))
LogPostArgs <- function(...) {
  .PrepareLogPostArgs(list(priors = list(metro = list(...))))
}

test_that("#2372: a native density with degenerate args is an error", {
  normal <- NormalPrior(0, 1)
  normal[[c("args", "sd")]] <- -1
  expect_false(.HasForeignDensity(normal))
  expect_silent(.NoteForeignDensityPriors(list(priors = list(
    metro = list(a = normal)
  ))))
  expect_error(LogPostArgs(a = normal),
               "'a' is classed `NormalPrior` but has invalid arguments.*-1")

  uniform <- UniformPrior(0, 1)
  uniform[["args"]] <- list(min = 1, max = 0)
  expect_false(.HasForeignDensity(uniform))
  expect_error(LogPostArgs(u = uniform), "`UniformPrior` but has invalid")

  # [min, max] below zero misses the log-normal's support entirely
  truncLog <- TruncLogNormalPrior(0, 1, 0.1, 2)
  truncLog[["args"]][c("min", "max")] <- list(-2, -1)
  expect_error(LogPostArgs(t = truncLog), "`TruncLogNormalPrior` but has")

  # a foreign density is still scored as a custom prior
  foreign <- NormalPrior(0, 1)
  foreign[["D"]] <- function(x, mean, sd, log = FALSE) {
    dnorm(x, mean, sd, log = log)
  }
  expect_true(.HasForeignDensity(foreign))
  expect_identical(LogPostArgs(f = foreign)[["priorTypes"]], "")
})

test_that("#2372: a released TruncLogNormDensity body stays native", {
  # v0.4.0's body, as a model saved under it carries
  v040 <- function(x, meanlog = 0, sdlog = 1, min = -Inf, max = Inf,
                   log = FALSE) {
    if (max <= min) stop("'max' must be greater than 'min'")
    logDensityValues <- dlnorm(x, meanlog, sdlog, log = TRUE)
    zL <- if (min <= 0) -Inf else (log(min) - meanlog) / sdlog
    zU <- if (is.infinite(max)) Inf else (log(max) - meanlog) / sdlog
    logDensityTruncated <- logDensityValues - .log_diff_pnorm(zL, zU)
    logDensityTruncated[x < min | x > max] <- -Inf
    if (log) {
      return(logDensityTruncated)
    } else {
      return(exp(logDensityTruncated))
    }
  }
  environment(v040) <- asNamespace("StratoBayes")
  released <- c(list(v040), .legacyTruncLogNormDensities)
  for (legacy in released) {
    prior <- TruncLogNormalPrior(0, 1, 0.1, 2)
    # as loaded from a model saved by an installed release
    prior[["D"]] <- utils::removeSource(legacy)
    expect_false(.HasForeignDensity(prior))
    expect_identical(LogPostArgs(t = prior)[["priorTypes"]],
                     "TruncLogNormalPrior")
    x <- c(0.05, 0.1, 0.7, 1.9, 2.5)
    expect_identical(prior[["D"]](x, 0, 1, 0.1, 2, log = TRUE),
                     TruncLogNormDensity(x, 0, 1, 0.1, 2, log = TRUE))

    # an identical body outside the namespace is not the package's
    copy <- legacy
    environment(copy) <- globalenv()
    prior[["D"]] <- copy
    expect_true(.HasForeignDensity(prior))
  }
})

test_that("#2372: a Fixed prior's R and Q must return its value", {
  expect_true(.PriorsValidity(PriorsOf(a = Fixed(0.3))))
  expect_true(.PriorsValidity(PriorsOf(a = Fixed(2L))))

  redrawn <- Fixed(0.3)
  redrawn[["R"]] <- function(n, value) rnorm(n, value, 1)
  expect_error(.PriorsValidity(PriorsOf(gammaLog_site_3 = redrawn)),
               "Fixed prior 'gammaLog_site_3' must have `R` and `Q` return")

  shifted <- Fixed(0.3)
  shifted[["Q"]] <- function(p, value, ...) rep(value + 1, length(p))
  expect_error(.PriorsValidity(PriorsOf(a = shifted)), "its `value` \\(0.3\\)")
})

test_that("#2372: a built-in density with a replaced sampler is an error", {
  resampled <- NormalPrior(0, 1)
  resampled[["R"]] <- function(n, mean, sd) runif(n, mean - sd, mean + sd)
  expect_error(.PriorsValidity(PriorsOf(a = resampled)),
               "built-in `NormalPrior` density but a different sampler")

  expect_true(.PriorsValidity(PriorsOf(a = Prior(rnorm, dnorm, qnorm,
                                                 mean = 0, sd = 1))))
  custom <- NormalPrior(0, 1)
  custom[["D"]] <- function(x, mean, sd, log = FALSE) {
    dnorm(x, mean, sd, log = log)
  }
  custom[["R"]] <- function(n, mean, sd) rnorm(n, mean, sd)
  expect_true(.PriorsValidity(PriorsOf(a = custom)))
})

test_that("#2311: the Fixed-mismatch error does not advise omission", {
  expect_error(
    .CheckFixedPriorsProposals(PriorsOf(a = Fixed(1)),
                               PriorsOf(a = NormalPrior(0, 1))),
    "\\(with the same value\\) in `priorsProposals`\\.$"
  )
})

test_that("#2311: StratModelTemplate refuses the age scale without ties", {
  expect_null(stratData1[["ties"]])
  for (sedModel in c("site", "partition", "site x partition",
                     "site, partition")) {
    expect_error(
      capture.output(StratModelTemplate(stratData1, "age", sedModel)),
      "alignmentScale = 'age' if there have not been any ties"
    )
  }
})

test_that("#2311: alphaPosition errors name negated depths", {
  expect_error(
    .MatchAlphaPosition(1e6, stratData3, "height", toNumeric = TRUE),
    "use negated depths for depth-scale data"
  )
})

test_that("#2311: a misspelt `priors` name gives one error naming `priors`", {
  priors <- stratPrior1
  names(priors)[names(priors) == "alpha_site_2"] <- "alpha_sit2"
  expect_no_warning(expect_error(
    StratModel(stratData1, priors = priors, alignmentScale = "height",
               sedModel = "site"),
    "^`priors` names no parameter of this model: alpha_sit2\\. Valid names"
  ))

  repeated <- c(stratPrior1, stratPrior1["alpha_site_2"])
  class(repeated) <- class(stratPrior1)
  expect_error(
    StratModel(stratData1, priors = repeated, alignmentScale = "height",
               sedModel = "site"),
    "^`priors` repeats alpha_site_2;"
  )
})

test_that("#2372: review follow-ups on classification", {
  current <- TruncLogNormalPrior(0, 1, 0.1, 2)
  current[["D"]] <- utils::removeSource(current[["D"]])
  expect_false(.HasForeignDensity(current))

  # `R` decides `Fixed` whatever `D` holds (RT-692)
  expect_true(.IsFixedPrior(Prior(.fixed_R, dnorm, .fixed_Q, value = 3)))

  located <- NormalPrior(0, 1)
  located[[c("args", "mean")]] <- NA_real_
  expect_false(.HasForeignDensity(located))
  expect_error(LogPostArgs(m = located), "`NormalPrior` but has invalid")

  missingValue <- Fixed(1)
  missingValue[[c("args", "value")]] <- NA_real_
  missingValue[["R"]] <- function(n, value) rep(1, n)
  missingValue[["Q"]] <- function(p, value, ...) rep(1, length(p))
  expect_error(.PriorsValidity(PriorsOf(a = missingValue)),
               "must have `R` and `Q` return its `value` [(]NA[)]")
})
