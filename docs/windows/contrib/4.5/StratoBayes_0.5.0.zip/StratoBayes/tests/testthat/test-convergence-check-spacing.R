# Convergence checks spaced by their cost rather than by `nIter`.

test_that("checks are spaced to cost their share of the wall-clock", {
  # 1 ms per check at 1 ms per iteration: 200 iterations keep it at 0.5%.
  expect_identical(.NextConvergenceCheck(5000, 0.001, 0.001, 1), 5200)
  expect_lte(0.001 / (200 * 0.001), .kConvergenceCheckShare)
  # However dear the check, the next is no further off than an unbounded
  # run's default checkpoint spacing.
  expect_identical(.NextConvergenceCheck(5000, 0.01, 0.001, 1),
                   5000 + .kConvergenceCheckMaxGap)
  # Never sooner than the next saved draw.
  expect_identical(.NextConvergenceCheck(5000, 1e-9, 0.001, 10), 5010)
  # Never later than the run has already run, so one slow check cannot stall
  # the rule.
  expect_identical(.NextConvergenceCheck(500, 0.01, 0.001, 1), 1000)
  # An iteration too fast to time says nothing about the gap.
  expect_identical(.NextConvergenceCheck(500, 0.01, 0, 1), 1000)
  expect_identical(.NextConvergenceCheck(500, 0, 0, 1), 1000)
})

test_that("agreement must span new effective draws, not just two checks", {
  dir <- withr::local_tempdir()
  Rows <- function(iters, seed) {
    set.seed(seed)
    cbind(iters, 1, matrix(stats::rnorm(2 * length(iters)), ncol = 2))
  }
  # Independent draws: one effective draw per iteration, so the streak must
  # outlast 10% of the ESS target -- 20 iterations.
  Check <- function(store) {
    .ConvergenceCheckpoint(store, list(rHat = 1.5, ess = 200), dir, "m",
                           run = 1, nRun = 1, endAdapting = 0,
                           crossRun = FALSE, useSentinel = FALSE)
  }
  store <- Check(.ConvergenceAppend(.ConvergenceStore(), Rows(1:300, 1),
                                    cols = 3:4))
  expect_identical(store[["metSince"]], 300)

  store <- Check(.ConvergenceAppend(store, Rows(301:305, 2), cols = 3:4))
  store <- Check(.ConvergenceAppend(store, Rows(306:310, 3), cols = 3:4))
  expect_identical(store[["streak"]], 3L)
  expect_false(store[["met"]])

  store <- Check(.ConvergenceAppend(store, Rows(311:340, 4), cols = 3:4))
  expect_true(store[["met"]])
})

# Proposal weights are tuned on measured wall-clock (#760); fixed here so that
# only the check spacing differs between runs.
FixedShares <- function(pOld, sqJump, sqJumpSq, timeNs, count, valid,
                        updateCount) {
  ifelse(valid, pOld, 0) / sum(pOld[valid])
}

test_that("extra checks do not move the sampler", {
  skip_on_cran()
  Run <- function(gap) {
    local_mocked_bindings(
      .NextConvergenceCheck = function(iter, ...) iter + gap,
      .EsjdProposalShares = FixedShares
    )
    dir <- withr::local_tempdir()
    # Past adaptation, proposal weights still update every 10 iterations from
    # the engine's history, which a check's extra visit must not disturb.
    RunStratModel(stratData1, stratModel1, nIter = 1000, nChains = 4,
                  nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                  modelDir = dir, modelName = "g", visualise = FALSE,
                  endAdapting = 200,
                  convergenceStop = list(rHat = 1.000001, ess = 30000))
  }
  expect_identical(Run(7)[["samples"]], Run(1e9)[["samples"]])
})

test_that("extra checks after a timer freeze do not move the sampler", {
  skip_on_cran()
  Run <- function(gap) {
    timer <- new.env()
    timer[["calls"]] <- 0L
    local_mocked_bindings(
      .NextConvergenceCheck = function(iter, ...) iter + gap,
      .EsjdProposalShares = FixedShares,
      .AdaptTimerCheckpoint = function(store, ...) {
        timer[["calls"]] <- timer[["calls"]] + 1L
        store[["predicted"]] <- 0
        store[["freeze"]] <- timer[["calls"]] >= 3L
        store
      }
    )
    dir <- withr::local_tempdir()
    post <- RunStratModel(stratData1, stratModel1, nIter = 2000, nChains = 4,
                          nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                          modelDir = dir, modelName = "z", visualise = FALSE,
                          convergenceStop = list(rHat = 1.000001, ess = 30000))
    list(samples = post[["samples"]],
         freeze = post[[c("mcmcSummary", "adaptFreeze")]][[1]][["iteration"]])
  }
  dense <- Run(7)
  # The freeze leaves a stretch of sampling before the original cap (1000).
  expect_lt(dense[["freeze"]], 900)
  expect_identical(dense, Run(1e9))
})

test_that("a long finite run stops soon after it can, not at 10% steps", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  post <- RunStratModel(stratData1, stratModel1, nIter = 20000, nChains = 2,
                        nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                        modelDir = dir, modelName = "s", visualise = FALSE,
                        endAdapting = 200,
                        convergenceStop = list(rHat = 10, ess = 1))
  # Write checkpoints alone could not stop it before iteration 4000.
  expect_lt(unlist(post[[c("mcmcSummary", "completedIter")]]), 4000)
})

test_that("a fast model stops near convergence, not a doubling late", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  post <- suppressWarnings(
    RunStratModel(stratData1, stratModel1, nIter = 240000, nChains = 8,
                  nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                  modelDir = dir, modelName = "c", visualise = FALSE,
                  convergenceStop = TRUE)
  )
  # Default criteria converge here by about 24000 iterations; write
  # checkpoints alone would wait for 48000, and checks spaced by cost alone
  # doubled their gap to stop at about 72000.
  expect_lt(unlist(post[[c("mcmcSummary", "completedIter")]]), 40000)
})
