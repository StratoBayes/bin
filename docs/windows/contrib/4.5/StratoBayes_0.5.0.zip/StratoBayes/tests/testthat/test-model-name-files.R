RunArgs <- function(dir, name, ...) {
  c(list(modelDir = dir, modelName = name, nThreads = 1L, quiet = TRUE,
         visualise = FALSE, runParallel = FALSE), list(...))
}

test_that("a modelName containing _temp runs, continues and reads back", {
  dir <- withr::local_tempdir()
  options(mc.cores = 2L)
  do.call(RunStratModel, RunArgs(dir, "m_temp", stratData1, stratModel1,
                                 nIter = 20, nChains = 2L, seed = 1))
  do.call(RunStratModel, RunArgs(dir, "m_temp", NULL, nIter = 5))
  expect_no_error(StratPosterior(dir, "m_temp"))
})

test_that(".ReadMCMC keeps a sample file whose name contains _temp", {
  dir <- withr::local_tempdir()
  expect_true(file.create(file.path(dir, "no_temp_samples_run_1.txt")))
  expect_false(
    grepl("No sample files matching",
          tryCatch(.ReadMCMC(readDir = dir, modelName = "no_temp"),
                   error = conditionMessage),
          fixed = TRUE)
  )
})

test_that(".CheckModelName rejects path separators", {
  expect_error(.CheckModelName("sub/x"), "path separator")
  expect_error(.CheckModelName("sub\\x"), "path separator")
  expect_no_error(.CheckModelName("sub_x"))
})

test_that(".CheckRequiredFiles anchors the samples files (m beside m_2)", {
  dir <- withr::local_tempdir()
  for (f in c("m_data.rds", "m_model.rds", "m_samples_run_1.txt",
              "m_mcmc_run_1.rds", "m_2_samples_run_2.txt",
              "m_2_mcmc_run_2.rds")) {
    file.create(file.path(dir, f))
  }
  writeLines("nRun = 1", file.path(dir, "m_options.txt"))
  expect_no_error(.CheckRequiredFiles(dir, "m"))
})
