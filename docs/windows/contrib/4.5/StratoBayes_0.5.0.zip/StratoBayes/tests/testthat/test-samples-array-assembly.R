# The samples array is allocated once and filled run by run. It must be
# identical() to what the earlier assembly built by padding per-run arrays and
# binding them with abind(), frozen here from 31ae4a9a6.
OldAssembly <- function(runData, paramNames, saveChainsList = NULL,
                        runNumbers = NULL) {
  if (is.null(runNumbers)) runNumbers <- seq_along(runData)
  compiledData <- list()
  runsSuccessfullyRead <- !vapply(runData, function(r) isFALSE(r),
                                  FUN.VALUE = logical(1))
  runsSuccessfullyReadIndices <- which(runsSuccessfullyRead)
  runsNotSuccessfullyRead <- which(!runsSuccessfullyRead)
  iterationsLength <- vapply(runData[runsSuccessfullyReadIndices], function(x)
                               length(unique(x[["iteration"]])), numeric(1))
  longestRun <-
    runData[runsSuccessfullyReadIndices][[which.max(iterationsLength)]]
  iterationsMax <- sort(unique(longestRun[["iteration"]]))
  for (run in runsSuccessfullyReadIndices) {
    trueRun <- runNumbers[run]
    iterations <- sort(unique(runData[[run]][["iteration"]]))
    nIterations <- length(iterations)
    if (!is.null(saveChainsList) && length(saveChainsList) >= trueRun &&
          length(saveChainsList[[trueRun]]) > 0L) {
      chains <- saveChainsList[[trueRun]]
    } else {
      chains <- sort(unique(runData[[run]][["chain"]]))
    }
    nSaveChains <- length(chains)
    runArray <- array(NA, dim = c(nIterations, length(paramNames), 1,
                                  nSaveChains))
    for (k in seq_along(chains)) {
      ch <- chains[[k]]
      sub <- runData[[run]][runData[[run]][["chain"]] == ch, , drop = FALSE]
      if (nrow(sub) == 0L) next
      sub <- sub[order(sub[["iteration"]]), , drop = FALSE]
      sub <- sub[!duplicated(sub[["iteration"]], fromLast = TRUE), ,
                 drop = FALSE]
      rowMatch <- match(iterations, sub[["iteration"]])
      runArray[, , 1, k] <- as.matrix(sub[rowMatch, paramNames, drop = FALSE])
    }
    compiledData[[run]] <- runArray
  }
  for (run in runsNotSuccessfullyRead) {
    trueRun <- runNumbers[run]
    successfulRun <- runData[[runsSuccessfullyReadIndices[[1]]]]
    nCh <- if (!is.null(saveChainsList) && length(saveChainsList) >= trueRun &&
                 length(saveChainsList[[trueRun]]) > 0L) {
      length(saveChainsList[[trueRun]])
    } else {
      length(unique(successfulRun[["chain"]]))
    }
    compiledData[[run]] <-
      array(NA, dim = c(1, length(paramNames), 1, nCh))
  }
  maxDim1 <- max(sapply(compiledData, function(x) dim(x)[[1]]))
  maxDim4 <- max(sapply(compiledData, function(x) dim(x)[[4]]))
  paddedArray <- lapply(compiledData, .PadArray, maxDim1 = maxDim1,
                        maxDim4 = maxDim4)
  compiledArray <- do.call(abind::abind, c(paddedArray, along = 3))
  dim1 <- dim(compiledArray)[[1]]
  if (length(iterationsMax) != dim1) {
    iterationsMax <- seq_len(dim1)
  }
  chainLabels <- paste0("chain", seq_len(maxDim4))
  if (!is.null(saveChainsList)) {
    ref <- which(vapply(saveChainsList, length, integer(1)) == maxDim4)
    if (length(ref) > 0L) {
      chainLabels <- paste0("chain", saveChainsList[[ref[1L]]])
    }
  }
  dimnames(compiledArray) <- list(
    iteration = iterationsMax,
    parameters = paramNames,
    runs = paste0("run", runNumbers),
    chains = chainLabels
  )
  compiledArray
}

params <- c("alpha[1]", "alpha[2]", "logPost")

# One run's samples, rows interleaved by chain as the samplers write them.
RunFrame <- function(iterations, chains, seed) {
  set.seed(seed)
  grid <- expand.grid(chain = chains, iteration = iterations)
  frame <- data.frame(iteration = grid[["iteration"]],
                      chain = grid[["chain"]])
  for (param in params) frame[[param]] <- round(rnorm(nrow(frame)), 3)
  frame
}

test_that("in-memory assembly is identical to the abind() assembly", {
  even <- list(RunFrame(1:5, 1:2, 1), RunFrame(1:5, 1:2, 2))
  ragged <- list(RunFrame(1:5, 1:2, 1), RunFrame(1:3, 1:2, 2))

  shuffled <- RunFrame(c(1, 3, 2, 4), 1:2, 3)
  shuffled <- shuffled[c(5, 2, 8, 1, 3, 7, 4, 6), ]
  # A stale row before a rewrite of iteration 3; the later row wins.
  shuffled <- rbind(transform(shuffled[1, ], logPost = -99), shuffled)

  gappyChain <- RunFrame(1:6, 1:2, 4)
  gappyChain <- gappyChain[!(gappyChain[["chain"]] == 2 &
                               gappyChain[["iteration"]] %in% c(2, 5)), ]

  naChain <- RunFrame(1:4, 1:2, 5)
  naChain[3, "chain"] <- NA

  intOnly <- RunFrame(1:3, 1:2, 6)
  for (param in params) intOnly[[param]] <- as.integer(intOnly[[param]] * 10)
  allNA <- RunFrame(1:3, 1:2, 7)
  for (param in params) allNA[[param]] <- NA
  noRows <- RunFrame(1:3, 1:2, 8)[0, ]

  cases <- list(
    even = list(even, list(1:2, 1:2)),
    evenNoSaveChains = list(even, NULL),
    ragged = list(ragged, list(1:2, 1:2)),
    raggedShorterFirst = list(rev(ragged), NULL),
    shuffledDuplicates = list(list(shuffled, ragged[[2]]), list(1:2, 1:2)),
    fewerChains = list(list(RunFrame(1:4, 1:3, 9), RunFrame(1:6, 1:2, 10)),
                       list(1:3, 1:2)),
    savedChainUnwritten = list(list(RunFrame(1:4, 1:2, 11)), list(1:3)),
    chainSubset = list(list(RunFrame(1:4, c(2, 4), 12)), list(c(2, 4))),
    gappyChain = list(list(gappyChain, ragged[[2]]), NULL),
    naChain = list(list(naChain, ragged[[2]]), NULL),
    firstUnreadable = list(list(FALSE, ragged[[1]], ragged[[2]]), NULL),
    middleUnreadable = list(list(ragged[[1]], FALSE, ragged[[2]]),
                            list(1:2, 1:3, 1:2)),
    noRows = list(list(even[[1]], noRows), list(1:2, 1:2)),
    onlyNoRows = list(list(noRows), list(1:2)),
    integer = list(list(intOnly, intOnly), NULL),
    integerAndDouble = list(list(intOnly, even[[2]]), NULL),
    allNA = list(list(allNA), NULL),
    allNAAndDouble = list(list(allNA, ragged[[2]]), NULL)
  )
  for (case in names(cases)) {
    runData <- cases[[case]][[1L]]
    saveChains <- cases[[case]][[2L]]
    expect_identical(
      .SamplesArrayFromRunListAfterMCMC(runData, params, saveChains),
      OldAssembly(runData, params, saveChains),
      label = case
    )
  }

  # Both refuse an unreadable run whose chains only an empty run could name.
  Message <- function(f) tryCatch(f(), error = conditionMessage)
  expect_identical(
    Message(function() {
      .SamplesArrayFromRunListAfterMCMC(list(noRows, FALSE), params)
    }),
    Message(function() OldAssembly(list(noRows, FALSE), params))
  )

  # A run-number gap: positions 1 and 2 hold runs 1 and 3.
  gap <- list(ragged[[1]], RunFrame(1:4, 1:3, 13))
  saveChains <- list(1:2, 1:4, 1:3)
  expect_identical(
    .SamplesArrayFromRunListAfterMCMC(gap, params, saveChains, c(1L, 3L)),
    OldAssembly(gap, params, saveChains, c(1L, 3L))
  )
  gapUnreadable <- list(ragged[[1]], FALSE)
  expect_identical(
    .SamplesArrayFromRunListAfterMCMC(gapUnreadable, params, saveChains,
                                      c(1L, 3L)),
    OldAssembly(gapUnreadable, params, saveChains, c(1L, 3L))
  )

  # A column-named matrix, as binary samples are stored, reads as the data
  # frame it would become.
  asMatrix <- lapply(ragged, as.matrix)
  expect_identical(
    .SamplesArrayFromReader(function(pos) asMatrix[[pos]], 2L, params,
                            list(1:2, 1:2)),
    OldAssembly(lapply(asMatrix, as.data.frame), params, list(1:2, 1:2))
  )
})

test_that("assembly from disk is identical on the RDS and the TSV paths", {
  dir <- withr::local_tempdir()
  model <- list(outputParams = params)
  frames <- list(RunFrame(1:6, 1:3, 21), RunFrame(1:4, 1:2, 22),
                 RunFrame(seq(10, 100000, length.out = 5), 1:3, 23))
  runs <- c(1L, 2L, 4L)
  saveChains <- list(1:3, 1:2, 1:4, 1:3)

  rdsFiles <- file.path(dir, paste0("m_binarysamples_run_", runs, ".rds"))
  for (i in seq_along(runs)) saveRDS(as.matrix(frames[[i]]), rdsFiles[[i]])
  expect_identical(
    .CompileSamplesAfterMCMC(dir, "m", model, saveChainsList = saveChains),
    OldAssembly(.ReadBinarySamples(rdsFiles, runs), params, saveChains, runs)
  )
  expect_identical(
    .CompileSamplesAfterMCMC(dir, "m", model),
    OldAssembly(.ReadBinarySamples(rdsFiles, runs), params, NULL, runs)
  )

  writeBin(as.raw(1:10), rdsFiles[[2]])
  expect_error(.CompileSamplesAfterMCMC(dir, "m", model),
               "Cannot read '.*m_binarysamples_run_2\\.rds'.* of run 2\\.")
  unlink(rdsFiles)

  tsvFiles <- file.path(dir, paste0("m_samples_run_", runs, ".txt"))
  for (i in seq_along(runs)) {
    write.table(frames[[i]], tsvFiles[[i]], row.names = FALSE,
                col.names = TRUE, sep = "\t", quote = FALSE)
  }
  OldFromTSV <- function(saveChainsList) {
    OldAssembly(lapply(tsvFiles, .ReadSamplesTable), params, saveChainsList,
                runs)
  }
  expect_identical(
    .CompileSamplesAfterMCMC(dir, "m", model, saveChainsList = saveChains),
    OldFromTSV(saveChains)
  )

  file.create(tsvFiles[[1]])  # Unreadable: zero bytes
  expect_identical(
    .CompileSamplesAfterMCMC(dir, "m", model, saveChainsList = saveChains),
    OldFromTSV(saveChains)
  )
  expect_identical(.CompileSamplesAfterMCMC(dir, "m", model),
                   OldFromTSV(NULL))
})

test_that("assembly refuses a run whose samples change between passes", {
  frames <- list(RunFrame(1:4, 1:2, 31), RunFrame(1:4, 1:2, 32))
  reads <- 0L
  ReadRun <- function(pos) {
    reads <<- reads + 1L
    if (pos == 1L && reads > 2L) RunFrame(1:5, 1:2, 31) else frames[[pos]]
  }
  expect_error(.SamplesArrayFromReader(ReadRun, 2L, params),
               "samples of run 1 changed while they were being read")
  # The last run is held from the first pass, not read again.
  reads <- 0L
  expect_identical(
    .SamplesArrayFromReader(function(pos) {
      reads <<- reads + 1L
      frames[[pos]]
    }, 2L, params),
    OldAssembly(frames, params)
  )
  expect_identical(reads, 3L)
})

test_that(".FiniteTotal() matches summing a copy of the finite values", {
  Old <- function(x) {
    finite <- is.finite(x)
    list(total = sum(x[finite]), nNonFinite = sum(!finite))
  }
  set.seed(41)
  big <- array(rnorm(2^20 + 7) * 1e6, dim = c(2^20 + 7, 1, 1, 1))
  bigNA <- big
  bigNA[c(1, 2^20, 2^20 + 1, 2^20 + 7)] <- NA
  bigNA[5] <- NaN
  cases <- list(
    finite = c(0.1, 0.2, 0.3, 1e17, -1e17),
    na = c(0.1, NA, 0.3, NaN),
    inf = c(0.1, Inf, NA),
    negInf = c(-Inf, 2),
    integer = c(1L, NA, 3L),
    logical = c(TRUE, FALSE, NA),
    allNA = array(NA, c(2, 2)),
    allNAReal = rep(NA_real_, 3),
    empty = double(0),
    big = big,
    bigNA = bigNA
  )
  for (case in names(cases)) {
    expect_identical(.FiniteTotal(cases[[case]]), Old(cases[[case]]),
                     label = case)
  }
})
