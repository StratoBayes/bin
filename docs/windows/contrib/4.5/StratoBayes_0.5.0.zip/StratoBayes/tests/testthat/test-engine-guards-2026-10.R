# Engine-construction and accept-step guards: boundaryMove on a constant-rate
# model (#2620), the partial-tempering sedSmooth accept from a -Inf marginal on
# the T = Inf rung (#2420), and the sedLambda default for an imported state
# that lacks one (#2263).

.GuardSedFixture <- function() {
  data("stratData1", package = "StratoBayes", envir = environment())
  sModel <- StratModel(stratData1,
                       priors = AutoPrior(stratData1, "height",
                                          sedModel = "site, partition"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE, flexibleKnots = FALSE,
                       knotRange = c(-5, 12),
                       residualCorrelation = "none")
  td <- withr::local_tempdir("guards", .local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "guards"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "guards_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc,
       state = mcmc$recentState[[1]])
}

.GuardConstantRateRun <- function(boundaryMove) {
  data("stratData1", package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12),
    residualCorrelation = "none"
  ))
  model$sedSmoothInfo <- list(boundaryMove = boundaryMove)
  td <- withr::local_tempdir("guards", .local_envir = parent.frame())
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model,
    nIter = 20, nChains = 1L, seed = 1, nThreads = 1L, runParallel = FALSE,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "constant"
  ))
}

test_that("boundaryMove on a constant-rate model is refused clearly (#2620)", {
  skip_on_cran()
  expect_error(.GuardConstantRateRun(TRUE), "boundaryMove.*sedSmooth")
  expect_error(.GuardConstantRateRun(list(prob = 0.1)),
               "boundaryMove.*sedSmooth")
  expect_s3_class(.GuardConstantRateRun(FALSE), "StratPosterior")
})

test_that("boundaryMove still builds on a sedSmooth model (#2620)", {
  skip_on_cran()
  fx <- .GuardSedFixture()
  model <- fx$model
  model$sedSmoothInfo$boundaryMove <- TRUE
  engine <- StratoBayes:::.sb_create_engine(
    data = fx$data, model = model, mcmc = fx$mcmc,
    state = fx$mcmc$recentState, tiesCallback = NULL
  )
  expect_true(StratoBayes:::.sb_sed_boundary_stats(engine)[["active"]])
})

test_that("the T = Inf rung's sedSmooth step escapes a -Inf marginal (#2420)", {
  skip_on_cran()
  fx <- .GuardSedFixture()
  mcmc <- suppressWarnings(StratMCMC(
    fx$model, nIter = 10, nChains = 2, tempering = TRUE, nThreads = 1L,
    temperingComponents = "signal", gradientProposals = "off"
  ))
  EngineAt <- function(lambda, temperatures) {
    s <- fx$state
    s$gibbs$lambda[] <- lambda
    engine <- StratoBayes:::.sb_create_engine(
      data = fx$data, model = fx$model, mcmc = mcmc, state = list(s, s),
      tiesCallback = NULL
    )
    StratoBayes:::.sb_update_temperatures(engine, temperatures)
    engine
  }
  SignalMarginal <- function(lambda) {
    StratoBayes:::.sb_extract_state(EngineAt(lambda, c(1, 2)))[[1]]$
      metro$logPostSep[[2]]
  }
  # A huge signal lambda fails the beta-marginal's conditioning gate. Just past
  # the threshold the current state's marginal is -Inf while some proposals'
  # are still finite, which is the regime the clamp is for.
  lo <- 1e12
  hi <- 1e20
  bracketRatio <- 1.01
  expect_true(is.finite(SignalMarginal(lo)))
  expect_identical(SignalMarginal(hi), -Inf)
  while (hi / lo > bracketRatio) {
    mid <- sqrt(lo * hi)
    if (is.finite(SignalMarginal(mid))) lo <- mid else hi <- mid
  }
  nSeed <- 50L
  Accepted <- function(temperatures) {
    sum(vapply(seq_len(nSeed), function(seed) {
      StratoBayes:::.sb_sed_smooth_gibbs_probe(
        EngineAt(hi, temperatures), 2L, seed
      )[["accepted"]]
    }, logical(1)))
  }
  # Control: at finite T the old energy is -Inf, not NaN, so moves were always
  # accepted there. Only the T = Inf rung rejected every move before the clamp.
  expect_gt(Accepted(c(1, 1e6)), 0)
  expect_gt(Accepted(c(1, Inf)), 0)
})

test_that("an imported state lacking sedLambda gets its prior mean (#2263)", {
  skip_on_cran()
  fx <- .GuardSedFixture()
  model <- fx$model
  # Off the engine's fallback hyperparameters, so the default is read from
  # the model rather than coinciding with them.
  model$sedSmoothInfo$aSedLambda <- 3
  model$sedSmoothInfo$bSedLambda <- 0.5
  state <- fx$state
  state$gibbs$sedLambda <- NULL
  engine <- StratoBayes:::.sb_create_engine(
    data = fx$data, model = model, mcmc = fx$mcmc, state = list(state),
    tiesCallback = NULL
  )
  info <- model$sedSmoothInfo
  expect_equal(
    StratoBayes:::.sb_extract_state(engine)[[1]]$gibbs$sedLambda,
    rep(info$aSedLambda * info$bSedLambda, info$nFormations)
  )
})
