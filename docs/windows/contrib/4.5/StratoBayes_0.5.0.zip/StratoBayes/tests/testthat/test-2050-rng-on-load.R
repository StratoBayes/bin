test_that("loading and non-drawing exports leave no .Random.seed (#2050)",
          {
            # A fresh process is the only session guaranteed to have no seed;
            # this one has drawn already.
            libs <- paste(deparse(.libPaths()), collapse = "")
            script <- tempfile(fileext = ".R")
            on.exit(unlink(script), add = TRUE)
            writeLines(
              c(
                paste0(".libPaths(", libs, ")"),
                "Seeded <- function() exists('.Random.seed', globalenv(),",
                "                            inherits = FALSE)",
                "before <- Seeded()",
                "suppressMessages(loadNamespace('StratoBayes'))",
                "afterLoad <- Seeded()",
                "ns <- asNamespace('StratoBayes')",
                "invisible(ns$.sb_mat_vec_mult(diag(2), c(1, 2)))",
                "invisible(ns$.sb_qtnorm(0.5, -1, 1))",
                "invisible(ns$.sb_expired())",
                "cat(before, afterLoad, Seeded(), sep = ',')"
              ),
              script
            )
            out <- system2(
              file.path(R.home("bin"), "Rscript"),
              c("--vanilla", shQuote(script)),
              stdout = TRUE, stderr = TRUE
            )
            expect_identical(out[length(out)], "FALSE,FALSE,FALSE",
                             info = paste(out, collapse = "\n"))
          })

# Pinned, so that an export whose `rng = false` is dropped cannot leave the
# list unnoticed: the drift check below then fails instead.
rngFreeExports <- c(
  ".sb_age_convert", ".sb_age_convert_batch", ".ClusterDistSumsCpp",
  ".sb_expiry_days", ".sb_expired", ".sb_expired_on", ".sb_clock_days",
  ".SectionOverlapCpp", ".sb_update_htby", ".IsDuplicateInHistory",
  ".sb_logpost", ".sb_mat_vec_mult", ".sb_qtnorm", ".sb_sed_spline_ages",
  ".sb_sed_spline_full_integral", ".sb_sed_spline_partial_integral",
  ".sb_spline_design", ".sb_steady_seconds", ".FirstAndLastCPP"
)

test_that("no rng = false export seeds a fresh session (#2717)", {
  # A bare symbol fails every Rcpp conversion, so a wrapper returns before its
  # body runs, but only after any RNGScope it holds has been opened.
  # `.sb_run_block` holds one: the positive control.
  libs <- paste(deparse(.libPaths()), collapse = "")
  script <- tempfile(fileext = ".R")
  on.exit(unlink(script), add = TRUE)
  writeLines(
    c(
      paste0(".libPaths(", libs, ")"),
      "suppressMessages(loadNamespace('StratoBayes'))",
      "ns <- asNamespace('StratoBayes')",
      paste0("exports <- c('.sb_run_block', ",
             paste(deparse(rngFreeExports), collapse = ""), ")"),
      "Seeded <- function() exists('.Random.seed', globalenv(),",
      "                            inherits = FALSE)",
      "seeding <- character()",
      "for (nm in exports) {",
      "  f <- get(nm, ns)",
      "  args <- rep(list(as.name('x')), length(formals(f)))",
      "  try(do.call(f, args, quote = TRUE), silent = TRUE)",
      "  if (Seeded()) {",
      "    seeding <- c(seeding, nm)",
      "    rm('.Random.seed', envir = globalenv())",
      "  }",
      "}",
      "cat('SEEDING:', paste(seeding, collapse = ','), sep = '')"
    ),
    script
  )
  out <- system2(
    file.path(R.home("bin"), "Rscript"),
    c("--vanilla", shQuote(script)),
    stdout = TRUE, stderr = TRUE
  )
  expect_identical(out[length(out)], "SEEDING:.sb_run_block",
                   info = paste(out, collapse = " "))
})

test_that("the pinned rng = false exports are the generated ones (#2717)", {
  srcFile <- testthat::test_path("..", "..", "src", "RcppExports.cpp")
  skip_if_not(file.exists(srcFile), "src/ not found")
  lines <- readLines(srcFile, warn = FALSE)
  starts <- grep("^RcppExport SEXP _StratoBayes_", lines)
  ends <- grep("^END_RCPP", lines)
  noRngScope <- vapply(starts, function(s) {
    !any(grepl("RNGScope", lines[s:ends[ends > s][1]], fixed = TRUE))
  }, logical(1))
  expect_identical(sum(noRngScope), length(rngFreeExports))
})
