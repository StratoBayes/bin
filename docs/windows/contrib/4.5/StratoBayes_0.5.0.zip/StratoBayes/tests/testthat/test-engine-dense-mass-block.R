# Engine-side dense 2x2 mass block: momentum draw (mass_sample_momentum) and
# kinetic energy (mass_kinetic_energy). The other mass-block tests exercise
# only the R helpers.
#
# Both are observed through single-leapfrog NUTS steps (maxTreeDepth = 1) with
# a step size so small that the gradient contributes nothing visible:
#  * the position increment is eps * M^-1 p, so its correlation across the
#    block is that of M^-1 only if p has covariance M (p = Lz, not L'z);
#  * the leapfrog conserves the Hamiltonian only if the kinetic energy is
#    p' M^-1 p / 2 including the cross terms; otherwise the energy error is
#    first-order in eps and trips a tiny divergence threshold.

MakeDenseBlockEngine <- function(nChains = 1L, stepSize, divergenceMax) {
  sModel <- StratModel(
    stratData1,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12),
    residualCorrelation = "none"
  )
  td <- file.path(tempdir(), paste0("dmb_", sample.int(1e9, 1L)))
  dir.create(td, recursive = TRUE)
  set.seed(4242)
  result <- RunStratModel(
    gradientProposals = "on", stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = nChains, seed = 1, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "dmb", engine = "R", nThreads = 1L
  )
  mcmc <- readRDS(file.path(td, "dmb_mcmc_run_1.rds"))
  unlink(td, recursive = TRUE)

  massMat <- matrix(c(1, 1.5, 1.5, 4), 2L)
  MakeBlock <- function(idx, m) {
    list(idx = idx, cholMat = as.vector(t(chol(m))),
         invMat = as.vector(solve(m)), k = length(idx))
  }
  blocks <- list(MakeBlock(1:2, massMat), MakeBlock(3L, matrix(1)),
                 MakeBlock(4L, matrix(1)))
  nutsCol <- which(names(mcmc$propose) == "NUTS")
  for (ch in seq_len(nChains)) {
    hmcArgs <- mcmc$metro$proposalArgs[[ch]][["NUTS"]]
    hmcArgs$massMatInv <- c(diag(solve(massMat)), 1, 1)
    hmcArgs$massBlocks <- blocks
    hmcArgs$stepSize <- stepSize
    hmcArgs$maxTreeDepth <- 1L
    hmcArgs$divergenceMax <- divergenceMax
    hmcArgs$adaptStepSize <- FALSE
    mcmc$metro$proposalArgs[[ch]][["NUTS"]] <- hmcArgs
    mcmc$metro$proposalProbability[ch, ] <- 0
    mcmc$metro$proposalProbability[ch, nutsCol] <- 1
  }

  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  engine <- StratoBayes:::.sb_create_engine(
    result$data, model, mcmc, mcmc$recentState
  )
  StratoBayes:::.sb_set_threads(engine, 1L)
  list(engine = engine, massMat = massMat)
}

# Block parameters after each of nIter single iterations
BlockTrace <- function(engine, nIter) {
  trace <- matrix(NA_real_, nIter, 2L)
  for (i in seq_len(nIter)) {
    StratoBayes:::.sb_run_block(engine, 1L)
    state <- StratoBayes:::.sb_extract_state(engine)
    trace[i, ] <- state[[1]]$metro$parameters[1:2]
  }
  trace
}

test_that("engine momentum for a dense 2x2 mass block has covariance M", {
  fx <- MakeDenseBlockEngine(stepSize = 1e-5, divergenceMax = 1000)
  set.seed(8161)
  steps <- diff(BlockTrace(fx$engine, 2000L))
  steps <- steps[rowSums(steps != 0) > 0, , drop = FALSE]
  expect_gt(nrow(steps), 600L)
  # eps * M^-1 p has correlation of M^-1, here -0.75; L'z gives about 0.26
  expect_equal(cor(steps)[1, 2], cov2cor(solve(fx$massMat))[1, 2],
               tolerance = 0.1)
})

test_that("engine kinetic energy of a dense 2x2 block keeps cross terms", {
  fx <- MakeDenseBlockEngine(stepSize = 1e-5, divergenceMax = 1e-6)
  set.seed(8162)
  nIter <- 2000L
  steps <- diff(BlockTrace(fx$engine, nIter))
  # With the full K the energy error is far below the threshold, so about
  # half the iterations move (the rest keep the start); without the cross
  # terms it is first-order in eps and only about a quarter move.
  expect_gt(mean(rowSums(steps != 0) > 0), 0.4)
})
