MakeRun <- function(dir, name, seed, nIter = 60L, nRun = 1L) {
  RunStratModel(stratData1, stratModel1, nIter = nIter, nThin = 1,
                nChains = 2L, nRun = nRun, seed = seed, quiet = TRUE,
                nThreads = 1L, runParallel = FALSE, modelDir = dir,
                modelName = name, visualise = FALSE, convergenceStop = FALSE)
}

Snapshot <- function(dir) {
  files <- list.files(dir, recursive = TRUE, full.names = TRUE)
  stats::setNames(unname(tools::md5sum(files)), basename(files))
}

PerturbData <- function(dir, name) {
  path <- file.path(dir, paste0(name, "_data.rds"))
  data <- readRDS(path)
  data[["signal"]][["value"]] <- data[["signal"]][["value"]] * 1.0066
  saveRDS(data, path)
}

test_that("a rejected combine leaves sources and destination untouched", {
  skip_on_cran()
  for (keep in c(TRUE, FALSE)) {
    dir <- withr::local_tempdir()
    MakeRun(dir, "A", 1)
    MakeRun(dir, "B", 2)
    PerturbData(dir, "B")
    before <- Snapshot(dir)

    expect_error(
      suppressMessages(
        CombineModelRuns(dir, c("A", "B"), "AB", keepOriginals = keep)
      ),
      "not identical"
    )
    expect_identical(Snapshot(dir), before)
    expect_length(list.files(dir, pattern = "^AB_"), 0L)
  }
})

test_that("an interrupted thinning is recovered before combining", {
  skip_on_cran()
  local_mocked_bindings(.StoreTauDraws = function(...) 1e6)
  dir <- withr::local_tempdir()
  withr::with_options(
    list(StratoBayes.maxStore = 64L, StratoBayes.testThinCrash = "commit"),
    expect_error(
      RunStratModel(stratData1, stratModel1, nIter = 320, nThin = 1,
                    nChains = 2L, nRun = 1, seed = 1, quiet = TRUE,
                    nThreads = 1L, modelDir = dir, modelName = "t",
                    visualise = FALSE, convergenceStop = FALSE,
                    endAdapting = 50, adaptTemperaturesMonitor = TRUE),
      "simulated crash"
    )
  )
  MakeRun(dir, "B", 2)
  expect_length(list.files(dir, pattern = "\\.thin\\d+$"), 1L)

  post <- suppressWarnings(CombineModelRuns(dir, c("t", "B"), "tB",
                                            keepOriginals = FALSE))
  expect_length(list.files(dir, pattern = "\\.thin\\d+$"), 0L)
  saved <- as.numeric(post[[c("mcmcSummary", "saveIter")]][[1]])
  rows <- utils::read.delim(file.path(dir, "tB_samples_run_1.txt"))
  expect_identical(as.numeric(unique(rows[["iteration"]])), saved)
})

test_that("a live writer on a source refuses the combine", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "A", 1)
  MakeRun(dir, "B", 2)
  local_mocked_bindings(.LiveWriter = function(modelDir, modelName) {
    modelName == "B"
  })
  before <- Snapshot(dir)
  expect_error(CombineModelRuns(dir, c("A", "B"), "AB"), "being written")
  expect_identical(Snapshot(dir), before)
})

test_that("duplicate sources are refused", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "A", 1)
  expect_error(CombineModelRuns(dir, c("A", "A"), "AA"), "more than once")
  expect_error(
    CombineModelRuns(c(dir, file.path(dir, "..", basename(dir))),
                     c("A", "A"), "AA"),
    "more than once"
  )
  expect_length(list.files(dir, pattern = "^AA_"), 0L)

  dirB <- withr::local_tempdir()
  MakeRun(dirB, "B", 1)
  before <- Snapshot(dir)
  expect_error(CombineModelRuns(c(dir, dirB), c("A", "B"), "AB"),
               "first drawn sample of 'B'.*identical.*'A'")
  expect_identical(Snapshot(dir), before)
})

test_that("independent runs sharing a starting state are combined", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "A", 1)
  MakeRun(dir, "B", 2)
  binA <- readRDS(file.path(dir, "A_binarysamples_run_1.rds"))
  binB <- readRDS(file.path(dir, "B_binarysamples_run_1.rds"))
  binB[1L, ] <- binA[1L, ]
  saveRDS(binB, file.path(dir, "B_binarysamples_run_1.rds"))
  expect_no_error(suppressWarnings(CombineModelRuns(dir, c("A", "B"), "AB")))
})

test_that("a destination collision stops a combine before anything moves", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "A", 1)
  MakeRun(dir, "B", 2)
  writeLines("stale", file.path(dir, "AB_samples_run_2.txt"))
  before <- Snapshot(dir)
  expect_error(
    CombineModelRuns(dir, c("A", "B"), "AB", keepOriginals = FALSE),
    "Failed to copy"
  )
  expect_identical(Snapshot(dir), before)
})

test_that("a combined model can be continued from its directory", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "A", 1)
  MakeRun(dir, "B", 2)
  suppressWarnings(CombineModelRuns(dir, c("A", "B"), "AB"))
  options <- readLines(file.path(dir, "AB_options.txt"))
  expect_identical(grep("^nRun = ", options, value = TRUE), "nRun = 2")

  out <- RunStratModel(modelDir = dir, modelName = "AB", nIter = 90,
                       quiet = TRUE, nThreads = 1L, runParallel = FALSE,
                       visualise = FALSE, convergenceStop = FALSE)
  expect_identical(length(out[[c("mcmcSummary", "completedIter")]]), 2L)
})

test_that("divergence metadata is the union across runs, in either order", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  MakeRun(dir, "off", 1)
  MakeRun(dir, "on", 2)
  mcmcPath <- file.path(dir, "on_mcmc_run_1.rds")
  mcmc <- readRDS(mcmcPath)
  mcmc[["nDivergent"]] <- 12L
  mcmc[["nGradientTransitions"]] <- 300L
  mcmc[["maxTreeDepth"]] <- 5L
  mcmc[["nGibbsCholeskyFailures"]] <- 3L
  saveRDS(mcmc, mcmcPath)

  for (order in list(c("off", "on"), c("on", "off"))) {
    post <- suppressWarnings(
      CombineModelRuns(dir, order, paste(order, collapse = "_"))
    )
    summ <- post[["mcmcSummary"]]
    want <- if (order[[1]] == "off") c(NA, 12L) else c(12L, NA)
    expect_identical(as.integer(summ[["nDivergent"]]), want)
    expect_identical(as.integer(summ[["nGradientTransitions"]]),
                     if (order[[1]] == "off") c(NA, 300L) else c(300L, NA))
    expect_identical(as.integer(summ[["nGibbsCholeskyFailures"]]),
                     if (order[[1]] == "off") c(0L, 3L) else c(3L, 0L))
    expect_no_error(
      divergences <- summary(post)[[c("general", "divergences")]]
    )
    expect_identical(divergences[["nDivergent"]], 12L)
  }
})

test_that("a shared parametersInitial does not make runs duplicates", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  start <- c(alpha_site_2 = 5, alpha_site_3 = 0, gammaLog_site_2 = 0,
             gammaLog_site_3 = 0)
  for (s in 1:2) {
    RunStratModel(stratData1, stratModel1, nIter = 40, nThin = 1,
                  nChains = 2L, saveChains = c(1, 2), seed = s, quiet = TRUE,
                  parametersInitial = start, nThreads = 1L,
                  runParallel = FALSE, modelDir = dir,
                  modelName = LETTERS[s], visualise = FALSE,
                  convergenceStop = FALSE)
  }

  expect_no_error(
    suppressWarnings(CombineModelRuns(dir, c("A", "B"), "AB"))
  )
})
