# Pins for mutants that survived the suite (#2717). Each fails with the
# mutation named in its test applied.

test_that("group labels sort by radix under a non-C collation (#2114)", {
  collations <- c("en_US.UTF-8", "en_GB.UTF-8", "English_United Kingdom.1252",
                  "English_United States.1252")
  usable <- vapply(collations, function(loc) {
    old <- Sys.getlocale("LC_COLLATE")
    on.exit(Sys.setlocale("LC_COLLATE", old))
    nzchar(suppressWarnings(Sys.setlocale("LC_COLLATE", loc))) &&
      identical(sort(c("B", "a", "b")), c("a", "b", "B"))
  }, logical(1))
  skip_if_not(any(usable), "no locale with case-insensitive collation")
  withr::local_collate(collations[usable][[1]])
  signal <- data.frame(site = rep(c("s1", "s2", "s3"), each = 4),
                       z = rep(1:4, 3), v = 1:12)
  data <- StratData(signal = signal, signalColumn = "v", siteColumn = "site",
                    zColumn = "z", group = c(s1 = "b", s2 = "B", s3 = "a"))
  expect_equal(data[["groupAttr"]][["groups"]], c("B", "a", "b"))
})

test_that("every rng = false export is wrapped without an RNGScope (#2050)", {
  srcDir <- testthat::test_path("..", "..", "src")
  skip_if_not(file.exists(file.path(srcDir, "RcppExports.cpp")),
              "src/ not found (not running against a source tree)")
  generated <- readLines(file.path(srcDir, "RcppExports.cpp"))
  sources <- setdiff(list.files(srcDir, "[.]cpp$", full.names = TRUE),
                     file.path(srcDir, "RcppExports.cpp"))
  noRng <- unlist(lapply(sources, function(path) {
    lines <- readLines(path)
    at <- grep("^// *[[]{2}Rcpp::export[(].*rng *= *false", lines)
    vapply(at, function(i) {
      decl <- lines[i + seq_len(5L)]
      decl <- decl[grepl("(", decl, fixed = TRUE)][[1]]
      sub("^.*?([A-Za-z_][A-Za-z0-9_]*) *[(].*$", "\\1", decl, perl = TRUE)
    }, character(1))
  }))
  expect_gt(length(noRng), 15L)
  for (fn in noRng) {
    start <- which(generated == paste("//", fn))
    expect_length(start, 1L)
    end <- start + which(generated[-seq_len(start)] == "END_RCPP")[[1]]
    expect_false(any(grepl("RNGScope", generated[start:end], fixed = TRUE)),
                 info = fn)
  }
})

test_that("a subnormal blockLength keeps its blocks (#2368.3)", {
  signal <- data.frame(site = "a", height = c(0, 0, 1:5), value = 1:7)
  expect_identical(nrow(ThinSignal(signal, blockLength = 5e-324)), 7L)
})

test_that("a `_` boundary match beats a bare prefix match (#2114)", {
  nms <- c("gap_site2_1", "gap_site20_1", "alpha_s1", "alpha_s10")
  expect_no_warning(hit <- .PrefixMatch(nms, "gap_site2"))
  expect_identical(nms[hit], "gap_site2_1")
})

test_that("maxPointsPerSite = \"Inf\" is not a way to disable thinning", {
  signal <- data.frame(site = rep(c("a", "b"), each = 4),
                       height = rep(c(0, 4, 8, 12), 2), value = 1:8)
  expect_error(StratData(signal, maxPointsPerSite = "Inf"),
               "must be a single whole number >= 2, or Inf/NULL")
})

test_that("the ESS gate fires between 10 and 100 (#2412)", {
  general <- list(rhatMax = 1, multiESS = 1000, minESS = 50,
                  minESSParam = "alpha_site1", nDivergent = 0L)
  expect_true(any(grepl("'alpha_site1' has an effective sample size of only 50",
                        .FitGateMessages(general))))
  general[["minESS"]] <- 500
  expect_false(any(grepl("effective sample", .FitGateMessages(general))))
})

test_that("the worst ESS is taken across every block (#2412)", {
  tab1 <- cbind(ess = c(a = 80, b = 60))
  tab2 <- cbind(ess = c(a = 90, c = 20))
  worst <- .FitWorstESS(list(list(summary = tab1), list(summary = tab2)))
  expect_identical(worst[["ess"]], 20)
  expect_identical(worst[["param"]], "c")
  expect_identical(.FitWorstESS(list(list(summary = tab2),
                                     list(summary = tab1)))[["param"]], "c")
})
