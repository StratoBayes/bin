# The samples store across interrupts, hard kills and concurrent writers
# (#2301, #2346, #2393, #2303).

IntegrityData <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  list(data = stratData1,
       model = StratModel(stratData1, alignmentScale = "height",
                          sedModel = "site",
                          residualCorrelation = "none"))
}

IntegrityRun <- function(fx, dir, ..., stratObject = fx$data,
                         stratModel = fx$model) {
  RunStratModel(
    stratObject, stratModel, ..., nChains = 1L, nThreads = 1L,
    tempering = FALSE, convergenceStop = FALSE, visualise = FALSE,
    quiet = TRUE, runParallel = FALSE, modelDir = dir, modelName = "m"
  )
}

Continue <- function(dir, ...) {
  RunStratModel(NULL, ..., modelDir = dir, modelName = "m", nThreads = 1L,
                visualise = FALSE, quiet = TRUE, runParallel = FALSE)
}

SamplesTable <- function(dir) {
  read.table(file.path(dir, "m_samples_run_1.txt"), header = TRUE,
             sep = "\t", check.names = FALSE)
}

# Every saved iteration exactly once, and no stretch of draws repeated.
ExpectNoReplay <- function(dir, block = 5L) {
  smp <- SamplesTable(dir)
  expect_identical(anyDuplicated(smp[["iteration"]]), 0L)
  expect_false(is.unsorted(smp[["iteration"]], strictly = TRUE))
  draws <- as.matrix(smp[, -(1:2)])
  windows <- vapply(seq_len(nrow(draws) - block + 1L), function(r) {
    paste(draws[r:(r + block - 1L), ], collapse = ",")
  }, character(1))
  expect_identical(anyDuplicated(windows), 0L)
}

test_that("an R-engine interrupt between checkpoints is not replayed (#2301)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  withr::with_options(list(StratoBayes.testInterruptAtIter = 170L), {
    expect_error(IntegrityRun(fx, dir, engine = "R", nIter = 200, seed = 1),
                 "simulated interrupt")
  })
  checkpoint <- readRDS(file.path(dir, "m_mcmc_run_1.rds"))
  expect_lt(checkpoint[["completedIter"]],
            max(SamplesTable(dir)[["iteration"]]))

  post <- Continue(dir, nIter = 40)
  smp <- SamplesTable(dir)
  expect_identical(smp[["iteration"]],
                   as.integer(seq_len(checkpoint[["completedIter"]] + 40)))
  ExpectNoReplay(dir)
  expect_identical(post[[c("mcmcSummary", "completedIter")]],
                   checkpoint[["completedIter"]] + 40)
})

test_that("an interrupted C++ continuation is not replayed (#2301)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  IntegrityRun(fx, dir, nIter = 100, seed = 1)
  withr::with_options(list(StratoBayes.testInterruptAtIter = 175L), {
    expect_error(Continue(dir, nIter = 100, .maxBatchSize = 1L),
                 "simulated interrupt")
  })
  checkpoint <- readRDS(file.path(dir, "m_mcmc_run_1.rds"))[["completedIter"]]
  expect_lt(checkpoint, max(SamplesTable(dir)[["iteration"]]))

  Continue(dir, nIter = 40)
  smp <- SamplesTable(dir)
  expect_identical(smp[["iteration"]], as.integer(seq_len(checkpoint + 40)))
  ExpectNoReplay(dir)
})

test_that("a line cut short by a hard kill is not appended onto (#2301)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  IntegrityRun(fx, dir, engine = "R", nIter = 40, seed = 1)
  path <- file.path(dir, "m_samples_run_1.txt")
  bytes <- readBin(path, "raw", file.size(path))
  writeBin(bytes[seq_len(length(bytes) - 9L)], path)

  Continue(dir, nIter = 20)
  post <- StratPosterior(readDir = dir, modelName = "m")
  # The cut row was the checkpoint's own, so the run resumes one label early.
  expect_identical(post[[c("mcmcSummary", "completedIter")]], 59)
  ExpectNoReplay(dir)
})

test_that("a samples file is trimmed to its checkpoint's rows (#2301)", {
  dir <- withr::local_tempdir()
  path <- file.path(dir, "s.txt")
  header <- "iteration\tchain\ta"
  writeLines(c(header, "1\t1\t0.1", "2\t1\t0.2", "3\t1\t0.3"), path)
  expect_false(.TrimSamplesFile(path, 3))
  expect_true(.TrimSamplesFile(path, 2))
  expect_identical(readLines(path), c(header, "1\t1\t0.1", "2\t1\t0.2"))

  # A last line without its newline is cut short, even with every field.
  cat(header, "\n1\t1\t0.1\n2\t1\t0.2\n3\t1\t0.", sep = "", file = path)
  expect_true(.TrimSamplesFile(path, NA))
  expect_identical(readLines(path), c(header, "1\t1\t0.1", "2\t1\t0.2"))
  writeLines(c(header, "1\t1\t0.1", "2\t1", "3\t1\t0.3"), path)
  expect_true(.TrimSamplesFile(path, NULL))
  expect_identical(readLines(path), c(header, "1\t1\t0.1", "3\t1\t0.3"))
  expect_false(file.exists(paste0(path, ".tmp")))
  expect_false(.TrimSamplesFile(file.path(dir, "absent.txt"), 1))
})

test_that("a ragged samples line is dropped, not recycled (#2301, #2393)", {
  parsed <- .ParseSampleLines(c("1\t1\t0.1", "2\t1", "3\t1\t0.3",
                                "4\t1\t0.4\t9"), 3L)
  expect_identical(parsed[, 1L], c(1, 3))
  expect_identical(parsed[, 3L], c(0.1, 0.3))
  expect_null(.ParseSampleLines("2\t1", 3L))
})

# ── #2346: the writer marker ────────────────────────────────────────────────

test_that("a dead writer's marker is stale where `ps` is missing (#2346)", {
  skip_if_not(dir.exists("/proc/1"))
  dir <- withr::local_tempdir()
  writeLines(c(Sys.info()[["nodename"]], .Machine$integer.max),
             .WriterMarkerPath(dir, "m"))
  withr::local_envvar(PATH = "/nonexistent")
  expect_false(.ProcessAlive(.Machine$integer.max))
  expect_false(.LiveWriter(dir, "m"))
  expect_true(.ProcessAlive(Sys.getpid()))
})

test_that("a writer claims its marker exclusively (#2346)", {
  dir <- withr::local_tempdir()
  marker <- .WriterMarkerPath(dir, "m")
  other <- c(Sys.info()[["nodename"]], Sys.getpid() + 1L)
  writeLines(other, marker)

  local_mocked_bindings(.ProcessAlive = function(pid) TRUE)
  expect_error(.MarkWriter(dir, "m", "continued"),
               "still being written.*cannot be continued")
  expect_identical(readLines(marker), other)

  local_mocked_bindings(.ProcessAlive = function(pid) FALSE)
  .MarkWriter(dir, "m")
  expect_identical(readLines(marker)[[2L]], as.character(Sys.getpid()))
  expect_identical(list.files(dir), basename(marker))
})

test_that("a continuation claims the run before touching it (#2346)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  IntegrityRun(fx, dir, engine = "R", nIter = 20, seed = 1)
  claimed <- new.env()
  local_mocked_bindings(.RecoverThinning = function(modelDir, modelName) {
    claimed[["marker"]] <- readLines(.WriterMarkerPath(modelDir, modelName))
    character(0)
  })
  Continue(dir, nIter = 5)
  expect_identical(claimed[["marker"]][[2L]], as.character(Sys.getpid()))
  expect_false(file.exists(.WriterMarkerPath(dir, "m")))
})

test_that("recovery sweeps orphaned temporary files (#2346)", {
  dir <- withr::local_tempdir()
  orphans <- c("m_model.rds.tmp", "m_writing.tmp", "m_samples_run_1.txt.tmp",
               paste0("m_writing.", .Machine$integer.max, ".tmp"))
  for (f in orphans) writeLines("x", file.path(dir, f))
  liveClaim <- file.path(dir, paste0("m_writing.", Sys.getpid(), ".tmp"))
  writeLines("x", liveClaim)
  binary <- file.path(dir, "m_binarysamples_run_1.rds")
  saveRDS(matrix(1:4, 2), binary)
  saveRDS(matrix(1:6, 3), paste0(binary, ".tmp"))
  dataPath <- file.path(dir, "m_data.rds")
  saveRDS("new", paste0(dataPath, ".tmp"))
  keep <- file.path(dir, "m_2_data.rds.tmp")
  writeLines("x", keep)

  local_mocked_bindings(.ProcessAlive = function(pid) pid == Sys.getpid())
  expect_identical(.RecoverThinning(dir, "m"), character(0))
  expect_false(any(file.exists(file.path(dir, orphans))))
  expect_true(file.exists(liveClaim))
  expect_identical(readRDS(binary), matrix(1:6, 3))
  expect_false(file.exists(paste0(binary, ".tmp")))
  expect_identical(readRDS(dataPath), "new")
  expect_true(file.exists(keep))
})

test_that("a pending thin waits while its schedule is unmoved (#2346)", {
  dir <- withr::local_tempdir()
  mcmcPath <- file.path(dir, "m_mcmc_run_1.rds")
  samples <- file.path(dir, "m_samples_run_1.txt")
  saveRDS(list(thinGeneration = 0), mcmcPath)
  writeLines("old", samples)
  saveRDS(list(thinGeneration = 1), paste0(mcmcPath, ".tmp"))
  pending <- .ThinPendingPath(samples, 1)
  writeLines("thinned", pending)

  local_mocked_bindings(.ReplaceFile = function(from, to) {
    invisible(FALSE)
  })
  expect_identical(.RecoverThinning(dir, "m"), "1")
  expect_true(file.exists(pending))
  expect_identical(readLines(samples), "old")
})

test_that("a continuation refuses a run whose swap is unsettled (#2346)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  IntegrityRun(fx, dir, engine = "R", nIter = 20, seed = 1)
  samples <- SamplesTable(dir)
  local_mocked_bindings(.RecoverThinning = function(modelDir, modelName) "1")
  expect_error(Continue(dir, nIter = 5),
               "run\\(s\\) 1 of 'm' could not be moved into place")
  expect_identical(SamplesTable(dir), samples)
})

test_that("a pending thin already copied into place is discarded (#2393)", {
  dir <- withr::local_tempdir()
  saveRDS(list(thinGeneration = 1), file.path(dir, "m_mcmc_run_1.rds"))
  samples <- file.path(dir, "m_samples_run_1.txt")
  pending <- .ThinPendingPath(samples, 1)
  writeLines(c("header", "1"), pending)
  writeLines(c("header", "1", "2"), samples)
  .RecoverThinning(dir, "m")
  expect_identical(readLines(samples), c("header", "1", "2"))
  expect_false(file.exists(pending))

  # A copy cut short leaves the target a prefix of the pending file instead.
  writeLines(c("header", "1", "2"), pending)
  cat("header\n1", file = samples)
  .RecoverThinning(dir, "m")
  expect_identical(readLines(samples), c("header", "1", "2"))
  expect_false(file.exists(pending))
})

test_that("a failed binary checkpoint stops the run (#2346)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  local_mocked_bindings(.WriteBinarySamplesRDS = function(...) FALSE)
  warned <- testthat::capture_warnings(
    IntegrityRun(fx, dir, nIter = 100, seed = 1)
  )
  expect_true(any(grepl("saved draws could not be moved into place", warned)))
  expect_lt(readRDS(file.path(dir, "m_mcmc_run_1.rds"))[["completedIter"]],
            100)
})

# ── #2393: thinning and the planning horizon ───────────────────────────────

test_that("a finite C++ run is not thinned at its last checkpoint (#2393)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  withr::local_options(StratoBayes.maxStore = 256L)
  post <- suppressMessages(IntegrityRun(fx, dir, nIter = 260, seed = 1))
  expect_identical(dim(post[["samples"]])[[1]], 260L)
  expect_identical(readRDS(file.path(dir, "m_mcmc_run_1.rds"))[["nThin"]], 1)
})

test_that("the next checkpoint is found by binary search (#2393)", {
  schedule <- c(10, 20, 30)
  expect_identical(.NextScheduled(schedule, 1), 10)
  expect_identical(.NextScheduled(schedule, 20), 20)
  expect_identical(.NextScheduled(schedule, 21), 30)
  expect_true(is.na(.NextScheduled(schedule, 31)))
  expect_true(is.na(.NextScheduled(numeric(0), 1)))
})

test_that("an unbounded run stops at the last integer iteration (#2393)", {
  near <- .kMaxIter - 100
  expect_equal(.PlanningHorizon(near, Inf), .kMaxIter)
  mcmc <- list(startIter = 1, horizon = 2^30, endIter = Inf, nThin = 2^20,
               saveIter = 1, writeMCMCiterations = FALSE)
  extended <- .ExtendHorizon(mcmc)
  expect_equal(extended[["horizon"]], .kMaxIter)
  expect_false(anyNA(suppressWarnings(as.integer(extended[["saveIter"]]))))
  expect_identical(.ExtendHorizon(extended), extended)
  expect_true(.StopCondition(.kMaxIter, Inf, NULL, 0))
  expect_false(.StopCondition(.kMaxIter - 1, Inf, NULL, 0))
  expect_error(.PlanningHorizon(.kMaxIter + 1, Inf), "cannot be continued")
})

test_that("tau survives a column holding -Inf (#2393)", {
  withr::local_seed(1)
  n <- 2 * .kAutoBurnInMinRows
  mat <- cbind(iteration = seq_len(n), chain = 1, a = stats::rnorm(n),
               b = c(-Inf, stats::rnorm(n - 1)), c = 1e-9 * stats::rnorm(n))
  expect_true(is.finite(.StoreTauDraws(mat, 3:5, 0)))
  mat[2, 3] <- NA
  expect_true(is.na(.StoreTauDraws(mat, 3:5, 0)))
})

test_that("the budget message prints maxStore in full (#2393)", {
  msg <- .SampleBudgetMessage(1e5)
  expect_match(msg, "budget (100000 draws)", fixed = TRUE)
  expect_match(msg, "cannot exceed 50000", fixed = TRUE)
})

test_that("a run thinned by its store combines without a false warning", {
  base <- list(nThin = 1, nChains = 2L, saveChains = 1L)
  thinned <- modifyList(base, list(nThin = 8, thinBase = 1))
  reference <- .CheckCombinedMCMCSettings(base, NULL, "a", 1L)
  expect_no_warning(.CheckCombinedMCMCSettings(thinned, reference, "b", 1L))
  expect_warning(
    .CheckCombinedMCMCSettings(modifyList(base, list(nThin = 2)), reference,
                               "c", 1L),
    "nThin: 2"
  )
})

# ── #2303: file matching and profiles ───────────────────────────────────────

test_that("a sibling model's samples are not attributed to its prefix", {
  skip_on_cran()
  data(stratData1, stratModel1, package = "StratoBayes",
       envir = environment())
  td <- withr::local_tempdir()
  a <- list(nIter = 20, nChains = 2L, nThreads = 1L, quiet = TRUE,
            visualise = FALSE, runParallel = FALSE, modelDir = td)
  do.call(RunStratModel, c(list(stratData1, stratModel1, seed = 1,
                                modelName = "m"), a))
  do.call(RunStratModel, c(list(stratData1, stratModel1, seed = 1:2,
                                modelName = "m_2"), a))
  post <- RunStratModel(NULL, nIter = 5, modelDir = td, modelName = "m",
                        nThreads = 1L, quiet = TRUE, visualise = FALSE,
                        runParallel = FALSE)
  expect_identical(dim(post[["samples"]])[[3]], 1L)
})

test_that("a continuation appends to the run's profile (#2303)", {
  skip_on_cran()
  fx <- IntegrityData()
  dir <- withr::local_tempdir()
  IntegrityRun(fx, dir, engine = "R", nIter = 20, seed = 1, profile = TRUE)
  profile <- file.path(dir, "m_Rprof_run1.out")
  first <- readLines(profile)
  Continue(dir, nIter = 20, profile = TRUE)
  expect_identical(readLines(profile)[seq_along(first)], first)
  expect_identical(sum(grepl("^sample\\.interval=", readLines(profile))), 2L)
  called <- rownames(.ExtractProfileSummaries(profile)[[1L]][["by.self"]])
  expect_false(any(grepl("sample.interval", called, fixed = TRUE)))
})
