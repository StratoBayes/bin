# .sb_create_engine's wrapper refuses hand-built model, data and state shapes
# that its implementation would otherwise read out of bounds or throw from:
# the index signs and partition tables (#2606), partitions with no rate in the
# model (#2710 item c), imported state lengths and HMC/NUTS on a sedSmooth
# model (#2243). Each refusal must come from the wrapper, as an R error.

.ImportFixture <- function(sData, sModel) {
  td <- withr::local_tempdir("import", .local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2L, seed = 1, nThreads = 1L, runParallel = FALSE,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "import"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "import_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc,
       state = mcmc$recentState)
}

.Create <- function(fx, data = fx$data, model = fx$model, mcmc = fx$mcmc,
                    state = fx$state) {
  StratoBayes:::.sb_create_engine(data = data, model = model, mcmc = mcmc,
                                  state = state, tiesCallback = NULL)
}

.SiteFixture <- function(flexibleKnots = FALSE) {
  data("stratData1", package = "StratoBayes", envir = environment())
  .ImportFixture(stratData1, suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site",
    flexibleKnots = flexibleKnots,
    knotRange = if (!flexibleKnots) c(-5, 12)
  )))
}

test_that("the index signs are checked in the wrapper (#2606)", {
  skip_on_cran()
  fx <- .SiteFixture()
  expect_no_error(.Create(fx))

  model <- fx$model
  model$ind$depthHeightSign <- NULL
  expect_error(.Create(fx, model = model),
               "`indices\\$depthHeightSign` is missing")
  model <- fx$model
  model$ind$ageHeightSign <- "a"
  expect_error(.Create(fx, model = model),
               "`indices\\$ageHeightSign` must be 1 or -1")
})

test_that("partition tables are checked and converted in the wrapper", {
  skip_on_cran()
  data("stratData3", package = "StratoBayes", envir = environment())
  data("stratModel3", package = "StratoBayes", envir = environment())
  fx <- .ImportFixture(stratData3, stratModel3)
  expect_identical(fx$model$sedModel, "partition")
  expect_no_error(.Create(fx))

  data <- fx$data
  data$partsAttr$sedRatesDF[] <- as.character(data$partsAttr$sedRatesDF)
  expect_error(.Create(fx, data = data),
               "`partsAttr\\$sedRatesDF` must be numeric")

  # #2606: a double holding a value an int cannot hold warned from the impl,
  # an error there under options(warn = 2)
  data <- fx$data
  npt <- as.double(data$partsAttr$numericPartsTwo)
  npt[[length(npt)]] <- 3e9
  data$partsAttr$numericPartsTwo <- npt
  withr::local_options(warn = 2)
  expect_no_error(.Create(fx, data = data))
})

test_that("a partition with no rate in the model is refused (#2710)", {
  skip_on_cran()
  data("stratData3", package = "StratoBayes", envir = environment())
  data("stratModel3", package = "StratoBayes", envir = environment())
  fx <- .ImportFixture(stratData3, stratModel3)
  expect_identical(fx$model$alignmentScale, "height")

  # Read past `gamma` in ac_get_sed_rate before the guard, so never run red.
  model <- fx$model
  model$ind$gamma <- model$ind$gamma[-1]
  expect_error(.Create(fx, model = model),
               "partition.*with a sedimentation rate but the model has")

  model <- fx$model
  model$ind$gamma[[1]] <- model$parametersLength + 1L
  expect_error(.Create(fx, model = model), "gamma must lie in")

  data <- fx$data
  data$partsAttr$sedRatesDF <- data$partsAttr$sedRatesDF[, 1, drop = FALSE]
  expect_error(.Create(fx, data = data),
               "sedRatesDF has no entry for each partition of site 2")
})

test_that("an age-scale partition code beyond the model's rates is refused", {
  skip_on_cran()
  ties <- data.frame(site = c("site1", "site1"), height = c(2.5, 6.5) * pi,
                     mean = c(12, 10), sd = c(0.1, 0.05))
  sData <- StratData(signalData4, ties = ties, parts = partsData4)
  alpha <- NormalPrior(mean = 11, sd = 1)
  rate <- NormalPrior(mean = log(2 * pi), sd = 1)
  priors <- structure(
    list("alpha_site1" = alpha, "alpha_site2" = alpha,
         "gammaLog_partition site 1" = rate,
         "gammaLog_bottom part., site 2" = rate,
         "gammaLog_top part., site 2" = rate,
         "gap_site2_1" = ExponentialPrior(rate = 1)),
    class = c("StratPrior", "list")
  )
  fx <- .ImportFixture(sData, suppressMessages(StratModel(
    sData, priors, alignmentScale = "age", sedModel = "partition",
    alphaPosition = c(4.5 * pi, "middle"), nKnots = 15, flexibleKnots = FALSE
  )))
  tiesCallback <- function(parameters) {
    ages <- StratoBayes:::.sb_age_convert(fx$data, fx$model$ind, parameters)
    StratoBayes:::.LogLikTies(fx$data, fx$model,
                              list(age = list(ties = ages$ties)))
  }
  expect_no_error(StratoBayes:::.sb_create_engine(
    fx$data, fx$model, fx$mcmc, fx$state, tiesCallback
  ))

  data <- fx$data
  srdf <- data$partsAttr$sedRatesDF
  srdf[which(!is.na(srdf) & srdf > 0)[[1]]] <- length(fx$model$ind$gamma) + 1L
  data$partsAttr$sedRatesDF <- srdf
  expect_error(StratoBayes:::.sb_create_engine(
    data, fx$model, fx$mcmc, fx$state, tiesCallback
  ), "exceeds the model's")
})

test_that("imported state shapes are checked in the wrapper (#2243)", {
  skip_on_cran()
  fx <- .SiteFixture()
  p <- fx$model$splineBase$num_basis

  Refused <- function(pattern, state = fx$state, model = fx$model) {
    expect_error(.Create(fx, model = model, state = state), pattern)
  }
  s <- fx$state
  s[[2]]$gibbs$beta[[1]] <- c(s[[2]]$gibbs$beta[[1]], 0)
  Refused("state\\[\\[2\\]\\]\\$gibbs\\$beta\\[\\[1\\]\\] must hold", s)
  s <- fx$state
  s[[1]]$gibbs$beta <- NULL
  Refused("gibbs\\$beta must be a list", s)
  s <- fx$state
  s[[1]]$gibbs$lambda <- numeric(0)
  Refused("gibbs\\$lambda must hold one value per signal", s)
  s <- fx$state
  s[[1]]$gibbs$sigma <- "a"
  Refused("gibbs\\$sigma must hold one value per signal", s)
  s <- fx$state
  s[[1]]$gibbs$Q <- list(diag(p - 1L))
  Refused("gibbs\\$Q\\[\\[1\\]\\] must be", s)
  s <- fx$state
  s[[1]]$age$ageRange <- 1
  Refused("age\\$ageRange must hold two values", s)
  s <- fx$state
  s[[1]]$age$signalFlat <- s[[1]]$age$signalFlat[-1]
  Refused("age\\$signalFlat must hold one age per signal observation", s)
  s <- fx$state
  s[[1]]$metro$parameters <- s[[1]]$metro$parameters[-1]
  Refused("metro\\$parameters must hold", s)
  s <- fx$state
  s[[1]]$metro$H[[1]] <- s[[1]]$metro$H[[1]][-1, ]
  Refused("metro\\$H\\[\\[1\\]\\] must be", s)

  s <- fx$state
  s[[1]]$metro$tBy <- s[[1]]$metro$tBy[0]
  Refused("metro\\$tBy must hold one vector per signal", s)
  s <- fx$state
  s[[1]]$metro$logPost <- c(-1, -2)
  Refused("metro must carry a single logPost", s)
  s <- fx$state
  s[[1]]$metro$logPostSep <- NULL
  Refused("numeric logPostSep", s)

  model <- fx$model
  model$splineBase$D <- model$splineBase$D[-1, -1]
  Refused("splineBase\\$D must be", model = model)
  model <- fx$model
  model$flexibleKnots <- NA
  Refused("flexibleKnots must be TRUE or FALSE", model = model)
})

test_that("a sedSmooth partition model, which has no gamma, still builds", {
  skip_on_cran()
  data("stratData3", package = "StratoBayes", envir = environment())
  for (sedModel in c("partition", "site x partition")) {
    fx <- .ImportFixture(stratData3, suppressWarnings(StratModel(
      stratData3,
      priors = AutoPrior(stratData3, "height", sedModel = sedModel),
      alignmentScale = "height", sedModel = sedModel, sedSmooth = TRUE,
      flexibleKnots = FALSE, knotRange = c(-10, 10)
    )))
    expect_length(fx$model$ind$gamma, 0)
    expect_no_error(.Create(fx))
  }
})

test_that("an imported flexible-knot penalty must be square (#2243)", {
  skip_on_cran()
  fx <- .SiteFixture(flexibleKnots = TRUE)
  skip_if(is.null(fx$state[[1]]$spline), "fixture state carries no spline")
  expect_no_error(.Create(fx))
  s <- fx$state
  s[[1]]$spline$D <- "a"
  expect_error(.Create(fx, state = s), "spline must carry numeric knots")
})

test_that("HMC and NUTS are refused on a sedSmooth model (#2243)", {
  skip_on_cran()
  data("stratData1", package = "StratoBayes", envir = environment())
  fx <- .ImportFixture(stratData1, StratModel(
    stratData1,
    priors = AutoPrior(stratData1, "height", sedModel = "site, partition"),
    alignmentScale = "height", sedModel = "site, partition",
    sedSmooth = TRUE, flexibleKnots = FALSE, knotRange = c(-5, 12)
  ))
  expect_no_error(.Create(fx))
  mcmc <- fx$mcmc
  mcmc$propose$NUTS <- identity
  expect_error(.Create(fx, mcmc = mcmc), "not available for sedSmooth models")
})
