test_that("default adaptation intervals are capped for a large finite nIter", {
  cap <- StratoBayes:::.kMaxDefaultAdaptInterval
  mcmc <- StratMCMC(stratModel1, nIter = 1e7, nChains = 2, nThreads = 1L)
  expect_identical(mcmc[[c("metro", "adaptProposalInterval")]], cap)
  expect_identical(mcmc[[c("temper", "adaptTemperaturesIntervall")]], cap)
  expect_lte(nrow(mcmc[[c("temper", "temperRatioCapped")]]), cap)
})

test_that("the cap leaves default intervals unchanged up to nIter = 200139", {
  UncappedInterval <- function(mcmc) {
    max(10, floor(0.05 * StratoBayes:::.AdaptCadenceSpan(mcmc)))
  }
  for (nIter in c(2e5, 200139)) {
    mcmc <- StratMCMC(stratModel1, nIter = nIter, nChains = 2, nThreads = 1L)
    expect_identical(mcmc[[c("metro", "adaptProposalInterval")]],
                     UncappedInterval(mcmc))
    expect_identical(mcmc[[c("temper", "adaptTemperaturesIntervall")]],
                     UncappedInterval(mcmc))
  }
  unbounded <- StratMCMC(stratModel1, nIter = Inf, nChains = 2, nThreads = 1L)
  expect_identical(unbounded[[c("metro", "adaptProposalInterval")]],
                   UncappedInterval(unbounded))

  capped <- StratMCMC(stratModel1, nIter = 200140, nChains = 2, nThreads = 1L)
  expect_identical(capped[[c("metro", "adaptProposalInterval")]],
                   StratoBayes:::.kMaxDefaultAdaptInterval)
})

test_that("an explicit adaptation interval is not capped", {
  big <- 2 * StratoBayes:::.kMaxDefaultAdaptInterval
  mcmc <- StratMCMC(stratModel1, nIter = 1e7, nChains = 2, nThreads = 1L,
                    adaptProposalInterval = big)
  expect_identical(mcmc[[c("metro", "adaptProposalInterval")]], big)
})

test_that("an unreachable adaptation window activates history-free proposals", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 400, nChains = 2, nThreads = 1L,
                      endAdapting = 1),
    "`endAdapting = 1`"
  )
  valid <- mcmc[[c("metro", "proposalValid")]]
  expect_true(all(valid[, c("Univariate", "ShiftAlphas", "ShiftAlphasRandJoint",
                            "ShiftAlphasRandSeparate")]))

  # The default window is unreachable at nIter <= 3; only explicit asks warn.
  expect_no_warning(
    short <- StratMCMC(stratModel1, nIter = 3, nChains = 2, nThreads = 1L)
  )
  expect_true(all(short[[c("metro", "proposalValid")]][, "Univariate"]))

  # Adaptation runs at no iteration, so RT-628's single-iteration warning
  # would be false.
  expect_length(capture_warnings(
    StratMCMC(stratModel1, nIter = 400, nChains = 2, nThreads = 1L,
              startAdapting = 5, endAdapting = 1)
  ), 1)

  expect_no_warning(
    control <- StratMCMC(stratModel1, nIter = 400, nChains = 2,
                         nThreads = 1L, endAdapting = 2)
  )
  expect_identical(c(control[["startAdapting"]], control[["endAdapting"]]),
                   c(2, 2))
  expect_false(any(control[[c("metro", "proposalValid")]][, "Univariate"]))
})

test_that("a proposal window under 3 warns for every clustering method", {
  for (method in c("proto", "dbscan")) {
    warnings <- capture_warnings(
      StratMCMC(stratModel1, nIter = 400, nChains = 4, nThreads = 1L,
                adaptProposalWindow = 2, clustMethodMCMC = method)
    )
    expect_length(warnings, 1)
    expect_match(warnings, "`Multivariate` proposals.*unavailable")
  }
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 400, nChains = 4, nThreads = 1L,
              adaptProposalWindow = 3, clustMethodMCMC = "proto")
  )
})

test_that("a short proposal window leaves Multivariate off all run", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 400, nChains = 4,
    adaptProposalWindow = 2, nThreads = 1L, runParallel = FALSE, seed = 1,
    quiet = TRUE, visualise = FALSE, modelDir = dir, modelName = "w2"
  ))
  mcmc <- readRDS(file.path(dir, "w2_mcmc_run_1.rds"))
  expect_false(any(mcmc[[c("metro", "proposalValid")]][, "Multivariate"]))
})

test_that("a resume one past endAdapting does not adapt sedBeta", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height"),
    alignmentScale = "height", sedModel = "site, partition", sedSmooth = TRUE
  ))
  dir <- withr::local_tempdir()
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L, runParallel = FALSE,
    quiet = TRUE, visualise = FALSE, modelDir = dir, modelName = "sedResume"
  ))
  state <- readRDS(file.path(dir, "sedResume_mcmc_run_1.rds"))[["recentState"]]
  endAdapting <- 50L

  AdaptsAfterResume <- function(startIter) {
    engine <- StratoBayes:::.HMCCreateEngine(result[["data"]],
                                             result[["model"]], state[[1]])
    StratoBayes:::.SedBetaAdaptResume(
      engine, result[["model"]],
      list(startIter = startIter, endAdapting = endAdapting)
    )
    StratoBayes:::.sb_sed_beta_adapt_state(engine)[["adapt"]]
  }
  expect_true(AdaptsAfterResume(endAdapting))
  expect_false(AdaptsAfterResume(endAdapting + 1L))
})
