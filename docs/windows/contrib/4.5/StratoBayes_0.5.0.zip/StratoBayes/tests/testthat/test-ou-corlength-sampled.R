# StratModel(corLength = "sample"): the OU correlation length of each site and
# signal is sampled in the C++ engine, log-uniform on a support from a
# twentieth of the median spacing to the smaller of half the span and the
# shared curve's knot spacing. These tests pin the fixed path against the
# sampled one at equal corLength, the move's target against a dense OU
# oracle, its stationary law against a grid, and the bookkeeping that block
# updates and swaps must keep exact.

# Dense OU correlation for rows in signal order, with the engine's segment
# rule: a new site or a tied height starts an independent segment.
.OuDenseR <- function(z, site, ell) {
  n <- length(z)
  seg <- cumsum(c(TRUE, site[-1] != site[-n] | diff(z) == 0))
  outer(seq_len(n), seq_len(n), function(i, j) {
    ifelse(seg[i] == seg[j] & ell[i] > 0,
           exp(-abs(z[i] - z[j]) / pmax(ell[i], 1e-300)), 0) +
      (i == j) * (ell[i] == 0)
  })
}

.SampledFixture <- function(nChains = 2L, nIter = 60L, envir = parent.frame()) {
  data("stratData2", "stratPrior2", package = "StratoBayes",
       envir = environment())
  set.seed(1)
  model <- suppressMessages(suppressWarnings(StratModel(
    stratData2, alignmentScale = "age", sedModel = "site",
    priors = stratPrior2, alphaPosition = c("top", "middle", "bottom"),
    individualSplineIter = 40, corLength = "sample",
    # The oracles below are the sigma-sampled laws (#2810).
    integrateSigma = FALSE
  )))
  td <- withr::local_tempdir("ousample", .local_envir = envir)
  result <- suppressMessages(suppressWarnings(RunStratModel(
    stratObject = stratData2, stratModel = model, nIter = nIter,
    nChains = nChains, seed = 1, nThreads = 1L, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "ous",
    runParallel = FALSE, nCores = 1L
  )))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "ous_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc, result = result,
       dir = td)
}

.SampledEngine <- function(fx, model = fx$model, state = fx$mcmc$recentState,
                           mcmc = fx$mcmc) {
  ns <- asNamespace("StratoBayes")
  ties <- ns$.SafeCallback(ns$.MakeTiesCallback(fx$data, model),
                           "ties densityFun")
  ns$.sb_create_engine(data = fx$data, model = ns$.SafeModelCallbacks(model),
                       mcmc = mcmc, state = state, tiesCallback = ties)
}

# The same model with corLength fixed at `ell`.
.FixedModel <- function(model, ell = model$residualCorrelation$corLength) {
  rc <- model$residualCorrelation
  rc[c("sample", "corLengthLower", "corLengthUpper", "corLengthFree")] <- NULL
  rc$corLength <- ell
  model$residualCorrelation <- rc
  model
}

.WithCorLength <- function(state, ell) {
  lapply(state, function(st) {
    st$gibbs$corLength <- matrix(as.double(ell), nrow(ell))
    st
  })
}

# Signal m's beta-marginal plus 1/2 log|Q| at corLength `ell` (sites x
# signals), from the dense OU correlation, up to terms free of corLength.
.DenseMarginal <- function(data, st, m, ell) {
  rows <- data$signalAttr$sigs[[m]]$signalInd
  z <- data$signal[[data$zColumn]][rows]
  site <- match(data$signal[[data$siteColumn]][rows], data$sites)
  y <- data$signalAttr$signalValuesVec[[m]]
  R <- .OuDenseR(z, site, ell[site, m])
  Q <- solve(R)
  B <- st$metro$B[[m]]
  sigma <- st$gibbs$sigma[m]
  lambda <- st$gibbs$lambda[m]
  D <- st$spline$D
  BtQB <- crossprod(B, Q %*% B)
  BtQy <- drop(crossprod(B, Q %*% y))
  M <- BtQB / sigma^2 + lambda * D
  mu <- solve(M, BtQy / sigma^2)
  -0.5 * as.numeric(determinant(R)$modulus) -
    0.5 * drop(crossprod(y, Q %*% y)) / sigma^2 +
    0.5 * sum(BtQy / sigma^2 * mu) - 0.5 * as.numeric(determinant(M)$modulus)
}

test_that("corLength = 'sample' builds the prior's support", {
  data("stratData2", "stratPrior2", package = "StratoBayes",
       envir = environment())
  Build <- function(...) suppressMessages(suppressWarnings(StratModel(
    stratData2, alignmentScale = "age", sedModel = "site",
    priors = stratPrior2, alphaPosition = c("top", "middle", "bottom"),
    individualSplineIter = 40, ...
  )))
  model <- Build(corLength = "sample")
  rc <- model$residualCorrelation
  expect_true(rc$sample)
  free <- rc$corLengthFree
  expect_true(all(free))
  expect_true(all(rc$corLengthLower[free] > 0))
  expect_true(all(rc$corLengthUpper[free] > rc$corLengthLower[free]))
  expect_true(all(rc$corLength[free] >= rc$corLengthLower[free] &
                    rc$corLength[free] <= rc$corLengthUpper[free]))
  # The top is the smaller of half the span and the knot spacing.
  for (m in seq_len(ncol(free))) {
    z <- lapply(seq_len(nrow(free)), function(s) {
      SignalLookUp(stratData2, type = "height", site = s, signal = m,
                   includeNAsignal = FALSE)
    })
    span <- vapply(z, function(h) diff(range(h)), numeric(1))
    expect_equal(unname(rc$corLengthUpper[, m]),
                 pmin(span / 2, max(span) / (model$splineBase$nKnots - 1)))
  }
  expect_identical(utils::tail(model$outputParams, sum(free)),
                   StratoBayes:::.OuCorLengthNames(rc))
  expect_identical(StratoBayes:::.OuCorLengthNames(rc)[1:2],
                   c("corLength_site1_a", "corLength_site2_a"))
  expect_output(print(model), "corLength sampled, starting at", fixed = TRUE)

  fixed <- Build()
  expect_null(fixed$residualCorrelation$sample)
  expect_false(any(grepl("^corLength_", fixed$outputParams)))

  expect_error(Build(corLength = "sample", sedSmooth = TRUE), "sedSmooth")
  expect_warning(suppressMessages(StratModel(
    stratData2, alignmentScale = "age", sedModel = "site",
    priors = stratPrior2, alphaPosition = c("top", "middle", "bottom"),
    corLength = "sample", residualCorrelation = "none"
  )), "ignored")
  expect_error(Build(corLength = "estimate"), "\"sample\"")
})

test_that("a state at the fixed corLength reproduces the fixed path exactly", {
  skip_on_cran()
  fx <- .SampledFixture()
  ell <- fx$model$residualCorrelation$corLength
  state <- .WithCorLength(fx$mcmc$recentState, ell)
  sampled <- .SampledEngine(fx, state = state)
  fixed <- .SampledEngine(fx, model = .FixedModel(fx$model), state = state)
  stS <- StratoBayes:::.sb_extract_state(sampled)
  stF <- StratoBayes:::.sb_extract_state(fixed)
  rc <- fx$model$residualCorrelation
  free <- rc$corLengthFree
  logPrior <- -sum(log(log(rc$corLengthUpper[free]) -
                         log(rc$corLengthLower[free])))
  for (ch in seq_along(stS)) {
    expect_identical(stS[[ch]]$metro$H, stF[[ch]]$metro$H)
    expect_identical(stS[[ch]]$metro$tBy, stF[[ch]]$metro$tBy)
    params <- stS[[ch]]$metro$parameters
    evS <- StratoBayes:::.sb_eval_logpost(sampled, ch, params, debug = TRUE,
                                          marginal = TRUE)
    evF <- StratoBayes:::.sb_eval_logpost(fixed, ch, params, debug = TRUE,
                                          marginal = TRUE)
    expect_identical(evS$logPostSep[2], evF$logPostSep[2])
    expect_equal(evS$logPostSep[1] - evF$logPostSep[1], logPrior,
                 tolerance = 1e-12)
  }
  expect_null(stF[[1]]$gibbs$corLength)
})

test_that("the log posterior in corLength matches the dense OU oracle", {
  skip_on_cran()
  fx <- .SampledFixture()
  rc <- fx$model$residualCorrelation
  lo <- rc$corLengthLower
  hi <- rc$corLengthUpper
  # Distinct values per site and signal, inside the support.
  E1 <- lo + (hi - lo) * matrix(c(0.6, 0.3, 0.8, 0.2, 0.7, 0.4), 3)
  E2 <- lo + (hi - lo) * matrix(c(0.1, 0.9, 0.5, 0.95, 0.15, 0.55), 3)
  Eval <- function(E) {
    eng <- .SampledEngine(fx, state = .WithCorLength(fx$mcmc$recentState, E))
    st <- StratoBayes:::.sb_extract_state(eng)[[1]]
    expect_equal(st$gibbs$corLength, E, ignore_attr = TRUE)
    ev <- StratoBayes:::.sb_eval_logpost(eng, 1L, st$metro$parameters,
                                         debug = TRUE, marginal = TRUE)
    list(st = st, signal = ev$logPostSep[2])
  }
  r1 <- Eval(E1)
  r2 <- Eval(E2)
  oracle <- function(r, E) {
    sum(vapply(1:2, function(m) .DenseMarginal(fx$data, r$st, m, E),
               numeric(1)))
  }
  expect_equal(r2$signal - r1$signal, oracle(r2, E2) - oracle(r1, E1),
               tolerance = 1e-8)
  expect_gt(abs(r2$signal - r1$signal), 1)
})

test_that("the corLength move samples its conditional", {
  skip_on_cran()
  fx <- .SampledFixture()
  rc <- fx$model$residualCorrelation
  # One free entry per signal, so each conditional is a 1-d grid: site 1 of
  # b, whose rows open the signal, and site 3 of a, whose rows follow others.
  free <- list(c("site3", "a"), c("site1", "b"))
  model <- fx$model
  model$residualCorrelation$corLengthFree[] <- FALSE
  for (e in free) model$residualCorrelation$corLengthFree[e[1], e[2]] <- TRUE
  temps <- fx$mcmc$temper$temperatures
  expect_length(temps, 2L)
  expect_gt(temps[2], 1)
  ell0 <- rc$corLength
  for (ch in seq_along(temps)) {
    eng <- .SampledEngine(fx, model = model,
                          state = .WithCorLength(fx$mcmc$recentState, ell0))
    nK <- length(ell0)
    StratoBayes:::.sb_ou_corlength_control(
      eng, adapt = FALSE, step = matrix(1, length(temps), nK)
    )
    set.seed(3)
    draws <- StratoBayes:::.sb_ou_corlength_probe(eng, ch, 12000L)
    expect_lt(draws$stampError, 1e-8)
    st <- StratoBayes:::.sb_extract_state(eng)[[ch]]
    for (e in free) {
      m <- match(e[2], colnames(ell0))
      k <- match(e[1], rownames(ell0)) + (m - 1) * nrow(ell0)
      x <- log(draws$corLength[-(1:1000), k])
      grid <- seq(log(rc$corLengthLower[e[1], e[2]]),
                  log(rc$corLengthUpper[e[1], e[2]]), length.out = 161)
      lp <- vapply(grid, function(g) {
        E <- ell0
        E[e[1], e[2]] <- exp(g)
        .DenseMarginal(fx$data, st, m, E)
      }, numeric(1)) / temps[ch]
      w <- exp(lp - max(lp))
      w <- w / sum(w)
      gridMean <- sum(w * grid)
      gridSd <- sqrt(sum(w * (grid - gridMean)^2))
      # Batch-means standard error of the draws' mean.
      batches <- colMeans(matrix(x[seq_len(50 * floor(length(x) / 50))],
                                 ncol = 50))
      se <- stats::sd(batches) / sqrt(length(batches))
      expect_lt(abs(mean(x) - gridMean), 4 * se + 0.02 * gridSd)
      expect_lt(abs(stats::sd(x) / gridSd - 1), 0.15)
    }
  }
})

test_that("an accepted move with no likelihood leaves no stale factor", {
  skip_on_cran()
  fx <- .SampledFixture()
  mcmc <- fx$mcmc
  mcmc$temper$temperatures[length(mcmc$temper$temperatures)] <- Inf
  eng <- .SampledEngine(fx, mcmc = mcmc)
  hot <- length(mcmc$temper$temperatures)
  draws <- StratoBayes:::.sb_ou_corlength_probe(eng, hot, 300L)
  expect_lt(draws$stampError, 1e-8)
  expect_gt(length(unique(draws$corLength[, 1])), 10)
  cold <- StratoBayes:::.sb_ou_corlength_probe(eng, 1L, 300L)
  expect_lt(cold$stampError, 1e-8)
})

test_that("block updates and swaps keep each state exact", {
  skip_on_cran()
  fx <- .SampledFixture(nChains = 3L)
  eng <- .SampledEngine(fx)
  StratoBayes:::.sb_run_block(eng, 300L)
  ctl <- StratoBayes:::.sb_ou_corlength_control(eng)
  expect_identical(ctl$clones, rep(0L, 3))
  rate <- sum(ctl$accepts) / sum(ctl$tries)
  expect_gt(rate, 0.05)
  expect_lt(rate, 0.95)
  st <- StratoBayes:::.sb_extract_state(eng)
  rebuilt <- .SampledEngine(fx, state = st)
  for (ch in seq_along(st)) {
    imported <- StratoBayes:::.sb_extract_state(rebuilt)[[ch]]
    expect_identical(imported$gibbs$corLength, st[[ch]]$gibbs$corLength)
    ev <- StratoBayes:::.sb_eval_logpost(rebuilt, ch, st[[ch]]$metro$parameters,
                                         debug = TRUE, marginal = TRUE)
    expect_equal(ev$logPostSep[2], st[[ch]]$metro$logPostSep[2],
                 tolerance = 1e-9)
    expect_equal(ev$logPost, st[[ch]]$metro$logPost, tolerance = 1e-9)
  }
})

test_that("RunStratModel() saves, adapts and resumes the sampled corLength", {
  skip_on_cran()
  fx <- .SampledFixture(nIter = 80L)
  rc <- fx$model$residualCorrelation
  cols <- StratoBayes:::.OuCorLengthNames(rc)
  samples <- fx$result$samples
  expect_true(all(cols %in% dimnames(samples)[[2]]))
  x <- matrix(samples[, cols, , 1], ncol = length(cols))
  lo <- rep(rc$corLengthLower[rc$corLengthFree], each = nrow(x))
  hi <- rep(rc$corLengthUpper[rc$corLengthFree], each = nrow(x))
  expect_true(all(x >= lo & x <= hi))
  expect_equal(unname(samples[1, cols, 1, 1]),
               as.numeric(rc$corLength[rc$corLengthFree]))
  stats1 <- fx$mcmc$ouCorLengthStats
  expect_identical(dim(stats1$step), c(2L, length(rc$corLength)))
  expect_false(stats1$adapt)

  again <- suppressMessages(suppressWarnings(RunStratModel(
    fx$result, nIter = 20L, quiet = TRUE, visualise = FALSE,
    nThreads = 1L, runParallel = FALSE
  )))
  expect_true(all(cols %in% dimnames(again$samples)[[2]]))
  # The continuation resumed the frozen steps and carried the counts on.
  stats2 <- readRDS(file.path(fx$dir, "ous_mcmc_run_1.rds"))$ouCorLengthStats
  expect_identical(stats2$step, stats1$step)
  expect_false(stats2$adapt)
  expect_true(all(stats2$tries >= stats1$tries))
  expect_gt(sum(stats2$tries), sum(stats1$tries))
  expect_true(all(stats2$accepts >= stats1$accepts))
})

test_that("FitDiagnostics() whitens each draw at its own corLength", {
  skip_on_cran()
  fx <- .SampledFixture(nIter = 80L)
  rc <- fx$model$residualCorrelation
  cols <- StratoBayes:::.OuCorLengthNames(rc)
  saved <- matrix(fx$result$samples[, cols, , 1], ncol = length(cols))
  seen <- list()
  original <- StratoBayes:::.FitOuWhitening
  local_mocked_bindings(.FitOuWhitening = function(data, model, layout,
                                                   corLength) {
    if (!missing(corLength)) {
      seen[[length(seen) + 1L]] <<- as.numeric(corLength[rc$corLengthFree])
      return(original(data, model, layout, corLength))
    }
    original(data, model, layout)
  })
  fd <- suppressMessages(suppressWarnings(
    FitDiagnostics(fx$result, burnIn = 0, maxSamples = 15)
  ))
  expect_s3_class(fd, "FitDiagnostics")
  expect_gt(length(seen), 1L)
  # Each draw's whitening corLength is one saved row, in column order.
  for (v in seen) {
    expect_true(any(apply(saved, 1, function(row) identical(row, v))))
  }
})

test_that("the engine wrapper refuses a malformed corLength specification", {
  skip_on_cran()
  fx <- .SampledFixture()
  Bad <- function(field, value) {
    model <- fx$model
    model$residualCorrelation[[field]] <- value
    model
  }
  rc <- fx$model$residualCorrelation
  expect_error(.SampledEngine(fx, model = Bad("corLengthLower", 1)),
               "corLengthLower must be a numeric matrix")
  expect_error(
    .SampledEngine(fx, model = Bad("corLength", rc$corLengthUpper * 2)),
    "start inside"
  )
  flipped <- Bad("corLengthUpper", rc$corLengthLower / 2)
  expect_error(.SampledEngine(fx, model = flipped), "0 < corLengthLower")
  outside <- .WithCorLength(fx$mcmc$recentState, rc$corLengthUpper * 2)
  expect_error(.SampledEngine(fx, state = outside), "outside the corLength")
  eng <- .SampledEngine(fx)
  expect_error(StratoBayes:::.sb_ou_corlength_control(eng, step = matrix(1)),
               "rows")
  expect_error(StratoBayes:::.sb_ou_corlength_control(eng, adapt = NA),
               "adapt")
  fixedEng <- .SampledEngine(fx, model = .FixedModel(fx$model))
  expect_error(StratoBayes:::.sb_ou_corlength_control(fixedEng),
               "corLength = \"sample\"")
})
