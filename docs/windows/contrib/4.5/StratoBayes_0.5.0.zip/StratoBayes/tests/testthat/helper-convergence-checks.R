# Checks are spaced to cost 0.5% of a run's wall-clock, which a short run on a
# small model cannot afford even once; tests of what a check does space them
# by iterations instead.
LocalFrequentChecks <- function(gap = 5, env = parent.frame()) {
  testthat::local_mocked_bindings(
    .NextConvergenceCheck = function(iter, ...) iter + gap,
    .package = "StratoBayes", .env = env
  )
}
