# Gradient proposals (HMC/NUTS) under residualCorrelation = "ou" (#2809). The
# joint log-likelihood is -1/2 |L r|^2 / sigma^2 with L fixed by the site
# heights, so the gradient's per-row seed is (L'L r)_i rather than r_i. The
# oracles are the engine's own log posterior, which already whitens, and the
# same state with the OU block removed, which is what the unwhitened seed
# computes.

.OuGradEngine <- function(fx, model = fx$model) {
  StratoBayes:::.sb_create_engine(
    data = fx$data, model = model, mcmc = fx$mcmc,
    state = fx$mcmc$recentState, tiesCallback = fx$tiesCallback
  )
}

.OuGradFixture <- function(stratData, modelArgs, envir = parent.frame()) {
  model <- suppressWarnings(suppressMessages(
    do.call(StratModel, c(list(stratData), modelArgs))
  ))
  td <- withr::local_tempdir("ou-grad", .local_envir = envir)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = model, nIter = 40, nChains = 1L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    convergenceStop = FALSE, modelDir = td, modelName = "g"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  data <- result$data
  fx <- list(
    data = data, model = model,
    mcmc = readRDS(file.path(td, "g_mcmc_run_1.rds")),
    free = model$ind$paramNotFixed,
    tiesCallback = if ("ties" %in% names(data)) function(parameters) {
      ages <- StratoBayes:::.sb_age_convert(data, model$ind, parameters, FALSE)
      StratoBayes:::.LogLikTies(data, model, list(age = list(ties = ages$ties)))
    }
  )
  fx$params <- fx$mcmc$recentState[[1]]$metro$parameters
  fx$engine <- .OuGradEngine(fx)
  fx
}

.Independent <- function(model) {
  model$residualCorrelation <- NULL
  model
}

# phi = exp(-dz / corLength) over every whitening link
.OuPhi <- function(fx) {
  ell <- fx$model$residualCorrelation$corLength
  unlist(lapply(seq_along(fx$data$signalAttr$signalNames), function(m) {
    lapply(seq_along(fx$data$sites), function(s) {
      dz <- diff(SignalLookUp(fx$data, type = "height", site = s, signal = m,
                              includeNAsignal = FALSE))
      exp(-dz[dz > 0] / ell[s, m])
    })
  }))
}

.OuFdAt <- function(fx, i, h) {
  idx <- fx$free[[i]]
  p <- fx$params
  p[idx] <- p[idx] + h
  up <- StratoBayes:::.sb_eval_logpost(fx$engine, 1L, p)
  p[idx] <- p[idx] - 2 * h
  (up - StratoBayes:::.sb_eval_logpost(fx$engine, 1L, p)) / (2 * h)
}

.OuFixed <- function() {
  data("stratData1", package = "StratoBayes", envir = environment())
  list(stratData1, list(
    priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12), sigmaFixed = 0.5, individualSplineIter = 40,
    residualCorrelation = "ou", corLength = 1.5
  ))
}

test_that("the OU gradient matches central differences of the log posterior", {
  data("stratData2", "stratPrior2", package = "StratoBayes",
       envir = environment())
  tol <- 1e-5
  h0 <- 1e-5
  ladder <- h0 / 4^(0:3)
  # stratData2: two signals, NA rows, ties, a gap and flexible knots.
  cases <- list(
    fixed = .OuFixed(),
    flexible = list(stratData2, list(
      priors = stratPrior2, alignmentScale = "age", sedModel = "site",
      alphaPosition = c("top", "middle", "bottom"), individualSplineIter = 40,
      residualCorrelation = "ou", corLength = 1.5, integrateSigma = FALSE
    ))
  )
  for (case in names(cases)) {
    fx <- .OuGradFixture(cases[[case]][[1]], cases[[case]][[2]])
    # The whitening is far from the identity, or this would test nothing.
    expect_gt(stats::median(.OuPhi(fx)), 0.3)

    g <- StratoBayes:::.sb_compute_gradient(fx$engine, 1L)$grad
    fd <- vapply(seq_along(fx$free), function(i) .OuFdAt(fx, i, h0),
                 numeric(1))
    expect_fd_close(g, fd, refine = function(i, h) .OuFdAt(fx, i, h),
                    h0 = h0, tol = tol,
                    param_names = fx$model$ind$names[fx$free], info = case)

    # The unwhitened seed fails the same check by a wide margin, on the step
    # that suits it best.
    indep <- StratoBayes:::.sb_compute_gradient(
      .OuGradEngine(fx, .Independent(fx$model)), 1L
    )$grad
    worst <- max(vapply(seq_along(fx$free), function(i) {
      min(vapply(ladder, function(h) .FdRelErr(indep[[i]], .OuFdAt(fx, i, h)),
                 numeric(1)))
    }, numeric(1)))
    expect_gt(worst, 100 * tol)
  }
})

test_that("the leapfrog energy error under OU falls as the step squared", {
  args <- .OuFixed()
  fx <- .OuGradFixture(args[[1]], c(args[[2]], overlapPenalty = FALSE))
  indepEngine <- .OuGradEngine(fx, .Independent(fx$model))
  # The potential is always the OU engine's; `forceEngine` supplies the force.
  DeltaH <- function(forceEngine, eps, nStep, p0) {
    Force <- function(x) StratoBayes:::.sb_gradient_at(forceEngine, 1L, x)$grad
    Potential <- function(x) {
      -StratoBayes:::.sb_gradient_at(fx$engine, 1L, x)$logPost
    }
    x <- fx$params
    p <- p0 + 0.5 * eps * Force(x)
    for (k in seq_len(nStep)) {
      x[fx$free] <- x[fx$free] + eps * p
      if (k < nStep) p <- p + eps * Force(x)
    }
    p <- p + 0.5 * eps * Force(x)
    Potential(x) + 0.5 * sum(p^2) - Potential(fx$params) - 0.5 * sum(p0^2)
  }
  set.seed(2)
  p0 <- stats::rnorm(length(fx$free))
  steps <- c(8L, 16L, 32L, 64L)
  len <- 0.02
  whitened <- abs(vapply(steps, function(n) DeltaH(fx$engine, len / n, n, p0),
                         numeric(1)))
  ratios <- whitened[-4] / whitened[-1]
  expect_true(all(ratios > 3.5 & ratios < 4.5), info = toString(ratios))

  # A force that disagrees with the potential leaves an error that does not
  # shrink with the step.
  unwhitened <- abs(vapply(steps, function(n) {
    DeltaH(indepEngine, len / n, n, p0)
  }, numeric(1)))
  expect_gt(unwhitened[[4]], 100 * whitened[[4]])
  expect_lt(unwhitened[[3]] / unwhitened[[4]], 1.5)
})

test_that("the leapfrog's B-only update scores the OU state as a full one", {
  args <- .OuFixed()
  fx <- .OuGradFixture(args[[1]], args[[2]])
  p <- fx$params
  p[fx$free] <- p[fx$free] + 1e-3 * seq_along(fx$free)
  leapfrog <- StratoBayes:::.sb_hmc_eval_logpost(fx$engine, 1L, p)
  full <- StratoBayes:::.sb_eval_logpost(fx$engine, 1L, p, debug = TRUE,
                                         marginal = FALSE)
  expect_true(leapfrog$ok)
  expect_equal(leapfrog$logPostSep, full$logPostSep, tolerance = 1e-12)
})

# A smoke test for the lifted refusals: it would also pass with an
# unwhitened gradient, which the tests above exclude.
test_that("NUTS runs end to end under OU, tempered", {
  args <- .OuFixed()
  model <- suppressWarnings(suppressMessages(
    do.call(StratModel, c(args[1], args[[2]]))
  ))
  td <- withr::local_tempdir("ou-nuts")
  result <- suppressWarnings(RunStratModel(
    stratObject = args[[1]], stratModel = model, nIter = 100, nChains = 2L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    convergenceStop = FALSE, modelDir = td, modelName = "nuts",
    gradientProposals = "on"
  ))
  mcmc <- readRDS(file.path(td, "nuts_mcmc_run_1.rds"))
  expect_true("NUTS" %in% names(mcmc$propose))
  expect_identical(result$model$residualCorrelation$type, "ou")
  expect_gt(sum(result$mcmcSummary$nGradientTransitions), 0)
  expect_true(all(is.finite(result$samples[, "posterior", , ])))
})
