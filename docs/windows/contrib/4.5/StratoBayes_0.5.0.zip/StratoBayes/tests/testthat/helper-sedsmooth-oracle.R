# Age differences inside one formation, recomputed from `sedBeta` by the
# uncached spline code and compared with `ages` (all rows of the signal data).
# Differences remove the alpha anchor, which the cached and full conversions
# share by construction. Returns the number of formations compared.
ExpectAgesMatchUncached <- function(ages, signal, info, sedBeta,
                                    oracleBeta = sedBeta) {
  sites <- unique(signal$site)
  compared <- 0L
  for (f in seq_len(info$nFormations)) {
    fm <- info$formations[[f]]
    rows <- which(signal$site == sites[info$formToSite[f]] &
                    signal$height >= fm$hLow & signal$height <= fm$hHigh)
    if (length(rows) < 2L) next
    heights <- signal$height[rows]
    expected <- StratoBayes:::.sb_sed_spline_ages(oracleBeta, info, f, heights,
                                                  0, 1)
    expect_equal(ages[rows] - ages[rows[1]], expected - expected[1],
                 tolerance = 1e-9)
    compared <- compared + 1L
  }
  compared
}
