MakeRun <- function(dir, name, seed, ...) {
  RunStratModel(stratData1, stratModel1, nIter = 50, nThin = 1,
                nChains = 2L, nRun = 1L, seed = seed, quiet = TRUE,
                nThreads = 1L, runParallel = FALSE, modelDir = dir,
                modelName = name, visualise = FALSE, convergenceStop = FALSE,
                ...)
}

Snapshot <- function(dir) {
  files <- list.files(dir, recursive = TRUE, all.files = TRUE,
                      full.names = TRUE)
  stats::setNames(unname(tools::md5sum(files)), basename(files))
}

test_that("hidden files in a source directory survive keepOriginals = FALSE", {
  skip_on_cran()
  root <- withr::local_tempdir()
  dirA <- file.path(root, "A")
  dirB <- file.path(root, "B")
  dir.create(dirA)
  dir.create(dirB)
  MakeRun(dirA, "A", 1)
  MakeRun(dirB, "B", 2)
  writeLines("notes", file.path(dirB, ".notes"))
  dir.create(file.path(dirB, ".git"))
  writeLines("x", file.path(dirB, ".git", "HEAD"))

  CombineModelRuns(c(dirA, dirB), c("A", "B"), "AB", keepOriginals = FALSE)

  expect_true(file.exists(file.path(dirB, ".notes")))
  expect_true(file.exists(file.path(dirB, ".git", "HEAD")))
})

test_that("an emptied source directory is still removed", {
  skip_on_cran()
  root <- withr::local_tempdir()
  dirA <- file.path(root, "A")
  dirB <- file.path(root, "B")
  dir.create(dirA)
  dir.create(dirB)
  MakeRun(dirA, "A", 1)
  MakeRun(dirB, "B", 2)

  CombineModelRuns(c(dirA, dirB), c("A", "B"), "AB", keepOriginals = FALSE)

  expect_false(dir.exists(dirB))
})

test_that("a source contributing no runs is refused before anything moves", {
  skip_on_cran()
  td <- withr::local_tempdir()
  MakeRun(td, "hot", 1)
  MakeRun(td, "cold", 2)
  missingDir <- file.path(td, "nope")
  before <- Snapshot(td)

  expect_error(CombineModelRuns(td, c("hot", "Cold"), "HC"), "Cold")
  expect_error(CombineModelRuns(c(td, missingDir), c("hot", "cold"), "HC2"),
               "cold")
  expect_error(CombineModelRuns(c(missingDir, td), c("x", "cold"), "XC"),
               "'x'")
  expect_identical(Snapshot(td), before)
})

test_that("$mcmc is kept whichever source saved it", {
  skip_on_cran()
  td <- withr::local_tempdir()
  MakeRun(td, "A", 1, saveMCMC = FALSE)
  MakeRun(td, "B", 2, saveMCMC = TRUE)

  ab <- suppressWarnings(CombineModelRuns(td, c("A", "B"), "AB"))
  ba <- suppressWarnings(CombineModelRuns(td, c("B", "A"), "BA"))

  expect_length(ab[["mcmc"]], 2L)
  expect_length(ba[["mcmc"]], 2L)
})

test_that("integer and double settings do not warn as different", {
  integerSettings <- list(nThin = 1L, nChains = 2L, saveChains = TRUE)
  doubleSettings <- list(nThin = 1, nChains = 2, saveChains = TRUE)
  reference <- .CheckCombinedMCMCSettings(integerSettings, NULL, "A", 1L)

  expect_no_warning(
    .CheckCombinedMCMCSettings(doubleSettings, reference, "B", 1L)
  )
  expect_warning(
    .CheckCombinedMCMCSettings(list(nThin = 1, nChains = 3, saveChains = TRUE),
                               reference, "B", 1L),
    "nChains"
  )
})

test_that("keepOriginals = FALSE leaves no source artefacts in a shared dir", {
  skip_on_cran()
  td <- withr::local_tempdir()
  MakeRun(td, "A", 1)
  MakeRun(td, "B", 2)
  writeLines("boom", file.path(td, "A_error_run_3.txt"))
  saveRDS(list(), file.path(td, "A_errorMessages.rds"))

  CombineModelRuns(td, c("A", "B"), "AB", keepOriginals = FALSE)

  expect_length(list.files(td, pattern = "^(A|B)_"), 0L)
  expect_true(file.exists(file.path(td, "AB_data.rds")))
  expect_true(file.exists(file.path(td, "AB_model.rds")))
})
