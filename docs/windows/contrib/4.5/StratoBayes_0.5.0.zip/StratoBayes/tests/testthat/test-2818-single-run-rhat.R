# #2818: split R-hat over one run compares its two halves, so a run that never
# left a wrong basin passes. print(summary()) must say so whenever the R-hat
# it shows came from one run. Fixture values are not reproducible, so only
# structure is asserted.

caveat <- "cannot detect an alignment the run never visited"

PrintedCaveats <- function(s) {
  sum(grepl(caveat, utils::capture.output(print(s)), fixed = TRUE))
}

# Run 3 of `stratPosterior1` keeps 4 draws past iteration 2500, too few to
# split for R-hat (as in the #1692 test).
TruncatedRun3 <- function(stopped = 2600) {
  sp <- stratPosterior1
  saveIter <- sp[[c("mcmcSummary", "saveIter")]][[3]]
  sp[["mcmcSummary"]][["saveIter"]][[3]] <- saveIter[saveIter <= stopped]
  sp[["mcmcSummary"]][["completedIter"]][[3]] <- stopped
  sp[["mcmcSummary"]][["completedIterIndex"]][[3]] <- sum(saveIter <= stopped)
  .WithClusterCache(sp, lazy = TRUE)
}

test_that("a one-run posterior's R-hat is flagged as single-run", {
  s <- summary(stratPosterior3)
  psrf <- s[[c("general", "psrf")]]
  expect_length(attr(psrf, "runsCompared"), 1L)
  expect_true(any(is.finite(psrf)))
  expect_identical(PrintedCaveats(s), 1L)
})

test_that("R-hat compared across runs carries no single-run caveat", {
  s <- summary(stratPosterior1)
  expect_length(attr(s[[c("general", "psrf")]], "runsCompared"), 3L)
  expect_identical(PrintedCaveats(s), 0L)

  one <- summary(stratPosterior1, runs = 2)
  expect_identical(as.integer(attr(one[[c("general", "psrf")]],
                                   "runsCompared")), 2L)
  expect_identical(PrintedCaveats(one), 1L)
})

test_that("a run left out of R-hat counts against the runs compared", {
  sp <- TruncatedRun3()
  s <- suppressWarnings(summary(sp, burnIn = 2500, alignment = "none",
                                runs = 2:3))
  psrf <- s[[c("general", "psrf")]]
  expect_identical(s[[c("general", "nRun")]], 2L)
  expect_identical(names(attr(psrf, "runsOmitted")), "3")
  expect_length(attr(psrf, "runsCompared"), 1L)
  expect_identical(PrintedCaveats(s), 1L)

  # Nothing was computed, so there is no verdict to qualify.
  none <- suppressWarnings(summary(sp, burnIn = 2500, alignment = "none",
                                   runs = 3))
  expect_false(any(is.finite(none[[c("general", "psrf")]])))
  expect_identical(PrintedCaveats(none), 0L)
})

test_that("a summary without `runsCompared` falls back to its run count", {
  Strip <- function(s) {
    attr(s[["general"]][["psrf"]], "runsCompared") <- NULL
    s
  }
  expect_identical(PrintedCaveats(Strip(summary(stratPosterior3))), 1L)
  expect_identical(PrintedCaveats(Strip(summary(stratPosterior1))), 0L)
})

test_that("a certified automatic burn-in on one run is qualified once", {
  certified <- list(iteration = 600, rHat = 1.003, ess = 400, tauDraws = 1,
                    nRunUsed = 1L, nRunDropped = 0L, rHatMax = 1.02,
                    essTarget = 0, parametersDropped = character(0),
                    drawsAvailable = 400L, minRunRows = 400L, status = "ok")
  local_mocked_bindings(.AutoBurnIn = function(object, ...) certified)
  s <- summary(stratPosterior3, burnIn = "auto")
  out <- utils::capture.output(print(s))
  expect_true(any(grepl("Automatic burn-in: discarding iterations up to 600",
                        out, fixed = TRUE)))
  expect_identical(sum(grepl(caveat, out, fixed = TRUE)), 1L)
})
