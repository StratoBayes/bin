# The per-step `order()` scan the incremental schedule replaced: kept as an
# oracle, since the slot each saved row lands in decides what the live plot
# shows.
OrderScanSchedule <- function(nRow, saveIter, propDiscard = 0.25) {
  nIt <- length(saveIter)
  mat <- matrix(NA, nrow = nIt, ncol = 2)
  lastPos <- integer(nRow)
  for (itInd in seq_len(nIt)) {
    iter <- saveIter[itInd]
    if (itInd <= nRow) {
      mat[itInd, ] <- c(itInd, iter)
      lastPos[itInd] <- itInd
    } else {
      relMat <- mat[lastPos, ]
      toReplace <- which(relMat[, 2] < floor(propDiscard * iter))
      if (length(toReplace) > 0) {
        replaceInd <- toReplace[which.min(relMat[toReplace, 2])]
      } else {
        itersOrder <- order(relMat[, 2])
        itersOrdered <- relMat[itersOrder, 2]
        diffs <- itersOrdered[2:nRow] - itersOrdered[1:(nRow - 1)]
        replaceInd <- itersOrder[which.min(diffs) + 1]
      }
      mat[itInd, ] <- c(replaceInd, iter)
      lastPos[replaceInd] <- itInd
    }
  }
  mat[, 1]
}

test_that("the live-plot slot schedule matches the order() scan", {
  set.seed(2594)
  grids <- list(
    1:10, 1:50, 1:51,
    seq(5, 5000, by = 5),
    c(1:100, seq(105, 3000, by = 5)),
    seq(1003, 60000, by = 3),
    cumsum(sample(1:20, 4000, replace = TRUE))
  )
  for (saveIter in grids) {
    expect_equal(
      .PlotSampleMatrixUpdateIndices(nRow = 50, saveIter = saveIter),
      OrderScanSchedule(nRow = 50, saveIter = saveIter)
    )
  }
  expect_identical(
    .PlotSampleMatrixUpdateIndices(nRow = 50, saveIter = numeric(0)),
    numeric(0)
  )
})

test_that("scheduling a long save grid stays cheap", {
  skip_on_cran()
  elapsed <- system.time(
    .PlotSampleMatrixUpdateIndices(nRow = 50, saveIter = seq(5, 1e6, by = 5))
  )[["elapsed"]]
  expect_lt(elapsed, 5)
})
