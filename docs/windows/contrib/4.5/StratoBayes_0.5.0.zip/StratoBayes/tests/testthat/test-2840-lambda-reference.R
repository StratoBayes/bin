# Hot-rung λ reference (#2840): rung T targets posterior^(1/T) * r(λ)^(1 - 1/T),
# r a log-normal fitted to the cold chain at each ladder update. Runs are
# nThreads = 1; a model's construction draws random spline fits, so each test
# builds its own under a seed.

.lrModel <- function(priors = stratPrior1) {
  StratModel(stratData1, priors = priors, alignmentScale = "height",
             sedModel = "site", alphaPosition = "bottom", nKnots = 10,
             residualCorrelation = "none")
}

.lrRun <- function(sm, mc, dir = tempfile()) {
  post <- suppressMessages(
    RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                  convergenceStop = FALSE, quiet = TRUE, visualise = FALSE,
                  seed = 1L, modelDir = dir, modelName = "lr")
  )
  list(post = post, mcmc = readRDS(file.path(dir, "lr_mcmc_run_1.rds")))
}

# An engine resumed from a finished run, with replica swaps switched off so
# each rung samples its own target.
.lrEngine <- function(run) {
  model <- run$post$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- run$mcmc
  mcmc[[c("temper", "nSwaps")]] <- 0L
  StratoBayes:::.sb_create_engine(
    data = run$post$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
}

# log r(λ) up to the engine's constant: log-normal density in λ.
.lrLogRef <- function(lambda, centre, scale) {
  -log(lambda) - 0.5 * ((log(lambda) - centre) / scale)^2
}

test_that("the reference is fitted with the ladder and carried on", {
  skip_on_cran()
  set.seed(1)
  sm <- .lrModel()
  dir <- tempfile()
  mc <- StratMCMC(sm, nIter = 1200L, nChains = 4L, endAdapting = 600L,
                  nThreads = 1L)
  ref <- .lrRun(sm, mc, dir)$mcmc[[c("temper", "lambdaRef")]]
  nSignals <- length(stratData1[[c("signalAttr", "signalNames")]])
  expect_length(ref[["centre"]], nSignals)
  expect_true(all(is.finite(ref[["centre"]])))
  expect_true(all(ref[["scale"]] >= .LambdaRefMinScale))

  suppressMessages(
    RunStratModel(modelDir = dir, modelName = "lr", nIter = 200L,
                  runParallel = FALSE, convergenceStop = FALSE, quiet = TRUE,
                  visualise = FALSE)
  )
  continued <- readRDS(file.path(dir, "lr_mcmc_run_1.rds"))
  expect_identical(continued[[c("temper", "lambdaRef")]], ref)
})

test_that("the reference is off where it cannot be fitted or targeted", {
  skip_on_cran()
  set.seed(1)
  sm <- .lrModel()
  Ref <- function(...) {
    mc <- StratMCMC(sm, nIter = 600L, endAdapting = 300L, nThreads = 1L, ...)
    .lrRun(sm, mc)$mcmc[[c("temper", "lambdaRef")]]
  }
  expect_null(Ref(nChains = 1L, tempering = FALSE))
  expect_null(Ref(nChains = 4L, adaptTemperatures = FALSE))
  # An infinite rung that tempers the prior has no proper target, so
  # StratMCMC() refuses it (#2817); one that holds the prior at T = 1 has one,
  # and takes the reference.
  expect_error(Ref(nChains = 4L, temperatures = c(1, 2, 4, Inf)),
               "infinite top rung")
  expect_length(Ref(nChains = 4L, temperatures = c(1, 2, 4, Inf),
                    temperingComponents = "signal")[["scale"]], 1L)
})

test_that("the reference exports check their inputs", {
  skip_on_cran()
  set.seed(1)
  sm <- .lrModel()
  run <- .lrRun(sm, StratMCMC(sm, nIter = 10L, nChains = 2L, nThreads = 1L))
  engine <- .lrEngine(run)
  nSignals <- length(run$post$data[[c("signalAttr", "signalNames")]])
  Set <- function(centre, scale) {
    StratoBayes:::.sb_set_lambda_reference(engine, centre, scale, TRUE)
  }
  Fit <- function(inflate = 2, minScale = 0.5) {
    StratoBayes:::.sb_lambda_reference_fit(engine, inflate, minScale)
  }

  expect_error(Fit(), "not collecting")
  expect_error(Set(1, numeric()), "one entry per signal")
  expect_error(Set(rep(0, nSignals), rep(-1, nSignals)), "positive")
  Set(numeric(), numeric())
  expect_error(Fit(inflate = 0), "positive and finite")
  # Nothing collected yet: the reference stays off.
  fit <- Fit()
  expect_length(fit$scale, 0)
  expect_identical(fit$n, 0)
})

test_that("each rung's swap energy is its tempered energy less log r", {
  skip_on_cran()
  set.seed(1)
  sm <- .lrModel()
  run <- .lrRun(sm, StratMCMC(sm, nIter = 10L, nChains = 3L,
                              temperatures = c(1, 2, 4), nThreads = 1L))
  engine <- .lrEngine(run)
  centre <- 3
  scale <- 0.7
  StratoBayes:::.sb_set_lambda_reference(engine, centre, scale, FALSE)
  StratoBayes:::.sb_run_block(engine, 1L)
  buffer <- StratoBayes:::.sb_get_ring_buffer(engine)
  lambda <- vapply(StratoBayes:::.sb_extract_state(engine),
                   function(chain) chain[[c("gibbs", "lambda")]], numeric(1))
  expect_equal(buffer$swapEnergy - buffer$logPost,
               -.lrLogRef(lambda, centre, scale), tolerance = 1e-10)
})

test_that("a hot rung samples its tempered target times r^(1 - 1/T)", {
  skip_on_cran()
  # With the alignment pinned and swaps off, the hot rung's λ alone moves, so
  # its law is a one-dimensional density we can tabulate exactly.
  pinned <- c(alpha_site_2 = 2, alpha_site_3 = 4, gammaLog_site_2 = 0,
              gammaLog_site_3 = 0)
  priors <- stratPrior1
  for (p in names(priors)) priors[[p]] <- Fixed(pinned[[p]])
  set.seed(1)
  sm <- .lrModel(priors)
  temperature <- 3
  run <- .lrRun(sm, StratMCMC(sm, nIter = 10L, nChains = 2L,
                              temperatures = c(1, temperature),
                              adaptTemperatures = FALSE, nThreads = 1L))
  model <- run$post$model
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  data <- run$post$data
  state <- .GenerateInitialState(data, model, run$mcmc, 1L)
  gibbs <- model[[c("priors", "gibbs")]]
  logLambda <- seq(log(gibbs[["lambdaMin"]]) + 0.01, 25, by = 0.01)
  Untempered <- vapply(exp(logLambda), function(lambda) {
    state[[c("gibbs", "lambda")]] <- lambda
    .LogPost(data, model, state, marginal = TRUE)[[2]] +
      dgamma(lambda, gibbs[["aLambda"]], scale = gibbs[["bLambda"]],
             log = TRUE)
  }, numeric(1))
  Moments <- function(logDensity) {
    w <- exp(logDensity - max(logDensity))
    w <- w / sum(w)
    m <- sum(w * logLambda)
    c(mean = m, sd = sqrt(sum(w * (logLambda - m)^2)))
  }
  # r sits 1.5 above the cold mode, where it moves the hot law well clear of
  # where it would be without r.
  centre <- logLambda[[which.max(Untempered + logLambda)]] + 1.5
  scale <- 0.5
  withRef <- Moments(Untempered / temperature + logLambda +
                       (1 - 1 / temperature) *
                         .lrLogRef(exp(logLambda), centre, scale))
  withoutRef <- Moments(Untempered / temperature + logLambda)

  engine <- .lrEngine(run)
  StratoBayes:::.sb_set_lambda_reference(engine, centre, scale, FALSE)
  draws <- vapply(seq_len(1500), function(i) {
    StratoBayes:::.sb_run_block(engine, 4L)
    StratoBayes:::.sb_extract_state(engine)[[2]][[c("gibbs", "lambda")]]
  }, numeric(1))
  hot <- log(draws[-seq_len(200)])
  tolerance <- 4 * withRef[["sd"]] / sqrt(.EssFunc(hot))
  expect_gt(abs(withRef[["mean"]] - withoutRef[["mean"]]), 5 * tolerance)
  expect_lt(abs(mean(hot) - withRef[["mean"]]), tolerance)
  expect_lt(abs(sd(hot) / withRef[["sd"]] - 1), 0.15)
})

# Exact stationary law of a two-rung chain over a discrete joint
# pi(a, lambda, beta), each in {1, 2, 3}, moving in the engine's order: a by MH
# on the beta-marginal, then (hot rung) lambda by MH on
# marginal^(1/T) * r^(1 - 1/T) and beta exactly, or (cold rung) beta and
# lambda by Gibbs. Checks the scheme, not the engine.
.RefRungKernel <- function(joint, temperature, logRef) {
  n <- dim(joint)[[1]]
  marginal <- apply(joint, c(1, 2), sum)
  states <- expand.grid(a = seq_len(n), l = seq_len(n), b = seq_len(n))
  Index <- function(a, l, b) a + n * (l - 1L) + n^2 * (b - 1L)
  invT <- 1 / temperature
  Move <- function(logRatio) min(1, exp(logRatio)) / (n - 1L)
  MhDist <- function(current, LogTarget) {
    dist <- numeric(n)
    for (proposal in setdiff(seq_len(n), current)) {
      move <- Move(LogTarget(proposal) - LogTarget(current))
      dist[[proposal]] <- move
      dist[[current]] <- dist[[current]] + 1 / (n - 1L) - move
    }
    dist
  }
  kernel <- matrix(0, nrow(states), nrow(states))
  for (i in seq_len(nrow(states))) {
    l <- states$l[[i]]
    aDist <- MhDist(states$a[[i]], function(a) invT * log(marginal[a, l]))
    for (a2 in which(aDist > 0)) {
      if (temperature == 1) {
        betaDist <- joint[a2, l, ] / sum(joint[a2, l, ])
        for (b2 in seq_len(n)) {
          lambdaDist <- joint[a2, , b2] / sum(joint[a2, , b2])
          j <- Index(a2, seq_len(n), b2)
          kernel[i, j] <- kernel[i, j] + aDist[[a2]] * betaDist[[b2]] *
            lambdaDist
        }
      } else {
        lambdaDist <- MhDist(l, function(l2) {
          invT * log(marginal[a2, l2]) + (1 - invT) * logRef[[l2]]
        })
        for (l2 in which(lambdaDist > 0)) {
          betaDist <- joint[a2, l2, ] / sum(joint[a2, l2, ])
          j <- Index(a2, l2, seq_len(n))
          kernel[i, j] <- kernel[i, j] + aDist[[a2]] * lambdaDist[[l2]] *
            betaDist
        }
      }
    }
  }
  list(kernel = kernel, energy = log(marginal[cbind(states$a, states$l)]),
       logRef = logRef[states$l])
}

.RefColdLawError <- function(joint, hotTemperature, logRef, swapUsesRef) {
  cold <- .RefRungKernel(joint, 1, logRef)
  hot <- .RefRungKernel(joint, hotTemperature, logRef)
  n <- nrow(cold[["kernel"]])
  energy <- cold[["energy"]] - if (swapUsesRef) cold[["logRef"]] else 0
  pair <- expand.grid(hot = seq_len(n), cold = seq_len(n))
  swapRatio <- pmin(1, exp((energy[pair$hot] - energy[pair$cold]) *
                             (1 - 1 / hotTemperature)))
  from <- (pair$cold - 1L) * n + pair$hot
  to <- (pair$hot - 1L) * n + pair$cold
  swap <- matrix(0, n^2, n^2)
  swap[cbind(from, to)] <- swap[cbind(from, to)] + swapRatio
  swap[cbind(from, from)] <- swap[cbind(from, from)] + 1 - swapRatio
  chain <- kronecker(cold[["kernel"]], hot[["kernel"]]) %*% swap
  stationary <- qr.solve(rbind(t(chain) - diag(n^2), 1), c(numeric(n^2), 1))
  coldLaw <- rowSums(matrix(stationary, n, n, byrow = TRUE))
  max(abs(coldLaw - as.vector(joint)))
}

test_that("an exact two-rung chain keeps the cold law with the reference", {
  set.seed(2840)
  for (hotTemperature in c(2, 5)) {
    joint <- array(rgamma(27, 1), c(3, 3, 3))
    joint <- joint / sum(joint)
    logRef <- log(c(0.1, 0.3, 0.6))
    expect_lt(.RefColdLawError(joint, hotTemperature, logRef, TRUE), 1e-12)
    expect_gt(.RefColdLawError(joint, hotTemperature, logRef, FALSE), 1e-3)
  }
})
