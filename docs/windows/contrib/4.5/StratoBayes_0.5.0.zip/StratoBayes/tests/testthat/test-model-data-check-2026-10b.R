mdcTies <- stratData2[["ties"]]
mdcSignal <- stratData2[["signal"]]
mdcParts <- stratData2[["parts"]][, c("site", "height", "partition")]

MdcData <- function(signal = mdcSignal, ties = mdcTies, parts = mdcParts,
                    ...) {
  suppressWarnings(
    StratData(signal, ties = ties, parts = parts, signalColumn = c("a", "b"),
              ...)
  )
}

MdcModel <- function(data, sedModel = "site", ...) {
  StratModel(data, alignmentScale = "height", sedModel = sedModel, ...)
}

MdcRun <- function(data, model, modelDir = tempfile("mdc"), nIter = 20,
                   ...) {
  RunStratModel(data, model, nRun = 1, nIter = nIter, nChains = 2,
                nThreads = 1L, runParallel = FALSE, seed = 3,
                visualise = FALSE, convergenceStop = FALSE, quiet = TRUE,
                modelDir = modelDir, modelName = "mdc", ...)
}

mdcRefusal <- "`stratObject` does not correspond to `stratModel`"

test_that("RunStratModel() refuses a model built for other data (#2710)", {
  full <- MdcData()
  model <- MdcModel(full)
  noSite3 <- MdcData(
    signal = mdcSignal[mdcSignal[["site"]] != "site3", ],
    ties = mdcTies[mdcTies[["site"]] != "site3", ],
    parts = mdcParts[mdcParts[["site"]] != "site3", ]
  )
  extraPart <- MdcData(parts = rbind(
    mdcParts, data.frame(site = "site3", height = 10, partition = "part 3.0")
  ))
  extraGap <- MdcData(parts = rbind(
    mdcParts,
    data.frame(site = "site3", height = c(10, 5),
               partition = c(NA, "part 3.0"))
  ))
  untied <- MdcData(ties = NULL)
  Refused <- function(data, model, ...) {
    expect_error(MdcRun(data, model, ...), mdcRefusal, fixed = TRUE)
  }

  # case 1: a tie the model never saw is not silently dropped
  Refused(full, MdcModel(MdcData(ties = mdcTies[1:2, ])))
  # case 2: a different reference site relabels every parameter
  Refused(MdcData(referenceSite = "site2"), model)
  # case 3: the C++ engine would read past the model's rate indices
  Refused(extraPart, MdcModel(full, "partition"), engine = "R")
  Refused(noSite3, model)
  Refused(full, MdcModel(noSite3))
  Refused(extraGap, model)
  Refused(extraPart, model)
  Refused(MdcData(signal = mdcSignal[-(1:10), ]), model)
  Refused(full, MdcModel(untied))
  Refused(untied, model)
})

test_that("a refused run leaves the existing run untouched (#2710)", {
  full <- MdcData()
  modelDir <- withr::local_tempdir()
  MdcRun(full, MdcModel(full), modelDir = modelDir)
  Fingerprint <- function() tools::md5sum(sort(list.files(
    modelDir, full.names = TRUE, recursive = TRUE, all.files = TRUE
  )))
  before <- Fingerprint()
  expect_error(
    MdcRun(MdcData(referenceSite = "site2"), MdcModel(full),
           modelDir = modelDir),
    mdcRefusal, fixed = TRUE
  )
  expect_identical(Fingerprint(), before)
})

test_that("a model built for the data still runs (#2710)", {
  full <- MdcData()
  run <- MdcRun(full, MdcModel(full, disableTies = list(site3 = 1)),
                modelDir = withr::local_tempdir())
  expect_s3_class(run, "StratPosterior")
})

# The functions must be closures of globalenv() reading another global, as
# when a script defines them at its top level.
GlobalScalePrior <- function(scale, env = parent.frame()) {
  assign("mdcScale2675", scale, envir = globalenv())
  withr::defer(
    if (exists("mdcScale2675", envir = globalenv(), inherits = FALSE)) {
      rm("mdcScale2675", envir = globalenv())
    },
    envir = env
  )
  myD <- function(x, m, log = FALSE) dnorm(x, m, mdcScale2675, log = log)
  myR <- function(n, m) rnorm(n, m, mdcScale2675)
  myQ <- function(p, m) qnorm(p, m, mdcScale2675)
  environment(myD) <- environment(myR) <- environment(myQ) <- globalenv()
  structure(list(alpha_site2 = Prior(myR, myD, myQ, m = 1)),
            class = c("StratPrior", "list"))
}

GlobalScaleModel <- function(priors) {
  StratModel(stratData0, priors = priors, alignmentScale = "height",
             sedModel = "site", nKnots = 10)
}

test_that("priors reading globals are named for parallel runs (#2675)", {
  model <- GlobalScaleModel(GlobalScalePrior(2))
  expect_identical(.PriorsReadingGlobals(model), "alpha_site2")

  proposals <- model
  proposals[["priorsProposals"]] <- proposals[[c("priors", "metro")]]
  proposals[[c("priors", "metro")]] <- stratModel1[[c("priors", "metro")]]
  expect_identical(.PriorsReadingGlobals(proposals), "alpha_site2")

  LocalPrior <- function() {
    localScale <- 2
    Prior(function(n, m) rnorm(n, m, localScale),
          function(x, m, log = FALSE) dnorm(x, m, localScale, log = log),
          function(p, m) qnorm(p, m, localScale), m = 1)
  }
  localModel <- model
  localModel[[c("priors", "metro", "alpha_site2")]] <- LocalPrior()
  localModel[["priorsProposals"]] <- NULL
  expect_identical(.PriorsReadingGlobals(localModel), character(0))
  expect_identical(.PriorsReadingGlobals(stratModel1), character(0))
})

test_that("runParallel warns about priors reading globals (#2675)", {
  skip_on_cran()  # spawns worker processes
  skip_if_not_installed("future.apply")
  skip_if(!file.exists(file.path(find.package("StratoBayes"), "R",
                                 "StratoBayes.rdb")),
          "dev session: parallel workers would load the installed build")
  model <- GlobalScaleModel(GlobalScalePrior(2))
  expect_warning(
    try(
      RunStratModel(stratData0, model, nRun = 2, nIter = 20, nChains = 2,
                    nThreads = 1L, runParallel = TRUE, nCores = 2L,
                    seed = 1:2, visualise = FALSE, quiet = TRUE,
                    modelDir = withr::local_tempdir(), modelName = "g"),
      silent = TRUE
    ),
    "alpha_site2"
  )
})

test_that("continuation sees a changed global read by a prior (#2675)", {
  priors <- GlobalScalePrior(2)
  modelDir <- withr::local_tempdir()
  common <- list(nThreads = 1L, convergenceStop = FALSE,
                 quiet = TRUE, visualise = FALSE, runParallel = FALSE,
                 modelDir = modelDir, modelName = "c")
  do.call(RunStratModel, c(list(stratData0, GlobalScaleModel(priors),
                                nIter = 20, nChains = 2, seed = 1), common))
  assign("mdcScale2675", 50, envir = globalenv())
  expect_warning(
    do.call(RunStratModel, c(list(stratModel = GlobalScaleModel(priors),
                                  nIter = 5), common)),
    "priors: alpha_site2"
  )
})

test_that("a StratPosterior's model is not called `stratModel` (#2712)", {
  common <- list(nThreads = 1L, convergenceStop = FALSE, quiet = TRUE,
                 visualise = FALSE, runParallel = FALSE)
  r1 <- do.call(RunStratModel, c(list(stratData1, stratModel1, nIter = 20,
                                      nChains = 2, seed = 1,
                                      modelDir = withr::local_tempdir()),
                                 common))
  r1[[c("model", "priors", "metro", "gammaLog_site_2")]] <-
    NormalPrior(0.3, 1)
  caught <- capture_warnings(
    do.call(RunStratModel, c(list(r1, nIter = 5), common))
  )
  differs <- grep("differs from", caught, value = TRUE)
  expect_length(differs, 1L)
  expect_match(differs, "The model in this StratPosterior differs",
               fixed = TRUE)
  expect_no_match(differs, "stratModel", fixed = TRUE)
})

test_that("a density forwarding `...` from a factory still runs (#2675)", {
  Factory <- function(dfun, rfun, qfun, ...) {
    Prior(function(n, m) rfun(n, m, ...),
          function(x, m, log = FALSE) dfun(x, m, ..., log = log),
          function(p, m) qfun(p, m, ...), m = 1)
  }
  priors <- structure(
    list(alpha_site2 = Factory(dnorm, rnorm, qnorm, sd = 2)),
    class = c("StratPrior", "list")
  )
  modelDir <- withr::local_tempdir()
  common <- list(nThreads = 1L, convergenceStop = FALSE, quiet = TRUE,
                 visualise = FALSE, runParallel = FALSE,
                 modelDir = modelDir, modelName = "f")
  r1 <- do.call(RunStratModel, c(list(stratData0, GlobalScaleModel(priors),
                                      nIter = 20, nChains = 2, seed = 1),
                                 common))
  expect_true(file.exists(file.path(modelDir, "f_model.rds")))
  expect_no_warning(
    do.call(RunStratModel, c(list(r1, nIter = 5), common)),
    message = "differs from"
  )
})

test_that("a global sharing a name with a local is not keyed (#2675)", {
  assign("mdcLoop2675", 1, envir = globalenv())
  withr::defer(rm("mdcLoop2675", envir = globalenv()))
  myD <- function(x, m, log = FALSE) {
    for (mdcLoop2675 in 1) x <- x * mdcLoop2675
    dnorm(x, m, 2, log = log)
  }
  environment(myD) <- globalenv()
  expect_identical(.FreeNamesIn(myD), character(0))
})

test_that("continuing a folder with a model for other data is refused", {
  full <- MdcData()
  modelDir <- withr::local_tempdir()
  MdcRun(full, MdcModel(full), modelDir = modelDir)
  expect_error(
    RunStratModel(stratModel = MdcModel(MdcData(ties = mdcTies[1:2, ])),
                  modelDir = modelDir, modelName = "mdc", nIter = 5,
                  nThreads = 1L, runParallel = FALSE, visualise = FALSE,
                  quiet = TRUE),
    "`mdc_data.rds` does not correspond to `stratModel`", fixed = TRUE
  )
  continued <- RunStratModel(modelDir = modelDir, modelName = "mdc",
                             nIter = 5, nThreads = 1L, runParallel = FALSE,
                             visualise = FALSE, quiet = TRUE,
                             convergenceStop = FALSE)
  expect_null(attr(continued[["model"]], "priorKeys"))
})

test_that("a folder-only continuation sees a changed global (#2675)", {
  priors <- GlobalScalePrior(2)
  modelDir <- withr::local_tempdir()
  common <- list(nThreads = 1L, convergenceStop = FALSE, quiet = TRUE,
                 visualise = FALSE, runParallel = FALSE,
                 modelDir = modelDir, modelName = "g")
  do.call(RunStratModel, c(list(stratData0, GlobalScaleModel(priors),
                                nIter = 20, nChains = 2, seed = 1), common))
  expect_no_warning(do.call(RunStratModel, c(list(nIter = 5), common)),
                    message = "custom prior density")
  assign("mdcScale2675", 50, envir = globalenv())
  expect_warning(do.call(RunStratModel, c(list(nIter = 5), common)),
                 "custom prior density")
})

test_that("StratPosterior refusals do not name `stratModel` (#2712)", {
  modelDir <- withr::local_tempdir()
  saveRDS(stratModel1, file.path(modelDir, "m_model.rds"))
  renamed <- stratModel1
  renamed[["outputParams"]][[2]] <- "x"
  expect_error(
    .CheckModelAgainstStored(renamed, modelDir, "m", fromPosterior = TRUE),
    "The model in this StratPosterior's output parameter 2 is 'x'",
    fixed = TRUE
  )
})
