# Follow-ups to #2817. Sampled offsets add two improper directions: sigma with
# every offset and tau, and tau with the offsets of groups a signal never
# observes. An infinite top rung is improper wherever it tempers the prior, or
# the offsets' prior, away. A template's ladder is checked against the model it
# is run with.

OffsetModel <- function(nGroups = 6L, tauFixed = FALSE, nPerSite = 10L,
                        nObsPerGroup = NULL, sigmaFixed = FALSE) {
  list(
    sigmaFixed = sigmaFixed,
    priors = list(gibbs = list(aSigma = 0.01,
                               shapeSigma = 0.01 + nGroups * nPerSite / 2)),
    offsetConfig = list(active = TRUE, nGroups = nGroups, aTau = 1,
                        tauFixed = tauFixed, nObsPerGroup = nObsPerGroup)
  )
}

OffsetData <- function(observedB = 6L) {
  set.seed(2817)
  sites <- paste0("s", 1:6)
  h <- seq(0, 10, length.out = 10)
  sig <- do.call(rbind, lapply(seq_along(sites), function(i) {
    data.frame(site = sites[[i]], height = h,
               a = sin(h) + (i - 3.5) / 3 + rnorm(10, 0, 0.1),
               b = if (i <= observedB) cos(h) + rnorm(10, 0, 0.1) else NA)
  }))
  StratData(signal = sig, signalColumn = if (observedB) c("a", "b") else "a",
            group = data.frame(site = sites, group = paste0("G", 1:6)))
}

test_that("sampled offsets bound sigma at (n + G - 2 + 2 aSigma) / (G - 2)", {
  # n = 60, G = 6: the offsets direction binds long before n - 1 + 2 aSigma.
  rays <- .SigmaRayBounds(OffsetModel(), 15L)
  expect_equal(unname(rays[, "sigma"]), 59.02)
  expect_equal(unname(rays[, "offsets"]), 64.02 / 4)
  expect_equal(.SigmaTemperatureBound(OffsetModel(), 15L), 64.02 / 4)
  # Holding the prior at T = 1 keeps sigma's own decay, not the offsets'.
  for (mask in c(2L, 6L)) {
    rays <- .SigmaRayBounds(OffsetModel(), mask)
    expect_identical(unname(rays[, "sigma"]), Inf)
    expect_equal(unname(rays[, "offsets"]), 63 / 2.98)
  }
})

test_that("groups a signal never observes bound tau at (G - 1) / (f - 2)", {
  # Signal b has no observations in 4 of 6 groups: bound 5 / 2, sigma fixed or
  # not, under any mask that tempers the signal.
  observed <- list(a = rep(10, 6), b = c(10, 10, 0, 0, 0, 0))
  for (sigmaFixed in list(FALSE, 0.1)) {
    model <- OffsetModel(nObsPerGroup = observed, sigmaFixed = sigmaFixed)
    model[[c("priors", "gibbs", "shapeSigma")]] <- c(a = 30.01, b = 10.01)
    for (mask in c(15L, 2L, 6L)) {
      expect_equal(unname(.SigmaRayBounds(model, mask)[, "unobserved"]),
                   c(Inf, 2.5))
      expect_equal(.SigmaTemperatureBound(model, mask), 2.5)
    }
    expect_identical(.SigmaTemperatureBound(model, 4L), Inf)
  }
  # Two unobserved groups stay proper: 2 - 2 aTau is not positive.
  twoMissing <- OffsetModel(nObsPerGroup = list(c(1, 1, 1, 1, 0, 0)))
  expect_identical(unname(.SigmaRayBounds(twoMissing, 15L)[, "unobserved"]),
                   Inf)
  expect_identical(.SigmaTemperatureBound(
    OffsetModel(nObsPerGroup = observed["b"], tauFixed = TRUE,
                sigmaFixed = 0.1), 15L
  ), Inf)
})

test_that("a model with unobserved offset groups cannot use a default ladder", {
  m <- suppressMessages(StratModel(OffsetData(observedB = 2L), priors = NULL,
                                   alignmentScale = "height",
                                   sedModel = "site", nKnots = 8,
                                   signalOffsets = TRUE))
  expect_equal(.SigmaTemperatureBound(m, 15L), 2.5)
  expect_error(StratMCMC(m, nIter = 10, nChains = 8),
               "only below temperature 2.5.*offsetPriorScale")
  expect_error(StratMCMC(m, nIter = 10, nChains = 4,
                         temperatures = c(1, 1.5, 2, 3)),
               "no observations in 4 of its 6 offset groups.*offsetPriorScale")
  expect_silent(StratMCMC(m, nIter = 10, nChains = 4,
                          temperatures = c(1, 1.5, 2, 2.4)))
  expect_identical(.SigmaTemperatureBound(m, 4L), Inf)
})

test_that("the offsets direction needs tau sampled and enough groups", {
  expect_equal(.SigmaTemperatureBound(OffsetModel(tauFixed = TRUE), 15L),
               59.02)
  # G = 3: (n + G - 2 + 2 aSigma) / (G - 2) = 46.02 / 1 lies above 44.02.
  expect_equal(.SigmaTemperatureBound(OffsetModel(nGroups = 3L, nPerSite = 15L),
                                      15L), 44.02)
  expect_identical(.SigmaTemperatureBound(OffsetModel(), 4L), Inf)
})

test_that("an infinite top rung is refused where its target is improper", {
  expect_error(StratMCMC(stratModel1, nIter = 10, nChains = 3,
                         temperatures = c(1, 2, Inf)),
               "infinite top rung.*every component is tempered away")
  expect_silent(StratMCMC(stratModel1, nIter = 10, nChains = 3,
                          temperatures = c(1, 2, Inf),
                          temperingComponents = "signal"))
  expect_silent(StratMCMC(stratModel3, nIter = 10, nChains = 3,
                          temperatures = c(1, 2, Inf),
                          temperingComponents = "signal"))
  expect_true(.InfiniteRungProper(OffsetModel(), 4L))
  expect_false(.InfiniteRungProper(OffsetModel(), 2L))
  expect_false(.InfiniteRungProper(OffsetModel(), 6L))
})

test_that("a model with sampled offsets caps and checks its ladder", {
  m <- suppressMessages(StratModel(OffsetData(observedB = 0L), priors = NULL,
                                   alignmentScale = "height",
                                   sedModel = "site", nKnots = 10,
                                   signalOffsets = TRUE, sigmaFixed = FALSE))
  bound <- 64.02 / 4
  expect_equal(.SigmaTemperatureBound(m, 15L), bound)

  mcmc <- StratMCMC(m, nIter = 10, nChains = 8)
  expect_equal(mcmc[[c("temper", "temperatures")]][[8]],
               .kSigmaCeiling * bound)
  expect_error(StratMCMC(m, nIter = 10, nChains = 4,
                         temperatures = c(1, 4, 10, 20)),
               "its 6 offset groups.*offsetPriorScale")
  expect_error(StratMCMC(m, nIter = 10, nChains = 3,
                         temperatures = c(1, 2, Inf),
                         temperingComponents = "signal"),
               "offsets' prior away")
})

test_that("a template's ladder is checked against the model it runs with", {
  sigmaFixedModel <- stratModel3
  sigmaFixedModel[["sigmaFixed"]] <- 0.5
  template <- StratMCMC(sigmaFixedModel, nIter = 10, nChains = 8)
  expect_identical(template[[c("temper", "temperatures")]][[8]], 80)
  dir <- withr::local_tempdir()
  expect_error(
    RunStratModel(stratData3, stratModel = stratModel3, stratMCMC = template,
                  visualise = FALSE, quiet = TRUE, runParallel = FALSE,
                  nThreads = 1L, modelDir = dir, modelName = "tmpl"),
    "ladder of `stratMCMC` reaches 80.*build `stratMCMC` from this model"
  )
})
