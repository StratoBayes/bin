# Under residualCorrelation = "ou", a site whose residual variogram is mostly
# nugget gets independent residuals (#2813), but only above the share where
# pure OU starts to misplace sites, and only where corLength is long enough
# for that share to be identified.

# A stationary OU draw, e[1] ~ N(0, 1), with the given correlation length.
.NuggetOu <- function(z, ell) {
  e <- numeric(length(z))
  e[1] <- stats::rnorm(1)
  for (i in seq_along(z)[-1]) {
    phi <- exp(-(z[i] - z[i - 1]) / ell)
    e[i] <- phi * e[i - 1] + sqrt(1 - phi^2) * stats::rnorm(1)
  }
  e
}

# Unit-variance residuals on a unit grid, a share `f` of them white noise.
.NuggetResiduals <- function(f, seed, z = 0:199) {
  withr::with_seed(seed, {
    list(z = z, r = sqrt(1 - f) * .NuggetOu(z, 3) +
           sqrt(f) * stats::rnorm(length(z)))
  })
}

.TwoSites <- function() {
  matrix(NA_real_, 2, 1, dimnames = list(c("A", "B"), "value"))
}

test_that("a moderate nugget keeps the OU fit, without a message", {
  modest <- .NuggetResiduals(0.5, 1)
  expect_no_message(
    est <- StratoBayes:::.EstimateCorLength(
      .TwoSites(), list(list(.NuggetResiduals(0, 5), modest))
    )
  )
  expect_gt(est$nuggetFraction[2, 1], 0.5)
  expect_lt(est$nuggetFraction[2, 1], StratoBayes:::.kOuNuggetMax)
  expect_gt(est$corLength[2, 1], 1)
})

test_that("a dominant nugget gives that site independent residuals", {
  smooth <- .NuggetResiduals(0, 5)
  noisy <- .NuggetResiduals(0.9, 1)
  expect_message(
    est <- StratoBayes:::.EstimateCorLength(.TwoSites(),
                                            list(list(smooth, noisy))),
    paste0("nugget for site 'B' signal 'value' \\(9[0-9]%, fitted ",
           "corLength [0-9.]+\\).*treated as independent")
  )
  expect_identical(unname(est$corLength[2, 1]), 0)
  expect_gt(est$nuggetFraction[2, 1], StratoBayes:::.kOuNuggetMax)
  expect_gt(est$corLength[1, 1], 1)
  expect_identical(unname(est$source[, 1]), c("site", "site"))

  given <- .TwoSites()
  given["B", "value"] <- 5
  expect_no_message(
    est <- StratoBayes:::.EstimateCorLength(given, list(list(smooth, noisy)))
  )
  expect_identical(unname(est$corLength[2, 1]), 5)
})

test_that("a corLength below the median spacing is not acted on", {
  Fit <- function(corLength) {
    function(vg, upper) {
      list(corLength = corLength, nuggetFraction = 0.99, sill = 1,
           atBound = FALSE)
    }
  }
  site <- list(list(.NuggetResiduals(0.9, 1)))
  one <- matrix(NA_real_, 1, 1, dimnames = list("A", "value"))

  testthat::local_mocked_bindings(.FitExpVariogram = Fit(0.5),
                                  .package = "StratoBayes")
  expect_no_message(est <- StratoBayes:::.EstimateCorLength(one, site))
  expect_identical(unname(est$corLength[1, 1]), 0.5)
  expect_identical(unname(est$nuggetFraction[1, 1]), 0.99)

  testthat::local_mocked_bindings(.FitExpVariogram = Fit(1),
                                  .package = "StratoBayes")
  expect_message(est <- StratoBayes:::.EstimateCorLength(one, site),
                 "nugget for site 'A'")
  expect_identical(unname(est$corLength[1, 1]), 0)
})

test_that("white noise needs no message", {
  # A flat variogram gives corLength 0 and nugget 1: already independent.
  white <- withr::with_seed(5, list(z = 0:199, r = stats::rnorm(200)))
  expect_no_message(
    est <- StratoBayes:::.EstimateCorLength(
      .TwoSites(), list(list(.NuggetResiduals(0, 5), white))
    )
  )
  expect_identical(unname(est$corLength[2, 1]), 0)
  expect_identical(unname(est$nuggetFraction[2, 1]), 1)
})
