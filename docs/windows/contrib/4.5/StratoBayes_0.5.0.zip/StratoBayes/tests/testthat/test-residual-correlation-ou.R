# StratModel(residualCorrelation = "ou"): OU-correlated signal residuals in
# the C++ engine. The engine whitens with the bidiagonal factor L of the OU
# precision Q = R^-1 and feeds L'L-weighted cross-products to the shared
# beta-marginal core, adding 1/2 log|Q|. These tests pin that against a dense
# R oracle built from solve(R), so they compare two independent computations.

.OuL <- function(w) {
  n <- length(w$diag)
  L <- diag(w$diag, n)
  if (n > 1L) L[cbind(2:n, 1:(n - 1L))] <- w$sub[-1]
  L
}

.OuFixture <- function(corLength = 1.5, nChains = 2L, sigmaFixed = 0.5,
                       residualCorrelation = "ou", envir = parent.frame()) {
  data("stratData1", package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12), sigmaFixed = sigmaFixed,
    individualSplineIter = 40, residualCorrelation = residualCorrelation,
    corLength = corLength
  ))
  td <- withr::local_tempdir("ou", .local_envir = envir)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 50,
    nChains = nChains, seed = 1, nThreads = 1L, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "ou"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "ou_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc, result = result)
}

.OuEngine <- function(fx, model = fx$model) {
  StratoBayes:::.sb_create_engine(
    data = fx$data, model = model, mcmc = fx$mcmc,
    state = fx$mcmc$recentState, tiesCallback = NULL
  )
}

test_that("the OU whitening factors the dense OU precision", {
  # Irregular spacing, a tied height, a gap past the underflow cut-off, and a
  # second site with its own correlation length.
  z <- c(0, 0.3, 1.1, 1.1, 2.0, 50, 50.4, 0, 0.5, 2)
  site <- c(rep(1L, 7), rep(2L, 3))
  ell <- c(rep(1.2, 7), rep(0.7, 3))
  w <- StratoBayes:::.sb_ou_whitening(z, site, ell)
  R <- .OuDenseR(z, site, ell)
  L <- .OuL(w)
  expect_equal(crossprod(L), solve(R), tolerance = 1e-10)
  expect_equal(w$halfLogDetQ, -0.5 * as.numeric(determinant(R)$modulus),
               tolerance = 1e-12)

  # 1'Q1 has a closed form for the OU process: 1 + sum (1 - phi) / (1 + phi)
  # over each segment's links.
  zz <- c(0, 0.4, 0.5, 1.7, 3.0)
  phi <- exp(-diff(zz) / 0.8)
  w1 <- StratoBayes:::.sb_ou_whitening(zz, rep(1L, 5), rep(0.8, 5))
  expect_equal(sum((.OuL(w1) %*% rep(1, 5))^2),
               1 + sum((1 - phi) / (1 + phi)), tolerance = 1e-12)

  w0 <- StratoBayes:::.sb_ou_whitening(zz, rep(1L, 5), rep(0, 5))
  expect_identical(w0$diag, rep(1, 5))
  expect_identical(w0$sub, rep(0, 5))
  expect_identical(w0$halfLogDetQ, 0)

  expect_error(StratoBayes:::.sb_ou_whitening(c(1, 0), c(1L, 1L), c(1, 1)),
               "sorted")
})

test_that("the variogram fit recovers the correlation length and nugget", {
  set.seed(11)
  n <- 2000
  z <- cumsum(stats::runif(n, 0.2, 1.8))
  ell <- 5
  nugget <- 0.2
  u <- numeric(n)
  u[1] <- stats::rnorm(1)
  for (i in 2:n) {
    phi <- exp(-(z[i] - z[i - 1]) / ell)
    u[i] <- phi * u[i - 1] + sqrt(1 - phi^2) * stats::rnorm(1)
  }
  r <- sqrt(1 - nugget) * u + sqrt(nugget) * stats::rnorm(n)
  pairs <- StratoBayes:::.VariogramPairs(z, r)
  fit <- StratoBayes:::.FitExpVariogram(StratoBayes:::.BinVariogram(pairs),
                                        pairs$maxLag)
  expect_gt(fit$corLength, 3)
  expect_lt(fit$corLength, 8)
  expect_gt(fit$nuggetFraction, 0.1)
  expect_lt(fit$nuggetFraction, 0.3)

  white <- StratoBayes:::.VariogramPairs(z, stats::rnorm(n))
  fitWhite <- StratoBayes:::.FitExpVariogram(
    StratoBayes:::.BinVariogram(white), white$maxLag
  )
  expect_lt(fitWhite$corLength, 1)
})

test_that("StratModel() resolves corLength; 'none' models are unchanged", {
  data("stratData1", package = "StratoBayes", envir = environment())
  priors <- AutoPrior(stratData1, "height", sedModel = "site")
  Build <- function(..., residualCorrelation = "none") StratModel(
    stratData1, priors = priors, alignmentScale = "height",
    sedModel = "site", sigmaFixed = 0.5, individualSplineIter = 40, ...,
    residualCorrelation = residualCorrelation
  )
  expect_null(Build()$residualCorrelation)
  expect_warning(none <- Build(corLength = 2), "ignored")
  expect_null(none$residualCorrelation)

  given <- suppressWarnings(Build(residualCorrelation = "ou", corLength = 2))
  rc <- given$residualCorrelation
  expect_identical(rc$type, "ou")
  expect_identical(dim(rc$corLength), c(3L, 1L))
  expect_true(all(rc$corLength == 2))
  expect_true(all(rc$corLengthSource == "user"))
  expect_output(print(given),
                paste("Residual correlation: OU, corLength 2",
                      "(units of site height), sigma fixed"),
                fixed = TRUE)
  expect_false(any(grepl("Residual correlation",
                         utils::capture.output(print(none)))))

  partial <- matrix(c(1, NA, 3), 3, 1,
                    dimnames = list(rev(stratData1$sites), "value"))
  mixed <- suppressWarnings(Build(residualCorrelation = "ou",
                                  corLength = partial))$residualCorrelation
  expect_identical(unname(mixed$corLength[c(1, 3), 1]), c(3, 1))
  expect_identical(unname(mixed$corLengthSource[c(1, 3), 1]),
                   c("user", "user"))
  expect_true(is.finite(mixed$corLength[2, 1]) && mixed$corLength[2, 1] >= 0)
  expect_true(mixed$corLengthSource[2, 1] %in% c("site", "pooled", "none"))

  estimated <- suppressWarnings(Build(residualCorrelation = "ou"))
  expect_true(all(is.finite(estimated$residualCorrelation$corLength)))

  expect_error(Build(residualCorrelation = "ou", corLength = -1),
               "non-negative")
  expect_error(Build(residualCorrelation = "ou", corLength = c(1, 2)),
               "one row per site")
  expect_error(Build(residualCorrelation = "arma"), "\"none\" or \"ou\"")
})

test_that("sigma is sampled under 'ou' and fixed under 'none' by default", {
  data("stratData1", package = "StratoBayes", envir = environment())
  priors <- AutoPrior(stratData1, "height", sedModel = "site")
  Build <- function(...) suppressWarnings(StratModel(
    stratData1, priors = priors, alignmentScale = "height",
    sedModel = "site", individualSplineIter = 40, ...
  ))

  ou <- Build(corLength = 2)
  expect_identical(ou$residualCorrelation$type, "ou")
  expect_false(ou$sigmaFixed)
  expect_output(print(ou), "(units of site height), sigma sampled",
                fixed = TRUE)

  fixed <- Build(corLength = 2, sigmaFixed = TRUE)
  expect_true(is.numeric(fixed$sigmaFixed) && all(fixed$sigmaFixed > 0))
  given <- Build(corLength = 2, sigmaFixed = 0.5)
  expect_equal(unname(given$sigmaFixed), 0.5)

  none <- Build(residualCorrelation = "none")
  expect_null(none$residualCorrelation)
  expect_true(is.numeric(none$sigmaFixed) && all(none$sigmaFixed > 0))
  expect_false(Build(residualCorrelation = "none",
                     sigmaFixed = FALSE)$sigmaFixed)
})

test_that("signal offsets are refused under residualCorrelation = 'ou'", {
  data("stratData1", package = "StratoBayes", envir = environment())
  expect_error(
    StratModel(stratData1,
               priors = AutoPrior(stratData1, "height", sedModel = "site"),
               alignmentScale = "height", sedModel = "site", sigmaFixed = 0.5,
               signalOffsets = TRUE, residualCorrelation = "ou",
               corLength = 1),
    "signalOffsets"
  )
})

test_that("whitened statistics and likelihoods match a dense oracle", {
  fx <- .OuFixture(corLength = 1.5)
  expect_true(all(is.finite(fx$result$samples)))
  engine <- .OuEngine(fx)
  st <- StratoBayes:::.sb_extract_state(engine)[[1]]
  d <- fx$data
  rows <- d$signalAttr$sigs[[1]]$signalInd
  z <- d$signal[[d$zColumn]][rows]
  site <- match(d$signal[[d$siteColumn]][rows], d$sites)
  y <- d$signalAttr$signalValuesVec[[1]]
  n <- length(y)
  R <- .OuDenseR(z, site, rep(1.5, n))
  Q <- solve(R)

  B <- st$metro$B[[1]]
  sigma <- st$gibbs$sigma[1]
  lambda <- st$gibbs$lambda[1]
  BtQB <- crossprod(B, Q %*% B)
  BtQy <- drop(crossprod(B, Q %*% y))
  expect_equal(st$metro$H[[1]] * sigma^2, BtQB, tolerance = 1e-10)
  expect_equal(st$metro$tBy[[1]] * sigma^2, BtQy, tolerance = 1e-10)

  # The beta-marginal, with the engine's dropped constants (-n/2 log 2 pi,
  # 1/2 log pdet D) also left out here.
  p <- ncol(B)
  M <- BtQB / sigma^2 + lambda * fx$model$splineBase$D
  mu <- solve(M, BtQy / sigma^2)
  logDetR <- as.numeric(determinant(R)$modulus)
  marginal <- -n * log(sigma) - 0.5 * logDetR -
    0.5 * drop(crossprod(y, Q %*% y)) / sigma^2 +
    0.5 * (p - 2) * log(lambda) + 0.5 * sum(BtQy / sigma^2 * mu) -
    0.5 * as.numeric(determinant(M)$modulus)
  params <- st$metro$parameters
  ev <- StratoBayes:::.sb_eval_logpost(engine, 1L, params, debug = TRUE,
                                       marginal = TRUE)
  expect_equal(ev$logPostSep[2], marginal, tolerance = 1e-9)

  resid <- y - drop(B %*% st$gibbs$beta[[1]])
  joint <- -n * (log(sigma) + 0.5 * log(2 * pi)) - 0.5 * logDetR -
    0.5 * drop(crossprod(resid, Q %*% resid)) / sigma^2
  evJoint <- StratoBayes:::.sb_eval_logpost(engine, 1L, params, debug = TRUE,
                                            marginal = FALSE)
  expect_equal(evJoint$logPostSep[2], joint, tolerance = 1e-9)

  # The gradient's seed is (Q r)_i / sigma^2, times the slope of the fitted
  # curve at row i; fixed knots leave no endpoint terms.
  dbg <- StratoBayes:::.sb_compute_gradient(engine, 1L, debug = TRUE)
  dB <- splines::splineDesign(fx$model$splineBase$ext_knots,
                              dbg$signalFlat[rows], derivs = 1L)
  expect_equal(dbg$dLogLik_dAges[rows],
               drop(Q %*% resid) / sigma^2 * drop(dB %*% st$gibbs$beta[[1]]),
               tolerance = 1e-9)
})

# The alignment MH step scores the proposal at the pre-move sigma and lambda
# and compares it with the stored current log-posterior. Replaying both from
# the pre-move state on a fresh engine recovers those two operands, which the
# dense oracle then has to reproduce, 1/2 log|Q| included.
test_that("the alignment MH ratio under 'ou' is the whitened marginal's", {
  fx <- .OuFixture(corLength = 1.5, nChains = 1L)
  d <- fx$data
  rows <- d$signalAttr$sigs[[1]]$signalInd
  z <- d$signal[[d$zColumn]][rows]
  site <- match(d$signal[[d$siteColumn]][rows], d$sites)
  y <- d$signalAttr$signalValuesVec[[1]]
  n <- length(y)
  R <- .OuDenseR(z, site, rep(1.5, n))
  Q <- solve(R)
  logDetR <- as.numeric(determinant(R)$modulus)
  knots <- fx$model$splineBase$ext_knots
  D <- fx$model$splineBase$D
  Oracle <- function(ages, sigma, lambda) {
    B <- splines::splineDesign(knots, ages[rows], sparse = FALSE)
    BtQy <- drop(crossprod(B, Q %*% y)) / sigma^2
    M <- crossprod(B, Q %*% B) / sigma^2 + lambda * D
    -n * log(sigma) - 0.5 * logDetR -
      0.5 * drop(crossprod(y, Q %*% y)) / sigma^2 +
      0.5 * (ncol(B) - 2) * log(lambda) + 0.5 * sum(BtQy * solve(M, BtQy)) -
      0.5 * as.numeric(determinant(M)$modulus)
  }

  withr::local_seed(2770)
  engine <- .OuEngine(fx)
  checked <- 0L
  for (i in seq_len(60)) {
    before <- StratoBayes:::.sb_extract_state(engine)[[1]]
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    after <- StratoBayes:::.sb_extract_state(engine)[[1]]
    moved <- !identical(after$metro$parameters, before$metro$parameters)
    if (!isTRUE(after$metro$accept) || !moved) next

    replay <- StratoBayes:::.sb_create_engine(
      data = d, model = fx$model, mcmc = fx$mcmc, state = list(before),
      tiesCallback = NULL
    )
    Eval <- function(params) {
      StratoBayes:::.sb_eval_logpost(replay, 1L, params, debug = TRUE,
                                     marginal = TRUE)
    }
    old <- Eval(before$metro$parameters)
    new <- Eval(after$metro$parameters)
    expect_equal(old$logPost, before$metro$logPost, tolerance = 1e-12)
    expect_equal(new$logPost, after$metro$logPostNew, tolerance = 1e-12)

    sigma <- before$gibbs$sigma[1]
    lambda <- before$gibbs$lambda[1]
    oracleOld <- Oracle(old$signalFlat, sigma, lambda)
    oracleNew <- Oracle(new$signalFlat, sigma, lambda)
    expect_lt(abs(old$logPostSep[2] - oracleOld), 1e-8)
    expect_lt(abs(new$logPostSep[2] - oracleNew), 1e-8)
    rest <- sum(new$logPostSep[-2] - old$logPostSep[-2])
    expect_lt(abs(after$metro$logPostNew - before$metro$logPost -
                    (oracleNew - oracleOld + rest)), 1e-8)

    checked <- checked + 1L
    if (checked == 3L) break
  }
  expect_identical(checked, 3L)
})

# The OU precision couples neighbouring rows, so B'QB is wider than B'B and
# bandKd bounds only the latter: each state records its own band when its
# knots move. The stored log-posterior after a knot refresh is scored on that
# band, so a stale or truncated one shows up against the dense oracle. The
# oracle is the sigma-sampled marginal.
test_that("flexible knots under 'ou' score a moved state on its own band", {
  withr::local_seed(2834)
  data("stratData1", package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", individualSplineIter = 40,
    corLength = 1.5, integrateSigma = FALSE
  ))
  expect_true(model$flexibleKnots)
  td <- withr::local_tempdir("ou-flex")
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 50, nChains = 1L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE, modelDir = td,
    modelName = "ouflex"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "ouflex_mcmc_run_1.rds"))
  d <- result$data
  engine <- StratoBayes:::.sb_create_engine(
    data = d, model = model, mcmc = mcmc, state = mcmc$recentState,
    tiesCallback = NULL
  )
  before <- StratoBayes:::.sb_extract_state(engine)[[1]]
  for (i in seq_len(200)) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    after <- StratoBayes:::.sb_extract_state(engine)[[1]]
    if (!identical(after$spline$knots, before$spline$knots)) break
  }
  expect_false(identical(after$spline$knots, before$spline$knots))

  rows <- d$signalAttr$sigs[[1]]$signalInd
  z <- d$signal[[d$zColumn]][rows]
  site <- match(d$signal[[d$siteColumn]][rows], d$sites)
  y <- d$signalAttr$signalValuesVec[[1]]
  n <- length(y)
  R <- .OuDenseR(z, site, rep(1.5, n))
  Q <- solve(R)
  base <- model$splineBase
  ord <- base$splineOrder
  ageRange <- after$age$ageRange
  knots <- seq(ageRange[[1]], ageRange[[2]], length.out = base$nKnots)
  B <- splines::splineDesign(
    c(rep(knots[[1]], ord - 1), knots, rep(knots[[base$nKnots]], ord - 1)),
    after$age$signalFlat[rows], ord
  )
  expect_equal(after$metro$B[[1]], B, tolerance = 1e-12, ignore_attr = TRUE)
  BtQB <- crossprod(B, Q %*% B)
  coupled <- which(abs(BtQB) > 1e-12 * max(abs(BtQB)), arr.ind = TRUE)
  expect_gt(max(abs(coupled[, 1] - coupled[, 2])),
            StratoBayes:::.sb_engine_band_kd(engine))

  scale <- base$ageSpan / diff(ageRange)
  D <- scale^3 * base$D
  expect_equal(after$spline$D, D, tolerance = 1e-12, ignore_attr = TRUE)
  sigma <- after$gibbs$sigma[1]
  lambda <- after$gibbs$lambda[1]
  expect_equal(after$metro$H[[1]] * sigma^2, BtQB, tolerance = 1e-10)
  BtQy <- drop(crossprod(B, Q %*% y))
  p <- ncol(B)
  M <- BtQB / sigma^2 + lambda * D
  # 1.5 (p - 2) log(scale) is the alignment-dependent part of
  # 1/2 log pdet(lambda * D).
  signal <- -n * log(sigma) - 0.5 * as.numeric(determinant(R)$modulus) -
    0.5 * drop(crossprod(y, Q %*% y)) / sigma^2 +
    0.5 * (p - 2) * log(lambda) + 1.5 * (p - 2) * log(scale) +
    0.5 * sum(BtQy / sigma^2 * solve(M, BtQy / sigma^2)) -
    0.5 * as.numeric(determinant(M)$modulus)
  ev <- StratoBayes:::.sb_eval_logpost(engine, 1L, after$metro$parameters,
                                       debug = TRUE, marginal = TRUE)
  expect_equal(ev$logPostSep[2], signal, tolerance = 1e-9)
  expect_equal(after$metro$logPost, sum(ev$logPostSep[-2]) + signal,
               tolerance = 1e-9)
})

test_that("a tempered 'ou' run swaps states without leaving them stale", {
  data("stratData1", package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12), sigmaFixed = 0.5, individualSplineIter = 40,
    residualCorrelation = "ou", corLength = 1.5
  ))
  td <- withr::local_tempdir("ou-pt")
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 300,
    nChains = 4L, seed = 1, nThreads = 2L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "oupt", adaptTemperaturesMonitor = TRUE
  ))
  mcmc <- readRDS(file.path(td, "oupt_mcmc_run_1.rds"))
  expect_true(mcmc$temper$tempering)
  expect_true(all(is.finite(result$samples)))
  stored <- vapply(mcmc$recentState, function(s) s$metro$logPost, numeric(1))
  expect_length(stored, 4L)
  expect_true(all(is.finite(stored)))

  swaps <- mcmc$temper$temperingSwaps
  withCold <- which(mcmc$temper$swapIndices[, 1] == 1L)
  expect_gt(sum(swaps[, withCold], na.rm = TRUE), 0L)

  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  fresh <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
  recomputed <- vapply(seq_along(stored), function(chain) {
    StratoBayes:::.sb_eval_logpost(
      fresh, chain, mcmc$recentState[[chain]]$metro$parameters,
      marginal = TRUE
    )
  }, numeric(1))
  expect_equal(recomputed, stored, tolerance = 1e-10)
})

test_that("corLength = 0 reproduces the independent-residual model", {
  fx <- .OuFixture(corLength = 0, nChains = 1L)
  none <- .OuFixture(corLength = NULL, nChains = 1L,
                     residualCorrelation = "none")$model
  expect_null(none$residualCorrelation)
  expect_false("weights" %in% names(none$overlapPenalty))
  expect_identical(fx$model$overlapPenalty$weights[[1]],
                   rep(1, length(fx$data$signalAttr$signalValuesVec[[1]])))
  params <- fx$mcmc$recentState[[1]]$metro$parameters
  for (marginal in c(TRUE, FALSE)) {
    expect_equal(
      StratoBayes:::.sb_eval_logpost(.OuEngine(fx), 1L, params, debug = TRUE,
                                     marginal = marginal)$logPostSep,
      StratoBayes:::.sb_eval_logpost(.OuEngine(fx, none), 1L, params,
                                     debug = TRUE,
                                     marginal = marginal)$logPostSep,
      tolerance = 1e-10
    )
  }
  # With L = I the whitened gradient and joint log-posterior reduce exactly;
  # only the marginal's cross-products accumulate in another order.
  expect_identical(
    StratoBayes:::.sb_compute_gradient(.OuEngine(fx), 1L),
    StratoBayes:::.sb_compute_gradient(.OuEngine(fx, none), 1L)
  )
  expect_identical(
    StratoBayes:::.sb_eval_logpost(.OuEngine(fx), 1L, params, debug = TRUE,
                                   marginal = FALSE)$logPostSep,
    StratoBayes:::.sb_eval_logpost(.OuEngine(fx, none), 1L, params,
                                   debug = TRUE, marginal = FALSE)$logPostSep
  )
})

test_that("a sampled sigma runs under residualCorrelation = 'ou'", {
  fx <- .OuFixture(corLength = 1.5, sigmaFixed = FALSE)
  expect_true(all(is.finite(fx$result$samples)))
})

test_that("FitDiagnostics() drops the spline noise floor under 'ou'", {
  fx <- .OuFixture(corLength = 1.5, sigmaFixed = FALSE)
  fd <- suppressWarnings(FitDiagnostics(fx$result))
  expect_true(all(is.finite(fd$signals$sigma)))
  expect_true(all(is.na(fd$signals$sigmaReference)))
  expect_true(all(is.na(fd$signals$sigmaRatio)))
  printed <- paste(capture.output(print(fd)), collapse = "
")
  expect_match(printed, "sigma = ", fixed = TRUE)
  expect_no_match(printed, "noise floor", fixed = TRUE)
})

test_that("the engine and RunStratModel() refuse what OU does not support", {
  fx <- .OuFixture(corLength = 1.5, nChains = 1L)
  bad <- fx$model
  bad$residualCorrelation$corLength[1, 1] <- -1
  expect_error(.OuEngine(fx, bad), "finite and non-negative")
  bad$residualCorrelation$corLength <- 1
  expect_error(.OuEngine(fx, bad), "one row per site")

  data("stratData1", package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir("ou-refuse")
  Run <- function(...) suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = fx$model, nIter = 5,
    nChains = 1L, seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "refuse", ...
  ))
  expect_error(Run(engine = "R"), "C\\+\\+ engine only")
})

# A smooth shared curve plus a site-specific slow term and OU noise of known
# correlation length, on a 1 m grid: site A spans `spanA` m, site B half that.
.OuSimSites <- function(seed, ell, spanA = 300, noiseSd = 0.3) {
  f <- function(x) {
    2 * sin(2 * pi * x / 300) + 1.2 * sin(2 * pi * x / 130 + 1) +
      0.6 * sin(2 * pi * x / 70 + 2)
  }
  ouNoise <- function(n) {
    phi <- exp(-1 / ell)
    e <- numeric(n)
    e[1] <- stats::rnorm(1)
    for (i in 2:n) e[i] <- phi * e[i - 1] + sqrt(1 - phi^2) * stats::rnorm(1)
    noiseSd * e
  }
  withr::local_seed(seed)
  zA <- seq(0, spanA - 1)
  zB <- seq(0, spanA / 2 - 1)
  yA <- f(zA) + 0.4 * sin(2 * pi * zA / 330 + 2.1) + ouNoise(length(zA))
  yB <- f(zB + 100) + 0.4 * sin(2 * pi * zB / 250 + 0.7) + ouNoise(length(zB))
  list(
    data = StratData(signal = data.frame(
      site = rep(c("A", "B"), c(length(zA), length(zB))),
      height = c(zA, zB), value = c(yA, yB)
    )),
    x = list(A = zA, B = zB), y = list(A = yA, B = yB)
  )
}

test_that("a corLength at the top of its search range falls back to pooled", {
  withr::local_seed(5)
  OuNoise <- function(z, ell) {
    e <- numeric(length(z))
    e[1] <- stats::rnorm(1)
    for (i in 2:length(z)) {
      phi <- exp(-(z[i] - z[i - 1]) / ell)
      e[i] <- phi * e[i - 1] + sqrt(1 - phi^2) * stats::rnorm(1)
    }
    e
  }
  # A linear trend: the variogram grows to the end of its lags.
  trend <- list(z = 0:99, r = 0.05 * (0:99) + 0.1 * stats::rnorm(100))
  pairs <- StratoBayes:::.VariogramPairs(trend$z, trend$r)
  expect_true(StratoBayes:::.FitExpVariogram(
    StratoBayes:::.BinVariogram(pairs), pairs$maxLag
  )$atBound)

  alone <- matrix(NA_real_, 1, 1, dimnames = list("A", "value"))
  expect_message(
    est <- StratoBayes:::.EstimateCorLength(alone, list(list(trend))),
    "site 'A' signal 'value'.*Supply `corLength`"
  )
  expect_identical(est$source[1, 1], "pooled (at bound)")

  ell <- matrix(NA_real_, 3, 1, dimnames = list(c("A", "B", "C"), "value"))
  res <- list(list(trend, list(z = 0:199, r = OuNoise(0:199, 3)),
                   list(z = 0:199, r = OuNoise(0:199, 3))))
  expect_no_warning(est <- StratoBayes:::.EstimateCorLength(ell, res))
  expect_identical(unname(est$source[, 1]), c("pooled", "site", "site"))
  expect_lt(est$corLength[1, 1], pairs$maxLag)
})

# Sites A (60 rows), B (50) and C (3) of a sine plus OU noise; a mocked
# BayesianSpline() fails on B, and C is too short for a variogram of its own.
test_that("a skipped or failed site fit takes the pooled corLength", {
  withr::local_seed(7)
  Sim <- function(n) {
    z <- seq(0, n - 1)
    e <- numeric(n)
    e[1] <- stats::rnorm(1)
    for (i in 2:n) {
      e[i] <- exp(-1 / 3) * e[i - 1] + sqrt(1 - exp(-2 / 3)) * stats::rnorm(1)
    }
    data.frame(height = z, value = sin(2 * pi * z / 40) + 0.3 * e)
  }
  d <- StratData(signal = cbind(site = rep(c("A", "B", "C"), c(60, 50, 3)),
                                rbind(Sim(60), Sim(50), Sim(3))))
  priors <- AutoPrior(d, "height", sedModel = "site")
  nFits <- 0L
  realSpline <- StratoBayes::BayesianSpline
  testthat::local_mocked_bindings(
    BayesianSpline = function(x, ...) {
      nFits <<- nFits + 1L
      if (length(x) == 50L) stop("no fit")
      realSpline(x, ...)
    }
  )
  Build <- function(...) {
    nFits <<- 0L
    StratModel(d, priors = priors, alignmentScale = "height",
               sedModel = "site", nKnots = 8, sigmaFixed = 0.3,
               individualSplineIter = 40, residualCorrelation = "ou", ...)
  }
  rc <- Build()$residualCorrelation
  expect_identical(nFits, 3L)
  expect_identical(unname(rc$corLengthSource[, 1]),
                   c("site", "pooled", "pooled"))
  expect_true(all(rc$corLength > 0))

  # A's own fit still feeds the pool that B and C draw on.
  given <- matrix(c(2, NA, NA), 3, 1, dimnames = list(c("A", "B", "C"),
                                                      "value"))
  expect_no_warning(rc <- Build(corLength = given)$residualCorrelation)
  expect_identical(nFits, 3L)
  expect_identical(unname(rc$corLengthSource[, 1]),
                   c("user", "pooled", "pooled"))
  expect_true(all(rc$corLength > 0))
  expect_identical(rc$corLength[2, 1], rc$corLength[3, 1])
})

test_that("the coarse detrend halves the shared curve's knot density", {
  expect_identical(StratoBayes:::.OuCoarseKnots(22, c(300, 150, 75)),
                   c(11, 6, 3))
  expect_identical(StratoBayes:::.OuCoarseKnots(22, c(300, 4)), c(11, 2))
  expect_identical(StratoBayes:::.OuCoarseKnots(2, 100), 2)
  expect_identical(StratoBayes:::.OuCoarseKnots(10, c(0, 0)), c(5, 5))
})

test_that("only the 'ou' estimate fits the extra coarse splines", {
  fx <- .OuSimSites(1, ell = 5, spanA = 80)
  priors <- AutoPrior(fx$data, "height", sedModel = "site")
  nFits <- 0L
  realSpline <- StratoBayes::BayesianSpline
  testthat::local_mocked_bindings(
    BayesianSpline = function(...) {
      nFits <<- nFits + 1L
      realSpline(...)
    }
  )
  Build <- function(..., residualCorrelation = "none") {
    nFits <<- 0L
    suppressWarnings(StratModel(
      fx$data, priors = priors, alignmentScale = "height", sedModel = "site",
      nKnots = 8, individualSplineIter = 40, ...,
      residualCorrelation = residualCorrelation
    ))
    nFits
  }
  expect_identical(Build(sigmaFixed = 0.3), 0L)
  expect_identical(Build(sigmaFixed = TRUE), 2L)
  expect_identical(Build(sigmaFixed = 0.3, residualCorrelation = "ou",
                         corLength = 3), 0L)
  expect_identical(Build(sigmaFixed = 0.3, residualCorrelation = "ou"), 2L)
  expect_identical(Build(sigmaFixed = TRUE, residualCorrelation = "ou"), 4L)
})

# A coarse fit that errors keeps the site unfitted and says nothing, so a
# stale call inside .OuSiteResiduals() (one the merged package no longer
# accepts) would leave every site without residuals and show only downstream
# as corLengthSource "none". Pin the seeded path directly.
test_that("the coarse per-site fits yield residuals under a seeded bLambda", {
  fx <- .OuSimSites(1, ell = 5)
  data <- StratoBayes:::.EnsurePreExtracted(fx$data)
  nKnots <- 22
  seen <- new.env()
  realSpline <- StratoBayes::BayesianSpline
  testthat::local_mocked_bindings(
    BayesianSpline = function(x, y, nKnots, nIter, aLambda, bLambda, aSigma,
                              bSigma) {
      seen[["bLambda"]] <- c(seen[["bLambda"]], bLambda)
      realSpline(x, y, nKnots = nKnots, nIter = nIter, aLambda = aLambda,
                 bLambda = bLambda, aSigma = aSigma, bSigma = bSigma)
    }
  )
  res <- StratoBayes:::.OuSiteResiduals(
    data, nKnots = nKnots, nIter = 40, aLambda = 1, bLambda = 1000,
    aSigma = 0.01, bSigma = 0.01, seedBLambda = TRUE
  )
  expect_length(res, 1L)
  for (s in 1:2) {
    expect_length(res[[1]][[s]][["r"]], length(fx$x[[s]]))
    expect_true(all(is.finite(res[[1]][[s]][["r"]])))
  }
  # Each fit took its own site's scale, as the sigma-seeding splines do.
  kSite <- StratoBayes:::.OuCoarseKnots(
    nKnots, vapply(fx$x, function(h) max(h) - min(h), numeric(1))
  )
  expect_identical(seen[["bLambda"]], vapply(1:2, function(s) {
    StratoBayes:::.SeedingBLambda(fx$x[[s]], fx$y[[s]], kSite[s], 1000)
  }, numeric(1)))
  expect_true(all(seen[["bLambda"]] != 1000))
})

test_that("a half-density detrend recovers the correlation length", {
  ell <- 5
  nKnots <- 22
  coarse <- fine <- numeric(0)
  for (seed in 1:3) {
    fx <- .OuSimSites(seed, ell)
    model <- suppressWarnings(StratModel(
      fx$data, priors = AutoPrior(fx$data, "height", sedModel = "site"),
      alignmentScale = "height", sedModel = "site", nKnots = nKnots,
      sigmaFixed = 0.3, residualCorrelation = "ou"
    ))
    coarse <- c(coarse, model$residualCorrelation$corLength[, 1])

    # The fits that set `sigmaFixed`: nKnots over each site's own range.
    fineRes <- lapply(c("A", "B"), function(s) {
      fit <- BayesianSpline(fx$x[[s]], fx$y[[s]], nKnots = nKnots, nIter = 500)
      StratoBayes:::.SplineResiduals(
        list(fit = fit, x = fx$x[[s]], y = fx$y[[s]]), seq(126, 500)
      )
    })
    fine <- c(fine, suppressWarnings(StratoBayes:::.EstimateCorLength(
      matrix(NA_real_, 2, 1, dimnames = list(c("A", "B"), "value")),
      list(fineRes)
    ))$corLength[, 1])
  }
  expect_true(all(coarse > fine))
  expect_gt(min(coarse), ell / 2)
  expect_lt(max(coarse), ell * 2)
  expect_lt(median(fine), ell / 2)
})

test_that("the OU penalty weight is min(1, dz / 2 ell) on known grids", {
  W <- StratoBayes:::.OuSpacingWeights
  expect_equal(W(0:9, 5), rep(0.1, 10))
  expect_equal(W(seq(0, 40, 10), 5), rep(1, 5))
  expect_equal(W(0:9, 0), rep(1, 10))
  expect_equal(W(3, 5), 1)
  # An end row has one spacing; interior rows average the two either side.
  expect_equal(W(c(0, 1, 4, 10), 2), c(0.25, 0.5, 1, 1))
  # A tie starts an independent segment in the engine: the second row keeps
  # weight 1 and the zero spacing leaves both rows' means.
  expect_equal(W(c(0, 1, 1, 2, 3), 5), c(0.1, 0.1, 1, 0.1, 0.1))
  expect_equal(W(c(2, 2, 2), 5), rep(1, 3))
})

test_that("StratModel() weights the overlap penalty only under 'ou'", {
  fx <- .OuSimSites(1, ell = 5, spanA = 80)
  priors <- AutoPrior(fx$data, "height", sedModel = "site")
  Build <- function(..., residualCorrelation = "none") {
    suppressWarnings(StratModel(
      fx$data, priors = priors, alignmentScale = "height", sedModel = "site",
      nKnots = 8, sigmaFixed = 0.3, ...,
      residualCorrelation = residualCorrelation
    ))
  }
  none <- Build()
  expect_true(none$overlapPenalty$overlapPenalty)
  expect_false("weights" %in% names(none$overlapPenalty))
  expect_false("weights" %in% names(
    Build(residualCorrelation = "ou", corLength = 5,
          overlapPenalty = FALSE)$overlapPenalty
  ))

  # Sites A (80 rows) and B (40 rows) on a 1 m grid, then B left independent.
  ou <- Build(residualCorrelation = "ou", corLength = 5)
  expect_identical(lengths(ou$overlapPenalty$weights), 120L)
  expect_equal(ou$overlapPenalty$weights[[1]], rep(0.1, 120))
  ellMat <- matrix(c(5, 0), 2, 1, dimnames = list(c("A", "B"), "value"))
  mixed <- Build(residualCorrelation = "ou", corLength = ellMat)
  expect_equal(mixed$overlapPenalty$weights[[1]], rep(c(0.1, 1), c(80, 40)))
  expect_equal(ou$overlapPenalty$adjustments, none$overlapPenalty$adjustments)
})

test_that("OU penalty weights follow each site's heights in row order", {
  set.seed(3)
  zA <- cumsum(stats::runif(25, 0.2, 3))
  zB <- cumsum(stats::runif(15, 0.5, 6))
  d <- StratData(signal = data.frame(
    site = rep(c("A", "B"), c(25, 15)), height = c(zA, zB),
    value = stats::rnorm(40)
  ))
  ell <- matrix(c(2, 0.5), 2, 1, dimnames = list(c("A", "B"), "value"))
  w <- StratoBayes:::.OuOverlapWeights(d, ell)
  expect_length(w, 1L)
  expect_equal(w[[1]], c(StratoBayes:::.OuSpacingWeights(zA, 2),
                         StratoBayes:::.OuSpacingWeights(zB, 0.5)))
  expect_true(any(w[[1]] < 1) && any(w[[1]] == 1))
})

test_that("OU weights multiply the sedSmooth taper", {
  data("stratData1", package = "StratoBayes", envir = environment())
  ell <- matrix(2, 3, 1, dimnames = list(stratData1$sites, "value"))
  m <- suppressWarnings(StratModel(
    stratData1, alignmentScale = "height", sedModel = "site, partition",
    priors = AutoPrior(stratData1, "height"), sedSmooth = TRUE,
    sigmaFixed = 0.5, residualCorrelation = "ou", corLength = 2
  ))
  taper <- StratoBayes:::.ComputeOverlapTaperWeights(
    stratData1, StratoBayes:::.SetupSedSmooth(stratData1, "height", 6L), 0.15
  )
  ou <- StratoBayes:::.OuOverlapWeights(stratData1, ell)
  expect_gt(sum(taper[[1]] < 1), 0)
  expect_gt(sum(ou[[1]] < 1), 0)
  expect_equal(m$overlapPenalty$weights[[1]], taper[[1]] * ou[[1]])
  expect_equal(StratoBayes:::.OuOverlapWeights(stratData1, ell, taper)[[1]],
               taper[[1]] * ou[[1]])
})

test_that("a penalty-on 'ou' run applies the weights in the engine", {
  fx <- .OuFixture(corLength = 1.5)
  w <- fx$model$overlapPenalty$weights[[1]]
  expect_length(w, length(fx$data$signalAttr$signalValuesVec[[1]]))
  expect_true(all(w > 0 & w <= 1) && any(w < 1))
  expect_true(all(is.finite(fx$result$samples)))
  expect_true(all(is.finite(fx$mcmc$recentState[[1]]$logPost)))

  engine <- .OuEngine(fx)
  st <- StratoBayes:::.sb_extract_state(engine)[[1]]
  ov <- st$age$signalSectionOverlap[[1]]
  adj <- fx$model$overlapPenalty$adjustments[[1]]
  keep <- ov > 0 & ov <= length(adj)
  weighted <- sum(w[keep] * adj[ov[keep]])
  unweighted <- sum(adj[ov[keep]])
  expect_lt(weighted, 0)
  expect_gt(weighted, unweighted)
  ev <- StratoBayes:::.sb_eval_logpost(engine, 1L, st$metro$parameters,
                                       debug = TRUE, marginal = TRUE)
  expect_equal(ev$logPostSep[4], weighted, tolerance = 1e-10)
})

# An accepted sedSmooth move swaps the new B'QB into the chain state member by
# member. Its band under OU is recorded per state and grows where neighbouring
# rows straddle more knot spans, so it must move with B'QB: a stale, narrower
# band packs a truncated precision into every later marginal and beta draw.
test_that("an accepted sedSmooth move carries the OU band with B'QB", {
  data("stratData1", package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height"),
    alignmentScale = "height", sedModel = "site, partition", sedSmooth = TRUE,
    flexibleKnots = FALSE, knotRange = c(-5, 12), nKnots = 60,
    sigmaFixed = 0.5, individualSplineIter = 40,
    residualCorrelation = "ou", corLength = 1.5
  ))
  td <- withr::local_tempdir("ou-sed")
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 10, nChains = 1L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "oused"
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "oused_mcmc_run_1.rds"))
  engine <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
  SedBeta <- function(st) unlist(st$gibbs$sedBeta)
  previous <- SedBeta(StratoBayes:::.sb_extract_state(engine)[[1]])
  nAccepted <- 0L
  gap <- vapply(seq_len(80), function(i) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    st <- StratoBayes:::.sb_extract_state(engine)[[1]]
    if (!identical(SedBeta(st), previous)) nAccepted <<- nAccepted + 1L
    previous <<- SedBeta(st)
    fresh <- StratoBayes:::.sb_eval_logpost(engine, 1L, st$metro$parameters,
                                            debug = TRUE, marginal = TRUE)
    st$metro$logPostSep[2] - fresh$logPostSep[2]
  }, numeric(1))
  # The gap can only open after an accepted sedSmooth move, so some must be.
  expect_gt(nAccepted, 0L)
  expect_equal(max(abs(gap)), 0, tolerance = 1e-8)
})

# A stationary OU draw, e[1] ~ N(0, 1), with the given correlation length.
.OuNoise <- function(z, ell) {
  e <- numeric(length(z))
  e[1] <- stats::rnorm(1)
  for (i in seq_along(z)[-1]) {
    phi <- exp(-(z[i] - z[i - 1]) / ell)
    e[i] <- phi * e[i - 1] + sqrt(1 - phi^2) * stats::rnorm(1)
  }
  e
}

# The residuals of an OU fit to OU-generated data are correlated by
# construction. Whitened with the engine's factor they are independent, so
# the diagnostics must read a correct alignment as such; on the raw residuals
# the modelled correlation alone floors pppDrift at every site.
test_that("FitDiagnostics() whitens the residuals under 'ou'", {
  withr::local_seed(4)
  Curve <- function(x) {
    2 * sin(2 * pi * x / 300) + 1.2 * sin(2 * pi * x / 130 + 1) +
      0.6 * sin(2 * pi * x / 70 + 2)
  }
  zA <- 0:299
  zB <- 0:149
  d <- StratData(signal = data.frame(
    site = rep(c("A", "B"), c(300, 150)), height = c(zA, zB),
    value = c(Curve(zA) + 0.3 * .OuNoise(zA, 5),
              Curve(zB + 100) + 0.3 * .OuNoise(zB, 5))
  ))
  model <- suppressWarnings(suppressMessages(StratModel(
    d, priors = AutoPrior(d, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", nKnots = 25,
    residualCorrelation = "ou", corLength = 5, sigmaFixed = FALSE
  )))
  td <- withr::local_tempdir("ou-fd")
  result <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = model, nIter = 1500, nChains = 1L,
    seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "oufd"
  ))
  whitened <- suppressWarnings(FitDiagnostics(result, burnIn = 0.5))
  # pppDrift is about uniform under a correct model; 1e-3 keeps the
  # assertion clear of the raw case's 1e-4 floor without a 1 in 50 miss.
  expect_true(all(whitened$sites$pppDrift > 1e-3))
  expect_true(all(abs(whitened$sites$scatter - 1) < 0.25))

  testthat::with_mocked_bindings(
    raw <- suppressWarnings(FitDiagnostics(result, burnIn = 0.5)),
    .FitOuWhitening = function(...) NULL, .package = "StratoBayes"
  )
  expect_true(all(raw$sites$pppDrift < 0.01))
  expect_true(all(whitened$sites$lpd > raw$sites$lpd))
})

# R scores the initial state with independent residuals; the engine re-scores
# it under OU when it is created, and the saved iteration-1 row must carry
# that value rather than R's.
test_that("the iteration-1 row is scored with the OU likelihood", {
  data("stratData1", package = "StratoBayes", envir = environment())
  Fit <- function(corLength) {
    model <- suppressWarnings(StratModel(
      stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
      alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
      knotRange = c(-5, 12), sigmaFixed = 0.5, individualSplineIter = 40,
      residualCorrelation = "ou", corLength = corLength
    ))
    td <- withr::local_tempdir("ou-row1", .local_envir = parent.frame())
    # No iteration runs, so `recentState` is the initial state itself.
    result <- suppressWarnings(RunStratModel(
      stratObject = stratData1, stratModel = model, nIter = 1,
      nChains = 1L, seed = 1, nThreads = 1L, quiet = TRUE,
      visualise = FALSE, modelDir = td, modelName = "row1"
    ))
    list(result = result,
         mcmc = readRDS(file.path(td, "row1_mcmc_run_1.rds")))
  }
  one <- Fit(1.5)
  expect_identical(dim(one$result$samples)[[1]], 1L)
  model <- one$result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  engine <- StratoBayes:::.sb_create_engine(
    data = one$result$data, model = model, mcmc = one$mcmc,
    state = one$mcmc$recentState, tiesCallback = NULL
  )
  scored <- StratoBayes:::.sb_extract_metro(engine)[[1]]$metro
  rSide <- one$mcmc$recentState[[1]]$metro
  row1 <- one$result$samples[1, , 1, 1]
  expect_equal(row1[["likelihood_spline"]], scored$logPostSep[[2]])
  expect_equal(row1[["posterior"]], scored$logPost)
  expect_gt(abs(row1[["likelihood_spline"]] - rSide$logPostSep[[2]]), 10)

  # corLength = 0 is the independent likelihood, where R and engine agree.
  none <- Fit(0)
  expect_equal(none$result$samples[1, "likelihood_spline", 1, 1],
               none$mcmc$recentState[[1]]$metro$logPostSep[[2]])
})

test_that("a site with a non-finite residual takes the pooled corLength", {
  withr::local_seed(5)
  ell <- matrix(NA_real_, 2, 1, dimnames = list(c("A", "B"), "value"))
  smooth <- list(z = 0:199, r = .OuNoise(0:199, 3))
  broken <- list(z = 0:199, r = replace(.OuNoise(0:199, 3), 10, NA_real_))
  expect_no_warning(
    est <- StratoBayes:::.EstimateCorLength(ell, list(list(smooth, broken)))
  )
  expect_identical(unname(est$source[, 1]), c("site", "pooled"))
  expect_equal(est$corLength[2, 1], est$corLength[1, 1])

  alone <- matrix(NA_real_, 1, 1, dimnames = list("A", "value"))
  expect_message(
    est <- StratoBayes:::.EstimateCorLength(alone, list(list(broken))),
    "treated as independent"
  )
  expect_identical(unname(est$corLength[1, 1]), 0)
})

test_that("heights within a thousandth of corLength count as tied", {
  d <- StratData(signal = data.frame(
    site = rep(c("A", "B"), c(6, 3)),
    height = c(0, 1, 2, 2.002, 3, 3, 0, 1, 2), value = seq_len(9)
  ))
  ell <- matrix(c(5, 5), 2, 1, dimnames = list(c("A", "B"), "value"))
  expect_equal(unname(StratoBayes:::.TiedHeightFraction(d, ell)[, 1]),
               c(2 / 6, 0))
  expect_equal(unname(StratoBayes:::.TiedHeightFraction(d, ell * 0)[, 1]),
               c(1 / 6, 0))
  expect_equal(unname(StratoBayes:::.TiedHeightFraction(d, ell / 5)[, 1]),
               c(1 / 6, 0))
})
