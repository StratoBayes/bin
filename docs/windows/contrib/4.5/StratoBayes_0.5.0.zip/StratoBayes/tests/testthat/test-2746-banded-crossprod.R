test_that(".sb_update_htby's banded B'B matches the dense product (#2746)", {
  set.seed(2746)
  nObs <- 40L
  nBasis <- 12L
  knots <- c(rep(0, 3), seq(0, 1, length.out = nBasis - 2L), rep(1, 3))
  bSpline <- splines::splineDesign(knots, sort(runif(nObs)), sparse = FALSE)

  irregular <- bSpline
  irregular[3, ] <- 0
  irregular[5, c(1, nBasis)] <- c(0.4, -1.5)
  irregular[7, 6] <- 2

  y <- rnorm(nObs)
  sigma <- 0.8
  for (b in list(bSpline, irregular)) {
    out <- .sb_update_htby(list(b), list(y), sigma)
    expect_equal(out[["H"]][[1]], crossprod(b) / sigma^2, tolerance = 1e-14)
    expect_equal(
      out[["tBy"]][[1]], drop(crossprod(b, y)) / sigma^2,
      tolerance = 1e-14
    )
  }
})

test_that("a non-finite basis entry propagates across its whole row (#2746)", {
  nBasis <- 5L
  b <- diag(nBasis)
  b[2, 3] <- Inf
  dense <- matrix(0, nBasis, nBasis)
  for (i in seq_len(nBasis)) dense <- dense + outer(b[i, ], b[i, ])

  h <- .sb_update_htby(list(b), list(numeric(nBasis)), 1)[["H"]][[1]]
  expect_equal(h, dense)
  expect_true(all(is.nan(h[3, c(1, 4, 5)])))
})
