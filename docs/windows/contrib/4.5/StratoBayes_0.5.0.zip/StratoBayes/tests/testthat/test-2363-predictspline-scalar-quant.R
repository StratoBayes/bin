test_that("PredictSpline() with one quantile returns one column (#2363)", {
  set.seed(2363)
  x <- seq(0, 8, length.out = 30)
  y <- sin(x) + rnorm(30, 0, 0.2)
  fit <- BayesianSpline(x, y, nKnots = 6, nIter = 30, nThin = 1)
  at <- c(1, 2, 3, 4.5)

  one <- PredictSpline(fit, at = at, quant = 0.5, burnIn = 1)
  expect_identical(nrow(one), length(at))
  expect_identical(colnames(one), c("x", "mu", "sd", "0.5"))

  two <- PredictSpline(fit, at = at, quant = c(0.5, 0.6), burnIn = 1)
  expect_identical(colnames(two), c("x", "mu", "sd", "0.5", "0.6"))
  expect_equal(one[["0.5"]], two[["0.5"]])
  expect_false(isTRUE(all.equal(two[["0.5"]], two[["0.6"]])))

  # distinct per-x values, not one recycled row
  expect_gt(length(unique(one[["0.5"]])), 1L)
})
