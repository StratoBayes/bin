# Rescaling a signal by k must scale the default sigma prior by k^2, or the
# posterior depends on the units the signal was recorded in. signalData1 has
# n * var(y) = 100 at k = 1 and 0.01 at k = 0.01, so the sweep crosses the
# old min(0.01, 0.01 * n * var(y)) branch point.
ScaledModel <- function(k) {
  signal <- signalData1
  signal[["value"]] <- signal[["value"]] * k
  StratModel(
    StratData(signal),
    nKnots = 5,
    alignmentScale = "height",
    sedModel = "site",
    residualCorrelation = "none"
  )
}

test_that("default bSigma scales with the square of the signal units (#2540)", {
  set.seed(2540)
  native <- ScaledModel(1)
  small <- ScaledModel(0.01)
  expect_equal(
    small[[c("priors", "gibbs", "bSigma")]] / 0.01^2,
    native[[c("priors", "gibbs", "bSigma")]],
    tolerance = 1e-12
  )
  expect_equal(
    unname(small[["sigmaFixed"]] / 0.01),
    unname(native[["sigmaFixed"]]),
    tolerance = 0.05
  )
})
