# #2511: the Hastings term the C++ engine's update_state_internal builds for
# the Prior and the asymmetric (NeighbourScaled) moves, pinned through the
# engine itself rather than through a copy of the formula. Each oracle is a
# target whose correct kernel is known exactly, so neither depends on
# bit-reproducible draws across platforms.

.ForceProposal2511 <- function(mcmc, name) {
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, name] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
  pw[, ] <- 1
  mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw
  mcmc
}

.RunEngine2511 <- function(data, model, mcmc, nIter) {
  state <- list(.GenerateInitialState(data, model, mcmc, 1))
  e <- .sb_create_engine(data, model, mcmc, state)
  par <- matrix(NA_real_, nIter, length(state[[1]][[c("metro", "parameters")]]))
  accept <- logical(nIter)
  logPost <- numeric(nIter)
  for (i in seq_len(nIter)) {
    .sb_run_block(e, 1L)
    st <- .sb_extract_state(e)[[1]]
    par[i, ] <- st[[c("metro", "parameters")]]
    accept[i] <- isTRUE(st[[c("metro", "accept")]])
    logPost[i] <- st[[c("metro", "logPost")]]
  }
  list(engine = e, initial = state[[1]], par = par, accept = accept,
       logPost = logPost)
}

test_that("a Prior move on a likelihood-blind gap always accepts (#2511)", {
  # A basal hiatus allocates a gap parameter that nothing above it depends on
  # (#1959), so with every other parameter fixed the likelihood is flat and
  # the Prior move's g == prior independence ratio is exactly 1 at T = 1.
  # Dropping the Hastings term leaves log alpha = delta log prior; flipping
  # it doubles that. Either rejects a large share of draws.
  parts <- data.frame(
    site = c("site_1", "site_2", "site_2", "site_2", "site_3"),
    height = c(10, 0, 0, 2.19, 4.46),
    partition = c("a", "a", NA, "a", "a")
  )
  data <- StratData(stratData1[["signal"]], parts = parts)
  priors <- list(
    alpha_site_2 = Fixed(2), alpha_site_3 = Fixed(1),
    gammaLog_site_2 = Fixed(0.3), gammaLog_site_3 = Fixed(0.4),
    gap_site_2_1 = ExponentialPrior(rate = 0.4)
  )
  set.seed(2511)
  model <- StratModel(data, priors, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "bottom")
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  nIter <- 300L
  mcmc <- .ForceProposal2511(StratMCMC(model, nIter = nIter, nChains = 1,
                                       nThreads = 1L), "Prior")
  run <- .RunEngine2511(data, model, mcmc, nIter)

  gapIdx <- which(names(run[["initial"]][[c("metro", "parameters")]]) ==
                    "gap_site_2_1")
  expect_length(gapIdx, 1L)

  # The construction's premise: the gap moves every likelihood component by
  # nothing at all, so only the prior term differs.
  p <- run[["initial"]][[c("metro", "parameters")]]
  Components <- function(gap) {
    p[gapIdx] <- gap
    .sb_eval_logpost(run[["engine"]], 1L, p, debug = TRUE,
                     marginal = TRUE)[["logPostSep"]]
  }
  atZero <- Components(0.01)
  for (gap in c(0.5, 4, 15)) {
    other <- Components(gap)
    expect_identical(other[-1], atZero[-1])
    expect_false(other[1] == atZero[1])
  }

  # Non-vacuous: the gap actually explored its prior.
  expect_gt(length(unique(run[["par"]][, gapIdx])), nIter / 2)
  expect_true(all(run[["logPost"]] > -1e29))

  expect_equal(sum(run[["accept"]]), nIter)
})

test_that("a hot NeighbourScaled chain keeps a flat target flat (#2511)", {
  # At T = 1e6 the tempered target is uniform on the alpha prior box to within
  # ~1e-3 in log density. NeighbourScaled's step size is proportional to the
  # gap between the two alphas, so only the correct Hastings term keeps that
  # gap at its uniform spread (E|a2 - a3| = 8/3). Zeroed or negated, the
  # kernel favours small steps and the alphas collapse together. One chain
  # can linger near the diagonal for a thousand iterations, so the statistic
  # pools four. Observed pooled mean gap: 1.95-3.22 over 150 seeds when
  # correct; at most 0.33 under either mutant over 25.
  priors <- list(
    alpha_site_2 = UniformPrior(-4, 4), alpha_site_3 = UniformPrior(-4, 4),
    gammaLog_site_2 = Fixed(0), gammaLog_site_3 = Fixed(0)
  )
  set.seed(2511)
  model <- StratModel(stratData1, priors, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "bottom")
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  nIter <- 3000L
  mcmc <- .ForceProposal2511(StratMCMC(model, nIter = nIter, nChains = 1,
                                       nThreads = 1L), "NeighbourScaled")
  mcmc[[c("temper", "temperatures")]] <- 1e6
  runs <- replicate(4L, .RunEngine2511(stratData1, model, mcmc, nIter),
                    simplify = FALSE)

  logPost <- unlist(lapply(runs, `[[`, "logPost"))
  expect_true(all(logPost > -1e29))
  expect_gt(max(logPost) - min(logPost), 0)
  expect_gt(mean(unlist(lapply(runs, `[[`, "accept"))), 0.5)

  keep <- -seq_len(300L)
  gap <- unlist(lapply(runs, function(run) {
    abs(run[["par"]][keep, 1] - run[["par"]][keep, 2])
  }))
  expect_gt(mean(gap), 1)
})
