# StratModel(integrateSigma = TRUE) under OU (GH #2810): beta's prior
# precision scales with (s / sigma)^2, so sigma integrates out of the energy
# that alignment moves and tempering swaps see. The engine runs its existing
# machinery at sigma = s (sigmaRef) and draws sigma from its collapsed
# conditional IG(aSigma + (n - 2) / 2, bSigma + S' / 2) on every rung.

.IsModel <- function(integrateSigma = TRUE, ...) {
  data("stratData1", package = "StratoBayes", envir = environment())
  args <- list(stratData1, alignmentScale = "height", sedModel = "site",
               residualCorrelation = "ou", sigmaFixed = FALSE,
               corLength = 0.03, individualSplineIter = 40)
  extra <- list(...)
  args[names(extra)] <- extra
  if (!is.null(integrateSigma)) args$integrateSigma <- integrateSigma
  suppressWarnings(suppressMessages(do.call(StratModel, args)))
}

.IsRun <- function(model, envir = parent.frame(), nIter = 60L,
                   temperatures = c(1, 2, 4, 8), ...) {
  data("stratData1", package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir("is", .local_envir = envir)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = nIter,
    nChains = length(temperatures), temperatures = temperatures, seed = 1,
    nThreads = 1L, quiet = TRUE, visualise = FALSE, modelDir = td,
    modelName = "is", ...
  ))
  model <- result$model
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "is_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc, result = result,
       dir = td)
}

.IsEngine <- function(fx, model = fx$model, state = fx$mcmc$recentState) {
  StratoBayes:::.sb_create_engine(
    data = fx$data, model = model, mcmc = fx$mcmc, state = state,
    tiesCallback = NULL
  )
}

.Signal <- function(engine, chain, theta, beta, sigma, lambda) {
  StratoBayes:::.sb_sync_gibbs(engine, chain, beta, sigma, lambda)
  StratoBayes:::.sb_eval_logpost(engine, chain, theta, debug = TRUE,
                                 marginal = TRUE)$logPostSep
}

test_that("integrateSigma needs OU residuals and a sampled sigma", {
  data("stratData1", package = "StratoBayes", envir = environment())
  Build <- function(...) suppressWarnings(suppressMessages(StratModel(
    stratData1, alignmentScale = "height", sedModel = "site",
    individualSplineIter = 40, ...
  )))
  expect_error(Build(residualCorrelation = "none", integrateSigma = TRUE),
               "residualCorrelation")
  expect_error(Build(residualCorrelation = "ou", corLength = 0.03,
                     sigmaFixed = TRUE, integrateSigma = TRUE),
               "sigmaFixed = FALSE")
  expect_error(Build(residualCorrelation = "ou", corLength = 0.03,
                     sigmaFixed = 0.2, integrateSigma = TRUE),
               "sigmaFixed = FALSE")
  expect_error(Build(residualCorrelation = "ou", corLength = 0.03,
                     sigmaFixed = FALSE, integrateSigma = NA))
  model <- .IsModel()
  expect_true(model$residualCorrelation$integrateSigma)
  expect_length(model$residualCorrelation$sigmaRef, 1L)
  expect_gt(model$residualCorrelation$sigmaRef, 0)
  expect_output(print(model), "sigma sampled and integrated out")
})

# Where the default leaves integrateSigma off, the model is the one built
# before the argument existed; that such runs are unchanged is checked
# offline (dev/integrate-sigma/bitident.R).
test_that("sigma is integrated out by default where it is sampled under OU", {
  set.seed(3)
  omitted <- .IsModel(integrateSigma = NULL)
  set.seed(3)
  expect_identical(.IsModel(integrateSigma = TRUE), omitted)
  sampled <- .IsModel(integrateSigma = FALSE)
  expect_null(sampled$residualCorrelation$integrateSigma)

  data("stratData1", package = "StratoBayes", envir = environment())
  Build <- function(...) suppressWarnings(suppressMessages(StratModel(
    stratData1, alignmentScale = "height", sedModel = "site",
    individualSplineIter = 40, ...
  )))
  set.seed(4)
  none <- Build(residualCorrelation = "none")
  set.seed(4)
  expect_identical(Build(residualCorrelation = "none", integrateSigma = FALSE),
                   none)
  # The package default (OU, sigma sampled) integrates sigma out.
  expect_true(Build(corLength = 0.03)$residualCorrelation$integrateSigma)
  set.seed(5)
  fixed <- Build(residualCorrelation = "ou", corLength = 0.03,
                 sigmaFixed = TRUE)
  set.seed(5)
  expect_identical(Build(residualCorrelation = "ou", corLength = 0.03,
                         sigmaFixed = TRUE, integrateSigma = FALSE), fixed)
  expect_null(fixed$residualCorrelation$integrateSigma)
})

test_that("the energy is the sigma-sampled marginal integrated over sigma", {
  fx <- .IsRun(.IsModel())
  engIs <- .IsEngine(fx)
  sampled <- fx$model
  sampled$residualCorrelation$integrateSigma <- NULL
  sampled$residualCorrelation$sigmaRef <- NULL
  engSampled <- .IsEngine(fx, sampled)

  st <- fx$mcmc$recentState[[1]]
  theta <- st$metro$parameters
  beta <- st$gibbs$beta
  lambda <- st$gibbs$lambda
  s <- fx$model$residualCorrelation$sigmaRef
  gibbs <- fx$model$priors$gibbs
  energy <- .Signal(engIs, 1L, theta, beta, st$gibbs$sigma, lambda)[[2]]

  # beta | lambda, sigma ~ N(0, (sigma / s)^2 (lambda D)^-) is today's prior at
  # lambda (s / sigma)^2; integrate today's marginal against sigma's prior.
  sigmaHat <- st$gibbs$sigma
  u <- seq(log(sigmaHat) - 1.5, log(sigmaHat) + 1.5, length.out = 2001)
  integrand <- vapply(u, function(lu) {
    sig <- exp(lu)
    .Signal(engSampled, 1L, theta, beta, sig, lambda * (s / sig)^2)[[2]] +
      stats::dgamma(1 / sig^2, shape = gibbs$aSigma, rate = gibbs$bSigma,
                    log = TRUE) + log(2) - 3 * lu + lu
  }, numeric(1))
  top <- max(integrand)
  quadrature <- top + log(sum(exp(integrand - top)) * diff(u)[1])
  expect_equal(energy, quadrature, tolerance = 1e-9)

  # sigma is out of the energy
  expect_identical(
    .Signal(engIs, 1L, theta, beta, 3 * st$gibbs$sigma, lambda)[[2]], energy
  )
  expect_error(StratoBayes:::.sb_eval_logpost(engIs, 1L, theta),
               "integrated out")
})

test_that("the energy depends on lambda and s only through lambda s^2", {
  fx <- .IsRun(.IsModel())
  st <- fx$mcmc$recentState[[1]]
  s <- fx$model$residualCorrelation$sigmaRef
  rescaled <- fx$model
  rescaled$residualCorrelation$sigmaRef <- 1.7 * s
  eng1 <- .IsEngine(fx)
  eng2 <- .IsEngine(fx, rescaled)
  e1 <- .Signal(eng1, 1L, st$metro$parameters, st$gibbs$beta,
                st$gibbs$sigma, st$gibbs$lambda)[[2]]
  e2 <- .Signal(eng2, 1L, st$metro$parameters, st$gibbs$beta,
                st$gibbs$sigma, st$gibbs$lambda / 1.7^2)[[2]]
  expect_equal(e2, e1, tolerance = 1e-10)
})

test_that("sigma and beta follow their conditionals at a fixed alignment", {
  skip_on_cran()
  fx <- .IsRun(.IsModel())
  eng <- .IsEngine(fx)
  s <- fx$model$residualCorrelation$sigmaRef
  gibbs <- fx$model$priors$gibbs
  n <- length(fx$data$signalAttr$signalValuesVec[[1]])
  probe <- StratoBayes:::.sb_nig_probe(eng, 1L, 4000L, 11, FALSE)

  pit <- stats::pgamma(1 / probe$sigma^2, shape = gibbs$aSigma + (n - 2) / 2,
                       rate = gibbs$bSigma + probe$S / 2)
  expect_gt(stats::ks.test(pit, "punif")$p.value, 1e-3)

  # beta = mu + (sigma / s) L^-T z: rescaled by s / sigma its spread is
  # Qref, the covariance at sigma = s, whatever sigma was drawn.
  centred <- sweep(probe$beta, 2, colMeans(probe$beta))
  scaled <- centred * (s / probe$sigma)
  for (j in c(3L, 12L, 20L)) {
    expect_equal(stats::var(scaled[, j]) / probe$Qref[j, j], 1,
                 tolerance = 0.1)
  }
  # Without the rescale the spread would carry E[(sigma / s)^2], far from 1.
  expect_gt(abs(mean((probe$sigma / s)^2) - 1), 0.3)
})

.LambdaGridCdf <- function(eng, chain, theta, beta, sigma, lambdaMin, temp,
                           mask, grid) {
  logDensity <- vapply(grid, function(lam) {
    sep <- .Signal(eng, chain, theta, beta, sigma, lam)
    prior <- sep[[1]]
    signal <- sep[[2]]
    w <- c(prior = if (bitwAnd(mask, 1L)) 1 / temp else 1,
           signal = if (bitwAnd(mask, 2L)) 1 / temp else 1)
    w[["prior"]] * prior + w[["signal"]] * signal + log(lam)
  }, numeric(1))
  logDensity[grid < lambdaMin] <- -Inf
  dens <- exp(logDensity - max(logDensity))
  cdf <- cumsum(c(0, (dens[-1] + dens[-length(dens)]) / 2 * diff(log(grid))))
  cdf / cdf[length(cdf)]
}

.HotRungCheck <- function(components, chain = 2L) {
  skip_on_cran()
  fx <- .IsRun(.IsModel(), temperatures = c(1, 4),
               temperingComponents = components)
  eng <- .IsEngine(fx)
  mask <- fx$mcmc$temper$mask
  st <- fx$mcmc$recentState[[chain]]
  probe <- StratoBayes:::.sb_nig_probe(eng, chain, 30000L, 5, TRUE)
  expect_identical(probe$hot, chain > 1L)
  gibbs <- fx$model$priors$gibbs
  n <- length(fx$data$signalAttr$signalValuesVec[[1]])

  pit <- stats::pgamma(1 / probe$sigma^2, shape = gibbs$aSigma + (n - 2) / 2,
                       rate = gibbs$bSigma + probe$S / 2)
  expect_gt(stats::ks.test(pit, "punif")$p.value, 1e-3)

  draws <- probe$lambda[seq(1001, 30000, by = 15)]
  grid <- exp(seq(log(gibbs$lambdaMin), log(max(draws)) + 3,
                  length.out = 3000))
  cdf <- .LambdaGridCdf(eng, chain, st$metro$parameters, st$gibbs$beta,
                        st$gibbs$sigma, gibbs$lambdaMin, probe$temperature,
                        mask, grid)
  empirical <- stats::ecdf(draws)
  expect_lt(max(abs(empirical(grid) - cdf)), 0.06)
}

test_that("the cold chain's lambda draw keeps its conditional", {
  .HotRungCheck("full", chain = 1L)
})

test_that("hot-rung lambda and sigma keep their tempered target (full)", {
  .HotRungCheck("full")
})

test_that("hot-rung lambda and sigma keep their tempered target (signal)", {
  .HotRungCheck("signal")
})

test_that("an integrated sigma lifts the sigma temperature bound", {
  integrated <- .IsModel()
  sampled <- .IsModel(integrateSigma = FALSE)
  bound <- StratoBayes:::.SigmaTemperatureBound(sampled, 15L)
  expect_true(is.finite(bound))
  expect_identical(StratoBayes:::.SigmaTemperatureBound(integrated, 15L), Inf)
  expect_silent(StratoBayes:::.CheckLadderTarget(c(1, 10, 4 * bound),
                                                 integrated, 15L))
  expect_error(StratoBayes:::.CheckLadderTarget(c(1, 10, 4 * bound),
                                                sampled, 15L),
               "no proper target")
  expect_identical(StratoBayes:::.AutoLadderTmax(8L, integrated, 15L),
                   StratoBayes:::.LadderTmax(8L))
  expect_lt(StratoBayes:::.AutoLadderTmax(8L, sampled, 15L),
            StratoBayes:::.LadderTmax(8L))
})

test_that("a continued run keeps sigma integrated out", {
  fx <- .IsRun(.IsModel(), nIter = 40L, temperatures = c(1, 3))
  continued <- suppressWarnings(RunStratModel(
    modelDir = fx$dir, modelName = "is", nIter = 20, quiet = TRUE,
    visualise = FALSE
  ))
  expect_true(continued$model$residualCorrelation$integrateSigma)
  cols <- grep("^sigma_", dimnames(continued$samples)[[2]])
  sigma <- continued$samples[, cols, 1, 1]
  expect_true(all(is.finite(sigma) & sigma > 0))
  expect_false(isTRUE(all(sigma == fx$model$residualCorrelation$sigmaRef)))
  # The checkpoint carries the drawn sigma, not sigmaRef.
  state <- readRDS(file.path(fx$dir, "is_mcmc_run_1.rds"))$recentState[[1]]
  expect_true(state$gibbs$sigma > 0)
  expect_false(state$gibbs$sigma == fx$model$residualCorrelation$sigmaRef)
  last <- dim(continued$samples)[1]
  expect_equal(state$gibbs$sigma, unname(sigma[last]))
})

test_that("the reference scale is the residual SD under OU whitening", {
  model <- .IsModel()
  expect_identical(.IsModel(bSigma = 0.02)$residualCorrelation$sigmaRef,
                   model$residualCorrelation$sigmaRef)

  # The sites with enough rows for a fit, whitened by a dense OU correlation
  # in which a tied height starts an independent segment.
  data("stratData1", package = "StratoBayes", envir = environment())
  d <- StratoBayes:::.EnsurePreExtracted(stratData1)
  nKnots <- model$splineBase$nKnots
  rss <- df <- 0
  ties <- 0
  for (s in seq_len(d$S)) {
    Look <- function(type) {
      SignalLookUp(d, type = type, site = s, signal = 1,
                   includeNAsignal = FALSE)
    }
    z <- Look("height")
    ord <- order(z)
    z <- z[ord]
    y <- Look("value")[ord]
    base <- StratoBayes:::.CreateSplineBaseBspline(list(x = z), nKnots,
                                                   min(z), max(z))
    n <- length(z)
    if (n < base$num_basis + 5L) next
    ties <- ties + sum(diff(z) == 0)
    B <- StratoBayes:::.sb_spline_design(base$ext_knots, z, 4L)
    Lt <- t(chol(.OuDenseR(z, rep(1L, n), rep(0.03, n))))
    qrB <- qr(forwardsolve(Lt, B))
    rss <- rss + sum(qr.resid(qrB, forwardsolve(Lt, y))^2)
    df <- df + n - qrB$rank
  }
  expect_gt(ties, 0)
  expect_equal(model$residualCorrelation$sigmaRef, sqrt(rss / df),
               tolerance = 1e-10)
  unwhitened <- StratoBayes:::.SignalNoiseVariance(stratData1, nKnots)
  expect_gt(abs(model$residualCorrelation$sigmaRef /
                  sqrt(unwhitened[[1]]$pooled) - 1), 0.05)

  # A site at corLength 0 is fitted by ordinary least squares, exactly; here
  # it is the only site with enough rows.
  ell <- matrix(c(0, 0.03, 0.03), ncol = 1,
                dimnames = list(d$sites, d$signalAttr$signalNames))
  zeroModel <- .IsModel(corLength = ell)
  expect_identical(zeroModel$residualCorrelation$sigmaRef,
                   sqrt(unwhitened[[1]]$pooled))

  # A signal constant within each site has no noise estimate; s falls to 1.
  data("signalData1", package = "StratoBayes", envir = environment())
  flat <- signalData1
  flat$value <- match(flat$site, unique(flat$site))
  flatModel <- suppressWarnings(suppressMessages(StratModel(
    StratData(signal = flat), alignmentScale = "height", sedModel = "site",
    residualCorrelation = "ou", sigmaFixed = FALSE, corLength = 0.03,
    individualSplineIter = 40, integrateSigma = TRUE
  )))
  expect_identical(flatModel$residualCorrelation$sigmaRef, 1)
})

test_that("gradient proposals need sigma sampled", {
  data("stratData1", package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir("is-grad")
  Run <- function(name, ...) {
    suppressWarnings(suppressMessages(RunStratModel(
      stratObject = stratData1, nIter = 20L, nChains = 1L, seed = 1,
      nThreads = 1L, quiet = TRUE, visualise = FALSE, modelDir = td,
      modelName = name, gradientProposals = "on", ...
    )))
  }
  expect_error(Run("given", stratModel = .IsModel()),
               "Gradient-based proposals do not support sigma integrated out")
  built <- Run("built", alignmentScale = "height", sedModel = "site",
               individualSplineIter = 40, corLength = 0.03)
  expect_identical(built$model$residualCorrelation$type, "ou")
  expect_false(built$model$sigmaFixed)
  expect_null(built$model$residualCorrelation$integrateSigma)
})

test_that("the engine checks the integrateSigma fields", {
  fx <- .IsRun(.IsModel(), nIter = 20L, temperatures = c(1, 2))
  Engine <- function(edit) {
    model <- fx$model
    model$residualCorrelation <- utils::modifyList(model$residualCorrelation,
                                                   edit)
    .IsEngine(fx, model)
  }
  expect_error(Engine(list(integrateSigma = NA)), "TRUE or FALSE")
  expect_error(Engine(list(sigmaRef = c(1, 2))), "one value per signal")
  expect_error(Engine(list(sigmaRef = -1)), "finite and positive")
  fixed <- fx$model
  fixed$sigmaFixed <- TRUE
  expect_error(.IsEngine(fx, fixed), "sigmaFixed = FALSE")

  eng <- .IsEngine(fx)
  st <- fx$mcmc$recentState[[1]]
  # A factor the conditioning gate cannot trust scores -Inf.
  expect_identical(.Signal(eng, 1L, st$metro$parameters, st$gibbs$beta,
                           st$gibbs$sigma, 1e100)[[2]], -Inf)
  theta <- st$metro$parameters
  expect_error(StratoBayes:::.sb_compute_gradient(eng, 1L), "integrated out")
  expect_error(StratoBayes:::.sb_gradient_at(eng, 1L, theta), "integrated out")
  expect_error(StratoBayes:::.sb_hmc_eval_logpost(eng, 1L, theta),
               "integrated out")
  expect_error(StratoBayes:::.sb_nig_probe(eng, 3L, 10L, 1), "between 1")
  expect_error(StratoBayes:::.sb_nig_probe(eng, 1L, 0L, 1), "positive")
  expect_error(StratoBayes:::.sb_nig_probe(eng, 1L, 10L, -1), "seed")
  sampled <- fx$model
  sampled$residualCorrelation$integrateSigma <- NULL
  expect_error(StratoBayes:::.sb_nig_probe(.IsEngine(fx, sampled), 1L, 10L, 1),
               "does not integrate")
})
