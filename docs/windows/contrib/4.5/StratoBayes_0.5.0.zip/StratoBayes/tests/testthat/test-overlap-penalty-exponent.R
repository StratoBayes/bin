test_that("OverlapPenaltyFunction() uses q = 1/2 only if sigmaFixed is FALSE", {
  nSig <- stratData2[[c("signalAttr", "signalN")]]
  nSites <- stratData2[["S"]]
  sdSpline <- rep(list(rep(0.01, nSites)), nSig)
  Penalty <- function(sigmaFixed) {
    OverlapPenaltyFunction(
      stratData = stratData2, sigmaFixed = sigmaFixed,
      penaltyMultiplier = 1 / 4, sdSpline = sdSpline
    )
  }
  sdRatio <- vapply(
    seq_len(nSites),
    function(s) sd(SignalLookUp(stratData2, "value", s, 1, FALSE)) / 0.01,
    numeric(1)
  )
  expect_true(all(sdRatio[!is.na(sdRatio)] > 1))
  base <- -sqrt(nSites - 1) + sqrt(0:(nSites - 1))

  expect_equal(
    Penalty(FALSE)[[1]],
    base * mean(sqrt(sdRatio), na.rm = TRUE) / 4
  )
  expect_equal(Penalty(TRUE)[[1]], base * mean(sdRatio, na.rm = TRUE) / 4)
  expect_equal(Penalty(1)[[1]], Penalty(TRUE)[[1]])
})
