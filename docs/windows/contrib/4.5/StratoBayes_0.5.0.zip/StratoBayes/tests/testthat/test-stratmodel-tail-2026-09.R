RescaledData1 <- function(hMul) {
  sig <- stratData1[["signal"]]
  sig[["height"]] <- sig[["height"]] * hMul
  suppressMessages(
    StratData(sig, zColumn = "height", siteColumn = "site",
              signalColumn = "value")
  )
}

# Records the `bLambda` each per-site seeding spline is fitted under, and the
# one a standalone BayesianSpline() would place the default at on that site,
# without running the fits.
SeedingBLambdas <- function(data, ..., alignmentScale = "height",
                            sedModel = "site") {
  seen <- new.env()
  local_mocked_bindings(
    BayesianSpline = function(x, y, nKnots, nIter, aLambda, bLambda, aSigma,
                              bSigma) {
      ownScale <- .ModelBspline(
        data.frame(x = x, y = y), nKnots, NULL, aSigma, bSigma, aLambda,
        1000, NULL, FALSE, NULL, NULL, raiseBLambda = TRUE
      )[[c("priors", "gibbs", "bLambda")]]
      seen[["bLambda"]] <- c(seen[["bLambda"]], bLambda)
      seen[["ownScale"]] <- c(seen[["ownScale"]], ownScale)
      list(sigma = rep(0.1, nIter))
    }
  )
  model <- suppressMessages(
    StratModel(data, alignmentScale = alignmentScale, sedModel = sedModel,
               ...,
               residualCorrelation = "none")
  )
  list(seen = seen[["bLambda"]], ownScale = seen[["ownScale"]],
       model = model)
}

# Heights multiplied by `hMul` and alignment rates by `exp(rateShift)`: the
# seeding fits see only the first, the model's own lambda scale both.
AgeScaleSeeding <- function(hMul, rateShift) {
  scaled <- lapply(stratData2[c("signal", "parts", "ties")], function(x) {
    x[["height"]] <- x[["height"]] * hMul
    x
  })
  data <- suppressMessages(
    StratData(scaled[["signal"]], parts = scaled[["parts"]],
              ties = scaled[["ties"]], zColumn = "height",
              siteColumn = "site", signalColumn = c("a", "b"))
  )
  priors <- stratPrior2
  for (rate in grep("gammaLog", names(priors), value = TRUE)) {
    priors[[rate]][["args"]][["mean"]] <-
      priors[[rate]][["args"]][["mean"]] + rateShift
  }
  SeedingBLambdas(data, priors, alignmentScale = "age", sedModel = "s",
                  alphaPosition = "b", nKnots = 5)
}

test_that("seeding splines place a default bLambda at their own scale (#1650)",
          {
            data <- RescaledData1(1e3)
            fit <- SeedingBLambdas(data)
            gibbs <- fit[["model"]][[c("priors", "gibbs")]]
            # millimetre heights put every site's healthy lambda far above
            # the cap that the absolute default sets
            expect_length(fit[["seen"]], data[["S"]])
            expect_true(all(fit[["seen"]] > 1000))
            expect_identical(fit[["seen"]], fit[["ownScale"]])
            # the model's own prior follows the model's scale
            expect_identical(
              gibbs[["bLambda"]],
              .BLambdaAtScale(1000, gibbs[["lambdaMin"]])
            )
          })

test_that("age-scale seeding splines are scaled on their own heights (#1650)", {
  # mm heights with rates in mm per unit age leave the age span unchanged
  fit <- AgeScaleSeeding(1e3, log(1e3))
  gibbs <- fit[[c("model", "priors", "gibbs")]]
  expect_identical(gibbs[["bLambda"]],
                   .BLambdaAtScale(c(1000, 1000), gibbs[["lambdaMin"]]))
  expect_identical(fit[["seen"]], fit[["ownScale"]])
  expect_true(all(fit[["seen"]] > 1e6))
})

test_that("a model scale keyed to age units does not reach the sites (pin)", {
  # Slower rates stretch the age span a thousandfold and raise the model's
  # bLambda, but the seeding fits are on unchanged heights, at their own scale.
  fit <- AgeScaleSeeding(1, -log(1e3))
  expect_true(all(fit[[c("model", "priors", "gibbs", "bLambda")]] > 1e6))
  expect_identical(fit[["seen"]], fit[["ownScale"]])
  expect_true(all(fit[["seen"]] < 1e6))
})

test_that("an explicit bLambda reaches the seeding splines unraised (#1650)", {
  fit <- SeedingBLambdas(RescaledData1(1e3), bLambda = 1000)
  expect_equal(unique(fit[["seen"]]), 1000)
  expect_identical(fit[[c("model", "priors", "gibbs", "bLambda")]], 1000)
})

test_that("a custom penalty function must return numeric adjustments (#1636)",
          {
            for (ret in list(TRUE, FALSE, NA, function(...) 1,
                             list(function(...) 1), list())) {
              BadPenalty <- function(...) ret
              expect_error(
                suppressMessages(
                  StratModel(stratData1, alignmentScale = "height",
                             sedModel = "site", sigmaFixed = 1,
                             overlapPenalty = list(BadPenalty),
                             residualCorrelation = "none")
                ),
                "penalty function returned .* must return numeric adjustments"
              )
            }
          })

test_that("overlapPenalty = NA stays rejected, not read as FALSE (#1636 pin)", {
  expect_error(
    suppressMessages(
      StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                 sigmaFixed = 1, overlapPenalty = NA,
                 residualCorrelation = "none")
    ),
    "Invalid `overlapPenalty`"
  )
})

test_that("disableTies refuses a site named twice (#1390)", {
  expect_error(
    suppressMessages(
      StratModel(stratData2, alignmentScale = "height", sedModel = "site",
                 sigmaFixed = c(1, 1), disableTies = list(site1 = 1, site1 = 2),
                 residualCorrelation = "none")
    ),
    "site1.*list\\(site1 = c\\(1, 2\\)\\)"
  )
  model <- suppressMessages(
    StratModel(stratData2, alignmentScale = "height", sedModel = "site",
               sigmaFixed = c(1, 1), disableTies = list(site1 = c(1, 2)),
               residualCorrelation = "none")
  )
  expect_false(any(model[["tiesActive"]][, "site1"]))
})

test_that("knotRange warns that flexible knots ignore it (#871)", {
  expect_warning(
    suppressMessages(
      StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                 sigmaFixed = 1, knotRange = c(-5, 12),
                 residualCorrelation = "none")
    ),
    "`knotRange` has no effect"
  )
  expect_no_warning(
    suppressMessages(
      StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                 sigmaFixed = 1, knotRange = c(-5, 12), flexibleKnots = FALSE,
                 residualCorrelation = "none")
    )
  )
})

test_that("a constant signal keeps a positive default bSigma (#868)", {
  sig <- stratData1[["signal"]]
  sig[["value"]] <- 1
  data <- suppressMessages(
    StratData(sig, zColumn = "height", siteColumn = "site",
              signalColumn = "value")
  )
  model <- suppressMessages(
    StratModel(data, alignmentScale = "height", sedModel = "site",
               sigmaFixed = 1,
               residualCorrelation = "none")
  )
  expect_identical(model[[c("priors", "gibbs", "bSigma")]], 0.01)
})
