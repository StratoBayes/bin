# #2163: a segmented run must equal an uninterrupted one on every model family,
# not only stratModel1. Engine state that the checkpoint does not carry shows up
# here as the first differing parameter.

.OracleConfigs <- function() {
  data(stratData1, stratData2, stratPrior2, package = "StratoBayes",
       envir = environment())
  Model <- function(d, ...) {
    suppressWarnings(StratModel(d, alignmentScale = "height", ...,
                                residualCorrelation = "none"))
  }
  n <- 30
  h <- seq(0, 10, length.out = n)
  offsetData <- StratData(
    signal = data.frame(
      site = rep(c("site_1", "site_2"), each = n),
      height = c(h, h),
      value = c(sin(h), sin(h) + 2) +
        withr::with_seed(1983, rnorm(2 * n, 0, 0.1))
    ),
    group = data.frame(site = c("site_1", "site_2"), group = c("A", "B"))
  )
  list(
    defaults = list(stratData1, Model(stratData1, sedModel = "site")),
    sigmaFree = list(
      stratData1,
      Model(stratData1, sedModel = "site", sigmaFixed = FALSE)
    ),
    ties = list(stratData2, Model(stratData2, sedModel = "site")),
    noOverlap = list(
      stratData1,
      Model(stratData1, sedModel = "site", overlapPenalty = FALSE)
    ),
    signalOffsets = list(
      offsetData,
      Model(offsetData, sedModel = "site", nKnots = 8, signalOffsets = TRUE)
    ),
    sedSmooth = list(
      stratData1,
      Model(stratData1, sedModel = "site, partition", sedSmooth = TRUE,
            nKnots = 10)
    ),
    age = list(
      stratData2,
      suppressWarnings(StratModel(
        stratData2, priors = stratPrior2, alignmentScale = "age",
        sedModel = "site", alphaPosition = c("top", "middle", "bottom"),
        nKnots = 10,
        residualCorrelation = "none"
      ))
    )
  )
}

.OracleRun <- function(cfg, nIter, modelDir) {
  suppressWarnings(RunStratModel(
    stratObject = cfg[[1]], stratModel = cfg[[2]], nIter = nIter, nChains = 2,
    seed = 7, tempering = TRUE, adaptProposal = FALSE,
    gradientProposals = "off", engine = "cpp", quiet = TRUE,
    visualise = FALSE, runParallel = FALSE, nThreads = 1L,
    modelDir = modelDir, modelName = "oracle"
  ))
}

test_that("segmented runs match uninterrupted runs on every config (#2163)", {
  skip_on_cran()

  configs <- .OracleConfigs()
  for (name in names(configs)) {
    cfg <- configs[[name]]
    if (name == "sedSmooth") next
    whole <- .OracleRun(cfg, 20, withr::local_tempdir())
    first <- .OracleRun(cfg, 10, withr::local_tempdir())
    segmented <- suppressWarnings(RunStratModel(
      first, nIter = 10, seed = 7, engine = "cpp", quiet = TRUE,
      visualise = FALSE, nThreads = 1L
    ))

    expect_identical(dim(segmented[["samples"]]), dim(whole[["samples"]]),
                     label = name)
    differs <- which(
      unname(segmented[["samples"]]) != unname(whole[["samples"]]),
      arr.ind = TRUE
    )
    firstDiff <- if (nrow(differs)) {
      colnames(whole[["samples"]])[differs[1, 2]]
    } else {
      "none"
    }
    expect_equal(unname(segmented[["samples"]]), unname(whole[["samples"]]),
                 label = paste0(name, " (first differing parameter: ",
                                firstDiff, ")"))
  }
})

test_that("a segmented sedSmooth run matches an uninterrupted one (#2156)", {
  skip_on_cran()
  skip("#2156: sedAdapt is not checkpointed, so a continuation diverges")

  cfg <- .OracleConfigs()[["sedSmooth"]]
  whole <- .OracleRun(cfg, 20, withr::local_tempdir())
  first <- .OracleRun(cfg, 10, withr::local_tempdir())
  segmented <- suppressWarnings(RunStratModel(
    first, nIter = 10, seed = 7, engine = "cpp", quiet = TRUE,
    visualise = FALSE, nThreads = 1L
  ))
  expect_equal(unname(segmented[["samples"]]), unname(whole[["samples"]]))
})
