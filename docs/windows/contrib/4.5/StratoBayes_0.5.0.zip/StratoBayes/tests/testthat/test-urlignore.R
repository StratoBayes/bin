test_that(".urlignore patterns also match the bare repository URL", {
  path <- testthat::test_path("..", "..", ".urlignore")
  skip_if_not(file.exists(path), ".urlignore is build-ignored")
  lines <- readLines(path)
  patterns <- lines[nzchar(lines) & !startsWith(lines, "#")]
  expect_gt(length(patterns), 0L)
  for (pattern in patterns) {
    bare <- sub("/?\\*$", "", pattern)
    expect_true(grepl(utils::glob2rx(pattern), bare), info = pattern)
    expect_true(grepl(utils::glob2rx(pattern), paste0(bare, "/issues/1")),
                info = pattern)
  }
})
