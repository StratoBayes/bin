# The boundary-relocation move's accept step.
#
# Each pin drives the engine where the correct ratio has a known limit, rather
# than replaying a recorded trajectory:
#   - at T = 1e8 under full tempering the ratio is (dLogPost / T) ~ 0, so a hot
#     rung rejects only proposals that fail the support checks, and accepts far
#     more often than the cold chain;
#   - under signal-only tempering the prior, which carries the sedimentation
#     terms, stays at T = 1, so the same hot rung accepts about as rarely as
#     the cold chain;
#   - at T = 1 the cold chain rejects most proposals and stays near its mode.
# The step sds adapt as the engine runs (the default), so the rates are those
# of the adapted kernel.

BoundaryWarmStart2510 <- function(components, seed) {
  data(stratData1, package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height"),
    alignmentScale = "height", sedModel = "site, partition", sedSmooth = TRUE
  ))
  model[["sedSmoothInfo"]][["boundaryMove"]] <- list(prob = 1,
                                                     includeCold = TRUE)
  td <- tempfile("bm2510")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 150L,
    nChains = 3L, tempering = TRUE, temperingComponents = components,
    gradientProposals = "off", quiet = TRUE, visualise = FALSE,
    nThreads = 1L, nRun = 1L, seed = seed, modelDir = td, modelName = "s"
  ))
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))
  model <- result[["model"]]
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  list(data = result[["data"]], model = model, mcmc = mcmc)
}

# Every rung attempts the move every iteration; the hot rungs sit at T = 1e8.
# Returns the per-rung (attempts, accepts) counts and the cold chain's stored
# logPost beside a fresh evaluation at each iteration.
RunHotRungs2510 <- function(fx, nIter) {
  engine <- .sb_create_engine(fx[["data"]], fx[["model"]], fx[["mcmc"]],
                              fx[["mcmc"]][["recentState"]])
  .sb_update_temperatures(engine, c(1, 1e8, 1e8))
  stored <- fresh <- numeric(nIter)
  for (i in seq_len(nIter)) {
    .sb_run_block(engine, 1L)
    cold <- .sb_extract_state(engine)[[1]][["metro"]]
    stored[i] <- cold[["logPost"]]
    fresh[i] <- .sb_eval_logpost(engine, 1L, cold[["parameters"]],
                                 marginal = TRUE)
  }
  list(counts = .sb_sed_boundary_stats(engine)[["counts"]],
       stored = stored, fresh = fresh)
}

test_that("boundary move accepts on the tempered ratio (#2510)", {
  set.seed(2510)
  fx <- BoundaryWarmStart2510("full", seed = 11L)
  set.seed(1)
  run <- RunHotRungs2510(fx, 300L)
  counts <- run[["counts"]]

  expect_equal(counts[, 1], rep(300, 3))
  # An always-accept step takes most cold proposals, and the cold chain's
  # logPost collapses by orders of magnitude.
  expect_gt(counts[1, 2], 0)
  expect_lt(counts[1, 2] / counts[1, 1], 0.35)
  expect_gt(min(run[["stored"]]), -1e3)
  # Dropping T from the ratio holds the hot rungs near the cold chain's rate.
  expect_gt(sum(counts[-1, 2]) / sum(counts[-1, 1]), 0.45)

  expect_equal(run[["stored"]], run[["fresh"]], tolerance = 1e-8)
})

test_that("partial tempering leaves the move's prior at T = 1 (#2510)", {
  set.seed(2510)
  fx <- BoundaryWarmStart2510("signal", seed = 11L)
  set.seed(1)
  run <- RunHotRungs2510(fx, 300L)
  counts <- run[["counts"]]

  expect_equal(counts[, 1], rep(300, 3))
  # Tempering every component instead lets the hot rungs accept as they do
  # under full tempering.
  hotRate <- sum(counts[-1, 2]) / sum(counts[-1, 1])
  expect_gt(hotRate, 0.1)
  expect_lt(hotRate, 0.38)
  expect_gt(counts[1, 2], 0)
  expect_lt(counts[1, 2] / counts[1, 1], 0.35)
  expect_equal(run[["stored"]], run[["fresh"]], tolerance = 1e-8)
})

test_that("untempered chains make boundary moves by default (#2510)", {
  # stratData4 has a shared formation boundary, so the move is on by default,
  # and at its defaults (includeCold = FALSE) only rungs hotter than T = 1
  # attempt it -- unless no rung is hotter, as here.
  data(stratData4, package = "StratoBayes", envir = environment())
  set.seed(2510)
  model <- suppressWarnings(StratModel(
    stratData4, priors = AutoPrior(stratData4, "height"),
    alignmentScale = "height", sedModel = "site, partition", sedSmooth = TRUE
  ))
  td <- tempfile("bm2510")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  suppressWarnings(RunStratModel(
    stratObject = stratData4, stratModel = model, nIter = 100L,
    nChains = 2L, tempering = FALSE, gradientProposals = "off",
    quiet = TRUE, visualise = FALSE, nThreads = 1L, nRun = 1L, seed = 7L,
    modelDir = td, modelName = "s"
  ))
  stats <- readRDS(file.path(td, "s_mcmc_run_1.rds"))[["sedBoundaryStats"]]

  expect_true(stats[["active"]])
  # About 0.2 * 100 attempts per chain at the default probability.
  expect_true(all(stats[["counts"]][, 1] > 0))
})
