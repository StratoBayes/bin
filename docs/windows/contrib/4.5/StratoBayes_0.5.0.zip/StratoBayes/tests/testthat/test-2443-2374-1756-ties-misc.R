# #2443: a disabled tie with a non-native density must not disable threading.
# #2374: tie densities resolve via `.TieDensity()`, never a global shadow.
# #1756: a NaN age reaches the "invalid values" diagnostic, not `if (NaN)`.

.withGlobalDensity <- function(name, fun, env = parent.frame()) {
  assign(name, fun, envir = globalenv())
  withr::defer(rm(list = name, envir = globalenv()), envir = env)
}

test_that("a disabled custom tie does not force sequential chains (#2443)", {
  skip_on_cran()
  .withGlobalDensity("dfoo2443", function(x, mean, log = FALSE) {
    dnorm(x, mean, 1, log = log)
  })
  data(signalData2, package = "StratoBayes", envir = environment())
  data(tiesData2, package = "StratoBayes", envir = environment())
  data(partsData2, package = "StratoBayes", envir = environment())
  data(stratPrior2, package = "StratoBayes", envir = environment())
  ties <- rbind(tiesData2,
                data.frame(site = "site3", height = 10, arg1 = 30, arg2 = NA,
                           densityFun = "dfoo2443"))
  stratData2 <- StratData(signalData2, parts = partsData2, ties = ties,
                          signalColumn = c("a", "b"), zColumn = "height",
                          siteColumn = "site")

  nWorkers <- function(disable) {
    model <- suppressWarnings(suppressMessages(
      StratModel(stratData = stratData2, priors = stratPrior2,
                 alignmentScale = "age", sedModel = "s", alphaPosition = "b",
                 nKnots = 5, sigmaFixed = c(0.5, 0.5), disableTies = disable)
    ))
    td <- file.path(tempdir(), paste0("t2443_", sample.int(1e6, 1)))
    dir.create(td)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)
    mcmcSpec <- StratMCMC(model, nIter = 3, nChains = 2, nThreads = 1)
    res <- suppressWarnings(
      RunStratModel(stratData2, model, mcmcSpec, seed = 1, quiet = TRUE,
                    visualise = FALSE, modelDir = td, modelName = "t2443",
                    engine = "cpp")
    )
    mcmc <- readRDS(file.path(td, "t2443_mcmc_run_1.rds"))
    mod <- res$model
    if (is.null(mod$.logpost_cpp)) {
      mod$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(mod)
    }
    mod[[".tiesDispatch"]] <- StratoBayes:::.BuildTiesDispatch(res$data, mod)
    callback <- StratoBayes:::.MakeTiesCallback(res$data, mod)
    ptr <- StratoBayes:::.sb_create_engine(res$data, mod, mcmc,
                                           mcmc$recentState, callback)
    suppressMessages(StratoBayes:::.sb_set_threads(ptr, 2L))
    StratoBayes:::.sb_n_workers(ptr)
  }
  expect_gt(nWorkers(list(site3 = 2)), 0L)
  expect_equal(nWorkers(NULL), 0L)
})

test_that("tie arity ignores a global shadow of a native density (#2374)", {
  .withGlobalDensity("dcauchy", function(x, log = FALSE) 1)
  .withGlobalDensity("dunif", function(x, log = FALSE) 1)
  ties <- data.frame(site = c("a", "b"), height = 0,
                     densityFun = c("dcauchy", "dunif"),
                     arg1 = c(20, 5), arg2 = c(2, 9))
  expect_no_warning(got <- StratoBayes:::.TieCentralAges(ties))
  expect_equal(got, c(20, 7))
})

test_that("a NaN age gives the diagnostic, not `if (NaN)` (#1756)", {
  data(stratData2, package = "StratoBayes", envir = environment())
  data(stratPrior2, package = "StratoBayes", envir = environment())
  model <- suppressWarnings(suppressMessages(
    StratModel(stratData = stratData2, priors = stratPrior2,
               alignmentScale = "age", sedModel = "s", alphaPosition = "b",
               nKnots = 5, sigmaFixed = c(0.5, 0.5))
  ))
  model[["flexibleKnots"]] <- FALSE
  model[[c("splineBase", "knotRange")]] <- c(-1e3, 1e3)
  mcmc <- StratMCMC(model, nIter = 3, nChains = 1)
  calls <- new.env()
  calls$n <- 0L
  nanAges <- function(...) {
    calls$n <- calls$n + 1L
    ages <- .sb_age_convert_orig(...)
    ages[["signal"]][[1]][1] <- NaN
    ages
  }
  .sb_age_convert_orig <- StratoBayes:::.sb_age_convert
  testthat::local_mocked_bindings(.sb_age_convert = nanAges,
                                  .package = "StratoBayes")
  Propose <- function() {
    StratoBayes:::.GenerateValidProposal(
      stratData2, model, mcmc, stateOld = NULL,
      ProposeMetro = StratoBayes:::.MetroPriorSample,
      initialState = TRUE, chain = 1
    )
  }
  expect_error(Propose(), "age-height conversion produced invalid values")
  expect_identical(calls$n, 1L)
})
