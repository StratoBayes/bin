# The boundary-relocation move shifts a site's alpha to hold its anchor
# boundary, so it must never target a site whose alpha is Fixed().

FixedAlphaRun <- function(stratData, priors, scale,
                          boundaryMove = list(prob = 1, includeCold = TRUE)) {
  sModel <- suppressWarnings(StratModel(
    stratData, priors = priors, alignmentScale = scale,
    sedModel = "site, partition", sedSmooth = TRUE, nKnots = 10
  ))
  # By default on the cold chain at every iteration, so the saved samples see
  # each move.
  sModel$sedSmoothInfo["boundaryMove"] <- list(boundaryMove)
  td <- tempfile("sedfixed")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressMessages(suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = sModel,
    nIter = 100, nChains = 2L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "fixed"
  )))
  list(
    samples = result$samples,
    stats = readRDS(file.path(td, "fixed_mcmc_run_1.rds"))$sedBoundaryStats
  )
}

test_that("boundary move leaves a Fixed alpha alone (height scale)", {
  data(stratData4, package = "StratoBayes")
  priors <- AutoPrior(stratData4, "height")
  # Site 2 holds every boundary target, a shared boundary among them.
  priors$alpha_site2 <- Fixed(12)
  run <- FixedAlphaRun(stratData4, priors, "height")
  expect_true(all(run$samples[, "alpha_site2", , ] == 12))
  expect_null(run$stats)
  # Without its only shared boundary, the move no longer switches itself on.
  expect_null(FixedAlphaRun(stratData4, priors, "height", NULL)$stats)
})

test_that("boundary move leaves a Fixed alpha alone (age scale)", {
  data(stratData2, package = "StratoBayes")
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = -100, max = 100),
    "alpha_site2" = Fixed(0),
    "alpha_site3" = UniformPrior(min = -100, max = 100),
    "gap_site2_1" = ExponentialPrior(rate = 1)
  ), class = c("StratPrior", "list"))
  run <- FixedAlphaRun(stratData2, priors, "age")
  expect_true(all(run$samples[, "alpha_site2", , ] == 0))
  # The move still runs on the sites whose alpha is free.
  expect_true(run$stats$active)
  expect_false(any(run$stats$targets[, 1] == 2L))
  expect_setequal(unique(run$stats$targets[, 1]), c(1L, 3L))
  expect_gt(sum(run$stats$counts[, 1]), 0)
})
