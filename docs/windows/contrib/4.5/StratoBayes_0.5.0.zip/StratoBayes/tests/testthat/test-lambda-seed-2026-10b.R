# .InitializeGibbs(): the lambda seed reads the starting alignment's penalty
# under flexibleKnots (#2722), and the beta seed fits the model's own knots
# (#2364 item 2) without failing on tied ages (#2364 tol).

kRate <- 100
kAlpha <- c(s1 = 10, s2 = 10.1)
kTrueStart <- c(alpha_s1 = kAlpha[["s1"]], alpha_s2 = kAlpha[["s2"]],
                gammaLog_s1 = log(kRate), gammaLog_s2 = log(kRate))
kNoiseSd <- 0.15

SeedData <- function(h1 = sort(runif(80, 0, 50)),
                     h2 = sort(runif(80, 0, 50))) {
  ages <- c(kAlpha[["s1"]] - h1 / kRate, kAlpha[["s2"]] - h2 / kRate)
  signal <- data.frame(
    site = rep(c("s1", "s2"), c(length(h1), length(h2))),
    height = c(h1, h2),
    value = sin(2 * pi * ages / 0.15) + 2 * (ages - 9.8) +
      rnorm(length(ages), 0, kNoiseSd)
  )
  tieHeights <- c(5, 45)
  ties <- data.frame(
    site = rep(c("s1", "s2"), each = 2),
    height = tieHeights,
    densityFun = "dnorm",
    arg1 = rep(kAlpha, each = 2) - tieHeights / kRate,
    arg2 = 0.05
  )
  parts <- data.frame(site = rep(c("s1", "s2"), each = 2), height = c(0, 50),
                      partition = rep(c("a", "b"), each = 2))
  StratData(signal = signal, parts = parts, ties = ties,
            signalColumn = "value", zColumn = "height", siteColumn = "site",
            partitionColumn = "partition")
}

SeedState <- function(data, logRateMedian = log(kRate), ...) {
  ratePrior <- NormalPrior(logRateMedian, 3)
  priors <- structure(
    list(alpha_s1 = UniformPrior(0, 100), alpha_s2 = UniformPrior(0, 100),
         gammaLog_s1 = ratePrior, gammaLog_s2 = ratePrior),
    class = c("list", "StratPrior")
  )
  model <- StratModel(data, priors, alignmentScale = "age", sedModel = "site",
                      alphaPosition = "bottom", ...)
  mcmc <- StratMCMC(model, nIter = 2, nChains = 1, tempering = FALSE,
                    nThreads = 1L, parametersInitial = kTrueStart)
  list(model = model,
       state = .GenerateInitialState(data, model, mcmc, chain = 1))
}

SeedRms <- function(data, state) {
  y <- data[[c("signalAttr", "signalValuesVec")]][[1]]
  fit <- state[[c("metro", "B")]][[1]] %*% state[[c("gibbs", "beta")]][[1]]
  sqrt(mean((y - fit)^2))
}

test_that("flexibleKnots lambda seed does not move with the prior medians", {
  set.seed(11)
  data <- SeedData()
  y <- data[[c("signalAttr", "signalValuesVec")]][[1]]
  groups <- .LambdaStarGroups(data, FALSE)[[1]]
  # log(rate) prior medians 4.6 log units apart: the data, and the starting
  # alignment, are the same, so only splineBase's span differs.
  offCentre <- SeedState(data, logRateMedian = 0)
  centred <- SeedState(data, logRateMedian = log(kRate))
  expect_gt(offCentre$model[[c("splineBase", "ageSpan")]] /
              centred$model[[c("splineBase", "ageSpan")]], 50)

  for (fit in list(offCentre, centred)) {
    alignmentBase <- fit$model[["splineBase"]]
    alignmentBase[["D"]] <- fit$state[[c("spline", "D")]]
    seed <- fit$state[[c("gibbs", "lambda")]][[1]]
    expect_equal(seed, .LambdaStar(alignmentBase, y, groups))
    expect_gte(seed, fit$model[[c("priors", "gibbs", "lambdaMin")]][[1]])
  }
  expect_equal(offCentre$state[[c("gibbs", "lambda")]],
               centred$state[[c("gibbs", "lambda")]])
})

test_that("fixed-knot lambda seed still reads splineBase", {
  set.seed(11)
  data <- SeedData()
  y <- data[[c("signalAttr", "signalValuesVec")]][[1]]
  fit <- SeedState(data, flexibleKnots = FALSE, knotRange = c(9, 10.5))
  expect_identical(fit$state[[c("gibbs", "lambda")]][[1]],
                   .LambdaStar(fit$model[["splineBase"]], y,
                               .LambdaStarGroups(data, FALSE)[[1]]))
})

test_that("beta seed fits the model's knots, not the signal's range", {
  set.seed(11)
  data <- SeedData()
  # knotRange wider than the signal ages: knots on the data range would
  # mismatch the basis the sampler evaluates beta on.
  fit <- SeedState(data, flexibleKnots = FALSE, sigmaFixed = FALSE,
                   knotRange = c(9, 10.5))
  expect_lt(SeedRms(data, fit$state), 2 * kNoiseSd)
  expect_lt(fit$state[[c("gibbs", "sigma")]][[1]], 2 * kNoiseSd)
})

test_that("beta seed survives heavily tied signal ages", {
  set.seed(11)
  tiedHeights <- c(rep(25, 100), seq(0, 50, length.out = 20))
  data <- SeedData(h1 = tiedHeights, h2 = seq(0, 50, length.out = 40))
  for (flexible in c(TRUE, FALSE)) {
    fit <- SeedState(data, flexibleKnots = flexible, sigmaFixed = FALSE,
                     knotRange = if (!flexible) c(9, 10.5))
    expect_false(all(fit$state[[c("gibbs", "beta")]][[1]] == 0))
    expect_lt(SeedRms(data, fit$state), 2 * kNoiseSd)
  }
})
