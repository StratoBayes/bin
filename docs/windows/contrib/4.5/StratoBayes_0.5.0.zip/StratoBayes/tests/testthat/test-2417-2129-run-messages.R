# #2417: the collapse warning named ties and sedimentation-rate priors whatever
# had put the chain out of support. It now names the term that is out.
componentChunks <- function(spline = -50, ties = NULL, overlap = -5,
                            params = -20, post = -1e30, n = 20) {
  m <- cbind(iteration = seq_len(n), chain = 1, posterior = post,
             likelihood_spline = spline, prior_overlap = overlap,
             prior_parameters = params)
  if (!is.null(ties)) m <- cbind(m, likelihood_ties = ties)
  list(m)
}
CollapseMessage <- function(chunks) {
  tryCatch({
    .WarnCollapsedPosterior(chunks, colnames(chunks[[1]]), 1)
    NA_character_
  }, warning = conditionMessage)
}

test_that("a -Inf spline likelihood names the lambda prior (#2417)", {
  msg <- CollapseMessage(componentChunks(spline = -Inf))
  expect_match(msg, "stuck outside the support")
  expect_match(msg, "aLambda", fixed = TRUE)
  expect_no_match(msg, "tie density")
})

test_that("the term out in the most draws is the one named (#2417)", {
  spline <- rep(c(-Inf, -100), 10)
  msg <- CollapseMessage(componentChunks(spline = spline, overlap = -1e30))
  expect_match(msg, "overlapPenalty", fixed = TRUE)
  expect_no_match(msg, "aLambda", fixed = TRUE)
})

test_that("an out-of-support tie names the ties (#2417)", {
  msg <- CollapseMessage(componentChunks(ties = -1e30))
  expect_match(msg, "narrow tie density")
  expect_no_match(msg, "aLambda", fixed = TRUE)
})

test_that("an out-of-support prior names the priors alone (#2417)", {
  # The engine leaves the other terms NA once the prior is out.
  msg <- CollapseMessage(componentChunks(spline = NA, ties = NA, overlap = NA,
                                         params = -1e30))
  expect_match(msg, "outside the support of its prior")
  expect_no_match(msg, "spline likelihood")
  expect_no_match(msg, "tie density")
  expect_no_match(msg, "overlapPenalty", fixed = TRUE)
})

test_that("an unattributed collapse without ties omits them (#2417)", {
  msg <- CollapseMessage(componentChunks())
  expect_no_match(msg, "tie")
  expect_match(msg, "aLambda", fixed = TRUE)
})

test_that("an extreme lambda prior is blamed in a real run (#2417)", {
  skip_on_cran()
  # A sampled sigma: with sigma integrated out the precision is built at the
  # fixed sigmaRef, and this prior no longer breaks the Cholesky factor.
  m <- suppressWarnings(StratModel(stratData1, alignmentScale = "height",
                                   sedModel = "site", aLambda = 1e12,
                                   integrateSigma = FALSE))
  messages <- capture_warnings(
    RunStratModel(stratData1, m, nRun = 1, nIter = 400, nChains = 2,
                  nThreads = 1L, runParallel = FALSE, seed = 3,
                  visualise = FALSE, convergenceStop = FALSE, quiet = TRUE,
                  modelDir = withr::local_tempdir())
  )
  collapse <- grep("outside the support", messages, value = TRUE)
  expect_length(collapse, 1L)
  expect_match(collapse, "aLambda", fixed = TRUE)
  expect_no_match(collapse, "tie density")
  cholesky <- grep("spline coefficients could not be drawn", messages,
                   value = TRUE)
  expect_length(cholesky, 1L)
  expect_match(cholesky, "aLambda", fixed = TRUE)
})

# #2129: modelName and parameter names went into the page unescaped, so a `#`
# or `%` broke the image URL and a `"` broke the attribute.
test_that(".CreateHtmlCode encodes URLs and escapes attributes (#2129)", {
  html <- .CreateHtmlCode(nRun = 1, saveDir = tempdir(),
                          parametersToPlot = "a<b>&'c",
                          allRuns = 1, allSigs = 1, modelName = "run#1%x")
  expect_match(html, "data-src=\"run%231%25x_plot_run_1_sig_1.png\"",
               fixed = TRUE)
  expect_match(html, "alt=\"Plot Parameter a&lt;b&gt;&amp;&#39;c\"",
               fixed = TRUE)
  expect_no_match(html, "run#1", fixed = TRUE)
  expect_no_match(html, "<b>", fixed = TRUE)

  quoted <- .CreateHtmlCode(nRun = 1, saveDir = tempdir(),
                            parametersToPlot = "alpha_\"x\"", allRuns = 1,
                            allSigs = 1, modelName = "m")
  expect_match(quoted, "alt=\"Plot Parameter alpha_&quot;x&quot;\"",
               fixed = TRUE)
  expect_match(quoted, "data-src=\"m_plot_parameter_alpha__x_.png\"",
               fixed = TRUE)
})

test_that("the run-progress page stops polling (#2129)", {
  js <- paste(readLines(system.file("js", "viewRun.js",
                                    package = "StratoBayes")),
              collapse = "\n")
  expect_match(js, "clearInterval(refresher)", fixed = TRUE)
})
