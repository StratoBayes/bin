test_that("a repeated site is a clean argument error (#1296.1)", {
  expect_error(TopsPlot(stratPosterior1, sites = c(1, 1), display = FALSE),
               "same site twice")
  expect_error(.ValidateSites(c("site_1", "site_1"), stratPosterior1[["data"]]),
               "same site twice")
})

test_that("a fractional refHeightsSite is an error (#1296.2)", {
  expect_error(
    TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 2.9,
             display = FALSE),
    "must be a whole number"
  )
})

test_that("supplied `parameters` bypass draw selection (#1296.3)", {
  pars <- as.matrix(ExtractParameters(
    stratPosterior1, parameters = "parameters", maxSamples = 5
  ))
  expect_error(
    Tops(stratPosterior1, refHeights = 1, iterations = 1e9),
    "No iterations could be selected"
  )
  expect_s3_class(
    Tops(stratPosterior1, refHeights = 1, iterations = 1e9, parameters = pars),
    "data.frame"
  )
  expect_s3_class(
    StratMap(stratPosterior1, heights = 1, site = 2, iterations = 1e9,
             parameters = pars),
    "data.frame"
  )
})

test_that("the all-alignments fast path matches .ValidateAlignment() (#1296.5)",
          {
            expect_true(.IsAllAlignment("all"))
            expect_true(.IsAllAlignment("All"))
            expect_true(.IsAllAlignment("none"))
            expect_false(.IsAllAlignment(1))

            # `alignment = "All"` skipped the fast path and clustered for
            # nothing; the result was identical either way, so the observable is
            # that the clustering branch is no longer entered -- assert it via
            # the answer plus the absence of the clustering-only warning path
            expect_equal(
              Tops(stratPosterior1, refHeights = c(1, 2), quantiles = 0.5,
                   alignment = "All"),
              Tops(stratPosterior1, refHeights = c(1, 2), quantiles = 0.5,
                   alignment = "all")
            )
            expect_equal(
              StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                       quantiles = 0.5,
                       alignment = "All"),
              StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                       quantiles = 0.5,
                       alignment = "all")
            )
          })

test_that(paste0("Tops() row order is as documented for each `quantiles` mode ",
                 "(#1296.6)"), {
            refHeights <- c(1, 2, 3)
            numeric <- Tops(stratPosterior1, refHeights = refHeights,
                            quantiles = 0.5)
            samples <- suppressWarnings(
              Tops(stratPosterior1,
                   refHeights = refHeights,
                   quantiles = "samples",
                   maxSamples = 2)
            )

            # numeric: site varies fastest within each refHeight
            expect_identical(numeric[["refHeight"]], rep(refHeights, each = 2))
            # samples: refHeight varies fastest within each site
            expect_identical(samples[["refHeight"]], rep(refHeights, times = 2))
          })

test_that("TopsPlot x-coordinates follow the caller's layout (#1615)", {
  pdf(NULL)
  on.exit(dev.off())
  par(mfrow = c(1, 3))
  spans <- lapply(1:3, function(i) {
    plot.new()
    .PanelNdcX(0)
  })
  for (i in 1:3) {
    expect_gte(spans[[i]][[1]], (i - 1) / 3)
    expect_lte(spans[[i]][[2]], i / 3)
  }
  par(mfrow = c(1, 1))
  plot.new()
  single <- .PanelNdcX(0)
  expect_gt(single[[2]] - single[[1]], 0.5)
  expect_no_error(TopsPlot(stratPosterior1, overridePar = FALSE))
})
