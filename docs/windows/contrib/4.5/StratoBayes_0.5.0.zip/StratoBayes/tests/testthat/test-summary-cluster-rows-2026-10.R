# Rows and arguments summary(), Cluster() and hist() actually use: misspelt
# arguments and an unneeded automatic burn-in (#2499), the R-hat row floor on
# the default path (#2350), and hist()'s mode shares under a supplied
# `stratCluster` with a `runs` subset (#2405).

# `stratPosterior1` tiled to `nRow` saved rows per run, with run 3 stopped
# after `shortRows` of them.
Interrupted2350 <- function(nRow = 4009L, shortRows = 19L) {
  sp <- stratPosterior1
  samples <- .subset2(sp, "samples")
  sp[["samples"]] <- samples[rep_len(seq_len(dim(samples)[[1]]), nRow), , , ,
                             drop = FALSE]
  saveIter <- c(1, 25 * seq_len(nRow - 1L))
  nRun <- sp[["nRun"]]
  sp[["mcmcSummary"]][["saveIter"]] <- rep(list(saveIter), nRun)
  sp[["mcmcSummary"]][["completedIter"]] <- rep(max(saveIter), nRun)
  sp[["mcmcSummary"]][["completedIterIndex"]] <- rep(nRow, nRun)
  sp[["mcmcSummary"]][["saveIter"]][[3]] <- saveIter[seq_len(shortRows)]
  sp[["mcmcSummary"]][["completedIter"]][[3]] <- saveIter[[shortRows]]
  sp[["mcmcSummary"]][["completedIterIndex"]][[3]] <- shortRows
  .WithClusterCache(sp, lazy = TRUE)
}

test_that("Cluster() and summary() flag arguments they do not have (#2499)", {
  expect_warning(Cluster(stratPosterior5a, burnin = 0.9), "burnin")
  expect_warning(Cluster(stratPosterior5a, clusterMehtod = "hdbscan"),
                 "clusterMehtod")
  expect_warning(summary(stratPosterior1, burnin = 0.9), "burnin")
  expect_no_warning(Cluster(stratPosterior5a, burnIn = 0.5))
})

test_that("burnIn = \"auto\" is not resolved when rows are supplied (#2499)", {
  sp <- .WithClusterCache(stratPosterior3, lazy = TRUE)
  local_mocked_bindings(
    .AutoBurnIn = function(...) stop("the automatic burn-in search ran")
  )
  cl <- Cluster(sp, burnIn = "auto", iterations = 1:300)
  expect_identical(cl[["options"]][["burnIn"]], "auto")
  expect_lte(max(unlist(cl[["rowIndex"]])), 61L)

  rows <- lapply(seq_len(sp[["nRun"]]), function(r) 1:40)
  cl <- Cluster(sp, burnIn = "auto", selectRows = rows)
  expect_identical(cl[["options"]][["burnIn"]], "auto")

  sc <- Cluster(sp, burnIn = 0.5)
  expect_no_warning(summary(sp, burnIn = "auto", stratCluster = sc))
  expect_no_warning(summary(sp, burnIn = "auto", iterations = 1:300,
                            alignment = "none"))
})

test_that("burnIn = \"auto\" is still resolved when it decides (#2499)", {
  sp <- .WithClusterCache(stratPosterior3, lazy = TRUE)
  auto <- suppressWarnings(.AutoBurnIn(sp))
  resolved <- suppressWarnings(.ResolveBurnIn(sp, "auto"))
  cl <- suppressWarnings(Cluster(sp, burnIn = "auto"))
  expect_identical(cl[["options"]][["burnIn"]], resolved)
  expect_true(is.list(auto))
})

test_that("summary() and Cluster() keep a short run's R-hat rows (#2350)", {
  sp <- Interrupted2350()
  cl <- Cluster(sp, burnIn = 0.002)
  expect_gte(length(cl[["rowIndex"]][[3]]), .kAutoBurnInMinRows)

  sm <- suppressWarnings(summary(sp, burnIn = 0.002))
  expect_null(attr(sm[[c("general", "psrf")]], "runsOmitted"))
  expect_no_match(capture.output(print(sm)), "R-hat omits run 3")

  ce <- .subset2(sp, ".cache")
  expect_length(ce$clusterCache, 1L)
})

test_that("a lower maxSamples still caps summary()'s clustered rows (#2350)", {
  sp <- Interrupted2350()
  cl <- Cluster(sp, burnIn = 0.002, maxSamples = 500)
  expect_lte(sum(lengths(cl[["rowIndex"]])), 500 + 2 * .kAutoBurnInMinRows)
  expect_gte(length(cl[["rowIndex"]][[3]]), .kAutoBurnInMinRows)
})

test_that("hist() weights modes by the selected runs (#2405)", {
  p <- stratPosterior5a
  sc <- Cluster(p)
  h <- hist(p, runs = 1, stratCluster = sc, display = FALSE, prior = FALSE)
  expect_identical(length(h[[1]][["cluster"]]), nrow(h[[1]][["x"]]))

  restricted <- sc
  keep <- function(l) lapply(seq_along(l), function(r) if (r == 1) l[[r]])
  restricted[["rowIndex"]] <- keep(sc[["rowIndex"]])
  restricted[["clusterList"]] <- keep(sc[["clusterList"]])
  shares <- table(sc[["clusterList"]][[1]]) / length(sc[["clusterList"]][[1]])

  dens <- function(stratCluster) {
    out <- hist(p, runs = 1, stratCluster = stratCluster, display = FALSE,
                colourBy = "alignment")
    out[[1]]
  }
  full <- dens(sc)
  expect_equal(as.vector(table(full[["cluster"]]) / length(full[["cluster"]])),
               as.vector(shares), tolerance = 1e-8)
  expect_equal(full[["cluster"]], dens(restricted)[["cluster"]])
})
