# The C++ engine's per-signal Gibbs step (gibbs_one_signal) on hand-built
# states, through .sb_gibbs_one_signal_probe.

GibbsProbe <- function(H, tBy = seq_len(nrow(H)), D = 0 * H,
                       beta = rep(0, nrow(H)), lambda = 1,
                       Q = diag(nrow(H)),
                       cholLBand = matrix(0, 1L, nrow(H)), cholKd = -1L,
                       structKd = 1L, splineOrder = 4L, aLambda = 1,
                       bLambda = 1, lambdaMin = 1e-10, drawLambda = FALSE,
                       nDraw = 1L, seed = 1) {
  .sb_gibbs_one_signal_probe(H, tBy, D, beta, lambda, Q, cholLBand, cholKd,
                             structKd, splineOrder, aLambda, bLambda,
                             lambdaMin, drawLambda, nDraw, seed)
}

# Lower band storage (kd = 1) of chol(diag(100, 3)): a valid factor of a
# matrix other than the current M
staleFactor <- rbind(rep(10, 3), rep(0, 3))

GrevilleUniform <- function(p, k = 4L) {
  nKnots <- p - k + 2L
  t <- c(rep(0, k - 1L), seq_len(nKnots) - 1, rep(nKnots - 1, k - 1L))
  vapply(seq_len(p), function(i) mean(t[(i + 1L):(i + k - 1L)]), 0)
}

test_that("band failure draws beta from the current M, not a stored factor", {
  # M is positive definite but its kd = 1 band is not, so the band
  # factorisation fails and only a dense one of M itself succeeds
  M <- matrix(0.9, 3, 3)
  diag(M) <- 1
  expect_lt(min(eigen(M * (abs(row(M) - col(M)) <= 1))$values), 0)
  tBy <- c(1, 2, 3)
  nDraw <- 20000L
  res <- GibbsProbe(M, tBy, cholLBand = staleFactor, cholKd = 1L,
                    nDraw = nDraw)
  Minv <- solve(M)
  se <- sqrt(diag(Minv) / nDraw)
  expect_true(all(abs(colMeans(res[["beta"]]) - Minv %*% tBy) < 5 * se))
  expect_equal(cov(res[["beta"]]), Minv, tolerance = 0.05)
  # an exact draw is not a degradation
  expect_identical(res[["nCholFail"]], 0L)
  # and leaves the covariance that backs it
  expect_identical(res[["cholKd"]], -1L)
  expect_equal(res[["Q"]], Minv)
})

test_that("beta is held, and lambda still drawn, when M cannot be factorised", {
  H <- diag(c(1, -1, 1))
  beta0 <- c(0.5, -0.25, 2)
  for (structKd in c(1L, -1L)) {
    res <- GibbsProbe(H, beta = beta0, lambda = 3, Q = diag(0.01, 3),
                      cholLBand = staleFactor,
                      cholKd = if (structKd < 0) -1L else 1L,
                      structKd = structKd, drawLambda = TRUE, nDraw = 5L)
    expect_identical(unname(res[["beta"]]), matrix(beta0, 5, 3, byrow = TRUE))
    # holding lambda too would not be invariant: whether M factorises
    # depends on lambda
    expect_true(all(is.finite(res[["lambda"]])))
    expect_true(all(res[["lambda"]] != 3))
    expect_identical(res[["nCholFail"]], 5L)
    expect_identical(res[["cholKd"]], if (structKd < 0) -1L else 1L)
    expect_identical(res[["cholLBand"]], staleFactor)
    expect_identical(res[["Q"]], diag(0.01, 3))
  }
})

test_that("a non-finite draw leaves the factor or covariance backing beta", {
  M <- matrix(c(2, 1, 0, 1, 2, 1, 0, 1, 2), 3, 3)
  beta0 <- c(1, 2, 3)
  sentinel <- matrix(7, 3, 3)
  banded <- GibbsProbe(M, tBy = c(1, Inf, 1), beta = beta0, Q = sentinel,
                       cholLBand = staleFactor, cholKd = 1L, structKd = 1L)
  expect_identical(banded[["cholKd"]], 1L)
  expect_identical(banded[["cholLBand"]], staleFactor)
  expect_identical(banded[["Q"]], sentinel)
  expect_identical(as.vector(banded[["beta"]]), beta0)
  expect_identical(banded[["nCholFail"]], 1L)

  # a full M is not banded, so this arm draws densely, which writes Q
  full <- matrix(0.9, 3, 3)
  diag(full) <- 1
  dense <- GibbsProbe(full, tBy = c(1, Inf, 1), beta = beta0, Q = sentinel,
                      structKd = -1L)
  expect_identical(dense[["cholKd"]], -1L)
  expect_identical(dense[["Q"]], sentinel)
  expect_identical(as.vector(dense[["beta"]]), beta0)
  expect_identical(dense[["nCholFail"]], 1L)
})

test_that("beta'D beta does not cancel for a large near-linear beta", {
  p <- 20L
  D <- .bsplinepen(seq(0, 1100, length.out = p - 2L))
  xi <- GrevilleUniform(p)
  set.seed(2275)
  r <- rnorm(p)
  beta <- 5e6 + 3e5 * xi + r
  exact <- drop(crossprod(r, D %*% r))
  for (kd in c(3L, -1L)) {
    q <- .sb_penalty_quadform_probe(D, beta, 4L, kd)
    expect_identical(q[["nullBasis"]], 1)
    expect_equal(q[["quadform"]], exact, tolerance = 1e-8)
  }
  # sedSmooth's penalty is the same matrix rescaled
  Dsed <- D * 1100^3
  expect_equal(.sb_penalty_quadform_probe(Dsed, beta, 4L, -1L)[["quadform"]],
               exact * 1100^3, tolerance = 1e-8)
})

test_that("a non-uniform penalty keeps the plain quadratic form", {
  D <- .bsplinepen(c(0, 1, 3, 4, 8, 9, 15))
  beta <- seq_len(nrow(D))
  q <- .sb_penalty_quadform_probe(D, beta, 4L, -1L)
  expect_identical(q[["nullBasis"]], 0)
  expect_equal(q[["quadform"]], drop(crossprod(beta, D %*% beta)))
})

test_that("lambda draw for a large linear beta is a Gamma draw, not a floor", {
  p <- 20L
  D <- .bsplinepen(seq(0, 1100, length.out = p - 2L))
  betaLinear <- 5e6 + 3e5 * GrevilleUniform(p)
  H <- diag(1e20, p)
  res <- GibbsProbe(H, tBy = 1e20 * betaLinear, D = D, beta = betaLinear,
                    lambda = 1e10, structKd = 3L, bLambda = 1e12,
                    lambdaMin = 1, drawLambda = TRUE, nDraw = 20L)
  # rate = 1/bLambda + (beta'D beta = noise only) / 2 ~ 1e-12, shape 10
  expect_true(all(is.finite(res[["lambda"]])))
  expect_true(all(res[["lambda"]] > 1e11))
})

test_that("real spline penalties pass the null-space check", {
  # a check that failed on real models would silently disable the deflation
  for (m in list(stratModel1, stratModel2, stratModel3)) {
    D <- m[[c("splineBase", "D")]]
    expect_identical(.sb_penalty_quadform_probe(
      D, rep(1, nrow(D)), m[[c("splineBase", "splineOrder")]], -1L
    )[["nullBasis"]], 1)
  }
  for (nBasis in c(4L, 12L)) {
    D <- .BuildFormationSpline(-1500, 2.5e4, nBasis, 1L)[["D"]]
    expect_identical(
      .sb_penalty_quadform_probe(D, rep(1, nBasis), 4L, -1L)[["nullBasis"]], 1
    )
  }
})
