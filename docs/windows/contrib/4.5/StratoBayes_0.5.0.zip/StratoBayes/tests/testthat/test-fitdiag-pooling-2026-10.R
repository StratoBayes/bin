test_that("alignment = 'all' counts the modes among the pooled rows (#2406)", {
  skip_if_not_installed("mcmcse")
  supplied <- Cluster(stratPosterior2, burnIn = 0)
  expect_gt(supplied[["nClust"]], 1L)
  own <- FitDiagnostics(stratPosterior2)
  got <- FitDiagnostics(stratPosterior2, stratCluster = supplied)
  expect_lt(own[["general"]][["nAlignments"]], supplied[["nClust"]])
  expect_identical(got[["general"]][["nAlignments"]],
                   own[["general"]][["nAlignments"]])
})

test_that(".FitPooledAlignmentCount() counts labels, not nClust (#2406)", {
  rows <- list(1:4, 1:2)
  local_mocked_bindings(
    ExtractIterations = function(...) rows
  )
  cl <- list(clusterList = list(c(1, 1, 0, 1), c(1, 1)),
             rowIndex = list(1:4, 1:2), nClust = 3L)
  expect_identical(.FitPooledAlignmentCount(NULL, cl, 0, "all"), 1L)
  cl[["clusterList"]][[2]] <- c(2, 3)
  expect_identical(.FitPooledAlignmentCount(NULL, cl, 0, "all"), 3L)
  # a thinned clustering labels only some rows of each run
  cl[["rowIndex"]] <- list(c(1L, 3L), 2L)
  cl[["clusterList"]] <- list(c(1, 0), 2)
  expect_identical(.FitPooledAlignmentCount(NULL, cl, 0, "all"), 2L)
  # a pooled run the clustering never labelled
  cl[["rowIndex"]] <- list(c(1L, 3L), NULL)
  expect_identical(.FitPooledAlignmentCount(NULL, cl, 0, "all"), NA_integer_)
  cl[["rowIndex"]][[2]] <- 5:6
  expect_identical(.FitPooledAlignmentCount(NULL, cl, 0, "all"), NA_integer_)
})

test_that("alignment = 0 earns the unassigned-draws caveat (#2403)", {
  gen <- list(rhatMax = 1.01, multiESS = 500, nDivergent = 0,
              nAlignments = 3, alignment = 0)
  msgs <- .FitGateMessages(gen)
  expect_length(msgs, 1L)
  expect_match(msgs, "unassigned to any alignment")
  expect_false(any(grepl("pooled over", msgs)))
  msgs <- .FitGateMessages(utils::modifyList(gen, list(alignment = c(1, 0))))
  expect_false(any(grepl("pooled over", msgs)))
  expect_true(any(grepl("unassigned", msgs)))
  msgs <- .FitGateMessages(utils::modifyList(gen, list(alignment = c(1, 2, 0))))
  expect_true(any(grepl("pooled over 2", msgs)))
})

test_that("a missing mcmcse is named in the gate message (#2325)", {
  gen <- list(rhatMax = 1.01, multiESS = NA_real_, alignment = "all",
              nAlignments = 1L)
  local_mocked_bindings(.McmcseAvailable = function(...) FALSE)
  expect_match(.FitGateUnknown(gen), "install mcmcse")
  local_mocked_bindings(.McmcseAvailable = function(...) TRUE)
  expect_match(.FitGateUnknown(gen), "could not be computed[.]$")
})
