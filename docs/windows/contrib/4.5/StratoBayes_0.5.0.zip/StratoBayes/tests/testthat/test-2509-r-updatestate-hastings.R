# #2509: the R engine's .UpdateState, pinned at the caller. The proposal
# densities and the accept arithmetic have their own tests
# (test-asymmetric-proposal-hastings.R, test-prior-proposal-hastings.R); these
# pin how .UpdateState composes them and what it stores afterwards.

.Fixture2509 <- function() {
  td <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  data <- StratData(td$signal, parts = td$parts, ties = td$ties,
                    signalColumn = c("a", "b"), zColumn = "Hight",
                    siteColumn = "SIT")
  priors <- structure(
    list(
      alpha_site1 = UniformPrior(10, 60), alpha_site2 = UniformPrior(-10, 60),
      alpha_site3 = UniformPrior(-10, 60), gammaLog_site1 = NormalPrior(1, 1),
      gammaLog_site2 = NormalPrior(1, 1), gammaLog_site3 = NormalPrior(1, 1),
      gap_site2_1 = ExponentialPrior(rate = 0.1)
    ),
    class = c("list", "StratPrior")
  )
  model <- suppressWarnings(
    StratModel(data, priors, alignmentScale = "age", sedModel = "site",
               alphaPosition = "bottom")
  )
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  model[[".tiesDispatch"]] <- .BuildTiesDispatch(data, model)
  mcmc <- StratMCMC(model, nIter = 10, nChains = 1, nThreads = 1L)
  mcmc[["currentIter"]] <- 1L
  state <- .GenerateInitialState(data, model, mcmc, 1)
  list(data = data, model = model, mcmc = mcmc, state = state)
}

.Force2509 <- function(mcmc, name) {
  k <- which(names(mcmc[["propose"]]) == name)
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, k] <- 1
  mcmc[[c("metro", "proposalProbability")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbability")]][1, k] <- 1
  mcmc
}

test_that(".UpdateState stores the post-sweep marginal log posterior (#2509)", {
  set.seed(2509)
  fx <- .Fixture2509()
  state <- fx[["state"]]
  Fresh <- function(s) {
    lp <- sum(.LogPost(fx[["data"]], fx[["model"]], s, marginal = TRUE),
              na.rm = TRUE)
    if (is.finite(lp)) lp else -1e30
  }
  nCalls <- 30L
  stored <- fresh <- numeric(nCalls)
  lambda <- vector("list", nCalls)
  for (i in seq_len(nCalls)) {
    state <- .UpdateState(fx[["data"]], fx[["model"]], fx[["mcmc"]], state, 1)
    stored[i] <- state[[c("metro", "logPost")]]
    fresh[i] <- Fresh(state)
    lambda[[i]] <- state[[c("gibbs", "lambda")]]
  }
  # Non-vacuous: the Gibbs sweep moved what the stored marginal depends on.
  expect_gt(length(unique(lambda)), 1L)
  expect_equal(stored, fresh, tolerance = 1e-10)
})

test_that("a Prior move under a flat likelihood is always accepted (#2509)", {
  # With the likelihood mocked to the prior alone, a Prior draw from g == prior
  # has acceptance ratio exactly 1. A flipped Hastings sign squares the prior
  # instead and rejects most draws from the prior mode.
  set.seed(2509)
  fx <- .Fixture2509()
  FlatLogPost <- function(data, model, state, marginal = FALSE) {
    c(sum(.MetroPriorLog(model, state[[c("metro", "parameters")]])), 0, 0, 0)
  }
  local_mocked_bindings(.LogPost = FlatLogPost)
  mcmc <- .Force2509(fx[["mcmc"]], "Prior")
  state <- fx[["state"]]
  state[[c("metro", "parameters")]][] <- c(35, 25, 25, 1, 1, 1, 0.01)
  state[[c("metro", "logPost")]] <- sum(FlatLogPost(NULL, fx[["model"]], state))

  nSeeds <- 60L
  accepted <- vapply(seq_len(nSeeds), function(seed) {
    set.seed(seed)
    .UpdateState(fx[["data"]], fx[["model"]], mcmc, state, 1)[[
      c("metro", "accept")
    ]]
  }, logical(1))
  expect_true(all(accepted))
})

test_that(".UpdateState passes log q(x|x*) - log q(x*|x) on (#2509)", {
  set.seed(2509)
  fx <- .Fixture2509()
  OriginalAccept <- .AcceptProposal
  OriginalPropose <- .GenerateValidProposal
  seen <- new.env()
  local_mocked_bindings(
    .AcceptProposal = function(logPostOld, logPostNew, temperature,
                               logHastings = 0) {
      seen[["logHastings"]] <- logHastings
      OriginalAccept(logPostOld, logPostNew, temperature, logHastings)
    },
    .GenerateValidProposal = function(...) {
      proposal <- OriginalPropose(...)
      seen[["proposal"]] <- proposal
      proposal
    }
  )
  state <- fx[["state"]]
  model <- fx[["model"]]
  dimFactor <- fx[["mcmc"]][[c("metro", "dimFactor")]]
  LogG <- function(x) sum(.MetroProposalLog(model, x))

  for (propName in c("NeighbourScaled", "Prior")) {
    mcmc <- .Force2509(fx[["mcmc"]], propName)
    k <- which(names(mcmc[["propose"]]) == propName)
    proposeArg <- mcmc[[c("metro", "proposalArgs")]][[1]][[k]]
    proposalFactor <- mcmc[[c("metro", "proposalFactor")]][1, k]
    nChecked <- 0L
    for (seed in seq_len(8L)) {
      set.seed(seed)
      rm(list = ls(seen), envir = seen)
      .UpdateState(fx[["data"]], model, mcmc, state, 1)
      if (is.null(seen[["proposal"]])) next
      x <- state[[c("metro", "parameters")]]
      xStar <- seen[["proposal"]][[c("metro", "parameters")]]
      expected <- if (propName == "Prior") {
        LogG(x) - LogG(xStar)
      } else {
        .ProposalLogDensity(propName, model, xStar, x, proposeArg,
                            proposalFactor, dimFactor) -
          .ProposalLogDensity(propName, model, x, xStar, proposeArg,
                              proposalFactor, dimFactor)
      }
      expect_false(expected == 0)
      expect_equal(seen[["logHastings"]], expected, tolerance = 1e-12,
                   info = paste(propName, "seed", seed))
      nChecked <- nChecked + 1L
    }
    expect_gt(nChecked, 3L)
  }
})
