# Under residualCorrelation = "ou" the default interval between temperature
# updates is the nominal-span rule's (97), not 5% of the window (#2814). An
# explicit `adaptTemperaturesIntervall` and independent residuals are unchanged.

.Ou2814Model <- function() {
  data("stratData1", package = "StratoBayes", envir = environment())
  suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height", sedModel = "site"),
    alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-5, 12), individualSplineIter = 40,
    residualCorrelation = "ou", corLength = 1.5
  ))
}

.Interval2814 <- function(mcmc) {
  mcmc[[c("temper", "adaptTemperaturesIntervall")]]
}

test_that("under OU the default interval is the nominal span's", {
  ou <- .Ou2814Model()
  nominal <- .DefaultAdaptInterval(.kDefaultAdaptIter - 50)
  expect_equal(nominal, 97)

  mcmc <- StratMCMC(ou, nIter = 1e5, nChains = 8, nThreads = 1L)
  expect_equal(.Interval2814(mcmc), nominal)
  scheduled <- mcmc[[c("temper", "adaptTemperaturesIterations")]]
  expect_equal(scheduled, seq(nominal + 1, mcmc[["endAdapting"]], nominal))
  expect_gt(length(scheduled), 500)
  expect_equal(mcmc[[c("temper", "adaptTemperaturesDecay")]],
               length(scheduled) / 5)
  expect_equal(nrow(mcmc[[c("temper", "temperRatioCapped")]]), nominal)

  # The interval an unbounded segment already uses, and the cap's ceiling is
  # never reached.
  expect_equal(.Interval2814(StratMCMC(ou, nChains = 8, nThreads = 1L)),
               nominal)
  big <- StratMCMC(ou, nIter = 1e7, nChains = 4, nThreads = 1L)
  expect_equal(.Interval2814(big), nominal)
  expect_lt(.Interval2814(big), .kMaxDefaultAdaptInterval)

  # The proposals keep their own 5% cadence.
  expect_equal(mcmc[[c("metro", "adaptProposalInterval")]],
               .DefaultAdaptInterval(.AdaptCadenceSpan(mcmc)))
})

test_that("a window shorter than the nominal span keeps its 5% interval", {
  ou <- .Ou2814Model()
  for (nIter in c(400, 1000, 3900)) {
    mcmc <- StratMCMC(ou, nIter = nIter, nChains = 4, nThreads = 1L)
    expect_equal(.Interval2814(mcmc),
                 .DefaultAdaptInterval(.AdaptCadenceSpan(mcmc)))
  }
})

test_that("independent residuals keep the 5% interval", {
  mcmc <- StratMCMC(stratModel1, nIter = 1e5, nChains = 8, nThreads = 1L)
  expect_equal(.Interval2814(mcmc),
               .DefaultAdaptInterval(.AdaptCadenceSpan(mcmc)))
  expect_equal(.Interval2814(mcmc), 2497)
  expect_length(mcmc[[c("temper", "adaptTemperaturesIterations")]], 20)
})

test_that("an explicit interval is used as given, under OU and without", {
  # The default is never consulted, so the explicit path cannot have changed.
  local_mocked_bindings(
    .DefaultTemperatureInterval = function(...) stop("default consulted")
  )
  for (model in list(.Ou2814Model(), stratModel1)) {
    for (interval in c(20, 97, 100, 2497)) {
      mcmc <- StratMCMC(model, nIter = 1e5, nChains = 8, nThreads = 1L,
                        adaptTemperaturesIntervall = interval)
      expect_identical(.Interval2814(mcmc), interval)
      scheduled <- mcmc[[c("temper", "adaptTemperaturesIterations")]]
      expect_equal(scheduled, seq(max(50, interval + 1, interval), 5e4,
                                  interval))
      expect_equal(mcmc[[c("temper", "adaptTemperaturesDecay")]],
                   length(scheduled) / 5)
    }
  }
})

test_that("the default under OU equals the same interval passed explicitly", {
  ou <- .Ou2814Model()
  set.seed(1)
  default <- StratMCMC(ou, nIter = 1e5, nChains = 8, nThreads = 1L)
  set.seed(1)
  explicit <- StratMCMC(ou, nIter = 1e5, nChains = 8, nThreads = 1L,
                        adaptTemperaturesIntervall = 97)
  expect_identical(default[["temper"]], explicit[["temper"]])
})

test_that("a timer freeze keeps the dense updates scheduled before it", {
  mcmc <- StratMCMC(.Ou2814Model(), nIter = 1e5, nChains = 8, nThreads = 1L)
  scheduled <- mcmc[[c("temper", "adaptTemperaturesIterations")]]

  rebased <- .RebaseAdaptCursors(mcmc, freezeAt = 17500,
                                 adaptProposalInterval = 100)
  expect_equal(rebased[["adaptTempIter"]], scheduled[scheduled <= 17500])
  expect_length(rebased[["adaptTempIter"]], floor((17500 - 98) / 97) + 1)
  expect_true(rebased[["adaptTemp"]])

  # The default cadence's first update is at 2,498, so an early freeze left the
  # ladder untouched; here it needs only to fall after 97.
  early <- .RebaseAdaptCursors(mcmc, freezeAt = 1000,
                               adaptProposalInterval = 100)
  expect_length(early[["adaptTempIter"]], 10)
  expect_true(early[["adaptTemp"]])
  expect_false(.RebaseAdaptCursors(mcmc, freezeAt = 97,
                                   adaptProposalInterval = 100)[["adaptTemp"]])
})

test_that("500 dense updates keep the ladder ordered and below the sigma cap", {
  ou <- .Ou2814Model()
  mcmc <- StratMCMC(ou, nIter = 1e5, nChains = 8, nThreads = 1L)
  top <- mcmc[[c("temper", "temperatures")]][[8]]
  bound <- .SigmaTemperatureBound(ou, 15L)
  expect_lt(top, bound)

  ratios <- mcmc[[c("temper", "temperRatioCapped")]]
  withr::local_seed(2814)
  ordered <- pinned <- logical(0)
  nUpdates <- length(mcmc[[c("temper", "adaptTemperaturesIterations")]])
  for (update in seq_len(nUpdates)) {
    # Each link accepts every swap or none, the most one update can move a rung.
    ratios[] <- matrix(rep(stats::rbinom(ncol(ratios), 1, 0.5),
                           each = nrow(ratios)), nrow(ratios))
    mcmc[[c("temper", "temperRatioCapped")]] <- ratios
    mcmc[["temper"]] <- .UpdateTemperatures(mcmc)
    now <- mcmc[[c("temper", "temperatures")]]
    ordered[[update]] <- !is.unsorted(now, strictly = TRUE)
    pinned[[update]] <- identical(now[c(1, 8)], c(1, top))
  }
  expect_gt(length(ordered), 500)
  expect_true(all(ordered))
  expect_true(all(pinned))
  expect_lt(max(mcmc[[c("temper", "temperatures")]]), bound)
})

test_that("a run under OU adapts on the dense cadence and stays proper", {
  skip_on_cran()
  ou <- .Ou2814Model()
  dir <- withr::local_tempdir()
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = ou, nIter = 4200, nChains = 3,
    nThin = 4, seed = 1, nThreads = 1L, runParallel = FALSE, quiet = TRUE,
    visualise = FALSE, modelDir = dir, modelName = "dense"
  ))
  mcmc <- readRDS(file.path(dir, "dense_mcmc_run_1.rds"))
  expect_equal(.Interval2814(mcmc), 97)
  expect_equal(mcmc[[c("temper", "adaptTemperaturesCount")]],
               length(mcmc[[c("temper", "adaptTemperaturesIterations")]]))
  expect_gt(mcmc[[c("temper", "adaptTemperaturesCount")]], 0)
  temperatures <- mcmc[[c("temper", "temperatures")]]
  expect_false(is.unsorted(temperatures, strictly = TRUE))
  expect_lt(max(temperatures), .SigmaTemperatureBound(ou, 15L))
})
