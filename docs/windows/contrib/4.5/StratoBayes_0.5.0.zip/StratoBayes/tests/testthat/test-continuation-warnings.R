# A continuation that silently runs a different kernel or setting than the
# caller expects must say so (#2711, #2550, #2464), and an interrupted
# multi-run call must be resumable (#2535).

ContinuationFixture <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  list(data = stratData1,
       model = StratModel(stratData1, alignmentScale = "height",
                          sedModel = "site"))
}

QuietRun <- function(...) {
  RunStratModel(..., nThreads = 1L, convergenceStop = FALSE, quiet = TRUE,
                visualise = FALSE, runParallel = FALSE)
}

Warnings <- function(expr) suppressMessages(capture_warnings(expr))

test_that("an inert temperingComponents that turns on says so (#2711)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  w1 <- Warnings(r1 <- QuietRun(fx$data, fx$model, nIter = 40, nChains = 3L,
                                seed = 1, tempering = FALSE,
                                temperingComponents = "signal",
                                modelDir = withr::local_tempdir()))
  expect_match(w1, "no effect", all = FALSE)
  w2 <- Warnings(r2 <- QuietRun(r1, nIter = 20, tempering = TRUE,
                                saveMCMC = TRUE))
  expect_match(w2, "turns tempering on.*\"signal\"", all = FALSE)
  expect_identical(r2[["mcmc"]][[1]][[c("temper", "mask")]], 2L)

  # A partial mask that was already in force stays silent.
  w3 <- Warnings(QuietRun(r2, nIter = 10))
  expect_false(any(grepl("turns tempering on", w3)))
})

test_that("an edited boundary-move rwSd on a continuation warns (#2711)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  model <- suppressWarnings(StratModel(
    stratData1, sedModel = "site, partition", sedSmooth = TRUE, nKnots = 10,
    alignmentScale = "height"
  ))
  model[[c("sedSmoothInfo", "boundaryMove")]] <- list(rwSd = 0.5,
                                                      adapt = FALSE)
  r1 <- suppressWarnings(QuietRun(stratData1, model, nIter = 60, nChains = 2L,
                                  seed = 1, modelDir = withr::local_tempdir()))
  same <- Warnings(QuietRun(r1, nIter = 10))
  expect_false(any(grepl("boundaryMove\\$rwSd", same)))

  r1[["model"]][[c("sedSmoothInfo", "boundaryMove")]] <-
    list(rwSd = 3, adapt = FALSE)
  w <- Warnings(QuietRun(r1, nIter = 20))
  expect_match(w, "boundaryMove\\$rwSd` \\(3\\) differs", all = FALSE)

  # The logical form `?StratModel` documents carries no step to compare.
  model[[c("sedSmoothInfo", "boundaryMove")]] <- TRUE
  r1 <- suppressWarnings(QuietRun(stratData1, model, nIter = 30, nChains = 2L,
                                  seed = 1, modelDir = withr::local_tempdir()))
  expect_no_error(suppressWarnings(QuietRun(r1, nIter = 10)))
})

test_that("unequally thinned runs keep their own nThin (#2711)", {
  f <- StratoBayes:::.ResolveContinuationThin
  runs <- list(list(nThin = 4, thinBase = 1), list(nThin = 1))
  expect_warning(
    res <- f(2, runs, c(800, 800), c("nThin", "nIter")),
    "run 1: 4, run 2: 1.*each run keeps its own"
  )
  expect_false("nThin" %in% res[["providedArgs"]])
})

test_that("turning tempering off warns for a saved heated chain (#2550)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  r1 <- suppressWarnings(QuietRun(fx$data, fx$model, nIter = 40, nChains = 4L,
                                  saveChains = c(1, 4), seed = 1,
                                  modelDir = withr::local_tempdir()))
  w <- Warnings(QuietRun(r1, nIter = 20, tempering = FALSE))
  expect_match(w, "saved chain\\(s\\) 4 ran heated", all = FALSE)
})

test_that("cold-only saved chains switch tempering off silently (#2550)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  r1 <- suppressWarnings(QuietRun(fx$data, fx$model, nIter = 40, nChains = 3L,
                                  seed = 1, modelDir = withr::local_tempdir()))
  w <- Warnings(QuietRun(r1, nIter = 20, tempering = FALSE))
  expect_false(any(grepl("ran heated", w)))
})

test_that("a run stopped inside its window says so, as do heirs (#2464)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  w1 <- Warnings(r1 <- QuietRun(fx$data, fx$model, nIter = 1e5,
                                endAdapting = 9e4, nChains = 1L,
                                tempering = FALSE, timeLimit = 1e-6, seed = 1,
                                modelDir = withr::local_tempdir()))
  stoppedAt <- r1[[c("mcmcSummary", "completedIter")]]
  expect_lt(stoppedAt, 9e4)
  expect_match(w1, "still adapting", all = FALSE)
  expect_warning(summary(r1, burnIn = 0.5),
                 "stopped inside the adaptation window")
  expect_no_warning(summary(r1, burnIn = 0), message = "adaptation window")

  w2 <- Warnings(QuietRun(r1, nIter = 20))
  expect_match(w2, paste0("stopped at iteration ", stoppedAt,
                          ", inside its proposal adaptation window"),
               all = FALSE)
})

test_that(".WarnStoppedInAdaptation spares a run that finished adapting", {
  post <- list(mcmcSummary = list(endAdapting = c(100, 50, 100),
                                  adaptCut = c(FALSE, TRUE, FALSE)))
  expect_no_warning(
    StratoBayes:::.WarnStoppedInAdaptation(post, 1L, 100, 0.5)
  )
  expect_warning(
    StratoBayes:::.WarnStoppedInAdaptation(post, 1:3, c(100, 50, 80), 0.5),
    "Run\\(s\\) 2, 3 stopped"
  )
  expect_no_warning(
    StratoBayes:::.WarnStoppedInAdaptation(post, 1:3, c(100, 50, 80), 0L)
  )
})

test_that("an interrupt just after the window closes is not flagged (#2464)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  Interrupted <- function(at) {
    dir <- withr::local_tempdir()
    withr::with_options(list(StratoBayes.testInterruptAtIter = at), {
      expect_error(QuietRun(fx$data, fx$model, nIter = 200, endAdapting = 100,
                            nChains = 1L, tempering = FALSE, seed = 1,
                            modelDir = dir, modelName = "m"),
                   "simulated interrupt")
    })
    Warnings(RunStratModel(NULL, nIter = 10, modelDir = dir, modelName = "m",
                           nThreads = 1L, visualise = FALSE, quiet = TRUE,
                           runParallel = FALSE))
  }
  expect_false(any(grepl("adaptation window", Interrupted(110))))
  expect_match(Interrupted(90), "stopped at iteration 80, inside", all = FALSE)
})

test_that("an interrupted multi-run call can be continued (#2535)", {
  skip_on_cran()
  fx <- ContinuationFixture()
  dir <- withr::local_tempdir()
  withr::with_options(list(StratoBayes.testInterruptAtIter = 280L), {
    expect_error(QuietRun(fx$data, fx$model, nRun = 2, nIter = 300,
                          nChains = 1L, tempering = FALSE, seed = 1:2,
                          modelDir = dir, modelName = "p"),
                 "simulated interrupt")
  })
  checkpoint <- readRDS(file.path(dir, "p_mcmc_run_1.rds"))[["completedIter"]]
  # Only the session holding the writer marker may touch the directory.
  expect_identical(StratoBayes:::.CheckRequiredFiles(dir, "p")[["nRun"]], 1L)
  expect_true(file.exists(file.path(dir, "p_samples_run_2.txt")))
  expect_message(
    post <- RunStratModel(NULL, nIter = 20, modelDir = dir, modelName = "p",
                          nThreads = 1L, visualise = FALSE, quiet = TRUE,
                          runParallel = FALSE),
    "Run\\(s\\) 2 of 'p' never started"
  )
  expect_equal(post[["nRun"]], 1)
  expect_identical(unname(post[[c("mcmcSummary", "completedIter")]]),
                   checkpoint + 20)
  expect_false(file.exists(file.path(dir, "p_samples_run_2.txt")))
  expect_silent(suppressMessages(
    RunStratModel(NULL, nIter = 5, modelDir = dir, modelName = "p",
                  nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  runParallel = FALSE)
  ))
})

Signal0Fixture <- function() {
  data <- StratData(signal = signalData0)
  priors <- structure(list(
    alpha_site2 = UniformPrior(min = 0.25, max = 18.7),
    gammaLog_site2 = NormalPrior(mean = 0, sd = log(2))
  ), class = c("StratPrior", "list"))
  list(data = data,
       model = StratModel(stratData = data, priors = priors,
                          alignmentScale = "height", sedModel = "site",
                          alphaPosition = "middle", nKnots = 10))
}

test_that("a StratPosterior's own model is not called supplied (#2712)", {
  skip_on_cran()
  fx <- Signal0Fixture()
  r1 <- suppressWarnings(QuietRun(fx$data, fx$model, nIter = 40, nChains = 2L,
                                  seed = 1, modelDir = withr::local_tempdir()))
  r1[["model"]][[c("priors", "metro", "gammaLog_site2")]] <- Fixed(0.3)
  w <- Warnings(QuietRun(r1, nIter = 10))
  expect_match(w, "The model in this StratPosterior differs", all = FALSE)
  expect_false(any(grepl("stratModel", w, fixed = TRUE)))
})

test_that("an inherited adaptTemperaturesMonitor is not reported (#2712)", {
  skip_on_cran()
  fx <- Signal0Fixture()
  r1 <- suppressWarnings(QuietRun(fx$data, fx$model, nIter = 60, nChains = 3L,
                                  seed = 1, adaptTemperaturesMonitor = TRUE,
                                  modelDir = withr::local_tempdir()))
  w <- Warnings(QuietRun(r1, nIter = 20, tempering = FALSE))
  expect_false(any(grepl("adaptTemperaturesMonitor", w)))
})
