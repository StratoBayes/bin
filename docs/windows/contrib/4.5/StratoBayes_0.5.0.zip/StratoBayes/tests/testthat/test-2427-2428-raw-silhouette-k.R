# #2427: k is chosen on the raw silhouette; the outlier strip only labels.
# #2428: clusters smaller than max(2, 1% of n) are relabelled 0.

StretchedGaussian <- function(n, seed, sdRatio = 3) {
  set.seed(seed)
  cbind(rnorm(n, sd = sdRatio), rnorm(n))
}

test_that(".ProtoCluster() does not split a unimodal Gaussian (#2427)", {
  # Each seed split into k = 2 when the strip fed the score.
  for (seed in 2:4) {
    expect_equal(max(.ProtoCluster(StretchedGaussian(450, seed), 12)), 1)
  }
  for (seed in 2:3) {
    expect_equal(max(.ProtoCluster(StretchedGaussian(2500, seed), 12)), 1)
  }
})

test_that(".ProtoClusterFast() does not split a unimodal Gaussian (#2427)", {
  for (seed in c(3, 5, 7)) {
    expect_equal(max(.ProtoClusterFast(StretchedGaussian(450, seed, 2.7), 12,
                                       silCutOff = 0.5,
                                       silOutlierThreshold = TRUE)), 1)
  }
})

test_that("the strip labels draws without changing the chosen k (#2427)", {
  set.seed(4)
  x <- rbind(matrix(rnorm(60 * 2, sd = 0.2), ncol = 2),
             matrix(rnorm(60 * 2, mean = 30, sd = 0.2), ncol = 2),
             cbind(seq(8, 22, length.out = 6), 15))
  kept <- .ProtoCluster(x, 12, silOutlierThreshold = FALSE)
  stripped <- .ProtoCluster(x, 12, silOutlierThreshold = 0.7)
  expect_equal(max(stripped), max(kept))
  expect_true(any(stripped == 0))
  assigned <- stripped != 0
  expect_true(all(tapply(kept[assigned], stripped[assigned],
                         function(k) length(unique(k))) == 1))
})

test_that("small clusters are relabelled 0 (#2428)", {
  set.seed(1)
  x <- rbind(matrix(rnorm(200 * 2), ncol = 2),
             matrix(rnorm(200 * 2, mean = 30), ncol = 2),
             c(-60, 60))
  cl <- .ProtoCluster(x, 12)
  expect_equal(max(cl), 2)
  expect_equal(cl[[401]], 0L)
  expect_setequal(unique(cl), 0:2)

  # A singleton beside a single blob leaves one cluster: k = 1, no 0 label.
  y <- rbind(matrix(rnorm(99 * 2), ncol = 2), c(60, 60))
  expect_identical(.ProtoCluster(y, 12), rep.int(1L, 100))
})

test_that("clusters under 1% of the draws are relabelled 0 (#2428)", {
  FarCluster <- function(m) {
    set.seed(5)
    rbind(matrix(rnorm(400), ncol = 2), matrix(rnorm(400, 30), ncol = 2),
          matrix(rnorm(2 * m, sd = 0.1), ncol = 2) + 60)
  }
  # 403 draws: a cluster needs at least 4.03 of them.
  three <- .ProtoCluster(FarCluster(3), 12)
  expect_equal(max(three), 2)
  expect_true(all(tail(three, 3) == 0))
  five <- .ProtoCluster(FarCluster(5), 12)
  expect_equal(max(five), 3)
  expect_true(all(tail(five, 5) == 3))
})

test_that("a cluster the strip shrinks below the floor is relabelled (#2428)",
          {
            # Size counted before the strip would keep one of these five
            # bridging draws as a cluster of its own.
            labels <- .LabelChosenPartition(c(rep(1L, 95), rep(2L, 5)),
                                            c(rep(0.9, 96), rep(0.1, 4)),
                                            silOutlierThreshold = 0.5,
                                            silOutlierSDFromMean = 3)
            expect_identical(labels, rep.int(1L, 100))
          })

test_that("Cluster() reports one alignment for stratPosterior3 (#2428)", {
  cl <- Cluster(stratPosterior3)
  expect_equal(cl[["nClust"]], 1)
  expect_false(0 %in% cl[["cluster"]])
})

test_that("stratPosterior5a keeps its three alignments (#2427)", {
  expect_equal(Cluster(stratPosterior5a)[["nClust"]], 3)
})
