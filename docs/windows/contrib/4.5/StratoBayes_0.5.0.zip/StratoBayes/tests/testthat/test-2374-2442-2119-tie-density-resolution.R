LocalGlobal <- function(name, value, envir = parent.frame()) {
  assign(name, value, envir = globalenv())
  withr::defer(rm(list = name, envir = globalenv()), envir = envir)
}

TieFixture <- function(ties) {
  e <- new.env()
  utils::data("signalData2", "partsData2", "stratPrior2",
              package = "StratoBayes", envir = e)
  data <- StratData(e$signalData2, parts = e$partsData2, ties = ties,
                    signalColumn = c("a", "b"), zColumn = "height",
                    siteColumn = "site")
  set.seed(2374)
  model <- suppressWarnings(StratModel(
    data, priors = e$stratPrior2, alignmentScale = "age", sedModel = "site",
    alphaPosition = c("top", "middle", "bottom"), flexibleKnots = FALSE,
    knotRange = c(0, 100), sigmaFixed = TRUE
  ))
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  mcmc <- suppressWarnings(StratMCMC(model, nIter = 10, nChains = 1,
                                     tempering = FALSE, nThreads = 1L))
  state <- .GenerateInitialState(data, model, mcmc, 1L)
  list(data = data, model = model, mcmc = mcmc, state = state)
}

TiesTermCpp <- function(fx) {
  model <- fx$model
  model$.tiesDispatch <- .BuildTiesDispatch(fx$data, model)
  callback <- .SafeCallback(.MakeTiesCallback(fx$data, model), "ties")
  engine <- .sb_create_engine(
    data = fx$data, model = .SafeModelCallbacks(model), mcmc = fx$mcmc,
    state = list(fx$state), tiesCallback = callback
  )
  params <- unlist(fx$state$metro$parameters)
  .sb_eval_logpost(engine, 1L, params, debug = TRUE)$logPostSep[[3]]
}

TiesTermR <- function(fx, dispatch = TRUE) {
  model <- fx$model
  if (dispatch) model$.tiesDispatch <- .BuildTiesDispatch(fx$data, model)
  .LogLikTies(fx$data, model, fx$state)
}

ReferenceTiesTerm <- function(fx, densities) {
  ages <- fx$state$age$ties
  sum(vapply(densities, function(d) {
    do.call(d$fn, c(list(ages[[d$site]][[d$tie]]), d$args, log = TRUE))
  }, double(1)))
}

cauchyTies <- data.frame(site = c("site1", "site3"), height = c(0, 20),
                         densityFun = c("dcauchy", "dexp"),
                         arg1 = c(40, 0.05), arg2 = c(2, NA))

test_that("a global density cannot shadow a native tie density (#2374)", {
  skip_on_cran()
  fx <- TieFixture(cauchyTies)
  expected <- ReferenceTiesTerm(fx, list(
    list(fn = stats::dcauchy, site = 1, tie = 1, args = list(40, 2)),
    list(fn = stats::dexp, site = 3, tie = 1, args = list(0.05))
  ))

  LocalGlobal("dcauchy", function(...) stats::dnorm(...))
  expect_equal(TiesTermR(fx), expected)
  expect_equal(TiesTermR(fx, dispatch = FALSE), expected)
  expect_equal(TiesTermCpp(fx), expected)
})

test_that("a global `dt` does not make StratData() refuse a dt tie (#2374)", {
  LocalGlobal("dt", function(a, b) 0)
  ties <- data.frame(site = "a", height = 5, densityFun = "dt", arg1 = 3)
  expect_identical(.CheckTies(ties, "height", "site")[["densityFun"]], "dt")
})

test_that("a custom density may share a name with a package import", {
  LocalGlobal("dist", function(x, mu, log = FALSE) {
    stats::dnorm(x, mu, log = log)
  })
  ties <- data.frame(site = "a", height = 5, densityFun = "dist", arg1 = 3)
  expect_identical(.CheckTies(ties, "height", "site")[["densityFun"]], "dist")
})

test_that("global quantiles do not move tie central ages (#2374)", {
  ties <- data.frame(densityFun = c("dt", "dgamma"), arg1 = c(3, 2),
                     arg2 = c(NA, 1))
  expected <- c(stats::qt(0.5, 3), stats::qgamma(0.5, 2, 1))
  LocalGlobal("qt", function(...) 999)
  LocalGlobal("qgamma", function(...) 777)
  expect_equal(.TieCentralAges(ties), expected)
})

test_that("a custom tie density must take `x` first (#2442)", {
  LocalGlobal("dMuFirst", function(mu = 0, x, sd = 1, log = FALSE) {
    stats::dnorm(x, mu, sd, log = log)
  })
  LocalGlobal("dAge", function(age, mu, log = FALSE) {
    stats::dnorm(age, mu, log = log)
  })
  ties <- data.frame(site = "a", height = 5, densityFun = "dMuFirst",
                     arg1 = 40, arg2 = 0.5)
  expect_error(.CheckTies(ties, "height", "site"),
               "'dMuFirst'.*first argument.*`x`")
  ties$densityFun <- "dAge"
  ties$arg2 <- NA
  expect_error(.CheckTies(ties, "height", "site"),
               "'dAge'.*first argument.*`x`")
})

test_that("a row's unused tie scheme must be empty (#2119)", {
  ties <- data.frame(site = c("a", "a"), height = c(1, 5),
                     mean = c(10, 20), sd = c(1, 1),
                     densityFun = c("dlnorm", NA), arg1 = c(NA, NA),
                     arg2 = c(NA, NA))
  expect_error(.CheckTies(ties, "height", "site"),
               "Row 1 .*'densityFun'")

  ties <- data.frame(site = c("a", "a"), height = c(1, 5),
                     mean = c(7, 20), sd = c(NA, 1),
                     densityFun = c("dnorm", NA), arg1 = c(3, NA),
                     arg2 = c(1, NA))
  expect_error(.CheckTies(ties, "height", "site"), "Row 1 .*'mean'")

  ties <- data.frame(site = c("a", "a"), height = c(1, 5),
                     mean = c(10, 20), sd = c(1, 1),
                     densityFun = c(NA, NA), arg1 = c(NA, NA),
                     arg2 = c(4, NA))
  expect_error(.CheckTies(ties, "height", "site"), "Row 1 .*'arg2'")
})

test_that("dispatch binds arg1 past a density's `...` (#2119)", {
  skip_on_cran()
  LocalGlobal("dDotsRate", function(x, ..., rate = 1, log = FALSE) {
    stats::dexp(x, rate, log = log)
  })
  ties <- cauchyTies
  ties$densityFun[2] <- "dDotsRate"
  fx <- TieFixture(ties)
  dispatch <- .BuildTiesDispatch(fx$data, fx$model)
  expect_identical(names(dispatch$dispatch[[3]][[1]]$args), c("rate", "log"))

  expected <- ReferenceTiesTerm(fx, list(
    list(fn = stats::dcauchy, site = 1, tie = 1, args = list(40, 2)),
    list(fn = stats::dexp, site = 3, tie = 1, args = list(0.05))
  ))
  expect_equal(TiesTermR(fx), expected)
  expect_equal(TiesTermR(fx, dispatch = FALSE), expected)
  expect_equal(TiesTermCpp(fx), expected)
})

test_that("a dgamma tie refuses a `scale` arg3 (#2160)", {
  ties <- data.frame(site = "a", height = 5, densityFun = "dgamma",
                     arg1 = 2, arg2 = 1, arg3 = 1)
  expect_error(.CheckTies(ties, "height", "site"), "'scale' \\(arg3\\)")
  ties$arg3 <- NA
  expect_silent(.CheckTies(ties, "height", "site"))
})

test_that("mean/sd beside one-argument densities, any row (#1532)", {
  for (pos in 1:3) {
    ties <- data.frame(site = "a", height = c(1, 5, 9), mean = NA_real_,
                       sd = NA_real_, densityFun = "dpois", arg1 = 2)
    ties[pos, c("mean", "sd")] <- c(10, 1)
    ties[pos, c("densityFun", "arg1")] <- NA
    checked <- .CheckTies(ties, "height", "site")
    expect_identical(checked$densityFun[[pos]], "dnorm", info = pos)
    expect_equal(checked$arg2[[pos]], 1, info = pos)
  }
})
