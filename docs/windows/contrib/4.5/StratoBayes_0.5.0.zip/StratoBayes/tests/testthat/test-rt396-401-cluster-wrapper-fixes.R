# Regression tests for two independent red-team findings:
#
#   RT-400  `.PamCluster`'s silhouette-outlier removal was a silent no-op
#           whenever the input carried row names.
#   RT-401  `.ProtoCluster` lacked the pam branch's `is.na(thresh)` guard.

# ---------------------------------------------------------------------------
# RT-400: .PamCluster must not depend on whether observations are labelled
# ---------------------------------------------------------------------------

# Two tight clusters plus four diffuse points that pam flags as silhouette
# outliers.  Pre-fix, the labelled and unlabelled runs disagreed on both the
# cluster assignments and the selected k.
.rt400Data <- function(seed = 1) {
  set.seed(seed)
  rbind(matrix(rnorm(8 * 3, 0, 0.4), 8, 3),
        matrix(rnorm(8 * 3, 5, 0.4), 8, 3),
        matrix(rnorm(4 * 3, 0, 6), 4, 3))
}

test_that(paste0(".PamCluster gives the same clustering labelled or ",
                 "unlabelled (RT-400)"), {
            x <- .rt400Data()
            xLabelled <- x
            rownames(xLabelled) <- paste0("obs", seq_len(nrow(x)))

            expect_equal(unname(.PamCluster(x, clustMax = 5)),
                         unname(.PamCluster(xLabelled, clustMax = 5)))
          })

test_that(paste0(".PamCluster's outlier removal still fires with labelled ",
                 "input (RT-400)"), {
            # The tell: with labels, `sum(isOutlier)` was 0 while outliers
            # existed, so no observation was ever assigned to the outlier
            # cluster 0.
            xLabelled <- .rt400Data()
            rownames(xLabelled) <- paste0("obs", seq_len(nrow(xLabelled)))

            expect_true(any(.PamCluster(xLabelled, clustMax = 5) == 0))
          })

test_that(paste0(".PamCluster respects a numeric silOutlierThreshold when ",
                 "labelled (RT-400)"), {
            # A threshold high enough to catch the diffuse points must have an
            # effect regardless of labelling; pre-fix the argument was silently
            # ignored.
            x <- .rt400Data()
            xLabelled <- x
            rownames(xLabelled) <- paste0("obs", seq_len(nrow(x)))

            unlabelled <- .PamCluster(x, clustMax = 5,
                                      silOutlierThreshold = 0.4)
            labelled <- .PamCluster(xLabelled, clustMax = 5,
                                    silOutlierThreshold = 0.4)

            expect_equal(unname(unlabelled), unname(labelled))
            expect_true(any(labelled == 0))
          })

# ---------------------------------------------------------------------------
# RT-401: .ProtoCluster's NA-threshold handling
# ---------------------------------------------------------------------------

test_that("an NA threshold skips outlier removal rather than erroring (RT-401)",
          {
            # `silOutlierThreshold = FALSE` is the live route to `thresh <- NA`
            # on the pam branch, and what `if (!is.na(thresh))` guards. An NA
            # `silOutlierSDFromMean` is now a hard error instead (RT-442).
            x <- .rt400Data()

            expect_no_error(result <- .PamCluster(x, clustMax = 4,
                                                  silOutlierThreshold = FALSE))
            expect_false(any(result == 0))
            expect_false(anyNA(result))
          })

test_that("an NA silOutlierThreshold is a clear usage error (RT-401)", {
  x <- .rt400Data()

  expect_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = NA_real_),
               "must be TRUE, FALSE or a number")
  expect_error(.PamCluster(x, clustMax = 4, silOutlierThreshold = NA_real_),
               "must be TRUE, FALSE or a number")
  expect_error(.ProtoCluster(x, clustMax = 4,
                             silOutlierThreshold = c(0.1, 0.2)),
               "must be a single value")
})
