# The adaptation timer inside RunStratModel(): what it budgets for (#2347) and
# which draws it reads (#1844).

TimerFixture <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  list(data = stratData1,
       model = StratModel(stratData1, alignmentScale = "height",
                          sedModel = "site"))
}

TimerRun <- function(fx, ...) {
  suppressWarnings(RunStratModel(
    fx$data, fx$model, ..., nChains = 1L, nThreads = 1L, tempering = FALSE,
    convergenceStop = FALSE, quiet = TRUE, visualise = FALSE,
    modelDir = withr::local_tempdir(.local_envir = parent.frame())
  ))
}

test_that("sequential runs each budget the timer for the full ESS (#2347)", {
  skip_on_cran()
  seen <- new.env()
  realEss <- StratoBayes:::.AdaptTimerEss
  local_mocked_bindings(.AdaptTimerEss = function(criteria, nRun, ...) {
    seen$nRun <- c(seen$nRun, nRun)
    realEss(criteria, nRun, ...)
  })
  TimerRun(TimerFixture(), nRun = 2, nIter = 60, seed = 1:2,
           runParallel = FALSE)
  expect_identical(seen$nRun, c(1L, 1L))
})

test_that("the timer reads no draw from before startAdapting (#1844)", {
  skip_on_cran()
  seen <- new.env()
  realAppend <- StratoBayes:::.AdaptTimerAppend
  local_mocked_bindings(.AdaptTimerAppend = function(store, ...) {
    store <- realAppend(store, ...)
    seen$first <- min(c(seen$first, unlist(lapply(store$chunks, `[`, , 1L)),
                        store$draws[, 1L], Inf))
    store
  })
  TimerRun(TimerFixture(), nIter = 1000, startAdapting = 200, seed = 1)
  expect_true(is.finite(seen$first))
  expect_gte(seen$first, 200)
})
