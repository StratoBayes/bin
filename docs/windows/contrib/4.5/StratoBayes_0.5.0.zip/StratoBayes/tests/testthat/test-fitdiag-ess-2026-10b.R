# Per-parameter ESS: Fixed() parameters are not judged (#2701), constancy is
# judged on each column's own scale (#2408), and the FitDiagnostics gate's
# threshold and across-block minimum are pinned (#2717 item 7).

Ar1 <- function(n, ar = 0.9, seed = 2408L) {
  withr::with_seed(seed, as.numeric(stats::arima.sim(list(ar = ar), n = n)))
}

RowEss <- function(sp, param, ...) {
  smry <- summary(sp, alignment = "none", ...)
  smry[[setdiff(names(smry), "general")[[1L]]]][["summary"]][param, "ess"]
}

ScaleColumn <- function(sp, param, factor) {
  sp[["samples"]][, param, , ] <- factor * sp[["samples"]][, param, , ]
  sp
}

test_that(".EssFunc() is scale-free (#2408)", {
  x <- Ar1(2000)
  expect_gt(.EssFunc(x), 10)
  for (scale in c(1e-3, 1e-9, 1e-15, 1e9)) {
    expect_equal(.EssFunc(scale * x), .EssFunc(x), info = format(scale))
  }
  # An exactly constant column is still a frozen chain.
  expect_identical(.EssFunc(rep(1e-9, 100)), 1)
  expect_identical(.EssFunc(rep(0, 100)), 1)
  expect_identical(.EssFunc(rep(-3, 100)), 1)
  # Relative jitter at the level of rounding is constancy too.
  expect_identical(.EssFunc(5 * (1 + 1e-12 * x[1:100])), 1)
  # A contaminated series is refused, not given an ESS (RT-422).
  expect_identical(.EssFunc(c(1, NA, 2, 3, 4)), NA_real_)
})

test_that("summary() and FitDiagnostics() keep a small-scale lambda (#2408)", {
  small <- ScaleColumn(stratPosterior1, "lambda_value", 1e-9)
  expect_equal(RowEss(small, "lambda_value"),
               RowEss(stratPosterior1, "lambda_value"))
  expect_gt(RowEss(small, "lambda_value"), 100)

  reference <- FitDiagnostics(stratPosterior1)[["general"]]
  got <- FitDiagnostics(small)[["general"]]
  expect_equal(got[["minESS"]], reference[["minESS"]])
  expect_identical(got[["minESSParam"]], reference[["minESSParam"]])
  expect_false(identical(got[["minESSParam"]], "lambda_value"))
})

test_that("auto burn-in monitors a small-scale column (#2408)", {
  iters <- list(1:600, 1:600)
  draws <- lapply(1:2, function(run) {
    matrix(Ar1(600, ar = 0.5, seed = run), ncol = 1,
           dimnames = list(NULL, "lambda"))
  })
  reference <- .AutoBurnInCore(draws, iters, floorIter = 100)
  expect_identical(reference[["status"]], "ok")
  small <- .AutoBurnInCore(lapply(draws, `*`, 1e-9), iters, floorIter = 100)
  expect_identical(small[["status"]], "ok")
  expect_identical(small[["iteration"]], reference[["iteration"]])
  expect_equal(small[["ess"]], reference[["ess"]])
})

test_that("thinning tau reads a small-scale column (#2408)", {
  x <- Ar1(1000)
  mat <- cbind(iteration = seq_along(x), chain = 1, a = x)
  reference <- .StoreTauDraws(mat, cols = 3L, floorIter = 0)
  expect_true(is.finite(reference))
  mat[, "a"] <- 1e-9 * mat[, "a"]
  expect_equal(.StoreTauDraws(mat, cols = 3L, floorIter = 0), reference)
})

test_that("the adaptation timer prices a small-scale column (#2408)", {
  slow <- Ar1(256, ar = 0.995)
  fast <- withr::with_seed(1L, stats::rnorm(256))
  Predicted <- function(p1) {
    store <- .AdaptTimerCollapse(.AdaptTimerAppend(
      .AdaptTimerStore(1), cbind(1:256, 1, p1, fast, deparse.level = 0),
      cols = 3:4, endAdapting = 256, elapsed = 256
    ))
    .AdaptTimerAssess(store, 200)[["predicted"]]
  }
  reference <- Predicted(slow)
  expect_gt(reference, 500)
  expect_equal(Predicted(1e-9 * slow), reference)
})

test_that("ESS gate skips Fixed() parameters (#2701)", {
  # A shipped posterior with a Fixed() gammaLog_3: the gate named it with ess
  # equal to the number of runs, whatever the free parameters did.
  fit <- FitDiagnostics(stratPosterior3)[["general"]]
  expect_false(identical(fit[["minESSParam"]], "gammaLog_3"))

  # A well-mixed posterior with one parameter made Fixed(): the gate still
  # reports the worst free parameter, as before.
  reference <- FitDiagnostics(stratPosterior1)[["general"]]
  fixedName <- setdiff(stratPosterior1[[c("model", "parametersNames")]],
                       reference[["minESSParam"]])[[1L]]
  sp <- stratPosterior1
  value <- sp[["samples"]][1L, fixedName, 1L, 1L]
  sp[["samples"]][, fixedName, , ] <- value
  sp[[c("model", "priors", "metro", fixedName)]] <- Fixed(value)
  fit <- FitDiagnostics(sp)[["general"]]
  expect_identical(fit[["minESSParam"]], reference[["minESSParam"]])
  expect_equal(fit[["minESS"]], reference[["minESS"]])
  expect_gte(reference[["minESS"]], 100)
  expect_false(any(grepl("effective sample size of only",
                         .FitGateMessages(fit))))
})

test_that("a summary cached before the scale-free rule is not served (#2408)", {
  x <- testthat::with_mocked_bindings(
    .WithClusterCache(stratPosterior1, lazy = TRUE),
    .ClusterCacheVersion = function() 1L,
    .package = "StratoBayes"
  )
  expect_null(.PosteriorCache(x))
})

test_that("Fixed, small-scale and frozen columns differ (#2701, #2408)", {
  # gammaLog_3 is Fixed(); gammaLog_2 is free but on a 1e-9 scale; gap_2_1 is
  # free and has frozen. Only the frozen column is a sampling failure, and it
  # sits after the Fixed() row, so a gate that kept the Fixed() row would name
  # that one on the tie.
  frozen <- stratPosterior3
  frozen[["samples"]][, "gap_2_1", , ] <-
    frozen[["samples"]][1L, "gap_2_1", 1L, 1L]
  sp <- ScaleColumn(frozen, "gammaLog_2", 1e-9)

  fit <- FitDiagnostics(sp)[["general"]]
  expect_identical(fit[["minESSParam"]], "gap_2_1")
  expect_identical(fit[["minESS"]], RowEss(sp, "gap_2_1"))
  expect_true(any(grepl("'gap_2_1' has an effective sample",
                        .FitGateMessages(fit))))

  expect_equal(RowEss(sp, "gammaLog_2"), RowEss(frozen, "gammaLog_2"))
})

test_that("ESS gate threshold and across-block minimum are pinned (#2717)", {
  Block <- function(ess) {
    list(summary = data.frame(ess = ess, row.names = names(ess)))
  }
  blocks <- list(Block(c(a = 60, b = 50)), Block(c(a = 20, c = 70)))
  expect_identical(.FitWorstESS(blocks), list(ess = 20, param = "a"))
  expect_identical(.FitWorstESS(rev(blocks)), list(ess = 20, param = "a"))
  expect_identical(.FitWorstESS(blocks, fixed = "a"),
                   list(ess = 50, param = "b"))

  # Between the gate's threshold and a tenth of it.
  msgs <- .FitGateMessages(list(minESS = 50, minESSParam = "b"))
  expect_true(any(grepl("'b' has an effective sample size of only 50", msgs)))
  expect_false(any(grepl("effective sample size",
                         .FitGateMessages(list(minESS = 100,
                                               minESSParam = "b")))))
})
