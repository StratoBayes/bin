test_that(".NeighbourScaledSDs() gives both members of a pair gap / 8", {
  model <- list(ind = list(alpha = 1:2, gamma = integer(0)))
  parameters <- c(5, 1)
  fallback <- c(0.1, 0.2)
  gap <- 4
  expect_equal(
    .NeighbourScaledSDs(parameters, fallback, model),
    pmax(gap / 8, fallback * 0.01)
  )
})
