# Snapshot baselines (vdiffr SVGs + text snapshots) were generated on Windows.
# Font metrics, graphics-device rendering, and BLAS-dependent numerical values
# cause drift on other platforms, so skip snapshot comparisons there.
#
# A skipped test never reaches `expect_doppelganger()`, so testthat would take
# the file's committed SVGs for orphans and delete them. Announcing them first
# marks them as in use.
skip_if_not_snapshot_os <- function() {
  if (Sys.info()[["sysname"]] %in% c("Darwin", "Linux", "SunOS")) {
    snapshotter <- getOption("testthat.snapshotter")
    if (!is.null(snapshotter)) {
      committed <- list.files(file.path(snapshotter[["snap_dir"]],
                                        snapshotter[["file"]]),
                              pattern = "[.]svg$")
      for (name in committed) {
        testthat::announce_snapshot_file(name, name = name)
      }
    }
  }
  testthat::skip_on_os(c("mac", "linux", "solaris"))
}
