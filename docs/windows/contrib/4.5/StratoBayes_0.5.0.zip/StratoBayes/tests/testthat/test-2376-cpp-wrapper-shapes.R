# #2376: hand-mutated inputs that the C++ wrappers passed on to their impls.
# A bad tie table read out of bounds in the impl, which segfaults even on
# x86-64, so those cases run in a child process: a crash there fails the test
# instead of killing the session. The other items failed with an error thrown
# from the impl frame, which only arm64 turns into a crash, so they pin the
# wrapper's own message.

# `call` is evaluated in a fresh R process with the package and `objects`
# loaded; returns the error message, "no error", or the process's output.
RunInChild <- function(call, objects) {
  rds <- tempfile(fileext = ".rds")
  script <- tempfile(fileext = ".R")
  on.exit(unlink(c(rds, script)), add = TRUE)
  saveRDS(list(call = call, objects = objects), rds)
  # Under devtools::test() the namespace is the source tree, which the child
  # must load too: the installed package may be stale.
  pkgPath <- getNamespaceInfo("StratoBayes", "path")
  load <- if (length(list.files(file.path(pkgPath, "R"), "\\.R$"))) {
    sprintf(
      "pkgload::load_all(%s, compile = FALSE, helpers = FALSE, quiet = TRUE)",
      deparse(pkgPath)
    )
  } else {
    "suppressMessages(library(StratoBayes))"
  }
  writeLines(c(
    paste0(".libPaths(", paste(deparse(.libPaths()), collapse = ""), ")"),
    "options(mc.cores = 2L)",
    load,
    sprintf("x <- readRDS(%s)", deparse(rds)),
    "env <- list2env(x$objects, parent = asNamespace('StratoBayes'))",
    "cat(tryCatch({eval(x$call, env); 'no error'},",
    "             error = function(e) conditionMessage(e)))"
  ), script)
  out <- suppressWarnings(system2(
    file.path(R.home("bin"), "Rscript"), c("--vanilla", shQuote(script)),
    stdout = TRUE, stderr = TRUE, timeout = 300
  ))
  paste(out, collapse = "\n")
}

tiesFixtureCache <- new.env(parent = emptyenv())

TiesEngineFixture <- function() {
  if (is.null(tiesFixtureCache[["fixture"]])) {
    td <- tempfile("ties2376_")
    dir.create(td)
    on.exit(unlink(td, recursive = TRUE))
    result <- RunStratModel(
      stratObject = stratData2, stratModel = stratModel2,
      nIter = 10, nChains = 1, nThreads = 1L, seed = 1,
      quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "t2376",
      engine = "R"
    )
    model <- result[["model"]]
    if (is.null(model[[".logpost_cpp"]])) {
      model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
    }
    mcmc <- readRDS(file.path(td, "t2376_mcmc_run_1.rds"))
    tiesFixtureCache[["fixture"]] <- list(
      data = result[["data"]], model = model, mcmc = mcmc,
      state = mcmc[["recentState"]],
      params = mcmc[["recentState"]][[1]][[c("metro", "parameters")]]
    )
  }
  tiesFixtureCache[["fixture"]]
}

# Both C++ consumers of the tie tables, on the same mutated data.
ExpectTieRefusal <- function(mutate, pattern) {
  fix <- TiesEngineFixture()
  data <- fix[["data"]]
  data[["tiesAttr"]] <- mutate(data[["tiesAttr"]])
  objects <- c(fix, list(data = data))
  expect_match(
    RunInChild(quote(.sb_age_convert(data, model$ind, params, FALSE)),
               objects),
    pattern
  )
  expect_match(
    RunInChild(quote(.sb_create_engine(data, model, mcmc, state,
                                       tiesCallback = function(p) 0)),
               objects),
    pattern
  )
}

test_that("a short tiesN is refused in the wrapper (#2376)", {
  ExpectTieRefusal(function(ta) {
    ta[["tiesN"]] <- ta[["tiesN"]][1:2]
    ta
  }, "tiesN needs one entry per site \\(3\\)")
})

test_that("a tiesN beyond the tie tables is refused (#2376)", {
  ExpectTieRefusal(function(ta) {
    ta[["tiesN"]][[3]] <- 5e6
    ta
  }, "tiesH must have a row per tie \\(5000000\\)")
})

test_that("a negative tiesN is refused in the wrapper (#2376)", {
  ExpectTieRefusal(function(ta) {
    ta[["tiesN"]][[1]] <- -1
    ta
  }, "tiesN\\[1\\] must be a non-negative whole number")
})

test_that("a tiesPartsB outside the site's partitions is refused (#2376)", {
  ExpectTieRefusal(function(ta) {
    ta[["tiesPartsB"]][1, 1] <- 1e8
    ta
  }, "tiesPartsB\\[1, 1\\] must name a partition of site 1")
})

test_that("a tie table with too few columns is refused (#2376)", {
  ExpectTieRefusal(function(ta) {
    ta[["tiesPartsB"]] <- ta[["tiesPartsB"]][, 1:2, drop = FALSE]
    ta
  }, "tiesPartsB must have a row per tie \\(2\\) and a column per site \\(3\\)")
})

test_that("the engine refuses a tiesActive smaller than the tie tables (#2376)",
          {
            fix <- TiesEngineFixture()
            fix[["model"]][["tiesActive"]] <- matrix(TRUE, 1, 1)
            expect_match(
              RunInChild(quote(.sb_create_engine(data, model, mcmc, state,
                                                 tiesCallback = function(p) 0)),
                         fix),
              "tiesActive must be a matrix with a row per tie \\(2\\)"
            )
          })

test_that("valid tie tables still convert (#2376)", {
  fix <- TiesEngineFixture()
  ages <- .sb_age_convert(fix[["data"]], fix[["model"]][["ind"]],
                          fix[["params"]], FALSE)
  expect_equal(lengths(ages[["ties"]]), c(site1 = 2L, site2 = 0L, site3 = 1L))
  expect_true(all(is.finite(unlist(ages[["ties"]]))))
})

test_that(".sb_age_convert reads the sign fields in its wrapper (#2376)", {
  fix <- TiesEngineFixture()
  for (field in c("ageHeightSign", "depthHeightSign")) {
    ind <- fix[[c("model", "ind")]]
    ind[[field]] <- NULL
    expect_error(.sb_age_convert(fix[["data"]], ind, fix[["params"]]),
                 sprintf("`indices\\$%s` is missing", field))
    ind[[field]] <- "1"
    expect_error(.sb_age_convert(fix[["data"]], ind, fix[["params"]]),
                 sprintf("`indices\\$%s` must be 1 or -1", field))
    params <- matrix(fix[["params"]], 1)
    expect_error(.sb_age_convert_batch(fix[["data"]], ind, params, 1:3, 2L),
                 sprintf("`indices\\$%s` must be 1 or -1", field))
  }
})

test_that(".sb_age_convert checks partition tables in its wrapper (#2376)", {
  data <- stratData3
  model <- StratModel(stratData = data, alignmentScale = "height",
                      sedModel = "partition", nKnots = 4,
                      residualCorrelation = "none")
  params <- rep(0.5, length(model[[c("ind", "names")]]))
  expect_type(.sb_age_convert(data, model[["ind"]], params), "list")
  data[[c("partsAttr", "numericPartsTwo")]] <- NULL
  expect_error(.sb_age_convert(data, model[["ind"]], params),
               "`partsAttr\\$numericPartsTwo` must be numeric")
  data[[c("partsAttr", "numericPartsTwo")]] <- "a"
  expect_error(
    .sb_age_convert_batch(data, model[["ind"]], matrix(params, 1), 1, 2L),
    "`partsAttr\\$numericPartsTwo` must be numeric"
  )
})

test_that("no int-range coercion warning is raised past the wrappers (#2376)",
          {
            withr::local_options(warn = 2)
            fix <- TiesEngineFixture()
            data <- fix[["data"]]
            partsB <- as.matrix(data[[c("tiesAttr", "tiesPartsB")]])
            storage.mode(partsB) <- "double"
            partsB[2, 2] <- 3e9  # site 2 has no ties, so the cell is unread
            data[[c("tiesAttr", "tiesPartsB")]] <- partsB
            expect_type(.sb_age_convert(data, fix[[c("model", "ind")]],
                                        fix[["params"]]), "list")

            data <- stratData3
            model <- StratModel(stratData = data, alignmentScale = "height",
                                sedModel = "partition", nKnots = 4,
                                residualCorrelation = "none")
            params <- rep(0.5, length(model[[c("ind", "names")]]))
            parts <- as.double(data[[c("partsAttr", "numericPartsTwo")]])
            parts[[length(parts)]] <- 3e9  # matched by value, so never found
            data[[c("partsAttr", "numericPartsTwo")]] <- parts
            expect_type(.sb_age_convert(data, model[["ind"]], params), "list")
            expect_true(is.matrix(
              .sb_age_convert_batch(data, model[["ind"]], matrix(params, 1),
                                    1, 2L)
            ))
          })

test_that("an expression-vector prior arg is refused in the wrapper (#2376)", {
  assign("as.list", function(...) stop("masked as.list was called"),
         envir = globalenv())
  on.exit(rm("as.list", envir = globalenv()))
  expect_error(
    .sb_logpost(
      x = 0.5, priorTypes = "", priorArgs = list(expression(1)),
      rCustomFns = list(function(x, log) stats::dnorm(x, log = log)),
      B_list = list(), beta_list = list(), signalValues = list(),
      sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    ),
    "priorArgs..1.. must be a list or a vector"
  )
})

test_that(".sb_spline_design refuses knots splineDesign would read otherwise",
          {
            unsorted <- c(0, 0, 0, 0, 2, 1, 3, 3, 3, 3)
            expect_error(.sb_spline_design(unsorted, 1.5, 4L),
                         "'knots' must be sorted")
            # splineDesign() returns NaN when the inner range is one knot
            expect_error(.sb_spline_design(rep(1, 7), 1, 4L),
                         "no interval of positive width for x.1.")
            for (knots in list(c(0, 1, 2, 2, 2, 2, 3, 4),
                               c(1, 2, 3, 3, 3, 3, 3, 4),
                               c(0, 0, 0, 0, 0, 0, 0, 1),
                               c(0, 0, 0, 0, 1, 2, 3, 3, 3, 3),
                               c(0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2),
                               c(0, 0, 0, 0, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4),
                               c(0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2),
                               c(0, 0, 0, 1, 1, 1, 2, 2, 2))) {
              inner <- knots[c(4, length(knots) - 3)]
              x <- unique(c(seq(inner[[1]], inner[[2]], length.out = 7),
                            knots[knots >= inner[[1]] & knots <= inner[[2]]]))
              expect_equal(.sb_spline_design(knots, x, 4L),
                           splines::splineDesign(knots, x, 4L))
            }
            expect_equal(.sb_spline_design(c(0, 1, 1, 2), c(0.5, 1, 1.5), 1L),
                         splines::splineDesign(c(0, 1, 1, 2), c(0.5, 1, 1.5),
                                               1L))
          })

test_that("tie tables are made matrices by base as.matrix (#2376)", {
  assign("as.matrix", function(x, ...) stop("masked as.matrix was called"),
         envir = globalenv())
  on.exit(rm("as.matrix", envir = globalenv()))
  fix <- TiesEngineFixture()
  expect_type(.sb_age_convert(fix[["data"]], fix[["model"]][["ind"]],
                              fix[["params"]]), "list")
})
