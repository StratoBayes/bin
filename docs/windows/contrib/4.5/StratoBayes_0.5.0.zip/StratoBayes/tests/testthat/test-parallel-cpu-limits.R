# Parallel RunStratModel() on headless / CPU-limited / CRAN machines
# (#2484, #2487, #2492).

test_that("#2484: no browser is opened when not interactive", {
  skip_if_not_installed("future.apply")
  opened <- FALSE
  local_mocked_bindings(interactive = function() FALSE, .package = "base")
  local_mocked_bindings(.BrowseURL = function(...) opened <<- TRUE)
  r1 <- RunStratModel(
    stratData0, stratModel = stratModel0, nRun = 2, nIter = 4, nChains = 1,
    visualise = c(1, 1, 1), seed = 1:2, runParallel = TRUE, nCores = 2L,
    nThreads = 1L, quiet = TRUE
  )
  expect_s3_class(r1, "StratPosterior")
  expect_false(opened)
})

test_that("#2484: .ShouldOpenBrowser() requires an interactive session", {
  local_mocked_bindings(interactive = function() FALSE, .package = "base")
  expect_false(.ShouldOpenBrowser())
})

test_that("#2484: a missing xdg-open messages the path instead of erroring", {
  skip_on_os(c("windows", "mac"))
  local_mocked_bindings(system = function(...) 1L, .package = "base")
  expect_message(.BrowseURL("/tmp/x_results.html"), "/tmp/x_results.html",
                 fixed = TRUE)
})

test_that("#2487: a failed plan setup does not leak the plan", {
  skip_if_not_installed("future.apply")
  withr::defer(future::plan(future::sequential))
  future::plan(future::sequential)
  realPlan <- future::plan
  local_mocked_bindings(
    plan = function(...) {
      if (nargs() == 0L) return(realPlan())
      args <- list(...)
      out <- do.call(realPlan, args)
      if (identical(args[[1]], future::multisession)) {
        stop("worker setup failed")
      }
      out
    },
    .package = "future"
  )
  expect_error(
    RunStratModel(
      stratData0, stratModel = stratModel0, nRun = 2, nIter = 2, nChains = 1,
      visualise = FALSE, seed = 1:2, runParallel = TRUE, nCores = 2L,
      nThreads = 1L, quiet = TRUE
    ),
    "worker setup failed"
  )
  expect_true(inherits(realPlan(), "sequential"))
})

test_that("#2492: default concurrency and warning use .AvailableCores()", {
  local_mocked_bindings(.AvailableCores = function() 3L)
  withr::local_options(mc.cores = NULL)
  expect_equal(.RunConcurrency(TRUE, NULL, 10), 3L)
  expect_equal(.RunConcurrency(TRUE, NULL, 2), 2L)
})
