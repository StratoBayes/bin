test_that("ReadLasFiles works with folder path", {
  skip_if_not_installed("SDAR")

  lasFolder <- .LasFolder()

  # Read all LAS files in folder
  result <- suppressMessages(ReadLasFiles(lasFolder))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 3)  # Should have 3 files
  expect_named(result)

  # Check that all elements are data.frames
  expect_true(all(vapply(result, is.data.frame, logical(1))))

  # Check names (should be filenames without extension)
  expectedNames <- c(
    "0500106234_700064597",
    "0500106313_700055550",
    "0500106285_700055767"
  )
  expect_equal(sort(names(result)), sort(expectedNames))
})

test_that("ReadLasFiles works with fileNames parameter", {
  skip_if_not_installed("SDAR")

  lasFolder <- .LasFolder()

  # Read specific files
  fileNames <- c("0500106234_700064597.las", "0500106313_700055550.las")
  result <- suppressMessages(ReadLasFiles(lasFolder, fileNames = fileNames))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 2)
  expect_named(result)

  # Check names
  expectedNames <- c("0500106234_700064597", "0500106313_700055550")
  expect_equal(sort(names(result)), sort(expectedNames))
})

test_that("ReadLasFiles handles fileNames without extension", {
  skip_if_not_installed("SDAR")

  lasFolder <- .LasFolder()

  # Read specific files without .las extension
  fileNames <- c("0500106234_700064597", "0500106313_700055550")
  result <- suppressMessages(ReadLasFiles(lasFolder, fileNames = fileNames))

  # Check structure
  expect_type(result, "list")
  expect_length(result, 2)
  expect_named(result)
})

test_that("ReadLasFiles errors on invalid folder", {
  skip_if_not_installed("SDAR")

  expect_error(ReadLasFiles("nonexistent_folder"), "does not exist")
})

test_that("ReadLasFiles errors on missing files", {
  skip_if_not_installed("SDAR")

  lasFolder <- .LasFolder()

  fileNames <- c("nonexistent_file.las", "0500106234_700064597.las")
  expect_error(ReadLasFiles(lasFolder, fileNames = fileNames), "were not found")
})

test_that(paste0("ReadLasFiles works with a single file (no minimum-count ",
                 "requirement)"), {
            # ReadLasFiles() is a general-purpose file reader; the "at least two
            # sites" rule belongs to StratData(), not here - a single file must
            # succeed so that e.g. c(ReadLasFiles(folderA),
            # ReadLasFiles(folderB)) can combine single-well folders.
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()

            fileNames <- c("0500106234_700064597.las")
            result <- suppressMessages(ReadLasFiles(lasFolder,
                                                    fileNames = fileNames))

            expect_type(result, "list")
            expect_length(result, 1)
            expect_named(result, "0500106234_700064597")
          })

test_that(paste0("ReadLasFiles auto-discovery errors on names colliding after ",
                 "dropping the extension (RT-517)"), {
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()
            tmpFolder <- withr::local_tempdir()

            # `list.files(..., ignore.case = TRUE)` matches both, and both strip
            # down to the same outNames entry -- pre-fix, the fileNames branch's
            # RT-228 duplicate guard (further up in this function) doesn't cover
            # auto-discovery.
            file.copy(file.path(lasFolder, "0500106234_700064597.las"),
                      file.path(tmpFolder, "Well1.las"))
            file.copy(file.path(lasFolder, "0500106313_700055550.las"),
                      file.path(tmpFolder, "Well1.LAS"))

            # Two names differing only in case need a case-sensitive filesystem
            # to coexist at all. Probing beats naming the OSes: Windows folds
            # case, and so does macOS's default APFS, which is why
            # skip_on_os("windows") left this failing on the macOS leg.
            skip_if(length(list.files(tmpFolder)) < 2L,
                    "case-insensitive filesystem")

            expect_error(ReadLasFiles(tmpFolder), "collide")
          })

test_that(paste0("ReadLasFiles errors on duplicate fileNames resolving to the ",
                 "same file"), {
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()

            # With and without extension resolve to the same underlying file
            fileNames <- c("0500106234_700064597", "0500106234_700064597.las")
            expect_error(ReadLasFiles(lasFolder, fileNames = fileNames),
                         "duplicate")
          })

test_that("ReadLasFiles auto-detect works on a folder with only one .las file",
          {
            # Auto-detect (fileNames = NULL) must behave consistently with the
            # explicit path above: a single file is read successfully, not
            # rejected.
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()
            singleFileDir <- withr::local_tempdir()
            file.copy(file.path(lasFolder, "0500106234_700064597.las"),
                      singleFileDir)

            result <- suppressMessages(ReadLasFiles(singleFileDir))
            expect_type(result, "list")
            expect_length(result, 1)
          })

test_that(paste0("ReadLasFiles output from single-well folders can be ",
                 "combined with c()"), {
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()
            dirA <- withr::local_tempdir()
            dirB <- withr::local_tempdir()
            file.copy(file.path(lasFolder, "0500106234_700064597.las"), dirA)
            file.copy(file.path(lasFolder, "0500106313_700055550.las"), dirB)

            combined <- c(
              suppressMessages(ReadLasFiles(dirA)),
              suppressMessages(ReadLasFiles(dirB))
            )

            expect_length(combined, 2)
            expect_named(combined,
                         c("0500106234_700064597", "0500106313_700055550"))
          })

test_that("ReadLasFiles reports NULL-replacement counts (RT-107)", {
  skip_if_not_installed("SDAR")

  lasFolder <- .LasFolder()
  fileNames <- c("0500106234_700064597.las", "0500106313_700055550.las")

  expect_message(
    ReadLasFiles(lasFolder, fileNames = fileNames),
    "NULL value .* replaced with NA"
  )
})

test_that(paste0("ReadLasFiles parses the NULL value correctly when the units ",
                 "token contains a digit (RT-358)"), {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            tmpFolder <- withr::local_tempdir()

            fileNames <- c("0500106234_700064597.las",
                           "0500106313_700055550.las")
            for (fn in fileNames) {
              lines <- readLines(file.path(srcFolder, fn))
              # Give the NULL mnemonic a units token with an embedded digit
              # ("D2"), mirroring a real LAS header field the old regex
              # mis-parsed: it matched the "2" in "D2" as the NULL value instead
              # of the real -999.2500.
              lines[grepl("^NULL\\.",
                          lines)] <- "NULL.D2                -999.2500: "
              writeLines(lines, file.path(tmpFolder, fn))
            }

            result <- suppressMessages(ReadLasFiles(tmpFolder,
                                                    fileNames = fileNames))

            allNumeric <- unlist(lapply(result, function(df) {
              unlist(df[vapply(df, is.numeric, logical(1))])
            }))

            # A mis-parsed NULL value ("2") would leave every -999.25 sentinel
            # intact (nothing would match "2" for replacement); the correctly
            # parsed value (-999.25) replaces every sentinel with NA instead.
            expect_false(
              any(is.finite(allNumeric) & abs(allNumeric - (-999.25)) < 1e-9)
            )
            expect_true(any(is.na(allNumeric)))
          })

test_that(paste0("ReadLasFiles keeps names paired with data when a mid-folder ",
                 "file fails (RT-354)"), {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            src <- sort(list.files(srcFolder, pattern = "\\.las$",
                                   full.names = TRUE))
            tmpFolder <- withr::local_tempdir()

            # Sort order is A_good, B_broken, C_good, D_broken: a failed parse
            # (B) precedes a later successful one (C), which is the condition
            # that triggers the drift.
            expect_true(file.copy(src[[1]], file.path(tmpFolder, "A_good.las")))
            expect_true(file.copy(src[[2]], file.path(tmpFolder, "C_good.las")))
            for (bad in c("B_broken.las", "D_broken.las")) {
              writeLines(c("~VERSION INFORMATION", "not a LAS file"),
                         file.path(tmpFolder, bad))
            }

            warns <- character(0)
            result <- withCallingHandlers(
              suppressMessages(ReadLasFiles(tmpFolder, quiet = TRUE)),
              warning = function(w) {
                warns <<- c(warns, conditionMessage(w))
                invokeRestart("muffleWarning")
              }
            )

            # Ground truth for the two readable files, read without any failure
            # in between.
            truth <- withCallingHandlers(
              suppressMessages(ReadLasFiles(tmpFolder,
                                            fileNames = c("A_good", "C_good"),
                                            quiet = FALSE)),
              warning = function(w) invokeRestart("muffleWarning")
            )

            # `expect_length(result, 2)` alone passes pre-fix -- the deletion
            # loses one element per failure, so the length is right while the
            # labelling is not. Pre-fix this returned names c("A_good",
            # "D_broken"), with D_broken's slot holding C_good's real signal
            # data.
            expect_named(result, c("A_good", "C_good"))
            expect_length(result, 2L)
            expect_equal(result[["A_good"]], truth[["A_good"]])
            expect_equal(result[["C_good"]], truth[["C_good"]])

            # The two unreadable files are also reported once, together, so a
            # dropped site is not lost among per-file warnings.
            expect_true(any(grepl("B_broken.las, D_broken.las", warns,
                                  fixed = TRUE)))
          })

test_that(paste0("ReadLasFiles keeps names paired with data when the first ",
                 "file fails (RT-354)"), {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            src <- sort(list.files(srcFolder, pattern = "\\.las$",
                                   full.names = TRUE))
            tmpFolder <- withr::local_tempdir()

            writeLines(c("~VERSION INFORMATION", "not a LAS file"),
                       file.path(tmpFolder, "A_broken.las"))
            expect_true(file.copy(src[[1]], file.path(tmpFolder, "B_good.las")))
            expect_true(file.copy(src[[2]], file.path(tmpFolder, "C_good.las")))

            result <- withCallingHandlers(
              suppressMessages(ReadLasFiles(tmpFolder, quiet = TRUE)),
              warning = function(w) invokeRestart("muffleWarning")
            )

            # Pre-fix: names c("A_broken", "B_good") over B_good's and C_good's
            # data.
            expect_named(result, c("B_good", "C_good"))
            expect_false(identical(result[["B_good"]], result[["C_good"]]))
          })

test_that(
  paste0("ReadLasFiles does not leak file connections on a malformed ",
         "LAS file (#567)"), {
    skip_if_not_installed("SDAR")

    srcFolder <- .LasFolder()
    src <- sort(list.files(srcFolder, pattern = "\\.las$", full.names = TRUE))
    tmpFolder <- withr::local_tempdir()

    expect_true(file.copy(src[[1]], file.path(tmpFolder, "B_good.las")))
    writeLines(c("~VERSION INFORMATION", "not a LAS file"),
               file.path(tmpFolder, "A_broken.las"))

    connsBefore <- getAllConnections()
    result <- suppressWarnings(suppressMessages(
      ReadLasFiles(tmpFolder, quiet = TRUE)
    ))
    connsAfter <- getAllConnections()

    expect_length(setdiff(connsAfter, connsBefore), 0L)
    expect_named(result, "B_good")
  }
)

test_that(paste0("ReadLasFiles falls back to SDAR's common NULL sentinels ",
                 "when the header line is missing (RT-516)"), {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            tmpFolder <- withr::local_tempdir()
            fn <- "0500106234_700064597.las"

            lines <- readLines(file.path(srcFolder, fn))
            # Drop the `~NULL` header line entirely so .ParseNullValue() returns
            # NA_real_ (no header line to parse at all -- a stronger case than a
            # merely-garbled line, but exercises the same NA_real_ fallback
            # path).
            lines <- lines[!grepl("^NULL\\.", lines)]
            # Inject a second hardcoded sentinel (-9999) into a data row
            # alongside the file's own -999.25 (also one of the fallback
            # candidates) -- the fallback loop must catch both, not just
            # whichever one happens to be listed first.
            hitRow <- grep("^\\s*7094\\.3000\\s", lines)
            expect_length(hitRow, 1L)
            lines[hitRow] <- sub("-999\\.2500", "-9999.0000", lines[hitRow],
                                 fixed = FALSE)
            writeLines(lines, file.path(tmpFolder, fn))

            result <- suppressMessages(ReadLasFiles(tmpFolder, fileNames = fn))
            df <- result[[1L]]

            allNumeric <- unlist(df[vapply(df, is.numeric, logical(1))])
            # Pre-fix: nullVal is NA_real_, .ReplaceNullWithNa() short-circuits,
            # and both sentinels survive as ordinary finite data.
            expect_false(
              any(is.finite(allNumeric) & abs(allNumeric - (-9999)) < 1e-6)
            )
            expect_false(
              any(is.finite(allNumeric) & abs(allNumeric - (-999.25)) < 1e-6)
            )
          })

test_that(paste0("ReadLasFiles treats a NULL return from SDAR::read.LAS() as ",
                 "a failed file, not a silent drop (RT-516)"), {
            skip_if_not_installed("SDAR")

            lasFolder <- .LasFolder()
            files <- sort(list.files(lasFolder, pattern = "\\.las$",
                                     full.names = TRUE))
            nullTarget <- basename(files[[2L]])

            # Stub only the targeted file as returning NULL; delegate everything
            # else to the real SDAR::read.LAS() so the other files still read
            # normally.
            origReadLas <- SDAR::read.LAS
            testthat::local_mocked_bindings(
              read.LAS = function(f, ...) {
                if (basename(f) == nullTarget) return(NULL)
                origReadLas(f, ...)
              },
              .package = "SDAR"
            )

            # Pre-fix: `inherits(res, "error")` is FALSE for a NULL `res`, so
            # `failed[i]` never gets set and the file silently vanishes with no
            # warning at all.
            expect_warning(
              result <- suppressMessages(ReadLasFiles(lasFolder, quiet = TRUE)),
              "returned NULL"
            )
            expect_length(result, 2L)
            expect_false(sub("\\.[Ll][Aa][Ss]$", "",
                             nullTarget) %in% names(result))
          })

test_that(paste0("StratData() keeps site names paired with LAS data through ",
                 "its default folder-ingestion path (RT-354)"), {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            src <- sort(list.files(srcFolder, pattern = "\\.las$",
                                   full.names = TRUE))
            tmpFolder <- withr::local_tempdir()

            expect_true(file.copy(src[[1]], file.path(tmpFolder, "A_good.las")))
            expect_true(file.copy(src[[2]], file.path(tmpFolder, "C_good.las")))
            for (bad in c("B_broken.las", "D_broken.las")) {
              writeLines(c("~VERSION INFORMATION", "not a LAS file"),
                         file.path(tmpFolder, bad))
            }

            # StratData(signal = <folder>) hardcodes ReadLasFiles(..., quiet =
            # TRUE) (R/StratData.R:134), so this exercises the actual reachable
            # path the finding described, not just ReadLasFiles() in isolation.
            data <- suppressWarnings(suppressMessages(
              StratData(tmpFolder, zColumn = "Depth", signalColumn = "GR")
            ))

            expect_equal(sort(data[["sites"]]), c("A_good", "C_good"))
          })


test_that(
  paste0("case-variant fileNames naming one file are rejected on a ",
         "case-folding filesystem (#1237)"), {
    skip_if_not_installed("SDAR")

    srcFolder <- .LasFolder()
    tmpFolder <- withr::local_tempdir()
    file.copy(file.path(srcFolder, "0500106234_700064597.las"),
              file.path(tmpFolder, "Well_A.las"))

    # Only a case-folding filesystem (NTFS, default APFS) resolves both
    # spellings to the same file; elsewhere they are genuinely distinct names.
    skip_if_not(file.exists(file.path(tmpFolder, "well_a.las")),
                "case-sensitive filesystem")

    # Pre-fix `duplicated()` compared the literal paths, so the two spellings
    # read the same well twice as two "sites" with identical signal content.
    expect_error(ReadLasFiles(tmpFolder, fileNames = c("Well_A", "well_a")),
                 "duplicate")

    # Control: genuinely distinct files are still accepted.
    file.copy(file.path(srcFolder, "0500106313_700055550.las"),
              file.path(tmpFolder, "Well_B.las"))
    expect_length(
      suppressMessages(ReadLasFiles(
        tmpFolder,
        fileNames = c("Well_A", "Well_B")
      )), 2L
    )
  }
)

test_that("ReadLasFiles() sorts files independent of collation locale (#1799)",
          {
            skip_if_not_installed("SDAR")

            srcFolder <- .LasFolder()
            tmpFolder <- tempfile()
            dir.create(tmpFolder)
            on.exit(unlink(tmpFolder, recursive = TRUE))

            # Mixed-case names whose default `sort()` order depends on the
            # platform collation locale (confirmed: "Well_A","well_b","Well_C"
            # under en_GB.utf8 vs "Well_A","Well_C","well_b" under
            # LC_COLLATE=C); `sites[[1]]` from this order becomes StratData()'s
            # default reference site, so the order must be reproducible across
            # machines rather than locale-dependent.
            file.copy(file.path(srcFolder, "0500106234_700064597.las"),
                      file.path(tmpFolder, "Well_A.las"))
            file.copy(file.path(srcFolder, "0500106313_700055550.las"),
                      file.path(tmpFolder, "well_b.las"))
            file.copy(file.path(srcFolder, "0500106285_700055767.las"),
                      file.path(tmpFolder, "Well_C.las"))

            result <- suppressMessages(ReadLasFiles(tmpFolder))

            # Byte-order (radix) sort: uppercase letters sort before lowercase
            # in ASCII, so "Well_C" precedes "well_b" regardless of the
            # platform's locale.
            expect_identical(names(result), c("Well_A", "Well_C", "well_b"))
          })
