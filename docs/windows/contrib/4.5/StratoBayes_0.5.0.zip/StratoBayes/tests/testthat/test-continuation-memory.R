# A continuation holds as few posterior-sized copies as it can: workers get
# only their arguments, binary samples are materialised one run at a time, and
# samples files are parsed straight to doubles.

test_that("the parallel worker is a namespace function, not a closure", {
  expect_identical(environment(.RunWorker), asNamespace("StratoBayes"))

  # A closure written in RunStratModel() would ship that whole frame to every
  # worker, posterior-sized locals included.
  FindDispatch <- function(x) {
    if (is.call(x)) {
      here <- if (identical(x[[1L]], quote(future.apply::future_lapply))) {
        list(x)
      }
      c(here, unlist(lapply(as.list(x), FindDispatch), recursive = FALSE))
    }
  }
  dispatch <- FindDispatch(body(RunStratModel))
  expect_length(dispatch, 1L)
  expect_identical(dispatch[[1L]][[3L]], quote(.RunWorker))
  expect_false(any(vapply(as.list(dispatch[[1L]])[-1L],
                          function(arg) is.call(arg) &&
                            identical(arg[[1L]], quote(`function`)),
                          logical(1))))
})

test_that(".ReadSamplesTable() reads what read.table() did", {
  dir <- withr::local_tempdir()
  Write <- function(name, text) {
    path <- file.path(dir, name)
    writeBin(charToRaw(text), path)
    path
  }
  Old <- function(path) {
    tryCatch(suppressWarnings(
      read.table(path, header = TRUE, sep = "\t", stringsAsFactors = FALSE,
                 check.names = FALSE)
    ), error = function(e) FALSE)
  }

  header <- "iteration\tchain\talpha[1]\n"
  same <- list(
    plain = paste0(header, "1\t1\t0.5\n100000\t2\t-1.25e-08\n"),
    crlf = "iteration\tchain\ta\r\n1\t1\t0.5\r\n2\t1\tInf\r\n",
    noFinalNewline = paste0(header, "1\t1\t0.5\n2\t1\t0.7"),
    special = paste0(header, "1\t1\tNA\n2\t1\tNaN\n3\t1\t-Inf\n"),
    blankLine = paste0(header, "1\t1\t0.5\n\n2\t1\t1\n")
  )
  for (case in names(same)) {
    path <- Write(case, same[[case]])
    expect_equal(.ReadSamplesTable(path), Old(path), label = case)
  }
  # Bookkeeping columns stay integer, so labels never read "1e+05".
  read <- .ReadSamplesTable(Write("big", same[["plain"]]))
  expect_type(read[["iteration"]], "integer")
  expect_type(read[["chain"]], "integer")
  expect_type(read[["alpha[1]"]], "double")
  expect_identical(names(read), c("iteration", "chain", "alpha[1]"))

  headerOnly <- .ReadSamplesTable(Write("headerOnly", header))
  expect_s3_class(headerOnly, "data.frame")
  expect_identical(dim(headerOnly), c(0L, 3L))

  expect_false(.ReadSamplesTable(Write("empty", "")))
  expect_false(.ReadSamplesTable(Write("short",
                                       paste0(header, "1\t1\t0.5\n2\t1\n"))))
  expect_false(.ReadSamplesTable(Write("long",
                                       paste0(header, "1\t1\t0.5\t9\n"))))
})

test_that(".SampleStoreMatrix() matches .ParseSampleLines()", {
  path <- withr::local_tempfile()
  lines <- c("iteration\tchain\ta", "1\t1\t0.1", "2\t1\t0.25", "3\t2\tNA")
  writeLines(lines, path)
  expect_identical(.SampleStoreMatrix(path, 3L),
                   .ParseSampleLines(lines[-1L], 3L))

  # A ragged line falls back to the line parser, which drops it.
  ragged <- c(lines, "4\t1")
  writeLines(ragged, path)
  expect_identical(.SampleStoreMatrix(path, 3L),
                   .ParseSampleLines(ragged[-1L], 3L))

  writeLines(lines[1L], path)
  expect_null(.SampleStoreMatrix(path, 3L))
})

test_that(".ThinnedStoreLines() keeps the header and rows on the grid", {
  path <- withr::local_tempfile()
  lines <- c("iteration\tchain\ta", "1\t1\t0.1", "2\t1\t0.2", "3\t1\t0.3",
             "4\t1\t0.4", "5\t1\t0.5")
  writeLines(lines, path)
  # Iteration 1 and every multiple of the stride.
  expect_identical(.ThinnedStoreLines(path, 1, 2), lines[c(1L, 2L, 3L, 5L)])
})

test_that("an unreadable binary-samples RDS stops a continuation intact", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  handle <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20, nChains = 1, nRun = 2, seed = 1:2, quiet = TRUE,
    visualise = FALSE, runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "bad"
  ))
  rds <- file.path(td, paste0("bad_binarysamples_run_", 1:2, ".rds"))
  skip_if_not(all(file.exists(rds)))
  writeLines("not an RDS", rds[[2L]])

  # Today the row recount reads every RDS before any is materialised, so this
  # pins the outcome, not the materialisation loop's ordering.
  for (from in list(NULL, handle)) {
    expect_error(
      RunStratModel(stratObject = from, modelDir = td, modelName = "bad",
                    nIter = 10, quiet = TRUE, visualise = FALSE,
                    nThreads = 1L),
      "bad_binarysamples_run_2\\.rds.*run 2"
    )
    expect_true(all(file.exists(rds)))
  }
})

test_that("the worker's error handler cannot mask the original error", {
  dir <- withr::local_tempdir()
  local_mocked_bindings(.PinBlasThreads = function() NULL,
                        .RestoreBlasThreads = function() NULL)

  # A missing argument the handler needs fails before the handler exists.
  expect_error(.RunWorker(list(run = 1L), seed = FALSE, profile = FALSE),
               "\"modelDir\" is missing")

  # Any other error is recorded under its run number, then propagates as is.
  expect_error(.RunWorker(list(run = 3L), profile = FALSE, modelDir = dir,
                          modelName = "m"),
               "\"seed\" is missing")
  expect_match(readLines(file.path(dir, "m_error_run_3.txt"))[[1L]],
               "^Error in run 3 : argument \"seed\" is missing")
})
