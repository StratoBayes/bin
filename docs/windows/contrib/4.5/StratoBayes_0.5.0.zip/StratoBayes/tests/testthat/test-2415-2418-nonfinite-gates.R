# Gates that certify convergence or end adaptation must fail closed on draws
# they cannot read, rather than dropping the column or erroring.

Ar1Draws <- function(n = 200L, seed = 1L) {
  set.seed(seed)
  stats::arima.sim(list(ar = 0.6), n = n)[seq_len(n)]
}

test_that(".EssFunc() is scale-free where the variance overflows (#2418)", {
  y <- Ar1Draws()
  expect_equal(.EssFunc(1e300 * y), .EssFunc(y), tolerance = 1e-6)
  expect_equal(.EssFunc(rep(c(1e300, -1e300), 4)), .EssFunc(rep(c(1, -1), 4)))
  long <- Ar1Draws(5000L)
  expect_equal(.EssFunc(1e300 * long), .EssFunc(long), tolerance = 1e-6)
  # A slow walk reaches the FFT, whose sums overflow before `var()` does.
  set.seed(6)
  walk <- cumsum(stats::rnorm(5000))
  expect_equal(.EssFunc(1e150 * walk), .EssFunc(walk), tolerance = 1e-6)
})

test_that(".EssFunc() refuses a non-finite draw rather than erroring", {
  expect_identical(.EssFunc(c(Ar1Draws(20L), -Inf)), NA_real_)
  expect_identical(.EssFunc(c(Ar1Draws(20L), NA)), NA_real_)
})

TimerStoreOf <- function(p1, p2 = stats::rnorm(length(p1))) {
  n <- length(p1)
  store <- .AdaptTimerAppend(.AdaptTimerStore(1),
                             cbind(seq_len(n), 1, p1, p2, deparse.level = 0),
                             cols = 3:4, endAdapting = n, elapsed = n)
  .AdaptTimerCollapse(store)
}

test_that("the timer prices a column whose variance overflows (#2418)", {
  set.seed(2)
  p2 <- stats::rnorm(256)
  huge <- .AdaptTimerAssess(TimerStoreOf(1e300 * Ar1Draws(256L), p2),
                            essShare = 100)
  plain <- .AdaptTimerAssess(TimerStoreOf(Ar1Draws(256L), p2),
                             essShare = 100)
  expect_equal(huge[["predicted"]], plain[["predicted"]], tolerance = 1e-6)
})

test_that("a timer column with an infinite draw blocks the freeze (#2415)", {
  set.seed(3)
  p1 <- stats::rnorm(256)
  p1[[250]] <- -Inf
  assessed <- .AdaptTimerAssess(TimerStoreOf(p1), essShare = 10)
  expect_identical(assessed[["predicted"]], NA_real_)
})

OffsetRuns <- function(n = 200L) {
  set.seed(4)
  list(cbind(a = stats::rnorm(n), b = stats::rnorm(n)),
       cbind(a = stats::rnorm(n), b = stats::rnorm(n) + 3))
}

test_that("one -Inf draw no longer hides an unconverged column (#2415)", {
  draws <- OffsetRuns()
  iters <- rep(list(seq_len(200L) * 10), 2)
  criteria <- list(rHat = 1.1, ess = 5)
  drawSet <- list(drawList = draws, iterList = iters, floorIter = 0)
  expect_identical(.ConvergenceAssess(drawSet, criteria)[["status"]],
                   "rHatNotReached")

  draws[[2]][150, "b"] <- -Inf
  drawSet[["drawList"]] <- draws
  res <- .ConvergenceAssess(drawSet, criteria)
  expect_identical(res[["status"]], "nonFiniteDraws")
  expect_identical(res[["parametersDropped"]], "b")
  expect_false(.ConvergenceCriteriaMet(drawSet, criteria))

  core <- .AutoBurnInCore(draws, iters, rHatMax = 1.1)
  expect_identical(core[["status"]], "nonFiniteDraws")
})

test_that("a constant column is still screened out, not damage", {
  set.seed(5)
  draws <- lapply(1:2, function(r) cbind(a = stats::rnorm(200), fixed = 2))
  iters <- rep(list(seq_len(200L) * 10), 2)
  res <- .AutoBurnInCore(draws, iters, rHatMax = 1.1)
  expect_identical(res[["status"]], "ok")
})

test_that("FitDiagnostics reads an unassessable R-hat as unknown (#2415)", {
  smry <- list(general = list(psrf = c(a = 1.001, b = NA_real_)))
  conv <- .FitConvergenceSummary(smry)
  expect_identical(conv[["rhatMax"]], NA_real_)
  expect_match(.FitGateUnknown(conv), "Convergence could not be assessed",
               all = FALSE)

  smry <- list(general = list(psrf = c(a = 1.001, b = 1.3)))
  expect_identical(.FitConvergenceSummary(smry)[["rhatMax"]], 1.3)
})

test_that("the adaptation timer's ESS option is validated (#2347)", {
  for (bad in list("400", -5, 0.5, c(100, 200), Inf, NA_real_, TRUE)) {
    withr::local_options(StratoBayes.adaptTimerEss = bad)
    expect_error(.AdaptTimerEss(NULL, 2), "StratoBayes.adaptTimerEss")
  }
  withr::local_options(StratoBayes.adaptTimerEss = 400L)
  expect_identical(.AdaptTimerEss(NULL, 2), 200)
  # An explicit criterion is used instead, so the option is never read.
  expect_identical(.AdaptTimerEss(list(ess = 100), 2, fallback = "400"), 50)
})

test_that("the timer store keeps no draw from before adaptation (#1844)", {
  store <- .AdaptTimerStore(1, startAdapting = 41)
  mat <- cbind(1:100, 1, stats::rnorm(100), stats::rnorm(100))
  store <- .AdaptTimerCollapse(
    .AdaptTimerAppend(store, mat, cols = 3:4, endAdapting = 80, elapsed = 10)
  )
  expect_identical(range(store[["iters"]]), c(41, 80))

  unbounded <- .AdaptTimerCollapse(
    .AdaptTimerAppend(.AdaptTimerStore(1), mat, cols = 3:4, endAdapting = 80,
                      elapsed = 10)
  )
  expect_identical(range(unbounded[["iters"]]), c(1, 80))
})
