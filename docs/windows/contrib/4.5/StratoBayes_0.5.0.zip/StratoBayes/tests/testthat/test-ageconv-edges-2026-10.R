TrailingGapData <- function() {
  signal <- data.frame(site = rep(c("A", "B"), each = 10),
                       height = rep(0:9, 2), value = sin(1:20))
  parts <- data.frame(site = c("A", "A", "B", "B", "B"),
                      height = c(10, 10, 5, 10, 10),
                      partition = c("p1", NA, "p2", "p3", NA))
  StratData(signal, parts = parts)
}

test_that("a trailing gap leaves the top height convertible (#2440)", {
  d <- TrailingGapData()
  heights <- c(0, 9, 9.5, 10)
  for (scale in c("age", "height")) {
    site <- if (scale == "age") 1 else 2
    sedModels <- c("site, partition", "site x partition", "partition", "site")
    ages <- vapply(sedModels, function(sedModel) {
      ind <- .CreateIndices(d, scale, sedModel, "bottom")
      par <- rep(0, length(ind[["names"]]))
      par[ind[["alpha"]]] <- 5
      par[ind[["gap"]]] <- 2
      single <- .AgeConversionGeneral(par, heights, site, stratData = d,
                                      indices = ind)
      batch <- .AgeConversionBatch(rbind(par), heights, site, d, ind)[, 1]
      expect_equal(single, batch)
      single
    }, numeric(length(heights)))
    expect_true(all(is.finite(ages)))
    expect_equal(ages[, "site, partition"], ages[, "site"])
  }

  # exactly one partition claims the top height, or a later one overwrites it
  bind <- .SignalsToBind(heights, d[["partsAttr"]], 1)
  expect_identical(colSums(!is.na(bind)) > 0, c(TRUE, FALSE))
  expect_identical(.HeightsCoveredByPartition(d, 1, heights), rep(TRUE, 4))
})

test_that("prior mapping refuses data missing the alpha anchor (#2361)", {
  shifted <- signalData0
  onSite2 <- shifted[["site"]] == "site2"
  shifted[onSite2, "height"] <- shifted[onSite2, "height"] + 100
  data <- StratData(shifted)
  expect_error(
    StratMap(stratModel0, heights = c(100, 105), site = 2, stratData = data,
             parameters = c(alpha_site2 = 5, gammaLog_site2 = 0)),
    "anchors alpha for site 'site2'"
  )

  # a model mapped onto its own data passes
  expect_no_error(.CheckModelMatchesData(stratModel0[["ind"]], stratData0))
})

test_that("the inverse map chains a gap scan across a flat partition (#2361)", {
  ind <- .CreateIndices(stratData2, "age", "site, partition", "bottom")
  par <- setNames(rep(0, length(ind[["names"]])), ind[["names"]])
  par[ind[["gap"]]] <- 5
  par[["gammaLog_part 2.2_site2"]] <- 800  # rate underflows to zero

  ages <- suppressWarnings(.AgeConversionGeneral(par, c(10.5, 19.5, 31), 2,
                                                 stratData = stratData2,
                                                 indices = ind))
  # partitions 2 and 4 of site 2 are flat, either side of the gap at 20
  expect_equal(ages[[1]], ages[[2]])
  hiatus <- ages[[2]] + c(-1, -2) * sign(ages[[2]] - ages[[3]])
  expect_warning(
    heights <- .CalculateRefHeightToHeights(stratData2, ind, par, 2,
                                            c(hiatus, ages[[3]])),
    "zero inverse sedimentation rate"
  )
  expect_equal(heights[1:2], c(20, 20))
  # the flat partition's single age has no single height
  expect_identical(heights[[3]], NA_real_)
})

test_that("a flat end partition refuses extrapolation past it (#2361)", {
  signal <- data.frame(site = rep(c("A", "B"), each = 16),
                       height = rep(0:15, 2), value = sin(1:32))
  parts <- data.frame(site = c("A", "B", "B", "B"),
                      height = c(15, 5, 10, 15),
                      partition = c("p1", "p2", "p3", "p4"))
  d <- StratData(signal, parts = parts)
  for (scale in c("height", "age")) {
    ind <- .CreateIndices(d, scale, "site, partition", "bottom")
    # 800 underflows the rate to zero; 740 leaves a denormal one
    for (gammaLog in c(800, 740)) {
      par <- setNames(rep(0, length(ind[["names"]])), ind[["names"]])
      par[ind[["alpha"]]] <- 50
      par[["gammaLog_p2_B"]] <- gammaLog
      ages <- range(.AgeConversionGeneral(par, c(0, 15), 2, stratData = d,
                                          indices = ind))
      ref <- c(ages - c(5, -5), ages)
      heights <- suppressWarnings(
        .CalculateRefHeightToHeights(d, ind, par, 2, ref)
      )
      flatEnd <- if (ages[[1]] == 50) 1 else 2
      expect_identical(is.na(heights), seq_along(ref) == flatEnd)
      expect_false(any(is.infinite(heights)))
    }
  }
})

test_that(".sb_age_convert refuses index positions past `parameters` (#2361)", {
  par <- rep(0.5, length(stratModel1[[c("ind", "names")]]))
  for (field in c("rates", "alpha", "gamma")) {
    ind <- stratModel1[["ind"]]
    ind[[field]][1] <- if (field == "rates") 1e8L else 1e6L
    expect_error(.sb_age_convert(stratData1, ind, par),
                 paste0("`indices\\$", field, "` refers to a parameter"))
  }
})

test_that("alphaPosition on the last boundary matches the C++ chain (#2153)", {
  d <- TrailingGapData()
  ind <- .CreateIndices(d, "height", "site, partition", "bottom")
  ind[["alphaPosition"]][[2]] <-
    max(d[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  par <- rep(0, length(ind[["names"]]))
  par[ind[["alpha"]]] <- 0.1
  par[ind[["rates"]]] <- c(0.3, -1.7)
  par[ind[["gap"]]] <- 2  # without it the anchors differ only by rounding
  expect_identical(
    .AgeConversionStratData(d, ind, par, returnAlphas = TRUE)[["alphas"]][[2]],
    .sb_age_convert(d, ind, par, returnAlphas = TRUE)[["alphas"]][[2]]
  )
})

test_that("an infinite inverse rate adds no sediment to alphas (#2153)", {
  ind <- .CreateIndices(stratData2, "age", "site, partition", "bottom")
  par <- setNames(rep(0, length(ind[["names"]])), ind[["names"]])
  par[ind[["gap"]]] <- 5
  par[["gammaLog_part 2.1_site2"]] <- -Inf

  rate <- .GetSedRates(stratData2, ind, .AdjustParams(par, ind), "age",
                       "site, partition", 2)
  expect_identical(rate[[1]], Inf)
  rOut <- .CalculateAlphas(stratData2, ind, .AdjustParams(par, ind), "age",
                           "site, partition", 2, rate)
  expect_true(all(is.finite(rOut)))
  expect_identical(rOut[[2]], rOut[[1]])
  expect_identical(
    .sb_age_convert(stratData2, ind, par, returnAlphas = TRUE)[["alphas"]][[2]],
    rOut
  )
})

test_that("a non-finite BoundLow is compacted away as in the engine (#1927)", {
  ind <- .CreateIndices(stratData2, "age", "site", "bottom")
  ind[["alphaPosition"]][[2]] <- 3
  d <- stratData2
  d[["partsAttr"]][["BoundLow"]][1, 2] <- -Inf
  par <- rep(0, length(ind[["names"]]))
  par[ind[["alpha"]]] <- 7
  # no finite BoundLow lies at or below 3, so alpha sits on the bottom boundary
  rOut <- .AgeConversionStratData(d, ind, par, returnAlphas = TRUE)
  expect_identical(rOut[["alphas"]][[2]][[1]], 7)
  expect_identical(
    .sb_age_convert(d, ind, par, returnAlphas = TRUE)[["alphas"]][[2]],
    rOut[["alphas"]][[2]]
  )
})

test_that("a sedBeta name collision names partition and site labels (#2263)", {
  signal <- data.frame(site = rep(c("r", "x", "y_x"), each = 10),
                       height = rep(0:9, 3), value = sin(1:30))
  parts <- data.frame(site = c("r", "x", "y_x"), height = 10,
                      partition = c("q", "p_y", "p"))
  d <- StratData(signal, parts = parts)
  expect_error(
    suppressWarnings(StratModel(d, alignmentScale = "height",
                                sedModel = "site", sedSmooth = TRUE,
                                nKnots = 5)),
    "partition or site label"
  )
})
