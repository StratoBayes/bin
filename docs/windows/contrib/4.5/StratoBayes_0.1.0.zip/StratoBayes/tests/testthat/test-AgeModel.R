test_that("StratMap() returns expected ages", {
  result <- readRDS(test_path("testdata", "test-clusters",
                              "test-multi-cluster.rds"))

  if (interactive()) {
    dev.new()
    par(mfrow = c(1, 3))
    plot(result, overridePar = FALSE, separateSites = F, alignment = 0)
    plot(result, overridePar = FALSE, separateSites = F, alignment = 1)
    plot(result, overridePar = FALSE, separateSites = F, alignment = 2)

  }
  set.seed(1)
  expect_error(StratMap(result, 30:35, 1, alignment = "all"),
               "first site .*unchanged")
  expect_error(StratMap(result, 30:35, 2, alignment = "all"),
               "extrapolation")


  shift <- 50
  stretch <- 2
  heights <- -((10 * c(5, 1) * (pi / 2) * stretch) + shift)
  allClust <- StratMap(result, heights, 2, alignment = "all")

  clust1 <- StratMap(result, heights, 2, alignment = 1)
  expect_gt(allClust$sd[[1]], clust1[["sd"]][[1]])
  expect_equal(allClust[["height"]], heights)
  expect_equal(clust1[["mean"]], clust1[["50%"]],
               tolerance = max(0.01,
                               abs(clust1[["sd"]] / clust1[["mean"]])[[1]]))

  .TestAligned <- function(alignment, sd_tolerance = 4) {
    clust <- StratMap(result, heights, 2, alignment = alignment)
    expect_equal(
      (clust$mean[1] / -10) %% (2 * pi), # OK to be off by a cycle
      pi / 2,
      tolerance = max(0.1, sd_tolerance * abs((clust$sd[1]) / clust$mean[1]))
    )
  }
  .TestAligned(1)
  # Fails (cycle is narrower in alignment 2)
  # .TestAligned(2)
  # Fails (no alignment 3 found)
  # .TestAligned(3)

  # Single height must survive vapply
  expect_equal(
    StratMap(result, heights = -100, site = "site_2"),
    StratMap(result, heights = c(-100, -100), site = "site_2")[1, ]
  )

  revCluster <- result$stratCluster
  revCluster[["clusterList"]] <- lapply(revCluster[["clusterList"]], function(x) 3 - x)
  clustRev <- StratMap(result, heights, 2, stratCluster = revCluster,
                       alignment = 2)
  expect_equal(clustRev, clust1)
})
