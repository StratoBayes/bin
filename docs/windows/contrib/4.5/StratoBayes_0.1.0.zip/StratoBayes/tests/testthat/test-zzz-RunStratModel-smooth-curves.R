test_that("smooth curves can be aligned", {

  skip_on_cran() # slow
  set.seed(0)


  # Don't use parallel evaluation unless doParallel is installed
  canRunParallel <- requireNamespace("doParallel", quietly = TRUE)

  n1 <- 500
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1)
  n2 <- 250
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)
  if (interactive())  {
    plot(stratD)
  }

  #StratModelTemplate(stratD, "h", "s", "m")
  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1, alignment = 1:2)
  }

  estimates <- summary(r1)

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) - 3/4 * pi) < 0.3), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"], 3/4 * pi, tolerance = 0.1)
  # absolute tolerance
  expect_equal(estimates[[selectAl]]$summary["gammaLog_b","50%"], 0, tolerance = 0.3)




  # sigma estimated
  set.seed(0)
  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = FALSE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      nChains = 12,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }


  estimates <- summary(r1)

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) - 3/4 * pi) < 0.3), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"], 3/4 * pi, tolerance = 0.1)
  # absolute tolerance
  expect_equal(estimates[[selectAl]]$summary["gammaLog_b","50%"], 0, tolerance = 0.3)




  # low n
  n1 <- 30
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1)
  n2 <- 15
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  #StratModelTemplate(stratD, "h", "s", "m")
  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))
  set.seed(0)
  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1, "posterior"))
  }



  estimates <- summary(r1)

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) - 3/4 * pi) < 0.3), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"], 3/4 * pi, tolerance = 0.1)
  # absolute tolerance
  expect_equal(estimates[[selectAl]]$summary["gammaLog_b","50%"], 0, tolerance = 0.3)



  # sigma estimated
  set.seed(0)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = FALSE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)
  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }


  estimates <- summary(r1)

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) - 3/4 * pi) < 0.3), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"],
               3/4 * pi, tolerance = 0.1)
  # absolute tolerance
  expect_equal(estimates[[selectAl]]$summary["gammaLog_b","50%"],
               0, tolerance = 0.3)





  ## non-matching case

  # high n

  n1 <- 500
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1)
  n2 <- 250
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- x2 - sqrt(x2)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)
  plot(stratD)
  #StratModelTemplate(stratD, "h", "s", "m")
  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))
  set.seed(0)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)


  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  estimates <- summary(r1, alignment = 1)

  # relative tolerance:
  expect_equal(estimates$alignment1$summary["alpha_b","50%"],
               3/2 * pi, tolerance = 0.1)

  # sigma estimated
  set.seed(0)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = FALSE)


  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  estimates <- summary(r1, alignment = "all")

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) -  3/2 * pi) < 0.5), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"],
               3/2 * pi, tolerance = 0.2)


  # low n
  n1 <- 30
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1)
  n2 <- 15
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- x2 - sqrt(x2)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)
  plot(stratD)
  #StratModelTemplate(stratD, "h", "s", "m")
  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))
  set.seed(0)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)


  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      nChains = 12,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  estimates <- summary(r1, alignment = "all")

  selectAl <- sample(which(abs(vapply(seq_len(estimates$general$overallAlignments), function(a) estimates[[a]][["summary"]]["alpha_b", "mean"], numeric(1)) -  3/2 * pi) < 0.5), 1)

  # relative tolerance:
  expect_equal(estimates[[selectAl]]$summary["alpha_b","50%"],
               3/2 * pi, tolerance = 0.2)


  # sigma estimated
  set.seed(0)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 10,
                      overlapPenalty = TRUE,
                      sigmaFixed = FALSE)


  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 200,
                      runParallel = canRunParallel,
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))

  }

  estimates <- summary(r1, alignment = "none")

  # relative tolerance:
  expect_equal(estimates$alignmentAll$summary["alpha_b","50%"],
               3/2 * pi, tolerance = 0.5)

})
