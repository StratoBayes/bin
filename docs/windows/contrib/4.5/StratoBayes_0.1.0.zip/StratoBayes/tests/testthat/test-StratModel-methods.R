# Additional tests in test-zzx-StratModel.R

test_that("StratModel() methods work", {
  expect_snapshot(summary(stratModel2))
  expect_snapshot(summary(stratModel3))
})
