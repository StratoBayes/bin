#' @title Run MCMC for StratModel
#'
#' @description `RunStratModelShiny()` runs a Markov chain Monte Carlo (MCMC) simulation to
#' sample from the posteriors of the model parameters. Results are saved in a
#' folder located at a directory specified as `modelDir`.
#'
#' @param stratObject Object of class `"StratData"` for a new model run or
#' `"StratPosterior"` for continuing an existing model run.
#' @param stratModel `StratModel` object created with \code{\link[StratoBayes:StratModel]{StratModel()}}. Will be ignored if a `StratPosterior` object has
#' been provided for `stratObject`.
#' @param stratMCMC `StratMCMC` object created with \code{\link[StratoBayes:StratMCMC]{StratMCMC()}}
#' @param nRun Integer, the number of independent model runs that should be
#' performed. Defaults to \code{1}.
#' @param runParallel Logical or numeric, defaults to \code{FALSE}. If
#' \code{TRUE} or \code{numeric}, the
#' independent model runs will be carried out in parallel. Per default, at least
#' 1 core will not be used. If a numeric value is given, `nRuns` or
#' `runParallel` will be the number of cores that will be used, whichever is
#' smaller. Requires the installation of the `future.apply` package. Note that
#' the progress bar is not working if models are run in parallel, but progress
#' can be tracked via an updating html file if `visualise` is activated.
#' @param nCores Integer specifying the number of cores used for
#' parallel model runs. Defaults to `min(nRun, parallel::detectCores())`.
#' @param seed Logical; or Integer vector of length `nRun` giving seeds for the
#' random number generation in R used in the independent model runs.If
#' `FALSE` (default), no seeds will be set. If `TRUE`, seeds will be set to
#' seq_len(nRun).
#' @param visualise List specifying 1) the interval at which the current state
#' of the MCMC will be plotted, 2) the index or name of the signal to be
#' visualised (can be more than one), and 3) the index or name of a model
#' parameter from `model$outputParams` for which the chain history will be
#' plotted. Set to `FALSE` for no visualisation.
#' @param colourScale A character string that defines the color palette to use
#' for visualisation. This can be any of the palettes given by hcl.pals().
#' Defaults to "Dark 3".
#' @param quiet Logical, determining whether the progress bar should be
#' disabled. Defaults to `FALSE`.
#' @param modelDir Path specifying a directory in which the data, model, samples
#' and mcmc log files will be saved during the model run. Append "\" or "//" to
#' the path to save log files in a new folder named by 'modelName'.
#' If `NULL` (default), files will be saved to a temporary directory and deleted
#' when the R session ends.
#' @param modelName Name used for the model folder and log files.
#' If `NULL` (default), a random string of letters will be used.
#' @param profile Logical, determining whether Rprof profiles of each individual
#' model run will be saved in `modelDir`. Defaults to
#' `FALSE`. Profiles can be investigated using
#' \code{\link[StratoBayes:.SummariseProfiles]{.SummariseProfiles()}}.
#' @template nIter_arg
#' @template nThin_arg
#' @template nChains_arg
#' @inheritParams StratModel
#' @inheritParams StratMCMC
#' @inheritParams StratData
#'
#' @details
#' In addition to samples from the posterior, the `StratPosterior` object
#' created by this function saves the `StratData` and`StratModel`
#' objects to facilitate processing of the results.
#'
#'
#' @return
#' `RunStratModel()` returns a `StratPosterior` object. Convergence of the model
#' run should always be checked visually with
#' \code{\link[StratoBayes:TracePlot]{TracePlot()}} before using the results.
#' Use \code{\link[StratoBayes:summary.StratPosterior]{summary()}} to
#' summarise the model run. Other useful steps include:
#' \describe{
#'     \item{\code{\link[StratoBayes:plot.StratPosterior]{plot()}}}{ visualises
#'     alignments corresponding to posterior samples from the model run.}
#'     \item{\code{\link[StratoBayes:hist.StratPosterior]{hist()}}}{ creates
#'     histograms of posterior samples of parameters from the model run.}
#'     \item{\code{\link[StratoBayes:StratMapPlot]{StratMapPlot()}}}{ visualises
#'    the stratigraphic mapping for specific sites, e.g. age-depth
#'    relationships.}
#'    }
#'
#' The `StratPosterior` object is a list containing the following elements:
#' \describe{
#'     \item{`samples`}{ Posterior samples of the model parameters. `samples` is
#'        a 4-D array where the first dimension represents the saved indices,
#'        the second dimension represents the different saved parameters, the
#'        third dimension represents the runs and the fourth dimension
#'        represents the chains (only  chain1, the untempered chain, is saved by
#'         default).}
#'     \item{`data`}{ `StratData` object used for the model run.}
#'     \item{`model`}{ `StratModel` object used for the model run.}
#'     \item{`mcmcSummary`}{ Saved items from each `StratMCMC` object used for the respective model run.}
#'     \item{`nRun`}{ Number of independent model runs.}
#'     \item{`stratCluster`}{ StratCluster object generated from the posterior
#'     samples.}
#'     \item{`savedParameters`}{ Names of the model parameters and other information saved
#'     from the model run (can be indexed along dimension 2 of `samples`.}
#'    }
#'
#'
#' @examples
#' # Read stratigraphic data
#' data <- StratData(signal = signalData0)
#'
#' # View required priors
#' StratModelTemplate(stratData = data, alignmentScale = "height",
#'   sedModel = "site", alphaPosition = "middle")
#'
#' # Define priors
#' priors <-
#' structure(list(
#'     "alpha_site2" = UniformPrior(min = 0.25, max = 18.7),
#'     "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
#'   class = c("StratPrior", "list"))
#'
#' # Create model
#' model <- StratModel(stratData = data, priors = priors,
#'                     alignmentScale = "height", sedModel = "site",
#'                     alphaPosition = "middle", nKnots = 10)
#'
#' # Conduct brief model run
#' result <- RunStratModel(stratObject = data,
#'                         stratModel = model,
#'                         nRun = 1,
#'                         nIter = 100)
#'
#' # Check for convergence
#' TracePlot(result)
#'
#' # Summary of model run
#' summary(result)
#'
#' # Extend run
#' result <- RunStratModel(stratObject = result,
#'                         stratModel = model,
#'                         nRun = 1,
#'                         nIter = 100)
#'
#' # Display alignment
#' plot(result)
#'
#' # View parameter estimates
#' hist(result)
#' @importFrom abind abind
#' @importFrom stats start
#' @importFrom utils browseURL capture.output read.table Rprof write.table
#' @importFrom fastmatch %fin%
#' @export
RunStratModelShiny <- function(stratObject = NULL,
                          stratModel = NULL,
                          stratMCMC = NULL,
                          nRun = length(seed),
                          runParallel = FALSE,
                          nCores = NULL,
                          seed = FALSE,
                          visualise = list(interval = 100, signal = 1:3,
                                           parameter = 1),
                          colourScale = "Dark 3",
                          quiet = FALSE,
                          modelDir = NULL,
                          modelName = NULL,
                          profile = FALSE,
                          # StratMCMC args
                          nIter = 1000,
                          nThin = 1,
                          nChains = 8,
                          timeLimit = NULL,
                          saveChains = 1,
                          adapt = NULL,
                          # StratModel args
                          priors = NULL,
                          nKnots = 25,
                          alignmentScale = "height",
                          sedModel = NULL,
                          alphaPosition = "middle",
                          overlapPenalty = TRUE,
                          penaltyMultiplier = 1/4,
                          countGaps = FALSE,
                          sigmaFixed = TRUE,
                          individualSplineIter = 2000,
                          flexibleKnots = TRUE,
                          knotRange = NULL,
                          aLambda = 1,
                          bLambda = 1000,
                          aSigma = 0.01,
                          bSigma = 0.01,
                          minSignalOverlap = FALSE,
                          priorsProposals = NULL,
                          disableTies = NULL,
                          ratesRange = c(-14, 14),
                          # StratMCMC args
                          tempering = TRUE,
                          temperatures = NULL,
                          adaptTemperatures = TRUE,
                          adaptTemperaturesIntervall = NULL,
                          adaptTemperaturesDecay = NULL,
                          adaptTemperaturesMonitor = FALSE,
                          adaptProposal = TRUE,
                          startAdapting = NULL,
                          endAdapting = NULL,
                          adaptProposalWindow =  NULL,
                          adaptProposalInterval = NULL,
                          acceptanceHistoryLength = 25,
                          alphaShift = NULL,
                          proposalProbabilityWeights = NULL,
                          scaleMultivariateProposals = TRUE,
                          onlyMultivariateProposalsAfterAdapt = TRUE,
                          clustWithParametersMCMC = TRUE,
                          clustMethodMCMC = "proto",
                          clustMaxMCMC = 12,
                          silCutOffMCMC = 0.5,
                          silOutlierThresholdMCMC = TRUE,
                          clustMinPtsMCMC = 3,
                          parametersInitial = NULL,
                          saveMCMC = FALSE,
                          writeMCMCfile = 0.1,
                          preview_path   = NULL,     # e.g. tempfile(filetext = ".png")
                          preview_width  = 600,
                          preview_height = 600,
                          preview_res    = 120) {

  # Adjust time limit for sequential runs
  if (!runParallel && !is.null(timeLimit)) {
    perRunTimeLimit <- timeLimit / nRun
  } else {
    perRunTimeLimit <- timeLimit
  }

  # legacy names:
  model <- stratModel
  mcmc <- stratMCMC

  if (inherits(stratObject, "StratData")) {
    data <- stratObject
    newRun <- TRUE
  } else if (inherits(stratObject, "StratPosterior")) {
    data <- stratObject[["data"]]
    model <- stratObject[["model"]]
    modelDir <- stratObject[["modelDir"]]
    modelName <- stratObject[["modelName"]]
    nRun <- stratObject[["nRun"]]
    newRun <- FALSE
  } else if (is.null(stratObject)) {
    if (is.null(modelDir)) stop("Please provide a valid stratObject or modelDir.")
    if (is.null(modelName)) stop("Please provide the modelName from the run you wish to continue.")

    # Validate directory
    if (dir.exists(modelDir)) {
      dirInfo <- StratoBayes:::.CheckRequiredFiles(modelDir, modelName, data, model, mcmc)
      data <- readRDS(file.path(modelDir, paste(modelName, "data.rds", sep = "_")))
      if (isTRUE(dirInfo[["readModel"]])) model <- readRDS(file.path(modelDir, paste(modelName, "model.rds", sep = "_")))
      nRun <- dirInfo[["nRun"]]
      newRun <- FALSE
    } else {
      stop("Invalid directory path provided for modelDir: \n'", modelDir, "' \n",
           "Please provide a different file path.")
    }
  } else {
    stop("'StratObject' must be a 'StratData' or 'StratPosterior' object.\n",
         "Alternatively, 'modelDir' and 'modelName' can be specified, pointing to a directory with files from an existing model run.",
         "  See '?RunStratModel' or '?StratData' for help.")
  }

  StratoBayes:::.CheckSeed(seed, nRun)

  StratoBayes:::.CheckStratData(data)

  # Check for provided arguments in RunStratModel that overlap with StratModel
  if (!is.null(stratModel)) {
    stratModelArgs <- c("priors", "nKnots", "alignmentScale", "sedModel",
                        "alphaPosition", "overlapPenalty", "penaltyMultiplier",
                        "countGaps", "sigmaFixed", "individualSplineIter",
                        "flexibleKnots", "knotRange", "aLambda", "bLambda",
                        "aSigma", "bSigma", "minSignalOverlap",
                        "priorsProposals", "disableTies", "ratesRange")

    providedArgs <- names(as.list(match.call())[-1])
    conflictingArgs <- intersect(providedArgs, stratModelArgs)
    if (length(conflictingArgs) > 0) {
      warning(sprintf("The following arguments were provided to RunStratModel but will be overwritten by the StratModel object: %s",
                      paste(conflictingArgs, collapse = ", ")),
              immediate. = TRUE)
    }
  }

  # Check for provided arguments in RunStratModel that overlap with StratMCMC
  # only if it is a new run (some arguments can be used for continued runs)
  if (isTRUE(newRun) && !is.null(mcmc)) {
    stratMCMCArgs <- c("nIter", "nThin", "nChains", "timeLimit", "saveChains",
                       "adapt", "tempering", "temperatures", "adaptTemperatures",
                       "adaptTemperaturesIntervall", "adaptTemperaturesDecay",
                       "adaptTemperaturesMonitor", "adaptProposal",
                       "startAdapting", "endAdapting", "adaptProposalWindow",
                       "adaptProposalInterval", "acceptanceHistoryLength",
                       "alphaShift", "proposalProbabilityWeights",
                       "scaleMultivariateProposals", "onlyMultivariateProposalsAfterAdapt",
                       "clustWithParametersMCMC",
                       "clustMethodMCMC", "clustMaxMCMC", "silCutOffMCMC",
                       "silOutlierThresholdMCMC", "clustMinPtsMCMC",
                       "parametersInitial", "saveMCMC", "writeMCMCfile")

    providedArgs <- names(as.list(match.call())[-1])
    conflictingArgs <- intersect(providedArgs, stratMCMCArgs)
    if (length(conflictingArgs) > 0) {
      warning(sprintf("The following arguments were provided to RunStratModel but will be overwritten by the StratMCMC object: %s",
                      paste(conflictingArgs, collapse = ", ")),
              immediate. = TRUE)
    }
  }

  # if no model was supplied, create it
  if (is.null(model)) {
    # to facilitate consistent model creation,
    # always use the first supplied random seed
    if (seed[[1]] != FALSE && is.numeric(seed)) {
      set.seed(seed[[1]])
    }

    # set to NULL as missing in StratModel fails to detect missing in outer fun
    if (missing(bSigma)) bSigma <- NULL

    model <- StratModel(
      stratData = data,
      penaltyMultiplier = penaltyMultiplier,
      individualSplineIter = individualSplineIter,
      priors = priors,
      nKnots = nKnots,
      knotRange = knotRange,
      alignmentScale = alignmentScale,
      sedModel = sedModel,
      alphaPosition = alphaPosition,
      aLambda = aLambda,
      bLambda = bLambda,
      aSigma = aSigma,
      bSigma = bSigma,
      sigmaFixed = sigmaFixed,
      flexibleKnots = flexibleKnots,
      overlapPenalty = overlapPenalty,
      countGaps = countGaps,
      minSignalOverlap = minSignalOverlap,
      priorsProposals = priorsProposals,
      disableTies = disableTies,
      ratesRange = ratesRange)
  } else {
    if (!(inherits(model, "StratModel"))) {
      stop(
        "`StratModel` must be `NULL`, or an object of class 'StratModel'. ",
        "See '?StratModel' for help."
      )
    }
  }

  # unique model name
  if (is.null(modelName)) {

    # random seed based on time avoids using same names with same provided seed
    set.seed(as.numeric(gsub(
      "[^0-9]", "", format(Sys.time(), "%Y-%m-%d %H:%M:%OS3")
    )) %% .Machine$integer.max)
    modelName <- paste0("StratoBayesModel_",
                        paste(sample(letters, 10, replace = TRUE), collapse = ""),
                        paste(sample(0:9, 2, replace = TRUE), collapse = "")
    )
    # reset to the first supplied random seed
    if (!isFALSE(seed[[1]]) && is.numeric(seed)) {
      set.seed(seed[[1]])
    }
  }

  # create directory to save current files
  if (isTRUE(newRun)) {
    modelDir <- StratoBayes:::.SetModelDir(saveDir = modelDir, modelName = modelName)
  }

  # save RunStratModel options to text file
  StratoBayes:::.CompileArgsToFile(modelDir, modelName, nRun)

  # try to load mcmc object from directory of previous run
  if (!newRun) {
    mcmc <- StratoBayes:::.ReadMCMC(mcmc, modelDir, modelName)

    completedIter <- rep(NA,nRun)

    # if run is continued from R objects rather than from directory
    if (inherits(stratObject, "StratPosterior")) {
      for (run in seq_len(nRun)) {
        samplesFileName <- paste0(modelName, "_samples", "_run_", run, ".txt")
        samplesFilePath <- file.path(modelDir, samplesFileName)

        if (!file.exists(samplesFilePath)) {

          iterations <- mcmc[[run]][["saveIter"]]
          nSavedChains <- dim(stratObject[["samples"]])[4]  # Number of saved chains
          sampleData <- stratObject[["samples"]][, , run, , drop = FALSE]  # Extract all data for this run
          # remove those rows that have been filled with NA by StratPosterior()
          sampleDataNonNA <- sampleData[!is.na(sampleData[ , 1, 1, 1]), , 1, , drop = FALSE]  #
          # get completed iterations
          completedIter[run] <- dim(sampleDataNonNA)[1]
          # Prepare the data frame for writing
          allData <- do.call(rbind, lapply(seq_along(mcmc[[run]][["saveChains"]]), function(chain) {
            # Create a data frame with iterations, chain, and sample data
            data.frame(
              iteration = iterations,
              chain = rep(mcmc[[run]][["saveChains"]][chain], length(iterations)),
              sampleDataNonNA[, , 1, chain]
            )
          }))

          # Write the data to the text file with column names
          write.table(allData, file = samplesFilePath, row.names = FALSE,
                      col.names = TRUE, sep = "\t", quote = FALSE)

        }
      }
    }

    if (any(is.na(completedIter))) { # get actual completed iterations from sample files
      samples <- .CompileSamplesAfterMCMC(modelDir, modelName, model, readPattern = "_samples_run_\\d+\\.txt$")
      iter <- as.numeric(dimnames(samples)[[1]])
      completedIter <- StratoBayes:::.CompleteSampleRows(samples, nRun, iter)

    }
  } else completedIter <- rep(0, nRun)

  if (isTRUE(newRun)) {
    colNames <- c("iteration", "chain", model[["outputParams"]])

    for (run in seq_len(nRun)) {
      samplesFileName <- paste0(modelName, "_samples", "_run_", run, ".txt")
      samplesFilePath <- file.path(modelDir, samplesFileName)
      write.table(t(as.data.frame(colNames)), file = samplesFilePath, row.names = FALSE, col.names = FALSE, sep = "\t", quote = FALSE)
    }
  }
  #}

  visualise <- StratoBayes:::.CheckVisualise(visualise, data, model)

  if (isFALSE(colourScale %fin% hcl.pals())) {
    stop(
      "Invalid colourScale value. ",
      "Please specify one of the palettes shown by hcl.pals(), ",
      "or specify 'sequential_hcl'"
    )
  }

  # if no mcmc object was supplied, create it
  if (is.null(mcmc) | !newRun) {

    if (!newRun) {
      # nThin needs to stay the same otherwise processing functions can get confused
      # if runs don't have the same n of completed iter
      # saveIter = lapply(mcmc, function(x) x[["saveIter"]])
      # saveIterLength <- vapply(saveIter, length, numeric(1))
      #completedIter <- vapply(mcmc, function(x) x[["completedIter"]], numeric(1))
      if (any(diff(completedIter) != 0)) nThin <- mcmc[[1]][["nThin"]]
    }

    # to facilitate consistent mcmc creation,
    # always use the first supplied random seed
    if (seed[[1]] != FALSE && is.numeric(seed)) {
      set.seed(seed[[1]])
    }
    mcmcNew <- lapply(
      seq_len(nRun),
      function(run) {
        if (is.null(mcmc)) {
          mcmcRun <- NULL } else {
            mcmcRun <- mcmc[[run]]
          }
        StratMCMC(
          stratModel = model,
          stratMCMC = mcmcRun,
          nIter = nIter,
          nChains = nChains,
          nThin = nThin,
          timeLimit = timeLimit,
          saveChains = saveChains,
          tempering = tempering,
          temperatures = temperatures,
          adapt = adapt,
          adaptTemperatures = adaptTemperatures,
          adaptTemperaturesIntervall = adaptTemperaturesIntervall,
          adaptTemperaturesDecay = adaptTemperaturesDecay,
          adaptTemperaturesMonitor = adaptTemperaturesMonitor,
          adaptProposal = adaptProposal,
          startAdapting = startAdapting,
          endAdapting = endAdapting,
          adaptProposalWindow =  adaptProposalWindow,
          adaptProposalInterval = adaptProposalInterval,
          acceptanceHistoryLength = acceptanceHistoryLength,
          alphaShift = alphaShift,
          proposalProbabilityWeights = proposalProbabilityWeights,
          scaleMultivariateProposals = scaleMultivariateProposals,
          onlyMultivariateProposalsAfterAdapt = onlyMultivariateProposalsAfterAdapt,
          clustWithParametersMCMC = clustWithParametersMCMC,
          clustMethodMCMC = clustMethodMCMC,
          clustMaxMCMC = clustMaxMCMC,
          silCutOffMCMC = silCutOffMCMC,
          silOutlierThresholdMCMC = silOutlierThresholdMCMC,
          clustMinPtsMCMC = clustMinPtsMCMC,
          parametersInitial = parametersInitial,
          saveMCMC = saveMCMC,
          writeMCMCfile = writeMCMCfile,
          completedIter = completedIter[run]
        )
      }
    )
  } else {
    if (!inherits(mcmc, "StratMCMC")) {
      stop(
        "`stratMCMC` must be `NULL`, or an object of class 'StratMCMC'. ",
        "See '?StratMCMC' for help."
      )
    } else {mcmcNew <- rep(list(mcmc), times = nRun)}
  }

  # pass on chainHistory, proposals, temperatures etc., or assign
  mcmc <- lapply(seq_len(nRun), function(run) {
    StratoBayes:::.UpdateMCMCforContinuedRun(
      mcmc = mcmc[[run]], mcmcNew = mcmcNew[[run]], newRun = newRun)
  })


  # assign name of signal
  # if (all(visualiseSignal %fin% seq_along(data[[c("signalAttr", "signalNames")]]))) {
  #   visualiseSignal <-
  #     data[[c("signalAttr", "signalNames")]][visualiseSignal]
  # }

  # before starting the MCMC, save data, model and options to folder to allow
  # continuing model run just from folder
  if (newRun) {
    saveRDS(data, paste0(modelDir, "/", modelName, "_data.rds"))
    saveRDS(model, paste0(modelDir, "/", modelName, "_model.rds"))
    saveRDS(model, paste0(modelDir, "/", modelName, "_model.rds"))
  }

  # check if parallel runs should be used
  isParallel <- runParallel # & nRun > 1

  # If running in parallel, disable single-file preview to avoid contention
  if (isTRUE(isParallel) && !is.null(preview_path)) {
    preview_path <- NULL
  }

  ## Plot related preparations

  if (isParallel && visualise[[1]] != FALSE) {
    # define directory to save PNG files
    saveVisualiseDir <- modelDir
    # double // may cause issues on mac
    saveVisualiseDir <- sub("//", "/",  saveVisualiseDir)
    # always plot log posterior
    parametersToPlot <- c("posterior", model[["outputParams"]][visualise[["parameter"]]])
    # remove potential residual plot files from previous run (on.exit deletion
    # doesn't always work on Mac):
    StratoBayes:::.RemoveResidualPlotFiles(saveVisualiseDir, modelDir, modelName, nRun,
                             sigIndices = visualise[[2]], parameters =
                               parametersToPlot)
    # HTML file
    htmlFileName <- file.path(saveVisualiseDir, "results.html")
    write(.CreateHtmlCode(nRun, saveVisualiseDir, parametersToPlot, seq_len(nRun), visualise[["signal"]]), htmlFileName)
    # open the HTML file in the default browser
    StratoBayes:::.BrowseURL(htmlFileName)

    # delete the HTML file after the function has finished
    on.exit(unlink(htmlFileName), add = TRUE)

    # delete pngs at the end
    on.exit(unlink(list.files(path = saveVisualiseDir, pattern = "plot_.*\\.png$",
                              full.names = TRUE)),
            add = TRUE)

    # lock file for plotting
    plotLock <- file.path(modelDir, paste0(modelName, "_plot"))

    .LockFileExists(plotLock)

    on.exit({
      .RemoveLockFile(plotLock)
    }, add = TRUE)


  } else {
    #create dummies for saveVisualiseDir and htmlFilenames if visualise == FALSE
    saveVisualiseDir <- NULL
    htmlFileName <- NULL
    # Restore user's parameters on exit
    if (!isParallel && !isFALSE(visualise[[1]])) {
      oPar <- par()
      on.exit(par(oPar[setdiff(names(oPar), c("cin", "cra", "csi", "cxy", "din", "page"))]), add = TRUE)
    }
  }

  # remove iterations (if parallel) and samples_read files
  on.exit(StratoBayes:::.CleanUpFiles(modelDir, modelName, nRun, isParallel), add = TRUE)


  #  Parallel runs
  if (isParallel && nRun > 1) {
    if (!requireNamespace("future.apply", quietly = TRUE)) {
      stop(
        'The "future.apply" package must be installed to use RunStratModel ',
        'with `runParallel = TRUE`.',
        call. = FALSE
      )
    }

    if (is.null(nCores)) {
      nCores <- min(nRun, parallel::detectCores())
    }

    # Use a local plan so we don't alter the user's global future settings
    oldPlan <- future::plan(future::multisession, workers = nCores)
    on.exit(future::plan(oldPlan), add = TRUE)

    potentialError <- future.apply::future_lapply(
      seq_len(nRun),
      function(run) {
        tryCatch({
          if (is.numeric(seed)) {
            set.seed(seed[run])
          } else if (isTRUE(seed)) {
            set.seed(run)
          }

          if (isTRUE(profile)) {
            profileFileName <- paste0(modelName, "_Rprof_run", run, ".out")
            profileFile <- file.path(modelDir, profileFileName)
            utils::Rprof(profileFile)
          }

          .InnerRunMCMC(
            run = run,
            nRun = nRun,
            data = data,
            model = model,
            mcmc = mcmc[[run]],
            isParallel = TRUE,
            seed = seed,
            visualise = visualise,
            colourScale = colourScale,
            quiet = quiet,
            saveVisualiseDir = saveVisualiseDir,
            htmlFileName = htmlFileName,
            perRunTimeLimit = perRunTimeLimit,
            modelDir = modelDir,
            modelName = modelName,
            preview_path = preview_path
          )

          if (isTRUE(profile)) {
            utils::Rprof(NULL)
          }

          NULL
        }, error = function(e) {
          errorDetails <- utils::capture.output(traceback())
          errorMessage <- paste(
            "Error in run", run, ":", e$message, "\n",
            paste(errorDetails, collapse = "\n")
          )
          cat(errorMessage,
              file = file.path(modelDir,
                               paste0(modelName, "_error_run_", run, ".txt")))
          stop(e)
        })
      },
      future.packages = "StratoBayes",
      future.seed = TRUE
    )
  } else {

    for (run in seq_len(nRun)) {
      # optionally set random seeds
      if (is.numeric(seed)) {
        set.seed(seed[run])
      } else {
        if (isTRUE(seed)) {
          set.seed(run)
        }
      }
      # start Rprof profiling
      if (isTRUE(profile)) {
        profileFileName <- paste0(modelName,"_Rprof_run", run, ".out")
        profileFile <- file.path(modelDir, profileFileName)
        utils::Rprof(profileFile)
      }

      potentialError <- .InnerRunMCMC(
        run = run,
        nRun = nRun,
        data = data,
        model = model,
        mcmc = mcmc[[run]],
        isParallel = isParallel,
        seed = seed,
        visualise = visualise,
        colourScale = colourScale,
        quiet = quiet,
        saveVisualiseDir = saveVisualiseDir,
        htmlFileName = htmlFileName,
        perRunTimeLimit = perRunTimeLimit,
        modelDir = modelDir,
        modelName = modelName,
        # NEW preview args
        preview_path   = preview_path,
        preview_width  = preview_width,
        preview_height = preview_height,
        preview_res    = preview_res)

      # stop Rprof profiling
      if (isTRUE(profile)) {
        utils::Rprof(NULL)
      }

      # Return:
      NULL # nothing (all saved in log files)
    }
  }

  if (any(!(vapply(potentialError, is.null, logical(1))))) {
    saveRDS(potentialError, file.path(modelDir, paste(modelName, "errorMessages.rds", sep = "_")))
  }
  # output
  StratPosterior(readDir = modelDir,
                 modelName = modelName,
                 stratData = data,
                 stratModel = model,
                 stratMCMClist = NULL)
}

#' @importFrom grDevices dev.off hcl.colors hcl.pals png rgb
.InnerRunMCMC <- function(run,
                          nRun,
                          data,
                          model,
                          mcmc,
                          isParallel,
                          seed,
                          visualise,
                          colourScale,
                          quiet,
                          modelDir,
                          modelName,
                          saveVisualiseDir = NULL,
                          htmlFileName = NULL,
                          perRunTimeLimit,
                          preview_path   = NULL,     # e.g. tempfile(filetext = ".png")
                          preview_width  = 600,
                          preview_height = 600,
                          preview_res    = 120) {
  #
  .preview_on <- !is.null(preview_path)

  # for time limit
  startTime <- Sys.time()

  # progress bar
  if (!isParallel && !quiet) {
    cli::cli_progress_bar(paste0("Sampling run ", run, "/", nRun), total = mcmc[["nIter"]])
  }

  ### insertion to monitor swapping ###
  if (mcmc[[c("temper", "adaptTemperaturesMonitor")]]) {
    temperingSwaps <-
      array(dim = c(mcmc[["nIter"]], mcmc[[c("temper", "nSwapCombinations")]]))
    mcmc[[c("temper", "temperingSwaps")]] <- temperingSwaps
  }
  ###

  # file management

  samplesFileName <- paste0(modelName, "_samples", "_run_", run, ".txt")
  samplesFilePath <- file.path(modelDir, samplesFileName)

  # lock file names for plotting
  plotLock <- file.path(modelDir, paste0(modelName, "_plot.lock"))
  plotLockInactive <- file.path(modelDir, paste0(modelName, "_plot_inactive.lock"))
  if (!isFALSE(visualise[[1]]) && isParallel) {
    file.create(plotLockInactive)
  }
  # Open a connection to the samples file for appending
  connection <- file(samplesFilePath, open = "a")
  on.exit(close(connection), add = TRUE)

  ###
  if (mcmc[["startIter"]] == 1) {
    state <- lapply(seq_len(mcmc[["nChains"]]), function(x)
      StratoBayes:::.GenerateInitialState(
        data = data,
        model = model,
        mcmc = mcmc,
        chain = x
      ))

    StratoBayes:::.AppendSamples(connection, model, state, iteration = 1, mcmc[["saveChains"]])

    if (any(mcmc[[c("metro", "adaptProposal")]])) {
      mcmc[["metro"]] <- StratoBayes:::.SaveMCMChistory(data, model, mcmc, state, inLateAdaptation = FALSE)
    }

    # write MCMC file
    mcmc[["recentState"]] <- state
    ### save that the first iteration has been completed
    mcmc[["completedIter"]] <- 1

    # save updating of mcmc and sample files
    filename <- paste(modelName, "mcmc", "run", run, sep = "_")
    filenameRDS <- paste0(modelDir, "/", filename, ".rds")
    saveRDS(mcmc, filenameRDS, compress = FALSE)

    # write samples to disk
    flush(connection)

    # .SafeWriteSamples(modelDir, modelName, run, connection)

  } else {
    state <- mcmc[["recentState"]]
  }

  if (visualise[[1]] != FALSE) {
    # set up indices for updating a storage matrix with samples for plotting
    saveIterUsed <- mcmc[["saveIter"]][mcmc[["saveIter"]] >= mcmc[["startIter"]]] - mcmc[["startIter"]] + 1
    plotSampleMatrixUpdateIndices <- StratoBayes:::.PlotSampleMatrixUpdateIndices(
      nRow = 50, saveIter = saveIterUsed)
    # first iteration
    # start with iteration = 1 also for continued runs # max(c(1, mcmc[["startIter"]])) - 1
    sample1 <- StratoBayes:::.SamplesToSave(model, state, iteration = 1, saveChains = 1, mode = "plotting")
    # initialise plotSampleMatrix (size hard coded to 50)
    plotSampleMatrix <- matrix(NA, nrow = 50, ncol = dim(sample1)[2])
    plotSampleMatrix[1 , ] <-  sample1
    # save immediately to make available for plotting
    StratoBayes:::.SafeWriteSamplesForPlotting(modelDir, modelName, run, plotSampleMatrix)
    # ── NEW: initial preview before the main loop (non-parallel only) ──
    if (.preview_on && !isParallel && visualise[[1]] != FALSE) {
      grDevices::png(filename = preview_path,
                     width = preview_width, height = preview_height, res = preview_res)
      StratoBayes:::.PlotDuringMCMC(data, model, mcmc, modelDir, modelName,
                      saveVisualiseDir, nRun, run, isParallel, visualise,
                      colourScale, i = mcmc[["startIter"]])
      grDevices::dev.off()
    }

  }

  # iterations for mcmc loop
  runIterations <- StratoBayes:::.RunIterations(max(c(2, mcmc[["startIter"]])),
                                  mcmc[["endIter"]])

  for (i in runIterations) {
    mcmc[["currentIter"]] <- i
    # Calculate the fraction of adaptation completed
    adaptFraction <- if (mcmc[["endAdapting"]] == mcmc[["startAdapting"]]) {
      1 } else {
        (mcmc[["currentIter"]] - mcmc[["startAdapting"]]) /
          (mcmc[["endAdapting"]] - mcmc[["startAdapting"]])
      }
    inLateAdaptation <- adaptFraction >= 0.5

    if (!isParallel && !quiet && i %% 10 == 0) {
      displayIteration <- i - mcmc[["startIter"]] + 1
      cli::cli_progress_update("Sampling",
                               set = displayIteration,
                               status = paste0("iteration ", displayIteration))
    }

    for (chain in seq_len(mcmc[["nChains"]])) {
      state[[chain]] <- StratoBayes:::.UpdateState(
        data = data,
        model = model,
        mcmc = mcmc,
        state = state[[chain]],
        chain = chain
      )
      # monitor acceptance
      if (i >= mcmc[[c("metro", "acceptanceMonitor", "startMonitoring")]]) {
        propNumber <- state[[chain]][[c("metro", "proposalNumber")]]
        mcmc[[c("metro", "acceptanceMonitor", "proposalTotal")]][chain, propNumber] <-
          mcmc[[c("metro", "acceptanceMonitor", "proposalTotal")]][chain, propNumber]  +
          1
        mcmc[[c("metro", "acceptanceMonitor", "acceptanceTotal")]][chain, propNumber] <-
          mcmc[[c("metro", "acceptanceMonitor", "acceptanceTotal")]][chain, propNumber] +
          state[[chain]][[c("metro", "accept")]]
      }
    }


    # save state history for adaptation
    if (any(mcmc[[c("metro", "adaptProposal")]]) &&
        (i <= mcmc[["endAdapting"]] ||
         # save chain history for potential continued runs,
         # assuming acceptance rate of ca 0.25
         i >= mcmc[["endIter"]] - 4 * mcmc[[c("metro", "historyLength")]])) {
      mcmc[["metro"]] <- StratoBayes:::.SaveMCMChistory(data, model, mcmc, state, inLateAdaptation)
    }

    # process state history to adapt proposal
    if (i == mcmc[["endAdapting"]] || i == mcmc[[c("metro", "nextAdapt")]] && i < mcmc[["endAdapting"]]) {
      mcmc[["metro"]] <- StratoBayes:::.UpdateMCMC(data, model, mcmc, i, inLateAdaptation)
      mcmc[["metro"]] <- StratoBayes:::.UpdateProposalProbAndFac(model, mcmc, inLateAdaptation)
    }

    # decide tempering (needs to be stored in mcmc for later updating temperatures)
    mcmc[["temper"]] <- StratoBayes:::.Tempering(mcmc, state, i)
    # execute tempering
    if (mcmc[[c("temper", "tempering")]])
      state <- state[mcmc[[c("temper", "newChainPositions")]]]

    # update temperatures
    if (mcmc[[c("temper", "tempering")]] &&
        mcmc[[c("temper", "adaptTemperatures")]] &&
        i %fin% mcmc[[c("temper", "adaptTemperaturesIterations")]]) {
      mcmc[["temper"]] <- StratoBayes:::.UpdateTemperatures(mcmc)
    }

    ### insertion to monitor swapping ###
    if (mcmc[[c("temper", "adaptTemperaturesMonitor")]]) {
      if (mcmc[[c("temper", "tempering")]] &&
          mcmc[[c("temper", "adaptTemperatures")]])
        temperingSwaps[i, mcmc[[c("temper", "swapOrder")]]] <-
          mcmc[[c("temper", "accept")]][mcmc[[c("temper", "swapOrder")]]]
    }
    ###
    # append samples to log file

    if (i %fin% mcmc[["saveIter"]]) {
      StratoBayes:::.AppendSamples(connection, model, state, iteration = i,
                     mcmc[["saveChains"]])
      if (visualise[[1]] != FALSE) {
        updateIndex <- plotSampleMatrixUpdateIndices[i - mcmc[["startIter"]] + 1 == saveIterUsed]
        plotSampleMatrix[updateIndex , ] <-
          StratoBayes:::.SamplesToSave(model, state, i - mcmc[["startIter"]] + 1,
                         saveChains = 1, mode = "plotting")
      }
    }

    ### save which iteration has been completed
    mcmc[["completedIter"]] <- i

    stopConditionMet <- StratoBayes:::.StopCondition(i, mcmc[["endIter"]] , perRunTimeLimit, startTime)

    # at last iteration and at certain intervals, and when stop condition is met
    # write MCMC for continued runs
    if (i %fin% mcmc[["writeMCMCiterations"]] || stopConditionMet) {
      mcmc[["recentState"]] <- state
      if (mcmc[[c("temper", "adaptTemperaturesMonitor")]])
        mcmc[[c("temper", "temperingSwaps")]] <- temperingSwaps

      if (stopConditionMet) {
        # prune saveIter to only hold iterations that were actually completed
        mcmc[["saveIter"]] <- mcmc[["saveIter"]][mcmc[["saveIter"]] <= mcmc[["completedIter"]]]
        # similar for endAdapting
        mcmc[["endAdapting"]] <- min(c(mcmc[["endAdapting"]], mcmc[["completedIter"]]))
      }

      filename <- paste(modelName, "mcmc", "run", run, sep = "_")
      filenameRDS <- paste0(modelDir, "/", filename, ".rds")
      saveRDS(mcmc, filenameRDS, compress = FALSE)

      # write samples to disk
      flush(connection)

      # .SafeWriteSamples(modelDir, modelName, run, connection)

    }

    # check if current iteration should be plotted
    plotConditionsMet <- visualise[[1]] != FALSE &&
      ((i %% visualise[[1]]) == 0 || i == mcmc[["nIter"]])

    plotNow <- FALSE

    if (isTRUE(plotConditionsMet)) {

      # write samples to disk
      flush(connection)

      # .SafeWriteSamples(modelDir, modelName, run, connection)
      StratoBayes:::.SafeWriteSamplesForPlotting(modelDir, modelName, run, plotSampleMatrix)

      if (!isParallel) {
        plotNow <- TRUE
      } else {
        # parallel process needs to check if this process should plot

        # check if current iteration has already been plotted by other run
        lastPlotIteration <- StratoBayes:::.ReadPlotIteration(file.path(modelDir, paste0(modelName,"_plotIteration")))

        if (i > lastPlotIteration) {

          if (!file.exists(sprintf("%s.lock", plotLock))) {
            file.rename(plotLockInactive, plotLock)
            file.create(plotLockInactive)
            plotNow <- TRUE
            StratoBayes:::.WritePlotIteration(i, file.path(modelDir, paste0(modelName,"_plotIteration")), run)
          }
        }
      }
    }

    # plot current iteration
    if (isTRUE(plotNow)) {

      if (.preview_on) {
        grDevices::png(filename = preview_path,
                       width = preview_width, height = preview_height, res = preview_res)
      }

      StratoBayes:::.PlotDuringMCMC(data, model, mcmc, modelDir, modelName, saveVisualiseDir, nRun, run, isParallel, visualise, colourScale, i)

      if (.preview_on) {
        grDevices::dev.off()   # flush so Shiny sees an updated file
      }

      if (isTRUE(isParallel)) {
        parametersToPlot <- c("posterior", model[["outputParams"]][visualise[["parameter"]]])

        # update html file
        write(StratoBayes:::.CreateHtmlCode(nRun, saveVisualiseDir, parametersToPlot, seq_len(nRun), visualise[["signal"]]), htmlFileName)
        StratoBayes:::.RemoveLockFile(plotLock)
      }

    }

    # break loop if necessary
    if (stopConditionMet) {
      # exit loop
      break
    }
  } # bracket ends runIterations loop
}

# Ensure %fin% exists at runtime (fallback to base %in% if fastmatch not attached)
if (!exists("%fin%", mode = "function")) {
  if (requireNamespace("fastmatch", quietly = TRUE)) {
    `%fin%` <- fastmatch::`%fin%`
  } else {
    `%fin%` <- function(x, table) base::`%in%`(x, table)
  }
}
