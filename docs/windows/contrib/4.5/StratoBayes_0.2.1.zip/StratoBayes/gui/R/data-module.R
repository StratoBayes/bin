##############################################################################
# Load data
##############################################################################

# Server-only module that binds all data-loading UI/logic

data_server <- function(input, output, session, r) {

  # local state moved from server.R
  uiTrigger <- reactiveVal(0)
  datasetId <- reactiveVal(0)

  UpdateData <- reactive({
    isolate({
      updateCheckboxGroupInput(session, "loadSiteSelect", choices = NULL, selected = NULL)
      updateCheckboxGroupInput(session, "viewSiteSelect", choices = NULL, selected = NULL)
    })

    req(!is.null(input$dataSource))

    source <- input$dataSource
    if (source == "file") {
      # If no file selected but we have persisted data, use it
      if (is.null(input$dataFile) && !is.null(r$persistedDataset)) {
        r$dataset <- r$persistedDataset
        updateDataPreview()
        showElement("siteColumn"); showElement("zColumn"); showElement("signalColumns")
        Notification(type = "message", paste("Loaded", nrow(r$dataset), "horizons (from previous session)"))
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
        return("Data restored from previous session")
      }

      # Require file input if no persisted data
      req(!is.null(input$dataFile))
      showElement("dataFile")
      runjs("console.log($('#dataFile-label'))")
      runjs(paste0(
        "$('#dataFile-label').parent()",
        ".css({'outline': 'dashed #428bca 20px', 'width': '100%'})",
        ".animate({'outline-width': '0px'}, 'slow');"))

      fileInput <- input$dataFile
      r$dataset <- NULL
      if (is.null(fileInput)) {
        Notification(type = "error", "No data file selected"); return("No data file selected.")
      }

      # Always clear LAS state before deciding how to read this upload
      r$lasFolderPath <- NULL
      r$lasFileNames <- NULL
      # Fresh data load: reset merge history so stale well-name entries don't
      # accidentally re-apply to an unrelated dataset.
      r$mergeHistory <- list()

      # Normalize fileInput to vectors (handle both data.frame and list structures)
      # Shiny fileInput with multiple=TRUE returns data.frame even for 1 file
      if (is.data.frame(fileInput)) {
        fileNames <- fileInput$name
        filePaths <- fileInput$datapath
        nFiles <- nrow(fileInput)
      } else {
        # List structure (shouldn't happen with multiple=TRUE, but handle it)
        fileNames <- fileInput$name
        filePaths <- fileInput$datapath
        nFiles <- length(fileNames)
      }

      # Multiple file mode: only if truly multiple (nFiles > 1)
      if (nFiles > 1) {
        fileExtensions <- tools::file_ext(tolower(fileNames))

        if (all(fileExtensions == "las")) {
          # Multiple LAS files
          tempLasDir <- file.path(
            tempdir(),
            paste0("StratoBayes_LAS_", digest::digest(paste(filePaths, collapse = ";")))
          )
          if (!dir.exists(tempLasDir)) dir.create(tempLasDir, recursive = TRUE)

          for (i in seq_along(filePaths)) {
            file.copy(filePaths[i], file.path(tempLasDir, fileNames[i]), overwrite = TRUE)
          }

          LogMsg("UpdateData(): from LAS files")

          r$readDataFile <- NULL
          r$lasFolderPath <- tempLasDir
          r$lasFileNames <- fileNames

          # Read and combine LAS files
          r$dataset <- tryCatch(
            .ReadLasAsDataset(folder = tempLasDir, fileNames = fileNames),
            error = function(e) {
              Notification(type = "error", paste("Failed to read LAS files:", conditionMessage(e)))
              NULL
            }
          )

          if (is.null(r$dataset)) return("Failed to read LAS files.")

          # Continue through the normal "loaded dataset" path
          # (no early return)
        } else {
          Notification(type = "error", "Mixed file types not supported. Please select either all CSV files or all LAS files.")
          return("Mixed file types not supported.")
        }
      } else {
        # Single file mode (nFiles == 1) - handle CSV, Excel, or single LAS
        # Normalize to single file path/name regardless of input structure
        dataFile <- if (is.data.frame(fileInput)) filePaths[1] else fileInput$datapath
        if (is.null(dataFile)) {
          Notification(type = "error", "No data file found."); return("No data file specified.")
        }

        LogMsg("UpdateData(): from file")
        r$readDataFile <- NULL

        # Single LAS file: allow loading 1 well; user can add more via "Add more LAS files"
        dataFileExt <- tolower(tools::file_ext(dataFile))
        if (dataFileExt == "las") {
          fileName <- if (is.data.frame(fileInput)) fileNames[1] else basename(dataFile)
          tempLasDir <- file.path(
            tempdir(),
            paste0("StratoBayes_LAS_", digest::digest(dataFile))
          )
          if (!dir.exists(tempLasDir)) dir.create(tempLasDir, recursive = TRUE)
          file.copy(dataFile, file.path(tempLasDir, fileName), overwrite = TRUE)
          r$lasFolderPath <- tempLasDir
          r$lasFileNames <- fileName
          r$dataset <- tryCatch(
            .ReadLasAsDataset(folder = tempLasDir, fileNames = NULL),
            error = function(e) {
              Notification(type = "error", paste("Failed to read LAS file:", conditionMessage(e)))
              r$lasFolderPath <- NULL
              r$lasFileNames <- NULL
              NULL
            }
          )
          if (is.null(r$dataset)) return("Failed to read LAS file.")
          nWells <- length(r$lasFileNames)
          if (nWells < 2L) {
            Notification(type = "message",
              paste("1 well loaded. Add more LAS files to proceed (StratoBayes requires at least 2 wells)."),
              duration = 6)
          }
          # Skip Excel/CSV branch
        } else {
          r$lasFolderPath <- NULL
          r$lasFileNames <- NULL

        if (length(grep("\\.xlsx?$", dataFile))) {
          if (!requireNamespace("readxl", quietly = TRUE)) {
            install.packages("readxl")
          }
          showElement("readxl.options", anim = TRUE)

        r$dataset <- tryCatch({
          sheets <- readxl::excel_sheets(dataFile)
          updateSelectInput(session, "readxl.sheet",
                            choices = setNames(sheets, sheets),
                            selected = if (input$readxl.sheet %in% sheets) input$readxl.sheet else sheets[1])

          tibble <- readxl::read_excel(
            path = dataFile,
            sheet = match(input$readxl.sheet, sheets, nomatch = 1L),
            skip = max(0L, input$readxlSkip - 2L),
            .name_repair = "minimal",
            col_types = "text"
          )
          tibble <- safe_colnames(tibble)

          firstCol <- input$readxlSkipCols - 1L
          dat <- as.matrix(tibble[, -seq_len(firstCol)])

          LogComment("Load data from spreadsheet", 2)
          if (r$excelFiles == 0 || tools::md5sum(dataFile) != tools::md5sum(paste0(tempdir(), "/", LastFile("excel")))) {
            CacheInput("excel", dataFile)
          }
          dat
        }, error = function(e) { NULL })
      } else {
        hideElement("readxl.options")
      }

      # CSV/TSV fallback
      if (is.null(r$dataset)) {
        suppressWarnings({
          r$dataset <- tryCatch(
            { safe_colnames(read.csv(dataFile, check.names = FALSE)) },
            error = function(e) {
              tryCatch({ read.table(dataFile) },
                       error = function(e) { r$readDataFile <- NULL; NULL })
            }
          )
        })
      }
      }  # Close else (non-LAS: Excel/CSV)
      }  # Close the else block for single file (list structure)

    } else {
      LogMsg("UpdateData(): from package")
      # First try package extdata
      dataFile <- system.file("extdata", source, package = "StratoBayes")
      # If not found, try gui/extdata directory
      if (dataFile == "" || !file.exists(dataFile)) {
        guiExtdataPath <- system.file("gui", "extdata", source, package = "StratoBayes")
        if (guiExtdataPath != "" && file.exists(guiExtdataPath)) {
          dataFile <- guiExtdataPath
        } else {
          # Fallback to current working directory
          dataFile <- file.path(getwd(), source)
        }
      }
      if (!file.exists(dataFile)) {
        Notification(type = "error", paste("Could not find example data at", dataFile))
        return("Example data not found.")
      }
      LogMsg(dataFile)
      r$dataset <- safe_colnames(read.csv(dataFile, check.names = FALSE))
      LogComment("Load dataset file from StratoBayes package")
    }

    if (is.null(r$dataset)) {
      Notification(type = "error", "Could not read data from file")
      return ("Could not read data from file")
    } else {
      # NEW LOGIC FOR RELOADING PARTITIONS
      if (isTRUE(r$loadedSavedDataset)) {
        # Restore partitions if they exist in the persisted object
        if (!is.null(r$persistedPartitions)) {
          r$parts_df <- r$persistedPartitions
          LogMsg("Partitions restored from saved dataset")
        }
      } else {
        # This is a brand new file upload
        isNewDataset <- is.null(r$persistedDataset) ||
          nrow(r$dataset) != nrow(r$persistedDataset) ||
          !identical(colnames(r$dataset), colnames(r$persistedDataset))

        if (isNewDataset) {
          r$persistedColumnSelections$siteColumn <- NULL
          r$persistedColumnSelections$zColumn <- NULL
          r$persistedColumnSelections$signalColumns <- NULL
          r$alignment <- NULL
          r$parts_df <- NULL # Clear partitions for new data
        }
      }

      updateDataPreview()
      showElement("siteColumn"); showElement("zColumn"); showElement("signalColumns")
      Notification(type = "message", paste("Loaded", nrow(r$dataset), "horizons"))
      datasetId(datasetId() + 1)
      uiTrigger(uiTrigger() + 1)
    }
  })

  # Helper function to get signal data for preview
  getSignalDataForPreview <- reactive({
    # Only use alignment data if it matches the current dataset
    # Check if alignment exists and if it's from the current dataset
    if (!is.null(r$alignment) && inherits(r$alignment, "StratPosterior") &&
        !is.null(r$alignment$data) && inherits(r$alignment$data, "StratData") &&
        !is.null(r$dataset)) {
      # Check if alignment data matches current dataset (by comparing dimensions or structure)
      # If datasets don't match, use current dataset instead
      align_signal <- r$alignment$data$signal
      if (!is.null(align_signal) && nrow(align_signal) > 0) {
        # Use alignment data only if it seems to match current dataset
        # (This is a heuristic - if column names match, assume it's the same dataset)
        if (nrow(align_signal) == nrow(r$dataset) &&
            length(intersect(colnames(align_signal), colnames(r$dataset))) > 0) {
          return(align_signal)
        }
      }
    }
    # Otherwise use raw dataset
    return(r$dataset)
  })

  # Pick rows for the preview that include all sites/wells, not just the head
  # of the combined data (which often lands entirely inside the first LAS
  # file). Caps the total at `cap` rows for responsiveness.
  .previewRows <- function(df, cap = 2000L) {
    if (is.null(df) || nrow(df) == 0L) return(df)
    cap <- as.integer(cap)
    if (nrow(df) <= cap) return(df)

    # Prefer the user-selected site column; otherwise try a conventional one.
    site_col <- tryCatch(siteColumn(), error = function(e) NULL)
    if (is.null(site_col) || !(site_col %in% colnames(df))) {
      for (cand in c("well", "site", "Site", "Well", "WELL")) {
        if (cand %in% colnames(df)) { site_col <- cand; break }
      }
    }
    if (is.null(site_col) || !(site_col %in% colnames(df))) {
      return(df[seq_len(cap), , drop = FALSE])
    }

    groups <- split(seq_len(nrow(df)), trimws(as.character(df[[site_col]])))
    n_per <- max(1L, as.integer(floor(cap / max(1L, length(groups)))))
    picks <- unlist(lapply(groups, function(idx) idx[seq_len(min(length(idx), n_per))]),
                    use.names = FALSE)
    picks <- sort(unique(as.integer(picks)))
    if (length(picks) > cap) picks <- picks[seq_len(cap)]
    df[picks, , drop = FALSE]
  }

  # Function to update data preview (show rows from each site; cap at 2000)
  updateDataPreview <- function() {
    signal_data <- getSignalDataForPreview()
    if (!is.null(signal_data) && nrow(signal_data) > 0) {
      output$dataHead <- renderTable({
        .previewRows(signal_data, cap = 2000L)
      })
    } else if (!is.null(r$dataset) && nrow(r$dataset) > 0) {
      output$dataHead <- renderTable({
        .previewRows(r$dataset, cap = 2000L)
      })
    }
  }

  # mirror observers
  # In-place mutations to r$dataset (e.g. renaming a well, writing a normalised
  # site column back in the partition-init code) must NOT be treated as a brand
  # new dataset load. Previously this observer bumped datasetId()/uiTrigger()
  # unconditionally, which changed the selectInput IDs from e.g. siteColumn_5
  # to siteColumn_6, so the user's column/reference-site picks were effectively
  # wiped (new widgets have no input value yet). We now detect structural
  # changes (row count / column set) vs. pure value-only edits.
  rDatasetFingerprint <- reactiveVal(NULL)
  observeEvent(r$dataset, {
    req(r$dataset)
    new_fp <- list(
      ncol = ncol(r$dataset),
      nrow = nrow(r$dataset),
      cols = sort(colnames(r$dataset))
    )
    old_fp <- rDatasetFingerprint()
    structural <- is.null(old_fp) || !identical(new_fp, old_fp)
    rDatasetFingerprint(new_fp)

    # Always keep the data preview fresh, even for in-place edits.
    updateDataPreview()

    if (!structural) {
      # Pure value mutation (e.g. rename). Do NOT reset checkboxes, IDs, or
      # alignment — those would wipe user selections downstream.
      return(invisible(NULL))
    }

    updateCheckboxGroupInput(session, "loadSiteSelect", choices  = character(0), selected = character(0))
    updateCheckboxGroupInput(session, "viewSiteSelect", choices  = character(0), selected = character(0))
    # Clear alignment if dataset structure changes (new dataset means old results are invalid)
    if (!is.null(r$alignment) && !is.null(r$alignment$data)) {
      align_signal <- tryCatch({
        if (inherits(r$alignment$data, "StratData")) {
          r$alignment$data$signal
        } else {
          NULL
        }
      }, error = function(e) NULL)
      if (is.null(align_signal) ||
          nrow(align_signal) != nrow(r$dataset) ||
          length(intersect(colnames(align_signal), colnames(r$dataset))) == 0) {
        r$alignment <- NULL
      }
    }
    datasetId(datasetId() + 1)
    uiTrigger(uiTrigger() + 1)
  })

  # Also update preview when alignment changes (for StratPosterior objects)
  # But only if data has actually been loaded (r$dataset is set)
  observeEvent(r$alignment, {
    if (!is.null(r$alignment) && inherits(r$alignment, "StratPosterior") &&
        !is.null(r$dataset)) {
      updateDataPreview()
    }
  }, ignoreInit = TRUE)

  output$siteColumn_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$siteColumn) &&
                    r$persistedColumnSelections$siteColumn %in% cols) {
      r$persistedColumnSelections$siteColumn
    } else if ("well" %in% cols) {
      "well"
    } else if (any(tolower(cols) == "api")) {
      cols[tolower(cols) == "api"][1]
    } else if ("site" %in% cols) {
      "site"
    } else if (length(cols) > 0) {
      # If no default exists, just use empty (user must select)
      ""
    } else {
      ""
    }
    selectInput(paste0("siteColumn_", datasetId()), "Well / API / Site labels",
                choices, selected, selectize = TRUE)
  })

  output$zColumn_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$zColumn) &&
                    r$persistedColumnSelections$zColumn %in% cols) {
      r$persistedColumnSelections$zColumn
    } else if ("Depth" %in% cols) {
      "Depth"
    } else if ("height" %in% cols) {
      "height"
    } else if (length(cols) > 0) {
      # If no default exists, just use empty (user must select)
      ""
    } else {
      ""
    }
    selectInput(paste0("zColumn_", datasetId()), "Depth or Height",
                choices, selected, selectize = TRUE)
  })

  output$signalColumns_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$signalColumns) &&
                    all(r$persistedColumnSelections$signalColumns %in% cols)) {
      r$persistedColumnSelections$signalColumns
    } else if ("value" %in% cols) {
      "value"
    } else {
      # If no default exists, return empty (user must select)
      character(0)
    }
    selectInput(paste0("signalColumns_", datasetId()), "Well log curves",
                choices, selected, multiple  = TRUE, selectize = TRUE)
  })

  # One-line header: "Wells to include (rename wells)" so it doesn’t wrap to 3 lines
  output$wellsToIncludeHeader_ui <- renderUI({
    req(r$dataset, siteColumn())
    sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))
    if (length(sites) == 0) return(NULL)
    tags$div(
      style = "margin-bottom: 0.25em; white-space: nowrap;",
      tags$strong("Wells to include"),
      " ",
      tags$span(
        style = "font-size: 0.85em; font-weight: normal; color: #666;",
        "(",
        actionLink("renameWellsBtn", "rename wells"),
        ")"
      )
    )
  })

  # Render "Wells to include" section with reference selection
  output$wellsToInclude_ui <- renderUI({
    req(r$dataset, siteColumn())

    sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))
    if (length(sites) == 0) return(NULL)

    selectedSites <- if (!is.null(r$persistedSiteSelections) &&
                        all(r$persistedSiteSelections %in% sites)) {
      r$persistedSiteSelections
    } else {
      sites
    }

    updateCheckboxGroupInput(session, "loadSiteSelect", choices = sites, selected = selectedSites)

    currentRefSite <- if (!is.null(r$persistedReferenceSite) && r$persistedReferenceSite %in% sites) {
      r$persistedReferenceSite
    } else if (length(sites) > 0) {
      sites[1]
    } else {
      NULL
    }

    ref_buttons <- lapply(sites, function(site) {
      is_ref <- !is.null(currentRefSite) && site == currentRefSite
      tags$div(
        style = "display: inline-block; margin-right: 15px; margin-bottom: 5px;",
        tags$span(site, style = "margin-right: 5px; font-weight: 500;"),
        actionButton(
          inputId = paste0("refSite_", gsub("[^A-Za-z0-9]", "_", site)),
          label = if (is_ref) "REF" else "ref",
          class = if (is_ref) "btn-ref-well btn-xs" else "btn-default btn-xs",
          style = if (is_ref) {
            "padding: 2px 8px; font-size: 10px; font-weight: bold; min-width: 45px;"
          } else {
            "padding: 2px 8px; font-size: 10px; min-width: 45px;"
          },
          title = if (is_ref) "Reference well (click to change)" else "Set as reference well"
        )
      )
    })

    tagList(
      div(
        class = "strat-checklist",
        checkboxGroupInput(
          "loadSiteSelect",
          label = NULL,
          choices = setNames(sites, sites),
          selected = selectedSites
        )
      ),
      uiOutput("renameWellsPanel_ui"),
      tags$details(
        style = "margin-top: 10px; padding: 8px; background-color: #f7f7f7; border: 1px solid #ddd; border-radius: 5px;",
        tags$summary(
          style = "cursor:pointer;",
          tags$strong("Reference Well"),
          tags$span(
            style = "margin-left:6px; color:#6c757d; font-size:0.9em;",
            if (!is.null(currentRefSite)) paste0("(", currentRefSite, ")") else "(auto)"
          ),
          tags$span(
            class = "formations-partitions-tooltip",
            style = "margin-left:6px; color:#6c757d; font-size:0.9em;",
            icon("circle-info", class = "fas"),
            tags$span(
              class = "formations-partitions-tooltiptext",
              "Select the well that will serve as the reference curve for aligning the other wells."
            )
          )
        ),
        tags$div(
          style = "margin-top: 6px;",
          ref_buttons
        )
      )
    )
  })

  # ------------------------------------------------------------------
  # Merge wells popup (ported from 0.2.1 / commit 2bef0217)
  # ------------------------------------------------------------------
  # Small trigger button (shown only when the current dataset has 2+ wells).
  # suspendWhenHidden = FALSE guarantees the renderUI evaluates as soon as the
  # Load Data modal becomes visible, so the button appears without needing a
  # subsequent reactive nudge after an initial load.
  output$mergeWells_ui <- renderUI({
    ds <- r$dataset
    sc <- siteColumn()
    if (is.null(ds) || is.null(sc) || !nzchar(sc) || !(sc %in% colnames(ds))) {
      return(NULL)
    }
    sites <- unique(trimws(as.character(ds[[sc]])))
    if (length(sites) < 2L) return(NULL)
    tags$div(
      style = "margin-top: 6px; margin-bottom: 6px;",
      actionButton(
        "mergeWellsOpenBtn",
        label = tagList(icon("object-group"), " Merge wells\u2026"),
        class = "btn-sm btn-info",
        title = "Combine two or more wells into one (outer join on depth)"
      )
    )
  })
  outputOptions(output, "mergeWells_ui", suspendWhenHidden = FALSE)

  # Form content of the merge-wells modal. Kept as a separate renderUI so it
  # refreshes when the site list changes while the modal is open.
  output$mergeWellsModalContent_ui <- renderUI({
    req(r$dataset, siteColumn())
    sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))
    if (length(sites) < 2L) {
      return(tags$p("Need at least 2 wells to merge.", style = "color: #666;"))
    }
    tagList(
      tags$div(
        class = "strat-checklist",
        style = "max-height: 140px; overflow-y: auto; margin-bottom: 8px;",
        checkboxGroupInput(
          "mergeWellsSelect",
          label = "Wells to merge",
          choices = setNames(sites, sites),
          selected = character(0)
        )
      ),
      textInput(
        "mergeWellsName",
        label = "Merged well name",
        value = "",
        placeholder = "e.g. Well1 (longest common prefix suggested)",
        width = "100%"
      ),
      actionButton(
        "mergeWellsBtn", "Merge selected into one well",
        class = "btn-sm btn-primary", style = "margin-top: 6px;"
      )
    )
  })

  # Open the merge popup. Shiny replaces (not stacks) modals; mergeWellsModalClose
  # below is responsible for restoring the Load Data modal afterwards.
  observeEvent(input$mergeWellsOpenBtn, {
    showModal(mergeWellsModal())
  })

  # Close the merge popup and restore the Load Data modal.
  observeEvent(input$mergeWellsModalClose, {
    removeModal()
    showModal(modelSelectionModal())
  })

  # Suggest a merged well name as soon as the user picks 2+ wells. We use the
  # longest common prefix so naming stays predictable; user can still override.
  observeEvent(input$mergeWellsSelect, {
    sel <- input$mergeWellsSelect
    if (length(sel) >= 2L) {
      suggested <- .LongestCommonPrefix(sel)
      updateTextInput(session, "mergeWellsName", value = suggested)
    }
  }, ignoreNULL = FALSE)

  # Perform the merge. Safety invariants preserved here:
  #   * All partition state is cleared BEFORE we mutate r$dataset, so the
  #     downstream observers (parts_df_basic rebuild + .maybeAutoAddMiddlePartitions)
  #     regenerate Top_<merged> and Bound1_<merged> correctly rather than
  #     inheriting stale BoundN_<mergedAwayWell> labels.
  #   * Temp partition caches used by the partition modal are also cleared.
  #   * Persisted selections are patched so the Load Data modal re-opens with
  #     the merged well selected and any references to merged-away wells fixed.
  observeEvent(input$mergeWellsBtn, {
    req(r$dataset, siteColumn(), zColumn())
    wells <- input$mergeWellsSelect
    if (is.null(wells) || length(wells) < 2L) {
      showNotification("Select at least two wells to merge.", type = "warning")
      return()
    }
    merged_name <- trimws(input$mergeWellsName %||% "")
    if (!nzchar(merged_name)) merged_name <- .LongestCommonPrefix(wells)
    if (!nzchar(merged_name)) merged_name <- paste(wells, collapse = "_")

    result <- tryCatch(
      withCallingHandlers(
        .MergeWellsDataset(
          dataset        = r$dataset,
          site_col       = siteColumn(),
          depth_col      = zColumn(),
          wells_to_merge = wells,
          merged_name    = merged_name
        ),
        warning = function(w) {
          showNotification(paste("Merge warning:", conditionMessage(w)), type = "message")
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) {
        showNotification(paste("Merge failed:", conditionMessage(e)), type = "error")
        NULL
      }
    )
    if (is.null(result)) return()

    # 1) Clear partition caches FIRST so auto-rebuild observers pick up new data
    #    without tripping the "auto partitions already present" guard.
    r$partitionData  <- NULL
    r$parts_df_basic <- NULL
    r$parts_df_added <- NULL
    # Also clear transient partition-modal caches (held between "Done" and
    # "Save") so merged-away well names cannot resurface there.
    if (!is.null(r$tempAutoPartitions))       r$tempAutoPartitions       <- NULL
    if (!is.null(r$tempPointClickPartitions)) r$tempPointClickPartitions <- NULL

    # 2) Update the dataset – triggers the basic/auto-partition rebuild chain.
    r$dataset <- result

    # 2b) Record the merge so "Add more LAS files" can re-apply it after
    #     re-reading the LAS folder (otherwise the merge is undone).
    if (is.null(r$mergeHistory)) r$mergeHistory <- list()
    r$mergeHistory[[length(r$mergeHistory) + 1L]] <- list(
      wells = wells,
      merged_name = merged_name
    )

    # 3) Persisted reference site: if it was a merged-away well, point it at
    #    the merged well so the next modal load doesn't show it as missing.
    if (!is.null(r$persistedReferenceSite) && r$persistedReferenceSite %in% wells) {
      r$persistedReferenceSite <- merged_name
    }

    # 4) Refresh the site include list: drop merged-away wells, ensure the
    #    merged well is selected, and intersect with the new site universe.
    new_sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))
    prev_sel  <- r$persistedSiteSelections
    kept      <- setdiff(prev_sel, wells)
    r$persistedSiteSelections <- unique(c(kept, merged_name))
    r$persistedSiteSelections <- intersect(r$persistedSiteSelections, new_sites)
    if (length(r$persistedSiteSelections) == 0L) r$persistedSiteSelections <- new_sites
    updateCheckboxGroupInput(
      session, "loadSiteSelect",
      choices  = new_sites,
      selected = r$persistedSiteSelections
    )

    # 5) Reset merge-modal inputs and re-show Load Data modal.
    updateTextInput(session, "mergeWellsName", value = "")
    updateCheckboxGroupInput(session, "mergeWellsSelect", selected = character(0))
    removeModal()
    showModal(modelSelectionModal())

    showNotification(
      paste0("Merged ", length(wells), " wells into '", merged_name,
             "' (outer join on ", zColumn(), ")."),
      type = "message", duration = 5
    )
  })

  # Inline "rename wells" panel (no modal – avoids closing parent)
  output$renameWellsPanel_ui <- renderUI({
    if (!isTRUE(r$showRenameWellsPanel)) return(tags$div())
    sites <- r$renameWellsSites
    if (is.null(sites) || length(sites) == 0) return(tags$div())
    rows <- lapply(sites, function(site) {
      sid <- gsub("[^A-Za-z0-9]", "_", site)
      sid <- substr(sid, 1, 80L)
      tags$div(
        style = "margin-bottom: 8px;",
        textInput(
          inputId = paste0("rename_well_", sid),
          label = site,
          value = site,
          placeholder = "New name",
          width = "100%"
        )
      )
    })
    tagList(
      tags$div(
        style = "margin-top: 8px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; background: #f9f9f9;",
        tags$p("Change names below, then Apply.", style = "font-size: 0.9em; margin-bottom: 8px;"),
        rows,
        tags$div(
          style = "margin-top: 10px;",
          actionButton("applyRenameWells", "Apply", class = "btn-primary btn-sm"),
          actionButton("renameWellsDoneBtn", "Done", class = "btn-default btn-sm", style = "margin-left: 6px;")
        )
      )
    )
  })

  # Handle reference site button clicks
  observe({
    req(r$dataset, siteColumn())
    sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))

    for (site in sites) {
      btn_id <- paste0("refSite_", gsub("[^A-Za-z0-9]", "_", site))
      btn_input <- input[[btn_id]]

      if (!is.null(btn_input) && btn_input > 0) {
        isolate({
          r$persistedReferenceSite <- site
          showNotification(paste("Reference site set to:", site), type = "message", duration = 2)
        })
      }
    }
  })

  # Reactive to get reference site
  referenceSite <- reactive({
    if (!is.null(r$persistedReferenceSite) &&
        !is.null(siteColumn()) &&
        !is.null(r$dataset) &&
        r$persistedReferenceSite %in% unique(trimws(as.character(r$dataset[[siteColumn()]])))) {
      return(r$persistedReferenceSite)
    }
    return(NULL)
  })

  siteColumn <- reactive({
    ds <- r$dataset
    if (is.null(ds)) return(NULL)
    id <- paste0("siteColumn_", datasetId())
    sc <- input[[id]]
    # When loading a saved dataset, use persisted columns so stratData/getPartitionData see correct names before UI updates
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$persistedColumnSelections$siteColumn) &&
        r$persistedColumnSelections$siteColumn %in% colnames(ds)) {
      if (is.null(sc) || !(sc %in% colnames(ds))) return(r$persistedColumnSelections$siteColumn)
    }
    if (is.null(sc) || !(sc %in% colnames(ds))) return(NULL)
    sc
  })
  zColumn <- reactive({
    ds <- r$dataset
    if (is.null(ds)) return(NULL)
    id <- paste0("zColumn_", datasetId())
    zc <- input[[id]]
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$persistedColumnSelections$zColumn) &&
        r$persistedColumnSelections$zColumn %in% colnames(ds)) {
      if (is.null(zc) || !(zc %in% colnames(ds))) return(r$persistedColumnSelections$zColumn)
    }
    if (is.null(zc) || !(zc %in% colnames(ds))) return(NULL)
    zc
  })
  signalColumns <- reactive({
    ds <- r$dataset
    if (is.null(ds)) return(NULL)
    id <- paste0("signalColumns_", datasetId())
    sigs <- input[[id]]
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$persistedColumnSelections$signalColumns) &&
        all(r$persistedColumnSelections$signalColumns %in% colnames(ds))) {
      if (is.null(sigs) || !all(sigs %in% colnames(ds))) return(r$persistedColumnSelections$signalColumns)
    }
    if (is.null(sigs) || !all(sigs %in% colnames(ds))) return(NULL)
    sigs
  })

  # Mirror current on-screen column selections into persistedColumnSelections.
  # Any mutation to r$dataset (rename wells, LAS append, merge, ...) invalidates
  # the renderUI blocks for siteColumn_ui / zColumn_ui / signalColumns_ui and
  # re-creates the selectInputs. Their `selected` value is computed from
  # persistedColumnSelections, so without this mirror the user's picks are
  # replaced by hardcoded defaults (well/Depth/value) or cleared entirely.
  observe({
    sc <- siteColumn()
    if (!is.null(sc) && nzchar(sc)) r$persistedColumnSelections$siteColumn <- sc
  })
  observe({
    zc <- zColumn()
    if (!is.null(zc) && nzchar(zc)) r$persistedColumnSelections$zColumn <- zc
  })
  observe({
    sigs <- signalColumns()
    if (!is.null(sigs) && length(sigs) > 0) r$persistedColumnSelections$signalColumns <- sigs
  })

  # --- Downsampling --------------------------------------------------------
  # Reduce the number of rows passed to StratData() by selecting rows that are
  # roughly evenly spaced along the z-column, site by site. Partition logic
  # keeps using the raw r$dataset so Top_ buffers stay stable regardless of
  # the downsample setting.
  .downsampleByZ <- function(df, site_col, z_col,
                             mode = "persite",
                             target_n_persite = 1000L,
                             target_n_total = 5000L) {
    if (is.null(df) || nrow(df) == 0L) return(df)
    if (is.null(site_col) || is.null(z_col)) return(df)
    if (!(site_col %in% colnames(df)) || !(z_col %in% colnames(df))) return(df)

    z_num <- suppressWarnings(as.numeric(df[[z_col]]))
    ok <- is.finite(z_num)
    if (!any(ok)) return(df)

    pick_evenly <- function(idx, z_vec, n_target) {
      n <- length(idx)
      if (n_target < 1L) n_target <- 1L
      if (n <= n_target) return(idx)
      zv <- z_vec[idx]
      ord <- order(zv)
      zv_sorted <- zv[ord]
      idx_sorted <- idx[ord]
      z_range <- range(zv_sorted)
      if (!isTRUE(diff(z_range) > 0)) {
        return(idx_sorted[round(seq(1L, n, length.out = n_target))])
      }
      targets <- seq(z_range[1], z_range[2], length.out = n_target)
      hits <- findInterval(targets, zv_sorted, all.inside = TRUE)
      right_idx <- pmin(hits + 1L, length(zv_sorted))
      left_d <- targets - zv_sorted[hits]
      right_d <- zv_sorted[right_idx] - targets
      picks <- ifelse(right_d < left_d, right_idx, hits)
      idx_sorted[sort(unique(picks))]
    }

    sites_char <- trimws(as.character(df[[site_col]]))
    ok_idx <- which(ok)
    by_site <- split(ok_idx, sites_char[ok_idx])

    if (identical(mode, "total")) {
      n_total <- nrow(df)
      if (n_total <= target_n_total) return(df)
      n_each <- lengths(by_site)
      if (sum(n_each) == 0L) return(df)
      alloc <- pmax(2L, as.integer(floor(target_n_total * n_each / sum(n_each))))
      # Trim rounding excess from the largest allocations
      while (sum(alloc) > target_n_total) {
        k <- which.max(alloc)
        if (alloc[k] <= 2L) break
        alloc[k] <- alloc[k] - 1L
      }
      keep <- unlist(lapply(seq_along(by_site), function(i) {
        pick_evenly(by_site[[i]], z_num, alloc[i])
      }), use.names = FALSE)
    } else {
      keep <- unlist(lapply(by_site, function(rows) {
        pick_evenly(rows, z_num, target_n_persite)
      }), use.names = FALSE)
    }

    keep <- sort(unique(as.integer(keep)))
    df[keep, , drop = FALSE]
  }

  # --- Clean data ----------------------------------------------------------
  # Per-site z-range filters and per-signal value-range filters, configured
  # from the "Look at Data" panel.  z filters drop rows; value filters replace
  # out-of-range values with NA in the affected signal column only.
  cleanSettings <- reactiveValues(zRange = list(), valueRange = list())

  # Clear cleaning when a new dataset is loaded.
  observeEvent(r$dataset, {
    cleanSettings$zRange <- list()
    cleanSettings$valueRange <- list()
  }, ignoreInit = TRUE)

  .applyCleanSettings <- function(df, site_col, z_col, signal_cols) {
    if (is.null(df) || nrow(df) == 0L) return(df)
    # z-range cuts per site (drop rows outside the kept window)
    zr <- cleanSettings$zRange
    if (length(zr) > 0L && !is.null(site_col) && !is.null(z_col) &&
        site_col %in% colnames(df) && z_col %in% colnames(df)) {
      sites_char <- trimws(as.character(df[[site_col]]))
      zv <- suppressWarnings(as.numeric(df[[z_col]]))
      keep <- rep(TRUE, nrow(df))
      for (s in names(zr)) {
        rng <- zr[[s]]
        if (is.null(rng) || length(rng) != 2L || any(!is.finite(rng))) next
        in_site <- sites_char == s
        if (!any(in_site)) next
        keep[in_site] <- keep[in_site] & is.finite(zv[in_site]) &
          zv[in_site] >= min(rng) & zv[in_site] <= max(rng)
      }
      df <- df[keep, , drop = FALSE]
    }

    # Per-signal value cuts: NA out signal values outside the kept window.
    vr <- cleanSettings$valueRange
    if (length(vr) > 0L && !is.null(signal_cols)) {
      for (sig in names(vr)) {
        if (!(sig %in% colnames(df))) next
        rng <- vr[[sig]]
        if (is.null(rng) || length(rng) != 2L || any(!is.finite(rng))) next
        vals <- suppressWarnings(as.numeric(df[[sig]]))
        mask_out <- is.finite(vals) & (vals < min(rng) | vals > max(rng))
        if (any(mask_out)) df[[sig]][mask_out] <- NA
      }
    }
    df
  }

  # Dataset after cleaning but before downsampling; used for partition/preview
  # computations that should honour cleaning.
  cleanedDataset <- reactive({
    ds <- r$dataset
    if (is.null(ds) || nrow(ds) == 0L) return(ds)
    .applyCleanSettings(ds, siteColumn(), zColumn(), signalColumns())
  })

  # Reactive dataset used downstream (StratData, plotting). Applies cleaning
  # (if any) and optional downsampling; returns r$dataset unchanged when
  # cleaning/downsampling are off or columns are not yet selected.
  dataForStratData <- reactive({
    ds <- cleanedDataset()
    if (is.null(ds) || nrow(ds) == 0L) return(ds)
    mode <- input$downsampleMode %||% "persite"
    if (identical(mode, "none")) return(ds)
    sc <- siteColumn(); zc <- zColumn()
    if (is.null(sc) || is.null(zc)) return(ds)

    n_per <- suppressWarnings(as.integer(input$downsamplePerSiteN %||% 1000L))
    if (is.na(n_per) || n_per < 10L) n_per <- 1000L
    n_tot <- suppressWarnings(as.integer(input$downsampleTotalN %||% 5000L))
    if (is.na(n_tot) || n_tot < 10L) n_tot <- 5000L

    .downsampleByZ(ds, sc, zc,
                   mode = mode,
                   target_n_persite = n_per,
                   target_n_total = n_tot)
  })

  # Badge rendered inside the collapsed "Downsample" <summary>. Shows a
  # green check-mark pill only when downsampling is actually thinning the data
  # (e.g., per-site mode and at least one site exceeds the threshold), so it is
  # obvious from the collapsed UI that downsampling is active.
  output$downsampleActiveBadge <- renderUI({
    # Prefer the cleaned dataset so post-cleaning row counts drive the check,
    # but fall back to the raw dataset if cleaning hasn't settled yet.
    ds <- tryCatch(cleanedDataset(), error = function(e) NULL)
    if (is.null(ds) || nrow(ds) == 0L) ds <- r$dataset
    if (is.null(ds) || nrow(ds) == 0L) return(NULL)

    mode <- input$downsampleMode %||% "persite"
    if (identical(mode, "none")) return(NULL)

    sc <- siteColumn()
    if (is.null(sc) || !nzchar(sc) || !(sc %in% colnames(ds))) return(NULL)

    active <- FALSE
    detail <- ""
    if (identical(mode, "persite")) {
      n_per <- suppressWarnings(as.integer(input$downsamplePerSiteN %||% 1000L))
      if (is.na(n_per) || n_per < 10L) n_per <- 1000L
      site_vec <- as.character(ds[[sc]])
      counts <- tabulate(match(site_vec, unique(site_vec)))
      if (length(counts) && any(counts > n_per)) {
        active <- TRUE
        detail <- paste0("active \u2013 max ", format(n_per, big.mark = ","), " pts/site")
      }
    } else if (identical(mode, "total")) {
      n_tot <- suppressWarnings(as.integer(input$downsampleTotalN %||% 5000L))
      if (is.na(n_tot) || n_tot < 10L) n_tot <- 5000L
      if (nrow(ds) > n_tot) {
        active <- TRUE
        detail <- paste0("active \u2013 max ", format(n_tot, big.mark = ","), " pts total")
      }
    }
    if (!active) return(NULL)

    tags$span(
      style = paste(
        "margin-left: 8px;",
        "padding: 2px 10px;",
        "background: #d1e7dd;",
        "color: #0f5132;",
        "border: 1px solid #badbcc;",
        "border-radius: 10px;",
        "font-size: 0.85em;",
        "font-weight: 600;",
        "white-space: nowrap;"
      ),
      tags$span(
        style = "margin-right: 4px; font-weight: 700;",
        HTML("&#10003;")
      ),
      detail
    )
  })

  # New and improved basic partition creator
  createBasicPartitions <- function(df, site_col, z_col, z_scale) {
    if (is.null(df) || is.null(site_col) || is.null(z_col) || nrow(df) == 0) return(NULL)

    sites <- unique(trimws(as.character(df[[site_col]])))
    parts_list <- lapply(sites, function(s) {
      site_data <- df[df[[site_col]] == s, ]
      z_vals <- suppressWarnings(as.numeric(site_data[[z_col]]))
      z_vals <- z_vals[!is.na(z_vals) & is.finite(z_vals)]
      if (length(z_vals) == 0) return(NULL)

      # Calculate a safe boundary (0.1% of range, scale-invariant so depth and
      # height get proportionally equivalent buffers; small floor to avoid zero)
      z_range <- diff(range(z_vals))
      buffer <- max(z_range * 0.001, 1e-10)

      # StratData needs the 'Top' partition to encompass the data
      # Depth: Top is the surface (min depth). We subtract buffer to stay above it.
      # Height: Top is the summit (max height). We add buffer to stay above it.
      if (z_scale == "depth") {
        top_z <- min(z_vals) - buffer
      } else {
        top_z <- max(z_vals) + buffer
      }

      data.frame(
        site = s,
        height = top_z,
        partition = paste0("Top_", s),
        sedRatePartition = paste0("Top_", s),
        stringsAsFactors = FALSE
      )
    })

    parts_df <- do.call(rbind, parts_list)
    if (!is.null(parts_df)) {
      colnames(parts_df)[1:2] <- c(site_col, z_col)
    }
    return(parts_df)
  }

  # New logic to ensure partitions exist without duplicating them
  ensureTopPartitionsWithBuffer <- function(current_parts) {
    # If we are reloading saved data, DO NOT recalculate or add buffer.
    if (isTRUE(r$loadedSavedDataset)) return(current_parts)

    # If no partitions exist at all, generate the basics
    if (is.null(current_parts) || nrow(current_parts) == 0) {
      return(createBasicPartitions(
        df = r$dataset,
        site_col = siteColumn(),
        z_col = zColumn(),
        z_scale = input$dataScale %||% "depth"
      ))
    }

    return(current_parts)
  }


  # Reactive function to update basic partitions when data or scale changes
  observeEvent({
    r$dataset
    input$dataScale
    siteColumn()
    zColumn()
  }, {
    # Only update if we have valid data and columns
    if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
        siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
      # Recreate basic partitions from current data
      r$parts_df_basic <- createBasicPartitions(
        df = r$dataset,
        site_col = siteColumn(),
        z_col = zColumn(),
        z_scale = input$dataScale %||% "depth"
      )
    } else {
      r$parts_df_basic <- NULL
    }
  }, ignoreInit = TRUE)

  # Auto-add 1 middle partition per site on a fresh data load so the default
  # experience has one internal boundary per site (two partitions total).
  # Skips saved datasets and never overwrites user-added partitions.
  .maybeAutoAddMiddlePartitions <- function() {
    if (isTRUE(r$loadedSavedDataset)) return(invisible(NULL))
    if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0L) return(invisible(NULL))
    ds <- r$dataset
    sc <- siteColumn(); zc <- zColumn()
    if (is.null(ds) || is.null(sc) || is.null(zc)) return(invisible(NULL))
    if (!(sc %in% colnames(ds)) || !(zc %in% colnames(ds))) return(invisible(NULL))

    sigs <- signalColumns()
    scale <- input$dataScale %||% "depth"

    added <- tryCatch(
      StratoBayes::Partitions(
        signal = ds,
        nStrata = 2L,
        distribute = "StratoSegment",
        siteColumn = sc,
        zColumn = zc,
        zScale = scale,
        signalColumn = sigs
      ),
      error = function(e) {
        # Fall back to a simple midpoint per site when StratoSegment can't run
        sites <- unique(trimws(as.character(ds[[sc]])))
        do.call(rbind, lapply(sites, function(s) {
          zv <- suppressWarnings(as.numeric(ds[[zc]][ds[[sc]] == s]))
          zv <- zv[is.finite(zv)]
          if (length(zv) < 2L) return(NULL)
          mid <- mean(range(zv))
          df_row <- data.frame(
            s,
            mid,
            partition = 1L,
            stringsAsFactors = FALSE
          )
          colnames(df_row)[1:2] <- c(sc, zc)
          df_row
        }))
      }
    )

    if (is.null(added) || !nrow(added)) return(invisible(NULL))

    # Partitions(nStrata = 2) emits 2 rows per site: the interior change point
    # and a data-extent boundary near the section top. Keep only the interior
    # change point (the first row per site) so we add exactly one new
    # partition per site on top of the Top_<site> row already in parts_df_basic.
    if (sc %in% colnames(added)) {
      added <- added[!duplicated(added[[sc]]), , drop = FALSE]
    }

    # Give the auto-added change points a brief, geologically meaningful name
    # per site (Bound1_<site>, Bound2_<site>, ...). Mirrors the existing
    # Top_<site> convention used for the section top boundary.
    if (sc %in% colnames(added)) {
      sites_vec <- as.character(added[[sc]])
      new_names <- character(length(sites_vec))
      for (s in unique(sites_vec)) {
        idx <- which(sites_vec == s)
        new_names[idx] <- paste0("Bound", seq_along(idx), "_", s)
      }
      added$partition <- new_names
    }
    if (!"sedRatePartition" %in% colnames(added)) {
      added$sedRatePartition <- added$partition
    }
    r$parts_df_added <- added

    # Route partition flow through parts_df_added so StratData picks up the
    # auto-added middle boundary without further user action.
    updateSelectInput(session, "partitionSource", selected = "interactive")

    # With >1 partition per site, the partition-aware sedimentation model is
    # usually the sensible default. User can still pick "site" in Advanced Run.
    updateSelectInput(session, "sedModel", selected = "partition")
    invisible(NULL)
  }

  observeEvent({
    r$parts_df_basic
    signalColumns()
  }, {
    if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0L) return()
    .maybeAutoAddMiddlePartitions()
  }, ignoreInit = TRUE)

  # Reactive function to get partition data
  getPartitionData <- reactive({
    # Always access input$nStrata to establish reactive dependency
    # Even if we don't use it, accessing it here ensures the reactive tracks changes
    nStrata_dependency <- input$nStrata

    if (is.null(input$partitionSource) || input$partitionSource == "none") {
      return(NULL)
    }

    # Ensure parts_df_basic exists with proper buffer before processing any partition source
    # This ensures top partitions always exist to cover all signal data
    if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0) {
      if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
          siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
        r$parts_df_basic <- createBasicPartitions(
          df = r$dataset,
          site_col = siteColumn(),
          z_col = zColumn(),
          z_scale = input$dataScale %||% "depth"
        )
      }
    }

    if (input$partitionSource == "auto") {
      # If we have saved partitionData from a saved dataset, use it EXACTLY as saved
      # This preserves the exact partitions that were saved, including Top_ partitions, with no modifications
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0 &&
          isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
        # Return saved partitions exactly as saved - no merging, no filtering, no buffers
        saved_parts <- r$partitionData
        # Just ensure proper ordering and return as-is
        if (nrow(saved_parts) > 0) {
          site_col <- siteColumn()
          z_col <- zColumn()
          if (site_col %in% colnames(saved_parts) && z_col %in% colnames(saved_parts)) {
            saved_parts <- saved_parts[order(match(saved_parts[[site_col]], unique(saved_parts[[site_col]])),
                                             saved_parts[[z_col]]), ]
          }
        }
        return(saved_parts)
      }

      # Otherwise, recalculate partitions based on current nStrata
      # Use the nStrata value  accessed at the top to ensure reactive dependency
      # This ensures the reactive recalculates when nStrata changes
      nStrata_val <- nStrata_dependency

      if (is.null(nStrata_val) || is.na(nStrata_val) || nStrata_val < 1) {
        return(NULL)
      }
      if (is.null(input$distributeMethod)) {
        return(NULL)
      }

      tryCatch({
        # Get the raw data and create partitions
        df <- r$dataset
        if (is.null(df) || is.null(siteColumn()) || is.null(zColumn())) {
          return(NULL)
        }

        # Convert to integer to ensure correct type
        nStrata_int <- as.integer(nStrata_val)

        # Create partitions using StratoBayes Partitions function with ACTUAL column names
        # Partitions() handles depth scale transformation internally, so pass raw data
        parts_df_added <- StratoBayes::Partitions(
          signal = df,
          nStrata = nStrata_int,
          distribute = input$distributeMethod,
          siteColumn = siteColumn(),
          zColumn = zColumn(),
          zScale = input$dataScale,
          signalColumn = signalColumns()
        )

        # Replace Partitions()'s plain 1..N numbering with geologically
        # meaningful per-site names: Bound1_<site>, Bound2_<site>, ...
        sc_nm <- siteColumn()
        if (!is.null(parts_df_added) && nrow(parts_df_added) > 0 &&
            sc_nm %in% colnames(parts_df_added)) {
          sites_vec <- as.character(parts_df_added[[sc_nm]])
          new_names <- character(length(sites_vec))
          for (s in unique(sites_vec)) {
            idx <- which(sites_vec == s)
            new_names[idx] <- paste0("Bound", seq_along(idx), "_", s)
          }
          parts_df_added$partition <- new_names
        }

        # Add the required sedRatePartition column that StratData expects
        parts_df_added$sedRatePartition <- parts_df_added$partition

        # Combine with basic partitions (site tops)
        parts_df_basic <- r$parts_df_basic
        if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
          # Combine: basic partitions + added partitions
          # Remove duplicates (if basic partition matches an added one)
          parts_df_full <- rbind(parts_df_basic, parts_df_added)
          if (nrow(parts_df_full) > 1) {
            site_col <- siteColumn()
            z_col <- zColumn()
            # Order by site and height
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            # Remove duplicates (same site and very close heights)
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {  # Very close heights are duplicates
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
          return(ensureTopPartitionsWithBuffer(parts_df_full))
        } else {
          return(ensureTopPartitionsWithBuffer(parts_df_added))
        }
      }, error = function(e) {
        showNotification(paste("Error creating auto partitions:", e$message), type = "error")
        return(NULL)
      })
    }

    if (input$partitionSource == "interactive") {
      # If loading saved data, use exact saved partitions without modification
      if (isTRUE(r$loadedSavedDataset) && !is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        # Return saved partitions exactly as saved - no merging, no filtering, no buffers
        saved_parts <- r$partitionData
        # Just ensure proper ordering and return as-is
        if (nrow(saved_parts) > 0) {
          site_col <- siteColumn()
          z_col <- zColumn()
          if (site_col %in% colnames(saved_parts) && z_col %in% colnames(saved_parts)) {
            saved_parts <- saved_parts[order(match(saved_parts[[site_col]], unique(saved_parts[[site_col]])),
                                             saved_parts[[z_col]]), ]
          }
        }
        return(saved_parts)
      }

      # Not loading saved data - combine basic partitions with user-added partitions
      parts_df_basic <- r$parts_df_basic
      parts_df_added <- r$parts_df_added

      # If we have added partitions, combine with basic
      if (!is.null(parts_df_added) && nrow(parts_df_added) > 0) {
        if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
          # Combine: basic partitions + added partitions
          parts_df_full <- rbind(parts_df_basic, parts_df_added)
          # Remove duplicates based on site and height (within small tolerance)
          if (nrow(parts_df_full) > 1) {
            site_col <- siteColumn()
            z_col <- zColumn()
            # Order by site and height
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            # Remove duplicates (same site and very close heights)
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {  # Very close heights are duplicates
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
          return(ensureTopPartitionsWithBuffer(parts_df_full))
        } else {
          return(ensureTopPartitionsWithBuffer(parts_df_added))
        }
      } else if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
        # Only basic partitions
        return(ensureTopPartitionsWithBuffer(parts_df_basic))
      } else {
        # Fallback to old partitionData for backward compatibility
        if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
          # Use partitionData as-is (no merging or modification)
          return(r$partitionData)
        }
        return(NULL)
      }
    }

    return(NULL)
  })

  stratData <- reactive({
    req(!is.null(r$dataset),
        !is.null(siteColumn())   && nzchar(siteColumn()),
        !is.null(zColumn())      && nzchar(zColumn()),
        !is.null(signalColumns()) && length(signalColumns()) > 0)

    # LAS mode: StratData requires at least 2 wells; block until user adds more
    if (!is.null(r$lasFolderPath) && !is.null(r$lasFileNames) && length(r$lasFileNames) < 2L) {
      return(NULL)
    }

    # Access partition source and partition data directly to create reactive dependencies
    # This ensures stratData recalculates when partitions are added
    partition_source <- input$partitionSource
    partition_data <- r$partitionData  # Direct access creates dependency

    tryCatch({
      # Use the (optionally) downsampled dataset for the signal input; partition
      # logic above still operates on r$dataset so Top_ partitions stay anchored
      # to the full data range.
      df <- dataForStratData()
      if (is.null(df)) df <- r$dataset
      df[[zColumn()]]    <- suppressWarnings(as.numeric(df[[zColumn()]]))
      df[[siteColumn()]] <- trimws(as.character(df[[siteColumn()]]))

      allSites <- unique(df[[ siteColumn() ]])
      userSel  <- input$loadSiteSelect
      selectSites <- if (is.null(userSel) || length(userSel) == 0 || setequal(userSel, allSites)) NULL else userSel
      # Keep only names that exist (avoids "Subset leaves <2 sites" after rename when input is stale)
      if (!is.null(selectSites)) {
        selectSites <- intersect(selectSites, allSites)
        if (length(selectSites) < 2L) selectSites <- NULL
      }
      # Drop curves that have non-NA values in fewer than 2 of the sites being
      # used for alignment. This avoids the hard StratData error ("at least two
      # sites for each signalColumn need to have non-NA values") when the user
      # merges wells or picks a single-well curve, and keeps any remaining
      # curves available for alignment. Ported from 0.2.1 (cf3494bc).
      effectiveSites <- if (!is.null(selectSites)) selectSites else allSites
      sigColsRequested <- signalColumns()
      sigColsToUse <- sigColsRequested[vapply(sigColsRequested, function(sig) {
        nSitesWithData <- sum(vapply(effectiveSites, function(s) {
          any(!is.na(df[[sig]][df[[siteColumn()]] == s]))
        }, FUN.VALUE = logical(1L)))
        nSitesWithData >= 2L
      }, FUN.VALUE = logical(1L))]
      if (length(sigColsToUse) < length(sigColsRequested)) {
        excluded <- setdiff(sigColsRequested, sigColsToUse)
        showNotification(
          paste("Curve(s) with data in only one well excluded for alignment:",
                paste(excluded, collapse = ", ")),
          type = "message", duration = 6, id = "stratdata-curves-excluded"
        )
      }
      if (length(sigColsToUse) == 0L) {
        showNotification(
          "Each curve needs non-NA values in at least 2 wells. No curve has data in 2+ wells.",
          type = "warning", duration = 10, id = "stratdata-sites"
        )
        return(NULL)
      }

      # If loading from a saved StratData object (from result), use its parts directly
      # This preserves the exact partitions that were saved, including top partitions
      if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedResultName) &&
          grepl("^from-result-", r$currentLoadedResultName) &&
          !is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        # Use saved parts directly from StratData object - don't recalculate
        parts_df <- r$partitionData
      } else {
        # Get partition data (reactive) - this will be recalculated when partition_source or partition_data changes
        # The dependency on partition_data above ensures this reactive recalculates
        parts_df <- getPartitionData()
      }

      StratoBayes::StratData(
        signal       = df,
        siteColumn   = siteColumn(),
        zColumn      = zColumn(),
        signalColumn = sigColsToUse,
        selectSites  = selectSites,
        zScale       = input$dataScale,
        parts        = parts_df,
        referenceSite = referenceSite()
      )
    }, error = function(e) {
      msg <- e$message
      LogMsg("StratData error: ", msg)
      if (grepl("less than two unique", msg, ignore.case = TRUE)) {
        showNotification(
          "Alignment requires at least 2 wells. You have 1 well (e.g. after merging). Add more LAS files or include more wells to continue.",
          type = "warning", duration = 10, id = "stratdata-sites"
        )
      } else if (grepl("each signalColumn need to have non-NA", msg, ignore.case = TRUE)) {
        showNotification(
          "Each curve needs non-NA values in at least 2 wells. One or more curves have data in only one well (e.g. after merging). Exclude that curve or add the other well's data.",
          type = "warning", duration = 10, id = "stratdata-sites"
        )
      } else if (grepl("at least two sites", msg, ignore.case = TRUE)) {
        showNotification(
          "Alignment requires at least 2 wells with data. Check well selection and that each curve has data in 2+ wells.",
          type = "warning", duration = 10, id = "stratdata-sites"
        )
      } else {
        showNotification(paste("StratData error:", msg), type = "error", duration = 8, id = "stratdata-error")
      }
      NULL
    })
  })

  signalValid <- reactive({inherits(stratData(), "StratData")})
  output$signalValid <- signalValid
  outputOptions(output, "signalValid", suspendWhenHidden = FALSE)

  observeEvent(siteColumn(), {
    req(r$dataset); col <- siteColumn(); ds <- r$dataset
    sites <- unique(trimws(as.character(ds[[col]])))

    # Restore persisted site selections if available, otherwise select all
    selectedSites <- if (!is.null(r$persistedSiteSelections) &&
                        all(r$persistedSiteSelections %in% sites)) {
      r$persistedSiteSelections
    } else {
      sites
    }

    updateCheckboxGroupInput(session, "loadSiteSelect", choices  = sites, selected = selectedSites)
    updateCheckboxGroupInput(session, "viewSiteSelect", choices  = sites, selected = selectedSites)

    # Initialize reference site if not set or if current reference site is not in the new sites list
    if (is.null(r$persistedReferenceSite) || !r$persistedReferenceSite %in% sites) {
      if (length(sites) > 0) {
        r$persistedReferenceSite <- sites[1]
      }
    }
  })

  # (viewSiteSelect reset handled by the structural-change branch of the main
  # r$dataset observer above; must NOT fire on in-place mutations like renames.)

  output$previewSignal <- renderPlot({
    req(signalValid()); req(length(input$loadSiteSelect) > 0, length(signalColumns()) > 0)
    sd    <- stratData(); sites <- input$loadSiteSelect; sigs  <- signalColumns()
    oldpar <- par(mfrow = c(length(sigs), length(sites))); on.exit(par(oldpar), add = TRUE)
    plotType <- if (!is.null(input$sigPlotType_load) && !is.na(input$sigPlotType_load)) {
      input$sigPlotType_load
    } else {
      "l"  # default to lines
    }
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      do.call(plot, c(list(x = sd, signal = sig_idx, sites = sites, overridePar = FALSE),
                      list(type = plotType)))
    }
  })

  # View Signal controls and plot (similar to preview but with more controls)
  output$viewPlotControls <- renderUI({
    req(signalValid())
    sites <- stratData()$sites
    sigs  <- signalColumns()

    tagList(
      fluidRow(
        column(3,
               tags$strong("Sites to display", style = "display:block; margin-bottom:6px;"),
               div(class = "strat-checklist",
                   checkboxGroupInput("viewSiteSelect", NULL, choices = sites,
                                      selected = input$viewSiteSelect %||% sites)
               )
        ),
        column(3,
               tags$strong("Signals to display"),
               div(class = "strat-checklist",
                   checkboxGroupInput("viewSignalSelect", NULL, choices = sigs,
                                      selected = input$viewSignalSelect %||% sigs)
               )
        ),
        column(2,
               radioButtons("sigPlotType_view", "Style", c("Pts"="p","Lines"="l","Both"="o"),
                            selected = input$sigPlotType_load, inline = TRUE)
        ),
        column(2, sliderInput("viewCex", "● size", min=0.5, max=5, value=1, step=0.1, width="100%")),
        column(2, sliderInput("viewLwd", "— width", min=0.5, max=5, value=2, step=0.5, width="100%"))
      )
    )
  })

  output$viewSignal <- renderPlot({
    req(signalValid())
    req(length(input$viewSiteSelect) > 0)
    req(length(input$viewSignalSelect) > 0)
    req(!is.null(input$viewCex), !is.null(input$viewLwd))

    sd    <- stratData()
    sites <- intersect(input$viewSiteSelect, sd$sites)
    sigs  <- input$viewSignalSelect
    nSig  <- length(sigs)

    oldp <- par(mfrow = c(nSig, length(sites))); on.exit(par(oldp), add=TRUE)

    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      common  <- list(cex=input$viewCex, lwd=input$viewLwd,
                      type=input$sigPlotType_view %||% input$sigPlotType_load)
      do.call(plot, c(list(x = sd, signal = sig_idx, sites = sites, overridePar = FALSE), common))
    }
  })

  # Helper function to get alpha positions from model parameters
  getAlphaPositions <- function(stratData, alignmentScale, alphaPosition, session = NULL) {
    if (is.null(stratData) || is.null(alignmentScale) || is.null(alphaPosition)) {
      return(NULL)
    }

    tryCatch({
      # Handle "custom" by collecting custom numeric values from inputs
      if (length(alphaPosition) == 1 && alphaPosition == "custom") {
        sites <- stratData$sites
        customValues <- numeric(length(sites))

        if (alignmentScale == "height") {
          customValues[1] <- NA  # Reference site doesn't need value
          inputSites <- sites[-1]
          for (i in seq_along(inputSites)) {
            site <- inputSites[i]
            inputId <- paste0("customAlpha_", site)
            val <- if (!is.null(session)) session$input[[inputId]] else input[[inputId]]
            if (!is.null(val) && !is.na(val)) {
              customValues[i + 1] <- val
            } else {
              # Use middle as default if not provided
              heights <- tryCatch({
                StratoBayes::SignalLookUp(stratData, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                # Ensure heights are finite and valid
                heights <- heights[is.finite(heights) & !is.na(heights)]
                if (length(heights) > 0) {
                  height_range <- range(heights, na.rm = TRUE)
                  if (all(is.finite(height_range)) && diff(height_range) > 0) {
                    customValues[i + 1] <- mean(height_range)
                  } else if (length(heights) > 0) {
                    # Fallback to median if range is invalid
                    customValues[i + 1] <- median(heights, na.rm = TRUE)
                  } else {
                    customValues[i + 1] <- 0
                  }
                } else {
                  customValues[i + 1] <- 0
                }
              } else {
                customValues[i + 1] <- 0
              }
            }
          }
        } else {
          # Age scale - all sites need values
          for (i in seq_along(sites)) {
            site <- sites[i]
            inputId <- paste0("customAlpha_", site)
            val <- if (!is.null(session)) session$input[[inputId]] else input[[inputId]]
            if (!is.null(val) && !is.na(val)) {
              customValues[i] <- val
            } else {
              # Use middle as default
              heights <- tryCatch({
                StratoBayes::SignalLookUp(stratData, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                # Ensure heights are finite and valid
                heights <- heights[is.finite(heights) & !is.na(heights)]
                if (length(heights) > 0) {
                  height_range <- range(heights, na.rm = TRUE)
                  if (all(is.finite(height_range)) && diff(height_range) > 0) {
                    customValues[i] <- mean(height_range)
                  } else if (length(heights) > 0) {
                    # Fallback to median if range is invalid
                    customValues[i] <- median(heights, na.rm = TRUE)
                  } else {
                    customValues[i] <- 0
                  }
                } else {
                  customValues[i] <- 0
                }
              } else {
                customValues[i] <- 0
              }
            }
          }
        }
        resolvedAlphaPos <- customValues
      } else {
        # Use the same logic as StratoBayes to resolve alpha positions
        resolvedAlphaPos <- StratoBayes:::.MatchAlphaPosition(alphaPosition, stratData, alignmentScale, toNumeric = TRUE)
      }

      # Create a named list of alpha positions for each site
      sites <- stratData$sites
      alphaPositions <- list()

      for (i in seq_along(sites)) {
        site <- sites[i]
        if (alignmentScale == "height" && i == 1) {
          # Reference site doesn't have alpha position on height scale
          next
        }
        # For age scale, include site 1; for height scale, skip site 1
        if (alignmentScale == "age" || i > 1) {
          if (i <= length(resolvedAlphaPos) && !is.na(resolvedAlphaPos[i])) {
            alphaPositions[[site]] <- resolvedAlphaPos[i]
          }
        }
      }

      return(alphaPositions)
    }, error = function(e) {
      return(NULL)
    })
  }

  # Plot for Model structure tab - identical to view tab but with alpha positions
  # Helper function to render data signal plots (used by both structureSignal and priorSignal)
  # includeAlphaPositions: show alpha position lines on sites 2, 3, etc.
  # showAlphaPriorMeans: show alpha prior mean lines on site 1 (for prior tab)
  renderDataSignalPlot <- function(includeAlphaPositions = TRUE, showAlphaPriorMeans = FALSE) {
    req(signalValid())

    sd    <- stratData()

    # Use view settings from the data_view module if available, otherwise use defaults
    # Module inputs are namespaced as "dataview-viewSiteSelect", etc.
    moduleSiteSelect <- input[["dataview-viewSiteSelect"]]
    moduleSignalSelect <- input[["dataview-viewSignalSelect"]]
    moduleCex <- input[["dataview-viewCex"]]
    moduleLwd <- input[["dataview-viewLwd"]]
    modulePlotType <- input[["dataview-sigPlotType_view"]]

    # Also check for global inputs (for backward compatibility)
    globalSiteSelect <- input$viewSiteSelect
    globalSignalSelect <- input$viewSignalSelect
    globalCex <- input$viewCex
    globalLwd <- input$viewLwd
    globalPlotType <- input$sigPlotType_view

    # Use module settings if available, otherwise fall back to global, then defaults
    sites <- if (!is.null(moduleSiteSelect) && length(moduleSiteSelect) > 0) {
      intersect(moduleSiteSelect, sd$sites)
    } else if (!is.null(globalSiteSelect) && length(globalSiteSelect) > 0) {
      intersect(globalSiteSelect, sd$sites)
    } else {
      sd$sites
    }

    sigs <- if (!is.null(moduleSignalSelect) && length(moduleSignalSelect) > 0) {
      moduleSignalSelect
    } else if (!is.null(globalSignalSelect) && length(globalSignalSelect) > 0) {
      globalSignalSelect
    } else {
      signalColumns()
    }

    # Filter to only valid signals
    sigs <- intersect(sigs, sd$signalAttr$signalNames)

    nSig  <- length(sigs)

    # Additional safety check: ensure we have sites and signals to plot
    req(length(sites) > 0)
    req(length(sigs) > 0)
    req(nSig > 0)

    # Calculate y-limits from height data (y-axis) across all selected sites for each signal
    # This ensures consistent y-limits across all site plots for the same signal
    all_ylims <- list()
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      # Collect all height values across all selected sites for this signal
      all_heights <- numeric(0)
      for (site_name in sites) {
        # Get height values for this site and signal
        site_heights <- tryCatch({
          StratoBayes::SignalLookUp(sd, "height", site_name, signal = sig_idx, includeNAsignal = FALSE)
        }, error = function(e) NULL)
        if (!is.null(site_heights) && length(site_heights) > 0) {
          all_heights <- c(all_heights, site_heights)
        }
      }
      # Calculate ylim from collected heights
      if (length(all_heights) > 0) {
        ylim_calc <- range(all_heights, na.rm = TRUE)
        # Only use if we have valid finite values
        if (all(is.finite(ylim_calc)) && length(ylim_calc) == 2) {
          all_ylims[[i]] <- ylim_calc
        } else {
          # Invalid values - don't set ylim, let plot.StratData handle it
          all_ylims[[i]] <- NULL
        }
      } else {
        # No height data found - don't set ylim, let plot.StratData handle it
        all_ylims[[i]] <- NULL
      }
    }

    oldp <- par(mfrow = c(nSig, length(sites))); on.exit(par(oldp), add=TRUE)

    # Create mapping from site names to their index numbers (2, 3, 4, etc., where 1 is reference site)
    # This is based on the order in sd$sites, not the order in the selected sites
    all_sites <- sd$sites
    site_number_map <- setNames(seq_along(all_sites), all_sites)  # site name -> index (1, 2, 3, ...)

    # Get alpha positions if we have the necessary inputs and includeAlphaPositions is TRUE
    alphaPositions <- NULL
    if (includeAlphaPositions && !is.null(input$alignmentScale) && !is.null(input$alphaPosition)) {
      alphaPositions <- getAlphaPositions(sd, input$alignmentScale, input$alphaPosition, session)
    }

    # Plot each signal for each site separately to ensure alpha lines appear in correct subplot
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      # Use view style settings from module if available, otherwise use defaults
      # (moduleCex, moduleLwd, etc. are defined above in the reactive)
      common  <- list(
        cex = if (!is.null(moduleCex)) moduleCex else if (!is.null(globalCex)) globalCex else 1,
        lwd = if (!is.null(moduleLwd)) moduleLwd else if (!is.null(globalLwd)) globalLwd else 1,
        type = if (!is.null(modulePlotType)) modulePlotType else if (!is.null(globalPlotType)) globalPlotType else if (!is.null(input$sigPlotType_load)) input$sigPlotType_load else "l"
      )
      # Only add ylim if we calculated valid limits, otherwise let plot.StratData handle it
      if (!is.null(all_ylims[[i]])) {
        common$ylim <- all_ylims[[i]]
      }

      for (j in seq_along(sites)) {
        site <- sites[j]

        # Get the site number from the mapping (1, 2, 3, etc.)
        site_num <- site_number_map[[site]]
        site_title <- if (!is.null(site_num) && is.finite(site_num)) {
          paste0(site, " (", site_num, ")")
        } else {
          site
        }

        # Plot individual site with site number in title
        plot_args <- c(list(x = sd, signal = sig_idx, sites = site, overridePar = FALSE, main = site_title), common)
        do.call(plot, plot_args)

        # Add alpha position line for this specific site (only if includeAlphaPositions is TRUE)
        if (includeAlphaPositions && !is.null(alphaPositions) && site %in% names(alphaPositions) && !is.na(alphaPositions[[site]])) {
          # Get the current plot's coordinates for THIS subplot
          usr <- par("usr")  # [xmin, xmax, ymin, ymax]
          xmax <- usr[2]

          # Draw dotted horizontal line at alpha position
          abline(h = alphaPositions[[site]], lty = 3, col = "grey40", lwd = 2)

          # Add correlation anchor label (Greek alpha) just to the right of the plot border (consistent across all signals)
          # Use a small offset from the right edge of the plot area
          text(x = xmax, y = alphaPositions[[site]],
               labels = expression(alpha), col = "grey40", cex = 1.2,
               pos = 4, xpd = TRUE)  # pos=4 means "to the right"
        }

        # For priorSignal plot: Add alpha prior mean lines on site 1 only
        # These show the mean values of Normal priors for alpha parameters of other sites
        # Only add when showAlphaPriorMeans is TRUE (which means we're in priorSignal)
        if (showAlphaPriorMeans && j == 1 && !is.null(r$alphaPriorMeans)) {
          # Get alpha prior means for sites with Normal priors
          alpha_means <- r$alphaPriorMeans
          if (length(alpha_means) > 0) {
            # Get the current plot's coordinates for THIS subplot (site 1)
            usr <- par("usr")  # [xmin, xmax, ymin, ymax]
            xmax <- usr[2]

            # Add a horizontal dashed line for each alpha prior mean
            for (site_name in names(alpha_means)) {
              mean_val <- alpha_means[[site_name]]
              if (!is.null(mean_val) && is.finite(mean_val)) {
                # Draw dotted horizontal line at alpha prior mean
                abline(h = mean_val, lty = 3, col = "grey40", lwd = 2)

                # Get site number from the mapping (2, 3, 4, etc. for sites after reference)
                # site_name is the actual site name (e.g., "SiteA", "site2", etc.)
                site_num <- site_number_map[[site_name]]
                if (!is.null(site_num) && is.finite(site_num) && site_num >= 2) {
                  # Use the site number directly (2, 3, 4, etc.)
                  label_text <- paste0("", site_num)
                } else {
                  # Fallback: if site not found in mapping, try to extract from name
                  # This should rarely happen, but provides a safety net
                  site_num <- sub("^[^0-9]*", "", site_name)
                  if (nchar(site_num) == 0 || site_num == site_name) {
                    site_num <- sub("^.*site", "", site_name, ignore.case = TRUE)
                    if (nchar(site_num) == 0 || site_num == site_name) {
                      site_num <- site_name
                    }
                  }
                  label_text <- paste0("", site_num)
                }

                # Add label: mu_2, mu_3, etc.
                text(x = xmax, y = mean_val,
                     labels = label_text, col = "grey40", cex = 1.2,
                     pos = 4, xpd = NA)  # pos=4 means "to the right"
              }
            }
          }
        }
      }
    }
  }

  output$structureSignal <- renderPlot({
    # Explicitly depend on alphaPosition and alignmentScale to ensure plot updates
    input$alphaPosition
    input$alignmentScale
    renderDataSignalPlot(includeAlphaPositions = TRUE)
  })

  output$priorSignal <- renderPlot({
    # Explicitly depend on alphaPosition and alignmentScale to ensure plot updates
    input$alphaPosition
    input$alignmentScale
    renderDataSignalPlot(includeAlphaPositions = TRUE, showAlphaPriorMeans = TRUE)  # Show both alpha position lines on sites 2,3,... and alpha prior means on site 1
  })


  # Helper function to normalize partition data structure
  normalizePartitionData <- function(parts_df) {
    if (is.null(parts_df) || nrow(parts_df) == 0) {
      return(data.frame(
        site = character(0),
        height = numeric(0),
        partition = character(0),
        stringsAsFactors = FALSE
      ))
    }
    # Ensure we only have the core columns (remove sedRatePartition if present)
    # We'll add it back when saving
    core_cols <- c("site", "height", "partition")
    if (all(core_cols %in% colnames(parts_df))) {
      return(parts_df[, core_cols, drop = FALSE])
    }
    # If structure is wrong, return empty
    return(data.frame(
      site = character(0),
      height = numeric(0),
      partition = character(0),
      stringsAsFactors = FALSE
    ))
  }

  # Partition creation state - will use actual column names when saving
  partitionState <- reactiveValues(
    data = data.frame(site = character(0), height = numeric(0), partition = character(0)),
    clickData = list(),
    isAddingPartition = FALSE  # Flag to prevent observer from overwriting during partition addition
  )
  showOverwritePartitionsConfirm <- reactiveVal(FALSE)

  # Observer to restore partitionState$data when loading saved partitions
  # This ensures partitions show up in the editable table when reopening the partition modal
  observe({
    # Watch for changes in partitionData and loadedSavedDataset
    r$partitionData
    r$loadedSavedDataset

    # Only restore if we're loading a saved dataset and have partition data
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$partitionData) && nrow(r$partitionData) > 0 &&
        !is.null(siteColumn()) && !is.null(zColumn())) {
      # Convert partitionData to normalized format for partitionState$data
      # partitionState$data uses generic "site" and "height" column names
      parts_for_state <- r$partitionData

      # Convert column names from actual names to generic names
      if (siteColumn() %in% colnames(parts_for_state) && siteColumn() != "site") {
        colnames(parts_for_state)[colnames(parts_for_state) == siteColumn()] <- "site"
      }
      if (zColumn() %in% colnames(parts_for_state) && zColumn() != "height") {
        colnames(parts_for_state)[colnames(parts_for_state) == zColumn()] <- "height"
      }

      # Remove sedRatePartition column if present (not needed for partitionState$data)
      if ("sedRatePartition" %in% colnames(parts_for_state)) {
        parts_for_state$sedRatePartition <- NULL
      }

      # Only update if structure is correct
      if ("site" %in% colnames(parts_for_state) && "height" %in% colnames(parts_for_state) &&
          "partition" %in% colnames(parts_for_state)) {
        partitionState$data <- normalizePartitionData(parts_for_state)
      }
    }
  })

  # Helper to convert partition data to use actual column names
  convertPartitionColumns <- function(parts_df) {
    if (is.null(parts_df) || nrow(parts_df) == 0) {
      return(parts_df)
    }

    # Get actual column names from data
    actual_site_col <- siteColumn()
    actual_z_col <- zColumn()

    if (is.null(actual_site_col) || is.null(actual_z_col)) {
      return(parts_df)
    }

    # If partition data uses generic names, convert to actual names
    if ("site" %in% colnames(parts_df) && actual_site_col != "site") {
      colnames(parts_df)[colnames(parts_df) == "site"] <- actual_site_col
    }
    if ("height" %in% colnames(parts_df) && actual_z_col != "height") {
      colnames(parts_df)[colnames(parts_df) == "height"] <- actual_z_col
    }

    return(parts_df)
  }

  # Helper: apply a site rename everywhere (dataset, partitions, UI state)
  # silent: if TRUE, do not show per-rename notification (e.g. when batching from modal)
  applySiteRename <- function(old_name, new_name, silent = FALSE) {
    sc <- siteColumn()
    if (is.null(sc) || !sc %in% colnames(r$dataset)) return(invisible(NULL))
    new_name <- trimws(as.character(new_name))
    if (new_name == "" || identical(old_name, new_name)) return(invisible(NULL))
    sites_now <- unique(trimws(as.character(r$dataset[[sc]])))
    if (new_name %in% setdiff(sites_now, old_name)) {
      showNotification("New name already used by another well.", type = "warning")
      return(invisible(NULL))
    }
    # Snapshot current column selections before mutating r$dataset, so the
    # triggered renderUI re-run restores them instead of falling back to
    # defaults.
    zc_now   <- zColumn()
    sigs_now <- signalColumns()
    if (!is.null(sc)   && nzchar(sc))          r$persistedColumnSelections$siteColumn    <- sc
    if (!is.null(zc_now) && nzchar(zc_now))    r$persistedColumnSelections$zColumn       <- zc_now
    if (!is.null(sigs_now) && length(sigs_now) > 0) r$persistedColumnSelections$signalColumns <- sigs_now
    # 1) Dataset: replace in site column
    rows <- trimws(as.character(r$dataset[[sc]])) == old_name
    if (any(rows)) r$dataset[[sc]][rows] <- new_name
    # 2) Partition data (site column + Top_old -> Top_new in partition column)
    site_col <- "site"
    part_col <- "partition"
    upd_part <- function(parts_df) {
      if (is.null(parts_df) || nrow(parts_df) == 0) return(parts_df)
      sc_df <- if ("site" %in% colnames(parts_df)) "site" else sc
      if (!sc_df %in% colnames(parts_df)) return(parts_df)
      out <- parts_df
      # 1) Update the site column for matching rows. Coerce factor columns
      # to character first so the new name is not dropped as an unknown level.
      if (is.factor(out[[sc_df]])) out[[sc_df]] <- as.character(out[[sc_df]])
      out[[sc_df]][trimws(as.character(out[[sc_df]])) == old_name] <- new_name
      # 2) Rename auto-generated labels in any partition column.
      #    For rows whose site value is now new_name, strip the auto-prefix
      #    (Top_ or Bound<k>_) off the label and reattach it to new_name. This
      #    is idempotent, tolerant of stale labels, and leaves user-customised
      #    labels (e.g. "Unit A") untouched because they don't match the
      #    auto-prefix regex.
      touched <- trimws(as.character(out[[sc_df]])) == new_name
      rewrite_labels <- function(col) {
        if (is.null(col)) return(col)
        col <- as.character(col)
        if (!any(touched)) return(col)
        # Only rewrite rows that were just renamed AND carry an auto-generated
        # prefix (Top_ or Bound<k>_). User-customised labels are preserved.
        sub_idx <- touched & grepl("^(Top|Bound[0-9]+)_", col, perl = TRUE)
        if (any(sub_idx)) {
          lbls <- col[sub_idx]
          m <- regexpr("^(Top|Bound[0-9]+)_", lbls, perl = TRUE)
          prefixes <- sub("_$", "", regmatches(lbls, m))
          col[sub_idx] <- paste0(prefixes, "_", new_name)
        }
        col
      }
      for (pcol in c("partition", "sedRatePartition")) {
        if (pcol %in% colnames(out)) out[[pcol]] <- rewrite_labels(out[[pcol]])
      }
      out
    }
    r$partitionData <- upd_part(r$partitionData)
    r$parts_df_basic <- upd_part(r$parts_df_basic)
    r$parts_df_added <- upd_part(r$parts_df_added)
    # Temp stores can hold live partition data between "Done" and "Save" in
    # the partition modal flow — update them too so nothing stale survives.
    if (!is.null(r$tempAutoPartitions))       r$tempAutoPartitions       <- upd_part(r$tempAutoPartitions)
    if (!is.null(r$tempPointClickPartitions)) r$tempPointClickPartitions <- upd_part(r$tempPointClickPartitions)
    if (nrow(partitionState$data) > 0 && "site" %in% colnames(partitionState$data)) {
      partitionState$data <- upd_part(partitionState$data)
    }
    # 3) Persisted UI state
    if (!is.null(r$persistedSiteSelections)) {
      r$persistedSiteSelections[r$persistedSiteSelections == old_name] <- new_name
      r$persistedSiteSelections <- unique(r$persistedSiteSelections)
    }
    if (identical(r$persistedReferenceSite, old_name)) r$persistedReferenceSite <- new_name
    # 4) Sync checkbox inputs
    sites_after <- unique(trimws(as.character(r$dataset[[sc]])))
    load_sel <- input$loadSiteSelect
    if (!is.null(load_sel)) {
      load_sel[load_sel == old_name] <- new_name
      load_sel <- unique(load_sel)
      updateCheckboxGroupInput(session, "loadSiteSelect", choices = sites_after, selected = load_sel)
    } else {
      updateCheckboxGroupInput(session, "loadSiteSelect", choices = sites_after, selected = character(0))
    }
    view_sel <- input$viewSiteSelect
    if (!is.null(view_sel)) {
      view_sel[view_sel == old_name] <- new_name
      view_sel <- unique(view_sel)
      updateCheckboxGroupInput(session, "viewSiteSelect", choices = sites_after, selected = view_sel)
    } else {
      updateCheckboxGroupInput(session, "viewSiteSelect", choices = sites_after, selected = character(0))
    }
    if (!silent) showNotification(paste("Renamed well to:", new_name), type = "message", duration = 2)
    invisible(NULL)
  }

  # Show inline "rename wells" panel (no modal)
  observeEvent(input$renameWellsBtn, {
    req(r$dataset, siteColumn())
    sites <- unique(trimws(as.character(r$dataset[[siteColumn()]])))
    if (length(sites) == 0) return()
    r$renameWellsSites <- sites
    r$showRenameWellsPanel <- TRUE
  })

  # Apply renames from inline panel and hide panel
  observeEvent(input$applyRenameWells, {
    sites <- r$renameWellsSites
    if (is.null(sites) || length(sites) == 0) {
      r$showRenameWellsPanel <- FALSE
      r$renameWellsSites <- NULL
      return()
    }
    applied <- 0L
    for (site in sites) {
      sid <- gsub("[^A-Za-z0-9]", "_", site)
      sid <- substr(sid, 1, 80L)
      new_name <- trimws(as.character(input[[paste0("rename_well_", sid)]] %||% ""))
      if (new_name == "" || identical(site, new_name)) next
      applySiteRename(site, new_name, silent = TRUE)
      applied <- applied + 1L
    }
    r$showRenameWellsPanel <- FALSE
    r$renameWellsSites <- NULL
    if (applied > 0L) {
      showNotification(paste("Renamed", applied, "well(s)."), type = "message", duration = 2)
    }
  })

  # Done without applying – just hide panel
  observeEvent(input$renameWellsDoneBtn, {
    r$showRenameWellsPanel <- FALSE
    r$renameWellsSites <- NULL
  })

  # -----------------------------------------------------------------------
  # Rename columns: inline link next to the data preview heading + panel.
  # Renames propagate into r$dataset, partitions, persisted selections.
  # -----------------------------------------------------------------------
  output$renameColumns_ui <- renderUI({
    ds <- r$dataset
    if (is.null(ds) || ncol(ds) == 0L) return(NULL)
    tags$span(
      style = "font-size: 0.9em; color: #666;",
      "(",
      actionLink("renameColumnsBtn", "rename columns"),
      if (ncol(ds) >= 2L) tagList(" | ", actionLink("mergeColumnsBtn", "merge columns")),
      ")"
    )
  })
  outputOptions(output, "renameColumns_ui", suspendWhenHidden = FALSE)

  output$renameColumnsPanel_ui <- renderUI({
    if (!isTRUE(r$showRenameColumnsPanel)) return(tags$div())
    cols <- r$renameColumnsList
    if (is.null(cols) || length(cols) == 0L) return(tags$div())
    rows <- lapply(cols, function(col) {
      cid <- gsub("[^A-Za-z0-9]", "_", col)
      cid <- substr(cid, 1L, 80L)
      tags$div(
        style = "display: inline-block; margin: 0 8px 8px 0; min-width: 180px;",
        textInput(
          inputId = paste0("rename_col_", cid),
          label = col,
          value = col,
          placeholder = "New name",
          width = "100%"
        )
      )
    })
    tags$div(
      style = paste("margin-top: 8px; padding: 10px; border: 1px solid #ddd;",
                    "border-radius: 4px; background: #f9f9f9;"),
      tags$p("Change column names below, then Apply.",
             style = "font-size: 0.9em; margin-bottom: 8px;"),
      tags$div(rows),
      tags$div(
        style = "margin-top: 6px;",
        actionButton("applyRenameColumns", "Apply", class = "btn-primary btn-sm"),
        actionButton("renameColumnsDoneBtn", "Done",
                     class = "btn-default btn-sm", style = "margin-left: 6px;")
      )
    )
  })

  observeEvent(input$renameColumnsBtn, {
    req(r$dataset)
    cols <- colnames(r$dataset)
    if (length(cols) == 0L) return()
    r$renameColumnsList <- cols
    r$showRenameColumnsPanel <- TRUE
  })

  observeEvent(input$renameColumnsDoneBtn, {
    r$showRenameColumnsPanel <- FALSE
    r$renameColumnsList <- NULL
  })

  observeEvent(input$applyRenameColumns, {
    cols <- r$renameColumnsList
    if (is.null(cols) || length(cols) == 0L) {
      r$showRenameColumnsPanel <- FALSE
      r$renameColumnsList <- NULL
      return()
    }
    ds <- r$dataset
    if (is.null(ds)) {
      r$showRenameColumnsPanel <- FALSE
      r$renameColumnsList <- NULL
      return()
    }

    # Build mapping old -> new. Skip unchanged, empty, or duplicates.
    mapping <- character(0)
    for (oldName in cols) {
      cid <- gsub("[^A-Za-z0-9]", "_", oldName)
      cid <- substr(cid, 1L, 80L)
      newName <- trimws(as.character(input[[paste0("rename_col_", cid)]] %||% ""))
      if (!nzchar(newName) || identical(oldName, newName)) next
      mapping[oldName] <- newName
    }
    if (length(mapping) == 0L) {
      r$showRenameColumnsPanel <- FALSE
      r$renameColumnsList <- NULL
      return()
    }

    # Validate: no collision with existing columns (except where we are about
    # to free the old slot via rename) and no duplicate targets.
    currentCols <- colnames(ds)
    projected <- currentCols
    for (i in seq_along(currentCols)) {
      if (currentCols[i] %in% names(mapping)) projected[i] <- mapping[[currentCols[i]]]
    }
    if (anyDuplicated(projected)) {
      dup <- projected[duplicated(projected)][1]
      showNotification(
        paste0("Rename would produce duplicate column name: '", dup, "'. Aborted."),
        type = "error"
      )
      return()
    }

    # Helper that renames any vector of names via the mapping.
    renameVec <- function(x) {
      if (is.null(x) || length(x) == 0L) return(x)
      x <- as.character(x)
      hits <- x %in% names(mapping)
      if (any(hits)) x[hits] <- mapping[x[hits]]
      x
    }
    # Helper that renames the names(df) attribute.
    renameDf <- function(df) {
      if (is.null(df) || !is.data.frame(df) || ncol(df) == 0L) return(df)
      colnames(df) <- renameVec(colnames(df))
      df
    }

    # 1) Rename the dataset itself.
    r$dataset <- renameDf(ds)
    if (!is.null(r$persistedDataset)) {
      r$persistedDataset <- renameDf(r$persistedDataset)
    }

    # 2) Rename partition data frames (column *names* only).
    if (!is.null(r$partitionData))            r$partitionData            <- renameDf(r$partitionData)
    if (!is.null(r$parts_df_basic))           r$parts_df_basic           <- renameDf(r$parts_df_basic)
    if (!is.null(r$parts_df_added))           r$parts_df_added           <- renameDf(r$parts_df_added)
    if (!is.null(r$tempAutoPartitions))       r$tempAutoPartitions       <- renameDf(r$tempAutoPartitions)
    if (!is.null(r$tempPointClickPartitions)) r$tempPointClickPartitions <- renameDf(r$tempPointClickPartitions)

    # 3) Update persisted column selections so the select inputs re-render
    #    with the user's picks preserved under their new names.
    if (!is.null(r$persistedColumnSelections)) {
      r$persistedColumnSelections$siteColumn    <- renameVec(r$persistedColumnSelections$siteColumn)
      r$persistedColumnSelections$zColumn       <- renameVec(r$persistedColumnSelections$zColumn)
      r$persistedColumnSelections$signalColumns <- renameVec(r$persistedColumnSelections$signalColumns)
    }

    # 4) Bump datasetId() so the siteColumn_/zColumn_/signalColumns_ select
    #    inputs re-render with the new column names and (via persisted
    #    selections) keep the same logical picks.
    datasetId(datasetId() + 1L)
    uiTrigger(uiTrigger() + 1L)

    # 5) Refresh preview and hide panel.
    updateDataPreview()
    r$showRenameColumnsPanel <- FALSE
    r$renameColumnsList <- NULL

    showNotification(
      paste0("Renamed ", length(mapping), " column(s)."),
      type = "message", duration = 2
    )
  })

  # -----------------------------------------------------------------------
  # Merge columns: combine two or more columns via row-wise coalesce.
  #   * No conflicts (at most one non-NA per row across selected cols) -> merge
  #   * Conflicts (>=2 non-NA in some rows) -> prompt user to pick which
  #     column's value wins in those rows.
  # -----------------------------------------------------------------------
  output$mergeColumnsPanel_ui <- renderUI({
    if (!isTRUE(r$showMergeColumnsPanel)) return(tags$div())
    ds <- r$dataset
    if (is.null(ds) || ncol(ds) < 2L) return(tags$div())
    cols <- colnames(ds)
    selected <- r$mergeColumnsSelected %||% character(0)
    defaultName <- r$mergeColumnsName %||% ""
    conflictMsg <- r$mergeColumnsConflictMsg
    needsPriority <- isTRUE(r$mergeColumnsNeedsPriority)

    tags$div(
      style = paste("margin-top: 8px; padding: 10px; border: 1px solid #ddd;",
                    "border-radius: 4px; background: #f9f9f9;"),
      tags$p("Combine two or more columns into one. Non-NA values are kept; where all columns are NA, the result is NA.",
             style = "font-size: 0.9em; margin-bottom: 8px;"),
      checkboxGroupInput(
        "mergeColumnsSelect",
        label = "Columns to merge",
        choices = cols,
        selected = selected,
        inline = TRUE
      ),
      textInput(
        "mergeColumnsName",
        label = "Merged column name",
        value = defaultName,
        placeholder = "Name for the merged column",
        width = "100%"
      ),
      if (!is.null(conflictMsg)) {
        tags$div(
          style = "margin: 6px 0; padding: 8px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; font-size: 0.9em;",
          conflictMsg
        )
      },
      if (needsPriority) {
        sel_for_prio <- intersect(r$mergeColumnsSelected, cols)
        radioButtons(
          "mergeColumnsPriority",
          label = "Which column's value should win in conflict rows?",
          choices = sel_for_prio,
          selected = r$mergeColumnsPriority %||% sel_for_prio[1],
          inline = FALSE
        )
      },
      tags$div(
        style = "margin-top: 6px;",
        if (needsPriority) {
          actionButton("confirmMergeColumns", "Confirm merge",
                       class = "btn-primary btn-sm")
        } else {
          actionButton("applyMergeColumns", "Apply",
                       class = "btn-primary btn-sm")
        },
        actionButton("mergeColumnsDoneBtn", "Cancel",
                     class = "btn-default btn-sm",
                     style = "margin-left: 6px;")
      )
    )
  })

  observeEvent(input$mergeColumnsBtn, {
    req(r$dataset)
    r$showMergeColumnsPanel <- TRUE
    r$mergeColumnsSelected <- character(0)
    r$mergeColumnsName <- ""
    r$mergeColumnsConflictMsg <- NULL
    r$mergeColumnsNeedsPriority <- FALSE
    r$mergeColumnsPriority <- NULL
  })

  observeEvent(input$mergeColumnsDoneBtn, {
    r$showMergeColumnsPanel <- FALSE
    r$mergeColumnsSelected <- NULL
    r$mergeColumnsName <- NULL
    r$mergeColumnsConflictMsg <- NULL
    r$mergeColumnsNeedsPriority <- FALSE
    r$mergeColumnsPriority <- NULL
  })

  # Keep reactive state in sync with the input widgets so edits survive re-renders
  # (textInput value survives naturally; checkboxGroupInput re-reads as user toggles).
  observeEvent(input$mergeColumnsSelect, ignoreNULL = FALSE, {
    r$mergeColumnsSelected <- input$mergeColumnsSelect
    # Reset conflict-resolution state whenever selection changes.
    r$mergeColumnsConflictMsg <- NULL
    r$mergeColumnsNeedsPriority <- FALSE
    r$mergeColumnsPriority <- NULL
    # Auto-suggest a name if the user hasn't typed one.
    if (is.null(r$mergeColumnsName) || !nzchar(r$mergeColumnsName)) {
      if (length(input$mergeColumnsSelect) > 0L) {
        updateTextInput(session, "mergeColumnsName",
                        value = input$mergeColumnsSelect[1])
      }
    }
  })
  observeEvent(input$mergeColumnsName, ignoreInit = TRUE, {
    r$mergeColumnsName <- input$mergeColumnsName
  })
  observeEvent(input$mergeColumnsPriority, ignoreInit = TRUE, {
    r$mergeColumnsPriority <- input$mergeColumnsPriority
  })

  # Internal helper: compute the coalesced column and replace the selected
  # columns in the dataset with a single merged column named `newName`.
  .performColumnMerge <- function(ds, cols, newName, priority) {
    # Coalesce in priority order: priority column first, then the others in
    # their original order.
    ordered <- unique(c(priority, setdiff(cols, priority)))
    m <- ds[[ordered[1]]]
    for (oc in ordered[-1]) {
      other <- ds[[oc]]
      # Preserve type of `m` where possible; fall back to ifelse which coerces
      # sensibly if mixed.
      na_idx <- is.na(m)
      if (any(na_idx)) {
        m[na_idx] <- other[na_idx]
      }
    }
    # Rebuild the data frame, placing merged column at position of the first
    # selected column, and dropping all other merged cols.
    all_cols <- colnames(ds)
    first_pos <- min(match(cols, all_cols))
    kept_cols <- setdiff(all_cols, cols)
    keep_order <- all_cols[all_cols %in% kept_cols]
    before_cols <- keep_order[match(keep_order, all_cols) < first_pos]
    after_cols <- setdiff(keep_order, before_cols)
    merged_df <- stats::setNames(data.frame(x = m, stringsAsFactors = FALSE), newName)
    out <- cbind(
      if (length(before_cols)) ds[, before_cols, drop = FALSE] else ds[, 0L, drop = FALSE],
      merged_df,
      if (length(after_cols)) ds[, after_cols, drop = FALSE] else ds[, 0L, drop = FALSE]
    )
    out
  }

  # Validate inputs and either perform the merge immediately (no conflicts) or
  # flip the panel into conflict-resolution mode.
  .tryMergeColumns <- function(priority = NULL) {
    ds <- r$dataset
    if (is.null(ds)) return()
    cols <- input$mergeColumnsSelect
    newName <- trimws(as.character(input$mergeColumnsName %||% ""))
    if (length(cols) < 2L) {
      showNotification("Select at least two columns to merge.", type = "warning")
      return()
    }
    if (!nzchar(newName)) {
      showNotification("Enter a name for the merged column.", type = "warning")
      return()
    }
    # If new name collides with a non-merged existing column, abort.
    if (newName %in% setdiff(colnames(ds), cols)) {
      showNotification(
        paste0("Column '", newName, "' already exists and is not part of the merge. ",
               "Pick a different name."),
        type = "error"
      )
      return()
    }

    # Count conflict rows: rows with non-NA in 2+ selected cols.
    sub <- ds[, cols, drop = FALSE]
    n_non_na <- rowSums(!is.na(sub))
    n_conflicts <- sum(n_non_na >= 2L)

    if (n_conflicts > 0L && is.null(priority)) {
      r$mergeColumnsConflictMsg <- paste0(
        n_conflicts, " row(s) have values in two or more selected columns. ",
        "Choose which column's value should take precedence there — ",
        "the other columns still fill in where the chosen column is NA."
      )
      r$mergeColumnsNeedsPriority <- TRUE
      r$mergeColumnsPriority <- cols[1]
      return()
    }

    if (is.null(priority) || !(priority %in% cols)) priority <- cols[1]

    newDs <- tryCatch(
      .performColumnMerge(ds, cols = cols, newName = newName, priority = priority),
      error = function(e) {
        showNotification(paste("Column merge failed:", conditionMessage(e)),
                         type = "error")
        NULL
      }
    )
    if (is.null(newDs)) return()

    # Mapping old -> new for downstream state (persisted columns, partitions).
    mapping <- stats::setNames(rep(newName, length(cols)), cols)
    renameVec <- function(x) {
      if (is.null(x) || length(x) == 0L) return(x)
      x <- as.character(x)
      hits <- x %in% names(mapping)
      if (any(hits)) x[hits] <- mapping[x[hits]]
      unique(x)
    }
    renameDf <- function(df) {
      if (is.null(df) || !is.data.frame(df) || ncol(df) == 0L) return(df)
      old <- colnames(df)
      hits <- old %in% names(mapping)
      if (any(hits)) old[hits] <- mapping[old[hits]]
      # Drop duplicate columns after rename (keep first occurrence).
      keep <- !duplicated(old)
      df <- df[, keep, drop = FALSE]
      colnames(df) <- old[keep]
      df
    }

    r$dataset <- newDs
    if (!is.null(r$persistedDataset)) {
      r$persistedDataset <- renameDf(r$persistedDataset)
    }
    if (!is.null(r$partitionData))            r$partitionData            <- renameDf(r$partitionData)
    if (!is.null(r$parts_df_basic))           r$parts_df_basic           <- renameDf(r$parts_df_basic)
    if (!is.null(r$parts_df_added))           r$parts_df_added           <- renameDf(r$parts_df_added)
    if (!is.null(r$tempAutoPartitions))       r$tempAutoPartitions       <- renameDf(r$tempAutoPartitions)
    if (!is.null(r$tempPointClickPartitions)) r$tempPointClickPartitions <- renameDf(r$tempPointClickPartitions)

    if (!is.null(r$persistedColumnSelections)) {
      r$persistedColumnSelections$siteColumn    <- renameVec(r$persistedColumnSelections$siteColumn)
      r$persistedColumnSelections$zColumn       <- renameVec(r$persistedColumnSelections$zColumn)
      r$persistedColumnSelections$signalColumns <- renameVec(r$persistedColumnSelections$signalColumns)
    }

    datasetId(datasetId() + 1L)
    uiTrigger(uiTrigger() + 1L)
    updateDataPreview()

    r$showMergeColumnsPanel <- FALSE
    r$mergeColumnsSelected <- NULL
    r$mergeColumnsName <- NULL
    r$mergeColumnsConflictMsg <- NULL
    r$mergeColumnsNeedsPriority <- FALSE
    r$mergeColumnsPriority <- NULL

    msg <- paste0("Merged ", length(cols), " columns into '", newName, "'")
    if (n_conflicts > 0L) {
      msg <- paste0(msg, " (", n_conflicts, " conflict row(s) resolved by '", priority, "')")
    }
    showNotification(paste0(msg, "."), type = "message", duration = 3)
  }

  observeEvent(input$applyMergeColumns, { .tryMergeColumns(priority = NULL) })
  observeEvent(input$confirmMergeColumns, {
    .tryMergeColumns(priority = input$mergeColumnsPriority)
  })

  # When dataScale changes, recreate auto-generated top partitions to match new scale
  # Do not recreate if loading saved data - use saved partitions exactly as saved
  observeEvent(input$dataScale, {
    # Skip if loading saved data - partitions should be preserved exactly as saved
    if (isTRUE(r$loadedSavedDataset)) return()

    # Only recreate if we have auto-generated partitions (just "Top_site" partitions)
    if (!is.null(r$partitionData) && nrow(r$partitionData) > 0 &&
        !is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn())) {
      # Check if these are just default "Top_site" partitions
      parts_df <- r$partitionData
      partition_col <- if ("partition" %in% colnames(parts_df)) "partition" else if ("sedRatePartition" %in% colnames(parts_df)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && all(grepl("^Top_", parts_df[[partition_col]], ignore.case = TRUE))) {
        # These are auto-generated top partitions - recreate based on current raw data
        df <- r$dataset
        sites <- unique(trimws(as.character(df[[siteColumn()]])))

        # Recreate top partitions from current raw data
        # IMPORTANT: If dataScale is "depth", we need to transform heights (multiply by -1)
        # because StratData expects partitions in the transformed coordinate system
        dataScale <- input$dataScale %||% "depth"
        top_partitions <- data.frame(
          site = character(0),
          height = numeric(0),
          partition = character(0),
          stringsAsFactors = FALSE
        )

        for (site in sites) {
          site_data <- df[df[[siteColumn()]] == site, ]
          if (nrow(site_data) > 0) {
            heights <- suppressWarnings(as.numeric(site_data[[zColumn()]]))
            heights <- heights[!is.na(heights)]
            if (length(heights) > 0) {
              height_range <- diff(range(heights))
              # StratData expects raw coordinates; it negates for depth internally.
              # Depth: top = min(depth), partition must be <= min so validation passes.
              # Height: top = max(height), partition must be >= max.
              if (dataScale == "depth") {
                buffer <- max(height_range * 0.001, 0.1, na.rm = TRUE)
                eps <- 1e-10
                top_height_with_buffer <- min(heights) - buffer - eps
                } else {
                buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
                top_height_with_buffer <- max(heights) + buffer
              }

              top_partitions <- rbind(top_partitions, data.frame(
                site = site,
                height = top_height_with_buffer,
                partition = paste0("Top_", site),
                stringsAsFactors = FALSE
              ))
            }
          }
        }

        if (nrow(top_partitions) > 0) {
          # Update with actual column names for saving
          colnames(top_partitions)[colnames(top_partitions) == "site"] <- siteColumn()
          colnames(top_partitions)[colnames(top_partitions) == "height"] <- zColumn()
          top_partitions$sedRatePartition <- top_partitions$partition
          r$partitionData <- top_partitions

          # Also update partitionState if partition modal is open
          if (!is.null(partitionState$data) && nrow(partitionState$data) > 0) {
            # Check if partitionState also has just top partitions
            if (all(grepl("^Top_", partitionState$data$partition, ignore.case = TRUE))) {
              # Convert back to generic names for partitionState
              parts_for_state <- top_partitions
              colnames(parts_for_state)[colnames(parts_for_state) == siteColumn()] <- "site"
              colnames(parts_for_state)[colnames(parts_for_state) == zColumn()] <- "height"
              partitionState$data <- normalizePartitionData(parts_for_state)
            }
          }
        }
      }
    }
  }, ignoreInit = TRUE)

  # Handle "Add Formations / Partitions" – open combined modal (Auto + Point & Click)
  observeEvent(input$addFormationsPartitions, {
    req(!is.null(r$dataset),
        !is.null(siteColumn()) && nzchar(siteColumn()),
        !is.null(zColumn()) && nzchar(zColumn()))
    showOverwritePartitionsConfirm(FALSE)

    updateSelectInput(session, "partitionSource", selected = "interactive")
    df <- r$dataset
    sites <- unique(trimws(as.character(df[[siteColumn()]])))
    updateSelectInput(session, "partitionSite", choices = sites)

    # When loading saved data, use EXACT saved partitions without modification
    # This ensures partitions are displayed exactly as saved, including Top_ partitions
    # Check if partitionState$data is already set (by the observer) - if so, use it
    if (isTRUE(r$loadedSavedDataset) && !is.null(partitionState$data) && nrow(partitionState$data) > 0) {
      # partitionState$data already set by observer - use it as-is
      # No need to modify it
    } else if (isTRUE(r$loadedSavedDataset) && !is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # Use saved partitions exactly as they were saved - no merging, no filtering, no buffers
      parts_df <- r$partitionData
      if (!is.null(parts_df) && nrow(parts_df) > 0) {
        # Convert from actual column names back to generic for editing
        if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
          colnames(parts_df)[colnames(parts_df) == siteColumn()] <- "site"
        }
        if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
          colnames(parts_df)[colnames(parts_df) == zColumn()] <- "height"
        }
        # Remove sedRatePartition column if present (not needed for partitionState$data)
        if ("sedRatePartition" %in% colnames(parts_df)) {
          parts_df$sedRatePartition <- NULL
        }
        # Use saved partitions exactly as saved - normalize structure only
        partitionState$data <- normalizePartitionData(parts_df)
      }
    } else if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # Not loading saved data - use existing partition data
      # Convert from actual column names back to generic for editing
      parts_df <- r$partitionData
      if (!is.null(parts_df) && nrow(parts_df) > 0) {
        if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
          colnames(parts_df)[colnames(parts_df) == siteColumn()] <- "site"
        }
        if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
          colnames(parts_df)[colnames(parts_df) == zColumn()] <- "height"
        }
        # Remove sedRatePartition column if present
        if ("sedRatePartition" %in% colnames(parts_df)) {
          parts_df$sedRatePartition <- NULL
        }
        partitionState$data <- normalizePartitionData(parts_df)
      }
    } else {
        # Initialize with automatic top partitions for each site using CURRENT raw data
        # IMPORTANT: If dataScale is "depth", we need to transform heights (multiply by -1)
        # because StratData expects partitions in the transformed coordinate system
        dataScale <- input$dataScale %||% "depth"
        top_partitions <- data.frame(
          site = character(0),
          height = numeric(0),
          partition = character(0),
          stringsAsFactors = FALSE
        )

        for (site in sites) {
          site_data <- df[df[[siteColumn()]] == site, ]
          if (nrow(site_data) > 0) {
            heights <- suppressWarnings(as.numeric(site_data[[zColumn()]]))
            heights <- heights[!is.na(heights)]
            if (length(heights) > 0) {
              # IMPORTANT: For the "top" partition boundary:
              # On height scale: top = max(height) because height increases upward (0=bottom, 30=top)
              # On depth scale: top = min(depth) because depth increases downward (0=top/surface, 30=bottom)
              # StratData expects partitions in RAW coordinates (positive for depth)
              # StratData will transform them itself (multiply by -1 for depth scale)

              if (dataScale == "depth") {
                # On depth scale: top = min(depth). Partition must be <= min so StratData validation passes.
                top_height <- min(heights)
                height_range <- diff(range(heights))
                buffer <- max(height_range * 0.001, 0.1, na.rm = TRUE)
                eps <- 1e-10
                top_height_with_buffer <- top_height - buffer - eps
                } else {
                # On height scale: top partition is at maximum height
                top_height <- max(heights)
                height_range <- diff(range(heights))
                buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
                top_height_with_buffer <- top_height + buffer
              }

              top_partitions <- rbind(top_partitions, data.frame(
                site = site,
                height = top_height_with_buffer,
                partition = paste0("Top_", site),
                stringsAsFactors = FALSE
              ))
            }
          }
        }

        # Seed modal table with Top_ rows PLUS any auto-added middle partitions
        # (e.g. the default Bound1_<site> change points created on fresh data load)
        # so they are visible and editable alongside Top_ rows.
        initial_parts <- top_partitions
        added <- r$parts_df_added
        if (!is.null(added) && nrow(added) > 0 &&
            !is.null(siteColumn()) && siteColumn() %in% colnames(added) &&
            !is.null(zColumn())    && zColumn()    %in% colnames(added) &&
            "partition" %in% colnames(added)) {
          added_norm <- data.frame(
            site      = as.character(added[[siteColumn()]]),
            height    = as.numeric(added[[zColumn()]]),
            partition = as.character(added$partition),
            stringsAsFactors = FALSE
          )
          initial_parts <- rbind(initial_parts, added_norm)
        }
        partitionState$data <- initial_parts

        # Ensure parts_df_basic is set with the top partitions
        # This ensures the top partition is always included when saving
        if (nrow(top_partitions) > 0 && !is.null(siteColumn()) && !is.null(zColumn())) {
          # Convert to use actual column names
          parts_df_basic_formatted <- top_partitions
          colnames(parts_df_basic_formatted)[colnames(parts_df_basic_formatted) == "site"] <- siteColumn()
          colnames(parts_df_basic_formatted)[colnames(parts_df_basic_formatted) == "height"] <- zColumn()
          # Add sedRatePartition column
          if (!"sedRatePartition" %in% colnames(parts_df_basic_formatted)) {
            parts_df_basic_formatted$sedRatePartition <- parts_df_basic_formatted$partition
          }
          r$parts_df_basic <- parts_df_basic_formatted
        }

        # Also update r$partitionData if it was just default partitions
        if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
          # Clear the old partition data since we're recreating
          r$partitionData <- NULL
        }
    }

    showModal(formationsPartitionsModal())
  })

  # Handle partition plot clicks
  observeEvent(input$partitionClick, {
    req(input$partitionClick, input$partitionSite)

    # Shiny click coordinates are already in data coordinates
    # plot.StratData plots: x = signal, y = height
    # IMPORTANT: The plot shows StratData's transformed coordinates (negative for depth)
    # But StratData will transform partitions again, so we need RAW coordinates
    # Therefore, we must UNTRANSFORM the click coordinates if depth scale is used
    if (!is.null(input$partitionClick$y) && !is.na(input$partitionClick$y)) {
      # Y coordinate is height from plot (in StratData's transformed coordinate system)
      clickHeight_transformed <- input$partitionClick$y
      clickSignal <- input$partitionClick$x

      # Get data scale - if depth, StratData has already transformed (multiplied by -1)
      # So we need to untransform (multiply by -1) to get raw coordinates
      dataScale <- input$dataScale %||% "depth"
      if (dataScale == "depth") {
        # Plot shows transformed (negative) coordinates, but we need raw (positive) for StratData
        clickHeight_raw <- clickHeight_transformed * -1
      } else {
        clickHeight_raw <- clickHeight_transformed
      }

      partitionState$clickData <- list(
        x = clickSignal,
        y = clickHeight_raw,  # Store in RAW coordinates (StratData will transform)
        site = input$partitionSite
      )

      showNotification(paste("Click recorded at height:", round(clickHeight_transformed, 2),
                            "- Enter a partition name and click 'Add Partition Top' to save"),
                      type = "message", duration = 3)
    }
  })

  # Handle brush events for click & drag
  observeEvent(input$partitionBrush, {
    req(input$partitionBrush, input$partitionSite)

    # Store brush data - use Y coordinate for height (plot.StratData: x=signal, y=height)
    # IMPORTANT: Plot shows StratData's transformed coordinates, but we need RAW coordinates
    if (!is.null(input$partitionBrush$ymin) && !is.na(input$partitionBrush$ymin)) {
      # Use the middle of the brush Y coordinate for height (in transformed coordinates)
      brushHeight_transformed <- (input$partitionBrush$ymin + input$partitionBrush$ymax) / 2
      brushSignal <- (input$partitionBrush$xmin + input$partitionBrush$xmax) / 2

      # Untransform if depth scale (plot shows transformed, but we need raw for StratData)
      dataScale <- input$dataScale %||% "depth"
      if (dataScale == "depth") {
        brushHeight_raw <- brushHeight_transformed * -1
      } else {
        brushHeight_raw <- brushHeight_transformed
      }

      partitionState$clickData <- list(
        x = brushSignal,
        y = brushHeight_raw,  # Store in RAW coordinates (StratData will transform)
        site = input$partitionSite
      )

      showNotification(paste("Drag recorded at height:", round(brushHeight_transformed, 2),
                            "- Enter a partition name and click 'Add Partition Top' to save"),
                      type = "message", duration = 3)
    }
  })

  # Handle adding a partition
  observeEvent(input$addPartition, {
    req(input$partitionSite)

    # Set flag to prevent observer from overwriting names during addition
    partitionState$isAddingPartition <- TRUE
    on.exit(partitionState$isAddingPartition <- FALSE)

    # Check for partition name first
    partition_name <- trimws(input$partitionName %||% "")
    if (!nzchar(partition_name)) {
      showNotification("Please enter a partition name", type = "warning")
      return()
    }

    # Parse manual height (single value)
    manual_height <- tryCatch({
      as.numeric(trimws(input$manualHeight))
    }, error = function(e) {
      showNotification("Invalid height format. Enter a single number.", type = "error")
      return(NULL)
    })

    # Use manual height if provided; otherwise fall back to clickData
    if (!is.null(manual_height) && !is.na(manual_height)) {

      # Ensure partitionState$data has the correct structure
      partitionState$data <- normalizePartitionData(partitionState$data)

      dataScale <- input$dataScale %||% "depth"

      # Convert to RAW coords for storage when depth scale is used
      if (dataScale == "depth" && manual_height < 0) {
        height_raw <- abs(manual_height)
      } else {
        height_raw <- manual_height
      }

      newRow <- data.frame(
        site = input$partitionSite,
        height = height_raw,
        partition = partition_name,
        stringsAsFactors = FALSE
      )

      partitionState$data <- normalizePartitionData(partitionState$data)
      partitionState$data <- rbind(partitionState$data, newRow)

      updateTextInput(session, "manualHeight", value = "")
      showNotification(
        paste("Partition top added at", manual_height),
        type = "message"
      )

    } else if (!is.null(partitionState$clickData) &&
               !is.null(partitionState$clickData$y) &&
               !is.null(partitionState$clickData$site) &&
               partitionState$clickData$site == input$partitionSite) {

      clickHeight <- partitionState$clickData$y
      dataScale <- input$dataScale %||% "depth"

      # Safety: enforce RAW positive depths
      if (dataScale == "depth" && clickHeight < 0) clickHeight <- -clickHeight

      partitionState$data <- normalizePartitionData(partitionState$data)

      newRow <- data.frame(
        site = input$partitionSite,
        height = clickHeight,
        partition = partition_name,
        stringsAsFactors = FALSE
      )

      partitionState$data <- rbind(partitionState$data, newRow)
      partitionState$clickData <- list()

      showNotification(
        paste("Partition top", partition_name, "added at height", round(clickHeight, 2)),
        type = "message"
      )

    } else {
      showNotification(
        "Please click on the plot first, then enter a partition name and click 'Add Partition Top'",
        type = "warning"
      )
    }
  })

  # Handle clearing all partitions (but preserve top boundaries)
  observeEvent(input$clearPartitions, {
    # Clear user-added partitions (parts_df_added), but keep basic partitions (parts_df_basic)
    # This should only clear parts_df_added, and force recalculation of parts_df_basic
    r$parts_df_added <- NULL

    # Force recalculation of parts_df_basic by triggering the observer
    # The observer will automatically update parts_df_basic based on current data and scale
    if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
        siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
      # Recreate basic partitions from current data
      r$parts_df_basic <- createBasicPartitions(
        df = r$dataset,
        site_col = siteColumn(),
        z_col = zColumn(),
        z_scale = input$dataScale %||% "depth"
      )
    }

    # Update partitionState$data to only show basic partitions (for modal display)
    if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
      # Convert to generic names for partitionState
      parts_for_state <- r$parts_df_basic
      if (siteColumn() %in% colnames(parts_for_state)) {
        colnames(parts_for_state)[colnames(parts_for_state) == siteColumn()] <- "site"
      }
      if (zColumn() %in% colnames(parts_for_state)) {
        colnames(parts_for_state)[colnames(parts_for_state) == zColumn()] <- "height"
      }
      partitionState$data <- normalizePartitionData(parts_for_state)
    } else {
      partitionState$data <- data.frame(
        site = character(0),
        height = numeric(0),
        partition = character(0),
        stringsAsFactors = FALSE
      )
    }

    showNotification("User-added partitions cleared (top boundaries preserved)", type = "message")
  })

  # Store original partition data before modifications (for discard functionality)
  originalPartitionData <- reactiveVal(NULL)

  # Handle done button - show save/discard prompt
  observeEvent(input$donePartitions, {
    removeModal()
    partitionState$data <- normalizePartitionData(partitionState$data)

    # Copy to temp storage (like auto partitions) - partitionState can be unreliable when save modal is shown
    r$tempPointClickPartitions <- as.data.frame(partitionState$data)

    # Store current partition data as original (for discard)
    originalPartitionData(r$partitionData)

    # Save column selections and other settings BEFORE showing save modal
    # This ensures they're preserved when the modal closes
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Show save/discard modal
    partitionCount <- nrow(partitionState$data)
    currentDatasetName <- if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
      r$currentLoadedDatasetName
    } else {
      NULL
    }
    showModal(partitionSaveModal(partitionCount, currentDatasetName))
  })

  # Handle save partitions button (for both point & click and auto partitions)
  observeEvent(input$savePartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)
    isPointClickPartitions <- !is.null(r$tempPointClickPartitions)

    if (isAutoPartitions) {
      # This is auto partitions
      # Extract only the non-basic partitions (exclude "Top_" partitions) and save to parts_df_added
      auto_parts <- r$tempAutoPartitions
      if (!is.null(auto_parts) && nrow(auto_parts) > 0) {
        # Filter out basic "Top_" partitions - only keep user-created auto partitions
        partition_col <- if ("partition" %in% colnames(auto_parts)) "partition" else if ("sedRatePartition" %in% colnames(auto_parts)) "sedRatePartition" else NULL
        if (!is.null(partition_col)) {
          # Keep only partitions that are NOT "Top_" partitions
          non_basic_mask <- !grepl("^Top_", auto_parts[[partition_col]], ignore.case = TRUE)
          if (any(non_basic_mask)) {
            # Save non-basic partitions to parts_df_added
            r$parts_df_added <- auto_parts[non_basic_mask, , drop = FALSE]
          } else {
            # If all are basic partitions, clear parts_df_added
            r$parts_df_added <- NULL
          }
        } else {
          # If no partition column, save all
          r$parts_df_added <- auto_parts
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      # Ensure parts_df_basic exists (top partitions) - recreate if missing
      if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0) {
        if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
            siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
          r$parts_df_basic <- createBasicPartitions(
            df = r$dataset,
            site_col = siteColumn(),
            z_col = zColumn(),
            z_scale = input$dataScale %||% "depth"
          )
        }
      }

      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # If parts_df_full is NULL or empty, this will cause StratData error
      # Ensure we always have at least the basic top partitions
      if (is.null(parts_df_full) || nrow(parts_df_full) == 0) {
        if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
          parts_df_full <- r$parts_df_basic
        } else {
          # Last resort: recreate basic partitions
          if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
              siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
            parts_df_full <- createBasicPartitions(
              df = r$dataset,
              site_col = siteColumn(),
              z_col = zColumn(),
              z_scale = input$dataScale %||% "depth"
            )
          }
        }
      }

      # Add sedRatePartition column if needed
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      r$partitionData <- parts_df_full
      r$tempAutoPartitions <- NULL
      partitionSource <- "auto"
    } else if (isPointClickPartitions) {
      # This is point & click partitions - use temp storage (same pattern as auto)
      point_click_data <- normalizePartitionData(r$tempPointClickPartitions)

      # Convert to use actual column names from data (not hardcoded "site", "height")
      if (nrow(point_click_data) > 0 && !is.null(siteColumn()) && !is.null(zColumn())) {
        colnames(point_click_data)[colnames(point_click_data) == "site"] <- siteColumn()
        colnames(point_click_data)[colnames(point_click_data) == "height"] <- zColumn()
      }

      # Filter out basic "Top_" partitions - only keep user-added partitions
      partition_col <- if ("partition" %in% colnames(point_click_data)) "partition" else if ("sedRatePartition" %in% colnames(point_click_data)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && nrow(point_click_data) > 0) {
        non_basic_mask <- !grepl("^Top_", point_click_data[[partition_col]], ignore.case = TRUE)
        if (any(non_basic_mask)) {
          user_added_parts <- point_click_data[non_basic_mask, , drop = FALSE]
          if (!"sedRatePartition" %in% colnames(user_added_parts)) {
            user_added_parts$sedRatePartition <- user_added_parts[[partition_col]]
          }
          r$parts_df_added <- user_added_parts
        } else {
          r$parts_df_added <- NULL
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # Add the required sedRatePartition column that StratData expects
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      # Save combined partition data to reactive values
      r$partitionData <- parts_df_full
      partitionSource <- "interactive"
      r$tempPointClickPartitions <- NULL
    } else {
      removeModal()
      showNotification("Partition data was lost. Please add partitions again and click Done.", type = "error")
      return()
    }

    # IMPORTANT: Save all current settings to preserve them
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Save partition source to persisted settings
    r$persistedPartitionSource <- partitionSource

    # Get save name (or generate one)
    saveName <- trimws(input$savePartitionDataName)
    if (is.null(saveName) || nchar(saveName) == 0) {
      saveName <- paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
    }

    # Save the data with partitions
    dataState <- list(
      dataset = r$dataset,
      siteColumn = siteColumn(),
      zColumn = zColumn(),
      signalColumns = signalColumns(),
      siteSelections = input$loadSiteSelect,
      dataSource = input$dataSource,
      dataScale = input$dataScale,
      partitionSource = partitionSource,
      partitionData = r$partitionData,
      parts_df_added = r$parts_df_added,  # Save user-added partitions separately
      parts_df_basic = r$parts_df_basic,  # Save basic partitions (Top_ partitions)
      referenceSite = r$persistedReferenceSite  # Save reference site selection
    )

    r$savedDatasets[[saveName]] <- dataState
    r$currentLoadedDatasetName <- saveName
    r$loadedSavedDataset <- TRUE
    r$lastSavedDataHash <- digest::digest(dataState)

    # Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state and prevents issues with partition source
    shinyjs::delay(200, {
      # Restore all settings from the saved dataset
      if (!is.null(dataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- dataState$siteColumn
      }
      if (!is.null(dataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- dataState$zColumn
      }
      if (!is.null(dataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- dataState$signalColumns
      }
      if (!is.null(dataState$dataset)) {
        r$dataset <- dataState$dataset
        r$persistedDataset <- dataState$dataset
      }
      if (!is.null(dataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
        r$persistedDataScale <- dataState$dataScale
      }
      if (!is.null(dataState$partitionSource) && dataState$partitionSource %in% c("none", "auto", "interactive")) {
        updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
        r$persistedPartitionSource <- dataState$partitionSource
      }
      # Restore partition data AFTER setting loadedSavedDataset flag
      # This ensures getPartitionData() knows to use saved data instead of recalculating
      if (!is.null(dataState$partitionData)) {
        r$partitionData <- dataState$partitionData
      }
      if (!is.null(dataState$parts_df_added)) {
        r$parts_df_added <- dataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }
      # Restore parts_df_basic from saved data, or recalculate if not saved
      if (!is.null(dataState$parts_df_basic)) {
        r$parts_df_basic <- dataState$parts_df_basic
      } else {
        # Recalculate basic partitions from current data
        if (!is.null(dataState$dataset) && !is.null(dataState$siteColumn) && !is.null(dataState$zColumn)) {
          r$parts_df_basic <- createBasicPartitions(
            df = dataState$dataset,
            site_col = dataState$siteColumn,
            z_col = dataState$zColumn,
            z_scale = dataState$dataScale %||% "depth"
          )
        }
      }
      # Restore reference site if saved
      if (!is.null(dataState$referenceSite)) {
        r$persistedReferenceSite <- dataState$referenceSite
      }
      # The observer will handle this automatically when data/scale changes
      if (!is.null(dataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
        r$persistedSiteSelections <- dataState$siteSelections
      }
    })

    # Close ONLY the save modal (partitionSaveModal)
    # For auto partitions, the main modal should stay open
    # For point & click, close both modals and reopen main modal
    if (isAutoPartitions) {
      # Auto partitions: close save modal, then explicitly ensure main modal is visible
      # Use same pattern as point & click - close modal then show main modal
      removeModal()  # Close partitionSaveModal (topmost modal)
      # Explicitly show main modal to ensure it's visible (similar to point & click)
      # This ensures the main modal is definitely open and visible
      shinyjs::delay(50, {
        showModal(modelSelectionModal())
      })
    } else {
      # Point & click: close save modal and reopen main modal (formations modal already closed when save was shown)
      removeModal()  # Close partitionSaveModal
      showModal(modelSelectionModal())  # Reopen main modal
    }

    # Restore settings after modal is shown (only if partition modal was open)
    if (!isAutoPartitions) {
      shinyjs::delay(100, {
        # Restore dataset first
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }

        # Restore partition source
        updateSelectInput(session, "partitionSource", selected = partitionSource)
        r$persistedPartitionSource <- partitionSource

        # Restore dataScale
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Restore column selections - CRITICAL for non-standard column names
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }

        # Restore site selections
        if (!is.null(r$persistedSiteSelections)) {
          updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
        }

        # Restore data source if available
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        }

        # Restore data scale if available
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Clear the restoration flag after UI updates complete
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })
    } else {
      # For auto partitions, just update the partition source and restore column selections
      # Don't close the main modal - stay in load screen
      updateSelectInput(session, "partitionSource", selected = partitionSource)
      r$persistedPartitionSource <- partitionSource

      # IMPORTANT: Restore dataScale for auto partitions
      if (!is.null(r$persistedDataScale)) {
        updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
      }

      # Restore column selections to prevent deselection
      shinyjs::delay(100, {
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }
        # Also restore dataScale again after column selections (in case it got reset)
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })
    }

    partitionCount <- if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) nrow(r$partitionData) else 0L

    showNotification(paste("Data saved as:", saveName, "with", partitionCount, "partition boundary(ies)."),
                    type = "message", duration = 5)
  })

  # Handle overwrite partitions button
  observeEvent(input$overwritePartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)
    isPointClickPartitions <- !is.null(r$tempPointClickPartitions)

    if (isAutoPartitions) {
      # This is auto partitions
      # Extract only the non-basic partitions (exclude "Top_" partitions) and save to parts_df_added
      auto_parts <- r$tempAutoPartitions
      if (!is.null(auto_parts) && nrow(auto_parts) > 0) {
        # Filter out basic "Top_" partitions - only keep user-created auto partitions
        partition_col <- if ("partition" %in% colnames(auto_parts)) "partition" else if ("sedRatePartition" %in% colnames(auto_parts)) "sedRatePartition" else NULL
        if (!is.null(partition_col)) {
          # Keep only partitions that are NOT "Top_" partitions
          non_basic_mask <- !grepl("^Top_", auto_parts[[partition_col]], ignore.case = TRUE)
          if (any(non_basic_mask)) {
            # Replace parts_df_added with new auto partitions
            r$parts_df_added <- auto_parts[non_basic_mask, , drop = FALSE]
          } else {
            # If all are basic partitions, clear parts_df_added
            r$parts_df_added <- NULL
          }
        } else {
          # If no partition column, save all
          r$parts_df_added <- auto_parts
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      # Ensure parts_df_basic exists (top partitions) - recreate if missing
      if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0) {
        if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
            siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
          r$parts_df_basic <- createBasicPartitions(
            df = r$dataset,
            site_col = siteColumn(),
            z_col = zColumn(),
            z_scale = input$dataScale %||% "depth"
          )
        }
      }

      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # If parts_df_full is NULL or empty, this will cause StratData error
      # Ensure we always have at least the basic top partitions
      if (is.null(parts_df_full) || nrow(parts_df_full) == 0) {
        if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
          parts_df_full <- r$parts_df_basic
        } else {
          # Last resort: recreate basic partitions
          if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
              siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
            parts_df_full <- createBasicPartitions(
              df = r$dataset,
              site_col = siteColumn(),
              z_col = zColumn(),
              z_scale = input$dataScale %||% "depth"
            )
          }
        }
      }

      r$partitionData <- parts_df_full
      r$tempAutoPartitions <- NULL
      partitionSource <- "auto"
    } else if (isPointClickPartitions) {
      # This is point & click partitions - use temp storage (same pattern as savePartitions)
      point_click_data <- normalizePartitionData(r$tempPointClickPartitions)

      # Convert to use actual column names from data (not hardcoded "site", "height")
      if (nrow(point_click_data) > 0 && !is.null(siteColumn()) && !is.null(zColumn())) {
        colnames(point_click_data)[colnames(point_click_data) == "site"] <- siteColumn()
        colnames(point_click_data)[colnames(point_click_data) == "height"] <- zColumn()
      }

      # Filter out basic "Top_" partitions - only keep user-added partitions
      partition_col <- if ("partition" %in% colnames(point_click_data)) "partition" else if ("sedRatePartition" %in% colnames(point_click_data)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && nrow(point_click_data) > 0) {
        non_basic_mask <- !grepl("^Top_", point_click_data[[partition_col]], ignore.case = TRUE)
        if (any(non_basic_mask)) {
          user_added_parts <- point_click_data[non_basic_mask, , drop = FALSE]
          # Add sedRatePartition column
          if (!"sedRatePartition" %in% colnames(user_added_parts)) {
            user_added_parts$sedRatePartition <- user_added_parts[[partition_col]]
          }
          r$parts_df_added <- user_added_parts
        } else {
          # If all are basic partitions, clear parts_df_added
          r$parts_df_added <- NULL
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      # Ensure parts_df_basic exists (top partitions) - recreate if missing
      if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0) {
        if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
            siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
          r$parts_df_basic <- createBasicPartitions(
            df = r$dataset,
            site_col = siteColumn(),
            z_col = zColumn(),
            z_scale = input$dataScale %||% "depth"
          )
        }
      }

      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # If parts_df_full is NULL or empty, this will cause StratData error
      # Ensure we always have at least the basic top partitions
      if (is.null(parts_df_full) || nrow(parts_df_full) == 0) {
        if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
          parts_df_full <- r$parts_df_basic
        } else {
          # Last resort: recreate basic partitions
          if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
              siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
            parts_df_full <- createBasicPartitions(
              df = r$dataset,
              site_col = siteColumn(),
              z_col = zColumn(),
              z_scale = input$dataScale %||% "depth"
            )
          }
        }
      }

      # Add the required sedRatePartition column that StratData expects
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      # Save combined partition data to reactive values
      r$partitionData <- parts_df_full
      partitionSource <- "interactive"
      r$tempPointClickPartitions <- NULL
    } else {
      removeModal()
      showNotification("Partition data was lost. Please add partitions again and click Done.", type = "error")
      return()
    }

    # IMPORTANT: Save all current settings to preserve them
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Save partition source to persisted settings
    r$persistedPartitionSource <- partitionSource

    # Check if we have a current loaded dataset name to overwrite
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
      # Overwrite the existing saved dataset
      dataState <- list(
        dataset = r$dataset,
        siteColumn = siteColumn(),
        zColumn = zColumn(),
        signalColumns = signalColumns(),
        siteSelections = input$loadSiteSelect,
        dataSource = input$dataSource,
        dataScale = input$dataScale,
        partitionSource = partitionSource,
        partitionData = r$partitionData,
        parts_df_added = r$parts_df_added,  # Save user-added partitions separately
        parts_df_basic = r$parts_df_basic  # Save basic partitions (Top_ partitions)
      )

      r$savedDatasets[[r$currentLoadedDatasetName]] <- dataState
      r$lastSavedDataHash <- digest::digest(dataState)

    # Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state and prevents issues with partition source
    # IMPORTANT: Restore partitionData FIRST, before partitionSource, to prevent getPartitionData() from recalculating
    shinyjs::delay(200, {
      # Restore partition data FIRST (before partitionSource) to prevent recalculation
      if (!is.null(dataState$partitionData)) {
        r$partitionData <- dataState$partitionData
      }
      if (!is.null(dataState$parts_df_added)) {
        r$parts_df_added <- dataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }

      # Then restore other settings
      if (!is.null(dataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- dataState$siteColumn
      }
      if (!is.null(dataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- dataState$zColumn
      }
      if (!is.null(dataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- dataState$signalColumns
      }
      if (!is.null(dataState$dataset)) {
        r$dataset <- dataState$dataset
        r$persistedDataset <- dataState$dataset
      }
      if (!is.null(dataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
        r$persistedDataScale <- dataState$dataScale
      }
      # Restore partitionSource AFTER partitionData to ensure getPartitionData() uses saved data
      if (!is.null(dataState$partitionSource) && dataState$partitionSource %in% c("none", "auto", "interactive")) {
        updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
        r$persistedPartitionSource <- dataState$partitionSource
      }
      if (!is.null(dataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
        r$persistedSiteSelections <- dataState$siteSelections
      }
    })

      partitionCount <- if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) nrow(r$partitionData) else 0L

      showNotification(paste("Data overwritten:", r$currentLoadedDatasetName, "with", partitionCount, "partition boundary(ies)."),
                      type = "message", duration = 5)

      # Close ONLY the save modal (partitionSaveModal)
      if (isAutoPartitions) {
        # Auto partitions: close save modal, then explicitly show main modal
        removeModal()  # Close partitionSaveModal (topmost modal)
        # Explicitly show main modal to ensure it's visible
        shinyjs::delay(50, {
          showModal(modelSelectionModal())
          # Restore dataScale after modal is shown
          shinyjs::delay(100, {
            if (!is.null(r$persistedDataScale)) {
              updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
            }
          })
        })
      } else {
        removeModal()  # Close partitionSaveModal (formations modal already closed)
        showModal(modelSelectionModal())  # Reopen main modal
        # Restore dataScale after modal is shown
        shinyjs::delay(100, {
          if (!is.null(r$persistedDataScale)) {
            updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
          }
        })
      }
    } else {
      showNotification("No saved dataset to overwrite. Please use 'Save with New Name' instead.", type = "error")
    }
  })

  # Handle discard partitions button (for both point & click and auto partitions)
  observeEvent(input$discardPartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)

    if (isAutoPartitions) {
      # This is auto partitions - just clear the temp data
      r$tempAutoPartitions <- NULL
      r$partitionData <- originalAutoPartitionData()

      # Close the save modal, then explicitly show main modal
      removeModal()  # Close partitionSaveModal (topmost modal)
      # Explicitly show main modal to ensure it's visible
      shinyjs::delay(50, {
        showModal(modelSelectionModal())
      })

      # Restore column selections to prevent deselection
      shinyjs::delay(100, {
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }
        # Restore dataScale
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })

      showNotification("Auto partitions discarded. Data restored to previous state.", type = "message", duration = 3)
    } else {
      # This is point & click partitions
      r$tempPointClickPartitions <- NULL
      r$partitionData <- originalPartitionData()

      # Clear partition state
      partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
      partitionState$clickData <- list()

      # Close the save modal (formations modal already closed when save was shown)
      removeModal()
      showModal(modelSelectionModal())

      # Restore settings after modal is shown
      shinyjs::delay(100, {
        # Restore dataset
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }

        # Restore partition source to what it was before
        if (!is.null(r$persistedPartitionSource)) {
          updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
    } else {
          updateSelectInput(session, "partitionSource", selected = "none")
        }

        # Restore column selections - CRITICAL for non-standard column names
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }

        # Restore site selections
        if (!is.null(r$persistedSiteSelections)) {
          updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
        }

        # Restore data source if available
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        }

        # Restore data scale if available
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Clear the restoration flag after UI updates complete
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })

      showNotification("Partitions discarded. Data restored to previous state.", type = "message", duration = 3)
    }
  })

  # Handle previousStep button when in partition modal - close partition modal and return to main modal
  observeEvent(input$previousStep, {
    # Check if we're likely in the partition modal by checking for partition-specific inputs
    if (!is.null(input$partitionSite)) {
      # Persist everything the user picked so it is restored when the main
      # data-load modal is re-rendered. Without this the site/z/signal column
      # selectors rebuild from scratch and lose their selected values.
      if (!is.null(input$dataScale)) {
        r$persistedDataScale <- input$dataScale
      }
      if (!is.null(siteColumn())   && nzchar(siteColumn()))   r$persistedColumnSelections$siteColumn   <- siteColumn()
      if (!is.null(zColumn())      && nzchar(zColumn()))      r$persistedColumnSelections$zColumn      <- zColumn()
      if (!is.null(signalColumns()) && length(signalColumns()) > 0) r$persistedColumnSelections$signalColumns <- signalColumns()
      if (!is.null(input$loadSiteSelect))  r$persistedSiteSelections    <- input$loadSiteSelect
      if (!is.null(input$partitionSource)) r$persistedPartitionSource   <- input$partitionSource
      if (!is.null(r$dataset))             r$persistedDataset           <- r$dataset
      # Close partition modal and return to main modal
      removeModal()
      showModal(modelSelectionModal())
      # Restore dataScale after modal is shown
      shinyjs::delay(100, {
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
      })
    }
  }, priority = 10)  # Higher priority to handle before the general previousStep handler

  # Render partition plot
  output$partitionPlot <- renderPlot({
    req(input$partitionSite, !is.null(r$dataset),
        !is.null(siteColumn()), !is.null(zColumn()))

    # Make reactive to click data changes
    partitionState$clickData
    partitionState$data

    site <- input$partitionSite

    # Try to use StratData if available (preferred - has correct axis orientation)
    if (signalValid()) {
      # Use the proper StratData plotting that was working before
      sd <- stratData()
      sigs <- signalColumns()

      if (length(sigs) > 0) {
        sig_idx <- match(sigs[1], sd$signalAttr$signalNames)

        # Use do.call with plot.StratData like in the view tab
        plotType <- if (!is.null(input$sigPlotType_view) && !is.na(input$sigPlotType_view)) {
          input$sigPlotType_view
        } else if (!is.null(input$sigPlotType_load) && !is.na(input$sigPlotType_load)) {
          input$sigPlotType_load
        } else {
          "l"
        }
        plotCex <- if (!is.null(input$viewCex) && !is.na(input$viewCex)) input$viewCex else 1
        plotLwd <- if (!is.null(input$viewLwd) && !is.na(input$viewLwd)) input$viewLwd else 2

        # Extend ylim to include top partition (if present) so it's visible
        site_partitions <- partitionState$data[partitionState$data$site == site, ]
        ylim_extended <- NULL
        if (nrow(site_partitions) > 0) {
          dataScale <- input$dataScale %||% "depth"
          depthMultiplier <- if (dataScale == "depth") -1 else 1
          partition_heights <- site_partitions$height * depthMultiplier
          max_partition_height <- max(partition_heights, na.rm = TRUE)
          # Get current signal heights to determine base ylim
          site_heights <- tryCatch({
            StratoBayes::SignalLookUp(sd, "height", site, signal = sig_idx, includeNAsignal = FALSE)
          }, error = function(e) NULL)
          if (!is.null(site_heights) && length(site_heights) > 0) {
            site_heights <- site_heights[is.finite(site_heights)]
            if (length(site_heights) > 0) {
              min_height <- min(site_heights, na.rm = TRUE)
              max_height <- max(site_heights, na.rm = TRUE)
              # Extend ylim to include top partition with small margin
              height_range <- max_height - min_height
              margin <- max(height_range * 0.05, abs(max_partition_height - max_height) * 1.1, 0.1)
              ylim_extended <- c(min_height, max(max_height + margin, max_partition_height + margin * 0.1))
            }
          }
        }

        plot_args <- list(x = sd, signal = sig_idx, sites = site, overridePar = FALSE,
                         type = plotType, cex = plotCex, lwd = plotLwd)
        if (!is.null(ylim_extended)) {
          plot_args$ylim <- ylim_extended
        }
        do.call(plot, plot_args)

        # Add existing partition lines for StratData plot (x=signal, y=height)
        site_partitions <- partitionState$data[partitionState$data$site == site, ]
        if (nrow(site_partitions) > 0) {
          # Get data scale to transform partition heights for display
          dataScale <- input$dataScale %||% "depth"
          depthMultiplier <- if (dataScale == "depth") -1 else 1

          # Get plot limits to position text properly
          xlims <- par("usr")[1:2]
          ylims <- par("usr")[3:4]
          for (i in seq_len(nrow(site_partitions))) {
            # Transform partition height for display (plot shows StratData's transformed coordinates)
            # partitionState$data stores heights in RAW coordinates, so transform for display
            display_height <- site_partitions$height[i] * depthMultiplier
            # Round to match table display precision (2 decimal places)
            display_height <- round(display_height, 2)
            # Draw partition line as HORIZONTAL line at transformed height
            abline(h = display_height, col = "red", lty = 2, lwd = 2)
            # Add label on the right side of plot
            text(x = xlims[2] * 0.95, y = display_height,
                 labels = site_partitions$partition[i], col = "red", pos = 4, cex = 0.9)
          }
        }

        # Add click indicator if available (draw on top)
        # clickData is stored in RAW coordinates, but plot shows transformed, so transform for display
        if (!is.null(partitionState$clickData) &&
            !is.null(partitionState$clickData$y) &&
            is.numeric(partitionState$clickData$y) &&
            !is.na(partitionState$clickData$y) &&
            (!is.null(partitionState$clickData$site) && partitionState$clickData$site == site)) {
          # Transform click height for display (plot shows StratData's transformed coordinates)
          dataScale <- input$dataScale %||% "depth"
          depthMultiplier <- if (dataScale == "depth") -1 else 1
          display_click_height <- partitionState$clickData$y * depthMultiplier

          xlims <- par("usr")[1:2]
          ylims <- par("usr")[3:4]
          # Draw a more visible indicator as HORIZONTAL line at transformed height
          abline(h = display_click_height, col = "blue", lty = 1, lwd = 3)
          # Add a point marker at the clicked location (x is signal, y is transformed height)
          points(x = partitionState$clickData$x, y = display_click_height,
                 col = "blue", pch = 19, cex = 2)
          # Add label on the right
          text(x = xlims[2] * 0.9, y = display_click_height,
               labels = paste("Click at height:", round(display_click_height, 2)),
               col = "blue", pos = 4, cex = 0.9, font = 2)
        }
      } else {
        plot(1, 1, type = "n", xlab = "Height", ylab = "Signal",
             main = paste("No signal data available for site:", site))
      }
    } else {
      # Fallback: Show informative message if StratData isn't available
      plot(1, 1, type = "n", xlab = "", ylab = "", axes = FALSE,
           xlim = c(0, 2), ylim = c(0, 2))
      text(1, 1.5, "Please ensure data is properly loaded",
           cex = 1.2, col = "black", font = 2)
      text(1, 1, "and all columns are selected",
           cex = 1.2, col = "black", font = 2)
      text(1, 0.5, "before creating partitions.",
           cex = 1.2, col = "black", font = 2)
    }
  })

  # Manual height label removed from UI; output kept for compatibility
  output$manualHeightInputLabel <- renderUI(NULL)

  # Render manual height input with dynamic label based on dataScale
  output$manualHeightInput <- renderUI({
    dataScale <- input$dataScale %||% "depth"
    label <- if (dataScale == "depth") "Depth" else "Height"
    placeholder <- if (dataScale == "depth") "e.g., -10" else "e.g., 10"
    textInput("manualHeight", label,
              placeholder = placeholder, width = "100%")
  })

  # Manual height help text removed per UX; output kept so no missing output if referenced
  output$manualHeightHelpText <- renderUI(NULL)

  # Instructions tooltip for partition modal (dynamic height/depth wording)
  output$partitionInstructionsTooltip <- renderUI({
    dataScale <- input$dataScale %||% "depth"
    zWord <- if (dataScale == "depth") "depth" else "height"
    tip <- paste0(
      "1. Select a site from the dropdown\n",
      "2. Click on the plot or type ", zWord, " below to set partition tops\n",
      "3. Enter partition names\n",
      "4. Click 'Done' when finished to save or discard."
    )
    tip <- gsub("\n", "<br>", tip, fixed = TRUE)
    tags$div(
      style = "display: flex; align-items: center;",
      tags$h4("Instructions", style = "margin: 0 6px 0 0;"),
      tags$span(
        class = "partition-instructions-tooltip",
        style = "color: #6c757d; font-size: 0.85em;",
        icon("circle-info", class = "fas"),
        tags$span(class = "partition-instructions-tooltiptext", HTML(tip))
      )
    )
  })

  # Inline overwrite confirmation (inside partition modal; no nested modal)
  output$partitionOverwriteConfirm_ui <- renderUI({
    if (!showOverwritePartitionsConfirm()) return(NULL)
    tags$div(
      class = "partition-overwrite-confirm",
      style = "margin-bottom: 10px; padding: 10px; border: 1px solid #ffc107; border-radius: 6px; background: #fff8e6;",
      tags$div(
        style = "display: flex; align-items: center; margin-bottom: 8px;",
        tags$p(tags$strong("Overwrite existing partitions?"), style = "margin: 0 6px 0 0;"),
        tags$span(
          class = "partition-overwrite-tooltip",
          style = "color: #6c757d; font-size: 0.85em;",
          icon("circle-info", class = "fas"),
          tags$span(
            class = "partition-overwrite-tooltiptext",
            "Custom partitions will be replaced by auto-generated ones. This cannot be undone."
          )
        )
      ),
      tags$div(
        class = "partition-overwrite-buttons",
        actionButton("cancelOverwritePartitions", "Cancel", class = "btn-secondary btn-sm"),
        actionButton("confirmAutoPartitions", "Overwrite", class = "btn-warning btn-sm")
      )
    )
  })

  # Render partition table as native UI rows with delete buttons
  output$partitionTable <- renderUI({
    if (nrow(partitionState$data) == 0) {
      return(tags$p("No partitions created yet", style = "color: #666; font-style: italic;"))
    }

    # Ensure we have the expected columns for ordering
    if (!("site" %in% colnames(partitionState$data) && "height" %in% colnames(partitionState$data))) {
      return(tags$p("Invalid partition data structure", style = "color: #d9534f;"))
    }

    # Order by site and height
    ordered_data <- partitionState$data[order(partitionState$data$site, partitionState$data$height), ]

    # IMPORTANT: Transform heights for display based on current dataScale
    # partitionState$data stores heights in raw coordinates (positive for depth)
    # But for display, we should show them as they appear on the plot
    # For depth scale, StratData transforms to negative, so we should show negative
    dataScale <- input$dataScale %||% "depth"
    display_heights <- ordered_data$height

    if (dataScale == "depth") {
      # Transform heights to match what's shown on the plot (negative for depth)
      display_heights <- display_heights * -1
    }

    # Round to 2 decimal places to match plot display precision
    display_heights <- round(display_heights, 2)

    # Use the actual zColumn name if available, otherwise use "height"
    z_col_name <- if (!is.null(zColumn()) && nzchar(zColumn())) {
      zColumn()
    } else {
      "height"
    }

    # Create rows with editable partition names and delete buttons
    # Use a stable ID based on site, height, and original partition name for the text input
    rows <- lapply(seq_len(nrow(ordered_data)), function(i) {
      row_data <- ordered_data[i, ]
      display_height <- display_heights[i]

      # Check if this is a default partition (starting with "Top_")
      is_default <- grepl("^Top_", row_data$partition, ignore.case = TRUE)

      # Create stable ID for partition name input using site and height only
      # This ensures the input ID remains stable even if the name changes
      # Use site + height as the stable identifier (height is unique enough with 6 decimal precision)
      name_input_id <- paste0("partition_name_",
                             gsub("[^A-Za-z0-9]", "_", row_data$site), "_",
                             gsub("\\.", "_", sprintf("%.6f", row_data$height)))
      # Limit ID length to avoid issues
      name_input_id <- substr(name_input_id, 1, 100)

      # Create button ID using row index
      btn_id <- paste0("del_partition_", i)

      # Create editable partition name input
      name_input <- textInput(
        inputId = name_input_id,
        label = NULL,
        value = row_data$partition,
        width = "100%",
        placeholder = "Enter partition name"
      )

      # Create delete button only for non-default partitions
      delete_btn <- if (!is_default) {
        actionButton(
          inputId = btn_id,
          label = "Delete",
          class = "btn-danger btn-sm",
          style = "padding: 2px 8px; font-size: 11px;"
        )
      } else {
        tags$span("", style = "display: inline-block; width: 60px;")  # Spacer for alignment
      }

      # Create row as a div with styling
      tags$div(
        class = "partition-row",
        style = "display: flex; align-items: center; padding: 8px; border-bottom: 1px solid #ddd;",
        tags$div(
          style = "flex: 1; display: grid; grid-template-columns: 1fr 1fr 2fr; gap: 10px; align-items: center;",
          tags$strong(row_data$site, style = "font-weight: 600;"),
          tags$span(sprintf("%.2f", display_height), style = "text-align: right;"),
          tags$div(
            style = "width: 100%;",
            name_input
          )
        ),
        tags$div(
          style = "margin-left: 10px;",
          delete_btn
        )
      )
    })

    # Create header row
    header <- tags$div(
      class = "partition-header",
      style = "display: flex; align-items: center; padding: 8px; background-color: #f5f5f5; font-weight: bold; border-bottom: 2px solid #ddd;",
      tags$div(
        style = "flex: 1; display: grid; grid-template-columns: 1fr 1fr 2fr; gap: 10px;",
        tags$span("Site"),
        tags$span(z_col_name, style = "text-align: right;"),
        tags$span("Partition Name")
      ),
      tags$div(
        style = "margin-left: 10px; width: 60px;",
        tags$span("")  # Spacer for delete button column
      )
    )

    # Return tagList with header and rows
    tagList(
      header,
      rows
    )
  })

  # Track which delete button was clicked to prevent multiple deletions
  lastDeleteClick <- reactiveVal(list(btn_id = NULL, click_count = 0))

  # Handle delete partition button clicks
  # Use a single observer that checks all delete buttons and processes only the clicked one
  observe({
    if (nrow(partitionState$data) == 0) return()

    # Order data to match display order
    ordered_data <- partitionState$data[order(partitionState$data$site, partitionState$data$height), ]

    # Check each delete button - process only the one that was clicked
    for (i in seq_len(nrow(ordered_data))) {
      row_data <- ordered_data[i, ]
      is_default <- grepl("^Top_", row_data$partition, ignore.case = TRUE)

      # Only check delete buttons for non-default partitions
      if (!is_default) {
        btn_id <- paste0("del_partition_", i)
        btn_input <- input[[btn_id]]

        # Check if this button was clicked (value increased)
        last_click <- lastDeleteClick()
        current_click_count <- if (!is.null(btn_input)) btn_input else 0

        # If this button was clicked and it's a new click (not the same as last processed)
        if (!is.null(btn_input) && btn_input > 0 &&
            (is.null(last_click$btn_id) || last_click$btn_id != btn_id ||
             last_click$click_count != current_click_count)) {

          isolate({
            # Mark this button as processed
            lastDeleteClick(list(btn_id = btn_id, click_count = current_click_count))

            # Find the exact row to delete by matching site, height, and partition name
            matching_rows <- which(
              partitionState$data$site == row_data$site &
              abs(partitionState$data$height - row_data$height) < 0.001 &
              partitionState$data$partition == row_data$partition
            )

            if (length(matching_rows) > 0) {
              # Remove only the specific matching row
              partitionState$data <- partitionState$data[-matching_rows[1], , drop = FALSE]
              showNotification(paste("Partition", row_data$partition, "deleted"),
                             type = "message")
            }
          })
          break  # Only process one deletion at a time
        }
      }
    }
  })

  # Observer to update partition names when text inputs in the table change
  # IMPORTANT: Only update if the name actually changed to prevent overwriting user input
  # Also skip if we're in the middle of adding a partition
  observe({
    if (nrow(partitionState$data) == 0) return()
    if (isTRUE(partitionState$isAddingPartition)) return()  # Don't update during partition addition

    # Order data to match display order
    ordered_data <- partitionState$data[order(partitionState$data$site, partitionState$data$height), ]

    # Check each partition name input
    for (i in seq_len(nrow(ordered_data))) {
      row_data <- ordered_data[i, ]

      # Create the same stable ID used in renderUI (site + height only)
      name_input_id <- paste0("partition_name_",
                             gsub("[^A-Za-z0-9]", "_", row_data$site), "_",
                             gsub("\\.", "_", sprintf("%.6f", row_data$height)))
      name_input_id <- substr(name_input_id, 1, 100)

      # Get the new name from the input
      new_name <- trimws(input[[name_input_id]] %||% "")

      if (nzchar(new_name)) {
        # Find the matching row in partitionState$data by site and height
        # Match by site and height (within small tolerance for floating point)
        matching_rows <- which(
          partitionState$data$site == row_data$site &
          abs(partitionState$data$height - row_data$height) < 0.001
        )

        if (length(matching_rows) > 0) {
          # Only update if the name is actually different (prevents overwriting during re-renders)
          current_name <- partitionState$data$partition[matching_rows[1]]
          if (!identical(current_name, new_name)) {
            partitionState$data$partition[matching_rows[1]] <- new_name
          }
        }
      }
    }
  })

  # Clear partitions when loading NEW data (not when restoring)
  observeEvent(input$dataSource, {
    # Don't proceed if dataSource is NULL (can happen on startup)
    if (is.null(input$dataSource)) {
      return()
    }

    # Only clear partitions if this is a new data source AND not loading saved dataset
    if (!isTRUE(r$loadedSavedDataset)) {
      # Check if this is different from persisted data source
      isNewSource <- is.null(r$persistedDataSource) || r$persistedDataSource != input$dataSource

      if (isNewSource) {
        # This is a new data source, clear partitions BEFORE loading data
    r$partitionData <- NULL
        partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
    partitionState$clickData <- list()
    # Reset partition source to none when loading new data
    updateSelectInput(session, "partitionSource", selected = "none")
        # Mark that we're loading from signal source, not saved dataset
        r$loadedSavedDataset <- FALSE
        r$currentLoadedDatasetName <- NULL  # Clear current loaded dataset name
        # Clear persisted dataset to force fresh load
        r$persistedDataset <- NULL
        # Clear hash to allow new saves
        r$lastSavedDataHash <- NULL
        # Clear persisted column selections so UI refreshes with new dataset columns
        r$persistedColumnSelections$siteColumn <- NULL
        r$persistedColumnSelections$zColumn <- NULL
        r$persistedColumnSelections$signalColumns <- NULL
        # Clear alignment/results from previous run so preview shows new data
        r$alignment <- NULL
        # Force UI refresh
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
      }
    }
    # Don't call UpdateData if we're restoring data (to prevent errors)
    if (isTRUE(r$isRestoringData)) {
      return()
    }

    # Automatically load data when source changes (only if dataSource is valid)
    # Don't call UpdateData if dataSource is NULL or empty - req() inside UpdateData will fail silently
    if (!is.null(input$dataSource) && nzchar(input$dataSource)) {
      tryCatch({
        # Access the reactive value to trigger it
        result <- UpdateData()
        # If UpdateData returns NULL due to req() failure, that's expected - don't show error
        if (is.null(result)) {
          # This is normal - req() stopped execution, not an error
          return()
        }
      }, error = function(e) {
        # Check if this is a shiny.silent.error (from req() failure) - ignore these
        error_class <- class(e)
        if ("shiny.silent.error" %in% error_class) {
          # This is expected when req() fails - don't show error
          return()
        }

        # Extract error message properly for real errors
        error_msg <- tryCatch({
          if (is.null(e)) {
            "Unknown error"
          } else if (!is.null(e$message) && nchar(trimws(e$message)) > 0) {
            e$message
          } else if (!is.null(conditionMessage(e)) && nchar(trimws(conditionMessage(e))) > 0) {
            conditionMessage(e)
          } else {
            paste("Error:", paste(error_class, collapse = ", "))
          }
        }, error = function(e2) {
          "Unknown error occurred"
        })

        # Only show error if it's a real error (not silent error from req())
        showNotification(paste("Error loading data:", error_msg), type = "error")
        LogMsg("Error in UpdateData(): ", error_msg)
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$dataFile, {
    # Only clear partitions if this is a new file (not restoring) AND not loading saved dataset
    if (!is.null(input$dataFile) && !isTRUE(r$loadedSavedDataset)) {
      # Check if this is different from persisted data
      isNewFile <- is.null(r$persistedDataset) ||
                   is.null(r$dataset) ||
                   (nrow(r$dataset) != nrow(r$persistedDataset)) ||
                   !all(dim(r$dataset) == dim(r$persistedDataset))

      if (isNewFile) {
        # This is a new file, clear partitions and column selections
    r$partitionData <- NULL
        partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
    partitionState$clickData <- list()
    # Reset partition source to none when loading new data
    updateSelectInput(session, "partitionSource", selected = "none")
        # Mark that we're loading from signal source, not saved dataset
        r$loadedSavedDataset <- FALSE
        # Clear persisted column selections so UI refreshes with new dataset columns
        r$persistedColumnSelections$siteColumn <- NULL
        r$persistedColumnSelections$zColumn <- NULL
        r$persistedColumnSelections$signalColumns <- NULL
        # Clear alignment/results from previous run so preview shows new data
        r$alignment <- NULL
        # Force UI refresh
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
      }
    }
    # Only call UpdateData if this is a real file change, not just restoration
    # Check if we're in the middle of restoring persisted data
    if (!is.null(input$dataFile) && !is.null(input$dataSource) && nzchar(input$dataSource)) {
      # Check if this is a restoration (we have persisted data and it matches)
      isRestoration <- !is.null(r$persistedDataset) &&
                      !is.null(r$dataset) &&
                      nrow(r$dataset) == nrow(r$persistedDataset) &&
                      all(dim(r$dataset) == dim(r$persistedDataset))

      # Only call UpdateData if it's not a restoration
      if (!isRestoration) {
        tryCatch({
          result <- UpdateData()
          if (is.null(result)) {
            return()
          }
        }, error = function(e) {
          # Check if this is a shiny.silent.error (from req() failure) - ignore these
          error_class <- class(e)
          if ("shiny.silent.error" %in% error_class) {
            # This is expected when req() fails - don't show error
            return()
          }

          error_msg <- tryCatch({
            if (is.null(e)) {
              "Unknown error"
            } else if (!is.null(e$message) && nchar(trimws(e$message)) > 0) {
              e$message
            } else if (!is.null(conditionMessage(e)) && nchar(trimws(conditionMessage(e))) > 0) {
              conditionMessage(e)
            } else {
              paste("Error:", paste(error_class, collapse = ", "))
            }
          }, error = function(e2) {
            "Unknown error occurred"
          })

          showNotification(paste("Error loading data file:", error_msg), type = "error")
          LogMsg("Error in UpdateData() from file: ", error_msg)
        })
      }
    }
  }, ignoreInit = TRUE)

  # Store original partition data before auto partition modifications (for discard functionality)
  originalAutoPartitionData <- reactiveVal(NULL)

  # Helper function to create auto partitions  (DROP-IN REPLACEMENT)
  createAutoPartitions <- function() {
    tryCatch({
      df <- r$dataset
      if (is.null(df) || is.null(siteColumn()) || is.null(zColumn())) {
        showNotification("Please select site and height columns first", type = "error")
        return()
      }

      sc <- siteColumn()
      zc <- zColumn()

      # 1) Normalize site keys the SAME way stratData() does
      df[[sc]] <- trimws(as.character(df[[sc]]))
      r$dataset[[sc]] <- df[[sc]]  # keep r$dataset consistent too

      # Ensure z is numeric in df for boundary calculations (Partitions can handle raw, but we need min/max)
      df[[zc]] <- suppressWarnings(as.numeric(df[[zc]]))

      # 2) Validate nStrata
      nStrata_val <- input$nStrata
      if (is.null(nStrata_val)) {
        showNotification("nStrata is NULL - please enter a number of strata", type = "error")
        return()
      }
      if (is.na(nStrata_val) || nStrata_val < 1 || nStrata_val > 8) {
        showNotification(
          paste("Invalid number of strata:", nStrata_val, "- Please enter a positive integer between 1 and 8."),
          type = "error"
        )
        return()
      }
      nStrata_int <- as.integer(round(nStrata_val))

      # 3) Build basic top partitions only if not already present
      if (is.null(r$parts_df_basic) || nrow(r$parts_df_basic) == 0) {
        r$parts_df_basic <- createBasicPartitions(
          df = df,
          site_col = sc,
          z_col = zc,
          z_scale = input$dataScale %||% "depth"
        )
      }

      # 4) Build auto partitions with StratoBayes
      parts_df <- StratoBayes::Partitions(
        signal = df,
        nStrata = nStrata_int,
        distribute = input$distributeMethod,
        siteColumn = sc,
        zColumn = zc,
        zScale = input$dataScale,
        signalColumn = signalColumns()
      )

      # Replace default integer partition names with per-site Bound1_<site>,
      # Bound2_<site>, ... Note: the top-of-section row is stripped in step 5
      # below, so remaining rows are renumbered afterwards.

      # Required by StratData
      parts_df$sedRatePartition <- parts_df$partition

      # 5) Strip the top-of-site boundary from auto partitions — basic partitions
      #    already provide Top_* with buffer. StratoBayes returns integer partition
      #    names and includes an unbuffered boundary at each site's top (min depth
      #    or max height). Remove those to prevent duplicates.
      z_scale <- input$dataScale %||% "depth"
      if (nrow(parts_df) > 0 && sc %in% colnames(parts_df) && zc %in% colnames(parts_df)) {
        sites_in_auto <- unique(parts_df[[sc]])
        rows_to_drop <- integer(0)
        for (s in sites_in_auto) {
          site_rows <- which(parts_df[[sc]] == s)
          if (length(site_rows) == 0) next
          z_vals <- parts_df[[zc]][site_rows]
          idx_at_top <- if (z_scale == "depth") which.min(z_vals) else which.max(z_vals)
          rows_to_drop <- c(rows_to_drop, site_rows[idx_at_top])
        }
        if (length(rows_to_drop) > 0) {
          parts_df <- parts_df[-rows_to_drop, , drop = FALSE]
        }
      }

      # Now rename remaining rows per site: Bound1_<site>, Bound2_<site>, ...
      if (nrow(parts_df) > 0 && sc %in% colnames(parts_df)) {
        sites_vec <- as.character(parts_df[[sc]])
        new_names <- character(length(sites_vec))
        for (s in unique(sites_vec)) {
          idx <- which(sites_vec == s)
          new_names[idx] <- paste0("Bound", seq_along(idx), "_", s)
        }
        parts_df$partition <- new_names
        parts_df$sedRatePartition <- parts_df$partition
      }
      r$parts_df_added <- if (nrow(parts_df) > 0) parts_df else NULL

      # 6) Combine basic + added into partitionData
      parts_full <- if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        rbind(r$parts_df_basic, r$parts_df_added)
      } else {
        r$parts_df_basic
      }

      # De-duplication safety net
      if (!is.null(parts_full) && nrow(parts_full) > 1) {
        parts_full <- parts_full[order(parts_full[[sc]], parts_full[[zc]]), ]
        keep <- rep(TRUE, nrow(parts_full))
        for (i in 2:nrow(parts_full)) {
          if (parts_full[[sc]][i] == parts_full[[sc]][i - 1]) {
            if (abs(parts_full[[zc]][i] - parts_full[[zc]][i - 1]) < 0.01) {
              keep[i] <- FALSE
            }
          }
        }
        parts_full <- parts_full[keep, , drop = FALSE]
      }

      # 7) Update the modal table in generic cols for editing/view
      state_df <- data.frame(
        site      = as.character(parts_full[[sc]]),
        height    = as.numeric(parts_full[[zc]]),
        partition = as.character(parts_full$partition),
        stringsAsFactors = FALSE
      )
      partitionState$data <- normalizePartitionData(state_df)

      showNotification(
        "Auto partitions added. Edit in the table or add more with Point & Click, then click Done to save.",
        type = "message", duration = 5
      )

    }, error = function(e) {
      showNotification(paste("Error creating auto partitions:", e$message), type = "error")
    })
  }

  # Handle add auto partitions button: check for existing partitions and show confirmation if needed
  observeEvent(input$addAutoPartitions, {
    # Check if there are existing custom partitions (not just basic "Top_" partitions)
    hasCustomPartitions <- FALSE
    if (!is.null(partitionState$data) && nrow(partitionState$data) > 0) {
      # Check if any partitions are not basic "Top_" partitions
      if ("partition" %in% colnames(partitionState$data)) {
        custom_mask <- !grepl("^Top_", partitionState$data$partition, ignore.case = TRUE)
        hasCustomPartitions <- any(custom_mask)
      }
    }

    # If custom partitions exist, show inline confirmation (no extra modal)
    if (hasCustomPartitions) {
      showOverwritePartitionsConfirm(TRUE)
    } else {
      createAutoPartitions()
    }
  })

  # Inline overwrite confirmation: Cancel
  observeEvent(input$cancelOverwritePartitions, {
    showOverwritePartitionsConfirm(FALSE)
  })

  # Inline overwrite confirmation: Overwrite
  observeEvent(input$confirmAutoPartitions, {
    showOverwritePartitionsConfirm(FALSE)
    createAutoPartitions()
  })


  # Make partition data reactive to partition source changes
  observeEvent(input$partitionSource, {
    # When switching to interactive, restore partition data if available
    if (input$partitionSource == "interactive" && !is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # Convert from actual column names back to generic for editing
      parts_df <- r$partitionData
      if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == siteColumn()] <- "site"
      }
      if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == zColumn()] <- "height"
      }
      # Restore partition data when switching back to interactive - normalize structure
      partitionState$data <- normalizePartitionData(parts_df)
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxl.sheet, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
    UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxlSkip, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
        UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxlSkipCols, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
        UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  # expose to other modules
  list(
    stratData    = stratData,
    signalValid  = signalValid,
    siteColumn   = siteColumn,
    zColumn      = zColumn,
    signalCols   = signalColumns,
    dataScale    = reactive(input$dataScale %||% "depth"),
    rawdata = reactive(r$dataset),
    updateDataPreview = updateDataPreview,
    datasetId = datasetId,
    uiTrigger = uiTrigger,
    # Clean-data API used by the data view module.
    cleanSettings = cleanSettings,
    setCleanZRange = function(site, range) {
      if (is.null(site) || !nzchar(site)) return(invisible(NULL))
      lst <- cleanSettings$zRange
      if (is.null(range)) {
        lst[[site]] <- NULL
      } else {
        lst[[site]] <- as.numeric(range)
      }
      cleanSettings$zRange <- lst
      invisible(NULL)
    },
    setCleanValueRange = function(signal, range) {
      if (is.null(signal) || !nzchar(signal)) return(invisible(NULL))
      lst <- cleanSettings$valueRange
      if (is.null(range)) {
        lst[[signal]] <- NULL
      } else {
        lst[[signal]] <- as.numeric(range)
      }
      cleanSettings$valueRange <- lst
      invisible(NULL)
    },
    resetCleanSettings = function() {
      cleanSettings$zRange <- list()
      cleanSettings$valueRange <- list()
      invisible(NULL)
    }
  )
}

# --- Helper: read LAS folder and bind into one data.frame
.ReadLasAsDataset <- function(folder, fileNames = NULL) {
  las_list <- StratoBayes::ReadLasFiles(folderPath = folder, fileNames = fileNames, quiet = TRUE)

  # 1) Standardize each file first (Depth/DEPT normalization + well/site label)
  dfs <- lapply(names(las_list), function(nm) {
    df <- las_list[[nm]]
    if (!is.data.frame(df) || nrow(df) == 0) return(NULL)

    df <- safe_colnames(df)

    # Normalize depth mnemonics per-file BEFORE binding
    cn <- names(df)
    depth_idx <- which(tolower(cn) %in% c("depth", "dept", "deph"))
    if (length(depth_idx) >= 1) {
      names(df)[depth_idx[1]] <- "Depth"
      # drop extra depth-like columns to avoid Depth+DEPT duplicates
      if (length(depth_idx) > 1) df <- df[, -depth_idx[-1], drop = FALSE]
    }

    df$well <- nm
    df
  })
  dfs <- Filter(Negate(is.null), dfs)

  if (length(dfs) == 0) stop("LAS read succeeded but produced no per-file data.frames.")

  # 2) Union all column names across files
  all_cols <- sort(unique(unlist(lapply(dfs, names), use.names = FALSE)))

  # Preferred leftmost order (only keep those that exist)
  preferred <- c("well", "Depth")

  # Rebuild all_cols: preferred first, then the rest (optionally alphabetized)
  all_cols <- c(intersect(preferred, all_cols),
                sort(setdiff(all_cols, preferred)))
  # 3) Make each df have all columns (fill missing with NA), then order identically
  dfs2 <- lapply(dfs, function(df) {
    missing <- setdiff(all_cols, names(df))
    if (length(missing)) {
      for (m in missing) df[[m]] <- NA
    }
    df <- df[, all_cols, drop = FALSE]
    df
  })

  out <- do.call(rbind, dfs2)
  row.names(out) <- NULL

  if (!("Depth" %in% names(out))) {
    stop("No Depth column after normalization; check LAS mnemonics and safe_colnames().")
  }

  out
}

# ----------------------------------------------------------------------------
# Merge-wells helpers (ported verbatim from 0.2.1 / commit 2bef0217, with minor
# formatting only). Keep these file-scoped (outside data_server) so they can
# be unit-tested without a Shiny session.
# ----------------------------------------------------------------------------

# Longest common prefix of a character vector (used to suggest a merged well name).
.LongestCommonPrefix <- function(x) {
  if (length(x) == 0L) return("")
  if (length(x) == 1L) return(x[[1L]])
  x <- as.character(x)
  n <- min(nchar(x))
  if (n == 0L) return("")
  for (i in seq_len(n)) {
    if (length(unique(substr(x, 1L, i))) > 1L) {
      return(if (i == 1L) "" else substr(x[1L], 1L, i - 1L))
    }
  }
  substr(x[1L], 1L, n)
}

# Outer-join a selected set of wells into one.
# Depth values are unioned and sorted; curves with the same name across wells
# are coalesced when values agree at shared depths, or kept as `curve__well`
# suffixed columns when they genuinely differ. Other (unmerged) wells pass
# through untouched. Columns are aligned so rbind is safe.
.MergeWellsDataset <- function(dataset, site_col, depth_col, wells_to_merge, merged_name) {
  if (!site_col %in% names(dataset) || !depth_col %in% names(dataset)) {
    stop("Site or depth column not found in dataset.")
  }
  wells_to_merge <- as.character(wells_to_merge)
  if (length(wells_to_merge) < 2L) stop("Select at least two wells to merge.")
  keep  <- dataset[[site_col]] %in% wells_to_merge
  other <- dataset[!keep, , drop = FALSE]
  sub   <- dataset[keep, , drop = FALSE]

  # Dedupe duplicate depths per well (keep first), warn once if any dropped.
  sub_dedup <- do.call(rbind, lapply(wells_to_merge, function(w) {
    d <- sub[sub[[site_col]] == w, , drop = FALSE]
    if (nrow(d) == 0L) return(d)
    d[!duplicated(d[[depth_col]]), , drop = FALSE]
  }))
  if (nrow(sub_dedup) < nrow(sub)) {
    warning("Duplicate depth rows in one or more wells were dropped (first kept).")
  }
  sub <- sub_dedup

  well_dfs <- split(sub, sub[[site_col]])
  well_dfs <- well_dfs[wells_to_merge]
  all_depths <- sort(unique(unlist(lapply(well_dfs, function(d) d[[depth_col]]), use.names = FALSE)))
  if (length(all_depths) == 0L) stop("No depth values in selected wells.")

  curve_cols <- setdiff(names(sub), c(site_col, depth_col))
  if (length(curve_cols) == 0L) {
    out_merged <- data.frame(dep = all_depths, stringsAsFactors = FALSE)
    names(out_merged)[1L] <- depth_col
    out_merged[[site_col]] <- merged_name
    n_out <- nrow(out_merged)
    for (nm in setdiff(names(dataset), names(out_merged))) out_merged[[nm]] <- rep(NA, n_out)
    out_merged <- out_merged[, names(dataset), drop = FALSE]
    n_other <- nrow(other)
    other <- other[, intersect(names(dataset), names(other)), drop = FALSE]
    for (nm in setdiff(names(dataset), names(other))) other[[nm]] <- rep(NA, n_other)
    other <- other[, names(dataset), drop = FALSE]
    return(rbind(other, out_merged))
  }

  # Build one column per (curve, well) with provisional names curve__well.
  out_merged <- data.frame(dep = all_depths, stringsAsFactors = FALSE)
  names(out_merged)[1L] <- depth_col
  curve_by_well <- list()
  for (w in wells_to_merge) {
    d <- well_dfs[[w]]
    if (is.null(d) || nrow(d) == 0L) next
    idx <- match(d[[depth_col]], all_depths)
    for (c in curve_cols) {
      if (!c %in% names(d)) next
      col_name <- paste0(c, "__", w)
      out_merged[[col_name]] <- NA_real_
      out_merged[[col_name]][idx] <- d[[c]]
      curve_by_well[[c]] <- c(curve_by_well[[c]], col_name)
    }
  }

  # For each base curve: if only one source, rename to base; if multiple,
  # coalesce when no row has >1 disagreeing non-NA value, otherwise keep
  # the per-well suffixed columns.
  base_curves <- unique(gsub("__.*$", "", unlist(curve_by_well, use.names = FALSE)))
  for (bc in base_curves) {
    cols <- curve_by_well[[bc]]
    if (is.null(cols)) next
    cols <- intersect(cols, names(out_merged))
    if (length(cols) == 0L) next
    if (length(cols) == 1L) {
      names(out_merged)[names(out_merged) == cols[1L]] <- bc
      next
    }
    vals <- out_merged[, cols, drop = FALSE]
    nna  <- rowSums(!is.na(vals))
    conflict <- nna >= 2L
    if (any(conflict)) {
      differing <- apply(vals[conflict, , drop = FALSE], 1L, function(r) {
        u <- unique(r[!is.na(r)])
        length(u) > 1L
      })
      if (any(differing)) {
        # Keep per-well suffixed columns (conflict).
        next
      }
    }
    # No conflict: coalesce into single base column.
    out_merged[[bc]] <- vals[[1L]]
    for (j in seq_along(cols)[-1L]) {
      na_idx <- is.na(out_merged[[bc]])
      if (any(na_idx)) out_merged[[bc]][na_idx] <- vals[[j]][na_idx]
    }
    for (col in cols) out_merged[[col]] <- NULL
  }

  out_merged[[site_col]] <- merged_name
  final_cols <- c(depth_col, setdiff(names(out_merged), c(depth_col, site_col)), site_col)
  final_cols <- unique(final_cols)
  out_merged <- out_merged[, final_cols, drop = FALSE]

  want_order <- c(site_col, depth_col, setdiff(names(dataset), c(site_col, depth_col)))
  want_order <- intersect(want_order, names(out_merged))
  other_cols <- setdiff(names(out_merged), want_order)
  out_merged <- out_merged[, c(want_order, other_cols), drop = FALSE]

  # Align columns across `other` and `out_merged` so rbind is safe.
  full_cols <- unique(c(names(other), names(out_merged)))
  n_other <- nrow(other)
  n_out   <- nrow(out_merged)
  other      <- other[, intersect(full_cols, names(other)), drop = FALSE]
  for (fc in setdiff(full_cols, names(other)))      other[[fc]]      <- rep(NA, n_other)
  other      <- other[, full_cols, drop = FALSE]
  out_merged <- out_merged[, intersect(full_cols, names(out_merged)), drop = FALSE]
  for (fc in setdiff(full_cols, names(out_merged))) out_merged[[fc]] <- rep(NA, n_out)
  out_merged <- out_merged[, full_cols, drop = FALSE]

  rbind(other, out_merged)
}
