test_that("Partitions() fails gracefully", {
  expect_error(Partitions(2, 2),
               "data.frame")
  expect_error(Partitions(data.frame(height = 2), 2),
               "column.*site")
  expect_error(Partitions(data.frame(site = 2), 2),
               "column.*height")
  expect_error(Partitions(data.frame(site = 2, height = 2),
                                   2, distribute = "invalid"),
               "distribute` must be")
  expect_error(Partitions(data.frame(site = 2, height = 2), "2"),
               "nStrata` must be")
})

test_that("Partitions() works", {
  test <- data.frame(site = c(rep("a", 12), rep("b", 25)),
                     signal = rnorm(37),
                     height = c(1:6, rep(6, 6 ) + seq(0.1, 0.6, 0.1), 1:25))
  aRange <- range(test[test$site == "a", "height"])
  bRange <- range(test[test$site == "b", "height"])
  expect_equal(
    Partitions(test, 2, distribute = "height"),
    data.frame(site = c("a", "a", "b", "b"),
               height = c(aRange[1] + (aRange[2] - aRange[1]) / 2,
                          aRange[2],
                          bRange[1] + (bRange[2] - bRange[1]) / 2,
                          bRange[2]),
               partition = 1:4
    )
  )

  expect_equal(
    Partitions(test, 3, distribute = "points")$height,
    c(5,6.3, 6.6, 9, 17, 25), tolerance = .01
    )

  # depth scale
  testDataDepth <- .GenerateTestData(testdata = "depth", version = "1")
  expect_equal(Partitions(testDataDepth$signal, 3, distribute = "points",
                                   zColumn = "depth", zScale = "depth")$depth,
               c(3,1,0,-2,-4,-5), tolerance = .01)

})


