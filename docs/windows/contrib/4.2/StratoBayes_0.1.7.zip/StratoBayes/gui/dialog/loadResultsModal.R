## inst/gui/dialog/loadResultsModal.R
loadResultsModal <- function(savedResultsList) {
  modalDialog(
    title = "Load Results",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "padding: 20px;",
        tags$h4("Load saved results from session"),
        tags$p("Select a previously saved result to load."),
        br(),
        if (length(savedResultsList) == 0) {
          tagList(
            tags$p("No saved results available.", style = "color: #666; font-style: italic;"),
            tags$p("Run a model first, then use 'Save Results' to save it.", style = "color: #666; font-size: 0.9em;")
          )
        } else {
          selectInput("loadResultsSelect", "Select result:",
                     choices = setNames(names(savedResultsList), names(savedResultsList)),
                     selected = NULL,
                     width = "100%")
        }
      )
    ),
    
    footer = tagList(
      actionButton("cancelLoadResults", "Cancel", 
                  class = "btn-secondary",
                  style = "float: left;"),
      if (length(savedResultsList) > 0) {
        actionButton("confirmLoadResults", "Load", 
                    class = "btn-primary",
                    style = "float: right;")
      }
    )
  )
}

