## inst/gui/dialog/exportResultsModal.R
exportResultsModal <- function() {
  modalDialog(
    title = "Save Results",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "padding: 20px;",
        tags$h4("Save results to disk"),
        tags$p("Save the current StratPosterior object to an RDS file."),
        br(),
        textInput("exportResultsName", "File name (without extension):",
                 value = paste0("result-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S")),
                 placeholder = "Enter a name for this result",
                 width = "100%"),
        br(),
        tags$p("The file will be saved with a .rds extension.", 
               style = "font-size: 0.9em; color: #666; margin-top: 5px;")
      )
    ),
    
    footer = tagList(
      actionButton("cancelExportResults", "Cancel", 
                  class = "btn-secondary",
                  style = "float: left;"),
      actionButton("confirmExportResults", "Save", 
                  class = "btn-primary",
                  style = "float: right;")
    )
  )
}

