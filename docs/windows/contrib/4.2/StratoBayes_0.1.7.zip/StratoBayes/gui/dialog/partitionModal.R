## inst/gui/dialog/partitionModal.R
partitionModal <- function() {
  modalDialog(
    title = "Create Partition Tops - Point & Click",
    size = "xl",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      fluidRow(
        column(3,
               tags$h4("Instructions"),
               tags$p("1. Select a site from the dropdown"),
               tags$p("2. Click and drag on the plot to set partition tops"),
               tags$p("3. Or type heights manually below"),
               tags$p("4. Enter partition names"),
               tags$p("5. Click 'Done' when finished"),
               
               br(),
               
               selectInput("partitionSite", "Select Site",
                          choices = NULL, width = "100%"),
               
               br(),
               
               tags$h5("Manual Height Input:"),
               textInput("manualHeight", "Heights", 
                        placeholder = "e.g., 1.5, 2.3, 4.1", width = "100%"),
               helpText("Enter heights separated by commas"),
               
               br(),
               
               textInput("partitionName", "Partition Name",
                        placeholder = "e.g., Unit A, Lithology 1", width = "100%"),
               
               br(),
               
               actionButton("addPartition", "Add Partition Top", 
                           class = "btn-success", width = "100%"),
               
               br(), br(),
               
               actionButton("clearPartitions", "Clear All", 
                           class = "btn-warning", width = "100%"),
               
               br(), br(),
               
               actionButton("donePartitions", "Done", 
                           class = "btn-primary", width = "100%")
        ),
        
        column(9,
               tags$h4("Data Plot - Click and Drag to Set Partition Tops"),
               plotOutput("partitionPlot", 
                         click = "partitionClick",
                         brush = "partitionBrush",
                         height = "500px"),
               
               br(),
               
               tags$h5("Current Partition Tops:"),
               tableOutput("partitionTable"),
               
               br(),
               
               tags$h5("Edit Top Partition Names:"),
               uiOutput("topPartitionEditors")
        )
      )
    ),
    
    footer = tagList(
      actionButton("previousStep", "Back", class = "btn-secondary", style = "float: left;")
      # Removed "Next" button - "Done" button handles the workflow
    )
  )
}
