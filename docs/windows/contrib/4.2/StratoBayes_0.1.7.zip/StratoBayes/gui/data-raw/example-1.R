################################################################################
#
# 1 - create simple data set for demonstration
#
################################################################################
#
# sine function to generate underlying signal y for any heights x
GenerateSine <- function(x) {
  sin(x) - 1/5*(x - 2 * 2 * pi)
}
#
# set random seed to ensure consistency of results
set.seed(0)
# reference section data
# number of periods
periods <- 3
# number of data points for reference section
n1 <- 80
x1 <- runif(n1, 0, 2 * pi * periods)
y1 <- GenerateSine(x1) + rnorm(n1, 0, 1/4)
# second section data
n2 <- 40
x2 <- runif(n2, 1.5 * pi, 4 * pi)
y2 <- GenerateSine(x2) + rnorm(n2, 0, 1/4)
#
# visualise signal
plot(x1, y1, bg = rgb(.8, 0, 0), pch = 21)
points(x2, y2, bg = rgb(0,.6,.8), pch = 22)
#
# scale x2 (change sedimentation rate)
sedRate2 <- 2.5
x2 <- x2 * sedRate2
# shift x2 to start at 0
x2 <- x2 - min(x2)
#
# format data for reading it with StratData()
signalData0 <- data.frame(site = rep(c("site1", "site2"), c(n1, n2)),
                          height = c(x1, x2),
                          value = c(y1, y2))

# Define the path to save the CSV file
csvFilePath <- file.path("inst", "gui", "extdata", "example-signal-1.csv")

# Write the data to a CSV file
write.csv(signalData0, file = csvFilePath, row.names = FALSE)

test4 <- RunStratModel(StratData(signalData0), alignmentScale = "h", sedModel = "s", alphaPosition = "middle")
