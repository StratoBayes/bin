source("gui-elements.R", local = TRUE)
source("R/logging.R", local = TRUE)
source("R/references.R", local = TRUE)
# options("StratoBayes.logging" = TRUE)
# options("StratoBayes.write.code" = TRUE)
options(shiny.maxRequestSize = 1024 ^ 3)  # Allow max 1 GB files

# Keep shared libraries here
library("methods", exclude = c("show", "removeClass"))
library("cli")
library("StratoBayes")   # inapplicable.datasets required within ui

suppressPackageStartupMessages({
  library("shiny",   exclude = c("runExample"))
  library("shinyjs", exclude = c("runExample"))
})
