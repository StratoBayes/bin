results_server <- function(input, output, session, data_api, model_api) {
  
  # Calculate and update default Ref Heights when alignment becomes available
  observeEvent({
    model_api$alignment()
    input$plotTypeMain
  }, {
    if (!is.null(model_api$alignment()) && 
        !is.null(input$plotTypeMain) && 
        input$plotTypeMain == "correlation") {
      alignm <- model_api$alignment()
      if (!is.null(alignm) && !is.null(alignm$data)) {
        dataObj <- alignm$data
        
        # Calculate default refHeights using same logic as TopsPlot
        defaultRefHeights <- NULL
        if (dataObj[["S"]] == 2) {
          # For 2 sites, use StratMap approach
          site2Range <- range(c(dataObj[[c("partsAttr", "Bound")]][,2],
                              dataObj[[c("partsAttr", "BoundLow")]][,2]), na.rm = TRUE)
          site2Span <- diff(site2Range)
          refHeightsSite2 <- c(site2Range[1], mean(site2Range), site2Range[2]) + c(0.1, 0, -0.1) * site2Span
          
          tryCatch({
            defaultRefHeights <- StratoBayes::StratMap(alignm, refHeightsSite2, 2)[["mean"]]
          }, error = function(e) {
            defaultRefHeights <<- NULL
          })
        } else {
          # For more than 2 sites, use bounds or signal lookup
          bounds <- unique(c(na.omit(dataObj[[c("partsAttr", "Bound")]][, 1]),
                           na.omit(dataObj[[c("partsAttr", "BoundLow")]][, 1])))
          if (length(bounds) > 2) {
            bounds_sorted <- sort(bounds)
            defaultRefHeights <- bounds_sorted[is.finite(bounds_sorted)]
          } else {
            tryCatch({
              h1 <- StratoBayes::SignalLookUp(dataObj, "height", 1, signal = 1, includeNAsignal = FALSE)
              h1_vals <- c(min(h1, na.rm = TRUE), mean(range(h1, na.rm = TRUE)), max(h1, na.rm = TRUE))
              h1_vals <- h1_vals[is.finite(h1_vals)]
              if (length(h1_vals) > 0) {
                defaultRefHeights <- sort(h1_vals)
              } else {
                defaultRefHeights <- c(0, 1, 2)
              }
            }, error = function(e) {
              defaultRefHeights <<- c(0, 1, 2)
            })
          }
        }
        
        # Final validation
        if (is.null(defaultRefHeights) || length(defaultRefHeights) == 0 || any(!is.finite(defaultRefHeights))) {
          defaultRefHeights <- c(0, 1, 2)
        } else {
          defaultRefHeights <- defaultRefHeights[is.finite(defaultRefHeights)]
          if (length(defaultRefHeights) == 0) {
            defaultRefHeights <- c(0, 1, 2)
          }
        }
        
        # Always update with auto-calculated values when alignment changes (new result generated/loaded)
        # Format as comma-separated string
        refHeightsStr <- paste(round(defaultRefHeights, 3), collapse = ", ")
        updateTextInput(session, "refHeights", value = refHeightsStr)
      }
    }
  }, ignoreInit = TRUE)
  
  # Export well tops download handler
  output$exportWellTops <- downloadHandler(
    filename = function() {
      paste0("well-tops-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"), ".csv")
    },
    content = function(file) {
      # Get alignment object
      alignm <- model_api$alignment()
      if (is.null(alignm)) {
        showNotification("No results available. Please run a model first.", type = "error")
        return()
      }
      
      # Parse refHeights input (same as used in TopsPlot)
      refHeights <- NULL
      if (!is.null(input$refHeights) && nzchar(trimws(input$refHeights))) {
        tryCatch({
          refHeights <- as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(input$refHeights)), ",")))
          refHeights <- refHeights[!is.na(refHeights)]
          if (length(refHeights) == 0) refHeights <- NULL
        }, error = function(e) {
          refHeights <<- NULL
        })
      }
      
      # Get alignment selection
      alignmentSel <- input$posteriorAlignments
      clustUnique <- model_api$stratCluster()$clustUnique
      
      # Convert selected cluster IDs to integers
      selected_clusters <- tryCatch({
        if (is.null(alignmentSel) || length(alignmentSel) == 0) {
          # No selection: default to first 4 (or all if <= 4)
          if (length(clustUnique) <= 4) {
            as.integer(clustUnique)
          } else {
            as.integer(clustUnique[1:4])
          }
        } else {
          # Convert to integers
          as.integer(alignmentSel)
        }
      }, error = function(e) {
        return(integer(0))
      })
      
      # Filter out invalid cluster IDs
      valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
      valid_clusters <- valid_clusters[!is.na(valid_clusters)]
      
      # Limit to maximum of 4 alignments
      if (length(valid_clusters) == 0) {
        # No valid clusters: default to first 4 (or all if <= 4)
        if (length(clustUnique) <= 4) {
          alignmentSel <- as.integer(clustUnique)
        } else {
          alignmentSel <- as.integer(clustUnique[1:4])
        }
      } else if (length(valid_clusters) > 4) {
        # More than 4 selected: limit to first 4
        alignmentSel <- valid_clusters[1:4]
      } else {
        alignmentSel <- valid_clusters
      }
      
      # Get sites
      sites <- input$posteriorSites %||% "all"
      
      # Calculate quantiles based on confidence level
      confidenceLevel <- input$confidenceLevel %||% 80
      if (confidenceLevel == 0) {
        quantiles <- 0.5
      } else if (confidenceLevel >= 100) {
        quantiles <- c(0.0, 0.5, 1.0)
      } else {
        alpha <- (100 - confidenceLevel) / 100
        lowerQuantile <- alpha / 2
        upperQuantile <- 1 - (alpha / 2)
        quantiles <- c(lowerQuantile, 0.5, upperQuantile)
      }
      
      # Get stratCluster if needed (always needed when alignmentSel is a vector)
      stratCluster <- model_api$stratCluster()
      
      # Call Tops function
      tryCatch({
        tops_df <- StratoBayes::Tops(
          stratObject = alignm,
          refHeights = refHeights,
          alignment = alignmentSel,
          burnIn = input$posteriorBurn/100,
          stratCluster = stratCluster,
          quantiles = quantiles
        )
        
        # Write to CSV
        write.csv(tops_df, file = file, row.names = FALSE)
      }, error = function(e) {
        showNotification(paste("Error generating well tops:", e$message), type = "error")
        # Write error message to file
        write.csv(data.frame(Error = e$message), file = file, row.names = FALSE)
      })
    },
    contentType = "text/csv"
  )

  # sync plot types between load and view
  observeEvent(input$sigPlotType_load, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_view", selected = input$sigPlotType_load)
  })
  observeEvent(input$sigPlotType_view, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_load", selected = input$sigPlotType_view)
  })

  # Posterior controls
  # Get sites and signals from alignment result, NOT from current dataset
  output$posteriorSiteSel <- renderUI({
    req(model_api$alignment())
    alignm <- model_api$alignment()
    # Get sites from alignment result's data
    sites <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData")) {
      alignm$data$sites
    } else {
      # Fallback to current dataset if alignment doesn't have data
      if (data_api$signalValid()) {
        data_api$stratData()$sites
      } else {
        character(0)
      }
    }
    
    # Get current selection to preserve user choices
    currentSelection <- input$posteriorSites
    
    # Default to first 4 sites (or all if 4 or fewer), unless user has already selected
    if (is.null(currentSelection) || length(currentSelection) == 0) {
      if (length(sites) <= 4) {
        selectedSites <- sites
      } else {
        selectedSites <- sites[1:4]
      }
    } else {
      # Preserve user's selection
      selectedSites <- currentSelection
    }
    
    checkboxGroupInput("posteriorSites", NULL,
                       choices = sites,
                       selected = selectedSites,
                       inline = TRUE
    )
  })
  output$posteriorSignalSel <- renderUI({
    req(model_api$alignment())
    alignm <- model_api$alignment()
    # Get signal columns from alignment result's data
    sigCols <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData") &&
                   !is.null(alignm$data$signalAttr) && !is.null(alignm$data$signalAttr$signalNames)) {
      alignm$data$signalAttr$signalNames
    } else {
      # Fallback to current dataset if alignment doesn't have data
      if (data_api$signalValid()) {
        data_api$signalCols()
      } else {
        character(0)
      }
    }
    plotType <- input$plotTypeMain %||% "alignment"
    
    # For correlation plot (TopsPlot), only allow one signal at a time
    # Auto-select first signal
    if (plotType == "correlation") {
      # Get current selection or default to first signal
      currentSel <- input$posteriorSignals
      if (is.null(currentSel) || length(currentSel) == 0 || length(currentSel) > 1) {
        currentSel <- if (length(sigCols) > 0) sigCols[1] else character(0)
      } else {
        # Ensure selected signal is still valid
        if (!currentSel %in% sigCols) {
          currentSel <- if (length(sigCols) > 0) sigCols[1] else character(0)
        }
      }
      radioButtons("posteriorSignals", NULL,
                   choices  = setNames(sigCols, sigCols),
                   selected = currentSel,
                   inline   = TRUE
      )
    } else {
      # For other plots, allow multiple signals
      checkboxGroupInput("posteriorSignals", NULL,
                         choices  = sigCols,
                         selected = if (is.null(input$posteriorSignals)) sigCols else input$posteriorSignals,
                         inline   = TRUE
      )
    }
  })
  # Track whether to show all alignments
  showAllAlignments <- reactiveVal(FALSE)
  
  # Reset show all when plot type changes
  observeEvent(input$plotTypeMain, {
    showAllAlignments(FALSE)
  }, ignoreInit = TRUE)
  
  # Handle show all alignments button
  observeEvent(input$showAllAlignments, {
    showAllAlignments(TRUE)
  })
  
  output$posteriorAlnSel <- renderUI({
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    nClust <- length(cl)
    
    # Determine which clusters to show
    if (showAllAlignments() || nClust <= 4) {
      clustersToShow <- cl
    } else {
      clustersToShow <- cl[1:4]
    }
    
    # Get current selection or determine default
    currentSelection <- input$posteriorAlignments
    plotType <- input$plotTypeMain %||% "alignment"
    
    # Set default selection based on plot type
    if (is.null(currentSelection) || length(currentSelection) == 0) {
      if (plotType == "correlation") {
        # Correlation: select all by default
        selectedClusters <- as.character(cl)
      } else {
        # Alignment and traceplot: select first 4 by default
        selectedClusters <- if (length(cl) <= 4) {
          as.character(cl)
        } else {
          as.character(cl[1:4])
        }
      }
    } else {
      # Use current selection - keep all selected clusters
      # When showing limited clusters, only show the ones that are visible
      # but keep the full selection so it persists when "show all" is clicked
      selectedClusters <- currentSelection
      # Ensure at least one visible cluster is selected
      visibleSelected <- selectedClusters[selectedClusters %in% as.character(clustersToShow)]
      if (length(visibleSelected) == 0 && length(clustersToShow) > 0) {
        # If none of the selected are visible, add first visible to selection
        selectedClusters <- c(selectedClusters, as.character(clustersToShow[1]))
      }
    }
    
    # Always include all clusters in choices to preserve full selection
    # Use CSS to hide/show clusters based on showAllAlignments state
    tagList(
      # Checkbox group with 2-column layout using CSS columns
      tags$div(
        id = "alignmentSelectorContainer",
        style = "column-count: 2; column-gap: 10px; margin-bottom: 10px;",
        checkboxGroupInput("posteriorAlignments", NULL,
                         choices  = setNames(as.character(cl), as.character(cl)),  # Always include all
                         selected = selectedClusters,
                         inline   = FALSE  # Vertical list, CSS columns will split into 2 columns
        )
      ),
      # Add JavaScript to hide/show clusters beyond first 4
      if (nClust > 4 && !showAllAlignments()) {
        tags$script(HTML(paste0("
          $(document).ready(function() {
            setTimeout(function() {
              var container = $('#alignmentSelectorContainer');
              var checkboxes = container.find('input[type=\"checkbox\"]');
              var clusterValues = ", jsonlite::toJSON(as.character(cl)), ";
              checkboxes.each(function(index) {
                var value = $(this).val();
                var clusterIndex = clusterValues.indexOf(value);
                if (clusterIndex >= 4) {
                  $(this).closest('div.checkbox').hide();
                }
              });
            }, 100);
          });
        ")))
      } else {
        tags$script(HTML("
          $(document).ready(function() {
            setTimeout(function() {
              $('#alignmentSelectorContainer').find('div.checkbox').show();
            }, 100);
          });
        "))
      },
      # Control buttons
      tags$div(
        style = "display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;",
        actionButton("selectAllAlignments", "Select All", 
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        actionButton("deselectAllAlignments", "Deselect All (keep 1)", 
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        if (nClust > 4 && !showAllAlignments()) {
          actionButton("showAllAlignments", "Show All Alignments", 
                      class = "btn-sm btn-info",
                      style = "font-size: 0.85em; padding: 2px 8px;")
        } else {
          NULL
        }
      )
    )
  })
  
  # Handle select all alignments
  observeEvent(input$selectAllAlignments, {
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    updateCheckboxGroupInput(session, "posteriorAlignments",
                            selected = as.character(cl))
  })
  
  # Handle deselect all alignments (keep only alignment 1)
  observeEvent(input$deselectAllAlignments, {
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    # Keep only the first alignment (or "1" if it exists)
    if (1 %in% cl) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = "1")
    } else if (length(cl) > 0) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = as.character(cl[1]))
    }
  })

  # Main plot
  output$plotOptionsUI <- renderUI({
    req(input$plotTypeMain)
    switch(input$plotTypeMain,
           "alignment" = div(style = "overflow-x:auto; white-space:nowrap; padding-bottom:0.5rem;",
                             div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Sites"),    br(), uiOutput("posteriorSiteSel")),
                             div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Signals"),  br(), uiOutput("posteriorSignalSel")),
                             div(style="display:inline-block; vertical-align:top; min-width:140px;", tags$strong("Alignments"), br(), uiOutput("posteriorAlnSel")),
                             div(style="display:inline-block; vertical-align:top; min-width:100px;", tags$strong("q"), br(), numericInput("posteriorQuantile", NULL, .5, 0, 1, step = .01, width = "100px")),
                             div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Burn-in"), br(), numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")),
                             div(style="display:inline-block; vertical-align:top; min-width:280px;", tags$strong("Style & Size"), br(),
                                 div(style="display:flex; gap:0.5rem; align-items:center;",
                                     radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"), inline = TRUE, selected = "l"),
                                     sliderInput("posteriorCex",  "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                     sliderInput("posteriorLwd",  "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                 ))
           ),
           "traceplot" = div(style = "overflow-x:auto; white-space:nowrap; padding-bottom:0.5rem;",
                             div(style="display:inline-block; vertical-align:top; min-width:140px;", tags$strong("Alignments"), br(), uiOutput("posteriorAlnSel")),
                             div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Burn-in"), br(), numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")),
                             div(style="display:inline-block; vertical-align:top; min-width:280px;", tags$strong("Style & Size"), br(),
                                 div(style="display:flex; gap:0.5rem; align-items:center;",
                                     radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"),
                                                  inline = TRUE, selected = "l"),
                                     sliderInput("posteriorCex", "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                     sliderInput("posteriorLwd", "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                 ))
           ),
           "correlation" = div(style = "overflow-x:auto; white-space:nowrap; padding-bottom:0.5rem;",
                               div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Sites"), br(), uiOutput("posteriorSiteSel")),
                               div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Signals"), br(), uiOutput("posteriorSignalSel")),
                               div(style="display:inline-block; vertical-align:top; min-width:140px;", tags$strong("Alignments"), br(), uiOutput("posteriorAlnSel")),
                               div(style="display:inline-block; vertical-align:top; min-width:120px;", tags$strong("Burn-in"), br(), numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")),
                               div(style="display:inline-block; vertical-align:top; min-width:280px;", tags$strong("Style & Size"), br(),
                                   div(style="display:flex; gap:0.5rem; align-items:center;",
                                       radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"), inline = TRUE, selected = "l"),
                                       sliderInput("posteriorCex", "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                       sliderInput("posteriorLwd", "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                   ))
           )
    )
  })

  output$mainPlot <- renderPlot({
    # Only run when these exist (prevents the getDims crash inside your plotting fns)
    req(input$plotTypeMain)
    req(model_api$alignment())
    req(model_api$stratCluster())

    alignm <- model_api$alignment()
    clust  <- model_api$stratCluster()

    switch(input$plotTypeMain,
           alignment = {
             alignmentSel <- input$posteriorAlignments
             clustUnique <- model_api$stratCluster()$clustUnique
             
             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })
             
             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]
             
             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- input$posteriorSites   %||% "all"
             signals <- input$posteriorSignals %||% 1
             style   <- input$posteriorStyle   %||% "p"
             
             # Validate quantile
             quantile_val <- input$posteriorQuantile
             if (is.null(quantile_val) || is.na(quantile_val) || 
                 !is.numeric(quantile_val) || quantile_val < 0 || quantile_val > 1) {
               quantile_val <- 0.5  # Default to median
             }

             plot(alignm,
                  alignment     = alignmentSel,
                  stratCluster  = clust,
                  sites         = sites,
                  signal        = signals,
                  separateSites = TRUE,
                  quantile      = quantile_val,
                  burnIn        = input$posteriorBurn/100,
                  type          = style,
                  cex           = input$posteriorCex,
                  lwd           = input$posteriorLwd,
                  cex.lab = 1.4, cex.axis = 1.3, cex.main = 1.4)
           },
           traceplot = {
             alignmentSel <- input$posteriorAlignments
             clustUnique <- model_api$stratCluster()$clustUnique
             
             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })
             
             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]
             
             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             style <- input$posteriorStyle %||% "l"
             TracePlot(alignm,
                       alignment = alignmentSel,
                       burnIn    = input$posteriorBurn/100,
                       type      = style,
                       cex       = input$posteriorCex,
                       lwd       = input$posteriorLwd)
           },
           correlation = {
             alignmentSel <- input$posteriorAlignments
             clustUnique <- model_api$stratCluster()$clustUnique
             
             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })
             
             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]
             
             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- input$posteriorSites   %||% "all"
             # For correlation plot, ensure only one signal is used
             # Get signal columns from alignment result, NOT from current dataset
             alignm <- model_api$alignment()
             sigCols <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData") &&
                            !is.null(alignm$data$signalAttr) && !is.null(alignm$data$signalAttr$signalNames)) {
               alignm$data$signalAttr$signalNames
             } else {
               # Fallback to current dataset if alignment doesn't have data
               if (data_api$signalValid()) {
                 data_api$signalCols()
               } else {
                 character(0)
               }
             }
             
             if (is.null(input$posteriorSignals)) {
               signals <- 1
             } else if (is.character(input$posteriorSignals) && length(input$posteriorSignals) > 0) {
               # If it's a character vector (from radioButtons), convert to index
               sigName <- input$posteriorSignals[1]  # Take first one
               if (sigName %in% sigCols) {
                 signals <- match(sigName, sigCols)
               } else {
                 signals <- 1
               }
             } else if (is.numeric(input$posteriorSignals)) {
               # If it's numeric, use first one
               signals <- if (length(input$posteriorSignals) > 1) {
                 input$posteriorSignals[1]
               } else {
                 input$posteriorSignals
               }
             } else {
               signals <- 1
             }
             style   <- input$posteriorStyle   %||% "p"

             # Parse refHeights input - ensure it's valid
             refHeights <- NULL
             if (!is.null(input$refHeights) && nzchar(trimws(input$refHeights))) {
               tryCatch({
                 refHeights <- as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(input$refHeights)), ",")))
                 refHeights <- refHeights[!is.na(refHeights) & is.finite(refHeights)]
                 if (length(refHeights) == 0) refHeights <- NULL
               }, error = function(e) {
                 refHeights <<- NULL
               })
             }
             # If refHeights is still NULL or invalid, let TopsPlot calculate it automatically
             # This prevents "missing value where TRUE/FALSE needed" errors

             # Calculate quantiles based on confidence level
             confidenceLevel <- input$confidenceLevel %||% 80
             if (confidenceLevel == 0) {
               # 0% confidence - just median
               quantiles <- 0.5
             } else if (confidenceLevel >= 100) {
               # 100% confidence - full range
               quantiles <- c(0.0, 0.5, 1.0)
             } else {
               # Calculate symmetric quantiles around median
               alpha <- (100 - confidenceLevel) / 100
               lowerQuantile <- alpha / 2
               upperQuantile <- 1 - (alpha / 2)
               quantiles <- c(lowerQuantile, 0.5, upperQuantile)
             }

             tryCatch({
               TopsPlot(alignm,
                        alignment = alignmentSel,
                        sites     = sites,
                        signal    = signals,
                        burnIn    = input$posteriorBurn/100,
                        type      = style,
                        cex       = input$posteriorCex,
                        lwd       = input$posteriorLwd,
                        refHeights = refHeights,
                        quantiles = quantiles)
             }, error = function(e) {
               # If TopsPlot fails (e.g., during QuickRun before data is fully ready),
               # show a message instead of crashing
               plot(1, 1, type = "n", 
                    xlab = "", ylab = "", 
                    main = "Tops plot not available",
                    sub = "Model may still be running or data not fully loaded")
               text(1, 1, paste("Error:", e$message), cex = 0.8, col = "red")
             })
           }
    )
  },
  height = 600,
  width  = 600  ) |> bindEvent(
    model_api$alignment(),
    input$plotTypeMain,
    input$posteriorAlignments,
    input$posteriorSites,
    input$posteriorSignals,
    input$posteriorStyle,
    input$posteriorCex,
    input$posteriorLwd,
    input$posteriorQuantile,
    input$posteriorBurn,
    input$refHeights,
    input$confidenceLevel
  )

  # simple export
  output$download_session <- downloadHandler(
    filename = function() paste0("session-", Sys.Date(), ".rds"),
    content = function(file) {
      saveRDS(list(
        data = list(
          dataset    = r$dataset,
          siteColumn = data_api$siteColumn(),
          zColumn    = data_api$zColumn(),
          signalCols = data_api$signalCols(),
          stratData  = data_api$stratData()
        ),
        model = list(
          indices      = model_api$indices(),
          priors       = model_api$priors(),
          alignment    = model_api$alignment(),
          stratCluster = model_api$stratCluster()
        )
      ), file)
    }
  )
}
