Reference <- function (authors, year, title, journal = "",
                       volume = NULL, pages = NULL, doi = NULL,
                       publisher = NULL, editors = NULL) {
  nAuth <- length(authors)
  if (nAuth > 1L) {
    authors <- paste(paste0(authors[-nAuth], collapse = ", "), "&amp;", authors[nAuth])
  }
  nEd <- length(editors)
  if (nEd > 1L) {
    editors <- paste(paste0(editors[-nEd], collapse = ", "), "&amp;", editors[nEd])
  } else if (nEd < 1) {
    editors <- ""
  }
  paste0("<p class=\"reference\">", authors, " (", year, "). &ldquo;", title,
         "&rdquo;. ",
         if (editors != "") paste0("In: ", editors, " (eds). ") else "",
         if (journal != "") paste0("<i>", journal, "</i> ") else "",
         if (is.null(volume)) "" else paste0("<b>", volume, "</b>:"),
         if (is.null(publisher)) "" else paste0(publisher, ". "),
         if (is.null(pages)) "" else paste0(paste0(pages, collapse = "&ndash;"), ". "),
         if (is.null(doi)) "" else paste0(
           "doi:<a href=\"https://doi.org/", doi, "\" target=\"_blank\" rel=\"noopener noreferrer\" onclick=\"event.stopPropagation(); return true;\" title=\"CrossRef\">",
           doi, "</a>. "),
         "</p>")
}


SBMethod <- Reference(
  "Eichenseer, K., Sinnesael, M., Smith, M.R., Millard, A.R.", "2025",
  "StratoBayes: a Bayesian method for automated stratigraphic correlation and age modelling",
  "7", "545–570",
  doi = "10.5194/gchron-7-545-2025", "Geochronology")
