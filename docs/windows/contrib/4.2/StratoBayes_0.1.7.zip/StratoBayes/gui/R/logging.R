Write <- function (txt, file) {
  if (serverEnv$loggingOn) {
    txt <- paste0(strrep(" ", logIndent), txt)
    con <- file(file, open = "a")
    on.exit(close(con))
    if (logging) {
      WriteLoggedCode(txt)
    }
    writeLines(txt, con)
  }
}

WriteP <- function (txt, file = NULL) {
  if (serverEnv$loggingOn) {
    txt <- paste0(strrep(" ", logIndent), txt)
    if (logging) {
      WriteLoggedCode(txt)
    }
    r$plotLog <- c(r$plotLog, as.character(txt))
  }
}

WriteLoggedCode <- if (isTRUE(getOption("StratoBayes.write.code"))) {
  if (requireNamespace("crayon", quietly = TRUE)) {
    function(txt) {
      for (line in txt) cat(if (substr(trimws(line), 0, 1) == "#") {
        crayon::green("  ", line, "\n")
      } else {
        crayon::yellow("  ", line, "\n")
      })
    }
  } else {
    function(txt) message("       ", txt)
  }
} else {
  function(txt) {}
}

PauseLog <- function() {
  serverEnv$loggingOn <- FALSE
}

ResumeLog <- function() {
  serverEnv$loggingOn <- TRUE
}

LogCode <- function(..., WriteFn = Write) {
  for (line in list(...)) {
    if (!is.null(line)) {
      WriteFn(as.character(line), cmdLogFile)
    }
  }
}

LogCodeP <- function(...) {
  LogCode(..., WriteFn = WriteP)
}

LogExpr <- function(exps, evaluate = TRUE, WriteFn = Write) {
  for (exp in exps) {
    WriteFn(as.character(exp), cmdLogFile)
    if (evaluate) {
      eval(exp)
    }
  }
}

LogExprP <- function(...) {
  LogExpr(..., WriteFn = WriteP)
}

LogIndent <- function(n) {
  serverEnv$logIndent <- serverEnv$logIndent + n
  if (serverEnv$logIndent < 0) {
    warning("Negative indent")
  }
}
LogComment <- function(exps, returns = 1, WriteFn = Write) {
  if (returns > 0) {
    WriteFn(rep("", returns), cmdLogFile)
  }
  for (exp in exps) {
    WriteFn(paste("#", exp), cmdLogFile)
  }
}

LogCommentP <- function (exps, returns = 1) {
  LogComment(exps, returns, WriteFn = WriteP)
}

DataFileName <- function(n) if (length(n)) {
  paste0("dataFile-", TwoWide(n), ".txt")
}

ExcelFileName <- function(n) if (length(n)) {
  paste0("excelFile-", TwoWide(n), ".xlsx")
}

LastFile <- function(type) {
  switch(pmatch(tolower(type), c("data", "excel")),
         DataFileName(r$dataFiles),
         ExcelFileName(r$excelFiles)
  )
}

CacheInput <- function(type, fileName) {
  key <- paste0(type, "Files")
  r[[key]] <- r[[key]] + 1
  file.copy(fileName, paste0(tempdir(), "/", LastFile(type)),
            overwrite = TRUE)
}


systemInfo <- c(
  paste(
    "System:", Sys.info()["sysname"], Sys.info()["release"],
    Sys.info()["version"], "-",
    .Platform$OS.type, R.version$platform
  ),
  paste(
    "-", R.version$version.string
  ),
  paste("- StratoBayes", packageVersion("StratoBayes"))
)

logCaveats <- c(
  "Before running, check that the script and any data files are in the",
  "R working directory, which can be read with getwd() and set with setwd().",
  "",
  "Please validate the code before reproducing in a manuscript, reporting",
  "any errors at https://github.com/ms609/StratoBayes/issues or by e-mail to",
  "the package maintainer."
)

BeginLog <- function() {
  LogComment(c(
    paste("# # StratoBayes session log:", .DateTime(), "# # #"),
    "",
    systemInfo,
    "",
    "This log was generated procedurally to facilitate the reproduction of",
    "results obtained during an interactive Shiny session.",
    "It is provided without guarantee of completeness or accuracy.",
    "In particular, code will not be logged when previously computed values",
    "are retrieved from cache.",
    "",
    logCaveats,
    "",
    "# # # # #"
  ))

  LogComment("Load required libraries", 2)
  LogCode(c(
    "library(\"StratoBayes\")"
  ))

  LogComment("View recommended citations", 1)
  LogCode(c(
    "citation(\"StratoBayes\")"
  ))
}

BeginLogP <- function() {
  r$plotLog <- NULL
  LogCommentP(c(
    paste("# # StratoBayes plot log:", .DateTime(), "# # #"),
    "",
    systemInfo,
    "",
    "This log was generated procedurally to facilitate the reproduction of",
    "figures obtained during an interactive Shiny session.",
    "It is provided without guarantee of completeness or accuracy.",
    "In particular, code will not be logged when previously computed values",
    "are retrieved from cache.",
    "",
    logCaveats,
    "",
    "# # # # #"
  ))
  LogCommentP("Load required libraries", 2)
  LogCodeP(c(
    "library(\"StratoBayes\")"
  ))

  LogCommentP("View recommended citations", 1)
  LogCodeP(c(
    "citation(\"StratoBayes\")",
  ))

  LogCommentP("Check working directory", 1)
  LogCodeP("getwd() # Should match location of data / tree files",
           "setwd(\".\") # Replace . with desired/directory to change")
}
