# gui-elements.R

Icon <- function(...) icon(..., class = "fas")
alignIcon <- Icon("arrow-down-up-across-line")
alignText <- "Estimate alignment"
closeIcon <- Icon("rectangle-xmark")
setupIcon <- Icon("gears")
setupText <- "Set up model run"
modelIcon <- Icon("chart-gantt")
priorIcon <- Icon("chart-area")
signalIcon <- Icon("wave-square")
signalText <- "Load signals"
modelSetupIcon <- Icon("gears")
modelSetupText <- "Model setup"

# Helper function to format numbers to 3-4 significant digits
formatPriorValue <- function(x) {
  if (is.null(x) || is.na(x) || !is.finite(x)) return(x)
  # Use signif to get 3-4 significant digits
  signif(x, digits = 4)
}

priorParams <- function(activePriorType, activePrior) {
  type <- activePriorType()        # call the reactive you were handed
  ap   <- activePrior()            # call the reactive you were handed
  if (is.null(ap)) return(tagList())  # defensive guard

  switch(
    type,
    Uniform = tagList(
      numericInput("uniformMin", "Minimum", formatPriorValue(ap$uniformMin)),
      numericInput("uniformMax", "Maximum", formatPriorValue(ap$uniformMax))
    ),
    # Gamma = tagList(
    #   numericInput("gammaAlpha", "Alpha (Shape)", formatPriorValue(ap$gammaAlpha), min = 0),
    #   numericInput("gammaBeta",  "Beta (Rate)",   formatPriorValue(ap$gammaBeta),  min = 1e-100)
    # ),
    Normal = tagList(
      numericInput("normalMean", "Mean",     formatPriorValue(ap$normalMean)),
      numericInput("normalSD",   "Std. Dev.", formatPriorValue(ap$normalSD), min = 1e-100)
    ),
    Exponential = tagList(
      numericInput("expRate", "Rate", formatPriorValue(ap$expRate), min = 1e-100)
    )
  )
}
priorTypeInput <- function(id, default) {
  # Note: This function appears to be unused in the current codebase
  # If indices() is not available (e.g., outside server context), return a basic input
  tryCatch({
    selectInput(paste0("priorType", id), indices()$names[[id]],
                choices = c("Uniform", "Normal", "Exponential"),
                selected = default)
  }, error = function(e) {
    selectInput(paste0("priorType", id), paste("Prior", id),
                choices = c("Uniform", "Normal", "Exponential"),
                selected = default)
  })
}
