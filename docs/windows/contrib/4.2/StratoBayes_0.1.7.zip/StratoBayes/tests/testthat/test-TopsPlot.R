
test_that("TopsPlot works", {
  expect_error(TopsPlot(1, 2, 2), "'stratPosterior' must be")

  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 1", function() {
    TopsPlot(stratPosterior1)
  })})

test_that("TopsPlot works with custom settings", {
  vdiffr::expect_doppelganger("TopsPlot 2", function() {

    TopsPlot(stratPosterior1, alignment = 1, sites = 3:1,
                 burnIn = 0.95, topsColourScale = "Viridis",
                 colourScale = "Dark 2", topsAlpha = 1,
                 lwd = 2)
  })})

test_that("TopsPlot works with custom settings", {
  vdiffr::expect_doppelganger("TopsPlot 3", function() {

    TopsPlot(stratPosterior0, alignment = 1, sites = 2:1,
             burnIn = 0.95, topsColourScale = "Viridis",
             colourScale = "Dark 2", topsAlpha = 1, refHeights = c(8, 11),
             topsLwd = 3, topsLty = c(2,3,1,4,5), quantiles = c(0.1, 0.2, 0.3, 0.4, 0.9),
             ylim = c(5, 15), xlim = c(0, 2), ylab = "height (m) ", pch = 1:2)
  })})



test_that("TopsPlot works on depth scale", {
  vdiffr::expect_doppelganger("TopsPlot 4", function() {

    TopsPlot(stratPosterior3, xlab = "depth (m)", alignment = 1, refHeights = c(-3, -1, 0))
  })})

# priors TopsPlot not yet implemented
#
# test_that("TopsPlot can plot prior", {
#   vdiffr::expect_doppelganger("StratMapPlot 4", function() {
#     set.seed(1)
#     StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 100)
#   })})

# test_that("TopsPlot can plot posterior and prior", {
#   vdiffr::expect_doppelganger("StratMapPlot 5", function() {
#
#     set.seed(1)
#     StratMapPlot(stratPosterior2, prior = TRUE, col = 2:3, tiesColour = 4,
#                  sites = 1:2, pch = 2, cex = 2, lwd = 2)
#   })})


test_that("TopsPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({TopsPlot(stratPosterior1)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
