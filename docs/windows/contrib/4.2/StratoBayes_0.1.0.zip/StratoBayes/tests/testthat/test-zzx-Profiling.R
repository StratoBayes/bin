# Parallel profiling
test_that("Profiling parallel runs works", {
  skip_if_not_installed("doParallel")
  r1 <- RunStratModel(stratData3, stratModel = stratModel3, nRun = 2, nIter = 100,
                      nChains = 2, visualise = FALSE, seed = 1:2,
                      runParallel = TRUE, profile = TRUE)

  prof1 <- .SummariseProfiles(r1)

  prof2 <- .SummariseProfiles(modelDir = r1[["modelDir"]],
                             modelName = r1[["modelName"]], nRun = r1[["nRun"]])

  # check that both ways of reading profiles with .SummariseProfiles work
  expect_equal(prof1, prof2)
  # correct class
  expect_s3_class(prof1, "data.frame")
})
