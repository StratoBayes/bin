
# StratData0
# StratModelTemplate(stratData0)
r1 <- range(SignalLookUp(stratData0, type = "height", site = 1))
d2 <- diff(range(SignalLookUp(stratData0, type = "height", site = 2)))

prior0a <- structure(list(
  "alpha_site2" = UniformPrior(min = r1[1] - d2, max = r1[2] + d2),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
  class = c("StratPrior", "list"))

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     userPriors = NULL)

test_that("AutoPrior() creates the correct priors", {
  expect_equal(prior0a, prior0b)
})

# custom prior
gammaPrior <- NormalPrior(mean = 0, sd = 3)
prior0a <- structure(list(
  "alpha_site2" = UniformPrior(min = r1[1] - d2, max = r1[2] + d2),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = 3)),
  class = c("StratPrior", "list"))

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     userPriors = list(gammaLog_site2 = gammaPrior))

test_that("AutoPrior() creates the correct priors with added custom prior", {
  expect_equal(prior0a, prior0b)
})

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
d2 <- diff(range(SignalLookUp(stratData2, type = "height", site = 2)))
d3 <- diff(range(SignalLookUp(stratData2, type = "height", site = 3)))

prior2a <- structure(list(
  "alpha_site2" = UniformPrior(min = r1[1] - d2, max = r1[2] + d2),
  "alpha_site3" = UniformPrior(min = r1[1] - d3, max = r1[2] + d3),
  "gammaLog_part 2.1" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 2.2" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 3.1" = NormalPrior(mean = 0, sd = log(2)),
  "gap_site2_1" = ExponentialPrior(rate = 4 / diff(r1))),
  class = c("StratPrior", "list"))
prior2b <- AutoPrior(stratData = stratData2,
                     alignmentScale = "height",
                     sedModel = "p",
                     alphaPosition = "middle",
                     userPriors = NULL)
test_that("AutoPrior() creates the correct priors for stratData2", {
  expect_equal(prior2a, prior2b)
})
