test_that("Create indices works with multi gap-names-3-sites", {
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")

  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "p", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s x p", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s, p", alphaPosition = "bottom"))

  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "p", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s x p", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s, p", alphaPosition = "b"))

  # to hit zetaNames <- NULL
  testData2 <- .GenerateTestData("single", version = "1")
  t2 <- StratData(testData2$signal)

  expect_equal(.CreateIndices(t2, alignmentScale = "height", sedModel = "s x p",
                              alphaPosition = "bottom")$names,
               c("alpha_2", "gammaLog_1"))

})
