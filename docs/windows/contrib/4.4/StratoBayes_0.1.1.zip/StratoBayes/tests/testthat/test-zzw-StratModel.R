test_that(".MatchSedModel correctly matches valid models and handles invalid input", {
  # Test valid inputs
  expect_equal(.MatchSedModel("site"), "site")
  expect_equal(.MatchSedModel("partition"), "partition")
  expect_equal(.MatchSedModel("site x partition"), "site x partition")
  expect_equal(.MatchSedModel("site, partition"), "site, partition")

  # Test valid abbreviations
  expect_equal(.MatchSedModel("s"), "site")
  expect_equal(.MatchSedModel("p"), "partition")
  expect_equal(.MatchSedModel("part"), "partition")
  expect_equal(.MatchSedModel("s x p"), "site x partition")
  expect_equal(.MatchSedModel("s x part"), "site x partition")
  expect_equal(.MatchSedModel("site x part"), "site x partition")
  expect_equal(.MatchSedModel("s, p"), "site, partition")
  expect_equal(.MatchSedModel("s, part"), "site, partition")
  expect_equal(.MatchSedModel("site, part"), "site, partition")

  # Test case insensitivity and extra whitespace handling
  expect_equal(.MatchSedModel("  Site "), "site")
  expect_equal(.MatchSedModel(" PARTITION "), "partition")
  expect_equal(.MatchSedModel("sITE X parTition"), "site x partition")
  expect_equal(.MatchSedModel(" site, partition "), "site, partition")

  # Test invalid inputs
  expect_error(.MatchSedModel("invalid"), "Invalid 'sedModel' input")
  expect_error(.MatchSedModel("sites"), "Invalid 'sedModel' input")

  # Test NULL input
  expect_error(.MatchSedModel(NULL), "sedModel is NULL")
})

#.MatchGibbsPriors
test_that(".MatchGibbsPriors throws errors", {
  expect_error(.MatchGibbsPriors(stratData1, 1,1,1,NULL),
  "bSigma")
  expect_error(.MatchGibbsPriors(stratData1, 1,1,1,NA),
               "bSigma")

  expect_error(.MatchGibbsPriors(stratData1, 1,1,1,1:2),
               "bSigma must be of length")
  expect_true(is.list(.MatchGibbsPriors(stratData2, 1,1,1,1:2)))

})

# Test suite for .MatchAlphaPosition
test_that(".MatchAlphaPosition correctly handles various inputs", {

  # Test valid position strings
  expect_equal(.MatchAlphaPosition("top", stratData1, "height"),
               as.numeric(c(NA,stratData1$partsAttr$Bound[1, 2:3])))
  pos <- as.numeric(c(stratData1$partsAttr$Bound[1, 1],
                      mean(c(stratData1$partsAttr$BoundLow[1, 2],
                             stratData1$partsAttr$Bound[1, 2])),
                      stratData1$partsAttr$BoundLow[1, 3]))
  expect_equal(.MatchAlphaPosition(c("top", "middle", "bottom"),
                                   stratData1, alignmentScale = "age"), pos)

  # Test valid numeric inputs
  expect_equal(.MatchAlphaPosition(1, stratData1, "age"), c(1, 1, 1))
  expect_equal(.MatchAlphaPosition(c(0, 1, 3), stratData1, "height"),
               c(NA, 1, 3))
  expect_equal(.MatchAlphaPosition(c(50, "middle", 10), stratData2, "age"),
               c(50, 14.92, 10), tolerance = 0.01)

  # Test invalid length input
  expect_error(.MatchAlphaPosition(c("top", "bottom"), stratData1, "age"),
               "`alphaPosition` needs to be length 1 or 3")
  expect_error(.MatchAlphaPosition(c("top", "bottom"), list(S = 4), "height"),
               "`alphaPosition` needs to be length 1, 3 or 4")

  # Test invalid position string
  expect_error(.MatchAlphaPosition("invalid", stratData1, "age"),
               "`alphaPosition\\[1\\]` \\('invalid'\\) must be 'top'")

  # Test out of bounds numeric input
  expect_error(.MatchAlphaPosition(30, stratData1, "age"),
               "`alphaPosition.1.` \\(30\\) must be >= 0 and <= 10")
  expect_error(.MatchAlphaPosition(c(5, 30, 50), stratData2, "age"),
               "`alphaPosition\\[3\\]` \\(50\\) must be >= 0 and <= 20")

  # Test non-numeric input that looks numeric
  expect_error(.MatchAlphaPosition("10abc", stratData1, "age"),
               "`alphaPosition\\[1\\]` .*10abc.* must be.*'top', 'bot")
})

# Test suite for .MatchAlignmentScale
test_that(".MatchAlignmentScale() matches valid scales", {
  # Test valid scales
  expect_equal(.MatchAlignmentScale("height"), "height")
  expect_equal(.MatchAlignmentScale("age"), "age")

  # Test case insensitivity
  expect_equal(.MatchAlignmentScale("Height"), "height")
  expect_equal(.MatchAlignmentScale("AGE"), "age")
})

test_that(".MatchAlignmentScale() handles invalid input", {
  # Test invalid scale
  expect_error(.MatchAlignmentScale("invalid"),
               "`alignmentScale` must be either 'height' or 'age'")

  # Test NULL input
  expect_error(.MatchAlignmentScale(NULL), "`alignmentScale` is NULL")
})

# Tests for .PriorsValidity

test_that(".PriorsValidity() works with stratModel1", {
  expect_true(.PriorsValidity(stratModel1$priors$metro, stratModel1$ind))
})

test_that(".PriorsValidity() works with stratModel2", {
  expect_true(.PriorsValidity(stratModel2$priors$metro, stratModel2$ind))
})

test_that(".PriorsValidity() throws errors for invalid priors", {
  expect_error(.PriorsValidity(stratModel2$priors$metro[1:6], stratModel2$ind),
               "stratModel2")
  testPrior <- stratModel2$priors$metro
  testPrior$gammaLog_site1 <- NULL
  expect_warning(expect_error(.PriorsValidity(testPrior, stratModel2$ind),
                              "Prior names do not match"))
  testPrior <- stratModel2$priors$metro
  testPrior$alpha_site2$D <- NULL
  expect_error(.PriorsValidity(testPrior, stratModel2$ind),
               "Prior 'alpha_site2'")
  testPrior <- stratModel2$priors$metro
  testPrior$gap_site2_1$args$rate <- -1
  expect_error(.PriorsValidity(testPrior, stratModel2$ind),
               "Error in R function")
})




test_that("StratModel creation works with StratData 1", {

 # StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s")

  priors <- structure(list(
    "alpha_site_2" = UniformPrior(min  = 1, max  = 10),
    "alpha_site_3" = UniformPrior(min  = 1, max  = 10),
    "gammaLog_site_2" = NormalPrior(mean  = 0, sd  = 1),
    "gammaLog_site_3" = NormalPrior(mean  = 0, sd  = 2)),
    class = c("StratPrior", "list"))

  expect_snapshot(
    StratModel(stratData = stratData1,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 25)
  )

})

test_that("StratModel creation works with StratData 2", {

  # StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "s x p")

  priors <- structure(list(
    "alpha_site2" = UniformPrior(min  = 0, max  = 20),
    "alpha_site3" = UniformPrior(min  = 5, max  = 20),
    "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
    "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
    "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 1),
    "zetaLog_site3" = NormalPrior(mean  = 0, sd  = .5),
    "gap_site2_1" = ExponentialPrior(rate  = 1)),
    class = c("StratPrior", "list"))

  expect_snapshot(
    StratModel(stratData = stratData2,
               priors = priors,
               alignmentScale = "height",
               sedModel = "site x partition",
               alphaPosition = "middle",
               nKnots = 25)
  )

})



t0 <- StratData(.GenerateTestData(version = "1")$signal)
# StratModelTemplate(t0, "h", "s", "b")
priors <- structure(list(
  "alpha_2" = UniformPrior(min  = 0, max  = 1),
  "gammaLog_2" = NormalPrior(mean  = 0, sd  = 1)),
  class = c("list", "StratPrior"))

StratModel(stratData = t0,
                    priors = priors,
                    alignmentScale = "height",
                    sedModel = "site",
                    alphaPosition = "bottom",
                    nKnots = 25)

test_that("StratModel custom specifications work and errors are correct", {
  dat7 <- StratData(signal = test_path("testdata", "test-7", "test-7-signal.csv"))
# StratModelTemplate(dat7)
  priors <- structure(list(
    `alpha_site 2` = UniformPrior(min = -120, max = 120),
    `gammaLog_site 2` = TruncNormalPrior(mean = 1, sd = 1, lower = 0.1, upper = 10)),
    class = c("StratPrior", "list"))

    # Changed with PR #224! Now expected to work due to the AutoPrior functionality
    expect_true("StratModel" %in% class(StratModel(stratData = dat7,
                            priors = NULL,
                            alignmentScale = "height",
                            sedModel = "site",
                            alphaPosition = "bottom",
                            nKnots = 5)))

  # Gibbs priors
  expect_error(StratModel(stratData = dat7, priors = priors, "h", "s", "b",
                          aLambda = "error"),
               "aLambda must be numeric.")
  expect_error(StratModel(stratData = dat7, priors = priors, "h", "s", "b",
                          aSigma = 1,
                                              bSigma = -1,
                                              aLambda = 1),
               "bSigma must be greater than 0.")

  model <- StratModel(stratData = dat7, priors = priors, "h", "s", "b",
                       aSigma = 1,
                                          bSigma = 2,
                                          aLambda = 3,
                                          bLambda = 4)
  expect_true(inherits(model, "StratModel"))
  expect_equal(model[["alignmentScale"]], "height")


  # Scale
  expect_warning(
  expect_error(StratModel(stratData = dat7, priors = priors, alignmentScale = "age", "s", "b"),
               "Prior names do not match requirements")
  , "missing priors")

  priors <- structure(list(
    `alpha_site 1` = UniformPrior(min = -120, max = 120),
    `alpha_site 2` = UniformPrior(min = -120, max = 120),
    `gammaLog_site 1` = TruncNormalPrior(mean = 1, sd = 1, lower = 0.1, upper = 10),
    `gammaLog_site 2` = TruncNormalPrior(mean = 1, sd = 1, lower = 0.1, upper = 10)
  ),
  class = c("StratPrior", "list"))

  expect_error(
    StratModel(stratData = dat7, priors = priors, alignmentScale = "age",
               "s", "b"),
    paste("cannot run the model with alignmentScale = 'age' if there have not",
          "been any ties supplied")
  )


  dat7d <- StratData(signal = test_path("testdata", "test-7", "test-7-signal.csv"),
                     ties = test_path("testdata", "test-7", "test-7-date.csv"))


  model <- StratModel(stratData = dat7d, priors = priors, alignmentScale = "age", "s", "b")
  expect_true(inherits(model, "StratModel"))

  # sedModel error
  expect_error(StratModel(stratData = dat7d, priors = priors, "a",
                           sedModel = "something else"),
               "Invalid 'sedModel' input. Please choose from")

  # flexibleKnots error
  expect_error(StratModel(stratData = dat7d, priors = priors, "a", "s", "b",
                           flexibleKnots = "something else"),
               "'flexibleKnots' needs to be logical.")

  # overlapPenalty
  model1 <- StratModel(stratData = dat7d, priors = priors,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = c(-1,2))
  model2 <- StratModel(stratData = dat7d, priors = priors,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = list(c(-1,2)))
  expect_equal(model1$overlapPenalty, model2$overlapPenalty)

  # overlapPenalty as list
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = list(c(-1,2,3), c(2,4,5)))
  expect_equal(model$overlapPenalty$adjustments[[2]], c(2,4,5))

  # overlapPenalty as vector
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = c(2,4,5))
  expect_equal(model$overlapPenalty$adjustments[[2]], c(2,4,5))

  # overlapPenalty as default
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b")
  expect_equal(model$overlapPenalty$adjustments[[2]], c(-0.9, -0.3, 0),
               tolerance = 0.25)

  # overlapPenalty TRUE
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = TRUE)
  expect_equal(model$overlapPenalty$adjustments[[2]], c(-0.9, -0.3, 0),
               tolerance = 0.25)

  # overlapPenalty FALSE


  # custom overlapPenalty function
  myPenalty <- function(stratData, myMultiplier, ...) {
    seq_len(stratData$S) * myMultiplier
  }
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = list(myPenalty, myMultiplier = 2))
  expect_equal(model$overlapPenalty$adjustments[[2]], c(2,4,6))

  myPenalty2 <- function(stratData) {
    seq_len(stratData$S) * myMultiplier
  }

  # StratModel works with AutoPrior()
  model <- StratModel(stratData = stratData1, priors = NULL,
                      alignmentScale = "height", sedModel = "s",
                      alphaPosition = "b")
  expect_equal(class(model)[[1]], "StratModel")

  # StratModel works with AutoPrior() and custom prior
  model <- StratModel(stratData = stratData1, priors = list(alpha_site_3 = NormalPrior(mean = 0, sd = 10),
                                                            gammaLog_site_3 = UniformPrior(min = 0.1, max = 10)),
                      alignmentScale = "height", sedModel = "s",
                      alphaPosition = "b")
  expect_equal(class(model)[[1]], "StratModel")

  # errors
  expect_error(StratModel(stratData = stratData2, priors = stratPrior2,
                      alignmentScale = "age", "s", "b",
                      overlapPenalty = list(myPenalty2, myMultiplier = 2)),
  "The penalty function must have")

  expect_error(StratModel(stratData = dat7d, priors = priors, "a", "s", "b",
                           overlapPenalty = "something else"),
               "overlapPenalty")
  expect_error(StratModel(stratData = dat7d, priors = priors, "a", "s", "b",
                          overlapPenalty = 1),
               "Invalid `overlapPenalty`")

  # minSignalOverlap error
  expect_error(StratModel(stratData = dat7d, priors = priors,"a", "s", "b",
                          minSignalOverlap = 25),
               "minSignalOverlap can't be larger")

  # priorsProposal
  model <- StratModel(stratData = dat7d, priors = priors,"a", "s", "b",
                          priorsProposals = priors)
  expect_true(inherits(model, "StratModel"))


  # priors length check
expect_warning(
    expect_error(StratModel(stratData = dat7d, priors = structure(list(
      `alpha_site 1` = UniformPrior(min = -120, max = 120),
      `gammaLog_site 1` = TruncNormalPrior(mean = 1, sd = 1, lower = 0.1, upper = 10),
      `alpha_site 2` = UniformPrior(min = -120, max = 120)
      ),     class = c("StratPrior", "list")), "h", "s", "b"), "[pP]rior names"),
  "unused priors")

  # priorsProposals length check
expect_warning(
expect_error(StratModel(stratData = dat7d, priors, "a", "s", "b", priorsProposals = structure(list(
  `alpha_site 1` = UniformPrior(min = -120, max = 120),
  `gammaLog_site 1` = TruncNormalPrior(mean = 1, sd = 1, lower = 0.1, upper = 10),
  `alpha_site 2` = UniformPrior(min = -120, max = 120)
), class = c("StratPrior", "list"))
), "[pP]rior names"),
"missing priors")

  # countGaps logical check
  expect_error(StratModel(stratData = dat7d, priors = priors,  "a", "s", "b", countGaps = "error"),
               "countGaps")
})
