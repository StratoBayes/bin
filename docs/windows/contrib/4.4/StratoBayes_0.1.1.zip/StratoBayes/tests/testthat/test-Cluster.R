{ # Initialize test objects
  set.seed(1)
  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- matrix(c(1, 0, 0.7, 0,
                   0, 1, 0.1, 0.1,
                   0.7, 0.1, 1, -0.5,
                   0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- matrix(c(0.7, 0, 0.4, 0,
                   0, 0.6, 0.5, 0.1,
                   0.4, 0.1, 0.75, -0.5,
                   0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4 * matrix(c(0.7, 0, -0.4, 0,
                         0, 0.6, 0.5, 0.1,
                         -0.4, 0.1, 0.75, 0.5,
                         0, 0.1, 0.5, 0.7), nrow = 4)
  data1 <- as.data.frame(rbind(
    Rfast::rmvnorm(n = n[1], mu = c(0, 0, 4, 4), sigma = cov1),
    Rfast::rmvnorm(n = n[2], mu = c(0, 5, 4, 7), sigma = cov2),
    Rfast::rmvnorm(n = n[3], mu = c(4, 0, 2, 7), sigma = cov3)
    ))

  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data2 <- as.data.frame(rbind(
    Rfast::rmvnorm(n = n[1], mu = c(0, 0, 4, 4), sigma = cov1),
    Rfast::rmvnorm(n = n[2], mu = c(0, 5, 4, 7), sigma = cov2),
    Rfast::rmvnorm(n = n[3], mu = c(4, 0, 2, 7), sigma = cov3)))
  if (interactive()) {
    plot(data2)
  }


  data3 <- data.frame(
    V1 = c(97.56527, 102.54420, 101.53206, 101.53206, 101.53206, 101.38620, 101.38620,
           100.94047, 100.94047, 99.57210, 100.33106, 100.18833, 99.34119, 99.34119,
           99.43087, 99.33477, 101.38620, 101.38620, 100.94047, 100.94047),
    V2 = c(103.02928, 108.00821, 118.25200, 109.04995, 103.32610, 103.18024, 100.84177,
           106.35769, 100.64825, 104.47125, 107.99137, 105.84992, 101.93326, 89.97386,
           87.70621, 94.24024, 103.18024, 100.84177, 106.35769, 100.64825),
    V3 = c(-0.05652142, -0.05652142, -0.04776534, -0.04776534, -0.04776534, -0.04776534,
           -0.04776534, -0.02732213, -0.02732213, -0.02991628, -0.01460799, -0.02466896,
           -0.01819302, -0.01819302, -0.01644947, -0.01931594, -0.04776534, -0.04776534,
           -0.02732213, -0.02732213),
    V4 = c(0.3448458, 0.3448458, 0.1349495, 0.1349495, 0.1349495, 0.1349495, 0.1349495,
           0.2623913, 0.2623913, 0.4074241, 0.1234816, 0.2380531, 0.4972773, 0.4972773,
           0.5936869, 0.6173871, 0.1349495, 0.1349495, 0.2623913, 0.2623913)
  )


  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(40, 9, 1)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data4 <- as.data.frame(rbind(
    Rfast::rmvnorm(n = n[1], mu = c(0, 0, 4, 4), sigma = cov1),
    Rfast::rmvnorm(n = n[2], mu = c(0, 5, 4, 7), sigma = cov2),
    Rfast::rmvnorm(n = n[3], mu = c(4, 0, 2, 7), sigma = cov3))
  )
}

test_that("Cluster.default data1 - proto", {
  set.seed(1)
    cl1 <- Cluster(data1)
    # most of the first 400 should be cluster 1
    testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.1)
    # most of the following 90 should be cluster 2
    testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.1)
})

test_that("Cluster.default data1 - proto, higher outlier", {
  set.seed(1)
  cl1 <- Cluster(data1, silOutlierThreshold = 0.3)
  # most of the last 10 should be cluster 0
  testthat::expect_equal(sum(abs(diff(cl1[491:500]) > 0)), 0, tolerance = 2)
})

test_that("Cluster.default data1 - pam", {
  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "pam")
  # most of the first 400 should be cluster 1
  testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.05)
  # most of the following 90 should be cluster 2
  testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.05)
})

test_that("Cluster.default data1 - hdbscan", {
  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "hdbscan", minPts = 4)
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))), 0, tolerance = 20)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0), 0, tolerance = 50)
})

test_that("Cluster.default data2 - proto", {
  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "proto",
                 silOutlierThreshold = 0.1)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))), 0, tolerance = 10)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0), 0, tolerance = 20)
})

test_that("Cluster.default data2 - hdbscan", {
  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(cl1Table[length(cl1Table) - c(1, 0)], c(90, 400), tolerance = 0.1)
})

test_that("Cluster.default data3 - hdbscan", {
  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) >  3)
})

test_that("Cluster.default data3 - proto", {
  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "proto", silOutlierThreshold = 0)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) <=  3)
})

test_that("Cluster.default data4 - proto", {
  set.seed(1)
  cl1 <- Cluster(data4, clusterMethod = "proto")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[41:49]))), 0, tolerance = 3)
  testthat::expect_equal(sum(abs(diff(cl1[1:40]))), 0, tolerance = 4)
  })

test_that("Cluster.StratPosterior - proto", {
set.seed(1)
cl1 <- Cluster(stratPosterior1, clusterMethod = "proto")[["cluster"]]
testthat::expect_equal(sum(cl1), length(cl1))
})

test_that("Cluster.StratPosterior - StratPosterio2", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior2, clusterMethod = "proto",
                 burnIn = 0.9)[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  condition3 <- all(cl1 %in% c(1,2))

  testthat::expect_true(all(condition1, condition2, condition3))
})

test_that("Cluster.StratPosterior - proto, lower silCutOff", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1, clusterMethod = "proto",
                 silCutOff = 1/4)[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  testthat::expect_true(all(condition1, condition2))
})

test_that("Cluster.StratPosterior - proto, extreme outlier threshold", {
  set.seed(1)
  cl1 <-  suppressWarnings( Cluster(stratPosterior1, clusterMethod = "proto",
                 silOutlierThreshold = 0.35)[["cluster"]] )
  condition1 <- length(unique(cl1)) > 3
  condition2 <- 0 %in% cl1
  testthat::expect_true(all(condition1, condition2))
})

test_that("Cluster.StratPosterior - hdbscan", {
  set.seed(1)
  cl1 <-  Cluster(stratPosterior2, clusterMethod = "hdbscan", maxSamples = 100)$cluster

  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  condition3 <- all(cl1 %in% c(1,2))

  testthat::expect_true(all(condition1, condition2, condition3))
})


test_that("Cluster.StratPosterior can deal with runSelect and selectRows", {
  set.seed(1)
  expect_error(Cluster(stratPosterior1, selectRows = list(102:101, 100:101)),
               "selectRows")
  expect_error(Cluster(stratPosterior1, runs = c(4,2),
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  expect_error(Cluster(stratPosterior1, runs = 3:1,
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = list(102:101, 100:101, NULL))[["cluster"]],
               c(1, 2))
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = 102:101)[["cluster"]],
               c(1, 2))
  expect_equal(Cluster(stratPosterior1, runs = c(3, 1),
                       selectRows = 102:101, silOutlierThreshold = 0)[["cluster"]],
               c(1, 1, 2, 2))
  expect_equal(Cluster(stratPosterior1, runs = c(3, 1),
                       selectRows = list(102:101, 100))[["runIndex"]],
               c(3, 3, 1))
  })

test_that("Cluster.StratPosterior returns Cluster Data", {
  set.seed(1)
  its <- 4950:5000
  selectedSamples <- length(which(its %in% stratPosterior2[[c("mcmcSummary", "saveIter")]][[1]])) * stratPosterior2$nRun
    cluster1 <- Cluster(stratPosterior2, iterations = its, returnClusterData = TRUE)
    expect_equal(dim(cluster1$clusterData), c(selectedSamples, length(unlist(stratPosterior2$model$heightsForClustering))))
})

test_that(".IsPositiveDefinite works", {
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3))))
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,NA,2,3,6,7,8,9), nrow = 3))))
  expect_true(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3)) + diag(3) / 1000))
})
