## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE
)


## ----plot-stratPosterior5a----------------------------------------------------
library(StratoBayes) # loading StratoBayes
plot(stratPosterior5a, alignment = 1:3, ylab = "height (m)")


## ----ties-df------------------------------------------------------------------
tiesData5 <- data.frame(site = "site2",
                        height = 3.72,
                        mean = 2.5 * pi,
                        sd = 1)


## ----ties-df-densityFun-------------------------------------------------------
tiesData5 <- data.frame(site = "site2",
                        height = 3.72,
                        densityFun = "dnorm",
                        arg1 = 2.5 * pi,
                        arg2 = 1)


## ----tie_prior_plot, fig.width = 6, fig.height = 2.5, echo = FALSE, message = FALSE, warning = FALSE----
par(mfrow = c(1,2), mar = c(3,4,1.5,1))

# ----- Panel 1: Normal -----
x <- seq(4.85, 10.85, length.out = 300)
plot(x, dnorm(x, 7.85, 0.5), type = "l", lwd = 2,
     xlab = "", ylab = "density",
     main = "Normal distribution")
lines(x, dnorm(x, 7.85, 1), lwd = 2, lty = 2)
legend("topleft", legend = c("sd = 0.5", "sd = 1"),
       lty = c(1,2), bty = "n", cex = 0.75, lwd = 2)

# ----- Panel 2: Gamma -----
xg <- seq(-0.01, 8, 0.01)
plot(xg, dgamma(xg, shape = 1, rate = 1), type = "l", lwd = 2,
     xlab = "", ylab = "density",
     main = "Gamma distribution")
lines(xg, dgamma(xg, shape = 3, rate = 1), lwd = 2, lty = 2)
legend("topright", legend = c("shape = 1, rate = 1", "shape = 3, rate = 1"),
       lty = c(1,2), bty = "n", cex = 0.75, lwd = 2)


## ----tie_prior_code, eval = FALSE---------------------------------------------
# # Code used to generate the figure above
# 
# par(mfrow = c(1,2), mar = c(3,3,1.5,1))
# 
# # Panel 1: Normal priors
# x <- seq(5, 10, length.out = 300)
# plot(x, dnorm(x, 7.85, 0.5), type = "l", lwd = 2,
#      xlab = "Reference height (m)", ylab = "density",
#      main = "Normal priors")
# lines(x, dnorm(x, 7.85, 1), lwd = 2, lty = 2)
# legend("topleft", legend = c("sd = 0.5", "sd = 1"),
#        lty = c(1,2), bty = "n", cex = 0.8)
# 
# # Panel 2: Gamma priors
# xg <- seq(0, 8, length.out = 300)
# plot(xg, dgamma(xg, shape = 1, rate = 1), type = "l", lwd = 2,
#      xlab = "Reference height (m)", ylab = "density",
#      main = "Gamma priors")
# lines(xg, dgamma(xg, shape = 3, rate = 1), lwd = 2, lty = 2)
# legend("topright", legend = c("shape = 1, rate = 1", "shape = 3, rate = 1"),
#        lty = c(1,2), bty = "n", cex = 0.8)


## ----prob-dist, eval = F, echo = F--------------------------------------------
# par(mfrow = c(1,3))
# x <- seq(-3, 3, 0.01)
# y <- dnorm(x)
# plot(x, y, type = "l", lwd = 2)


## ----StratData----------------------------------------------------------------
stratData5b <- StratData(signal = signalData5, ties = tiesData5, referenceSite = "site1")
summary(stratData5b)


## ----plot-StratData-----------------------------------------------------------
plot(stratData5b, show = "partition")


## ----run-model, eval = FALSE--------------------------------------------------
# # get min and max height of reference site for prior
# site1Min <- min(signalData5$height[signalData5$site == "site1"])
# site1Max <- max(signalData5$height[signalData5$site == "site1"])
# # define prior
# stratPrior5 <- structure(list(
#   "alpha_site2" = UniformPrior(min = site1Min, max = site1Max),
#   "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
#   class = c("StratPrior", "list"))
# # define model
# stratModel5b <- StratModel(stratData = stratData5b,
#                            priors = stratPrior5,
#                            alignmentScale = "height",
#                            sedModel = "site",
#                            alphaPosition = "middle",
#                            nKnots = 15,
#                            sigmaFixed = T)
# # run model
# stratPosterior5b <- RunStratModel(stratObject = stratData5b,
#                                   stratModel = stratModel5b,
#                                   nRun = 3,
#                                   nIter = 400,
#                                   nThin = 10,
#                                   runParallel = TRUE)


## ----plot-alignment-----------------------------------------------------------
plot(stratPosterior5b, ylab = "reference height (m)")


## ----StratMap-----------------------------------------------------------------
StratMap(stratPosterior5b, height = 3.72, site = 2)


## ----StratMap-values, echo = FALSE--------------------------------------------
posteriorTie <- round(StratMap(stratPosterior5b, height = 3.72, site = 2)[ ,c("mean", "sd")],2)

