# Development aid: run from the package source root (not from the installed
# package) to regenerate inst/extdata/signalData1_result1.rds.
stratDat <- StratData(signal = StratoBayes::signalData1)

plot(stratDat)

priors <- list(
  alpha_site_2 = UniformPrior(min = -6, max = 12),
  alpha_site_3 = UniformPrior(min = -6, max = 12),
  gammaLog_site_2 = NormalPrior(mean = 0, sd = 0.7),
  gammaLog_site_3 = NormalPrior(mean = 0, sd = 0.7)
)

result <- RunStratModel(stratObject = stratDat,
              nRun = 3,
              runParallel = TRUE,
              nIter = 5000,
              nThin = 25,
              nChains = 6,
              priors = priors,
              alignmentScale = "height",
              sedModel = "site",
              nKnots = 15,
              seed = 1:3,
              sigmaFixed = TRUE)

saveRDS(result, "inst/extdata/signalData1_result1.rds")
