## inst/gui/dialog/modelProgressModal.R
modelProgressModal <- function() {
  modalDialog(
    title = "Model Run Progress",
    size = "l",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "padding: 20px; min-height: 600px;",
        tags$h4("Model is running..."),
        tags$p("Progress will appear below once the model starts."),
        br(),
        uiOutput("modelProgressIframe")
      )
    ),
    
    footer = tagList(
      actionButton("closeProgressModal", "Close", 
                  class = "btn-secondary",
                  style = "float: right;")
    )
  )
}
