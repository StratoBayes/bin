## inst/gui/dialog/importResultsModal.R
importResultsModal <- function() {
  modalDialog(
    title = "Import Results",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "padding: 20px;",
        tags$h4("Import results from disk"),
        tags$p("Load a StratPosterior object from an RDS file."),
        br(),
        fileInput("importResultsFile", "Select RDS file:",
                 accept = c(".rds", ".RDS"),
                 placeholder = "Choose a .rds file",
                 width = "100%"),
        br(),
        textInput("importResultsName", "Name for this result (optional):",
                 value = "",
                 placeholder = "Leave empty to use file name",
                 width = "100%"),
        helpText("The result will be loaded and added to your session results list.", 
                style = "font-size: 0.9em; color: #666; margin-top: 5px;")
      )
    ),
    
    footer = tagList(
      actionButton("cancelImportResults", "Cancel", 
                  class = "btn-secondary",
                  style = "float: left;"),
      actionButton("confirmImportResults", "Import", 
                  class = "btn-primary",
                  style = "float: right;")
    )
  )
}
