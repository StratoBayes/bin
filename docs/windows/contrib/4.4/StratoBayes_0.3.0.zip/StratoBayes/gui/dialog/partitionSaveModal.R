## inst/gui/dialog/partitionSaveModal.R
partitionSaveModal <- function(partitionCount = 0, currentDatasetName = NULL) {
  modalDialog(
    title = "Save Partitions?",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "text-align: center; padding: 20px;",
        tags$h4("Partitions Created"),
        tags$p(paste("You have created", partitionCount, "partition boundary(ies).")),
        tags$p("Would you like to save the data with these partitions, or discard them?"),
        br(),
        tags$div(
          style = "margin-top: 20px;",
          textInput("savePartitionDataName", "Dataset name (optional):",
                   value = if (!is.null(currentDatasetName)) currentDatasetName else paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S")),
                   placeholder = "Leave empty for auto-name",
                   width = "100%"),
          helpText("If you don't provide a name, one will be generated automatically.", 
                  style = "font-size: 0.9em; color: #666; margin-top: 5px;")
        )
      )
    ),
    
    footer = tagList(
      actionButton("discardPartitions", "Discard", 
                  class = "btn-danger",
                  style = "float: left;"),
      conditionalPanel(
        "output.showOverwriteOption",
        actionButton("overwritePartitions", "Overwrite Saved Data", 
                    class = "btn-warning",
                    style = "float: left; margin-left: 10px;")
      ),
      actionButton("savePartitions", "Save with New Name", 
                  class = "btn-success",
                  style = "float: right;")
    )
  )
}
