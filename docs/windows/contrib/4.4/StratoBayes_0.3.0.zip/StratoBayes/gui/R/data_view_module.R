# inst/gui/R/data_view_module.R
# Data View module: controls + plot (no run buttons here — those stay in the dialog so IDs remain global)

data_view_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("controls")),
    br(),
    tags$div(
      style = "display:flex; align-items:center; gap:10px; margin-bottom:6px;",
      tags$span(
        style = "color:#6c757d; font-size:0.85em;",
        "Drag a rectangle on any panel then double-click that panel to zoom; double-click without a brush to reset that panel."
      ),
      actionButton(ns("resetZoom"), "Reset all zoom",
                   class = "btn-sm btn-secondary", icon = icon("undo"))
    ),
    uiOutput(ns("plotsContainer")),
    br(),
    tags$div(
      style = "padding:8px; background-color:#fafafa; border:1px solid #eee; border-radius:5px;",
      tags$div(
        style = "display:flex; align-items:center; justify-content:space-between; gap:10px;",
        tags$div(
          tags$strong("Manual axis override"),
          tags$span(style = "color:#6c757d; font-size:0.85em; margin-left:8px;",
                    "applied when a panel has no brush zoom set")
        ),
        actionButton(ns("resetManualAxes"), "Reset axes",
                     class = "btn-sm btn-secondary", icon = icon("undo"))
      ),
      fluidRow(
        column(6,
               tags$div(style = "margin-top:4px; font-weight:500;", "x-range (signal value)"),
               fluidRow(
                 column(6, numericInput(ns("xlimMin"), "min", value = NA, width = "100%")),
                 column(6, numericInput(ns("xlimMax"), "max", value = NA, width = "100%"))
               )
        ),
        column(6,
               tags$div(style = "margin-top:4px; font-weight:500;", "y-range (z / height)"),
               fluidRow(
                 column(6, numericInput(ns("ylimMin"), "min", value = NA, width = "100%")),
                 column(6, numericInput(ns("ylimMax"), "max", value = NA, width = "100%"))
               )
        )
      )
    ),
    # Clean Data panel
    tags$details(
      style = "margin-top:10px; padding:8px; background-color:#fafafa; border:1px solid #ddd; border-radius:5px;",
      tags$summary(tags$strong("Clean data"),
                   tags$span(style = "color:#6c757d; font-size:0.85em; margin-left:8px;",
                             "trim depths/heights per site, or cap signal values per signal")),
      br(),
      uiOutput(ns("cleanZUI")),
      br(),
      uiOutput(ns("cleanValueUI")),
      br(),
      actionButton(ns("cleanApply"), "Apply cleaning",
                   class = "btn-sm btn-primary", icon = icon("check")),
      actionButton(ns("cleanReset"), "Reset cleaning",
                   class = "btn-sm btn-warning", icon = icon("undo"),
                   style = "margin-left:6px;")
    )
  )
}

data_view_server <- function(id, data_api) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    # Defaults/caps:
    # - fresh render starts with up to 4 selected sites/signals
    # - user can add more, up to a hard site cap
    .DEFAULT_MAX_SELECTED <- 4L
    .MAX_SITES_SELECTED <- 12L

    # Keep immediate selections for cap enforcement, and debounced selections
    # for plotting so rapid multi-click updates render only once.
    viewSiteSelected <- reactive({ input$viewSiteSelect %||% character(0) })
    viewSignalSelected <- reactive({ input$viewSignalSelect %||% character(0) })
    viewSiteForPlot <- debounce(viewSiteSelected, 350L)
    viewSignalForPlot <- debounce(viewSignalSelected, 350L)

    # Preserve click-order so when caps are exceeded we can drop oldest picks.
    sitePickOrder <- reactiveVal(character(0))
    signalPickOrder <- reactiveVal(character(0))

    # Per-panel zoom state, keyed by panel id.
    zoomState <- reactiveValues()
    # Track which per-panel observers/outputs have already been wired up so the
    # renderUI loop doesn't keep piling on duplicate observers.
    regObs <- reactiveValues(registered = character(0))

    panelId <- function(sig_idx, site_idx) sprintf("panel_%d_%d", sig_idx, site_idx)

    # Format numeric hints with 5 significant digits, falling back gracefully.
    .fmtNum <- function(x) {
      if (!is.finite(x)) return("NA")
      formatC(x, digits = 5, format = "g", big.mark = "")
    }

    # Controls (site/signal/style/cex/lwd).
    #
    # IMPORTANT: this renderUI must NOT depend on input$viewSiteSelect /
    # input$viewSignalSelect (those are set by the checkboxes this UI
    # creates). Doing so produces a loop: click -> renderUI re-runs ->
    # checkboxes are regenerated -> Shiny sends another input change ->
    # renderUI re-runs again, which the user perceives as "jumping back
    # and forth". Previous selections are read once with isolate().
    output$controls <- renderUI({
      req(data_api$signalValid())
      sd    <- data_api$stratData()
      req(sd)
      sites <- sd$sites
      sigs  <- data_api$signalCols()

      selectedSites <- isolate({
        prev <- input$viewSiteSelect
        if (!is.null(prev) && length(prev) > 0) intersect(prev, sites)
        else head(sites, .DEFAULT_MAX_SELECTED)
      })
      selectedSigs <- isolate({
        prev <- input$viewSignalSelect
        if (!is.null(prev) && length(prev) > 0) intersect(prev, sigs)
        else head(sigs, .DEFAULT_MAX_SELECTED)
      })

      tagList(
        fluidRow(
          column(3,
                 tags$div(
                   style = "display:flex; align-items:center; gap:8px; margin-bottom:6px; flex-wrap:wrap;",
                   tags$strong("Sites to display"),
                   actionLink(ns("viewSiteAll"), "All",
                              style = "font-size:0.85em;"),
                   tags$span("|", style = "color:#ccc;"),
                   actionLink(ns("viewSiteNone"), "None",
                              style = "font-size:0.85em;")
                 ),
                 div(class = "strat-checklist sb-view-checklist",
                     style = if (length(sites) > 10) "max-height:220px; overflow-y:auto; padding:4px; border:1px solid #ddd; border-radius:4px;" else NULL,
                     checkboxGroupInput(ns("viewSiteSelect"), NULL,
                                        choices  = sites,
                                        selected = selectedSites
                     )
                 )
          ),
          column(3,
                 tags$div(
                   style = "display:flex; align-items:center; gap:8px; margin-bottom:6px; flex-wrap:wrap;",
                   tags$strong("Signals to display"),
                   actionLink(ns("viewSignalAll"), "All",
                              style = "font-size:0.85em;"),
                   tags$span("|", style = "color:#ccc;"),
                   actionLink(ns("viewSignalNone"), "None",
                              style = "font-size:0.85em;")
                 ),
                 div(class = "strat-checklist sb-view-checklist",
                     style = if (length(sigs) > 10) "max-height:220px; overflow-y:auto; padding:4px; border:1px solid #ddd; border-radius:4px;" else NULL,
                     checkboxGroupInput(ns("viewSignalSelect"), NULL,
                                        choices  = sigs,
                                        selected = selectedSigs
                     )
                 )
          ),
          column(2,
                 radioButtons(ns("sigPlotType_view"), "Style",
                              c("Pts"="p","Lines"="l","Both"="o"),
                              selected = "l", inline = TRUE
                 )
          ),
          column(4,
                 fluidRow(
                   column(6, sliderInput(ns("viewCex"), "● size", min=0.5, max=5, value=1, step=0.1, width="100%")),
                   column(6, sliderInput(ns("viewLwd"), "— width", min=0.5, max=5, value=2, step=0.5, width="100%"))
                 )
          )
        )
      )
    })

    # Select all / none for the view panel
    observeEvent(input$viewSiteAll, {
      sd <- tryCatch(data_api$stratData(), error = function(e) NULL)
      if (is.null(sd)) return()
      updateCheckboxGroupInput(session, "viewSiteSelect", selected = sd$sites)
    })
    observeEvent(input$viewSiteNone, {
      updateCheckboxGroupInput(session, "viewSiteSelect", selected = character(0))
    })
    observeEvent(input$viewSignalAll, {
      sigs <- tryCatch(data_api$signalCols(), error = function(e) NULL)
      if (is.null(sigs)) return()
      updateCheckboxGroupInput(session, "viewSignalSelect", selected = sigs)
    })
    observeEvent(input$viewSignalNone, {
      updateCheckboxGroupInput(session, "viewSignalSelect", selected = character(0))
    })

    # Enforce selection caps directly in the controls.
    # Priority: keep the most recently selected entries and drop oldest.
    observeEvent(list(input$viewSiteSelect, input$viewSignalSelect), {
      sd <- tryCatch(data_api$stratData(), error = function(e) NULL)
      sigs_all <- tryCatch(data_api$signalCols(), error = function(e) NULL)
      if (is.null(sd) || is.null(sigs_all)) return()

      cur_sites <- intersect(viewSiteSelected(), sd$sites)
      cur_sigs <- intersect(viewSignalSelected(), sigs_all)

      # Update click-order trackers.
      so <- sitePickOrder()
      so <- c(so[so %in% cur_sites], setdiff(cur_sites, so))
      sitePickOrder(so)
      go <- signalPickOrder()
      go <- c(go[go %in% cur_sigs], setdiff(cur_sigs, go))
      signalPickOrder(go)

      site_cap <- .MAX_SITES_SELECTED

      if (length(cur_sites) > site_cap) {
        keep_sites <- tail(so, site_cap)
        sitePickOrder(keep_sites)
        updateCheckboxGroupInput(session, "viewSiteSelect", selected = keep_sites)
      }
    }, ignoreInit = TRUE)

    # Global manual xlim/ylim overrides that apply when a panel has no per-panel brush zoom.
    global_xlim <- reactive({
      lo <- suppressWarnings(as.numeric(input$xlimMin))
      hi <- suppressWarnings(as.numeric(input$xlimMax))
      if (is.finite(lo) && is.finite(hi) && lo < hi) c(lo, hi) else NULL
    })
    global_ylim <- reactive({
      lo <- suppressWarnings(as.numeric(input$ylimMin))
      hi <- suppressWarnings(as.numeric(input$ylimMax))
      if (is.finite(lo) && is.finite(hi) && lo < hi) c(lo, hi) else NULL
    })

    observeEvent(input$resetZoom, {
      for (nm in names(reactiveValuesToList(zoomState))) {
        zoomState[[nm]] <- NULL
      }
      updateNumericInput(session, "xlimMin", value = NA)
      updateNumericInput(session, "xlimMax", value = NA)
      updateNumericInput(session, "ylimMin", value = NA)
      updateNumericInput(session, "ylimMax", value = NA)
    })

    observeEvent(input$resetManualAxes, {
      updateNumericInput(session, "xlimMin", value = NA)
      updateNumericInput(session, "xlimMax", value = NA)
      updateNumericInput(session, "ylimMin", value = NA)
      updateNumericInput(session, "ylimMax", value = NA)
    })

    # Scale-aware mapping between the raw data (positive depths when
    # dataScale == "depth") and the plot/display coordinate system (where
    # depth values are negated to match StratData's internal convention).
    .zRaw2Display <- function(x, scale) {
      if (!is.null(scale) && identical(scale, "depth")) -as.numeric(x) else as.numeric(x)
    }
    .zDisplay2Raw <- function(x, scale) {
      if (!is.null(scale) && identical(scale, "depth")) -as.numeric(x) else as.numeric(x)
    }

    # Helper: lazily register renderPlot + dblclick observer for a given panel.
    ensurePanel <- function(sig_idx, site_idx) {
      pid <- panelId(sig_idx, site_idx)
      if (pid %in% regObs$registered) return(pid)
      local({
        i_ <- sig_idx
        j_ <- site_idx
        pid_ <- panelId(i_, j_)
        brush_id <- paste0(pid_, "_brush")
        dbl_id   <- paste0(pid_, "_dbl")

        output[[pid_]] <- renderPlot({
          req(data_api$signalValid())
          sd <- data_api$stratData()
          req(sd)
          sites <- intersect(viewSiteForPlot() %||% sd$sites, sd$sites)
          sigs  <- intersect(viewSignalForPlot() %||% data_api$signalCols(),
                              data_api$signalCols())
          req(i_ <= length(sigs), j_ <= length(sites), cancelOutput = TRUE)
          sig_name  <- sigs[i_]
          site_name <- sites[j_]
          sig_idx_m <- match(sig_name, sd$signalAttr$signalNames)
          common <- list(
            cex  = input$viewCex %||% 1,
            lwd  = input$viewLwd %||% 2,
            type = input$sigPlotType_view %||% "l"
          )
          z <- zoomState[[pid_]]
          xl <- if (!is.null(z) && !is.null(z$xlim)) z$xlim else global_xlim()
          yl <- if (!is.null(z) && !is.null(z$ylim)) z$ylim else global_ylim()
          if (!is.null(xl)) common$xlim <- xl
          if (!is.null(yl)) common$ylim <- yl
          tryCatch({
            do.call(plot, c(list(x = sd, signal = sig_idx_m, sites = site_name,
                                 overridePar = FALSE), common))
          }, error = function(e) {
            plot.new()
            text(0.5, 0.55, labels = "Plot unavailable for current layout", cex = 0.95)
            text(0.5, 0.43, labels = "Reduce selected sites/signals", cex = 0.85, col = "#666666")
          })
        })

        observeEvent(input[[dbl_id]], {
          br <- input[[brush_id]]
          if (!is.null(br)) {
            zoomState[[pid_]] <- list(
              xlim = c(br$xmin, br$xmax),
              ylim = c(br$ymin, br$ymax)
            )
          } else {
            zoomState[[pid_]] <- NULL
          }
        })
      })
      regObs$registered <- c(regObs$registered, pid)
      pid
    }

    # Plots: one plotOutput per (signal, site) cell so brush coordinates are
    # well-defined per panel. Uses debounced selections so rapid tick/untick
    # does not trigger an avalanche of plot re-renders.
    output$plotsContainer <- renderUI({
      req(data_api$signalValid())
      sd <- data_api$stratData()
      req(sd)
      sites <- intersect(viewSiteForPlot() %||% sd$sites, sd$sites)
      sigs  <- intersect(viewSignalForPlot() %||% data_api$signalCols(),
                          data_api$signalCols())
      if (length(sites) == 0L || length(sigs) == 0L) {
        return(tags$em("Please select at least one site and one signal."))
      }

      rows <- lapply(seq_along(sigs), function(i) {
        panels <- lapply(seq_along(sites), function(j) {
          pid <- ensurePanel(i, j)
          tags$div(
            style = "display:inline-block; width:240px; min-width:240px; margin-right:8px; vertical-align:top;",
            plotOutput(
              ns(pid),
              height   = "360px",
              width    = "240px",
              brush    = brushOpts(id = ns(paste0(pid, "_brush")), resetOnNew = TRUE),
              dblclick = ns(paste0(pid, "_dbl"))
            )
          )
        })
        tags$div(
          style = "white-space:nowrap; margin-bottom:8px;",
          panels
        )
      })
      tags$div(
        class = "sb-top-scroll-wrap",
        do.call(tagList, rows)
      )
    })

    # ---- Clean data UI ----
    # Per-site z-range inputs. Displayed values honour the chosen data scale:
    # depth mode is shown negated so it matches the y-axis on the plot, while
    # internally the stored filter continues to reference raw data coordinates.
    output$cleanZUI <- renderUI({
      req(data_api$signalValid())
      sd <- data_api$stratData()
      req(sd)
      raw <- tryCatch(data_api$rawdata(), error = function(e) NULL)
      sc <- data_api$siteColumn()
      zc <- data_api$zColumn()
      scale <- tryCatch(data_api$dataScale(), error = function(e) "depth")
      if (is.null(raw) || is.null(sc) || is.null(zc)) return(NULL)

      sites <- intersect(viewSiteForPlot() %||% sd$sites, sd$sites)
      if (length(sites) == 0L) return(tags$em("Select at least one site to configure z-cuts."))

      cs <- data_api$cleanSettings
      rows <- lapply(sites, function(s) {
        zv <- suppressWarnings(as.numeric(raw[[zc]][trimws(as.character(raw[[sc]])) == s]))
        zv <- zv[is.finite(zv)]
        if (length(zv) < 1L) return(NULL)
        # default (and stored) ranges live in raw coordinates; convert to
        # display for the UI.
        rng_default_raw <- range(zv)
        rng_default_display <- sort(.zRaw2Display(rng_default_raw, scale))
        existing <- tryCatch(isolate(cs$zRange[[s]]), error = function(e) NULL)
        if (!is.null(existing) && all(is.finite(existing))) {
          rng_user_display <- sort(.zRaw2Display(existing, scale))
          lo_val <- rng_user_display[1]
          hi_val <- rng_user_display[2]
        } else {
          lo_val <- rng_default_display[1]
          hi_val <- rng_default_display[2]
        }
        fluidRow(
          column(4,
                 tags$div(style = "padding-top:24px;",
                   tags$div(style = "font-weight:500;", s),
                   tags$div(style = "color:#6c757d; font-size:0.8em;",
                            sprintf("data %s to %s",
                                    .fmtNum(rng_default_display[1]),
                                    .fmtNum(rng_default_display[2])))
                 )
          ),
          column(4, numericInput(ns(paste0("cleanZmin_", s)), "keep from",
                                 value = signif(lo_val, 5), width = "100%")),
          column(4, numericInput(ns(paste0("cleanZmax_", s)), "keep to",
                                 value = signif(hi_val, 5), width = "100%"))
        )
      })
      rows <- rows[!vapply(rows, is.null, logical(1))]
      if (length(rows) == 0L) return(NULL)
      scale_label <- if (identical(scale, "depth")) "depth (negative downward)" else "height"
      tagList(
        tags$strong(sprintf("Per-site z-range (%s, %s)", zc, scale_label)),
        br(), br(),
        do.call(tagList, rows)
      )
    })

    # Per-signal value-range inputs (only for currently-selected signals).
    output$cleanValueUI <- renderUI({
      req(data_api$signalValid())
      sd <- data_api$stratData()
      req(sd)
      raw <- tryCatch(data_api$rawdata(), error = function(e) NULL)
      if (is.null(raw)) return(NULL)

      sigs <- intersect(viewSignalForPlot() %||% data_api$signalCols(),
                        data_api$signalCols())
      if (length(sigs) == 0L) return(tags$em("Select at least one signal to configure value-cuts."))

      cs <- data_api$cleanSettings
      rows <- lapply(sigs, function(sig) {
        if (!(sig %in% colnames(raw))) return(NULL)
        vals <- suppressWarnings(as.numeric(raw[[sig]]))
        vals <- vals[is.finite(vals)]
        if (length(vals) < 1L) return(NULL)
        rng_default <- range(vals)
        existing <- tryCatch(isolate(cs$valueRange[[sig]]), error = function(e) NULL)
        lo_val <- if (!is.null(existing) && is.finite(existing[1])) existing[1] else rng_default[1]
        hi_val <- if (!is.null(existing) && is.finite(existing[2])) existing[2] else rng_default[2]
        fluidRow(
          column(4,
                 tags$div(style = "padding-top:24px;",
                   tags$div(style = "font-weight:500;", sig),
                   tags$div(style = "color:#6c757d; font-size:0.8em;",
                            sprintf("data %s to %s",
                                    .fmtNum(rng_default[1]), .fmtNum(rng_default[2])))
                 )
          ),
          column(4, numericInput(ns(paste0("cleanVmin_", sig)), "keep from",
                                 value = signif(lo_val, 5), width = "100%")),
          column(4, numericInput(ns(paste0("cleanVmax_", sig)), "keep to",
                                 value = signif(hi_val, 5), width = "100%"))
        )
      })
      rows <- rows[!vapply(rows, is.null, logical(1))]
      if (length(rows) == 0L) return(NULL)
      tagList(
        tags$strong("Per-signal value range (out-of-range values become NA)"),
        br(), br(),
        do.call(tagList, rows)
      )
    })

    observeEvent(input$cleanApply, {
      sd <- tryCatch(data_api$stratData(), error = function(e) NULL)
      raw <- tryCatch(data_api$rawdata(), error = function(e) NULL)
      sc <- tryCatch(data_api$siteColumn(), error = function(e) NULL)
      zc <- tryCatch(data_api$zColumn(), error = function(e) NULL)
      scale <- tryCatch(data_api$dataScale(), error = function(e) "depth")

      # Per-site z range: store only when user narrowed the default range.
      # Numeric inputs live in display coordinates (negated for depth); the
      # filter runs against raw data so we convert back before storing.
      if (!is.null(sd) && !is.null(raw) && !is.null(sc) && !is.null(zc)) {
        for (s in sd$sites) {
          lo_disp <- input[[paste0("cleanZmin_", s)]]
          hi_disp <- input[[paste0("cleanZmax_", s)]]
          lo_disp <- suppressWarnings(as.numeric(lo_disp))
          hi_disp <- suppressWarnings(as.numeric(hi_disp))
          if (!is.finite(lo_disp) || !is.finite(hi_disp) || lo_disp >= hi_disp) {
            data_api$setCleanZRange(s, NULL)
            next
          }
          raw_edges <- .zDisplay2Raw(c(lo_disp, hi_disp), scale)
          lo <- min(raw_edges)
          hi <- max(raw_edges)
          zv <- suppressWarnings(as.numeric(raw[[zc]][trimws(as.character(raw[[sc]])) == s]))
          zv <- zv[is.finite(zv)]
          if (length(zv) == 0L) {
            data_api$setCleanZRange(s, NULL)
            next
          }
          full <- range(zv)
          if (lo <= full[1] + 1e-12 && hi >= full[2] - 1e-12) {
            data_api$setCleanZRange(s, NULL)
          } else {
            data_api$setCleanZRange(s, c(lo, hi))
          }
        }
      }

      # Per-signal value range: likewise store only when narrowed.
      sigs_all <- tryCatch(data_api$signalCols(), error = function(e) NULL)
      if (!is.null(raw) && !is.null(sigs_all)) {
        for (sig in sigs_all) {
          lo <- input[[paste0("cleanVmin_", sig)]]
          hi <- input[[paste0("cleanVmax_", sig)]]
          lo <- suppressWarnings(as.numeric(lo))
          hi <- suppressWarnings(as.numeric(hi))
          if (!is.finite(lo) || !is.finite(hi) || lo >= hi) {
            data_api$setCleanValueRange(sig, NULL)
            next
          }
          if (!(sig %in% colnames(raw))) next
          vv <- suppressWarnings(as.numeric(raw[[sig]]))
          vv <- vv[is.finite(vv)]
          if (length(vv) == 0L) {
            data_api$setCleanValueRange(sig, NULL)
            next
          }
          full <- range(vv)
          if (lo <= full[1] + 1e-12 && hi >= full[2] - 1e-12) {
            data_api$setCleanValueRange(sig, NULL)
          } else {
            data_api$setCleanValueRange(sig, c(lo, hi))
          }
        }
      }
      showNotification("Cleaning applied.", type = "message", duration = 3)
    })

    observeEvent(input$cleanReset, {
      data_api$resetCleanSettings()
      showNotification("Cleaning reset.", type = "message", duration = 3)
    })
  })
}
