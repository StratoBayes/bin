safe_colnames <- function(x) {
  nms <- names(x)
  bad <- which(is.na(nms) | nms=="")

  if (length(bad)) {
    # build X1, X2, … names that don’t collide with real headers
    auto <- make.unique(sprintf("X%d", seq_along(bad)))
    nms[bad] <- auto
    names(x) <- nms
  }
  x
}

# Define null-coalescing operator (used throughout the codebase but not defined)
`%||%` <- function(a, b) if (is.null(a)) b else a

# logging (optional)
logging <- isTRUE(getOption("StratoBayes.logging"))

if (logging) {
  logMsgFile <- file("log.lg", open = "w+")
  LogMsg <- function(...) {
    message(.DateTime(), ": ", ...)
    writeLines(.DateTime(), con = logMsgFile)
    writeLines(paste0("  ", ...), con = logMsgFile)
  }
  BeginLog <- function(...) LogMsg("Started server")
} else {
  LogMsg <- function(...) {}
  BeginLog <- function(...) {}
}

getDims <- function(x) {
  if (is.null(x)) return(c(NA_integer_, NA_integer_))

  # Safe length check - handle cases where length() returns zero-length vector
  len <- tryCatch(length(x), error = function(e) 0)
  if (length(len) == 0 || len == 0) return(c(NA_integer_, NA_integer_))

  if (is.data.frame(x)) return(c(nrow(x), ncol(x)))
  if (is.matrix(x))     return(dim(x))
  stop("getDims: unsupported type: ", paste(class(x), collapse = "/"))
}

# helper: clear all fields in a reactiveValues()
clear_reactivevalues <- function(rv) {
  for (nm in names(rv)) rv[[nm]] <- NULL
  invisible(rv)
}


# Safely (re)build the Posterior controls based on the CURRENT model.
refresh_posterior_controls <- function(session, data_api, model_api,
                                       ids = list(
                                         sites   = "posteriorSites",
                                         signals = "posteriorSignals",
                                         aligns  = "posteriorAlignments"
                                       )) {

  # Alignment object drives site choices
  align <- model_api$alignment()
  if (!is.null(align) && !is.null(align$sites)) {
    sites <- align$sites
    updateCheckboxGroupInput(session, ids$sites,
                             choices  = sites,
                             selected = sites
    )
  }

  # Signals (from data_api)
  sc <- tryCatch(data_api$signalCols(), error = function(e) NULL)
  if (!is.null(sc) && length(sc)) {
    updateCheckboxGroupInput(session, ids$signals,
                             choices  = sc,
                             selected = sc
    )
  }

  # Clusters from current stratCluster
  cl <- tryCatch(model_api$stratCluster()$clustUnique, error = function(e) NULL)
  if (!is.null(cl) && length(cl)) {
    labs <- setNames(as.character(cl), as.character(cl))
    updateCheckboxGroupInput(session, ids$aligns,
                             choices  = labs,
                             selected = names(labs)
    )
  }

  invisible(TRUE)
}
