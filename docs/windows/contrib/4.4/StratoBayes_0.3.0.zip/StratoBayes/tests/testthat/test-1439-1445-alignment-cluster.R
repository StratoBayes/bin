# Regression tests for area-11 alignment validation and cluster accessors:
# #1439, #1440, #1441, #1442, #1443, #1445 (red-team round, area 11).
#
# #1444 (Cluster.StratPosterior() with an all-empty selectRows) is Refs-only:
# ExtractParameters()'s own `if (nrow(output) == 0) stop(...)` check (in place
# since 2024, well before this round) unconditionally precedes the
# clusterData/`.RescueAllNoiseClusters()` code the issue describes, so the
# `range(numeric(0))` path it names is not reachable for an all-empty
# `selectRows` -- see the PR body for the executed repro. No test here.

.A11CacheFixtureDir <- .PosteriorFixtureRun(1, 143901)

.A11FreshPosterior <- function() {
  suppressMessages(StratPosterior(readDir = .A11CacheFixtureDir))
}

# Deparsed namespace, one entry per function, named so a hit says which one.
# `R/*.R` is not readable under `R CMD check` -- tests there run against the
# installed package, whose `R/` is a lazy-load database -- and reading it via
# `test_path()` makes these checks error (or, with `list.files()`, pass
# vacuously). `deparse()` drops comments and normalises layout, so the
# whitespace squish is what keeps a wrapped expression greppable.
.A11DeparsedFunctions <- function() {
  ns <- asNamespace("StratoBayes")
  vapply(ls(ns, all.names = TRUE), function(nm) {
    obj <- get(nm, envir = ns)
    if (!is.function(obj)) return("")
    gsub("\\s+", " ", paste(deparse(obj, width.cutoff = 500L), collapse = " "))
  }, character(1))
}

test_that("#1440: hand-rolled alignment[1] != 'all' sites now use .IsAllAlignment()", {
  # Mechanical de-duplication check: no function should still hand-roll the
  # check `.IsAllAlignment()` exists to replace.
  src <- .A11DeparsedFunctions()
  hits <- grep('alignment(Input)?\\[\\[?1\\]?\\]?\\s*!=\\s*"all"', src)
  expect_identical(names(src)[hits], character(0))
})

test_that("#1440: ExtractIterations() skips clustering entirely for an all-equivalent alignment", {
  sp <- .A11FreshPosterior()

  # Pre-fix, `alignment[1] != "all"` does not recognise "None"/"All" as
  # equivalent to "all" and triggers a full, discarded clustering pass for
  # what should be a no-op filter. Mocking `.ClusterInternal()` to fail turns
  # that wasted call into a hard, observable red.
  testthat::local_mocked_bindings(
    .ClusterInternal = function(...) {
      stop("clustering was invoked for an all-equivalent alignment")
    },
    .package = "StratoBayes"
  )

  allSel <- ExtractIterations(sp, alignment = "all")
  expect_no_error(noneSel <- ExtractIterations(sp, alignment = "None"))
  expect_no_error(capsAllSel <- ExtractIterations(sp, alignment = "All"))
  expect_identical(noneSel, allSel)
  expect_identical(capsAllSel, allSel)
})

test_that("#1439: ExtractParameters() validates alignment on the stratCluster-supplied branch", {
  sp <- .A11FreshPosterior()
  sc <- Cluster(sp)
  nClust <- sc[["nClust"]]

  # Pre-fix, an out-of-range alignment silently returns whatever subset
  # matches (often nothing/partial) instead of erroring -- exactly the
  # divergence ExtractIterations()'s own (validated) path does not have.
  expect_error(
    ExtractParameters(sp, stratCluster = sc, alignment = c(1, nClust + 98)),
    "between"
  )

  # A value ExtractParameters()'s own documentation (`man/ExtractParameters.Rd`)
  # promises is equivalent to "all" must not error on this branch.
  expect_no_error(ExtractParameters(sp, stratCluster = sc, alignment = "none"))

  # The stratCluster-supplied branch and the no-stratCluster branch must agree
  # for a genuinely valid, in-range alignment.
  viaCluster <- ExtractParameters(sp, stratCluster = sc, alignment = 1)
  viaDefault <- ExtractParameters(sp, alignment = 1)
  expect_equal(viaCluster, viaDefault)
})

test_that("#1441: hist.StratPosterior()'s dead plotClusts-based indices are gone", {
  # Smoke/hygiene check, not a behaviour pin: the deleted pair was provably
  # dead (immediately shadowed), so there is no observable output to
  # discriminate on. This only confirms the source no longer contains it and
  # that the surviving (allClusts-based) logic still runs without error.
  src <- .A11DeparsedFunctions()[["hist.StratPosterior"]]
  expect_false(grepl("which(plotClusts != 0)", src, fixed = TRUE))
  expect_false(grepl("which(plotClusts == 0)", src, fixed = TRUE))
  # Positive control: the surviving `allClusts` pair must still be found by
  # this same search, or the two expectations above could pass on a string
  # that simply no longer resembles the code.
  expect_true(grepl("which(allClusts != 0)", src, fixed = TRUE))
  expect_true(grepl("which(allClusts == 0)", src, fixed = TRUE))

  sp <- .A11FreshPosterior()
  expect_no_error(
    suppressWarnings(hist(sp, colourBy = "alignment", display = FALSE))
  )
})

test_that("#1442: ExtractIterations() rejects a missing/empty alignment before clustering", {
  sp <- .A11FreshPosterior()

  # Pre-fix, this reaches the raw `alignment[1] != "all"` check with no
  # presence guard, surfacing as an unhelpful low-level error ("argument is
  # of length zero") that names neither `alignment` nor the actual cause.
  errNull <- tryCatch(ExtractIterations(sp, alignment = NULL),
                       error = function(e) conditionMessage(e))
  errEmpty <- tryCatch(ExtractIterations(sp, alignment = character(0)),
                        error = function(e) conditionMessage(e))

  expect_true(grepl("alignment", errNull, ignore.case = TRUE))
  expect_true(grepl("alignment", errEmpty, ignore.case = TRUE))
})

test_that("#1443: .CacheStamp() carries a clusterInputs fingerprint", {
  stamp <- .CacheStamp(array(seq_len(8), dim = c(2, 2, 2, 1)), nRun = 1)
  expect_setequal(names(stamp),
                   c("dim", "dimnames", "length", "nRun", "probe", "total",
                     "clusterInputs", "mcmcSummary"))
  expect_setequal(names(stamp[["clusterInputs"]]),
                   c("ind", "siteIndices", "heightsForClustering",
                     "sedSmoothInfo", "data"))
})

test_that("#1443: a mutated model/data copy misses the posterior cache; an unmutated one still hits", {
  sp <- .A11FreshPosterior()
  expect_false(is.null(.PosteriorCache(sp)))

  # One value each, not the whole field: #1992 holds these inputs whole, so a
  # single edit anywhere in them is caught. (They used to be probed at 32
  # points, which this test had to mutate every value to be sure of hitting.)
  spModelMutated <- sp
  spModelMutated$model$heightsForClustering[[1]][[1]] <-
    spModelMutated$model$heightsForClustering[[1]][[1]] + 1000
  expect_null(.PosteriorCache(spModelMutated))

  spDataMutated <- sp
  lastRow <- nrow(spDataMutated$data$signal)
  spDataMutated$data$signal$height[lastRow] <-
    spDataMutated$data$signal$height[lastRow] + 1000
  expect_null(.PosteriorCache(spDataMutated))

  spSedMutated <- sp
  spSedMutated$model$sedSmoothInfo <- list(betaMap = matrix(1L, 2, 2))
  expect_null(.PosteriorCache(spSedMutated))

  # An unmutated copy of the same object must still hit -- the fix must not
  # turn every access into a forced miss.
  spSame <- sp
  expect_false(is.null(.PosteriorCache(spSame)))
})

test_that("#1445: .PlotSegmentedLines() draws a cluster contributing exactly one point", {
  calls <- list()
  testthat::local_mocked_bindings(
    points = function(x, y, ...) {
      calls[[length(calls) + 1]] <<- list(x = x, y = y)
    },
    .package = "StratoBayes"
  )

  x <- c(1, 2, 3, 4)
  y <- c(10, 20, 30, 40)
  # group 1 (indices 1,2,4): 3 points, one adjacent-row-index pair (1,2) and
  # one isolated point (4, not adjacent to 2). group 2 (index 3): exactly
  # one point. Both 3 and 4 are cases the pre-fix code never drew -- a
  # length-1 group falls through its (empty) adjacent-pair loop entirely,
  # and index 4 fails the loop's `index_end == index_start + 1` guard against
  # its only neighbour (2) the same way.
  z <- c(1, 1, 2, 1)
  .PlotSegmentedLines(x, y, z, colours = c("black", "red"),
                      tempArgs = list(type = "l"))

  drawnPoint <- function(px, py) {
    any(vapply(calls, function(cl) identical(cl$x, px) && identical(cl$y, py),
               logical(1)))
  }
  # The lone point (index 3, cluster 2) must be drawn as its own call.
  expect_true(drawnPoint(3, 30))
  # The isolated point (index 4, cluster 1, no adjacent same-cluster
  # neighbour) must also be drawn.
  expect_true(drawnPoint(4, 40))
  # The adjacent pair (indices 1,2, cluster 1) must still be drawn (revert-
  # check for all three cases: segment, singleton group, isolated point).
  expect_true(any(vapply(calls, function(cl)
    setequal(cl$x, c(1, 2)) && setequal(cl$y, c(10, 20)), logical(1))))
})
