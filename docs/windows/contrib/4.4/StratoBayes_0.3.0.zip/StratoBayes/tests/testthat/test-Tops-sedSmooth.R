# Tops() on sedSmooth models: the spline age map has no closed-form inverse,
# so .CalculateRefHeightToHeights() root-finds through the same quadrature the
# forward map (.CalculateNewAgesSedSmooth()) uses. The unit tests below need no
# MCMC: indices, spline setup and a random sedBeta are enough to exercise every
# branch of the inverse.

.SedSmoothFixture <- function(data, alignmentScale, nBasis = 6L, seed = 1) {
  ind <- .CreateIndices(data, alignmentScale, "site, partition", "middle",
                        sedSmooth = TRUE)
  info <- .SetupSedSmooth(data, alignmentScale, "site, partition", nBasis)
  set.seed(seed)
  list(ind = ind, info = info,
       sedBeta = rnorm(info[["totalBeta"]], sd = 0.5))
}

.NamedParams <- function(ind, ...) {
  params <- setNames(rep(0, length(ind[["names"]])), ind[["names"]])
  given <- c(...)
  stopifnot(all(names(given) %in% names(params)))
  params[names(given)] <- given
  params
}

test_that("sedSmooth inverse round-trips the forward map on the height scale", {
  fx <- .SedSmoothFixture(stratData1, "height")
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)

  for (site in 2:3) {
    hLow <- stratData1[[c("partsAttr", "BoundLow")]][[1, site]]
    hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, site]]
    heights <- c(hLow, seq(hLow, hHigh, length.out = 7)[-c(1, 7)], hHigh)

    ages <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, site,
                                       heights, fx$info, fx$sedBeta)
    # a varying rate: the map must not be the constant-rate straight line
    expect_gt(sd(diff(ages) / diff(heights)), 1e-3)

    back <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, site,
                                         ages, fx$info, fx$sedBeta)
    expect_equal(back, heights, tolerance = 1e-8)
  }
})

test_that("sedSmooth inverse with sedBeta = 0 equals the constant-rate inverse", {
  ind_smooth <- .CreateIndices(stratData1, "height", "site, partition",
                               "middle", sedSmooth = TRUE)
  ind_const <- .CreateIndices(stratData1, "height", "site, partition",
                              "middle", sedSmooth = FALSE)
  info <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)
  zeroBeta <- rep(0, info[["totalBeta"]])
  refHeights <- c(4.2, 5, 5.9)

  for (site in 2:3) {
    expect_equal(
      .CalculateRefHeightToHeights(stratData1, ind_smooth, c(5, 5), site,
                                   refHeights, info, zeroBeta),
      .CalculateRefHeightToHeights(stratData1, ind_const, c(5, 5, 0, 0), site,
                                   refHeights),
      tolerance = 1e-10
    )
  }
})

test_that("sedSmooth inverse handles multi-partition sites, gaps and shared boundaries", {
  # stratData2 site 2: formations [-1.17, 10.5], [10.5, 20], [20, 31] with a
  # zero-width gap partition at 20 m carrying `gap_site2_1`
  fx <- .SedSmoothFixture(stratData2, "height")
  params <- .NamedParams(fx$ind, alpha_site2 = 50, alpha_site3 = 60,
                         gap_site2_1 = 3)
  boundLow <- stratData2[[c("partsAttr", "BoundLow")]][, 2]
  bound <- stratData2[[c("partsAttr", "Bound")]][, 2]
  expect_true(stratData2[[c("partsAttr", "gaps")]][3, 2])

  heights <- c(0, 5, 10.5, 12, 19.9, 20, 25, 31)
  ages <- .CalculateNewAgesSedSmooth(stratData2, fx$ind, params, 2, heights,
                                     fx$info, fx$sedBeta)
  back <- .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, ages,
                                       fx$info, fx$sedBeta)
  expect_equal(back, heights, tolerance = 1e-8)

  # the shared boundary at 10.5 m resolves from either side to 10.5
  expect_equal(back[3], 10.5, tolerance = 1e-10)

  # an age strictly inside the hiatus resolves to the gap height, 20 m
  alphas <- .CalculateAlphasSedSmooth(stratData2, fx$ind,
                                      .AdjustParams(params, fx$ind), 2,
                                      fx$info, fx$sedBeta)
  inGap <- (alphas[[3]] + alphas[[4]]) / 2
  expect_gt(abs(alphas[[4]] - alphas[[3]]), 1)
  expect_identical(
    .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, inGap,
                                 fx$info, fx$sedBeta),
    unname(bound[[3]])
  )
})

test_that("sedSmooth inverse warns when a negative gap overlaps partitions (#1170)", {
  # The overlap warning is not specific to the constant-rate arm: whether two
  # partitions overlap is decided by their age limits, which sedSmooth does not
  # change. Restricting it to constant rates once made the sedSmooth answer
  # silently wrong again. A negative gap cannot come from `priors`
  # (.CheckGapPriorSupport), but a hand-supplied `parameters` vector reaches here.
  fx <- .SedSmoothFixture(stratData2, "height")
  params <- .NamedParams(fx$ind, alpha_site2 = 50, alpha_site3 = 60,
                         gap_site2_1 = -3)
  alphas <- .CalculateAlphasSedSmooth(stratData2, fx$ind,
                                      .AdjustParams(params, fx$ind), 2,
                                      fx$info, fx$sedBeta)
  # with a positive gap these bracket the hiatus; negated they cross, so their
  # midpoint lies inside partition 2 (top 20 m) and partition 4 (base 20 m) both
  overlapAge <- (alphas[[3]] + alphas[[4]]) / 2

  expect_warning(
    .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, overlapAge,
                                 fx$info, fx$sedBeta),
    "Partitions 2, 4 of site 2 overlap in age"
  )

  # an age inside one partition only must stay silent
  expect_no_warning(
    .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, alphas[[2]],
                                 fx$info, fx$sedBeta)
  )
})

test_that("sedSmooth inverse on the age scale: round trip, gap and edge-rate extrapolation", {
  fx <- .SedSmoothFixture(stratData2, "age")
  expect_equal(fx$ind[["ageHeightSign"]], -1)
  params <- .NamedParams(fx$ind, alpha_site1 = 60, alpha_site2 = 55,
                         alpha_site3 = 50, gap_site2_1 = 4)
  boundLow <- stratData2[[c("partsAttr", "BoundLow")]][, 2]
  bound <- stratData2[[c("partsAttr", "Bound")]][, 2]

  heights <- c(-1, 3, 10.5, 15, 20, 24, 31)
  ages <- .CalculateNewAgesSedSmooth(stratData2, fx$ind, params, 2, heights,
                                     fx$info, fx$sedBeta)
  expect_true(all(diff(ages) < 0))
  back <- .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, ages,
                                       fx$info, fx$sedBeta)
  expect_equal(back, heights, tolerance = 1e-8)

  alphas <- .CalculateAlphasSedSmooth(stratData2, fx$ind,
                                      .AdjustParams(params, fx$ind), 2,
                                      fx$info, fx$sedBeta)
  inGap <- (alphas[[3]] + alphas[[4]]) / 2
  expect_identical(
    .CalculateRefHeightToHeights(stratData2, fx$ind, params, 2, inGap,
                                 fx$info, fx$sedBeta),
    unname(bound[[3]])
  )

  # beyond the domain the inverse extrapolates linearly with the spline rate
  # at the nearest formation end; check against a finite difference of the
  # forward integral rather than against .SedSplineRate() itself
  formIdx <- fx$info[["betaMap"]][, 2]
  eps <- 1e-6
  oldest <- alphas[[1]]                                    # base of site 2
  rateBase <- .SedSplinePartialIntegral(fx$sedBeta, fx$info, formIdx[[1]],
                                        boundLow[[1]], boundLow[[1]] + eps) / eps
  youngest <- ages[[length(ages)]]                         # top of site 2
  rateTop <- .SedSplinePartialIntegral(fx$sedBeta, fx$info, formIdx[[4]],
                                       bound[[4]] - eps, bound[[4]]) / eps
  extrap <- .CalculateRefHeightToHeights(
    stratData2, fx$ind, params, 2, c(oldest + 2, youngest - 2),
    fx$info, fx$sedBeta
  )
  expect_equal(extrap[[1]], boundLow[[1]] - 2 / rateBase, tolerance = 1e-5)
  expect_equal(extrap[[2]], bound[[4]] + 2 / rateTop, tolerance = 1e-5)
})

test_that("sedSmooth inverse refuses site 1 on the height scale and a missing sedBeta", {
  fx <- .SedSmoothFixture(stratData1, "height")
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  expect_error(
    .CalculateRefHeightToHeights(stratData1, fx$ind, params, 1, 5,
                                 fx$info, fx$sedBeta),
    "site 1 has no alpha parameters"
  )
  expect_error(
    .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, 5,
                                 sedSmoothInfo = fx$info),
    "requires both `sedSmoothInfo` and `sedBeta`"
  )
  # a sedSmooth model must never fall through to the constant-rate inverse
  expect_error(
    .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, 5),
    "requires both `sedSmoothInfo` and `sedBeta`"
  )
})

test_that("sedSmooth inverse extrapolates on the height scale with the edge rate", {
  # on the height scale a refHeight inside the reference site can still lie
  # beyond the interval a correlated site covers (RT-360 is the constant-rate
  # case); the site's end rate then extends the mapping linearly
  fx <- .SedSmoothFixture(stratData1, "height")
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  hLow <- stratData1[[c("partsAttr", "BoundLow")]][[1, 2]]
  hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, 2]]
  formIdx <- fx$info[["betaMap"]][[1, 2]]
  ageEnds <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2,
                                        c(hLow, hHigh), fx$info, fx$sedBeta)
  eps <- 1e-6
  rateLow <- .SedSplinePartialIntegral(fx$sedBeta, fx$info, formIdx,
                                       hLow, hLow + eps) / eps
  rateHigh <- .SedSplinePartialIntegral(fx$sedBeta, fx$info, formIdx,
                                        hHigh - eps, hHigh) / eps

  extrap <- .CalculateRefHeightToHeights(
    stratData1, fx$ind, params, 2, c(ageEnds[[1]] - 1.5, ageEnds[[2]] + 1.5),
    fx$info, fx$sedBeta
  )
  expect_equal(extrap[[1]], hLow - 1.5 / rateLow, tolerance = 1e-5)
  expect_equal(extrap[[2]], hHigh + 1.5 / rateHigh, tolerance = 1e-5)
})

test_that("sedSmooth inverse stays finite and in range for an extreme draw", {
  # a wild draw makes the moving-node quadrature of the forward map slightly
  # non-monotone within a knot span; the inverse must still terminate inside
  # the formation
  fx <- .SedSmoothFixture(stratData1, "height")
  set.seed(7)
  wildBeta <- rnorm(fx$info[["totalBeta"]], sd = 6)
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  hLow <- stratData1[[c("partsAttr", "BoundLow")]][[1, 2]]
  hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, 2]]
  ageEnds <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2,
                                        c(hLow, hHigh), fx$info, wildBeta)
  ages <- seq(ageEnds[[1]], ageEnds[[2]], length.out = 50)

  back <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, ages,
                                       fx$info, wildBeta)
  expect_true(all(is.finite(back)))
  expect_true(all(back >= hLow & back <= hHigh))
  forward <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2, back,
                                        fx$info, wildBeta)
  expect_equal(forward, ages, tolerance = 1e-11)

  # a draw whose rate overflows has no usable map: NA, not an error. The
  # infinite age span already trips the partition-level guard; the span-level
  # inverse behind it answers the same way when called directly.
  overflowBeta <- rep(800, fx$info[["totalBeta"]])
  expect_warning(
    overflow <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2,
                                             c(5, 6), fx$info, overflowBeta),
    "well-defined age limits"
  )
  expect_identical(overflow, c(NA_real_, NA_real_))
  formIdx <- fx$info[["betaMap"]][[1, 2]]
  expect_identical(
    .SedSplineHeights(overflowBeta, fx$info, formIdx, c(5, 6), 5, 1),
    c(NA_real_, NA_real_)
  )
})

test_that("sedSmooth inverse converges where a Newton step cycles in the bracket", {
  # this draw sends Newton into a two-cycle strictly inside the bracket, which
  # the out-of-bracket test alone never interrupts
  fx <- .SedSmoothFixture(stratData1, "height")
  set.seed(504)
  cyclingBeta <- rnorm(fx$info[["totalBeta"]], sd = 4)
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  hLow <- stratData1[[c("partsAttr", "BoundLow")]][[1, 2]]
  hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, 2]]
  ageEnds <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2,
                                        c(hLow, hHigh), fx$info, cyclingBeta)
  ages <- seq(ageEnds[[1]], ageEnds[[2]], length.out = 500)

  expect_silent(
    back <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, ages,
                                         fx$info, cyclingBeta)
  )
  expect_true(all(back >= hLow & back <= hHigh))
  forward <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2, back,
                                        fx$info, cyclingBeta)
  expect_true(all(is.finite(forward)))
  expect_lt(max(abs(forward - ages)), 1e-8)
})

test_that("sedSmooth inverse reports ages it cannot invert instead of returning them", {
  # an unconverged height is not an answer; the iteration cap has to say so
  fx <- .SedSmoothFixture(stratData1, "height")
  formIdx <- fx$info[["betaMap"]][[1, 2]]
  ages <- 5 + c(0.4, 0.8)
  expect_warning(
    capped <- .SedSplineHeights(fx$sedBeta, fx$info, formIdx, ages, 5, 1,
                                maxIter = 1L),
    "did not invert to within tolerance"
  )
  expect_identical(capped, c(NA_real_, NA_real_))
  expect_false(anyNA(
    .SedSplineHeights(fx$sedBeta, fx$info, formIdx, ages, 5, 1)
  ))
})

test_that("sedSmooth inverse returns NA where the sedimentation rate underflows", {
  fx <- .SedSmoothFixture(stratData1, "height")
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  hLow <- stratData1[[c("partsAttr", "BoundLow")]][[1, 2]]
  hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, 2]]

  # fully underflowed: the site spans no age at all, so it has no invertible
  # mapping -- NA, as for an overflowed draw, rather than a silent +-Inf
  underflowBeta <- rep(-800, fx$info[["totalBeta"]])
  expect_warning(
    underflow <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2,
                                              c(4, 5, 6), fx$info,
                                              underflowBeta),
    "well-defined age limits"
  )
  expect_identical(underflow, rep(NA_real_, 3))

  # underflowed over the top knot span only: the rest of the formation still
  # inverts, and one flat span must not take the whole batched call down
  formIdx <- fx$info[["betaMap"]][[1, 2]]
  topBeta <- fx$sedBeta
  topIdx <- fx$info[["betaStart"]][[formIdx]] + fx$info[["nBasis"]] - 1L
  topBeta[c(topIdx - 1L, topIdx)] <- -800
  ageEnds <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2,
                                        c(hLow, hHigh), fx$info, topBeta)
  ages <- seq(ageEnds[[1]], ageEnds[[2]], length.out = 5)
  expect_silent(
    back <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, ages,
                                         fx$info, topBeta)
  )
  expect_true(all(is.finite(back)))
  expect_true(all(back >= hLow & back <= hHigh))

  # beyond the top of that site the rate is zero, so the linear extension has
  # no slope to follow
  expect_warning(
    beyond <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2,
                                           ageEnds[[2]] + 1, fx$info, topBeta),
    "cannot be extrapolated"
  )
  expect_identical(beyond, NA_real_)
})

test_that("the forward age at a formation's top inverts back to the top exactly", {
  # classification, inversion and the forward map must share one integral: a
  # top age classified one ulp beyond the partition is extrapolated instead of
  # inverted, and the height it returns leaves the site, so .SignalsToBind()
  # drops it and StratMap(Tops(...)) gives NA. Seeds 18 and 34 did exactly
  # that when the partition limits came from .SedSplineFullIntegral().
  fx <- .SedSmoothFixture(stratData1, "height")
  params <- .NamedParams(fx$ind, alpha_site_2 = 5, alpha_site_3 = 5)
  hHigh <- stratData1[[c("partsAttr", "Bound")]][[1, 2]]

  for (seed in 1:50) {
    set.seed(seed)
    beta <- rnorm(fx$info[["totalBeta"]], sd = 1)
    top <- .CalculateNewAgesSedSmooth(stratData1, fx$ind, params, 2, hHigh,
                                      fx$info, beta)
    back <- .CalculateRefHeightToHeights(stratData1, fx$ind, params, 2, top,
                                         fx$info, beta)
    # inside the site, so .SignalsToBind() keeps it, and at the top
    expect_lte(back, unname(hHigh), label = paste("seed", seed))
    expect_equal(back, unname(hHigh), tolerance = 1e-12,
                 info = paste("seed", seed))
  }
})

test_that("sedSmooth inverse resolves a thin formation at a large coordinate", {
  # tolerances proportional to the formation's span alone fall below one ulp
  # of the absolute coordinate, and then no age converges at all
  form <- .BuildFormationSpline(2000, 2000.1, 6L, 1L)
  info <- list(formations = list(form), nBasis = form[["nBasis"]],
               nFormations = 1L, totalBeta = form[["nBasis"]], betaStart = 1L,
               betaMap = matrix(1L, 1, 1))
  set.seed(11)
  beta <- rnorm(form[["nBasis"]])
  ends <- .SedSplineAges(beta, info, 1L, c(2000, 2000.1), 300, 1)
  ages <- seq(ends[[1]], ends[[2]], length.out = 19)

  expect_silent(h <- .SedSplineHeights(beta, info, 1L, ages, 300, 1))
  expect_false(anyNA(h))
  expect_true(all(h >= 2000 & h <= 2000.1))
  expect_equal(.SedSplineAges(beta, info, 1L, h, 300, 1), ages,
               tolerance = 1e-14)
})

test_that("Tops() refuses prior sampling for sedSmooth models, as StratMap() does", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  expect_error(
    Tops(model, refHeights = 5, stratData = stratData1),
    "Tops\\(\\) does not support prior sampling for sedSmooth"
  )
})

test_that("Tops() and TopsPlot() work on a sedSmooth posterior", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 50, nThreads = 1L)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE, seed = 3)

  refHeights <- c(3, 4, 5)
  tops <- Tops(result, refHeights = refHeights, maxSamples = 10)
  expect_s3_class(tops, "data.frame")
  expect_equal(nrow(tops), length(refHeights) * 2)
  expect_setequal(as.character(tops[["site"]]), c("site_2", "site_3"))
  expect_true(all(is.finite(tops[["mean"]])))
  expect_true(all(is.finite(tops[["50%"]])))

  topsSamples <- Tops(result, refHeights = refHeights, maxSamples = 10,
                      quantiles = "samples")
  nSamples <- ncol(topsSamples) - 2L
  expect_gt(nSamples, 1L)

  # a user-supplied `parameters` must line up with the retained sedBeta draws
  rows <- .maxSampleDeterministicRows(
    ExtractIterations(result, "all", 0.5, NULL, 10,
                      .ValidateRunSelect("all", result[["nRun"]])), 10)
  metro <- as.matrix(ExtractParameters(result, "parameters", selectRows = rows))
  expect_equal(nrow(metro), nSamples)

  # Tops() must invert StratMap(): it selects the same draws and extracts the
  # sedBeta columns on its own, so a round trip pins Tops()'s extraction. A
  # mis-paired draw would invert draw j's reference height through draw k's
  # spline and miss the height it started from.
  #
  # The alignment is supplied rather than taken from the chain. With the
  # chain's own alphas there is nothing to invert unless 50 iterations happen
  # to reach an alignment overlapping the reference: 6 of 10 seeds checked
  # nothing, and a seed does not fix that across platforms, since macOS libc++
  # draws a different stream from libstdc++. `alpha` is exactly additive on the
  # reference scale, so anchoring each draw's site midpoint at the middle of
  # the reference range puts the round trip in range on every stream.
  refMid <- 0.5 * (stratData1[[c("partsAttr", "BoundLow")]][[1, 1]] +
                     stratData1[[c("partsAttr", "Bound")]][[1, 1]])
  alphaNames <- paste0("alpha_", stratData1[["sites"]][2:3])
  unshifted <- metro
  unshifted[, alphaNames] <- 0
  anchored <- metro
  midHeights <- numeric(2)
  for (site in 2:3) {
    mid <- 0.5 * (stratData1[[c("partsAttr", "BoundLow")]][[1, site]] +
                    stratData1[[c("partsAttr", "Bound")]][[1, site]])
    midHeights[[site - 1L]] <- mid
    atZero <- StratMap(result, heights = mid, site = site, maxSamples = 10,
                       quantiles = "samples", parameters = unshifted)
    anchored[, alphaNames[[site - 1L]]] <- refMid - as.numeric(atZero[1, -1])
  }
  back <- Tops(result, refHeights = refMid, maxSamples = 10,
               quantiles = "samples", parameters = anchored)
  for (site in 2:3) {
    siteRow <- back[["site"]] == stratData1[["sites"]][[site]]
    expect_equal(
      as.numeric(back[siteRow, paste0("sample_", seq_len(nSamples))]),
      rep(midHeights[[site - 1L]], nSamples), tolerance = 1e-8
    )
  }

  expect_equal(
    Tops(result, refHeights = refHeights, maxSamples = 10, parameters = metro),
    tops
  )
  expect_error(
    Tops(result, refHeights = refHeights, maxSamples = 10,
         parameters = metro[1:3, , drop = FALSE]),
    "one row per retained draw"
  )

  expect_no_error(
    TopsPlot(result, refHeights = refHeights, maxSamples = 10, display = FALSE)
  )
  # the sedSmooth vignette lists summary() among the tools that work
  expect_no_error(summary(result))
})
