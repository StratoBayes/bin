# RT-744/#1076: the Prior move must be priced against the density it SAMPLES
# from.
#
# The Prior move is an independence proposal drawing the whole metro vector
# from `priorsProposals` (g). Its exact correction is log g(x) - log g(x*).
# The C++ engine differenced `logPostSep[0]` -- the *prior* density -- instead,
# which is the same function only while g == prior. A PT_CUSTOM prior whose
# `priorsProposals` entry differs is the one case where it is not, and there
# the mismatch biases the stationary distribution rather than merely costing
# efficiency (see the closed-form test below).

# ── Closed-form ground truth for the mispricing ─────────────────────────────
# 1-D conjugate: prior P = N(0, 1), proposal g = Q = N(0, 3),
# likelihood N(y = 3; theta, 1).
#   Correct  (target P * L)                : mean 1.5,  sd sqrt(0.5)  = 0.7071
#   Mispriced (differencing P, not Q)      : logAlpha collapses to the pure
#     likelihood ratio, whose Q-proposal independence sampler is invariant for
#     Q * L: mean 2.7, sd sqrt(0.9) = 0.9487.
# The bug therefore samples the posterior of a model whose prior is the
# PROPOSAL, which is why no efficiency argument covers it.

test_that("pricing a g-drawn Prior move against the prior samples g * L (#1076)", {
  logD <- function(x, sd) dnorm(x, 0, sd, log = TRUE)
  logLik <- function(theta) dnorm(3, theta, 1, log = TRUE)

  run <- function(priced, n = 1.2e5) {
    x <- 0
    keep <- numeric(n)
    for (i in seq_len(n)) {
      xs <- rnorm(1, 0, 3)                        # independence draw from g
      lh <- logD(x, priced) - logD(xs, priced)    # Hastings, priced density
      lpx  <- logD(x, 1) + logLik(x)
      lpxs <- logD(xs, 1) + logLik(xs)
      if (.AcceptProposal(lpx, lpxs, 1, logHastings = lh)) x <- xs
      keep[i] <- x
    }
    keep[-seq_len(n %/% 6)]
  }

  set.seed(20260815)
  correct <- run(priced = 3)                       # g differenced: exact
  expect_equal(mean(correct), 1.5, tolerance = 0.05)
  expect_equal(sd(correct), 0.7071, tolerance = 0.03)

  mispriced <- run(priced = 1)                     # prior differenced: the bug
  expect_equal(mean(mispriced), 2.7, tolerance = 0.05)
  expect_equal(sd(mispriced), 0.9487, tolerance = 0.03)

  # Not a noise-level difference: the mispriced chain sits nearly a full unit
  # away from the posterior mean it is supposed to target.
  expect_gt(mean(mispriced) - mean(correct), 0.5)
})


# ── The same claim against the live C++ engine ──────────────────────────────
# Discriminator, from the algebra above: differencing the prior makes the
# accept ratio the bare likelihood ratio, so a run with priors = P and
# priorsProposals = Q is indistinguishable from one with priors = Q throughout.
# Pre-fix the two sample paths are bit-identical over 200 iterations; the
# correction must break that.

.customPrior1076 <- local({
  R <- function(n, m, s) stats::rnorm(n, m, s)
  D <- function(x, m, s, log = FALSE) stats::dnorm(x, m, s, log = log)
  Q <- function(p, m, s) stats::qnorm(p, m, s)
  # Argument names deliberately unlike any built-in constructor's, so
  # .InferPriorType() routes this to the PT_CUSTOM R-callback path.
  function(sd) Prior(R, D, Q, m = 0, s = sd)
})

.priorPathFixture1076 <- function(priorSd, proposalSd, nIter = 200L) {
  priors <- stratPrior1
  priors[["gammaLog_site_2"]] <- .customPrior1076(priorSd)
  proposals <- priors
  proposals[["gammaLog_site_2"]] <- .customPrior1076(proposalSd)
  model <- StratModel(stratData1, priors, priorsProposals = proposals,
                      alignmentScale = "height", sedModel = "site",
                      alphaPosition = "bottom", nKnots = 15)
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)

  mcmc <- StratMCMC(model, nIter = nIter, nChains = 1)
  # Prior move only, unweighted: the kernel under test is the only one that runs.
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, "Prior"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
  pw[, ] <- 1
  mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw

  list(model = model, mcmc = mcmc, nIter = nIter)
}

# One shared initial state across configurations: the alternative, generating
# it per configuration, draws through the differing priors and starts the two
# chains in different places, which would make any comparison vacuous.
.priorPath1076 <- function(fx, state, seed = 4242L) {
  set.seed(seed)
  e <- .sb_create_engine(stratData1, fx[["model"]], fx[["mcmc"]], state)
  par <- matrix(NA_real_, fx[["nIter"]], length(state[[1]][[c("metro", "parameters")]]))
  accept <- logical(fx[["nIter"]])
  for (i in seq_len(fx[["nIter"]])) {
    .sb_run_block(e, 1L)
    st <- .sb_extract_state(e)[[1]]
    par[i, ] <- st[[c("metro", "parameters")]]
    accept[i] <- isTRUE(st[[c("metro", "accept")]])
  }
  list(par = par, accept = accept)
}

.sharedState1076 <- function(fx, seed = 20260815L) {
  set.seed(seed)
  list(.GenerateInitialState(stratData1, fx[["model"]], fx[["mcmc"]], 1))
}

test_that("a custom priorsProposals is not silently swapped in for the prior (#1076)", {
  mismatched <- .priorPathFixture1076(priorSd = 0.3, proposalSd = 1.2)
  asProposal <- .priorPathFixture1076(priorSd = 1.2, proposalSd = 1.2)
  state <- .sharedState1076(mismatched)

  pathMismatched <- .priorPath1076(mismatched, state)
  pathAsProposal <- .priorPath1076(asProposal, state)

  # Non-vacuous: the Prior move actually moves, so the paths had an opportunity
  # to separate.
  expect_gt(sum(pathMismatched[["accept"]]), 0L)

  # The bug's signature. Differencing the prior cancels it out of the accept
  # ratio, leaving the likelihood ratio -- identical for both configurations,
  # hence identical sample paths.
  expect_false(identical(pathMismatched[["accept"]],
                         pathAsProposal[["accept"]]))
  expect_false(identical(pathMismatched[["par"]], pathAsProposal[["par"]]))
})

# ── The sign of the correction, not merely its presence ─────────────────────
# The test above asserts a DIFFERENCE, which a sign-flipped offset produces
# just as readily: it makes the kernel invariant for prior^2 * L / g, further
# from the truth than the bug being fixed and equally silent. Cross-engine bit
# parity cannot close that -- the custom draw consumes R's RNG through
# do_call_r while built-in priors consume ThreadRNG, so the streams cannot be
# aligned. What can be asserted instead is the theorem itself: with the
# correction right, the stationary distribution is prior * L whatever
# `priorsProposals` is, so a strongly informative prior must pull the chain to
# the same place from either configuration.
#
# The discriminating fixture is a prior far tighter than the proposal
# (sd 0.02 vs 3). The initial gamma sits at 4.13, ~200 prior sds out, so:
#   correct  logHastings = log g(x) - log g(x*), which is ~flat over the range
#            g proposes; the accept ratio is dominated by the prior, and the
#            chain collapses to |gamma| ~ 0 like the matched configuration.
#   flipped  logHastings = 2[log P(x) - log P(x*)] - [log g(x) - log g(x*)],
#            so the same prior term enters with the WRONG sign and rewards
#            distance from 0 by ~1250 * (x*^2 - x^2). The chain is repelled
#            from the prior mean and ratchets outwards from 4.13 instead.

test_that("the Prior move's correction has the sign that targets prior * L (#1076)", {
  gammaIdx <- 3L  # gammaLog_site_2, the custom-prior parameter
  # StratModel() draws splineBase$D through the ambient stream, so the fixture
  # is only reproducible with the models built from a pinned seed.
  set.seed(7L)
  mismatched <- .priorPathFixture1076(priorSd = 0.02, proposalSd = 3)
  matched <- .priorPathFixture1076(priorSd = 0.02, proposalSd = 0.02)
  state <- .sharedState1076(mismatched)

  # Non-vacuous: the shared start is ~190 prior sds out, so a chain that ends
  # up concentrated near 0 got there by accepting, not by sitting still.
  start <- abs(state[[1]][[c("metro", "parameters")]][gammaIdx])
  expect_gt(start, 1)

  # A flipped correction accepts x* over x only when 1250*(x*^2 - x^2) clears
  # the O(10) likelihood and g terms, i.e. essentially only when |gamma| grows,
  # so both medians would be pinned at or above `start`. Observed 0.28 and
  # 0.0029 against a start of 3.7.
  gamma <- function(fx) abs(.priorPath1076(fx, state)[["par"]][, gammaIdx])
  expect_lt(median(gamma(mismatched)), 1)
  expect_lt(median(gamma(matched)), 1)
})

test_that("a numerically equal priorsProposals leaves the C++ Prior move alone (#1076)", {
  # Same numbers, distinct closures: the correction is exactly zero, so the
  # correction machinery must not perturb the default path by so much as an ulp.
  fx <- .priorPathFixture1076(priorSd = 0.3, proposalSd = 0.3)
  state <- .sharedState1076(fx)

  priorsOnly <- fx
  priorsOnly[["model"]][["priorsProposals"]] <-
    priorsOnly[["model"]][[c("priors", "metro")]]

  expect_identical(.priorPath1076(fx, state), .priorPath1076(priorsOnly, state))
})

# ── The correction's own callback must fail loudly (#1087) ──────────────────
# `custom_proposal_offset()` evaluates two user R functions from deep inside
# `sb_run_block_impl`. The prior's `D` was already wrapped for #1134, but the
# proposal's `D` was the one callback `.SafeModelCallbacks()` never reached, so
# an error in it longjmped straight out of a C++ frame -- abort-class on
# aarch64-Linux. Both are now read through `callback_ok()`; only the proposal
# side is separately observable, because a prior `D` that throws is caught by
# the log-posterior's own call to it before the offset is ever reached.

test_that("a throwing proposal density errors from the wrapper (#1087)", {
  fx <- .priorPathFixture1076(priorSd = 0.3, proposalSd = 1.2)
  state <- .sharedState1076(fx)
  model <- fx[["model"]]
  custom <- which(!nzchar(model[[".logpost_cpp"]][["priorTypes"]]))
  expect_length(custom, 1L)
  model[["priorsProposals"]][[custom]][["D"]] <-
    function(x, m, s, log = FALSE) stop("the proposal density gave up")

  set.seed(4242L)
  engine <- .sb_create_engine(stratData1, .SafeModelCallbacks(model),
                              fx[["mcmc"]], state)
  expect_error(
    .sb_run_block(engine, 1L),
    "A custom proposal density raised an error: the proposal density gave up",
    fixed = TRUE
  )
})
