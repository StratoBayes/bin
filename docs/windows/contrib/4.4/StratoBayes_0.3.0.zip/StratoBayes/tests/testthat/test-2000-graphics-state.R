# Regression guards for #2000: state left behind by one test file made
# another file's vdiffr snapshots fail.

test_that("plot functions leave `par()` as they found it (#2000)", {
  skip_on_cran()

  # usr/xaxp/yaxp describe the coordinate system any high-level plot
  # establishes; every other entry is a setting the caller owns.
  drawn <- c("usr", "xaxp", "yaxp")

  Dirtied <- function(call, env, predraw) {
    png(tempfile(), width = 800, height = 600)
    on.exit(dev.off(), add = TRUE)
    if (predraw) plot(1:10)
    before <- par(no.readonly = TRUE)
    eval(call, env)
    after <- par(no.readonly = TRUE)
    keep <- setdiff(names(before), drawn)
    keep[!vapply(keep, function(n) isTRUE(all.equal(before[[n]], after[[n]])),
                 logical(1))]
  }

  # Both on a device the caller has already drawn on and on a virgin one: the
  # virgin case is what catches a restore that puts par("mfg") back, since
  # par(mfg = ) sets new = TRUE.  The call is re-evaluated rather than forced
  # once, or the second device would be measured without it.
  DirtiedPar <- function(expr) {
    call <- substitute(expr)
    env <- parent.frame()
    unique(c(Dirtied(call, env, predraw = TRUE),
             Dirtied(call, env, predraw = FALSE)))
  }

  expect_equal(DirtiedPar(plot(stratPrior1, parameters = "alpha_site_2")),
               character(0))
  expect_equal(DirtiedPar(plot(stratPrior3, log = FALSE, parameters = "all",
                               display = FALSE)),
               character(0))
  expect_equal(DirtiedPar(plot(stratData1)), character(0))
  expect_equal(DirtiedPar(plot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(TracePlot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(hist(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(BeanPlot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(boxplot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(ScatterPlot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(StratMapPlot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(TopsPlot(stratPosterior1)), character(0))
  expect_equal(DirtiedPar(.GenerateTestData("multi", "gap", plot = TRUE)),
               character(0))
})

test_that("no bare `on.exit()` discards a handler in its frame (#2000)", {
  # `on.exit(expr)` replaces every handler already registered in the frame, so
  # a bare call after local_mocked_bindings() silently leaks the mock into the
  # rest of the session.  That is what made test-TracePlot.R's snapshots fail
  # when it ran after test-plot.StratPrior.R.
  CallName <- function(e) {
    head <- e[[1]]
    if (is.name(head)) {
      as.character(head)
    } else if (is.call(head) && as.character(head[[1]]) %in% c("::", ":::")) {
      as.character(head[[3]])
    } else {
      ""
    }
  }
  # test_that() and local() evaluate their block in a frame of its own, as does
  # every function body; handlers only clobber each other within one frame.
  FrameBody <- function(e) {
    switch(CallName(e),
           "function" = list(e[[3]]),
           "test_that" = if (length(e) >= 3) list(e[[3]]) else list(),
           "local" = if (length(e) >= 2) list(e[[2]]) else list(),
           list())
  }
  Args <- function(e) {
    Filter(Negate(is.null),
           lapply(seq_along(e)[-1], function(i) {
             arg <- e[[i]]
             if (missing(arg)) NULL else arg
           }))
  }
  # Calls made directly in this frame, in source order, stopping at any nested
  # frame (whose handlers are registered elsewhere).
  FrameCalls <- function(e) {
    if (!is.call(e) || length(FrameBody(e))) return(list())
    c(list(e),
      unlist(lapply(Args(e), FrameCalls), recursive = FALSE))
  }
  NestedFrames <- function(e) {
    if (!is.call(e)) return(list())
    bodies <- FrameBody(e)
    c(bodies,
      unlist(lapply(c(bodies, Args(e)), NestedFrames), recursive = FALSE))
  }

  Offences <- function(file) {
    exprs <- parse(file, keep.source = TRUE)
    refs <- utils::getSrcref(exprs)
    bad <- character(0)
    for (i in seq_along(exprs)) {
      line <- if (is.null(refs)) "?" else refs[[i]][[1]]
      frames <- c(list(exprs[[i]]), NestedFrames(exprs[[i]]))
      for (frame in frames) {
        registered <- FALSE
        for (call in FrameCalls(frame)) {
          if (identical(CallName(call), "on.exit")) {
            if (registered && !isTRUE(as.list(call)[["add"]])) {
              bad <- c(bad, paste0(basename(file), ":", line))
            }
            registered <- TRUE
          } else if (CallName(call) == "defer" ||
                       startsWith(CallName(call), "local_")) {
            registered <- TRUE
          }
        }
      }
    }
    unique(bad)
  }

  sources <- list.files(test_path("."), pattern = "^(test|helper)-.*[.]R$",
                        full.names = TRUE)
  rDir <- test_path("..", "..", "R")  # absent once the package is installed
  if (dir.exists(rDir)) {
    sources <- c(sources,
                 list.files(rDir, pattern = "[.]R$", full.names = TRUE))
  }
  expect_equal(unique(unlist(lapply(sources, Offences))), character(0))
})
