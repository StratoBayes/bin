# T-137: Tests for NUTS/HMC divergence diagnostics surfacing
#
# Verifies that:
#   1. mcmcSummary contains divergence fields when NUTS is used
#   2. summary.StratPosterior includes divergences in general section
#   3. print.summary.StratPosterior displays divergence info
#   4. MH-only runs do NOT include divergence fields

# Helper: run a NUTS model and return StratPosterior
run_nuts_for_diagnostics <- function(engine = "R") {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  # RunStratModel returns a StratPosterior object
  RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = model,
    nIter = 500, nChains = 2, seed = 4817,
    quiet = TRUE, visualise = FALSE, engine = engine
  )
}


test_that("NUTS R engine surfaces divergence diagnostics in mcmcSummary", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true("nGradientTransitions" %in% names(post[["mcmcSummary"]]))
  expect_true("maxTreeDepth" %in% names(post[["mcmcSummary"]]))

  nRun <- post[["nRun"]]
  expect_length(post[[c("mcmcSummary", "nDivergent")]], nRun)
  expect_length(post[[c("mcmcSummary", "nGradientTransitions")]], nRun)

  # NUTS was used, so there should be gradient transitions
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "nDivergent")]] >= 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})

test_that("summary.StratPosterior includes divergences for NUTS", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  expect_true("divergences" %in% names(s[["general"]]))

  divInfo <- s[[c("general", "divergences")]]
  expect_true("nDivergent" %in% names(divInfo))
  expect_true("nGradientTransitions" %in% names(divInfo))
  expect_true("divergenceRate" %in% names(divInfo))
  expect_true("maxTreeDepth" %in% names(divInfo))
  expect_true("perRun" %in% names(divInfo))

  expect_true(divInfo$divergenceRate >= 0 && divInfo$divergenceRate <= 1)
  expect_s3_class(divInfo$perRun, "data.frame")
  expect_equal(nrow(divInfo$perRun), post[["nRun"]])
})

test_that("#349: divergence locations surface as a named data.frame", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "cpp")
  s <- summary(post)
  divInfo <- s[[c("general", "divergences")]]

  expect_true("locations" %in% names(divInfo))
  loc <- divInfo$locations
  expect_s3_class(loc, "data.frame")

  # Columns: run, rung, treeDepth, deltaH, then the full model parameter names
  # (in model$parametersNames order) — structural, not value-based.
  paramNames <- post[[c("model", "parametersNames")]]
  expect_identical(colnames(loc),
                   c("run", "rung", "treeDepth", "deltaH", paramNames))

  # Storage never exceeds the count; with the default cap the two are equal.
  expect_lte(nrow(loc), sum(post[[c("mcmcSummary", "nDivergent")]]))

  if (nrow(loc) > 0L) {
    # rung is the 1-based chain/rung index at the R boundary (raw C++ matrix is
    # 0-based; summary() flips it so cold chain == 1, matching `chain1`).
    expect_true(all(loc$rung >= 1L))
    expect_true(all(loc$rung <= post[[c("mcmcSummary", "nChains")]][1]))
    # every recorded point is genuinely divergent (non-finite deltaH from a
    # gradient failure, or deltaH beyond the default divergenceMax of 1000).
    expect_true(all(!is.finite(loc$deltaH) | loc$deltaH > 1000))
  }
})

test_that("#349: .AssembleDivergenceLocations flips rung to 1-based", {
  # Deterministic pin on the ONLY place the 0-based C++ chainIdx becomes the
  # 1-based user-facing rung. A raw rung of 0 (cold chain) must map to 1; this
  # catches both a forgotten flip (would stay 0) and a double flip (would be 2).
  asm <- StratoBayes:::.AssembleDivergenceLocations
  paramNames <- c("p1", "p2")
  # columns: rung (0-based), treeDepth, deltaH, p1, p2
  raw <- cbind(c(0, 0, 1), c(1, 2, 3), c(10, 20, 30),
               c(0.1, 0.2, 0.3), c(1.1, 1.2, 1.3))

  df <- asm(raw, run = 2L, paramNames)
  expect_s3_class(df, "data.frame")
  expect_identical(colnames(df),
                   c("run", "rung", "treeDepth", "deltaH", paramNames))
  # raw rung 0/0/1 -> 1/1/2 (1-based); cold chain (raw 0) becomes rung 1.
  expect_equal(df$rung, c(1, 1, 2))
  expect_equal(min(df$rung), 1)                  # forgotten flip would give 0
  expect_true(all(df$run == 2L))
  # non-rung columns pass through untouched
  expect_equal(df$treeDepth, c(1, 2, 3))
  expect_equal(df$deltaH, c(10, 20, 30))
  expect_equal(df$p1, c(0.1, 0.2, 0.3))

  # empty / absent block -> NULL so the caller can drop it
  expect_null(asm(NULL, 1L, paramNames))
  expect_null(asm(matrix(numeric(0), 0L, 3L + length(paramNames)), 1L, paramNames))
})

test_that("#349: .BindDivergenceLocations binds chunks and caps the per-run total", {
  cols <- 3L + 2L                       # rung, treeDepth, deltaH + 2 params
  mk <- function(n) matrix(seq_len(n * cols), nrow = n, ncol = cols)
  bind <- StratoBayes:::.BindDivergenceLocations

  # empty list -> NULL (caller then keeps the seeded 0-row matrix)
  expect_null(bind(list(), cap = 10L))

  # single chunk passes through unchanged (e.g. resume seed, no new divergences)
  expect_identical(bind(list(mk(3L)), cap = 10L), mk(3L))

  # under the cap: all chunks concatenated, every row retained
  under <- bind(list(mk(2L), mk(3L)), cap = 10L)
  expect_equal(nrow(under), 5L)

  # over the cap: truncated to cap, keeping the earliest (chronological) rows so
  # that truncation is visible via nDivergent > nrow, never a silent reshuffle
  over <- bind(list(mk(4L), mk(4L)), cap = 5L)
  expect_equal(nrow(over), 5L)
  expect_equal(over[seq_len(4L), , drop = FALSE], mk(4L))
})

test_that("print.summary.StratPosterior displays divergence info", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "R")
  s <- summary(post)

  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")

  expect_true(
    grepl("gradient-based", outputText, ignore.case = TRUE) ||
      grepl("divergent", outputText, ignore.case = TRUE)
  )
})

test_that("MH-only run does NOT include divergence fields", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  post <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 50, nChains = 2, seed = 7291,
    quiet = TRUE, visualise = FALSE
  )

  expect_null(post[[c("mcmcSummary", "nDivergent")]])
  expect_null(post[[c("mcmcSummary", "nGradientTransitions")]])

  s <- summary(post)
  expect_null(s[[c("general", "divergences")]])
})

# ── T-138: Rank-normalized split-chain R-hat tests ───────────────────────────

test_that(".RhatRankNorm returns ~1.0 for converged chains", {
  set.seed(6142)
  # Two chains from the same distribution should give R-hat near 1
  chain1 <- matrix(rnorm(500), ncol = 2)
  chain2 <- matrix(rnorm(500), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  expect_true(all(rhat < 1.1))
  expect_true(all(rhat >= 1.0))
})

test_that(".RhatRankNorm detects non-convergence", {
  set.seed(3974)
  # Two chains from very different distributions
  chain1 <- matrix(rnorm(500, mean = 0), ncol = 2)
  chain2 <- matrix(rnorm(500, mean = 10), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("par1", "par2")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_true(all(rhat > 1.5))
})

test_that(".RhatRankNorm handles constant parameter", {
  chain1 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  chain2 <- matrix(c(rep(5, 100), rnorm(100)), ncol = 2)
  colnames(chain1) <- colnames(chain2) <- c("const", "varying")

  rhat <- StratoBayes:::.RhatRankNorm(list(chain1, chain2))
  expect_length(rhat, 2)
  # Constant parameter: R-hat = 1.0
  expect_equal(unname(rhat[1]), 1.0)
  # Varying parameter: R-hat near 1.0
  expect_true(rhat[2] < 1.2)
})

test_that(".RhatBasic computes standard R-hat correctly", {
  set.seed(8851)
  # 4 identical chains → R-hat = 1
  chains <- matrix(rnorm(400), ncol = 4)
  rhat <- StratoBayes:::.RhatBasic(chains)
  # R-hat should be close to 1 for IID chains (can be slightly below 1)
  expect_true(rhat > 0.95 && rhat < 1.1)
})

test_that("summary.StratPosterior uses rank-normalized R-hat label", {
  skip_on_cran()

  post <- StratoBayes::stratPosterior1
  s <- summary(post)
  output <- capture.output(print(s))
  outputText <- paste(output, collapse = "\n")
  expect_true(grepl("rank-normalized", outputText))
})

test_that("NUTS C++ engine surfaces divergence diagnostics", {
  skip_on_cran()

  post <- run_nuts_for_diagnostics(engine = "cpp")

  expect_true("nDivergent" %in% names(post[["mcmcSummary"]]))
  expect_true(all(post[[c("mcmcSummary", "nGradientTransitions")]] > 0L))
  expect_true(all(post[[c("mcmcSummary", "maxTreeDepth")]] >= 1L))
})

# ── RT-007: MonitorAccum gradient-diagnostic data race ───────────────────────
#
# recordGradient() runs inside pool.dispatch() on worker threads. Before the
# fix it mutated three shared scalars (nGradientTransitions/nDivergent/
# maxTreeDepth) with unsynchronized ++ / conditional-max — a C++ data race that
# silently *drops* increments under nThreads > 1.
#
# A full RunStratModel run is NOT reproducible in nThreads: the R-side NUTS /
# cost-aware schedule re-weights proposals between blocks off wall-clock timing,
# so gradient counts vary run-to-run even sequentially. We therefore drive the
# engine directly — .sb_run_block for a SINGLE monitor window with a NUTS-only
# proposal set. With one block there is no between-block re-weighting, so a fixed
# per-chain RNG seed makes the sampling — and the true gradient counts — bit-for-
# bit deterministic in nThreads. A sequential (nThreads = 0) block is the race-
# free ground truth; a parallel (nThreads = 2) block of the same seed must
# reproduce all three counters exactly. Under the race the parallel counters fall
# below the baseline (lost increments). nThreads is capped at 2 (CI convention);
# nChains = 4 > nThreads so chains queue across the workers, widening the race
# window. The reliable many-rep reproducer lives in
# dev/red-team/heavy-tests/RT-007-monitoraccum-race.R.

# Build a NUTS-only engine setup: run a short R chain to obtain fully-initialised
# state (incl. NUTS dual-averaging), then force the proposal set to NUTS only
# (0 * anyweight = 0, so no other proposal is ever selected).
.rt007_setup <- function(nChains = 4L) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("rt007_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  RunStratModel(gradientProposals = "on", stratData1, model, nIter = 30, nChains = nChains, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, which(colnames(pp) == "NUTS")] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  list(data = stratData1, model = model, mcmc = mcmc, state = mcmc$recentState)
}

# Run one NUTS-only block at nThreads and return the three diagnostic counters.
# A fresh engine each call starts from the same initial state; set.seed fixes the
# per-chain RNG seeds drawn at the start of .sb_run_block.
.rt007_grad_counts <- function(s, nThreads, nIter, seed) {
  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc, s$state)
  if (nThreads > 1L) StratoBayes:::.sb_set_threads(eng, as.integer(nThreads))
  StratoBayes:::.sb_configure_monitor(eng, s$mcmc[[c("metro", "nProposals")]][[1L]])
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, as.integer(nIter))
  mon <- StratoBayes:::.sb_get_monitor(eng)
  c(nGradientTransitions = mon$nGradientTransitions,
    nDivergent           = mon$nDivergent,
    maxTreeDepth          = mon$maxTreeDepth)
}

test_that("RT-007: parallel NUTS gradient diagnostics have no data race", {
  skip_on_cran()

  s <- .rt007_setup(nChains = 4L)
  nIter <- 400L
  baseline <- .rt007_grad_counts(s, nThreads = 0L, nIter = nIter, seed = 99L)

  # Must-hold invariants, independent of the race: the NUTS path ran and the
  # counters are internally consistent.
  expect_gt(baseline[["nGradientTransitions"]], 0L)
  expect_gte(baseline[["nDivergent"]], 0L)
  expect_lte(baseline[["nDivergent"]], baseline[["nGradientTransitions"]])
  expect_gte(baseline[["maxTreeDepth"]], 1L)

  # Race check: same seed + single block => deterministic in nThreads, so the
  # parallel counters must equal the sequential baseline exactly. Repeat to give
  # a reintroduced race more chances to drop an increment.
  for (rep in seq_len(5L)) {
    parCounts <- .rt007_grad_counts(s, nThreads = 2L, nIter = nIter, seed = 99L)
    expect_equal(parCounts[["nGradientTransitions"]],
                 baseline[["nGradientTransitions"]])
    expect_equal(parCounts[["nDivergent"]], baseline[["nDivergent"]])
    expect_equal(parCounts[["maxTreeDepth"]], baseline[["maxTreeDepth"]])
  }
})

# ── #349 item 1: forced-divergence location capture (CI-safe) ─────────────────
#
# The full-pipeline test above runs an easy target at the default divergenceMax,
# so it usually records ZERO divergences and the "genuinely divergent" predicate
# never fires. This engine-driven case forces divergences with a tiny
# divergenceMax (RT-007 single-block pattern), so the deltaH predicate, rung
# range and column count are actually exercised under CI — not only in the
# manual heavy-test RT-326. Structural assertions only; no absolute values.
test_that("#349: forced divergences record genuinely-divergent locations", {
  skip_on_cran()

  s <- .rt007_setup(nChains = 2L)
  pp <- s$mcmc[[c("metro", "proposalProbability")]]
  nutsPropNum <- which(colnames(pp) == "NUTS")
  mcmc <- s$mcmc
  for (ch in seq_len(2L))
    mcmc[[c("metro", "proposalArgs")]][[ch]][[nutsPropNum]][["divergenceMax"]] <-
      1e-6
  nParam <- s$model[["parametersLength"]]

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, s$state)
  StratoBayes:::.sb_set_threads(eng, 2L)
  StratoBayes:::.sb_configure_monitor(
    eng, mcmc[[c("metro", "nProposals")]][[1L]], 100000L)  # cap >> forced count
  set.seed(321L)
  StratoBayes:::.sb_run_block(eng, 150L)
  mon <- StratoBayes:::.sb_get_monitor(eng)

  loc <- mon$divergenceLocations
  expect_false(is.null(loc))
  expect_gt(mon$nDivergent, 0L)                    # divergences actually forced
  expect_equal(nrow(loc), mon$nDivergent)          # 1:1 identity (cap not binding)
  expect_equal(mon$nDivergenceStored, nrow(loc))
  expect_equal(ncol(loc), 3L + nParam)             # rung, treeDepth, deltaH + params

  # every recorded point is genuinely divergent (non-finite, or beyond the tiny
  # divergenceMax) — the core contract the CI pipeline test could not exercise
  deltaH <- loc[, 3]
  expect_true(all(!is.finite(deltaH) | deltaH > 1e-6))
  # rung is the 0-based chain/rung index; must be in range
  expect_true(all(loc[, 1] >= 0 & loc[, 1] < 2L))
})

# #349 item 1: fixed-step HMC divergences (gradient failures) must ALSO record a
# location, so the nDivergent/location 1:1 identity holds for the HMC path — not
# only NUTS. Without this, an HMC run would count divergences but return an empty
# `locations` table while the docstring claims a cap was hit. Drive HMC by
# renaming the NUTS proposal to "HMC" (the engine dispatches on the name) and
# giving it a huge fixed step so the leapfrog fails the gradient evaluation.
test_that("#349: fixed-step HMC divergences record locations too", {
  skip_on_cran()

  s <- .rt007_setup(nChains = 2L)
  mcmc <- s$mcmc
  nutsIdx <- which(names(mcmc[["propose"]]) == "NUTS")
  names(mcmc[["propose"]])[nutsIdx] <- "HMC"
  pp <- mcmc[[c("metro", "proposalProbability")]]
  colnames(pp)[which(colnames(pp) == "NUTS")] <- "HMC"
  pp[, ] <- 0
  pp[, "HMC"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  for (ch in seq_len(2L)) {
    a <- mcmc[[c("metro", "proposalArgs")]][[ch]][[nutsIdx]]
    a[["adaptStepSize"]] <- FALSE
    a[[".needsEpsInit"]] <- FALSE
    a[["stepSize"]] <- 1e6      # huge step -> leapfrog leaves the valid region
    a[["nSteps"]] <- 20L
    mcmc[[c("metro", "proposalArgs")]][[ch]][[nutsIdx]] <- a
  }
  divMax <- mcmc[[c("metro", "proposalArgs")]][[1L]][[nutsIdx]][["divergenceMax"]]
  expect_true(is.numeric(divMax) && length(divMax) == 1L && is.finite(divMax))
  nParam <- s$model[["parametersLength"]]

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, s$state)
  StratoBayes:::.sb_set_threads(eng, 2L)
  StratoBayes:::.sb_configure_monitor(
    eng, mcmc[[c("metro", "nProposals")]][[1L]], 100000L)
  set.seed(7L)
  StratoBayes:::.sb_run_block(eng, 60L)
  mon <- StratoBayes:::.sb_get_monitor(eng)

  loc <- mon$divergenceLocations
  expect_false(is.null(loc))
  expect_gt(mon$nDivergent, 0L)                 # HMC gradient failures forced
  expect_equal(nrow(loc), mon$nDivergent)       # 1:1 identity holds for HMC
  expect_equal(mon$nDivergenceStored, nrow(loc))
  expect_equal(ncol(loc), 3L + nParam)
  # Same predicate as the NUTS case above: a step this large mostly blows the
  # gradient up to non-finite, but a leapfrog that lands somewhere merely absurd
  # returns a finite deltaH of order 1e32 -- still divergent, still recorded.
  deltaH <- loc[, 3]
  expect_true(all(!is.finite(deltaH) | deltaH > divMax))
  expect_true(any(!is.finite(deltaH)))
  # A domain (gradient) failure always yields a non-finite deltaH, but a
  # non-finite deltaH can also arise from a finite-but-overflowing energy
  # calculation that never hit the domain-failure path -- so this is a lower
  # bound, not an identity (src/MCMCEngine.cpp's hamiltonianDivergent check
  # runs a plain !isfinite(deltaH) test even when !leap.divergent).
  expect_gte(sum(!is.finite(deltaH)), mon$nDomainFailure)
  expect_true(all(loc[, 1] >= 0 & loc[, 1] < 2L))
})

# ── #581: HMC energy divergence must carry the bounded-transform Jacobian ─────
#
# Leapfrog conserves H = -logPost/T - sum(logjac) + K to O(eps^3), so a tiny
# step leaves deltaH vanishing. An energy that omits the Jacobian instead
# tracks the O(eps) drift of sum(logjac) -- ~10^4 larger at the step size used
# here -- and flags perfectly ordinary transitions. The .rt007_setup priors
# bound alpha, so the free dims are logit-transformed and the term is non-zero;
# the test is vacuous on an all-identity model, hence the anyTransformed guard.

# Drive the fixed-step HMC path: rename the NUTS proposal (the engine dispatches
# on the name), pin the step size, run one monitor window.
.Rt581RunHmc <- function(s, stepSize, divergenceMax, nIter = 300L,
                         seed = 11L) {
  mcmc <- s$mcmc
  idx <- which(names(mcmc[["propose"]]) == "NUTS")
  names(mcmc[["propose"]])[idx] <- "HMC"
  pp <- mcmc[[c("metro", "proposalProbability")]]
  colnames(pp)[colnames(pp) == "NUTS"] <- "HMC"
  pp[, ] <- 0
  pp[, "HMC"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  a <- mcmc[[c("metro", "proposalArgs")]][[1L]][[idx]]
  a[["adaptStepSize"]] <- FALSE
  a[[".needsEpsInit"]] <- FALSE
  a[["stepSize"]] <- stepSize
  a[["nSteps"]] <- 1L
  a[["divergenceMax"]] <- divergenceMax
  mcmc[[c("metro", "proposalArgs")]][[1L]][[idx]] <- a

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, s$state)
  StratoBayes:::.sb_configure_monitor(eng,
                                      mcmc[[c("metro", "nProposals")]][[1L]],
                                      100000L)
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, nIter)
  c(StratoBayes:::.sb_get_monitor(eng),
    list(anyTransformed = StratoBayes:::.sb_get_transform(eng)$anyTransformed))
}

test_that("#581: HMC energy divergence carries the transform Jacobian", {
  skip_on_cran()

  s <- .rt007_setup(nChains = 1L)
  nIter <- 300L
  eps <- 1e-6

  strict <- .Rt581RunHmc(s, stepSize = eps, divergenceMax = 1e-8,
                         nIter = nIter)
  expect_true(strict$anyTransformed)
  expect_equal(strict$nGradientTransitions, nIter)
  # Measured margins on this fixture: max|deltaH| = 1.6e-10 with the Jacobian,
  # median 3.3e-7 without it, so 0 vs ~160 of the 300 transitions.
  expect_equal(strict$nDivergent, 0L)

  # Magnitude rather than count, so the negative half of the omitted term (which
  # no threshold can catch) is covered too: -Inf records every transition.
  every <- .Rt581RunHmc(s, stepSize = eps, divergenceMax = -Inf,
                        nIter = nIter)
  deltaH <- every$divergenceLocations[, 3]
  expect_length(deltaH, nIter)
  expect_true(all(is.finite(deltaH)))
  expect_lt(max(abs(deltaH)), 1e-8)
})
