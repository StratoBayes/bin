# PR-lane regression for the compact-band age-gradient window.
#
# The analytic age gradient reads the design derivative through a band window
# `[c0, c0 + splineOrder)` (Gradient_impl.h). An off-by-one in that window is
# numerically silent everywhere except the gradient itself, and every
# finite-difference gradient test in test-cpp-gradient.R /
# test-flexible-knots-gradient.R is skip_on_cran() -- so a band-window shift
# reaches a PR completely unchecked. This file is deliberately NOT skipped: one
# small fixture, one central difference, and knots pinned to the data range so
# the first and last observations fall in the CLAMPED end spans (span <= degree,
# where c0 is truncated at 0) that the ordinary fixtures never reach.

make_band_engine <- function(sData, sModel, knotRange, seed = 7261) {
  sModel <- StratoBayes::StratModel(
    stratData = sData,
    priors = sModel$priors$metro,
    alignmentScale = sModel$alignmentScale,
    sedModel = sModel$sedModel,
    flexibleKnots = FALSE,
    knotRange = knotRange
  )

  td <- file.path(tempdir(), paste0("band_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "band", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "band_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  list(data_obj = data_obj, model_obj = model_obj, mcmc_obj = mcmc_obj,
       state_obj = state_obj, params = state_obj[[1]]$metro$parameters,
       free_idx = model_obj$ind$paramNotFixed, td = td)
}

band_logpost_at <- function(setup, params) {
  # A fresh engine per evaluation: .sb_eval_logpost mutates a scratch copy of
  # the chain state, and the FD oracle must not inherit the previous point's.
  ep <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj
  )
  StratoBayes:::.sb_eval_logpost(ep, 1L, params)
}

band_fd_at <- function(setup, pIdx, h) {
  pPlus <- pMinus <- setup$params
  pPlus[pIdx] <- pPlus[pIdx] + h
  pMinus[pIdx] <- pMinus[pIdx] - h
  (band_logpost_at(setup, pPlus) - band_logpost_at(setup, pMinus)) / (2 * h)
}

# Shrinks the step past a straddled overlap-penalty jump (#989); a wrong window
# disagrees at every step, so only the straddle survives the ladder.
band_rel_err <- function(setup, pIdx, analytic, h0 = 1e-5) {
  rel <- Inf
  for (k in 0:3) {
    fd <- band_fd_at(setup, pIdx, h0 / 4 ^ k)
    rel <- abs(analytic - fd) / max(abs(analytic), abs(fd), 1e-8)
    if (rel < 1e-3) break
  }
  rel
}

test_that("the banded age gradient matches FD with knots clamped to the data", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  probe <- make_band_engine(stratData1, stratModel1, knotRange = c(-5, 12))
  on.exit(unlink(probe$td, recursive = TRUE), add = TRUE)

  # Pin the knot range to the sampled ages, leaving a margin far smaller than a
  # knot spacing but far larger than the FD step, so the extreme observations
  # sit inside the end spans rather than outside the basis.
  ages <- probe$state_obj[[1]][["age"]][["signalFlat"]]
  pad <- diff(range(ages)) * 1e-4
  setup <- make_band_engine(stratData1, stratModel1,
                            knotRange = c(min(ages) - pad, max(ages) + pad))
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  engine <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj
  )
  grad <- StratoBayes:::.sb_compute_gradient(engine, 1L)$grad
  expect_true(all(is.finite(grad)))

  pnames <- names(setup$params)[setup$free_idx]
  for (i in seq_along(setup$free_idx)) {
    rel <- band_rel_err(setup, setup$free_idx[i], grad[i])
    expect_lt(rel, 1e-3, label = sprintf("rel. error for '%s'", pnames[i]))
  }
})
