# Issue #129 stage 5d: a full retained-sample store thins rather than stops.
#
# Thinning is storage-only, so the property under test is an oracle: a run
# forced to thin k times must retain exactly the rows -- values and iteration
# labels -- that a run using the final stride from the start retains.

# ── The decision ────────────────────────────────────────────────────────────

test_that("thinning is taken only while it is free", {
  # tau = 400 raw iterations, stride 1: doubling to 2 is far below tau / 2, so
  # the draws shed and the autocorrelation shed cancel and ESS is unchanged.
  free <- .ThinSchedule(nThin = 1L, maxSaved = 8192L, tauRaw = 400)
  expect_identical(free[["action"]], "thin")
  expect_identical(free[["nThin"]], 2L)
  expect_identical(free[["maxSaved"]], 8192L)

  # The last stride that is still free: 2k <= tau / 2 with tau = 400.
  expect_identical(.ThinSchedule(100L, 8192L, 400)[["action"]], "thin")
  expect_identical(.ThinSchedule(101L, 8192L, 400)[["action"]], "grow")
})

test_that("a store that can no longer thin grows instead", {
  # Past tau / 2 each decimation would halve ESS, so memory becomes the binding
  # constraint and is spent rather than saved.
  grown <- .ThinSchedule(nThin = 256L, maxSaved = 8192L, tauRaw = 400)

  expect_identical(grown[["action"]], "grow")
  expect_identical(grown[["nThin"]], 256L)
  expect_identical(grown[["maxSaved"]], 16384L)
})

test_that("an unusable tau grows the store first, then thins it", {
  for (tau in list(NA_real_, NaN, Inf, -Inf, 0, -5, numeric(0), c(1, 2))) {
    expect_identical(.ThinSchedule(1L, 8192L, .TauRaw(tau, 1L))[["action"]],
                     "grow")
    expect_identical(
      .ThinSchedule(1L, .kMaxStoreDefault, .TauRaw(tau, 1L))[["action"]],
      "thin")
  }
})

test_that("at the ceiling a store thins even at a cost in ESS", {
  # Stopping to protect ESS would end a run that has not converged; a few
  # points of ESS are the cheaper loss.
  paid <- .ThinSchedule(1024L, .kMaxStoreDefault, tauRaw = 8)
  expect_identical(paid[["action"]], "thin")
  expect_identical(paid[["nThin"]], 2048L)
  expect_identical(paid[["maxSaved"]], .kMaxStoreDefault)

  # Only a store that cannot be thinned holds.
  held <- .ThinSchedule(1024L, .kMaxStoreDefault, tauRaw = 1e6, canThin = FALSE)
  expect_identical(held[["action"]], "hold")
  expect_identical(held[["nThin"]], 1024L)
  expect_identical(
    .ThinSchedule(1L, 8192L, tauRaw = 1e6, canThin = FALSE)[["action"]], "grow")

  # The last growth lands exactly on the ceiling rather than overshooting it.
  expect_identical(
    .ThinSchedule(1L, .kMaxStoreDefault - 1L, tauRaw = 1)[["maxSaved"]],
    .kMaxStoreDefault)

  withr::local_options(StratoBayes.maxStore = 4096L)
  expect_identical(.ThinSchedule(1024L, 4096L, tauRaw = 8)[["action"]], "thin")
})

test_that("tau is converted from retained draws to raw iterations", {
  expect_identical(.TauRaw(12, 1L), 12)
  expect_identical(.TauRaw(12, 8L), 96)

  # Same chain, two stores at different strides: the same verdict.
  expect_identical(.ThinSchedule(1L, 8192L, .TauRaw(400, 1L))[["action"]],
                   "thin")
  expect_identical(.ThinSchedule(200L, 8192L, .TauRaw(2, 200L))[["action"]],
                   "grow")
})

test_that("tau is read off the worst-mixing varying parameter", {
  set.seed(1)
  n <- 400
  slow <- as.numeric(stats::filter(rnorm(n), 0.95, method = "recursive"))
  mat <- cbind(iteration = seq_len(n), chain = 1, fast = rnorm(n),
               slow = slow, fixed = 3)
  tau <- .StoreTauDraws(mat, cols = 3:5, floorIter = 0)

  expect_equal(tau, n / .EssFunc(slow))
  # The constant column is ignored rather than read as ESS 1.
  expect_lt(tau, n)
  # Adaptation rows, other chains and too few rows give no estimate.
  expect_true(is.na(.StoreTauDraws(mat, 3:5, floorIter = n)))
  expect_true(is.na(.StoreTauDraws(mat[1:4, ], 3:5, floorIter = 0)))
  expect_true(is.na(.StoreTauDraws(cbind(mat[, 1:2], fixed = 3), 3,
                                   floorIter = 0)))
})

# ── The grid ────────────────────────────────────────────────────────────────

test_that("a thinned schedule is the schedule of a run at that stride", {
  for (stride in c(2, 4, 16)) {
    fine <- StratMCMC(stratModel1, nIter = 1000, nChains = 2)
    coarse <- StratMCMC(stratModel1, nIter = 1000, nChains = 2, nThin = stride)

    thinned <- .ThinnedSaveIter(fine[["saveIter"]], 437, stride, 1000)
    expect_identical(as.numeric(thinned), as.numeric(coarse[["saveIter"]]))
    expect_true(.OnThinLattice(thinned, stride))
  }
  # A history on two strides cannot be thinned exactly.
  expect_false(.OnThinLattice(c(1, 3, 6, 9, 11, 13), 3))
  expect_false(.OnThinLattice(1, 1))
})

# ── The oracle ──────────────────────────────────────────────────────────────

# Every thinning here is forced: the decision is not under test, and a tau that
# licenses every doubling makes the number of thinnings a function of the store
# size alone.
ForceThinning <- function(env = parent.frame()) {
  testthat::local_mocked_bindings(.StoreTauDraws = function(...) 1e6,
                                  .env = env)
}

ThinRun <- function(nThin, maxStore, dir, nIter = 320) {
  withr::with_options(list(StratoBayes.maxStore = maxStore), {
    RunStratModel(stratData1, stratModel1, nIter = nIter, nThin = nThin,
                  nChains = 2, nRun = 1, seed = 1, quiet = TRUE,
                  nThreads = 1L, modelDir = dir, modelName = "t",
                  visualise = FALSE, convergenceStop = FALSE,
                  endAdapting = 50, adaptTemperaturesMonitor = TRUE)
  })
}

ExpectSameRetained <- function(thinned, direct, dirThinned, dirDirect) {
  saved <- thinned[[c("mcmcSummary", "saveIter")]][[1]]
  expect_identical(as.numeric(saved),
                   as.numeric(direct[[c("mcmcSummary", "saveIter")]][[1]]))
  # Values and iteration labels, as read back from disk.
  expect_identical(thinned[["samples"]], direct[["samples"]])
  expect_identical(as.numeric(dimnames(thinned[["samples"]])[[1]]),
                   as.numeric(saved))
  onDisk <- function(dir) readRDS(file.path(dir, "t_mcmc_run_1.rds"))
  expect_identical(as.numeric(onDisk(dirThinned)[["saveIter"]]),
                   as.numeric(onDisk(dirDirect)[["saveIter"]]))

  # The swap record is cut to the retained iterations, and agrees there with
  # the unthinned run's per-iteration record.
  swapsThinned <- onDisk(dirThinned)[[c("temper", "temperingSwaps")]]
  swapsDirect <- onDisk(dirDirect)[[c("temper", "temperingSwaps")]]
  expect_identical(as.numeric(rownames(swapsThinned)), as.numeric(saved))
  expect_gt(sum(!is.na(swapsThinned)), 0L)
  expect_identical(unname(swapsThinned), swapsDirect[saved, , drop = FALSE])
}

test_that("a thinned run retains exactly what a run at its final stride does", {
  skip_on_cran()
  ForceThinning()
  dirA <- withr::local_tempdir()
  dirB <- withr::local_tempdir()

  # Store 64, checkpoints every 32: thinned at 96, 128, ...
  thinned <- ThinRun(1, 64L, dirA)
  stride <- unname(thinned[[c("mcmcSummary", "nThin")]])
  expect_gte(stride, 8)                          # at least three thinnings
  direct <- ThinRun(stride, 65536L, dirB)
  expect_identical(unname(direct[[c("mcmcSummary", "nThin")]]), stride)

  ExpectSameRetained(thinned, direct, dirA, dirB)
  # The in-memory store, as written: the whole matrix, labels included.
  expect_identical(readRDS(file.path(dirA, "t_binarysamples_run_1.rds")),
                   readRDS(file.path(dirB, "t_binarysamples_run_1.rds")))
  expect_identical(readRDS(file.path(dirA, "t_mcmc_run_1.rds"))[["thinBase"]],
                   1)
  expect_length(list.files(dirA, pattern = "\\.(thin\\d+|tmp)$"), 0L)
})

test_that("a continued run thins its streamed file to the same rows", {
  skip_on_cran()
  ForceThinning()
  dirA <- withr::local_tempdir()
  dirB <- withr::local_tempdir()

  # Segment lengths off every stride reached, so the continuation must resume
  # after the thinned checkpoint's `completedIter` (#1986), not its last save.
  Continue <- function(post) {
    RunStratModel(post, nIter = 300, visualise = FALSE, quiet = TRUE,
                  convergenceStop = FALSE, nThreads = 1L)
  }
  firstA <- ThinRun(1, 64L, dirA, nIter = 300)
  withr::with_options(list(StratoBayes.maxStore = 64L),
                      thinned <- Continue(firstA))
  firstStride <- unname(firstA[[c("mcmcSummary", "nThin")]])
  stride <- unname(thinned[[c("mcmcSummary", "nThin")]])
  expect_gt(stride, firstStride)                 # thinned again, from the file
  expect_gt(300 %% firstStride, 0)
  checkpoint <- readRDS(file.path(dirA, "t_mcmc_run_1.rds"))
  expect_identical(checkpoint[["startIter"]], 301)
  expect_identical(checkpoint[["completedIter"]], 600)
  expect_identical(
    .ContinuationCompletedIter(max(firstA[[c("mcmcSummary", "saveIter")]][[1]]),
                               300, firstA[[c("mcmcSummary", "saveIter")]][[1]]),
    300)

  direct <- Continue(ThinRun(stride, 65536L, dirB, nIter = 300))
  ExpectSameRetained(thinned, direct, dirA, dirB)
  expect_identical(readLines(file.path(dirA, "t_samples_run_1.txt")),
                   readLines(file.path(dirB, "t_samples_run_1.txt")))
})

test_that("a thinned posterior summarises like any other", {
  skip_on_cran()
  ForceThinning()
  dir <- withr::local_tempdir()
  post <- ThinRun(1, 64L, dir, nIter = 640)
  saved <- post[[c("mcmcSummary", "saveIter")]][[1]]
  expect_gt(unname(post[[c("mcmcSummary", "nThin")]]), 1)

  expect_no_error(summary(post))
  params <- ExtractParameters(post, burnIn = 0.5)
  expect_gt(nrow(params), 0L)
  expect_lte(nrow(params), length(saved))
  expect_no_error(ExtractParameters(post, burnIn = "auto"))
  burnIn <- .AutoBurnIn(post)
  if (identical(burnIn[["status"]], "ok")) {
    expect_true(burnIn[["iteration"]] %in% c(0, saved))
  }
})

test_that("a crash mid-swap leaves a posterior whose rows match its schedule", {
  skip_on_cran()
  ForceThinning()

  for (stage in c("pending", "commit")) {
    dir <- withr::local_tempdir()
    withr::with_options(
      list(StratoBayes.testThinCrash = stage),
      expect_error(ThinRun(1, 64L, dir), "simulated crash")
    )
    expect_length(list.files(dir, pattern = "\\.thin\\d+$"), 1L)

    post <- StratPosterior(dir, "t")
    saved <- as.numeric(post[[c("mcmcSummary", "saveIter")]][[1]])
    onDisk <- readRDS(file.path(dir, "t_binarysamples_run_1.rds"))
    expect_identical(unique(onDisk[, "iteration"]), saved)
    # Rolled back before the commit, forward after it.
    expect_identical(unname(post[[c("mcmcSummary", "nThin")]]),
                     if (stage == "pending") 1 else 2)
    expect_length(list.files(dir, pattern = "\\.(thin\\d+|tmp)$"), 0L)
  }
})

test_that("a crash mid-swap of a streamed file is recovered too", {
  skip_on_cran()
  ForceThinning()
  dir <- withr::local_tempdir()
  first <- ThinRun(1, 64L, dir)
  withr::with_options(
    list(StratoBayes.maxStore = 64L, StratoBayes.testThinCrash = "commit"),
    expect_error(RunStratModel(first, nIter = 320, visualise = FALSE,
                               quiet = TRUE, convergenceStop = FALSE,
                               nThreads = 1L),
                 "simulated crash")
  )
  post <- StratPosterior(dir, "t")
  saved <- as.numeric(post[[c("mcmcSummary", "saveIter")]][[1]])
  rows <- utils::read.delim(file.path(dir, "t_samples_run_1.txt"))
  expect_identical(as.numeric(unique(rows[["iteration"]])), saved)
  expect_gt(unname(post[[c("mcmcSummary", "nThin")]]),
            unname(first[[c("mcmcSummary", "nThin")]]))
})

test_that("pending files are resolved against the committed generation", {
  dir <- withr::local_tempdir()
  saveRDS(list(thinGeneration = 2), file.path(dir, "m_mcmc_run_1.rds"))
  writeLines("old", file.path(dir, "m_samples_run_1.txt"))
  writeLines("new", file.path(dir, "m_samples_run_1.txt.thin2"))
  writeLines("stale", file.path(dir, "m_binarysamples_run_1.rds.thin1"))
  writeLines("partial", file.path(dir, "m_samples_run_1.txt.thin3.tmp"))
  # Another model sharing the directory is left alone.
  writeLines("other", file.path(dir, "other_samples_run_1.txt.thin9"))

  .RecoverThinning(dir, "m")

  expect_identical(readLines(file.path(dir, "m_samples_run_1.txt")), "new")
  expect_setequal(list.files(dir),
                  c("m_mcmc_run_1.rds", "m_samples_run_1.txt",
                    "other_samples_run_1.txt.thin9"))

  # A schedule moved out of the way but not yet into place is finished.
  saveRDS(list(thinGeneration = 3), file.path(dir, "m_mcmc_run_2.rds.tmp"))
  .RecoverThinning(dir, "m")
  expect_identical(readRDS(file.path(dir, "m_mcmc_run_2.rds"))[["thinGeneration"]],
                   3)
})

# ── Where thinning is refused ───────────────────────────────────────────────

test_that("a store that cannot thin stops, and warns that it did not converge", {
  skip_on_cran()
  # The R engine is a frozen reference, so its store never thins, however
  # freely tau would allow it; the warning says which path refused.
  ForceThinning()
  dir <- withr::local_tempdir()
  expect_warning(
    post <- withr::with_options(
      list(StratoBayes.maxStore = 64L),
      RunStratModel(stratData1, stratModel1, nIter = 320, nChains = 2,
                    nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                    modelDir = dir, modelName = "r", visualise = FALSE,
                    convergenceStop = FALSE, endAdapting = 50, engine = "R")),
    "WITHOUT converging.*R engine")
  expect_lt(unname(post[[c("mcmcSummary", "completedIter")]]), 320)
  expect_identical(unname(post[[c("mcmcSummary", "nThin")]]), 1)
})

test_that("runs that thinned differently continue each on its own stride", {
  thinned <- list(list(nThin = 8, thinBase = 1), list(nThin = 4, thinBase = 1))
  kept <- .ResolveContinuationThin(1, thinned, c(320, 320), "nThin")
  expect_false("nThin" %in% kept[["providedArgs"]])
  expect_silent(.ResolveContinuationThin(1, thinned, c(320, 320), character(0)))

  # A different requested stride is still a mismatch.
  expect_warning(.ResolveContinuationThin(2, thinned, c(320, 320), "nThin"),
                 "differs")
})

test_that("the live plot is rebuilt on the thinned grid", {
  skip_on_cran()
  ForceThinning()
  dir <- withr::local_tempdir()
  offGrid <- 0L
  local_mocked_bindings(.PlotDuringMCMC = function(data, model, mcmc, modelDir,
                                                   modelName, ...) {
    plotted <- readRDS(file.path(modelDir,
                                 paste0(modelName, "_plot_samples_run_1.rds")))
    iters <- plotted[!is.na(plotted[, 1L]), 1L]
    # A slot left holding a row the grid dropped both plots twice and breaks
    # the signal plot.
    if (anyDuplicated(iters) || !all(.ThinKeep(iters, 1, mcmc[["nThin"]]))) {
      offGrid <<- offGrid + 1L
    }
  })
  post <- withr::with_options(
    list(StratoBayes.maxStore = 64L),
    RunStratModel(stratData1, stratModel1, nIter = 640, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "v", visualise = 40, convergenceStop = FALSE,
                  endAdapting = 50))
  expect_gt(unname(post[[c("mcmcSummary", "nThin")]]), 2)
  expect_identical(offGrid, 0L)
})

test_that("a store whose tau forbids thinning thins at the ceiling, not stops", {
  skip_on_cran()
  # tau of one draw: no doubling is ever free.
  local_mocked_bindings(.StoreTauDraws = function(...) 1)
  dir <- withr::local_tempdir()
  expect_no_warning(post <- ThinRun(1, 64L, dir))
  expect_identical(unname(post[[c("mcmcSummary", "completedIter")]]), 320)
  expect_gt(unname(post[[c("mcmcSummary", "nThin")]]), 1)
  expect_lte(length(post[[c("mcmcSummary", "saveIter")]][[1]]), 64L)
})

test_that("a store that fills while adapting stops, and says why", {
  skip_on_cran()
  ForceThinning()
  dir <- withr::local_tempdir()
  expect_warning(post <- ThinRun(1, 16L, dir),
                 "WITHOUT converging.*before adaptation ended")
  expect_lte(unname(post[[c("mcmcSummary", "completedIter")]]), 50)
})
