# Fixture whose second signal has exactly one non-NA point per site, so no
# site clears the `nPerSite >= 2L` gate that selects sites for spline fitting.
.SparseSignalData <- function() {
  n <- 12L
  heights <- seq(0, 11, length.out = n)
  df <- data.frame(
    site = rep(c("site1", "site2"), each = n),
    height = c(heights, heights),
    value = rep(c(1, 2, 3, 2, 1, 0, -1, -2, -1, 0, 1, 2), 2),
    v2 = NA_real_
  )
  df[["v2"]][[1L]] <- 1
  df[["v2"]][[n + 1L]] <- 2
  StratData(df, signalColumn = c("value", "v2"))
}

test_that("a signal with too few points errors instead of deriving NA sigma", {
  d <- .SparseSignalData()
  expect_error(
    StratModel(d, priors = NULL, alignmentScale = "height", sedModel = "site",
               nKnots = 5, overlapPenalty = FALSE),
    "v2"
  )
  expect_error(
    StratModel(d, priors = NULL, alignmentScale = "height", sedModel = "site",
               nKnots = 5, overlapPenalty = FALSE),
    "sigmaFixed"
  )
})

test_that("an explicit numeric sigmaFixed still builds on sparse signals", {
  d <- .SparseSignalData()
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 5, overlapPenalty = FALSE,
                  sigmaFixed = c(0.5, 0.5))
  expect_false(anyNA(m[["sigmaFixed"]]))
})

# Fixture whose second signal has both its site-1 points at one height, so
# `BayesianSpline()` is handed a zero-width range for that site and signal.
.DegenerateRangeData <- function() {
  heights <- c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
  df <- data.frame(
    site = rep(c("site1", "site2"), each = length(heights)),
    height = c(heights, heights),
    value = rep(c(1, 2, 3, 2, 1, 0, -1, -2, -1, 0), 2),
    v2 = NA_real_
  )
  df[["height"]][1:2] <- c(3, 3)
  df[["v2"]][c(1, 2, 11, 12)] <- c(1, 2, 1, 2)
  StratData(df, signalColumn = c("value", "v2"))
}

test_that("the spline-failure message does not advise sigmaFixed = FALSE", {
  d <- .DegenerateRangeData()
  Msg <- function(sigmaFixed) {
    tryCatch(
      StratModel(d, priors = NULL, alignmentScale = "height",
                 sedModel = "site", nKnots = 5, overlapPenalty = FALSE,
                 sigmaFixed = sigmaFixed),
      error = conditionMessage
    )
  }
  # premise, not a detector: this holds for any message text. It pins the
  # reason the advice is wrong, so a future change that made `FALSE` skip the
  # spline fit would surface here rather than in the wording assertion below
  expect_identical(Msg(TRUE), Msg(FALSE))
  expect_match(Msg(TRUE), "could not generate a Bayesian spline")
  expect_false(grepl("FALSE", Msg(TRUE), fixed = TRUE))
  expect_match(Msg(TRUE), "numeric vector")
  expect_s3_class(Msg(c(0.1, 0.1)), "StratModel")
})

test_that("a non-logical signalOffsets errors instead of disabling offsets", {
  d <- StratData(signal = signalData0)
  for (bad in list(1, "TRUE", NA, c(TRUE, TRUE))) {
    expect_error(
      StratModel(d, priors = NULL, alignmentScale = "height",
                 sedModel = "site", nKnots = 10, signalOffsets = bad),
      "signalOffsets"
    )
  }
})

test_that("offsetPriorScale is validated even when offsets are off", {
  d <- StratData(signal = signalData0)
  Build <- function(...) {
    StratModel(d, priors = NULL, alignmentScale = "height", sedModel = "site",
               nKnots = 10, signalOffsets = FALSE, ...)
  }
  for (bad in list(-5, 0, c(1, 2), "1")) {
    expect_error(Build(offsetPriorScale = bad), "positive scalar")
  }
  # a non-finite scale reached `offsetPriorScale <= 0` unguarded, so NaN and
  # NA died on "missing value where TRUE/FALSE needed" instead
  for (bad in list(Inf, NaN, NA_real_)) {
    expect_error(Build(offsetPriorScale = bad), "positive scalar")
  }
  expect_silent(Build(offsetPriorScale = 2))
})

test_that("offsetPriorScale is validated when offsets are on", {
  grp <- data.frame(site = c("site1", "site2"), group = c("A", "B"))
  d <- StratData(signal = signalData0, group = grp)
  for (bad in list(-5, Inf, NaN)) {
    expect_error(
      StratModel(d, priors = NULL, alignmentScale = "height",
                 sedModel = "site", nKnots = 10, signalOffsets = TRUE,
                 offsetPriorScale = bad),
      "positive scalar"
    )
  }
})

test_that(".CreateIndices() names alphaPosition when it is NULL", {
  expect_error(.CreateIndices(stratData1, "height", "site", NULL),
               "alphaPosition")
  expect_error(.CreateIndices(stratData1, "height", "site", NULL),
               "NULL")
})

test_that(".MatchSedModel() accepts abbreviations without a literal space", {
  expect_equal(.MatchSedModel("s,p"), "site, partition")
  expect_equal(.MatchSedModel("s, p"), "site, partition")
  expect_equal(.MatchSedModel("sxp"), "site x partition")
  expect_equal(.MatchSedModel("s x p"), "site x partition")
  expect_equal(.MatchSedModel("site,partition"), "site, partition")
  expect_equal(.MatchSedModel("site,part"), "site, partition")
  expect_equal(.MatchSedModel("sitexpartition"), "site x partition")
  expect_error(.MatchSedModel("sites"), "Invalid 'sedModel' input")
  # the padding must stay anchored. Un-anchor it and "sitex" pads to "site x",
  # which pmatch()es as a prefix of "site x partition" -- a *different* model,
  # silently. The leading-x spellings are controls; they error either way
  for (typo in c("sitex", "sitex ", "xsite", " xsite")) {
    expect_error(.MatchSedModel(typo), "Invalid 'sedModel' input", info = typo)
  }
})

test_that(".MatchAlignmentScale() rejects a length > 1 scale", {
  expect_error(.MatchAlignmentScale(c("age", "height")), "length 1")
  expect_error(.MatchAlignmentScale(character(0)), "length 1")
  expect_equal(.MatchAlignmentScale("age"), "age")
  expect_equal(.MatchAlignmentScale(list("age")), "age")
})

test_that("StratModelTemplate() emits one call per multi-line expression", {
  # `deparse()` only splits at a syntactic break point, so length alone is not
  # enough: the expression needs top-level commas to deparse to > 1 element
  arg <- quote(switch("a", aLongBranchName = stratData1,
                      bLongBranchName = stratData1,
                      cLongBranchName = stratData1, a = stratData1))
  expect_gt(length(deparse(arg)), 1L)

  out <- capture.output(
    StratModelTemplate(switch("a", aLongBranchName = stratData1,
                              bLongBranchName = stratData1,
                              cLongBranchName = stratData1, a = stratData1),
                       alignmentScale = "height", sedModel = "s")
  )
  expect_length(grep("StratModel\\(stratData = ", out), 1L)
  expect_length(grep("RunStratModel\\(stratObject = ", out), 1L)
})

test_that(".CreateIndices() returns integer index vectors for every config", {
  for (data in list(stratData1, stratData3)) {
    for (scale in c("height", "age")) {
      for (sed in c("site", "partition", "site x partition",
                    "site, partition")) {
        # `sedSmooth = TRUE` returns before the coercion loop, so it needs
        # its own arm: nothing else pins that branch's storage type
        for (smooth in c(FALSE, TRUE)) {
          ind <- .CreateIndices(data, scale, sed, "middle",
                                sedSmooth = smooth)
          for (slot in c("alpha", "gamma", "rates", "gap", "zeta")) {
            if (!is.null(ind[[slot]])) {
              expect_identical(typeof(ind[[slot]]), "integer",
                               info = paste(scale, sed, smooth, slot))
            }
          }
        }
      }
    }
  }
})
