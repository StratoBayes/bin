# Issue #129 stage 5: `nIter = Inf`.
#
# `saveIter`, `writeMCMCiterations` and the C++ batch schedule are vectors of
# absolute iteration numbers derived from `endIter`, and none can be
# materialised when that is `Inf`. The run therefore plans a finite *horizon*,
# builds the existing schedules over it unchanged, and widens it on arrival.
#
# So the assertions come in two halves: a finite run must be exactly what it
# was (`horizon == endIter`, never extended), and an unbounded one must cross
# horizons without leaving a gap in the grid.

test_that("nIter accepts Inf and rejects what it always rejected", {
  expect_true(is.infinite(StratMCMC(stratModel1)[["nIter"]]))
  expect_true(is.infinite(StratMCMC(stratModel1, nIter = Inf)[["nIter"]]))

  expect_error(StratMCMC(stratModel1, nIter = 0), "positive integer")
  expect_error(StratMCMC(stratModel1, nIter = 2.5), "positive integer")
  expect_error(StratMCMC(stratModel1, nIter = -Inf), "positive integer")
  expect_error(StratMCMC(stratModel1, nIter = NA), "positive integer")
  expect_error(StratMCMC(stratModel1, nIter = c(10, 20)), "positive integer")
})

test_that("a finite run plans exactly to its last iteration", {
  mcmc <- StratMCMC(stratModel1, nIter = 500, nChains = 2)

  expect_identical(mcmc[["horizon"]], mcmc[["endIter"]])
  expect_identical(mcmc[["horizon"]], 500)
  expect_identical(max(mcmc[["saveIter"]]), 500)
  # `.ExtendHorizon()` is a no-op for it, so a finite run can never take the
  # rebuild path however the loop is written.
  expect_identical(.ExtendHorizon(mcmc)[["horizon"]], 500)
})

test_that("an unbounded run plans a finite horizon and widens it", {
  mcmc <- StratMCMC(stratModel1, nChains = 2)

  expect_identical(mcmc[["horizon"]], .kHorizonIter + 0)
  expect_true(is.finite(max(mcmc[["saveIter"]])))
  expect_true(is.finite(max(mcmc[["writeMCMCiterations"]])))

  wider <- .ExtendHorizon(mcmc)
  expect_identical(wider[["horizon"]], 2 * .kHorizonIter)
  # Extended, never rewritten: everything already planned is still planned, at
  # the same iterations, so a rebuild cannot orphan a saved row.
  expect_identical(head(wider[["saveIter"]], length(mcmc[["saveIter"]])),
                   mcmc[["saveIter"]])
  expect_identical(head(wider[["writeMCMCiterations"]],
                        length(mcmc[["writeMCMCiterations"]])),
                   mcmc[["writeMCMCiterations"]])
  # The save grid stays evenly spaced across the join, which is what
  # `.EssFunc()`'s `acf()` reads it as.
  expect_length(unique(diff(wider[["saveIter"]])), 1L)
})

test_that("checkpoints do not drift further apart as a run goes on", {
  # `writeMCMCiterations` is a *fraction* of the planned range, so a naive
  # rebuild would double the gap between checkpoints every time the horizon
  # doubled -- and with it the work a crash costs.
  # (Checkpoint spacing is not exactly uniform to begin with -- a tenth of the
  # range rounds -- so the claim is that it does not *grow*, not that every gap
  # is equal.)
  mcmc <- StratMCMC(stratModel1, nChains = 2)
  spacing <- max(diff(mcmc[["writeMCMCiterations"]]))

  for (i in 1:4) {
    mcmc <- .ExtendHorizon(mcmc)
    expect_lte(max(diff(mcmc[["writeMCMCiterations"]])), spacing)
    expect_gte(max(mcmc[["writeMCMCiterations"]]),
               mcmc[["horizon"]] - spacing)
  }
})

test_that("a single-checkpoint schedule still recurs", {
  # `writeMCMCfile > 0.5` puts one checkpoint at the horizon and no more, so
  # there is no spacing to read off the schedule. An unbounded run assesses
  # convergence and its sample budget only when it checkpoints, so leaving that
  # schedule unextended leaves nothing that can end the run.
  mcmc <- StratMCMC(stratModel1, nChains = 2, writeMCMCfile = 1)
  expect_length(mcmc[["writeMCMCiterations"]], 1L)

  for (i in 1:3) {
    old <- mcmc[["horizon"]]
    mcmc <- .ExtendHorizon(mcmc)
    expect_true(any(mcmc[["writeMCMCiterations"]] > old))
    expect_identical(max(mcmc[["writeMCMCiterations"]]), mcmc[["horizon"]])
  }
})

test_that("the horizon never runs past a finite end", {
  mcmc <- StratMCMC(stratModel1, nIter = 500, nChains = 2)
  mcmc[["horizon"]] <- 200          # as if planned short
  expect_identical(.ExtendHorizon(mcmc)[["horizon"]], 400)
  mcmc[["horizon"]] <- 400
  expect_identical(.ExtendHorizon(mcmc)[["horizon"]], 500)
})

test_that("the batch schedule is planned to the horizon, not to Inf", {
  mcmc <- StratMCMC(stratModel1, nChains = 2)
  schedule <- .CppBatchSchedule(mcmc, canBulkHistory = TRUE)

  expect_identical(schedule[["endIt"]], mcmc[["horizon"]])
  expect_true(all(is.finite(schedule[["cppCheckpoints"]])))
  expect_true(all(is.finite(schedule[["adaptCPs"]])))
  # An unbounded run has no near end; treating the horizon as one would drop it
  # to per-iteration batching every time the horizon moved.
  expect_gt(schedule[["cppNearEndStart"]], mcmc[["horizon"]])
})

test_that("an unreachable ESS target is refused before sampling", {
  expect_error(
    RunStratModel(stratData1, stratModel1, nIter = 20, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L,
                  modelDir = withr::local_tempdir(), modelName = "u",
                  visualise = FALSE, convergenceStop = list(ess = 1e9)),
    "above the effective sample size")
  # The boundary is exactly half the store: a run's retained draws number about
  # twice its ESS at the point where thinning would stop.
  expect_identical(.ReachableEss(), .kMaxStoreDefault / 2)
})

test_that("a run with no stopping rule warns, and a store that cannot thin ends it", {
  skip_on_cran()
  # No artificial iteration cap. A store that can thin does so and the run goes
  # on (test-thin-store.R); one that cannot -- here a history mocked as mixing
  # strides -- is still a real bound, so the run ends rather than hanging.
  local_mocked_bindings(.OnThinLattice = function(...) FALSE)
  withr::local_options(StratoBayes.maxStore = 512L)
  dir <- withr::local_tempdir()

  expect_warning(
    expect_warning(
      post <- RunStratModel(stratData1, stratModel1, nChains = 2, nRun = 1,
                            seed = 1, quiet = TRUE, nThreads = 1L,
                            modelDir = dir, modelName = "n", visualise = FALSE,
                            convergenceStop = FALSE),
      "no stopping rule is set"),
    "WITHOUT converging")

  completed <- unlist(post[[c("mcmcSummary", "completedIter")]])
  expect_true(is.finite(completed))
  # Bounded by the budget plus at most one checkpoint interval's overshoot,
  # since the budget is only consulted at checkpoints.
  expect_lt(dim(post[["samples"]])[[1]], 512 + 0.1 * .kHorizonIter + 2)
})

test_that("an unbounded run crosses horizons on one uniform grid", {
  skip_on_cran()
  # The failure this guards: a rebuild that starts the next segment at the
  # wrong offset leaves a gap, and `.EssFunc()`'s `acf()` reads the result as
  # evenly spaced regardless.
  dir <- withr::local_tempdir()
  post <- RunStratModel(stratData1, stratModel1, nChains = 4, nRun = 1,
                        seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                        modelName = "h", visualise = FALSE,
                        convergenceStop = FALSE, timeLimit = 4 / 3600)

  saved <- post[[c("mcmcSummary", "saveIter")]][[1]]
  completed <- unlist(post[[c("mcmcSummary", "completedIter")]])

  expect_gt(completed, .kHorizonIter)      # at least one horizon crossed
  # ...without a gap. Past the always-saved iteration 1, since a store that
  # filled has thinned to a stride the first gap does not share.
  expect_length(unique(diff(saved[-1L])), 1L)
  expect_identical(max(saved), completed)
  expect_identical(dim(post[["samples"]])[[1]], length(saved))
})

test_that("a finite run is untouched by any of this", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  post <- RunStratModel(stratData1, stratModel1, nIter = 200, nChains = 4,
                        nRun = 2, seed = 1:2, quiet = TRUE, nThreads = 1L,
                        modelDir = dir, modelName = "f", visualise = FALSE)

  expect_identical(unlist(post[[c("mcmcSummary", "completedIter")]]),
                   c(200, 200))
  expect_identical(dim(post[["samples"]])[[1]], 200L)
  for (saved in post[[c("mcmcSummary", "saveIter")]]) {
    expect_identical(unique(diff(saved)), 1)
    expect_identical(max(saved), 200)
  }
})

test_that("a run that never checkpoints is refused when it has no last iteration", {
  # Convergence and the retained-sample budget are both assessed when the run
  # checkpoints, so `writeMCMCfile = FALSE` with an infinite `nIter` leaves
  # nothing that can end the run -- measured at 131,071 retained draws against
  # a budget of 1,024 before this guard.
  expect_error(StratMCMC(stratModel1, writeMCMCfile = FALSE),
               "cannot be `FALSE` or `0` when `nIter` is infinite")
  expect_error(StratMCMC(stratModel1, writeMCMCfile = 0), "cannot be")

  # A finite run still has `nIter` to end it, so nothing changes for it.
  expect_false(StratMCMC(stratModel1, nIter = 100,
                         writeMCMCfile = FALSE)[["writeMCMCiterations"]])
})

test_that("a budget stop prunes its schedule like every other stop", {
  skip_on_cran()
  # The budget is assessed before `.StopCondition()`, not inside the write
  # block it triggers, so the `saveIter` written to disk holds no iteration the
  # run never reached. Every other stop path already had this.
  local_mocked_bindings(.OnThinLattice = function(...) FALSE)
  withr::local_options(StratoBayes.maxStore = 1024L)
  dir <- withr::local_tempdir()
  expect_warning(
    post <- RunStratModel(stratData1, stratModel1, nChains = 2, nRun = 1,
                          seed = 1, quiet = TRUE, nThreads = 1L,
                          modelDir = dir, modelName = "b", visualise = FALSE,
                          convergenceStop = list(rHat = 1.02),
                          timeLimit = 90 / 3600),
    "WITHOUT converging")

  completed <- unlist(post[[c("mcmcSummary", "completedIter")]])
  expect_lt(completed, 1e5)          # the budget, not the time limit, stopped it
  expect_identical(max(post[[c("mcmcSummary", "saveIter")]][[1]]), completed)

  onDisk <- readRDS(file.path(dir, "b_mcmc_run_1.rds"))
  expect_identical(max(onDisk[["saveIter"]]), onDisk[["completedIter"]])
})

test_that("a horizon rebuild after a timer freeze keeps the loop's cap", {
  # A #259 freeze rebases `mcmc$endAdapting`, but the batch loop still branches
  # on the original cap. Rebuilt against the rebased value, the adaptation
  # branch would batch straight over the checkpoints between the two.
  mcmc <- StratMCMC(stratModel1, nChains = 2, endAdapting = 12000)
  cap <- mcmc[["endAdapting"]]
  frozen <- .RebaseAdaptCursors(mcmc, 3000,
                                mcmc[[c("metro", "adaptProposalInterval")]])
  frozen <- .ExtendHorizon(frozen[["mcmc"]])

  between <- frozen[["writeMCMCiterations"]]
  between <- between[between > 3000 & between <= cap]
  expect_gt(length(between), 0L)

  schedule <- .CppBatchSchedule(frozen, canBulkHistory = TRUE, endAdapt = cap)
  expect_true(all(between %in% schedule[["adaptCPs"]]))
})

test_that("a widened horizon saves on multiples of nThin, as StratMCMC() plans", {
  # A stride wider than the first horizon leaves iteration 1 the only save, and
  # counting on from it put every later save one iteration off the grid a
  # continuation (#1986) and an uninterrupted run both use.
  stride <- 2 * .kHorizonIter + 3
  mcmc <- StratMCMC(stratModel1, nChains = 2, nThin = stride)
  expect_identical(as.numeric(mcmc[["saveIter"]]), 1)
  for (k in 1:3) mcmc <- .ExtendHorizon(mcmc)
  expect_true(all(mcmc[["saveIter"]][-1L] %% stride == 0))
  expect_gt(length(mcmc[["saveIter"]]), 1L)
})
