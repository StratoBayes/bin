# #1193: post-endAdapting, `enablePostAdaptDecay = TRUE` re-derives a gain from
# the acceptance ring buffer at every checkpoint. Where nothing refreshes that
# buffer between checkpoints -- engine = "R", or clustWithParametersMCMC = FALSE,
# so the bulk writer is off and `.SaveMCMChistory` only refreshes near
# endAdapting and near the end of the run -- the same acceptMean was reapplied
# every interval, drifting proposalFactor monotonically off stale data.

.decayFixture <- function(accept = 0.05, bufLen = 8L) {
  acceptance <- array(accept, dim = c(1L, bufLen, 1L))
  list(
    nChains = 1L, currentIter = 2000L, endAdapting = 1000L,
    propose = setNames(vector("list", 1L), "Univariate"),
    temper = list(temperatures = 1, tempering = FALSE),
    metro = list(
      nProposals = 1L,
      enablePostAdaptDecay = TRUE,
      acceptance = acceptance,
      acceptanceIndex = matrix(1L, 1L, 1L),
      acceptanceLength = bufLen,
      proposalFactor = matrix(1, 1L, 1L,
                              dimnames = list(NULL, "Univariate")),
      proposalProbability = matrix(1, 1L, 1L,
                                   dimnames = list(NULL, "Univariate")),
      proposalValid = matrix(TRUE, 1L, 1L,
                             dimnames = list(NULL, "Univariate")),
      proposalTimeNs = matrix(0, 1L, 1L),
      proposalTimeCount = matrix(0L, 1L, 1L),
      proposalSqJump = matrix(0, 1L, 1L),
      proposalSqJumpSq = matrix(0, 1L, 1L),
      probUpdateCount = 0L,
      scaleMultivariateProposals = FALSE
    )
  )
}

# One post-adapt checkpoint, with NOTHING refreshing the buffer in between --
# exactly the configuration the issue describes.
.runCheckpoints <- function(mcmc, n) {
  model <- list(parametersLength = 1L, parametersLengthNotFixed = 1L,
                ind = list(paramNotFixed = 1L))
  factors <- numeric(n)
  for (k in seq_len(n)) {
    mcmc[["currentIter"]] <- mcmc[["currentIter"]] + 100L
    mcmc[["metro"]] <- .UpdateProposalProbAndFac(model, mcmc,
                                                 inLateAdaptation = TRUE)
    factors[k] <- mcmc[[c("metro", "proposalFactor")]][1L, 1L]
  }
  factors
}

test_that("a stale acceptance buffer no longer drives repeated decay (#1193)", {
  factors <- .runCheckpoints(.decayFixture(accept = 0.05), 6L)

  # The first checkpoint legitimately consumes the buffer it was given.
  expect_lt(factors[1], 1)
  # PRE-FIX every later checkpoint reapplied the SAME acceptMean, so `factors`
  # was strictly decreasing all the way down (~0.55 by checkpoint 6 here).
  # Consuming the buffer makes the unrefreshed checkpoints read empty and skip
  # the gain entirely, so the factor holds until real data arrives.
  expect_identical(factors[-1], rep(factors[1], 5L))
})

test_that("a refreshed buffer still decays every checkpoint (#1193)", {
  mcmc <- .decayFixture(accept = 0.05)
  model <- list(parametersLength = 1L, parametersLengthNotFixed = 1L,
                ind = list(paramNotFixed = 1L))
  factors <- numeric(4L)
  for (k in seq_len(4L)) {
    mcmc[["currentIter"]] <- mcmc[["currentIter"]] + 100L
    # Stand in for the writer that IS active under the defaults
    # (`.BulkSaveMCMChistory`, every iteration).
    mcmc[[c("metro", "acceptance")]][] <- 0.05
    mcmc[["metro"]] <- .UpdateProposalProbAndFac(model, mcmc,
                                                 inLateAdaptation = TRUE)
    factors[k] <- mcmc[[c("metro", "proposalFactor")]][1L, 1L]
  }
  expect_true(all(diff(factors) < 0))
})

test_that("the default configuration is untouched by the clear (#1193)", {
  mcmc <- .decayFixture(accept = 0.05)
  mcmc[[c("metro", "enablePostAdaptDecay")]] <- FALSE   # the shipped default
  model <- list(parametersLength = 1L, parametersLengthNotFixed = 1L,
                ind = list(paramNotFixed = 1L))

  out <- .UpdateProposalProbAndFac(model, mcmc, inLateAdaptation = TRUE)

  expect_identical(unname(out[["proposalFactor"]][1L, 1L]), 1)
  expect_identical(out[["acceptance"]], mcmc[[c("metro", "acceptance")]])
})
