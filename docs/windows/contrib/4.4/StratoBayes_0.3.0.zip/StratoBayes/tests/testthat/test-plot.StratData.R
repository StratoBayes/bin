set.seed(0)

## test-0

test_that("plot.StratData can plot StratData - test-1 - signal", {
  skip_if_not_snapshot_os()
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, cex = 2)
  vdiffr::expect_doppelganger("plot.StratData-test-1-signal", plot1)
})

test_that("plot.StratData can plot StratData - test-1 - signal - all", {
  skip_if_not_snapshot_os()
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, type = "l", signal = "all")
  vdiffr::expect_doppelganger("plot.StratData-test-1-signall-all", plot1)
})

test_that("plot.StratData can plot StratData - test-1 - partition", {
  skip_if_not_snapshot_os()
  t0 <- StratData(.GenerateTestData(version = "1")$signal)
  plot1 <- function() plot(t0, show = "partition", colourScale = "Viridis")
  vdiffr::expect_doppelganger("plot.StratData-test-1-partition", plot1)
})

## test-1

testData <- .GenerateTestData(version = "1a")

test_that("plot.StratData can plot StratData - test-1a - partition", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties), show = "partition", ylim = c(-25,100))
  vdiffr::expect_doppelganger("plot.StratData-test-1a-partition", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - select sites", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", sites = c(3,1), colourScale = "Cold", pch = 22)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-select-sites", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - single site", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", sites = 1, colourScale = "Cold", pch = 22)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-single-site", plot1)
})

test_that("plot.StratData can plot StratData - test-1a - signal - all", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plot1 <- function() plot(StratData(testData$signal, parts = testData$parts, ties = testData$ties),
                           colourBy = "site", signal = "all", pch = 22, sites = 3:2)
  vdiffr::expect_doppelganger("plot.StratData-test-1a-signal-all", plot1)
})

# test Multi


test_that("plot.StratData can plot StratData - test-multi-1 - signal - all", {
  skip_if_not_snapshot_os()
  # plot() subsamples points at random; seed it here rather than inheriting
  # whatever stream the previous test happened to leave behind.
  set.seed(1)
  testDataMulti <- .GenerateTestData("multi",version = "1")
  plot1 <- function() plot(StratData(testDataMulti$signal, parts = testDataMulti$parts, signalColumn = c("a", "b")), signal = "all", sites = "all", pch = 22:24)
  vdiffr::expect_doppelganger("plot.StratData-test-multi-1-signal-all", plot1)
})



test_that("plot.StratData works with depth data - type o", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - type o", function() {
    plot(stratData3, type = "o", colourBy = "p")
  })
})

test_that("plot.StratData works with depth data - type l", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - type l", function() {
    plot(stratData3, type = "l", colourBy = "p")
  })
})

test_that("plot.StratData works with depth data - all in one plot", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot.StratData depth data - all in one plot", function() {
    plot(stratData3, signal = "all")
  })
})


## test plot return

test_that("signal return works", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plotReturn <- plot(t1, show = "signal", display = FALSE, sites = c(3,1))
  expect_snapshot(plotReturn)
})


test_that("signal return works - two signals", {
  skip_if_not_snapshot_os()
  set.seed(1)
  testDataMulti <- .GenerateTestData("multi", version = "1")
  plotReturn <- plot(StratData(testDataMulti[["signal"]],
                               parts = testDataMulti$parts,
                               signalColumn = c("a", "b")), show = "signal",
                     display = FALSE, signal = "all")
  expect_snapshot(plotReturn)
})

test_that("partition return works", {
  skip_if_not_snapshot_os()
  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  plotReturn <- plot(t1, show = "partition", display = FALSE)
  expect_snapshot(plotReturn)
})

test_that("plot.stratData produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({plot(stratData3)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("plot.StratData does not crash for a valid but unmatched plot type", {
  png(filename = tempfile())
  expect_no_error(plot(stratData3, type = "h"))
  expect_no_error(plot(stratData3, show = "signal", type = "h"))
  dev.off()
})

test_that("plot.StratData does not crash for explicit NULL dots args (RT-297/RT-299)", {
  png(filename = tempfile())
  expect_no_error(plot(stratData1, show = "signal", type = NULL))
  expect_no_error(plot(stratData1, show = "signal", pch = NULL))
  dev.off()
})

test_that("plot.StratData rejects a non-finite xlim/ylim instead of a base R error (RT-470)", {
  expect_error(plot(stratData1, xlim = c(0, NA), display = FALSE),
               "`xlim` must contain only finite values")
  expect_error(plot(stratData1, ylim = c(0, Inf), display = FALSE),
               "`ylim` must contain only finite values")
})

test_that("plot.StratData(show = 'partition') colours a partition literally named 'gap' by name, not by factor code (RT-472)", {
  # A partition labelled 'gap' that isn't last in uniqueParts desyncs the
  # in-place `colourMap["gap"] <- "white"` mutation from the `parts_order`
  # relabelling that moves "gap" to the end -- indexing colourMap with the
  # resulting factor (integer codes in parts_order) then silently draws the
  # wrong colour for almost every partition.
  p <- partsData2
  p[["partition"]][p[["partition"]] %in% "part 2.1"] <- "gap"
  sd <- StratData(signalData2, parts = p, ties = tiesData2,
                  signalColumn = c("a", "b"), zColumn = "height",
                  siteColumn = "site")

  drawnCol <- character(0)
  testthat::local_mocked_bindings(
    rect = function(xleft, ybottom, xright, ytop, ..., col = NA) {
      drawnCol <<- c(drawnCol, if (is.null(col)) NA_character_ else as.character(col))
    },
    .package = "StratoBayes"
  )

  out <- plot(sd, show = "partition", display = FALSE)

  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  plot(sd, show = "partition", overridePar = FALSE)

  # the colour map keyed by name against the actual partition label at each
  # plotted row is ground truth, independent of how the drawing code looks it
  # up internally; NA entries correspond to unused padding rows (Upper = NA)
  # and carry no colour information either way
  expectedCol <- unname(out[["col"]][as.character(out[["data"]][["Parts"]])])
  expect_equal(drawnCol[!is.na(drawnCol)], expectedCol)

  # the real "gap" partition keeps its own assigned colour (RT-506/#727):
  # it must not be swallowed by the unconformity sentinel it collides with
  isRealGapPartition <- as.character(out[["data"]][["Parts"]]) == "gap"
  expect_true(any(isRealGapPartition))
  expect_false(any(expectedCol[isRealGapPartition] == "white"))

  # the genuine unconformity (an NA partition in the source data) is still
  # drawn white, under a disambiguated label distinct from "gap"
  isUnconformity <- expectedCol == "white" & !is.na(expectedCol)
  unconformityLabels <- as.character(out[["data"]][["Parts"]])[isUnconformity]
  expect_true(any(isUnconformity))
  expect_false(any(unconformityLabels == "gap"))

  # RT-472's actual invariant: colourMap's name order must match the factor
  # level order it's indexed against, so name- and code-indexing agree
  expect_equal(names(out[["col"]]), out[["labels"]])
})

test_that("plot.StratData tolerates length>1 'type' (RT-507/#728)", {
  # several `args[["type"]] == ...` comparisons become length-2 for a
  # length-2 `type`, which errors under R >= 4.3's stricter `&&`/`||`
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  expect_no_error(plot(stratData1, type = c("p", "l"), signal = 1))
})

test_that("plot.StratData rejects duplicated 'signal' (RT-504/#725)", {
  expect_error(plot(stratData1, signal = c(1, 1), display = FALSE),
               "'signal' must not contain duplicated values")

  # `signal` is unused for show = "partition", so duplicates there are fine
  expect_no_error(plot(stratData1, show = "partition", signal = c(1, 1),
                       display = FALSE))
})

test_that("plot.StratData(signal='all') honours colourBy (RT-505/#726)", {
  testDataMulti <- .GenerateTestData("multi", version = "1")
  sd <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                  signalColumn = c("a", "b"))
  uniqueParts <- sd[[c("partsAttr", "uniqueParts")]]
  expect_gt(length(uniqueParts), 1)

  outPartition <-
    plot(sd, signal = "all", colourBy = "partition", display = FALSE)
  expect_equal(sort(outPartition[["labels"]]), sort(uniqueParts))
  # the returned per-point colours must actually be partition colours, not
  # just the legend labels -- the drawing/return-value colour vector is what
  # RT-505 originally left unfixed even once the legend was corrected
  pointColours <- unique(unlist(lapply(outPartition[[1]], `[[`, "colour")))
  expect_true(all(pointColours %in% outPartition[["col"]]))

  outSite <- plot(sd, signal = "all", colourBy = "site", display = FALSE)
  expect_equal(outSite[["labels"]], sd[["sites"]])
})

test_that("plot.StratData draws partition-coloured lines (RT-505/#726)", {
  # the "o"/"l" line overlay was hard-coded to the site palette regardless
  # of colourBy, disagreeing with the legend/return value
  testDataMulti <- .GenerateTestData("multi", version = "1")
  sd <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                  signalColumn = c("a", "b"))

  drawnCol <- character(0)
  testthat::local_mocked_bindings(
    points = function(x, y, ..., col = NA) {
      drawnCol <<- c(drawnCol, as.character(col))
    }
  )

  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  out <- plot(sd, signal = "all", type = "l", colourBy = "partition")

  expect_gt(length(drawnCol), 0)
  expect_true(all(drawnCol %in% out[["col"]]))
})

test_that("plot.StratData(signal=) out of order keys plotDF correctly (#773)", {
  testDataMulti <- .GenerateTestData("multi", version = "1")
  sd <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                  signalColumn = c("a", "b"))

  out <- plot(sd, signal = c("b", "a"), display = FALSE)
  plotDF <- out[[1]]
  expect_equal(unique(plotDF[["a"]][["signal"]]), "a")
  expect_equal(unique(plotDF[["b"]][["signal"]]), "b")
})

test_that("plot.StratData suppresses ylab on correct panel (RT-500/#722)", {
  # sites = c(3, 1) draws site 3 first (leftmost panel) and site 1 second; the
  # ylab must attach to whichever panel is drawn first, not to "site 1".
  capturedYlabs <- character(0)
  originalExtract <- StratoBayes:::.ExtractRelevantArgs
  testthat::local_mocked_bindings(
    .ExtractRelevantArgs = function(args, funcName) {
      if (identical(funcName, "plot.default")) {
        ylab <- if (is.null(args[["ylab"]])) NA_character_ else args[["ylab"]]
        capturedYlabs <<- c(capturedYlabs, ylab)
      }
      originalExtract(args, funcName)
    },
    .package = "StratoBayes"
  )

  t1 <- StratData(testData$signal, parts = testData$parts, ties = testData$ties)
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  plot(t1, sites = c(3, 1))

  # only the plot.default() call that opens each panel sets an explicit
  # ylab; the subsequent lines()/points() calls for the same panel are also
  # routed through .ExtractRelevantArgs(..., "plot.default") but carry no
  # ylab of their own (NA here), so they're filtered out before comparing
  expect_equal(capturedYlabs[!is.na(capturedYlabs)], c("height", ""))
})
