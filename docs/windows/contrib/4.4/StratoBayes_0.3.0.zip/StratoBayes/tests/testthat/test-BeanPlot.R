test_that("BeanPlot works", {
  skip_if_not_snapshot_os()
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 1", function() {
    set.seed(1)
    BeanPlot(stratPosterior1)
  })
})

test_that("BeanPlot works with custom settings", {
  skip_if_not_snapshot_os()
  skip_if_not_installed("vdiffr")
  skip_on_ci()
  vdiffr::expect_doppelganger("BeanPlot 2", function() {
    set.seed(1)
    BeanPlot(stratPosterior5a, parameters = c(1:2, "posterior"),
            alignment = 1:2, col = c("blue", "red"),
            iterations = 4000:5000, runs = 1:2,
            xlab = expression(alpha[2], log~gamma[2], "posterior"),
            cex.axis = 1.2, cex.lab = 1.2,
            ylab = c("alpha", "log gamma", "log posterior"),
            border = "green")
  })
})


test_that("BeanPlot returns valid kde objects", {
  set.seed(1)
  png(tempfile())
  values <- BeanPlot(stratPosterior5a, parameters = c(1:2, "posterior"),
           alignment = 1:2, col = c("blue", "red"),
           iterations = 4000:5000, runs = 1:2,
           xlab = expression(alpha[2], log~gamma[2], "posterior"),
           cex.axis = 1.2, cex.lab = 1.2,
           ylab = c("alpha", "log gamma", "log posterior"),
           border = "green")
  dev.off()

  # Returns a list with one element per parameter group
  expect_type(values, "list")
  # Parameters 1:2 are alpha_site2, gammaLog_site2 → 2 groups
  # Plus "posterior" → 3 groups total
  expect_length(values, 3)

  # Each element is a list of kde objects
  for (i in seq_along(values)) {
    expect_type(values[[i]], "list")
    for (j in seq_along(values[[i]])) {
      kde <- values[[i]][[j]]
      expect_s3_class(kde, "kde")
      expect_true(is.numeric(kde$estimate))
      # ks's binned estimator can round a zero density to about -1e-16
      expect_true(all(kde$estimate >= -sqrt(.Machine$double.eps)))
      expect_true(length(kde$eval.points) > 0)
    }
  }
})


test_that("BeanPlot accepts col/border vectors matching length(parameters)", {
  set.seed(1)
  png(tempfile())
  on.exit(dev.off())
  expect_no_error(
    BeanPlot(stratPosterior2, parameters = c(3:5, "posterior"),
             col = c("blue", "red", "green", "purple"),
             border = c("black", "black", "black", "black"))
  )
})

test_that("BeanPlot works with new cluster object and
          iterations before burnIn", {
            skip_if_not_snapshot_os()
            skip_on_ci()

            clustNew <- Cluster(stratPosterior1, iterations = 100:200)

            vdiffr::expect_doppelganger("BeanPlot 3", function() {
              BeanPlot(stratPosterior1, alignment = 1,
                      stratCluster = clustNew, type = "o")
            })})


test_that("BeanPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({BeanPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("BeanPlot does not crash when a selection yields a single sample", {
  set.seed(1)
  png(tempfile())
  expect_no_error(values <- BeanPlot(stratPosterior1, maxSamples = 1))
  dev.off()

  expect_type(values, "list")
  for (group in values) {
    for (dens in group) {
      expect_true(isTRUE(dens[["singlePoint"]]))
    }
  }
})

test_that("BeanPlot does not crash on a near-degenerate (IQR = 0) column when
          ks is available (RT-302)", {
  skip_if_not_installed("ks")

  # Force alpha_site_2 to a single value for the vast majority of iterations
  # (a chain stuck at one value / a fixed parameter), so IQR(x) == 0. Before
  # the fix, this made ks::kde() throw "scale estimate is zero for input data",
  # crashing the plot; the nrow < 2 guard doesn't cover this case since there
  # are plenty of rows, just almost no variance among them.
  patched <- stratPosterior1
  samp <- patched[["samples"]]
  idx <- which(dimnames(samp)[[2]] == "alpha_site_2")
  sub <- samp[, idx, , , drop = FALSE]
  sub[seq_len(round(0.97 * length(sub)))] <- 6
  samp[, idx, , ] <- sub
  patched[["samples"]] <- samp

  png(tempfile())
  on.exit(dev.off())
  expect_no_error(values <- BeanPlot(patched, parameters = "alpha_site_2",
                                     display = TRUE))
  expect_false(isTRUE(values[[1]][[1]][["singlePoint"]]))
})

test_that("BeanPlot centres horizontal (srt = 0) axis labels instead of always right-aligning them (RT-609)", {
  # `argsText[["adj"]] <- 0.975` ran unconditionally after the srt == 0
  # branch, immediately overwriting the adj = 0.5 it had just set
  capturedAdj <- c()
  testthat::local_mocked_bindings(
    text = function(...) {
      capturedAdj <<- c(capturedAdj, list(...)[["adj"]])
      invisible(NULL)
    },
    .package = "StratoBayes"
  )
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  invisible(BeanPlot(stratPosterior1, srt = 0))
  expect_true(length(capturedAdj) > 0)
  expect_true(all(capturedAdj == 0.5))

  capturedAdj <- c()
  invisible(BeanPlot(stratPosterior1, srt = 45))
  expect_true(length(capturedAdj) > 0)
  expect_true(all(capturedAdj == 0.975))
})

test_that("BeanPlot validates `alignment` before dereferencing it (RT-604)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(BeanPlot(stratPosterior1, alignment = NULL),
               "`alignment` cannot be NULL")
  expect_error(BeanPlot(stratPosterior1, alignment = character(0)),
               "`alignment` cannot be an empty vector")
  expect_error(BeanPlot(stratPosterior1, alignment = NA),
               "`alignment` must not contain missing values")
})

test_that("BeanPlot validates maxSamples instead of crashing inside .maxSampleDeterministicRows (RT-606)", {
  expect_error(BeanPlot(stratPosterior1, maxSamples = NA), "`maxSamples`")
  expect_error(BeanPlot(stratPosterior1, maxSamples = -5), "`maxSamples`")
})
