# Red-team area 11: `Cluster()` argument validation (#1603, #1604, #1607) and
# the clustering memo's identity and reach (#1605, #1606).
# `.WithClusterCache()` lives in helper-cluster-cache.R.

set.seed(1)
threeGroups <- rbind(
  cbind(rnorm(60, 0), rnorm(60, 0)),
  cbind(rnorm(60, 30), rnorm(60, 0)),
  cbind(rnorm(60, 0), rnorm(60, 30))
)

# ---------------------------------------------------------------------------
# #1603: maxClusterSamples below the subsample floor silently returns k = 1
# ---------------------------------------------------------------------------

test_that("a too-small subsample is refused, not collapsed (#1603)", {
  # Below 3 the subsample cannot support `clustMax >= 2`, so `.ProtoCluster()`
  # labels every row 1 and `.ProtoClusterSubsample()` propagates that to all n
  # rows: a genuinely multimodal posterior reported as a single alignment.
  expect_error(Cluster(stratPosterior1, maxClusterSamples = 2),
               "maxClusterSamples")
  expect_error(Cluster(stratPosterior1, maxClusterSamples = 0),
               "maxClusterSamples")
  expect_error(Cluster(stratPosterior1, maxClusterSamples = -1),
               "maxClusterSamples")
})

test_that("3 is the value below which no split is ever scored (#1603)", {
  # Characterises the boundary the validator's constant claims, below the
  # public entry point that now refuses to cross it. `silCutOff = -1` accepts
  # any split the algorithm proposes, so a k of 1 here means `.ProtoCluster()`
  # returned before scoring anything -- the structural collapse -- rather than
  # having looked and found nothing.
  kAt <- function(m) {
    length(unique(.ProtoClusterSubsample(threeGroups, silCutOff = -1,
                                         maxClusterSamples = m)))
  }
  expect_equal(kAt(2), 1L) # never examined
  expect_gt(kAt(3), 1L)    # examined: the floor is exactly here
  expect_gt(kAt(2500), 1L)

  # and at the default cut-off the collapse is total below the floor
  expect_length(unique(.ProtoClusterSubsample(threeGroups,
                                              maxClusterSamples = 2)), 1L)
  expect_gt(length(unique(.ProtoClusterSubsample(threeGroups,
                                                 maxClusterSamples = 2500))),
            1L)
})

test_that("legitimate maxClusterSamples values still work (#1603)", {
  expect_no_error(Cluster(stratPosterior1, maxClusterSamples = 10))
  expect_no_error(Cluster(stratPosterior1, maxClusterSamples = Inf))
})

# ---------------------------------------------------------------------------
# #1604: the RT-320 bounds, never applied to the exported method
# ---------------------------------------------------------------------------

test_that("clustMax is validated as StratMCMC() validates its twin (#1604)", {
  expect_error(Cluster(stratPosterior1, clustMax = NA), "clustMax")
  expect_error(Cluster(stratPosterior1, clustMax = 1), "clustMax")
  expect_error(Cluster(stratPosterior1, clustMax = 2.5), "clustMax")
  expect_error(Cluster(stratPosterior1, clustMax = c(2, 3)), "clustMax")
  expect_no_error(Cluster(stratPosterior1, clustMax = 2))
})

test_that("silCutOff is validated as StratMCMC() validates its twin (#1604)", {
  expect_error(Cluster(stratPosterior1, silCutOff = NA), "silCutOff")
  expect_error(Cluster(stratPosterior1, silCutOff = 5), "silCutOff")
  expect_error(Cluster(stratPosterior1, silCutOff = -2), "silCutOff")
  expect_no_error(Cluster(stratPosterior1, silCutOff = -1))
  expect_no_error(Cluster(stratPosterior1, silCutOff = 1))
})

test_that("maxClusterSamples rejects NA and non-integers (#1604)", {
  expect_error(Cluster(stratPosterior1, maxClusterSamples = NA),
               "maxClusterSamples")
  expect_error(Cluster(stratPosterior1, maxClusterSamples = 10.5),
               "maxClusterSamples")
})

test_that("proto-only arguments are ignored under hdbscan (#1604, #1288)", {
  # `minPts`'s own precedent: an argument the chosen backend never reads is
  # not validated, and `options` records it as NULL.
  expect_no_error(hd <- Cluster(stratPosterior1, clusterMethod = "hdbscan",
                                minPts = 5, clustMax = NA, silCutOff = NA,
                                maxClusterSamples = NA))
  expect_null(hd[[c("options", "clustMax")]])
  expect_null(hd[[c("options", "silCutOff")]])
  expect_null(hd[[c("options", "maxClusterSamples")]])
  # and the converse, which is why they are safe to leave unvalidated
  expect_null(Cluster(stratPosterior1)[[c("options", "minPts")]])
})

# ---------------------------------------------------------------------------
# #1607: argument-handling quirks
# ---------------------------------------------------------------------------

test_that("two identical Cluster() calls are identical() (#1607)", {
  # `options$runSelect` leaked a fastmatch `.match.hash` stamped in place by
  # the `%fin%` that filtered it. fastmatch has gone (#1982); what keeps the
  # reported value bare now is `.ValidateRunSelect()`'s `as.integer()`, which
  # strips every attribute a user's `runs` arrived with.
  runs <- seq_len(stratPosterior1[["nRun"]])
  cl <- Cluster(stratPosterior1, burnIn = 0.75,
                runs = structure(runs, names = letters[runs], tag = "x"))
  expect_null(attributes(cl[[c("options", "runSelect")]]))
  expect_identical(Cluster(stratPosterior1, burnIn = 0.75),
                   Cluster(stratPosterior1, burnIn = 0.75))
})

test_that("a non-logical returnClusterData is refused (#1607)", {
  expect_error(Cluster(stratPosterior1, burnIn = 0.75,
                       returnClusterData = 1),
               "returnClusterData")
  expect_true("clusterData" %in%
                names(Cluster(stratPosterior1, burnIn = 0.75,
                              returnClusterData = TRUE)))
})

test_that("clusterMethod is matched the same way by both methods (#1607)", {
  # case-insensitive and partial in both, where each method used to accept
  # only what the other rejected
  expect_no_error(Cluster(stratPosterior1, clusterMethod = "PROTO"))
  expect_no_error(Cluster(threeGroups, clusterMethod = "prot"))
  expect_no_error(Cluster(threeGroups, clusterMethod = "PROTO"))
  expect_no_error(Cluster(stratPosterior1, clusterMethod = "prot"))
  expect_error(Cluster(stratPosterior1, clusterMethod = "pam"), "clusterMethod")
  expect_error(Cluster(threeGroups, clusterMethod = "nonesuch"),
               "clusterMethod")
  # `match.arg(NULL, choices)` used to return choices[[1]], silently running
  # proto for a caller who named no method at all
  expect_error(Cluster(stratPosterior1, clusterMethod = NULL), "clusterMethod")
  expect_error(Cluster(stratPosterior1, clusterMethod = NA), "clusterMethod")
  expect_error(Cluster(threeGroups, clusterMethod = c("proto", "pam")),
               "clusterMethod")
  expect_error(Cluster(threeGroups, clusterMethod = 1), "clusterMethod")
})

# ---------------------------------------------------------------------------
# #1605 / #1606: one memo, keyed on the resolved row selection
# ---------------------------------------------------------------------------

test_that("equivalent selections share one memo entry (#1605)", {
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]

  first <- StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2500,
                                         seq_len(nRun), NULL)
  expect_length(ce$clusterCache, 1L)

  # the same rows, this time supplied explicitly: the same clustering, so it
  # must not be computed and stored a second time
  StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2500, seq_len(nRun),
                                 first[["rowIndex"]])
  expect_length(ce$clusterCache, 1L)
})

test_that("[[.StratPosterior shares the memo with .ClusterInternal (#1605)", {
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")
  expect_length(ce$clusterCache, 0L)

  sc <- sp[["stratCluster"]]
  expect_length(ce$clusterCache, 1L)

  # and the entry the lazy accessor wrote serves an equivalent direct call
  StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2500,
                                 seq_len(sp[["nRun"]]), sc[["rowIndex"]])
  expect_length(ce$clusterCache, 1L)
})

test_that("no cache path claims to be clustering for the first time (#1605)", {
  # Read off the source, not the console: testthat suppresses cli's progress
  # conditions inside `test_file()`, so the emitted text is unobservable here.
  # A legacy posterior has nowhere to memoise to, so every access recomputes
  # and the claim was false on each one.
  src <- paste(deparse(`[[.StratPosterior`), collapse = " ")
  expect_true(grepl("Clustering posterior samples", src, fixed = TRUE))
  expect_false(grepl("first time only", src, fixed = TRUE))
})

test_that("a served clustering reports the current call's options (#1606)", {
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  warmed <- sp[["stratCluster"]] # default burnIn, i.e. 0.5

  served <- StratoBayes:::.ClusterInternal(sp, 2500, NULL, 2500,
                                          seq_len(sp[["nRun"]]),
                                          warmed[["rowIndex"]])
  expect_identical(served[["cluster"]], warmed[["cluster"]])
  expect_equal(served[[c("options", "burnIn")]], 2500)
  expect_equal(served[[c("options", "maxSamples")]], 2500)
})

test_that("a memo hit equals an independently computed miss (#1606)", {
  # Two copies with separate caches, so `fresh` shares no SEXP with `hit`:
  # comparing a hit against the object that warmed it cannot fail, because
  # they alias each other.
  # Not stratPosterior2: the shipped datasets were regenerated (#1622) and it
  # now clusters to one mode. 5a has the widest margin, at 3.
  warmCopy <- .WithClusterCache(stratPosterior5a, lazy = TRUE)
  coldCopy <- .WithClusterCache(stratPosterior5a, lazy = TRUE)
  expect_gt(warmCopy[["stratCluster"]][["nClust"]], 1L) # multimodal fixture

  # an ordinary summary() first, so anything a consumer does to the stored
  # object has already happened when the hit is served
  invisible(warmCopy[["summary"]])

  hit <- Cluster(warmCopy, burnIn = 0.5)
  fresh <- Cluster(coldCopy, burnIn = 0.5)
  expect_identical(hit, fresh)
})

test_that("a memo hit equals its miss for an attributed selectRows (#1606)", {
  # A hit used to rebuild `rowIndex` element by element to detach it from the
  # stored copy, which silently dropped any attribute a user's own
  # `selectRows` carried -- so the hit disagreed with the miss that stored it.
  rows <- lapply(ExtractIterations(stratPosterior1, "all", burnIn = 0.5),
                 structure, sourced = "user")
  warmCopy <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  coldCopy <- .WithClusterCache(stratPosterior1, lazy = TRUE)

  miss <- Cluster(coldCopy, selectRows = rows)
  invisible(Cluster(warmCopy, selectRows = rows))
  hit <- Cluster(warmCopy, selectRows = rows)
  expect_identical(hit[["rowIndex"]], miss[["rowIndex"]])
  expect_identical(hit, miss)
})

test_that("hdbscan and proto do not serve each other's rows (#1606)", {
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")

  proto <- Cluster(sp, burnIn = 0.5)
  hd <- Cluster(sp, burnIn = 0.5, clusterMethod = "hdbscan", minPts = 5)
  expect_length(ce$clusterCache, 2L)
  expect_equal(hd[[c("options", "clusterMethod")]], "hdbscan")
  expect_equal(proto[[c("options", "clusterMethod")]], "proto")

  # a second hdbscan call at a different minPts is a different clustering
  Cluster(sp, burnIn = 0.5, clusterMethod = "hdbscan", minPts = 40)
  expect_length(ce$clusterCache, 3L)
  expect_identical(Cluster(sp, burnIn = 0.5, clusterMethod = "hdbscan",
                           minPts = 5), hd)
  expect_length(ce$clusterCache, 3L)
})

test_that("a foreign cache is still disowned by the memo (RT-454, #1605)", {
  sp <- .WithClusterCache(stratPosterior2, lazy = TRUE)
  ce <- .subset2(sp, ".cache")
  invisible(sp[["stratCluster"]])
  nOwn <- length(ce$clusterCache)

  derived <- sp
  derived[["samples"]] <- derived[["samples"]][, , 1L, , drop = FALSE]
  derived[["nRun"]] <- 1L
  expect_null(.PosteriorCache(derived))

  invisible(derived[["stratCluster"]])
  expect_length(ce$clusterCache, nOwn)
})
