# Issue #259: the adaptive adaptation timer.
#
# The decision logic is pinned here against hand-written stores, whose clock
# is supplied rather than read; the integration tests check the wiring through
# a real run. Freeze *iterations* are never asserted exactly: the timer prices
# tuning against sampling in wall-clock, and cost-aware proposal reweighting
# (RT-323) already made sampled values vary across invocations even under a
# fixed seed. What is deterministic is the schedule when the timer does not
# fire, and the window bounds when it does.

# A saved-sample matrix: iteration, chain, then two parameter columns.
TimerMat <- function(iters, chain = 1, p1 = rnorm(length(iters)),
                     p2 = rnorm(length(iters))) {
  cbind(iters, chain, p1, p2, deparse.level = 0)
}

# A collapsed store holding `draws` (one column) at iterations 1..n, produced
# at `secsPerIter` seconds an iteration.
TimerStore <- function(draws, secsPerIter = 1) {
  store <- .AdaptTimerAppend(.AdaptTimerStore(1),
                             TimerMat(seq_along(draws), p1 = draws,
                                      p2 = rnorm(length(draws))),
                             cols = 3:4, endAdapting = length(draws),
                             elapsed = secsPerIter * length(draws))
  .AdaptTimerCollapse(store)
}

test_that(".AdaptTimerAppend keeps cold-chain adaptation rows only", {
  store <- .AdaptTimerStore(1)
  mat <- rbind(TimerMat(1:10), TimerMat(1:10, chain = 2))
  store <- .AdaptTimerAppend(store, mat, cols = 3:4, endAdapting = 6,
                             elapsed = 10)
  store <- .AdaptTimerCollapse(store)

  expect_identical(store[["iters"]], as.numeric(1:6))
  # Iteration column plus the two monitored columns.
  expect_identical(ncol(store[["draws"]]), 3L)
})

test_that("a matrix with nothing to keep leaves the store untouched", {
  store <- .AdaptTimerAppend(.AdaptTimerStore(1), TimerMat(1:10, chain = 2),
                             cols = 3:4, endAdapting = 10, elapsed = 10)
  expect_length(store[["chunks"]], 0L)
})

test_that("the store accumulates chunks and trims to its trailing cap", {
  store <- .AdaptTimerStore(1)
  for (block in list(1:300, 301:500, 501:700)) {
    store <- .AdaptTimerAppend(store, TimerMat(block), cols = 3:4,
                               endAdapting = 1000, elapsed = max(block))
  }
  expect_length(store[["chunks"]], 3L)
  store <- .AdaptTimerCollapse(store)

  expect_length(store[["chunks"]], 0L)
  expect_identical(store[["iters"]],
                   as.numeric(seq(701 - .kAdaptTimerRows, 700)))
})

test_that("too few rows give no estimate", {
  store <- TimerStore(rnorm(.kAdaptTimerMinRows - 1L))
  expect_identical(.AdaptTimerAssess(store, 10)[["predicted"]], NA_real_)
})

test_that("a store with no usable parameter gives no estimate", {
  store <- .AdaptTimerCollapse(
    .AdaptTimerAppend(.AdaptTimerStore(1),
                      TimerMat(1:200, p1 = rep(1, 200), p2 = rep(2, 200)),
                      cols = 3:4, endAdapting = 200, elapsed = 200))
  expect_identical(.AdaptTimerAssess(store, 10)[["predicted"]], NA_real_)
})

test_that("independent draws predict a cheap target, slow mixing a dear one", {
  set.seed(1)
  fast <- .AdaptTimerAssess(TimerStore(rnorm(256)), 10)
  expect_lt(fast[["predicted"]], 500)
  expect_identical(fast[["span"]], 128)

  slow <- as.numeric(arima.sim(list(ar = 0.995), n = 256))
  expect_gt(.AdaptTimerAssess(TimerStore(slow), 200)[["predicted"]], 500)
})

test_that("a pinned parameter does not poison the estimate", {
  set.seed(1)
  store <- .AdaptTimerCollapse(
    .AdaptTimerAppend(.AdaptTimerStore(1),
                      TimerMat(1:256, p1 = rnorm(256), p2 = rep(3, 256)),
                      cols = 3:4, endAdapting = 256, elapsed = 256))
  expect_lt(.AdaptTimerAssess(store, 10)[["predicted"]], 500)
})

test_that("only the trailing half is assessed, so a transient ages out", {
  set.seed(1)
  # A strong drift in the first half; independent draws in the second. Judged
  # whole, the drift would suppress the rate; the split means it cannot.
  store <- TimerStore(c(seq(0, 50, length.out = 128), rnorm(128)))
  expect_lt(.AdaptTimerAssess(store, 10)[["predicted"]], 500)
})

test_that("the target is priced in seconds, not iterations", {
  set.seed(1)
  # One store, re-priced: the draws are held byte-for-byte identical, so
  # nothing but the clock can move the estimate.
  store <- TimerStore(rnorm(256))
  slower <- store
  slower[["stampSecs"]] <- 2 * store[["stampSecs"]]

  quick <- .AdaptTimerAssess(store, 10)
  slow <- .AdaptTimerAssess(slower, 10)
  expect_equal(slow[["span"]], 2 * quick[["span"]])
  expect_equal(slow[["predicted"]], 2 * quick[["predicted"]])
})

test_that("mixing bought with time does not read as progress", {
  set.seed(1)
  # Thinning halves the autocorrelation between stored rows, so each row is
  # worth about twice the effective draws -- but the rows take twice as long
  # to produce. Per second the kernel has not improved, and the prediction
  # must not fall; priced per iteration the same draws look like a win, which
  # is what would reset the patience clock and keep tuning forever.
  ar <- as.numeric(arima.sim(list(ar = 0.8), n = 512))
  before <- .AdaptTimerAssess(TimerStore(ar[seq_len(256)]), 200)
  thinned <- ar[seq(2, 512, by = 2)]
  perSecond <- .AdaptTimerAssess(TimerStore(thinned, secsPerIter = 2), 200)
  perIteration <- .AdaptTimerAssess(TimerStore(thinned), 200)
  expect_gt(perSecond[["predicted"]], 0.75 * before[["predicted"]])
  expect_lt(perIteration[["predicted"]], 0.75 * before[["predicted"]])
})

test_that("a window the clock cannot resolve gives no estimate", {
  set.seed(1)
  # A zero span would price the target at zero, and the backstop fires on any
  # spend at all against a zero cost.
  flat <- .AdaptTimerAssess(TimerStore(rnorm(256), secsPerIter = 0), 10)
  expect_identical(flat[["predicted"]], NA_real_)
  expect_identical(flat[["span"]], NA_real_)

  # A store whose only stamp is the seed has nothing to interpolate between.
  expect_identical(.AdaptTimerSeconds(.AdaptTimerStore(1), 1, 2), NA_real_)
})

test_that("trimming keeps the stamp that brackets the oldest retained row", {
  store <- .AdaptTimerStore(1)
  for (from in seq(1, 801, by = 100)) {
    block <- from:(from + 99L)
    store <- .AdaptTimerAppend(store, TimerMat(block), cols = 3:4,
                               endAdapting = 1000, elapsed = max(block))
  }
  store <- .AdaptTimerCollapse(store)

  # Stamps below the retained rows are dropped, bar the one they interpolate
  # from; the map still prices any window inside the store.
  expect_lt(length(store[["stampIter"]]), 9L)
  expect_lte(store[["stampIter"]][[1L]], store[["iters"]][[1L]])
  expect_equal(.AdaptTimerSeconds(store, 500, 700), 200)
})

# Feed .AdaptTimerDecide a trajectory of predicted seconds at a fixed
# checkpoint spacing; return the spends at which it froze (numeric(0) if
# never). Every quantity here is seconds.
DecideRun <- function(predictions, span = 100, spacing = 50, from = 200) {
  store <- .AdaptTimerStore(1)
  frozen <- numeric(0)
  for (k in seq_along(predictions)) {
    spent <- from + (k - 1L) * spacing
    store <- .AdaptTimerDecide(store, predictions[[k]], span, spent)
    if (store[["freeze"]]) {
      frozen <- c(frozen, spent)
    }
  }
  frozen
}

test_that("the backstop freezes once the spend reaches the prediction", {
  store <- .AdaptTimerDecide(.AdaptTimerStore(1), 10, span = 128, spent = 500)
  expect_false(store[["freeze"]])
  expect_identical(store[["streak"]], 1L)

  store <- .AdaptTimerDecide(store, 10, span = 128, spent = 510)
  expect_true(store[["freeze"]])
})

test_that("a flat, well-measured cost freezes after the patience runs out", {
  # Never pays back, so patience = span + spread (0 here) after the first
  # verdict; the streak then needs a second vote: freeze at 350 + spacing.
  expect_identical(DecideRun(rep(10000, 8))[[1L]], 400)
})

test_that("tuning that pays 1:1 or better never freezes", {
  expect_length(DecideRun(seq(10000, by = -50, length.out = 20)), 0L)
})

test_that("a sub-1:1 return freezes once the unpaid spend exceeds patience", {
  # Saves 10 per 50 spent: the deficit grows 40 per checkpoint against a
  # patience of span + spread = 120, crossing at the fourth verdict; the
  # streak completes on the fifth.
  expect_identical(DecideRun(seq(10000, by = -10, length.out = 10))[[1L]], 400)
})

test_that("a shortfall inside the observed noise does not freeze", {
  # Flat in truth, but the spread (4000) swallows any deficit this run could
  # accumulate; the same trajectory rescaled 100-fold smaller freezes.
  noisy <- rep(c(8000, 12000, 9000, 11000), 5)
  expect_length(DecideRun(noisy), 0L)
  expect_gt(length(DecideRun(noisy / 100)), 0L)
})

test_that("a full payback resets the patience clock", {
  # Flat long enough to start the streak, then a step improvement repays the
  # sunk spend; the clock restarts and the run ends before it expires again.
  steps <- c(rep(10000, 4), rep(4000, 4))
  expect_length(DecideRun(steps), 0L)
  # Without the step, the flat stretch alone freezes within the same horizon.
  expect_gt(length(DecideRun(rep(10000, 8))), 0L)
})

test_that("the checkpoint needs a streak, and any non-freeze resets it", {
  set.seed(1)
  store <- TimerStore(rnorm(256))
  store[["streak"]] <- 0L

  store <- .AdaptTimerCheckpoint(store, 10, spent = 500)
  expect_false(store[["freeze"]])
  expect_identical(store[["streak"]], 1L)

  store <- .AdaptTimerCheckpoint(store, 10, spent = 510)
  expect_true(store[["freeze"]])

  # An unassessable checkpoint resets the streak rather than pausing it.
  short <- TimerStore(rnorm(64))
  short[["streak"]] <- 1L
  short <- .AdaptTimerCheckpoint(short, 10, spent = 500)
  expect_identical(short[["streak"]], 0L)
})

test_that(".AdaptTimerEss shares the criterion across runs", {
  expect_identical(.AdaptTimerEss(list(rHat = 1.02, ess = 100), 4), 25)
  expect_identical(.AdaptTimerEss(NULL, 2), .kConvergenceDefault[["ess"]] / 2)
  withr::local_options(StratoBayes.adaptTimerEss = 8)
  expect_identical(.AdaptTimerEss(NULL, 2), 4)
  # An explicit criterion outranks the option.
  expect_identical(.AdaptTimerEss(list(ess = 100), 2), 50)
})

test_that("only the default window arms the timer", {
  Arm <- function(...) {
    StratMCMC(stratModel1, nIter = 100, nChains = 2, ...)[["adaptTimer"]]
  }
  expect_true(Arm())
  expect_false(Arm(endAdapting = 30))
  expect_false(Arm(adaptProposal = FALSE))
})

# ── Cursor rebase at a freeze (#1090) ────────────────────────────────────────

# `nIter = 10000` with a fast proposal cadence is the configuration worked
# through in #1090: temperatures are first adapted at 248, while the timer can
# freeze from around iteration 200.
FreezeMCMC <- function(nIter = 10000, adaptProposalInterval = 10, ...) {
  StratMCMC(stratModel1, nIter = nIter, nChains = 4,
            adaptProposalInterval = adaptProposalInterval, ...)
}

test_that("a freeze below the first temperature update disables adaptation", {
  mcmc <- FreezeMCMC()
  expect_true(mcmc[[c("temper", "adaptTemperatures")]])
  first <- mcmc[[c("temper", "adaptTemperaturesIterations")]][[1L]]

  rebased <- .RebaseAdaptCursors(mcmc, first - 1L, 10)
  # Trimming to an empty schedule used to leave `[1]` as NA.
  expect_false(anyNA(rebased[["adaptTempIter"]]))
  expect_equal(rebased[["adaptTempIter"]], 0)
  expect_false(rebased[["adaptTemp"]])
  expect_false(rebased[["mcmc"]][[c("temper", "adaptTemperatures")]])
})

test_that("a freeze that stops swap monitoring says so (#1184)", {
  mcmc <- FreezeMCMC(adaptTemperaturesMonitor = TRUE)
  first <- mcmc[[c("temper", "adaptTemperaturesIterations")]][[1L]]

  # Swap monitoring is gated on adaptation still being live, so the freeze
  # ends it too -- silently, before the fix, leaving the rest of
  # `temperingSwaps` NA with nothing in the run's output to explain it.
  expect_warning(rebased <- .RebaseAdaptCursors(mcmc, first - 1L, 10),
                 "temperingSwaps")
  expect_false(rebased[["adaptTemp"]])

  # The user who never opted into the diagnostic hears nothing.
  expect_silent(.RebaseAdaptCursors(FreezeMCMC(), first - 1L, 10))
})

test_that(".Tempering() survives a freeze before the schedule starts", {
  mcmc <- FreezeMCMC()
  freezeAt <- mcmc[[c("temper", "adaptTemperaturesIterations")]][[1L]] - 1L
  frozen <- .RebaseAdaptCursors(mcmc, freezeAt, 10)[["mcmc"]]
  state <- lapply(seq_len(4), function(ch) list(metro = list(logPost = -ch)))

  # The R engine reads the trimmed schedule directly, so an empty one made
  # `iteration >= NA` abort the run with "missing value where TRUE/FALSE
  # needed" at the first iteration visited after the freeze.
  expect_error(.Tempering(frozen, state, freezeAt), NA)
})

test_that("a freeze rebases every cursor keyed to endAdapting", {
  mcmc <- FreezeMCMC()
  interval <- mcmc[[c("metro", "adaptProposalInterval")]]
  freezeAt <- 400
  rebased <- .RebaseAdaptCursors(mcmc, freezeAt, interval)

  expect_equal(rebased[["endAdapt"]], freezeAt)
  expect_equal(rebased[["mcmc"]][["endAdapting"]], freezeAt)
  expect_equal(rebased[["accMonStart"]], freezeAt + 1)
  expect_equal(
    rebased[["mcmc"]][[c("metro", "acceptanceMonitor", "startMonitoring")]],
    freezeAt + 1)
  expect_true(all(rebased[["adaptTempIter"]] <= freezeAt))
  # Without this the next weight update waits for the original cap, leaving
  # thousands of post-adaptation iterations unreweighted and then resetting the
  # rate accumulators over the whole span at once.
  expect_equal(rebased[["nextProbUpdate"]], freezeAt + interval)
  expect_lt(rebased[["nextProbUpdate"]], mcmc[["endAdapting"]] + interval)
})

test_that("no buildable configuration leaves an NA cursor after a freeze", {
  # #1090 suggests pinning
  # `adaptTemperaturesIterations[1] <= startAdapting + 2 * adaptProposalInterval`.
  # That is false as the schedules stand -- at `nIter = 10000` the first update
  # is 248 against a bound of 70 -- and it is precisely that gap that puts a
  # freeze below the schedule. The reachable safety property is pinned instead:
  # after a freeze anywhere in the window, the schedule is free of NA and
  # either non-empty or switched off.
  for (nIter in c(200, 1000, 10000)) {
    for (interval in c(10, 100)) {
      mcmc <- FreezeMCMC(nIter = nIter, adaptProposalInterval = interval)
      # round(): the sampler only ever produces integer iterations, and
      # .RebaseAdaptCursors() uses freezeAt as one.
      window <- round(seq(mcmc[["startAdapting"]], mcmc[["endAdapting"]],
                          length.out = 8))
      for (freezeAt in window) {
        rebased <- .RebaseAdaptCursors(mcmc, freezeAt, interval)
        expect_false(anyNA(rebased[["adaptTempIter"]]))
        expect_gt(length(rebased[["adaptTempIter"]]), 0L)
        expect_false(anyNA(rebased[["nextProbUpdate"]]))
        if (rebased[["adaptTemp"]]) {
          expect_true(all(rebased[["adaptTempIter"]] > 0))
        }
      }
    }
  }
})

# ── RT-766: the loop-local cursor assignments are wired, not just returned ──
#
# Every unit test above drives .RebaseAdaptCursors() as a function; none of
# them can catch RunStratModel.R:1867-1872 dropping one of its five
# assignments back into the loop-locals. Forcing an immediate freeze (mocked
# `.AdaptTimerCheckpoint()`) puts the freeze far below the default
# `endAdapting` (nIter/2), so a dropped `nextProbUpdate` rebase leaves the
# post-freeze reweight cursor at its stale, pre-freeze value -- reachable
# before `nIter` ends either way (nextProbUpdate's initial value is always
# under nIter for a fresh run), but reached far later and so fired far fewer
# times. Counts observed while writing this test: 44 reweights with the
# assignment in place, 25 with it deleted -- confirmed red by deleting the
# assignment locally and re-running.
test_that("RT-766: a dropped nextProbUpdate rebase starves post-freeze reweighting", {
  reweightCount <- 0L
  update <- .UpdateProposalProbAndFac
  local_mocked_bindings(
    .UpdateProposalProbAndFac = function(model, mcmc, inLateAdaptation) {
      reweightCount <<- reweightCount + 1L
      update(model, mcmc, inLateAdaptation)
    },
    .AdaptTimerCheckpoint = function(store, essShare, spent) {
      list(freeze = TRUE, predicted = 0)
    }
  )

  dir <- withr::local_tempdir()
  result <- RunStratModel(stratData1, stratModel1, nIter = 600, nChains = 4,
                          nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                          modelDir = dir, modelName = "rt766",
                          visualise = FALSE, convergenceStop = FALSE)
  ms <- result[["mcmcSummary"]]

  freezeAt <- ms[["adaptFreeze"]][[1L]][["iteration"]]
  expect_lt(freezeAt, 300)  # far below the default endAdapting (nIter/2)
  expect_gt(reweightCount, 30L)
})

# ── Integration ──────────────────────────────────────────────────────────────

# No `...`: `RunStratModel()` records its own call with `match.call()`, which
# cannot expand a `...` forwarded from a helper frame.
TimerRun <- function(convergenceStop, nIter = 600, engine = "cpp",
                     quiet = TRUE, endAdapting = NULL) {
  dir <- tempfile()
  dir.create(dir)
  RunStratModel(stratData1, stratModel1, nIter = nIter, nChains = 4,
                nRun = 1, seed = 1, quiet = quiet, nThreads = 1L,
                modelDir = dir, modelName = "timer", visualise = FALSE,
                convergenceStop = convergenceStop, engine = engine,
                endAdapting = endAdapting)
}

test_that("a small effective-sample target freezes adaptation early", {
  skip_on_cran()
  # rHat = 1.000001 is unreachable here, so the run completes and what is
  # observed is the timer alone; ess = 1 makes its target trivial.
  post <- TimerRun(list(rHat = 1.000001, ess = 1))
  ms <- post[["mcmcSummary"]]

  expect_identical(ms[["completedIter"]], 600)
  expect_lt(ms[["endAdapting"]], 300)
  freeze <- ms[["adaptFreeze"]][[1L]]
  expect_equal(freeze[["iteration"]], unname(ms[["endAdapting"]]))
  expect_lte(freeze[["predicted"]], freeze[["spent"]])
})

test_that("the R engine gets the timer working, not stubbed", {
  skip_on_cran()
  ms <- TimerRun(list(rHat = 1.000001, ess = 1), nIter = 360,
                 engine = "R")[["mcmcSummary"]]
  expect_lt(ms[["endAdapting"]], 180)
  expect_equal(ms[["adaptFreeze"]][[1L]][["iteration"]],
               unname(ms[["endAdapting"]]))
})

test_that("the default target leaves this model's window alone", {
  skip_on_cran()
  # Under the default ESS target the predicted sampling cost of this
  # slow-mixing model dwarfs any conceivable adaptation spend, so the timer
  # must not fire and the schedule is exactly the pre-timer one.
  ms <- TimerRun(TRUE)[["mcmcSummary"]]

  expect_identical(unname(ms[["endAdapting"]]), 300)
  expect_null(ms[["adaptFreeze"]][[1L]])
})

test_that("an explicit endAdapting switches the timer off", {
  skip_on_cran()
  ms <- TimerRun(list(rHat = 1.000001, ess = 1),
                 endAdapting = 250)[["mcmcSummary"]]

  expect_identical(unname(ms[["endAdapting"]]), 250)
  expect_null(ms[["adaptFreeze"]][[1L]])
})

test_that("the timer runs without the convergence machinery", {
  skip_on_cran()
  withr::local_options(StratoBayes.adaptTimerEss = 1)
  ms <- TimerRun(FALSE)[["mcmcSummary"]]

  expect_identical(ms[["completedIter"]], 600)
  expect_lt(ms[["endAdapting"]], 300)
})

test_that("a short run is untouched", {
  skip_on_cran()
  # Its adaptation window ends before the store can reach
  # `.kAdaptTimerMinRows`, so no verdict is ever formed.
  ms <- TimerRun(TRUE, nIter = 120)[["mcmcSummary"]]

  expect_identical(unname(ms[["endAdapting"]]), 60)
  expect_null(ms[["adaptFreeze"]][[1L]])
})

test_that("the freeze is announced", {
  skip_on_cran()
  expect_message(TimerRun(list(rHat = 1.000001, ess = 1), quiet = FALSE),
                 "Adaptation ends at iteration")
})

test_that("hitting the cap with a slow kernel is flagged", {
  skip_on_cran()
  expect_message(TimerRun(TRUE, nIter = 360, quiet = FALSE),
                 "used its whole window")
})
