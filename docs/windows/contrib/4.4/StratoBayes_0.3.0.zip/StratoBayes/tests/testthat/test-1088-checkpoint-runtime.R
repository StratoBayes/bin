# RT-756 (#1088): `.IntegerSequence` builds the write-checkpoint schedule that
# becomes `mcmc$writeMCMCiterations`; the schedule is then consumed at
# *runtime* as `cppCheckpoints` (R/RunStratModel.R) -- post-adaptation, the C++
# batching loop visits ONLY checkpoints, so a changed checkpoint set changes
# what actually runs, not merely what a vector contains. Prior tests pinned
# the schedule at construction only; nothing asserted the runtime consequence.
#
# Oracle: `mcmc[["completedIter"]]` is set to the exact iteration just reached
# (R/RunStratModel.R, immediately before each on-disk checkpoint write), and a
# checkpoint write fires iff the loop's current iteration is `%in%
# loopWriteIter` (== `writeMCMCiterations`). Mocking `saveRDS` inside the
# package namespace therefore records precisely the iterations the running
# engine stopped and checkpointed at, independent of the schedule construction
# this test does not re-derive. Deliberately does not hardcode `340/680/1000`
# style values, so it holds under either the overwrite or the append
# `.IntegerSequence` behaviour.
#
# `writeMCMCfile = 0.25` at `nIter = 100` is chosen so the schedule has a
# checkpoint (75) strictly *between* the default `endAdapting` (50) and
# `endIter` (100) that is not also an `adaptProposalInterval` probability-
# weight checkpoint (default interval 10, so those land on 60/70/80/90/100) --
# i.e. an iteration the C++ batching loop only stops at BECAUSE of the write
# schedule (R/RunStratModel.R:1581-1587), not because of any other checkpoint
# source. `endIter` itself always writes unconditionally via `stopConditionMet`
# (R/RunStratModel.R:2062-2066) whatever the schedule says, so it alone cannot
# discriminate a dropped checkpoint -- only an interior post-adapt entry can.
test_that("#1088: the cpp-engine loop writes a checkpoint at every scheduled iteration, and nowhere else", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  td <- file.path(tempdir(), paste0("rt756_", as.integer(runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  assign(".rt756_visited", integer(0), envir = globalenv())
  trace(
    "saveRDS", where = asNamespace("StratoBayes"), print = FALSE,
    tracer = quote(
      if (grepl("_mcmc_run_", basename(file), fixed = TRUE))
        assign(".rt756_visited",
               c(get(".rt756_visited", envir = globalenv()),
                 object[["completedIter"]]),
               envir = globalenv())
    )
  )
  on.exit({
    suppressMessages(untrace("saveRDS", where = asNamespace("StratoBayes")))
    rm(".rt756_visited", envir = globalenv())
  }, add = TRUE)

  set.seed(1088)
  RunStratModel(stratData1, stratModel1, nIter = 100L, nChains = 1L, seed = 11L,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "cpp", writeMCMCfile = 0.25,
                nThreads = 1L)

  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))
  schedule <- mcmc[["writeMCMCiterations"]]
  endAdapting <- mcmc[["endAdapting"]]
  endIter <- mcmc[["endIter"]]

  # `.InnerRunMCMC()` also writes an unconditional setup checkpoint at
  # iteration 1, before the checkpoint-schedule loop below even starts; that
  # save is not part of `writeMCMCiterations` and is excluded here.
  visitedAll <- get(".rt756_visited", envir = globalenv())
  visited <- visitedAll[visitedAll != 1L]

  # Discriminator: a schedule entry that is neither `endIter` (writes
  # unconditionally via `stopConditionMet` regardless of the schedule) nor at
  # or before `endAdapting` (reached one iteration at a time regardless of the
  # write schedule) must exist, or a dropped post-adapt checkpoint would go
  # undetected below.
  interior <- schedule[schedule > endAdapting & schedule < endIter]
  expect_gt(length(interior), 0L)

  # The set of iterations the *running* engine actually checkpointed at must
  # equal the constructed schedule exactly (same multiset) -- not a subset (a
  # checkpoint silently skipped by the C++ batching) and not a superset (an
  # extra, unscheduled write).
  expect_equal(sort(visited), sort(schedule))
})
