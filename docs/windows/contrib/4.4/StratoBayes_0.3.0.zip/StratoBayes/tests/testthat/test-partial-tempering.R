# Component-selective ("partial", temperingComponents = "signal") tempering.
#
# Proven invariant (dev/red-team/proofs/partial-tempering-correctness.md §1): at
# T = 1 every partial formula reduces to the full-tempering formula, so a single
# cold chain must produce a BIT-IDENTICAL trace under "full" and "signal". This is
# the regression guarantee that the reported (cold-chain) posterior is unchanged.
#
# Comparisons are RELATIVE (full vs signal, same seed, same machine) so they are
# platform-portable; runs are nThreads = 1 because the engine is intentionally
# non-deterministic across threads (RNG stream partition). Raw samples (r$samples,
# pre-clustering) are compared so the deterministic MCMC trace is tested directly,
# not the post-hoc clustering/summary. A discarded warmup run absorbs a one-time
# first-call effect (the first RunStratModel in a session differs from later ones).

.ptRaw <- function(tc) {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 200L, nChains = 1L, nThin = 1L, nThreads = 1L,
                  tempering = FALSE, temperingComponents = tc,
                  adaptProposal = FALSE)
  RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                visualise = FALSE, seed = 1L)$samples[, , 1, 1]
}

test_that("partial tempering is bit-identical to full at T=1 (MH proposals)", {
  skip_on_cran()
  invisible(.ptRaw("full"))            # warmup: discard first-call effect
  f <- .ptRaw("full")
  s <- .ptRaw("signal")
  expect_equal(dim(f), dim(s))
  # identical(), not a tolerance: at T=1 tempered_energy multiplies by exactly
  # 1.0, so the two paths are the same arithmetic. A tolerance would admit a
  # mis-scaled component too small to see — which is how RT-302 hid.
  expect_identical(as.numeric(f), as.numeric(s))
})

# NUTS cannot be reached through RunStratModel the way the MH arm is. Its
# selection weight is written only by `.UpdateProposals()` and its mass matrix
# only by adaptation, so `adaptProposal = FALSE` leaves it registered but never
# proposed. Adaptation cannot simply be switched on instead: proposal retuning
# is scored on measured wall-clock, so two identically seeded adapting runs
# diverge. Hence adaptation once, frozen, then the compared blocks driven
# against the engine with NUTS forced -- a pinned configuration is the only
# setting in which bit-identity is a legitimate oracle.
.ptNutsFixture <- function() {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = FALSE)
  td <- file.path(tempdir(), paste0("ptn_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  # `gradientProposals = "on"` is load-bearing: fixed knots alone do not
  # register NUTS.
  RunStratModel(stratData1, sm, nIter = 400L, nChains = 1L, nThin = 1L,
                nThreads = 1L, tempering = FALSE, gradientProposals = "on",
                adaptProposal = TRUE, engine = "R", nRun = 1L,
                runParallel = FALSE, visualise = FALSE, quiet = TRUE, seed = 1L,
                modelDir = td, modelName = "ptn")
  mcmc <- readRDS(file.path(td, "ptn_mcmc_run_1.rds"))
  if (is.null(sm[[".logpost_cpp"]]))
    sm[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(sm)

  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, "NUTS"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  list(model = sm, mcmc = mcmc, state = mcmc[["recentState"]])
}

# Read from the StratMCMC object rather than spelled as a literal, so the two
# arms differ in nothing but what `temperingComponents` itself produces.
.ptMask <- function(sm, tc) {
  StratMCMC(sm, nIter = 10L, nChains = 1L,
            temperingComponents = tc)[[c("temper", "mask")]]
}

# Returns the per-block metro trace plus the gradient counter, so a caller can
# assert both that traces agree and that NUTS is what produced them.
.ptNutsTrace <- function(fx, tc, nBlock, temperature = 1) {
  mcmc <- fx[["mcmc"]]
  mcmc[[c("temper", "mask")]] <- .ptMask(fx[["model"]], tc)
  eng <- StratoBayes:::.sb_create_engine(stratData1, fx[["model"]], mcmc,
                                         fx[["state"]])
  StratoBayes:::.sb_update_temperatures(eng, temperature)
  nProp <- mcmc[[c("metro", "nProposals")]][[1L]]
  StratoBayes:::.sb_configure_monitor(eng, nProp)
  set.seed(11L)
  trace <- vector("list", nBlock)
  for (i in seq_len(nBlock)) {
    StratoBayes:::.sb_run_block(eng, 20L)
    trace[[i]] <- StratoBayes:::.sb_extract_metro(eng)
  }
  list(trace = trace,
       nGradient = StratoBayes:::.sb_get_monitor(eng)[["nGradientTransitions"]])
}

test_that("partial tempering is bit-identical to full at T=1 (NUTS proposals)", {
  skip_on_cran()
  fx <- .ptNutsFixture()
  f <- .ptNutsTrace(fx, "full", 10L)
  s <- .ptNutsTrace(fx, "signal", 10L)

  # Both arms must have reached the gradient path at all; without this the
  # identity below holds trivially whenever NUTS is never proposed.
  expect_gt(f[["nGradient"]], 0L)
  expect_gt(s[["nGradient"]], 0L)
  expect_identical(f[["trace"]], s[["trace"]])

  # Away from T=1 the same two masks must part company; an engine that ignored
  # the mask entirely would satisfy the identity above and fail here.
  fHot <- .ptNutsTrace(fx, "full", 3L, temperature = 2)
  sHot <- .ptNutsTrace(fx, "signal", 3L, temperature = 2)
  expect_gt(fHot[["nGradient"]], 0L)
  expect_false(identical(fHot[["trace"]], sHot[["trace"]]))
})

test_that("partial tempering runs multi-chain (tempered) without error", {
  skip_on_cran()
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 200L, nChains = 4L, nThin = 1L, nThreads = 2L,
                  tempering = TRUE, temperingComponents = "signal",
                  adaptProposal = FALSE)
  r <- RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                     visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

test_that("temperingComponents rejects invalid values", {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE)
  expect_error(
    StratMCMC(sm, nIter = 10L, nChains = 2L, temperingComponents = "banana"),
    "should be one of"
  )
})

# RT-303: a continued run rebuilds the StratMCMC object via StratMCMC(), which
# defaults temperingComponents = "full", so .UpdateMCMCforContinuedRun must carry
# the original mask across — otherwise a resumed partial run silently reverts to
# full tempering. Tested at the fix site with real StratMCMC objects
# (adaptProposal = FALSE keeps the history-transfer block inert).
test_that("continued run preserves the tempering mask (RT-303)", {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE)
  mcNew <- StratMCMC(sm, nIter = 100L, nChains = 4L, tempering = TRUE,
                     temperingComponents = "full", adaptProposal = FALSE)
  expect_equal(mcNew[["temper"]][["mask"]], 15L)

  # Every subset must survive the rebuild, including "ties"/"signal+ties" which
  # the retired signalOnly flag could not represent at all.
  expectedMask <- c("signal" = 2L, "ties" = 4L, "signal+ties" = 6L)
  for (tc in names(expectedMask)) {
    # stratData1 has no ties, so the ties-selecting masks warn that they are a
    # no-op; mask carry-over is what is under test here, and it is mask-agnostic.
    mcOld <- suppressWarnings(
      StratMCMC(sm, nIter = 100L, nChains = 4L, tempering = TRUE,
                temperingComponents = tc, adaptProposal = FALSE))
    expect_equal(mcOld[["temper"]][["mask"]], expectedMask[[tc]], label = tc)
    updated <- StratoBayes:::.UpdateMCMCforContinuedRun(mcOld, mcNew,
                                                       newRun = FALSE)
    # 15 (mcNew's default) pre-fix — a silent revert to full tempering.
    expect_equal(updated[["temper"]][["mask"]], expectedMask[[tc]], label = tc)
  }

  # An object carrying no mask must not clobber the rebuilt object's.
  mcNoMask <- mcNew
  mcNoMask[["temper"]][["mask"]] <- NULL
  expect_equal(
    StratoBayes:::.UpdateMCMCforContinuedRun(mcNoMask, mcNew,
                                             newRun = FALSE)[["temper"]][["mask"]],
    15L
  )
})

# RT-304: temperature-ladder adaptation must tune against the SAME energy the
# replica swap uses — the tempered-component sum, surfaced by the ring buffer as
# swapEnergy. Exercises the adaptTemperatures path under a partial mask
# end-to-end (pre-fix R had no access to that energy at all).
test_that("partial tempering adapts the temperature ladder without error (RT-304)", {
  skip_on_cran()
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE,
                   flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 400L, nChains = 4L, nThin = 1L, nThreads = 2L,
                  tempering = TRUE, temperingComponents = "signal",
                  adaptTemperatures = TRUE, adaptProposal = FALSE)
  r <- RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                     visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

# RT-305: temperingComponents must be reachable through RunStratModel (not only by
# hand-building a StratMCMC object). Pre-fix it was neither a formal nor forwarded,
# so this call raised "unused argument".
test_that("RunStratModel exposes and forwards temperingComponents (RT-305)", {
  skip_on_cran()
  expect_true("temperingComponents" %in% names(formals(RunStratModel)))
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE,
                   flexibleKnots = TRUE)
  r <- RunStratModel(stratData1, sm, temperingComponents = "signal",
                     nIter = 200L, nChains = 4L, nThin = 1L, nThreads = 2L,
                     tempering = TRUE, adaptProposal = FALSE,
                     nRun = 1L, runParallel = FALSE, visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

# Component-selective tempering generalises to an arbitrary subset (mask over
# logPostSep = [prior, signal, ties, overlap]). "ties" tempers component [2] only,
# "signal+ties" tempers {1,2}. The T=1 identity is mask-invariant: at a single cold
# chain tempered_energy(sep, 1, mask) = sum(sep) = logPost for EVERY mask, so all
# subsets must give a BIT-IDENTICAL trace to "full".
test_that("all tempering subsets are bit-identical to full at T=1 (MH proposals)", {
  skip_on_cran()
  invisible(.ptRaw("full"))                  # warmup
  f <- .ptRaw("full")
  for (tc in c("signal", "ties", "signal+ties")) {
    x <- .ptRaw(tc)
    expect_equal(dim(f), dim(x))
    expect_identical(as.numeric(f), as.numeric(x),
                     label = paste0("T=1 trace for temperingComponents='", tc, "'"))
  }
})

# That identity is mask-invariant, so no test above can see the mask applied at
# all. At T != 1 it must change the trace: an engine that ignored
# `eng.temperMask` would silently revert every partial run to full tempering --
# the RT-303 failure mode. Verified by neutering the mask in both
# `tempered_energy()` and `masked_component_sum()`: only this test went red,
# every other test in the file stayed green. The mask reaches the trace by
# three routes (both of those, plus `temperPartial`'s ladder-adaptation branch
# in RunStratModel()), so a red here does not say which one broke.
.pt_hot <- function(tc) {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 200L, nChains = 4L, nThin = 1L, nThreads = 1L,
                  tempering = TRUE, temperingComponents = tc,
                  adaptProposal = FALSE)
  RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                visualise = FALSE, seed = 1L, quiet = TRUE)$samples[, , 1, 1]
}

test_that("the mask changes the tempered (T != 1) trace", {
  skip_on_cran()
  invisible(.pt_hot("full"))                   # warmup
  fullA <- .pt_hot("full")
  fullB <- .pt_hot("full")
  # The A/A control is load-bearing: without it "the traces differ" would also
  # be satisfied by run-to-run nondeterminism, and could not fail for the right
  # reason.
  expect_identical(as.numeric(fullA), as.numeric(fullB))
  expect_false(identical(as.numeric(fullA), as.numeric(.pt_hot("signal"))))
})

# Stage A: gradient (HMC/NUTS) component-selective tempering is implemented for
# "signal" only; "ties"/"signal+ties" are MH-only and MUST error (not silently
# temper the wrong component) when a NUTS proposal is registered (flexibleKnots =
# FALSE). "full"/"signal" must still run under NUTS.
test_that("non-signal subsets error under NUTS; full/signal run (Stage A guard)", {
  skip_on_cran()
  runNUTS <- function(tc) {
    sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                     sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                     sigmaFixed = TRUE, flexibleKnots = FALSE)
    # `gradientProposals = "on"` is load-bearing: since #526 fixed knots alone no
    # longer register NUTS, so without it the guard under test never fires.
    mc <- suppressWarnings(
      StratMCMC(sm, nIter = 400L, nChains = 2L, nThreads = 1L, tempering = TRUE,
                temperingComponents = tc, gradientProposals = "on",
                adaptProposal = TRUE))
    RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                  visualise = FALSE, seed = 1L, quiet = TRUE)
  }
  expect_error(runNUTS("ties"), "MH-only")
  expect_error(runNUTS("signal+ties"), "MH-only")
  rSig <- runNUTS("signal")                      # signal gradient path still works
  expect_true(is.finite(summary(rSig)[[1]][["summary"]]["log posterior", "mean"]))
})

# Tempering a component the model does not have divides an identically-zero term
# by T, so the "tempered" ladder samples the cold posterior in every chain and
# accepts every swap -- at nChains times the cost, and undetectably, since the
# ladder's own adaptation sees equal energies and holds still. stratData1 carries
# no ties; stratData2 does.
test_that("a tempering mask selecting an absent component warns (no-op mask)", {
  mkModel <- function(data, priors, scale) {
    StratModel(data, priors = priors, alignmentScale = scale, sedModel = "site",
               nKnots = 10, sigmaFixed = TRUE, flexibleKnots = TRUE)
  }
  noTies <- mkModel(stratData1, stratPrior1, "height")
  withTies <- mkModel(stratData2, stratPrior2, "age")
  expect_true(is.null(noTies[["tiesActive"]]))    # the condition being warned about
  expect_true(any(as.logical(withTies[["tiesActive"]])))

  mc <- function(model, tc, tempering = TRUE, nChains = 4L) {
    StratMCMC(model, nIter = 100L, nChains = nChains, tempering = tempering,
              temperingComponents = tc, adaptProposal = FALSE)
  }
  expect_warning(mc(noTies, "ties"), "no active ties")
  expect_warning(mc(noTies, "signal+ties"), 'equivalent to "signal"')

  # Masks that select a component the model HAS must stay silent.
  expect_no_warning(mc(noTies, "signal"))
  expect_no_warning(mc(noTies, "full"))
  expect_no_warning(mc(withTies, "ties"))
  expect_no_warning(mc(withTies, "signal+ties"))

  # The warning is about a tempered ladder, so it must not fire where there is
  # no ladder to be a no-op on.
  expect_no_warning(mc(noTies, "ties", tempering = FALSE))
  expect_no_warning(mc(noTies, "ties", nChains = 1L))
})

# The premise of that warning -- that the ties component is identically 0 on a
# tie-free model, so dividing it by T changes nothing -- is pinned against the
# engine in test-cpp-engine-guards.R, where the engine helper lives.
