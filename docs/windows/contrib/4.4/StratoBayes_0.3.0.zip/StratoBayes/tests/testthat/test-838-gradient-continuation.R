# RT-657 (#838): `gradientProposals` is deliberately not inherited across a
# continuation, so continuing a `"on"` run without re-specifying it swaps the
# single `NUTS` entry of the proposal registry for `SiteBlock` +
# `NeighbourScaled`. Every per-proposal matrix carried from the previous run is
# then the wrong width, and the run died on
# "proposalProbabilityWeights matrix must have dimensions 2 x 8" -- a message
# that names neither the cause nor the cure.

test_that("#838: a registry-changing continuation is rejected by name", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  td <- file.path(tempdir(), "rt657")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE, showWarnings = FALSE)

  run1 <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 20, nChains = 2, seed = 1, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "rt657", gradientProposals = "on"
  )
  # Discriminator: without a registered NUTS proposal the continuation below
  # changes nothing and the expectation on it is vacuous.
  checkpoint <- readRDS(file.path(td, "rt657_mcmc_run_1.rds"))
  expect_true("NUTS" %in% names(checkpoint[["propose"]]))

  # No `gradientProposals` here, so it resets to "auto" -- which registers no
  # gradient proposal, and the carried 2x7 proposal state cannot describe the
  # resulting 8-proposal registry.
  expect_error(
    suppressWarnings(RunStratModel(run1, nIter = 20, quiet = TRUE,
                                   visualise = FALSE)),
    "gradientProposals"
  )

  # Re-specifying it is the documented cure, and must still work.
  expect_no_error(
    run2 <- RunStratModel(run1, nIter = 20, gradientProposals = "on",
                          quiet = TRUE, visualise = FALSE)
  )
})

test_that("#838: a gradientProposals change that keeps the registry is allowed", {
  Check <- StratoBayes:::.CheckGradientProposalContinuation

  # "auto" and "off" both register no gradient proposal, so the registry is
  # unchanged and the pre-existing warning is enough.
  expect_no_error(
    Check("off", list(list(propose = list(Prior = NULL, Univariate = NULL))))
  )
  expect_error(
    Check("auto", list(list(propose = list(Prior = NULL, NUTS = NULL)))),
    "gradientProposals = \"on\""
  )
  expect_error(
    Check("on", list(list(propose = list(Prior = NULL, SiteBlock = NULL)))),
    "cannot change"
  )
})
