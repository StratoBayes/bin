# Tranche H: #1300 (in-run/post-hoc rHat disagreement), #1301 (three
# convergence-stopping edge cases), #1302 (five validation gaps), #1303 (two
# profiling lifecycle gaps).

# ── #1300: the run's own criteria, not always the live option ───────────────

test_that("#1300: convergenceStop = TRUE's default rHat follows the live option", {
  # Before the fix, `.kConvergenceDefault` was a hard-coded constant: the
  # in-run rule's default ignored `StratoBayes.rHatMax` entirely, so a user
  # who set only the option (never touching `convergenceStop`) got a
  # different answer from the in-run rule than from `burnIn = "auto"`.
  withr::local_options(StratoBayes.rHatMax = 1.5)
  criteria <- .ConvergenceCriteria(TRUE)
  expect_identical(criteria[["rHat"]], 1.5)
  expect_identical(criteria[["ess"]], .kConvergenceDefault[["ess"]])
})

test_that("#1300: a malformed StratoBayes.rHatMax is rejected before sampling, not mid-run", {
  # `.ConvergenceCriteria(TRUE)` now routes the option through the same range
  # check an explicit `convergenceStop = list(rHat = ...)` gets. Before this,
  # a bad option value (unset by any test fixture, so plausible from a user's
  # R profile) reached `.AutoBurnInCore()`'s default unchecked and either
  # errored deep in the sampling loop at the first checkpoint or silently
  # never stopped, rather than failing at the validated call site
  # (`RunStratModel.R:421`) before any sampling starts.
  withr::local_options(StratoBayes.rHatMax = NA_real_)
  expect_error(.ConvergenceCriteria(TRUE), "greater than 1")

  withr::local_options(StratoBayes.rHatMax = 1)
  expect_error(.ConvergenceCriteria(TRUE), "greater than 1")

  withr::local_options(StratoBayes.rHatMax = 1.02)
  expect_identical(.ConvergenceCriteria(TRUE)[["rHat"]], 1.02)
})

test_that("#1300: .AutoBurnIn() defaults to a posterior's own persisted criteria, not the option", {
  sp <- stratPosterior1
  cache <- new.env(parent = emptyenv())
  cache$stamp <- .CacheStamp(.subset2(sp, "samples"), .subset2(sp, "nRun"))
  sp[[".cache"]] <- cache
  # The run stopped (or would have stopped) under a looser criterion than the
  # option now in force -- the #1300 reproduction.
  sp[["mcmcSummary"]][["convergenceCriteria"]] <-
    rep(list(list(rHat = 1.5, ess = NULL)), sp[["nRun"]])

  withr::local_options(StratoBayes.rHatMax = 1.02)
  res <- .AutoBurnIn(sp)
  expect_identical(res[["rHatMax"]], 1.5)
})

test_that("#1300: a posterior with no persisted criteria still falls back to the option", {
  # `stratPosterior1` predates this field, and `convergenceStop = FALSE` runs
  # persist `NULL` -- both must behave exactly as before this fix.
  expect_null(stratPosterior1[[c("mcmcSummary", "convergenceCriteria")]])

  withr::local_options(StratoBayes.rHatMax = 1.23)
  expect_identical(.PersistedRHatMax(stratPosterior1), 1.23)

  sp <- stratPosterior1
  sp[["mcmcSummary"]][["convergenceCriteria"]] <-
    rep(list(NULL), sp[["nRun"]])
  expect_identical(.PersistedRHatMax(sp), 1.23)
})

test_that("#1300: an explicit rHatMax still overrides the persisted default", {
  sp <- stratPosterior1
  sp[["mcmcSummary"]][["convergenceCriteria"]] <-
    rep(list(list(rHat = 1.5, ess = NULL)), sp[["nRun"]])

  res <- .AutoBurnIn(sp, rHatMax = 1.9)
  expect_identical(res[["rHatMax"]], 1.9)
})

test_that("#1300: a run's own persisted criteria reach the object end-to-end", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  withr::local_options(StratoBayes.rHatMax = 1.02)

  post <- RunStratModel(stratData1, stratModel1, nIter = 120, nChains = 4,
                        nRun = 2, seed = 1:2, quiet = TRUE, nThreads = 1L,
                        modelDir = dir, modelName = "ci1300",
                        visualise = FALSE,
                        convergenceStop = list(rHat = 1.5, ess = 1))

  criteria <- post[[c("mcmcSummary", "convergenceCriteria")]]
  expect_length(criteria, 2L)
  expect_identical(criteria[[1L]][["rHat"]], 1.5)
  expect_identical(criteria[[2L]][["rHat"]], 1.5)

  # The persisted 1.5 wins over the still-in-force 1.02 option.
  res <- .AutoBurnIn(post)
  expect_identical(res[["rHatMax"]], 1.5)
})

# ── #1301.1: sequential multi-run stopping gets the same caveat as nRun = 1 ──

test_that("#1301: a sequential multi-run stop also warns about the blind spot", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  # Before the fix this was gated on `nRun == 1L`, so a 2-run *sequential*
  # batch (runParallel default FALSE) got no caveat at all despite being
  # exactly as blind as a single run: convCrossRun is FALSE either way.
  expect_message(
    RunStratModel(stratData1, stratModel1, nIter = 120, nChains = 4, nRun = 2,
                  seed = 1:2, quiet = FALSE, nThreads = 1L, modelDir = dir,
                  modelName = "ci1301a", visualise = FALSE,
                  convergenceStop = list(rHat = 10, ess = 1)),
    "cannot detect disagreement")
})

# ── #1301.3: runParallel = TRUE with nRun = 1 takes the cheap path ───────────

test_that("#1301: runParallel = TRUE with nRun = 1 never round-trips the convergence store", {
  skip_on_cran()
  # nRun = 1 never spawns a `future` worker (dispatch requires nRun > 1), so
  # this exercises the same sequential loop as runParallel = FALSE -- but
  # before the fix, `convCrossRun` read `isParallel` alone and was TRUE here,
  # serialising and reading this run's own store straight back at every
  # checkpoint with no peer to benefit from it.
  dir <- withr::local_tempdir()
  calls <- 0L
  realWrite <- .WriteConvergenceDraws
  testthat::local_mocked_bindings(
    .WriteConvergenceDraws = function(...) {
      calls <<- calls + 1L
      realWrite(...)
    }
  )

  RunStratModel(stratData1, stratModel1, nIter = 120, nChains = 4, nRun = 1,
                seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                modelName = "ci1301b", visualise = FALSE,
                runParallel = TRUE, nCores = 1L,
                convergenceStop = list(rHat = 10, ess = 1))

  expect_identical(calls, 0L)
})

# ── #1301.2: a peer that stopped for good is dropped, not waited on forever ─

# Peer draws are hand-written straight to disk: `.ConvergenceDrawSet()` is a
# pure file-level function, so the stale-peer scenario can be engineered
# directly without a real MCMC run (and without the multisession dispatch
# that #1301.3's cheap path and #1303's Rprof leak are not testable through
# under `load_all()`).
CvPeerMat <- function(iters) {
  matrix(stats::rnorm(length(iters) * 2), length(iters), 2)
}

test_that("#1301: a frozen peer past its overlap is dropped rather than deferred forever", {
  dir <- withr::local_tempdir()

  # Run 3 stopped early (perRunTimeLimit, say) and will never publish again;
  # its retained iterations sit far below where the survivors now are.
  .WriteConvergenceDraws(dir, "m", 3, CvPeerMat(seq(2, 64, 2)),
                         seq(2, 64, 2), endAdapting = 0, final = TRUE)
  # Runs 1 and 2 are still active, and share a healthy overlap with each
  # other -- but not with run 3's frozen, far-earlier range.
  .WriteConvergenceDraws(dir, "m", 1, CvPeerMat(seq(1000, 5000, 100)),
                         seq(1000, 5000, 100), endAdapting = 0, final = FALSE)
  .WriteConvergenceDraws(dir, "m", 2, CvPeerMat(seq(1000, 5000, 50)),
                         seq(1000, 5000, 50), endAdapting = 0, final = FALSE)

  result <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 3, crossRun = TRUE)

  expect_false(is.null(result))
  expect_length(result[["drawList"]], 2L)
  expect_gte(nrow(result[["drawList"]][[1L]]), .kAutoBurnInMinRows)
})

test_that("#1301: without a final peer, a starved intersection still defers", {
  # Same disjoint ranges, but nothing is marked final -- dropping a peer here
  # would be wrong, since for all this function knows run 3 is still running
  # and might yet publish overlapping iterations.
  dir <- withr::local_tempdir()
  .WriteConvergenceDraws(dir, "m", 3, CvPeerMat(seq(2, 64, 2)),
                         seq(2, 64, 2), endAdapting = 0, final = FALSE)
  .WriteConvergenceDraws(dir, "m", 1, CvPeerMat(seq(1000, 5000, 100)),
                         seq(1000, 5000, 100), endAdapting = 0, final = FALSE)
  .WriteConvergenceDraws(dir, "m", 2, CvPeerMat(seq(1000, 5000, 50)),
                         seq(1000, 5000, 50), endAdapting = 0, final = FALSE)

  expect_null(.ConvergenceDrawSet(dir, "m", run = 1, nRun = 3, crossRun = TRUE))
})

test_that("#1301: dropping final peers never leaves fewer than two runs", {
  # Two of the three runs are frozen; only one active run is left, which must
  # never be silently treated as a solo diagnostic.
  dir <- withr::local_tempdir()
  .WriteConvergenceDraws(dir, "m", 2, CvPeerMat(seq(2, 64, 2)),
                         seq(2, 64, 2), endAdapting = 0, final = TRUE)
  .WriteConvergenceDraws(dir, "m", 3, CvPeerMat(seq(4, 68, 2)),
                         seq(4, 68, 2), endAdapting = 0, final = TRUE)
  .WriteConvergenceDraws(dir, "m", 1, CvPeerMat(seq(1000, 5000, 100)),
                         seq(1000, 5000, 100), endAdapting = 0, final = FALSE)

  expect_null(.ConvergenceDrawSet(dir, "m", run = 1, nRun = 3, crossRun = TRUE))
})

test_that("#1301: .WriteConvergenceDraws() round-trips the final flag", {
  dir <- withr::local_tempdir()
  .WriteConvergenceDraws(dir, "m", 1, CvPeerMat(1:10), 1:10, endAdapting = 0,
                         final = TRUE)
  saved <- readRDS(.ConvergenceDrawsPath(dir, "m", 1))
  expect_true(saved[["final"]])
})

# ── #1302.2: NaN/NA top rung is rejected, not silently admitted ─────────────

test_that("#1302: a NaN top rung is rejected, not silently admitted", {
  temps <- c(1, 2, 4, NaN)
  expect_error(.TemperatureLadder(temps, nChains = 4L), "top rung")
})

test_that("#1302: an NA top rung is rejected too", {
  temps <- c(1, 2, 4, NA_real_)
  expect_error(.TemperatureLadder(temps, nChains = 4L), "top rung")
})

test_that("#1302: a finite or Inf top rung is still accepted", {
  expect_identical(.TemperatureLadder(c(1, 2, 4, 8), nChains = 4L), c(1, 2, 4, 8))
  expect_identical(.TemperatureLadder(c(1, 2, 4, Inf), nChains = 4L),
                   c(1, 2, 4, Inf))
})

# ── #1302.4: duplicate convergenceStop names are rejected ───────────────────

test_that("#1302: duplicate names in convergenceStop are rejected, not resolved to the first", {
  expect_error(.ConvergenceCriteria(list(rHat = 1.05, rHat = 1.02)),
              "unique")
})

# ── #1302.5: a failed sentinel write warns instead of failing silently ──────

test_that("#1302: a failed stop-sentinel write warns", {
  # A path under a directory that does not exist can never be created.
  dir <- file.path(withr::local_tempdir(), "does-not-exist")
  expect_warning(.WriteStopSentinel(dir, "m"), "sentinel")
})

test_that("#1302: a successful sentinel write stays silent", {
  dir <- withr::local_tempdir()
  expect_silent(.WriteStopSentinel(dir, "m"))
  expect_true(.StopSentinelExists(dir, "m"))
})

# ── #1303.1: Rprof stops even when a parallel worker errors ─────────────────

test_that("#1303: an erroring parallel run stops Rprof rather than leaking it", {
  skip_on_cran()
  # A real `future` multisession worker loads the *installed* package, not
  # this `load_all()`-loaded source tree (see project memory: parallel runs
  # are untestable under `load_all()`), so the dispatch is flattened to a
  # synchronous in-process `lapply()` -- this still exercises the exact
  # `tryCatch()`/`on.exit()`-guarded closure the fix lives in, just without a
  # second process.
  testthat::local_mocked_bindings(plan = function(...) invisible(NULL),
                                  .package = "future")
  testthat::local_mocked_bindings(
    future_lapply = function(X, FUN, ...) lapply(X, FUN),
    .package = "future.apply"
  )
  testthat::local_mocked_bindings(.InnerRunMCMC = function(...) stop("boom"))
  withr::defer(utils::Rprof(NULL))

  dir <- withr::local_tempdir()
  expect_error(
    RunStratModel(stratData1, stratModel1, nIter = 120, nChains = 4, nRun = 2,
                  seed = 1:2, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "ci1303", visualise = FALSE,
                  runParallel = TRUE, nCores = 1L, profile = TRUE),
    "boom"
  )

  # Before the fix, the profiler kept sampling into run 1's dead file after
  # the error -- so further CPU-bound work in *this* process kept growing it.
  # After the fix, `on.exit(Rprof(NULL))` closed the file before the error
  # left the worker closure, so it is inert.
  profileFile <- file.path(dir, "ci1303_Rprof_run1.out")
  expect_true(file.exists(profileFile))
  before <- file.size(profileFile)
  x <- 0
  for (i in seq_len(5e7)) x <- x + i
  after <- file.size(profileFile)
  expect_identical(before, after)
})

# ── #1303.2: a missing profile gives a message that names the fix ───────────

test_that("#1303: .SummariseProfiles() on an un-profiled run names the fix, not a raw I/O error", {
  dir <- withr::local_tempdir()
  expect_error(
    .SummariseProfiles(modelDir = dir, modelName = "noprofile", nRun = 1),
    "profile = TRUE")
})

test_that("#1303: .SummariseProfiles() still reads a real profile", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  profilePath <- file.path(dir, "real_Rprof_run1.out")
  utils::Rprof(profilePath)
  # Spin for a fixed time: a fixed loop can finish inside one 20 ms sampling
  # interval on a fast machine, leaving an empty profile.
  x <- 0
  until <- Sys.time() + 0.25
  while (Sys.time() < until) x <- x + 1
  utils::Rprof(NULL)

  result <- .SummariseProfiles(modelDir = dir, modelName = "real", nRun = 1)
  expect_true(is.data.frame(result))
})
