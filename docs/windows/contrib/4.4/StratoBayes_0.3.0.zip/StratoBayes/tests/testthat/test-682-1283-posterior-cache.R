# Regression tests for area-10 posterior-cache and accessor hygiene:
# #689, #1281, #682, #683, #687, #1283 (items 1 and 4).
#
# #1283 item 3 (the dead `if (!is.null(cache))` guard in `[[.StratPosterior`)
# is also fixed in this diff but has no test of its own: `cache` is
# unconditionally non-NULL by that point, so the removed branch was
# unreachable and the change has no observable behaviour to pin -- covered
# incidentally by every `#689`/`#1281` test that exercises `[[.StratPosterior`.
#
# #1282 and #1283 (item 2) are Refs-only in this tranche (see PR body) and
# have no tests here: #1282's described shortfall is provably unreachable by
# the current `.maxSampleDeterministicRows()` remainder algorithm (a zero-row
# run always ranks strictly last, and the remainder can never reach that far
# down the list -- verified by proof and by 2M-trial fuzzing), and #1283
# item 2's dead condition sits inside a block PR #1447 already rewrites.
#
# Cache tests need a `StratPosterior` whose cache they can drive from empty and
# whose run directory they can reload from, so `#689`/`#1281` build their own
# small fixture via `RunStratModel()` (`.PosteriorFixtureRun()`, from
# helper-posterior-fixtures.R), reused across both tests. stratPosterior1 is
# used below only for the cache-independent accessor tests.

.D2CacheFixtureDir <- .PosteriorFixtureRun(1, 68210)

.D2FreshPosterior <- function() {
  suppressMessages(StratPosterior(readDir = .D2CacheFixtureDir))
}

test_that("#689: the cache stamp carries no digest of the whole array", {
  samples <- array(seq_len(8), dim = c(2, 2, 2, 1))
  stamp <- .CacheStamp(samples, nRun = 1)
  expect_false("checksum" %in% names(stamp))
  # #1443: extended with a `clusterInputs` fingerprint of model/data.
  # #1992: and with one accumulation over the array, which is what #689 left
  # out and a 32-point probe cannot replace.
  expect_setequal(names(stamp),
                   c("dim", "dimnames", "length", "nRun", "probe", "total",
                     "clusterInputs", "mcmcSummary"))
  expect_identical(stamp[["total"]], sum(samples))
})

test_that("#1992: an edit between probe points invalidates the stamp", {
  sp <- .D2FreshPosterior()
  expect_false(is.null(.PosteriorCache(sp)))

  # Deliberately not a probed position: the probe samples 32 points spread
  # evenly through the array, so an index just past the first of them is
  # invisible to every stamp field except the total.
  samples <- .subset2(sp, "samples")
  probed <- unique(as.integer(seq.int(1, length(samples),
                                      length.out = min(length(samples), 32L))))
  unprobed <- setdiff(seq_along(samples), probed)[[2]]

  spEdited <- sp
  spEdited$samples[unprobed] <- spEdited$samples[unprobed] + 1
  expect_identical(.PosteriorStamp(spEdited)[["probe"]],
                   .PosteriorStamp(sp)[["probe"]])
  expect_null(.PosteriorCache(spEdited))

  # The parent keeps a usable cache, and the edited copy cannot write into it.
  invisible(suppressMessages(spEdited[["summary"]]))
  expect_null(.PosteriorCache(sp)$summary)
})

test_that("#1992: one edited data value invalidates the stamp", {
  # `data` is what clustering reads, and it used to be fingerprinted by
  # `unlist()`ing the whole dataset and keeping 32 values -- so an edit to any
  # other row was invisible, and a mutated copy both read and overwrote the
  # parent's memoised clustering.
  sp <- .D2FreshPosterior()
  expect_false(is.null(.PosteriorCache(sp)))

  spEdited <- sp
  lastRow <- nrow(spEdited$data$signal)
  spEdited$data$signal$value[lastRow] <- spEdited$data$signal$value[lastRow] + 1
  expect_null(.PosteriorCache(spEdited))

  # A site renamed in one row only: a character edit, equally invisible to a
  # probe of 32 values.
  spRenamed <- sp
  sites <- spRenamed$data$signal$site
  other <- setdiff(unique(sites), sites[[lastRow]])
  skip_if(length(other) == 0, "fixture has a single site")
  spRenamed$data$signal$site[lastRow] <- other[[1]]
  expect_null(.PosteriorCache(spRenamed))

  # An untouched copy must still hit: the whole-held fields have to compare
  # equal across the `.StripKeyAttr()` copy they are stamped through.
  expect_false(is.null(.PosteriorCache(sp)))
})

test_that("#689: cache validity still catches a genuine content change", {
  sp <- .D2FreshPosterior()
  expect_false(is.null(.PosteriorCache(sp)))

  # A value change at one of the 32 probed positions (position 1, always
  # probed) must still invalidate the cache without the checksum.
  spChanged <- sp
  spChanged$samples[1, 1, 1, 1] <- spChanged$samples[1, 1, 1, 1] + 1e6
  expect_null(.PosteriorCache(spChanged))

  # A value change at a position the stamp does NOT probe must invalidate too.
  # The 32-position probe alone cannot see this; `total = sum(samples)` can
  # (#1992). Against the pre-#1992 stamp this edit left the cache valid, so the
  # assertion discriminates -- which `spSame <- sp` (an unmodified copy) could
  # not.
  n <- length(sp[["samples"]])
  # Must track `.CacheStamp()`'s own probe rule, or `unprobed` quietly stops
  # being unprobed and this stops testing the checksum at all.
  probed <- unique(as.integer(seq.int(1, n, length.out = min(n, 32L))))
  unprobed <- setdiff(seq_len(n), probed)
  expect_gt(length(unprobed), 0)
  spSame <- sp
  spSame$samples[unprobed[[1]]] <- spSame$samples[unprobed[[1]]] + 1e6
  # An NA at that position would make the write a no-op -- the same collapse.
  expect_false(identical(spSame[["samples"]], sp[["samples"]]))
  expect_null(.PosteriorCache(spSame))

  # Valid is not enough: a cache that IS valid must still be *served*, not
  # recomputed. Sentinel, as in the #1281 test below. The unedited posterior is
  # the right vehicle now that any edit invalidates.
  freshCache <- .PosteriorCache(sp)
  expect_false(is.null(freshCache))
  suppressMessages(summary(sp))
  freshCache$summary[[c("general", "nRun")]] <- -99L
  expect_identical(suppressMessages(summary(sp))[[c("general", "nRun")]], -99L)
})

test_that("#1281: summary.StratPosterior() writes its result into the cache", {
  sp <- .D2FreshPosterior()
  cache <- .PosteriorCache(sp)
  expect_false(is.null(cache))
  expect_null(cache$summary)

  s1 <- suppressMessages(summary(sp))
  expect_false(is.null(cache$summary))
  expect_identical(cache$summary, s1)
})

test_that("#1281: a cached default summary() is served without recomputation", {
  sp <- .D2FreshPosterior()
  suppressMessages(summary(sp))
  cache <- .PosteriorCache(sp)

  # Sentinel: poke an implausible value into the memoised summary. A second
  # default call that actually recomputes would overwrite it with the real
  # (non-sentinel) figure; a call served from cache returns the sentinel.
  cache$summary[[c("general", "nRun")]] <- -99L
  s2 <- suppressMessages(summary(sp))
  expect_identical(s2[[c("general", "nRun")]], -99L)
})

test_that("#1281: a non-default summary() call does not overwrite the cached default", {
  sp <- .D2FreshPosterior()
  s1 <- suppressMessages(summary(sp))
  cache <- .PosteriorCache(sp)
  expect_identical(cache$summary, s1)

  # runs = 1 is non-default; must not clobber the memoised default summary.
  suppressWarnings(suppressMessages(summary(sp, runs = 1)))
  expect_identical(cache$summary, s1)
})

test_that("#682: .RoundToSigDigits() keeps the full digit count just below a power of ten", {
  df <- data.frame(x = c(9.5, 9.123456789, 99.5, 5, 0.5, 1.5))
  out <- .RoundToSigDigits(df, sigDigits = 6)
  # Pre-fix these overshoot and lose one significant digit: "9.5000" (5 sig
  # figs), "9.1235" (5), "99.500" (5).
  expect_identical(out$x[1], "9.50000")
  expect_identical(out$x[2], "9.12346")
  expect_identical(out$x[3], "99.5000")
  # Unaffected values (already correct pre-fix) stay correct.
  expect_identical(out$x[4], "5.00000")
  # #1508: the leading zero after the point used to eat one of the six digits.
  expect_identical(out$x[5], "0.500000")
  expect_identical(out$x[6], "1.50000")
})

test_that("#683: $.StratPosterior partial-matches an unambiguous field name", {
  expect_false(is.null(stratPosterior1$savedPar))
  expect_identical(stratPosterior1$savedPar, stratPosterior1$savedParameters)
  expect_identical(stratPosterior1$savedPar, unclass(stratPosterior1)$savedPar)
})

test_that("#683: $.StratPosterior returns NULL for an ambiguous partial match", {
  # "model" is a real, exactly-named element; "mode" ambiguously prefixes
  # both "modelDir" and "modelName", so ordinary list `$` semantics (and
  # unclass(.)$mode) return NULL rather than guessing.
  expect_null(unclass(stratPosterior1)$mode)
  expect_null(stratPosterior1$mode)
})

test_that("#683: $.StratPosterior still exact-matches ordinary fields", {
  expect_identical(stratPosterior1$nRun, stratPosterior1[["nRun"]])
})

test_that("#687: divergence-location colnames guard fires on a mismatched matrix width", {
  m <- matrix(1:12, nrow = 3, ncol = 4)  # 4 cols, but 5 expected for 2 param names
  expect_error(
    .AssembleDivergenceLocations(m, run = 1, divParamNames = c("alpha", "beta")),
    "column"
  )
})

test_that("#687: divergence-location assembly succeeds when the width matches", {
  m <- matrix(as.numeric(1:15), nrow = 3, ncol = 5)
  out <- .AssembleDivergenceLocations(m, run = 2, divParamNames = c("alpha", "beta"))
  expect_identical(colnames(out), c("run", "rung", "treeDepth", "deltaH", "alpha", "beta"))
  expect_identical(nrow(out), 3L)
})

test_that("#1283 (1/4): .AutoBurnInDraws() rejects a per-run row/samples mismatch", {
  # Sibling to "a posterior whose samples and mcmcSummary disagree errors
  # clearly" in test-auto-burnin-posterior.R, which drops a whole RUN (3rd
  # dim) -- the existing guard's own case. This drops a ROW (1st dim)
  # instead, which that guard (run-count only) lets through.
  badSp <- stratPosterior1
  badSp$samples <- badSp$samples[1, , , , drop = FALSE]
  expect_error(.AutoBurnInDraws(badSp), "saved row")
})

test_that("#1283 (4/4): print.StratPosterior() uses plain \\n, matching print.summary.StratPosterior()", {
  printed <- paste(capture.output(print(stratPosterior1)), collapse = "\n")
  expect_false(grepl("\r", printed, fixed = TRUE))
})

test_that(".StampMatches() forgives summation rounding in `total`, not edits", {
  samples <- .subset2(stratPosterior1, "samples")
  nRun <- .subset2(stratPosterior1, "nRun")
  stamp <- .CacheStamp(samples, nRun)
  expect_true(.StampMatches(stamp, samples, nRun))

  # A total computed without extended precision, as on Apple Silicon.
  rounded <- stamp
  rounded[["total"]] <- stamp[["total"]] * (1 + 4 * .Machine$double.eps)
  expect_false(identical(rounded, stamp))
  expect_true(.StampMatches(rounded, samples, nRun))

  edited <- samples
  n <- length(samples)
  probed <- unique(as.integer(seq.int(1, n, length.out = min(n, 32L))))
  unprobed <- setdiff(seq_len(n), probed)[[1]]
  edited[unprobed] <- edited[unprobed] + 1
  expect_false(.StampMatches(stamp, edited, nRun))
})
