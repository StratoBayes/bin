# #1194: `.AdaptMassMatrix` raises the one-shot restart flags in TWO places --
# the `.hmcDA` environment (read by the R engine) and the `proposalArgs` list
# slots (read by the C++ engine's extract_hmc_args). The block that lowers the
# list slots again ran only under `engine = "cpp"`, so an R-engine run left them
# latched TRUE. `.UpdateMCMCforContinuedRun` carries `proposalArgs` verbatim, so
# continuing such a run under `engine = "cpp"` made the C++ side see
# `needsEpsInit && adaptStepSize` and re-run the initial step-size search,
# discarding the step size it had just resumed.

test_that("an R-engine run does not latch the restart flags (#1194)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("latch1194_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  # `.AdaptMassMatrix` must actually fire, or the flags are never raised and
  # the assertion below is vacuous. It runs at every mass-matrix update, so
  # capture whether at least one happened.
  massUpdates <- 0L
  realAdapt <- StratoBayes:::.AdaptMassMatrix
  testthat::local_mocked_bindings(
    .AdaptMassMatrix = function(...) {
      massUpdates <<- massUpdates + 1L
      realAdapt(...)
    },
    .package = "StratoBayes"
  )

  RunStratModel(
    gradientProposals = "on", stratObject = stratData1, stratModel = model,
    nIter = 400, nChains = 2, seed = 8327, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "latch1194", engine = "R", nCores = 1L
  )
  expect_gt(massUpdates, 0L)

  # The saved `mcmc` is exactly what a continuation reads back, so this is the
  # object whose latched flags would reach a `engine = "cpp"` continuation.
  mcmc <- readRDS(file.path(td, "latch1194_mcmc_run_1.rds"))
  args <- mcmc[[c("metro", "proposalArgs")]]
  gradProp <- which(names(mcmc[["propose"]]) %in% c("HMC", "NUTS"))
  expect_length(gradProp, 1L)

  for (ch in seq_along(args)) {
    ha <- args[[ch]][[gradProp]]
    if (is.null(ha)) next
    # PRE-FIX both of these were TRUE for every chain: nothing under
    # `engine = "R"` ever lowered them again.
    expect_false(isTRUE(ha[["restartDualAvg"]]))
    expect_false(isTRUE(ha[[".needsEpsInit"]]))
    # The R engine's own restart path reads the ENV copy, which the fix must
    # not touch: it is cleared by `.UpdateStateNUTS` when it is consumed.
    expect_true(is.environment(ha[[".hmcDA"]]))
  }
})
