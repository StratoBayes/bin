# Ingestion-time validation gaps: #1366, #1368, #1369, #1371.

# A non-native density, resolved by match.fun() from the package namespace, so
# it has to live in globalenv() (as in test-ties-parallel-dispatch.R). `upper`
# is a truncation bound: Inf is the untruncated limit, and legitimate.
assign(".sb1366TruncExp",
       eval(quote(function(x, rate, upper, log = FALSE) {
         d <- stats::dexp(x, rate) / stats::pexp(upper, rate)
         d[x > upper] <- 0
         if (log) base::log(d) else d
       }), envir = globalenv()),
       envir = globalenv())
withr::defer(suppressWarnings(rm(".sb1366TruncExp", envir = globalenv())),
             testthat::teardown_env())

test_that(".CheckTies() rejects non-finite native density arguments (#1366)", {

  # An infinite scale makes the C++ tie density -Inf, which the engine clamps
  # to -1e30 -- a sentinel large enough to swallow logPrior + logLikSignal, so
  # the posterior goes constant, every proposal is accepted, and the run
  # completes silently as a random walk with no target.
  tiesInfSd <- data.frame(height = 1, site = "A",
                          densityFun = "dnorm", arg1 = 50, arg2 = Inf)
  expect_error(.CheckTies(tiesInfSd, "height", "site"),
               "'dnorm' density's 'sd' \\(arg2\\) must be finite")

  # The mean/sd row shape is rewritten to densityFun/arg1/arg2 before the guard.
  tiesMeanSdInf <- data.frame(height = 1, site = "A", mean = 0, sd = Inf)
  expect_error(.CheckTies(tiesMeanSdInf, "height", "site"),
               "'dnorm' density's 'sd' \\(arg2\\) must be finite")

  # 'mean' is not a positive-domain argument, so only a finiteness test catches
  # it, though z = -Inf gives the identical -Inf log-density.
  tiesInfMean <- data.frame(height = 1, site = "A",
                            densityFun = "dnorm", arg1 = Inf, arg2 = 1)
  expect_error(.CheckTies(tiesInfMean, "height", "site"),
               "'dnorm' density's 'mean' \\(arg1\\) must be finite")

  tiesNegInfMean <- data.frame(height = 1, site = "A", mean = -Inf, sd = 1)
  expect_error(.CheckTies(tiesNegInfMean, "height", "site"),
               "'dnorm' density's 'mean' \\(arg1\\) must be finite")

  # The existing max > min relation check cannot see this: Inf > -Inf is TRUE.
  tiesUnifInf <- data.frame(height = 1, site = "A",
                            densityFun = "dunif", arg1 = -Inf, arg2 = Inf)
  expect_error(.CheckTies(tiesUnifInf, "height", "site"),
               "'dunif' density's 'min' \\(arg1\\) must be finite")

  tiesUnifInfMax <- data.frame(height = 1, site = "A",
                               densityFun = "dunif", arg1 = 0, arg2 = Inf)
  expect_error(.CheckTies(tiesUnifInfMax, "height", "site"),
               "'dunif' density's 'max' \\(arg2\\) must be finite")

  # Controls: finite arguments, including a negative location and a range
  # spanning zero, stay silent.
  tiesNegMean <- data.frame(height = 1, site = "A", mean = -100, sd = 0.1)
  expect_silent(.CheckTies(tiesNegMean, "height", "site"))

  tiesSpanZero <- data.frame(height = 1, site = "A", densityFun = "dunif",
                             arg1 = -10, arg2 = 10)
  expect_silent(.CheckTies(tiesSpanZero, "height", "site"))
})

test_that(".CheckTies() still admits an infinite bound on a custom density", {

  # The -1e30 clamp is a property of the engine's own density branches. A
  # densityFun it does not recognise is evaluated by R callback, where an
  # infinite truncation bound gives a finite log-density, so the guard must
  # not reach it.
  tiesCustom <- data.frame(height = 1, site = "A",
                           densityFun = ".sb1366TruncExp",
                           arg1 = 1, arg2 = Inf)
  expect_silent(.CheckTies(tiesCustom, "height", "site"))

  # The positive-domain guard is scoped by argument name, not density name, so
  # it must still fire on a custom density's `rate`.
  tiesCustomBadRate <- data.frame(height = 1, site = "A",
                                  densityFun = ".sb1366TruncExp",
                                  arg1 = 0, arg2 = 10)
  expect_error(.CheckTies(tiesCustomBadRate, "height", "site"),
               "'rate' \\(arg1\\) must be > 0")
})

test_that("StratData() rejects non-finite z-coordinates (#1368)", {

  signal <- data.frame(
    site = c("s1", "s1", "s2", "s2"),
    height = c(0, 10, 0, 10),
    value = c(1, 2, 3, 4)
  )

  # -Inf propagates into the synthesized partition's BoundLow, surfacing much
  # later as "'mean' must not be NA."
  signalNegInf <- signal
  signalNegInf[["height"]][3] <- -Inf
  expect_error(StratData(signalNegInf),
               "`height` contains infinite values \\(row 3\\)")

  # +Inf makes the synthesized partition maximum Inf, so the later "heights
  # greater than the maximum height in `parts`" guard compares Inf > Inf and
  # does not fire either.
  signalPosInf <- signal
  signalPosInf[["height"]][2] <- Inf
  expect_error(StratData(signalPosInf),
               "`height` contains infinite values \\(row 2\\)")

  # Row numbers are those of the supplied data frame, not of what survives the
  # NA cull.
  signalWithNa <- rbind(data.frame(site = "s1", height = NA, value = 9), signal)
  signalWithNa[["height"]][3] <- Inf
  expect_error(suppressWarnings(StratData(signalWithNa)),
               "`height` contains infinite values \\(row 3\\)")

  # Many bad rows: plural, and truncated after five.
  signalManyInf <- signal[rep(seq_len(4), 2), ]
  signalManyInf[["height"]][1:6] <- Inf
  expect_error(
    StratData(signalManyInf),
    "`height` contains infinite values \\(rows 1, 2, 3, 4, 5, \\.\\.\\.\\)"
  )

  # A user-named z column is reported under its own name.
  signalX <- signal
  names(signalX)[2] <- "x"
  signalX[["x"]][4] <- Inf
  expect_error(StratData(signalX, zColumn = "x"),
               "`x` contains infinite values \\(row 4\\)")

  # `ties` and `parts` heights reach the same synthesized partition bound, so
  # they need the same guard; their errors name the frame the rows belong to.
  ties <- data.frame(site = "s1", height = Inf, mean = 5, sd = 1)
  expect_error(StratData(signal, ties = ties),
               "ties: `height` contains infinite values \\(row 1\\)")

  parts <- data.frame(site = c("s1", "s2"), height = c(Inf, 10),
                      partition = c(1, 1))
  expect_error(StratData(signal, parts = parts),
               "parts: `height` contains infinite values \\(row 1\\)")

  expect_s3_class(StratData(signal), "StratData")
})

# A LAS file whose header declares a NULL sentinel colliding with a real depth.
.WriteCollidingNullLas <- function(path) {
  writeLines(c(
    "~Version Information",
    "VERS.                      2.0: CWLS Log ASCII Standard - VERSION 2.0",
    "WRAP.                       NO: One line per depth step",
    "~Well Information Block",
    "STRT.FT                 0.0000: ",
    "STOP.FT                 4.0000: ",
    "STEP.FT                 1.0000: ",
    "NULL.                   0.0000: ",
    "COMP.          TEST: COMPANY",
    "WELL.          TEST WELL: WELL",
    "FLD.           TEST: FIELD",
    "LOC.           TEST: LOCATION",
    "CNTY.          TEST: COUNTY",
    "SRVC.          TEST: SERVICE COMPANY",
    "DATE.          2026: LOG DATE",
    "UWI.           TEST: UNIQUE WELL ID",
    "STAT.          TEST: STATE",
    "~Curve Information Block",
    "DEPT.FT            0 000 00 00: Depth",
    "GR.GAPI                       : Gamma Ray",
    "~A  Depth          GR",
    "     0.0000      0.0000",
    "     1.0000     10.0000",
    "     2.0000      0.0000",
    "     3.0000     30.0000",
    "     4.0000     40.0000"
  ), path)
}

test_that("ReadLasFiles() never nulls the depth/index curve (#1369)", {
  skip_if_not_installed("SDAR")

  tmpFolder <- withr::local_tempdir()
  .WriteCollidingNullLas(file.path(tmpFolder, "collide.las"))

  msgs <- testthat::capture_messages(
    result <- ReadLasFiles(tmpFolder, fileNames = "collide.las")
  )
  df <- result[["collide"]]

  # Pre-fix: the top-of-hole depth 0 matched the sentinel and became NA.
  expect_equal(df[[1L]], c(0, 1, 2, 3, 4))

  # Genuine readings equal to the sentinel are still replaced, on the colliding
  # row as well as elsewhere.
  expect_equal(df[["GR"]], c(NA, 10, NA, 30, 40))

  # The reported count must not keep counting the depth column.
  expect_match(paste(msgs, collapse = ""), "\\(2 values\\)")
})

test_that("ReadLasFiles() rejects NA and empty fileNames (#1371)", {
  skip_if_not_installed("SDAR")

  lasFolder <- testthat::test_path("testdata", "test-LAS")

  # Pre-fix: grepl() on NA_character_ returns FALSE, so paste0(NA, ".las")
  # reported a nonexistent "NA.las" -- a name the user never gave, and one a
  # folder could genuinely contain.
  expect_error(ReadLasFiles(lasFolder, fileNames = NA_character_),
               "fileNames must not contain NA or empty entries")
  expect_error(ReadLasFiles(lasFolder, fileNames = ""),
               "fileNames must not contain NA or empty entries")
  expect_error(ReadLasFiles(lasFolder, fileNames = "   "),
               "fileNames must not contain NA or empty entries")
  expect_error(
    ReadLasFiles(lasFolder,
                 fileNames = c("0500106234_2769043.las", NA_character_)),
    "fileNames must not contain NA or empty entries"
  )
})
