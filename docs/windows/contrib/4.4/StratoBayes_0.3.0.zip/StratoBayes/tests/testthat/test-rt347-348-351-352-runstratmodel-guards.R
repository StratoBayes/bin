# Targeted regression tests for RT-347, RT-348, RT-351, RT-352
# (see dev/red-team/findings.md for full detail/repro of each).

test_that("RT-347: completedIter uses the true iteration label, not a row
          count, when reconstructing continuation from a StratPosterior
          object with nThin > 1", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 9,
                      nChains = 2, nThreads = 0L, nThin = 3, visualise = FALSE,
                      seed = 1, runParallel = FALSE, quiet = TRUE)

  # nThin = 3 over 9 iterations saves rows {1,3,6,9} -- a row count (4)
  # diverges sharply from the true last iteration label (9).
  expect_equal(r1[["mcmcSummary"]][["saveIter"]][[1]], c(1, 3, 6, 9))

  # Delete the bulky per-run samples .txt (keeping only the in-memory
  # StratPosterior object) to force the "reconstruct from stratObject"
  # continuation path at RunStratModel.R:472-502.
  txtFile <- list.files(
    r1[["modelDir"]],
    pattern = paste0("^", r1[["modelName"]], "_samples_run_1\\.txt$"),
    full.names = TRUE
  )
  expect_length(txtFile, 1)
  file.remove(txtFile)

  r2 <- RunStratModel(r1, nIter = 3, visualise = FALSE, quiet = TRUE)

  # Before the fix, completedIter[1] was the row count (4) rather than the
  # true last iteration label (9): the sibling `.CompleteSampleRows` path's
  # <= completedIter filter then drops the real iterations 6 and 9 from
  # saveIter, and new draws get mislabelled starting at iteration 5 instead
  # of 10 -- corrupting/duplicating the resumed run's iteration labels
  # (observed: c(1, 3, 4, 5, 6, 7)). The fix preserves the true history and
  # continues cleanly from iteration 9.
  #
  # An unspecified `nThin` on a continuation now inherits the checkpoint's 3
  # rather than resetting to the default 1, so the one new row is iteration 12.
  # What this test discriminates is unchanged: the preserved c(1, 3, 6, 9) prefix
  # and a tail counted from label 9 rather than from the row count 4.
  expect_equal(unname(r2[["mcmcSummary"]][["nThin"]])[[1]], 3)
  expect_equal(r2[["mcmcSummary"]][["saveIter"]][[1]], c(1, 3, 6, 9, 12))
})

test_that("RT-348: RunStratModel's parallel-run worker closure re-pins BLAS
          threads inside the future worker process, not only in the parent", {
  # RhpcBLASctl::blas_set_num_threads() (called by .PinBlasThreads()) is an
  # in-process runtime call that cannot reach a separately spawned
  # future.apply worker. Confirm the call site exists inside the worker
  # closure (not just once in the parent, RunStratModel.R:~740) by counting
  # occurrences in the function body -- one in the parent before the
  # parallel/sequential branch, and one inside the future_lapply worker.
  deparsed <- deparse(body(RunStratModel))
  pinCalls <- grep("\\.PinBlasThreads\\(\\)", deparsed, fixed = FALSE)
  expect_gte(length(pinCalls), 2)
})

test_that("RT-348: .PinBlasThreads() actually pins BLAS to a single thread
          when invoked inside a spawned future worker", {
  skip_if_not_installed("future.apply")
  skip_if_not_installed("RhpcBLASctl")
  skip_if(RhpcBLASctl::blas_get_num_procs() <= 1L,
          "BLAS is already single-threaded on this machine")

  oldPlan <- future::plan(future::multisession, workers = 1L)
  on.exit(future::plan(oldPlan), add = TRUE)

  workerThreadsAfterPin <- future.apply::future_lapply(
    1,
    function(i) {
      StratoBayes:::.PinBlasThreads()
      RhpcBLASctl::blas_get_num_procs()
    },
    future.packages = "StratoBayes"
  )[[1]]

  expect_equal(workerThreadsAfterPin, 1L)
})

test_that("RT-351: silently overriding a diverged-run's supplied nThin now
          warns", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 6,
                      nChains = 2, nThreads = 0L, nThin = 1, visualise = FALSE,
                      seed = 1:2, runParallel = FALSE, saveMCMC = TRUE,
                      quiet = TRUE)

  # Truncate run 2's binary sample checkpoint so its completed-iteration
  # count genuinely diverges from run 1's on continuation (simulates one
  # run finishing fewer iterations than another, e.g. via `timeLimit`).
  rdsFile2 <- file.path(r1[["modelDir"]],
                        paste0(r1[["modelName"]], "_binarysamples_run_2.rds"))
  expect_true(file.exists(rdsFile2))
  d2 <- as.data.frame(readRDS(rdsFile2))
  saveRDS(d2[d2[["iteration"]] <= 3, ], rdsFile2)

  expect_warning(
    r2 <- RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                        nIter = 2, nThin = 3, visualise = FALSE, quiet = TRUE),
    "diverged in completed iterations"
  )

  # the override itself is unchanged: nThin is still forced back to the
  # runs' existing value (1) for consistent downstream array-combining.
  expect_equal(unname(r2[["mcmcSummary"]][["nThin"]]), c(1, 1))
})

test_that("RT-352: nCores x per-chain-thread oversubscription now warns", {
  skip_if_not_installed("future.apply")
  # `nCores` is clamped to `nRun` (#1485), so an oversized request can no
  # longer be what oversubscribes; the fixture instead asks for exactly the
  # `nRun` workers it gets and mocks a single available core.
  testthat::local_mocked_bindings(detectCores = function(...) 1L, .package = "parallel")

  # {parallelly} independently warns about the same oversubscribed worker
  # pool when the future plan is created; muffle that expected side warning
  # so only our own RT-352 warning reaches expect_warning() below.
  withCallingHandlers({
    expect_warning(
      RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                   nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1:2,
                   runParallel = TRUE, nCores = 2L, quiet = TRUE),
      "oversubscribe available CPU cores"
    )
  }, warning = function(w) {
    if (grepl("localhost parallel workers", conditionMessage(w), fixed = TRUE)) {
      invokeRestart("muffleWarning")
    }
  })
})
