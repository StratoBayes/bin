# Age-conversion hardening: #1537, #1539, #1540, #1630, #1631, #1633.

gapData <- local({
  set.seed(0)
  td <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  .EnsurePreExtracted(
    StratData(td[["signal"]], parts = td[["parts"]],
              signalColumn = c("a", "b"), zColumn = "Hight",
              siteColumn = "SIT")
  )
})
# Site 2 of this fixture is the only multi-partition section.
gapSite <- 2

test_that(".ValidateAgeConversionBounds rejects an out-of-range site (#1630)", {
  ind <- stratModel1[["ind"]]
  # -2 is the dangerous one: `BoundLow[, -2]` drops a column instead of
  # selecting one, so the height-range check silently passed.
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, -2, 5),
               "site index between 1 and 3")
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, 0, 1),
               "site index between 1 and 3")
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, 4, 1),
               "site index between 1 and 3")
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, c(2, 3), 1),
               "site index between 1 and 3")
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, NA_integer_, 1),
               "site index between 1 and 3")
  expect_error(.ValidateAgeConversionBounds(stratData1, ind, 2.5, 1),
               "site index between 1 and 3")
  expect_silent(.ValidateAgeConversionBounds(stratData1, ind, 2, 1))
})

test_that(".AgeConversionBatch rejects a negative site before C++ (#1630)", {
  # Before the guard this segfaulted: the R validation passed and the value
  # reached Rcpp's unchecked operator[].
  ind <- stratModel1[["ind"]]
  par <- matrix(rep(0.5, length(ind[["names"]])), nrow = 1)
  # "single" appears in the R guard's wording only, so this assertion cannot
  # be satisfied by the C++ wrapper's guard further downstream.
  expect_error(.AgeConversionBatch(par, c(0, 1, 2), -2, stratData1, ind),
               "single site index between 1 and 3")
})

test_that(".sb_age_convert_batch's wrapper guards the site index (#1630)", {
  # The guard must live in the exported wrapper, not the implementation:
  # unwinding out of the large impl frame segfaults on aarch64-Linux.
  ind <- stratModel1[["ind"]]
  par <- matrix(rep(0.5, length(ind[["names"]])), nrow = 1)
  expect_error(.sb_age_convert_batch(stratData1, ind, par, c(0, 1, 2), 99L),
               "site index between 1 and 3")
  expect_error(.sb_age_convert_batch(stratData1, ind, par, c(0, 1, 2), -2L),
               "site index between 1 and 3")
  # In range for the check above, but height-scale site 1 indexes the
  # reference-site-excluding alpha vector at -1.
  expect_error(.sb_age_convert_batch(stratData1, ind, par, c(0, 1, 2), 1L),
               "heights from the first site remain unchanged")
  expect_silent(.sb_age_convert_batch(stratData1, ind, par, c(0, 1, 2), 3L))
})

test_that(".GetSedRates errors on an unrecognised sedModel (#1631)", {
  # "Site" used to reach `gamma[NULL]`, and `prod(numeric(0), ...)` then
  # fabricated a rate of 1.
  ind <- stratModel1[["ind"]]
  par <- .AdjustParams(rep(0.5, length(ind[["names"]])), ind)
  expect_error(.GetSedRates(stratData1, ind, par, "height", "Site", 2),
               "Unknown sedModel")
  expect_error(.GetSedRates(stratData1, ind, par, "height", "s", 2),
               "Unknown sedModel")

  indAge <- stratModel2[["ind"]]
  parAge <- .AdjustParams(rep(0.5, length(indAge[["names"]])), indAge)
  expect_error(.GetSedRates(stratData2, indAge, parAge, "age", "Site", 2),
               "Unknown sedModel")
})

test_that(".AgeConversionGeneral canonicalises a passed sedModel (#1631)", {
  ind <- stratModel1[["ind"]]
  par <- rep(0.5, length(ind[["names"]]))
  indAbbrev <- ind
  indAbbrev[["sedModel"]] <- "s"

  expect_equal(
    .AgeConversionGeneral(par, c(0, 1, 2), 2, stratData = stratData1,
                          indices = indAbbrev),
    .AgeConversionGeneral(par, c(0, 1, 2), 2, stratData = stratData1,
                          indices = ind)
  )
})

test_that(".AgeConversionBatch canonicalises a passed sedModel (#1631)", {
  ind <- stratModel1[["ind"]]
  par <- matrix(rep(0.5, length(ind[["names"]])), nrow = 1)
  indAbbrev <- ind
  indAbbrev[["sedModel"]] <- "s"

  expect_equal(
    .AgeConversionBatch(par, c(0, 1, 2), 2, stratData1, indAbbrev),
    .AgeConversionBatch(par, c(0, 1, 2), 2, stratData1, ind)
  )
})

test_that(".CalculateAlphas propagates a non-finite parameter (#1537)", {
  ind <- .CreateIndices(gapData, "age", "site", "bottom")
  par <- rep(0.5, length(ind[["names"]]))
  par[ind[["alpha"]][[gapSite]]] <- NA_real_

  rOut <- .AgeConversionStratData(gapData, ind, par, returnAlphas = TRUE)
  cppOut <- .sb_age_convert(gapData, ind, par, returnAlphas = TRUE)

  # is.na() is TRUE for both NA and NaN, which the two engines pick
  # differently; the pin is which entries are non-finite, not the flavour.
  expect_true(all(is.na(rOut[["alphas"]][[gapSite]])))
  expect_identical(is.na(rOut[["alphas"]][[gapSite]]),
                   is.na(cppOut[["alphas"]][[gapSite]]))
  expect_identical(is.na(rOut[["signal"]][[gapSite]]),
                   is.na(cppOut[["signal"]][[gapSite]]))
})

test_that(".CalculateAlphasSedSmooth propagates non-finite terms (#1537)", {
  model <- StratModel(gapData, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 5)
  ind <- model[["ind"]]
  info <- model[["sedSmoothInfo"]]
  par <- rep(0.5, length(ind[["names"]]))
  beta <- rep(0, info[["totalBeta"]])

  # Finite inputs, including the gap parameter this site uses, stay finite.
  expect_true(all(is.finite(
    .CalculateAlphasSedSmooth(gapData, ind, par, gapSite, info, beta)
  )))

  # Height scale: the reference site has no alpha, so site s reads alpha[s - 1].
  naAlpha <- par
  naAlpha[ind[["alpha"]][[gapSite - 1]]] <- NA_real_
  expect_true(all(is.na(
    .CalculateAlphasSedSmooth(gapData, ind, naAlpha, gapSite, info, beta)
  )))

  expect_true(all(is.na(
    .CalculateAlphasSedSmooth(gapData, ind, par, gapSite, info,
                              rep(NaN, info[["totalBeta"]]))
  )))
})

test_that("both C++ entry points read zeta under the same condition (#1540)", {
  d <- .EnsurePreExtracted(stratData1)
  ind <- stratModel1[["ind"]]
  par <- rep(0.5, length(ind[["names"]]))

  # `.CreateIndices()` attaches zeta only under "site x partition" today, so
  # only a hand-built `indices` can separate the three conditions.
  indZeta <- ind
  indZeta[["zeta"]] <- ind[["alpha"]][[1]]

  site <- 3 # height scale: zeta covers sites 3..S
  heights <- SignalLookUp(d, "height", site)

  single <- as.numeric(.sb_age_convert(d, indZeta, par)[["signal"]][[site]])
  rOut <- as.numeric(
    .AgeConversionStratData(d, indZeta, par)[["signal"]][[site]])
  batch <- .sb_age_convert_batch(d, indZeta, matrix(par, nrow = 1),
                                 sort(heights), site)[, 1]

  expect_equal(single[order(heights)], batch)
  expect_equal(single, rOut)

  # Guard against a vacuous comparison: zeta must change the answer.
  expect_false(isTRUE(all.equal(
    single, as.numeric(.sb_age_convert(d, ind, par)[["signal"]][[site]]))))
})

test_that("the unconverted-height warning names its actual trigger (#1539)", {
  # stratData2's partitions are contiguous; widen one to open a real gap.
  d <- stratData2
  d[["partsAttr"]][["Bound"]][1, 2] <- 5
  ind <- stratModel2[["ind"]]
  set.seed(1)
  par <- rnorm(length(ind[["names"]]), sd = 1)

  expect_warning(
    result <- .AgeConversionGeneral(par, 7, 2, stratData = d,
                                    stratModel = stratModel2),
    "lie in no partition of site 2"
  )
  expect_true(is.na(result))
})

test_that("one non-finite parameter row does not flag every height (#1633)", {
  ind <- stratModel1[["ind"]]
  nPar <- length(ind[["names"]])
  parMat <- matrix(0.5, nrow = 3, ncol = nPar)
  parMat[2, ind[["alpha"]][[1]]] <- NA_real_
  heights <- c(0, 1, 2)

  warnings <- capture_warnings(
    out <- .AgeConversionBatch(parMat, heights, 2, stratData1, ind))

  expect_false(any(grepl("gap", warnings)))
  expect_false(any(grepl("lie in no partition", warnings)))
  expect_match(warnings, "check the supplied parameters", all = FALSE)

  expect_true(all(is.na(out[, 2])))
  expect_false(anyNA(out[, c(1, 3)]))
})

test_that(".HeightsCoveredByPartition matches the C++ binning (#1633)", {
  # The warning is only as good as this mirror of `.CalculateNewAges()`'s
  # coverage loop, so pin it against the binning C++ actually performs.
  d <- stratData2
  d[["partsAttr"]][["Bound"]][1, 2] <- 5
  ind <- stratModel2[["ind"]]
  set.seed(1)
  par <- matrix(rnorm(length(ind[["names"]]), sd = 1), nrow = 1)
  heights <- c(0.5, 3, 6, 7, 9, 12)

  out <- .sb_age_convert_batch(d, ind, par, heights, 2)

  expect_identical(.HeightsCoveredByPartition(d, 2, heights),
                   !apply(is.na(out), 1, all))
})
