{ # Initialize
  expectSpecificVector <- function(object, len, type, info = NULL) {
    expect_equal(class(object), type)
    expect_length(object, len)
    expect_true(all(!is.na(object)), info = paste(deparse(substitute(object)),
                                                  "contains NA values"))
  }

  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      ties = testDataMulti$ties,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  #StratModelTemplate(tmulti, alignmentScale = "age", sedModel = "s", alphaPosition = "b")
  priorsm <- structure(list(
      "alpha_site1" = UniformPrior(min  = 10, max  = 60),
      "alpha_site2" = UniformPrior(min  = -10, max  = 60),
      "alpha_site3" = UniformPrior(min  = -10, max  = 60),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.1)),
    class = c("list", "StratPrior"))

  model <- StratModel(tmulti, priorsm,
                      alignmentScale = "age",
                      sedModel = "site",
                      alphaPosition = "bottom")
  mcmc <- StratMCMC(model, nIter = 10, nChains = 2)
}

# t3 <- RunStratModel(tmulti, priors = priorsm, sigmaFixed = FALSE, nIter = 200,  visualise = 50,
#                     gibbsPriors = list(aSigma = 0.01, bSigma = 100, aLambda = 1, bLambda = 1))
# t4 <- RunStratModel(tmulti, priors = priorsm, sigmaFixed = TRUE, nIter = 200,  visualise = 50,
#                     gibbsPriors = list(aSigma = 1, bSigma = 1, aLambda = 1, bLambda = 1))
## Testing the components of .GenerateInitialState

test_that("Initialization successful", {
  # This behaviour is not tested in test-Stratdata.R
  # Worth checking here.
  expect_equal(lengths(tmulti[[c("signalAttr", "signalGapSectBindSepSignal")]]),
               c(a = 3, b = 3))
})

test_that(".GenerateValidProposal works", {
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)


  expectSpecificVector(stateNew$metro$parameters, length(model$parametersNames), "numeric")
  expectSpecificVector(stateNew$age$ageRange, 2, "numeric")

  for (s in seq_along(stateNew$age$signal)) {
    expectSpecificVector(stateNew$age$signal[[s]], tmulti$signalAttr$N[s], "numeric")
    expectSpecificVector(stateNew$age$ties[[s]], tmulti$tiesAttr$tiesN[s], "numeric")
  }

  for (m in seq_along(tmulti$signalAttr$signalNames)) {
    expectSpecificVector(stateNew$age$signalSectionOverlap[[m]], tmulti$signalAttr$nPerSignal[m], "integer")
  }
})

test_that(".SectionOverlap handles a site with zero non-NA signal observations (RT-028)", {
  # RT-028: a section with no observations (all-NA signal at one site, so its
  # ages vector is empty) previously crashed sectionOverlapCpp with an OOB
  # read on ages[0]. Fixed by the empty-section guard in FindMaxSect.cpp.
  result <- .SectionOverlap(signalAges = list(numeric(0), c(10, 15, 20)))

  expect_length(result, 2)
  expect_length(result[[1]], 0)
  expect_equal(result[[2]], c(1L, 1L, 1L))
})

test_that(".GenerateValidProposal caps the inner rates loop instead of hanging (RT-222)", {
  # A fixed `parametersInitial` whose rate parameter lies outside
  # [ratesMin, ratesMax] would make the inner while(ratesExtreme) loop re-select
  # the same out-of-range value forever. Inject one directly on the mcmc object
  # (bypassing StratMCMC()'s own validation) to exercise the cap. gammaLog_site1
  # (a rate parameter) is set to 100, far above the default ratesMax of 14.
  mcmcExtreme <- mcmc
  mcmcExtreme[[c("metro", "parametersInitial")]] <- c(30, 30, 30, 100, 1, 1, 5)

  expect_error(
    .GenerateValidProposal(tmulti, model, mcmcExtreme, stateOld = NULL,
                           ProposeMetro = .MetroPriorSample,
                           initialState = TRUE, chain = 2),
    "inside the permitted range",
    fixed = TRUE
  )

  # Normal in-range usage is unaffected: the auto-generated initial state still
  # produces a valid proposal without error.
  expect_no_error(
    .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL,
                           ProposeMetro = .MetroPriorSample,
                           initialState = TRUE, chain = 2)
  )
})


test_that(".LogLikTies dispatch path matches the fallback path (RT-031)", {
  # .tiesDispatch is only ever set by RunStratModel(), so a model built via
  # StratModel() (as tmulti/model are here) always takes the fallback path;
  # attach a dispatch table by hand to exercise and compare both paths on the
  # same state, which the test suite otherwise never does.
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)

  modelDispatch <- model
  modelDispatch[[".tiesDispatch"]] <- .BuildTiesDispatch(tmulti, model)

  llDispatch <- .LogLikTies(tmulti, modelDispatch, stateNew)
  llFallback <- .LogLikTies(tmulti, model, stateNew)

  # Guard against the comparison going vacuous if the fixture's ties were ever
  # to stop contributing.
  expect_true(is.finite(llFallback))
  expect_equal(llDispatch, llFallback)
})

test_that(".LogLikTies errors on NA from a custom densityFun, both paths (RT-032)", {
  # A pathological user-supplied densityFun returning NA used to be silently
  # zeroed by `sum(logLikTies, na.rm = TRUE)` on the fallback path, while the
  # dispatch path failed with a bare "missing value where TRUE/FALSE needed"
  # from its non-finite comparison. Both now report the same diagnostic.
  # Minimal hand-built data/model/state, exercising .LogLikTies() directly
  # rather than threading a custom densityFun through the full
  # StratData()/StratModel() validation pipeline.
  #
  # The function has to be reachable by name from the package namespace (both
  # paths resolve it with match.fun()), so it goes in globalenv() under a name
  # distinctive enough not to collide with anything else in the suite.
  assign(".rtBadTiesDensity", function(x, mean, log = TRUE) NA_real_,
         envir = globalenv())
  on.exit(rm(".rtBadTiesDensity", envir = globalenv()), add = TRUE)

  dataMin <- list(
    S = 1L,
    ties = TRUE,
    tiesAttr = list(
      densityFun = matrix(".rtBadTiesDensity", nrow = 1, ncol = 1),
      arg1 = matrix(0, nrow = 1, ncol = 1)
    )
  )
  modelMin <- list(alignmentScale = "age",
                   tiesActive = matrix(TRUE, nrow = 1, ncol = 1))
  stateMin <- list(age = list(ties = list(matrix(5))))

  # Fallback path (no .tiesDispatch attached).
  expect_error(.LogLikTies(dataMin, modelMin, stateMin), "NA log-likelihood")

  # Dispatch path — the one RunStratModel() always takes.
  modelDispatch <- modelMin
  modelDispatch[[".tiesDispatch"]] <- .BuildTiesDispatch(dataMin, modelMin)
  expect_error(.LogLikTies(dataMin, modelDispatch, stateMin),
               "NA log-likelihood")
})

test_that(".FlexibleKnotsUpdateDB works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  expect_true("matrix" %in% class(stateNew$spline$D))
  expect_false(any(is.na(stateNew$spline$D)))
  expect_true("matrix" %in% class(stateNew$metro$B[[1]]))
  expect_true("matrix" %in% class(stateNew$metro$B[[2]]))
  expect_false(any(is.na(stateNew$metro$B[[2]])))
  expect_false(any(is.na(stateNew$metro$B[[2]])))
})


test_that(".InitializeGibbs works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  expectSpecificVector(stateNew$gibbs$lambda, 2, "numeric")
  expectSpecificVector(stateNew$gibbs$beta[[1]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$gibbs$beta[[2]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$gibbs$sigma[[1]], 1, "numeric")
  expectSpecificVector(stateNew$gibbs$sigma[[2]], 1, "numeric")

  # RT-372: `Q` must exist before the first Gibbs sweep -- `.sb_gibbs()` reads
  # `Q_fallback[[m]]` when the Cholesky of `M = H + lambda * D` fails, and
  # would otherwise index an empty list. The C++ engine seeds the same slot
  # with identity matrices; the R path must match.
  p <- model$splineBase$num_basis
  expect_length(stateNew$gibbs$Q, 2)
  for (m in 1:2) {
    expect_true(is.matrix(stateNew$gibbs$Q[[m]]))
    expect_equal(dim(stateNew$gibbs$Q[[m]]), c(p, p))
    expect_equal(stateNew$gibbs$Q[[m]], diag(p))
  }
})

test_that("Gibbs Q fallback survives a first-iteration Cholesky failure (RT-372)", {
  # The fallback branch of `.sb_gibbs()` is not reachable through the ordinary
  # pipeline (it needs a rank-deficient M on iteration 1), so drive it
  # directly with the state `.InitializeGibbs()` produces. A zero H and a zero
  # penalty matrix make M = H + lambda * D singular, which is what sends
  # `.sb_gibbs()` into the `Q_fallback` branch.
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)
  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  p <- model$splineBase$num_basis
  singularH <- matrix(0, p, p)

  expect_warning(
    res <- .sb_gibbs(
      H_list           = list(singularH),
      tBy_list         = list(rep(1, p)),
      B_list           = list(matrix(1, 1, p)),
      signalValuesVec  = list(1),
      sigma_in         = 1,
      lambda_in        = 0,
      D_mat            = matrix(0, p, p),
      Q_fallback       = stateNew$gibbs$Q,
      aLambda          = 1, bLambda = 1,
      shapeSigma       = 1, bSigma_prior = 1,
      numBasis         = p,
      sigmaIsFixed     = TRUE,
      sigmaFixedValues = 1
    ),
    "Cholesky decomposition failed"
  )
  # the fallback Q that came out is the identity `.InitializeGibbs()` seeded
  expect_equal(dim(res$Q[[1]]), c(p, p))
  expect_equal(res$Q[[1]], diag(p))
  expect_true(all(is.finite(res$beta[[1]])))
})

test_that(".UpdateHtBy works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  stateNew <- .UpdateHtBy(tmulti, stateNew)

  expect_true("matrix" %in% class(stateNew$metro$H[[1]]))
  expect_false(any(is.na(stateNew$metro$H[[1]])))
  expect_equal(dim(stateNew$metro$H[[1]]), rep(model$splineBase$num_basis,2))
  expect_true("matrix" %in% class(stateNew$metro$H[[2]]))
  expect_false(any(is.na(stateNew$metro$H[[2]])))
  expect_equal(dim(stateNew$metro$H[[2]]), rep(model$splineBase$num_basis,2))
  expectSpecificVector(stateNew$metro$tBy[[1]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$metro$tBy[[2]], model$splineBase$num_basis, "numeric")
})


test_that(".LogLikTies and .LogPost works", {
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  stateNew <- .UpdateHtBy(tmulti, stateNew)

  logLikTies <- .LogLikTies(tmulti, model, stateNew)
  expectSpecificVector(logLikTies, 1, "numeric")

  logPost <- .LogPost(tmulti, model, stateNew)
  expectSpecificVector(logPost, 4, "numeric")

})

test_that(".LogPost rejects a negative gap parameter even under a custom NormalPrior (RT-019)", {
  # AutoPrior/the default ExponentialPrior above already assigns zero density
  # to negative gaps, so it cannot exercise the bug. Swap the gap prior for a
  # NormalPrior, whose density is finite for x < 0, to reproduce the scenario
  # RT-019 describes: a user-supplied prior with unbounded-below support lets
  # the MCMC visit geologically nonsensical negative-gap (time-reversed) states.
  # `.CheckGapPriorSupport()` (#1170) now rejects a gap prior with mass below
  # zero at construction, and any prior it does admit has zero density at -3 --
  # which is the very thing this test needs *not* to be the reason. So the
  # model is built with a legal prior and the NormalPrior swapped in
  # afterwards, leaving `.LogPost()`'s own structural guard as the only thing
  # that can reject the negative gap.
  modelNormalGap <- StratModel(tmulti, priorsm,
                               alignmentScale = "age",
                               sedModel = "site",
                               alphaPosition = "bottom")
  modelNormalGap[[c("priors", "metro")]][["gap_site2_1"]] <-
    NormalPrior(mean = 5, sd = 2)
  mcmcNormalGap <- StratMCMC(modelNormalGap, nIter = 10, nChains = 2)

  stateNew <- .GenerateValidProposal(tmulti, modelNormalGap, mcmcNormalGap,
                                     stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, modelNormalGap, stateNew)
  stateNew <- .InitializeGibbs(tmulti, modelNormalGap, stateNew)
  stateNew <- .UpdateHtBy(tmulti, stateNew)

  gapIdx <- modelNormalGap[[c("ind", "gap")]]
  expect_equal(modelNormalGap[["parametersNames"]][gapIdx], "gap_site2_1")

  # sanity check: the assigned prior itself has finite density at a negative
  # gap value -- without the structural guard in .LogPost() this would leak
  # through as a finite log-posterior
  expect_true(is.finite(dnorm(-3, mean = 5, sd = 2, log = TRUE)))

  stateNew[[c("metro", "parameters")]][gapIdx] <- -3
  logPost <- .LogPost(tmulti, modelNormalGap, stateNew)

  expect_equal(logPost[1], -Inf)
})

test_that(".LogLikTies fallback path binds args by name, matching the dispatch-table path (RT-249)", {
  # Site 1, tie 1 uses dnorm(x, mean, sd, log) with arg1 (mean) supplied.
  # Force arg1 to NA (skipped) while keeping arg2 (sd) supplied: the buggy
  # fallback assigned by list *position* after setNames(), so skipping the
  # first arg column left a NULL gap and every later argument landed one
  # slot off from the do.call() positional match.
  tmultiNaArg <- tmulti
  tmultiNaArg[[c("tiesAttr", "arg1")]][1, 1] <- NA
  tmultiNaArg[[c("tiesAttr", "arg2")]][1, 1] <- 1

  stateNew <- .GenerateValidProposal(tmultiNaArg, model, mcmc, stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmultiNaArg, model, stateNew)
  stateNew <- .InitializeGibbs(tmultiNaArg, model, stateNew)
  stateNew <- .UpdateHtBy(tmultiNaArg, stateNew)

  modelFallback <- model
  modelFallback[[".tiesDispatch"]] <- NULL

  modelDispatch <- model
  modelDispatch[[".tiesDispatch"]] <- .BuildTiesDispatch(tmultiNaArg, modelDispatch)

  logLikFallback <- .LogLikTies(tmultiNaArg, modelFallback, stateNew)
  logLikDispatch <- .LogLikTies(tmultiNaArg, modelDispatch, stateNew)

  expectSpecificVector(logLikFallback, 1, "numeric")
  expect_equal(logLikFallback, logLikDispatch)
})

# RT-184: `.LogPost()` reads `model[[".logpost_cpp"]]` and, when absent,
# falls back to computing it locally via `.PrepareLogPostArgs()` -- but never
# writes the result back into `model` (R's copy-on-modify semantics mean it
# can't, since `model` is a plain list passed by value). This is a
# documented, deliberate fallback (normally the cache is pre-populated once
# by `RunStratModel()` before the MCMC loop starts), not a correctness bug:
# confirm the two paths (cache pre-populated vs. computed on the fly) give
# identical results.
test_that(".LogPost() gives identical results with/without a pre-populated cache (RT-184)", {
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)
  stateNew <- .InitializeGibbs(tmulti, model, stateNew)
  stateNew <- .UpdateHtBy(tmulti, stateNew)

  modelNoCache <- model
  modelNoCache[[".logpost_cpp"]] <- NULL
  expect_null(modelNoCache[[".logpost_cpp"]])

  modelCached <- modelNoCache
  modelCached[[".logpost_cpp"]] <- .PrepareLogPostArgs(modelNoCache)

  logPostUncached <- .LogPost(tmulti, modelNoCache, stateNew)
  logPostCached <- .LogPost(tmulti, modelCached, stateNew)

  expect_equal(logPostUncached, logPostCached)
})

test_that(".GenerateInitialState works", {
  state <- .GenerateInitialState(tmulti, model, mcmc, 1)
  expectSpecificVector(state$metro$logPost, 1, "numeric")
})

test_that(".UpdateState works", {
  state <- .GenerateInitialState(tmulti, model, mcmc, 1)
  stateNew <- .UpdateState(tmulti, model, mcmc, state, 1)

  expectSpecificVector(   c(state$metro$logPostOld,
                            state$metro$logPostNew,
                            state$metro$logPost), 3, "numeric")
  expectSpecificVector(   c(stateNew$metro$logPostOld,
                            stateNew$metro$logPostNew,
                            stateNew$metro$logPost), 3, "numeric")
  })
