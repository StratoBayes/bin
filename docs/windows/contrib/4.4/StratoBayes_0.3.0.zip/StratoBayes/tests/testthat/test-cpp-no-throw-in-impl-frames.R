# RT-433 guard: an Rcpp-exported entry point must be a thin wrapper that holds
# every stop(), delegating to a `*_impl` function that never throws (AGENTS.md,
# "C++ error paths -- wrapper validates, implementation never throws"). Throwing
# out of a large implementation frame segfaults on aarch64-Linux (PR #384); this
# static check is the cheap, obvious guard against regressing that split.
#
# RT-700 extends it to warning(): under options(warn = 2) Rf_warning becomes
# errorcall and longjmps out of the same frame, so a warning raised in an impl
# breaks the invariant by the same route. Carry the message out on the result
# struct and raise it from the wrapper.
#
# Scope: this scans only `static ... name_impl(...) { ... }` DEFINITIONS -- the
# naming and "static" convention every wrapper/impl split in this codebase
# follows (sb_create_engine_impl, sb_run_block_impl, sb_gibbs_impl, ...). It
# does NOT catch a stop() reached via a helper the impl calls (e.g. a small
# static parser), nor a throw from a header function several frames deep
# (Gradient_impl.h's compute_logpost_gradient is reviewed by hand -- see the
# RT-433 sweep PR description for why it is closed off at the call sites
# instead of restructured). Treat this as a mechanical regression check for the
# split itself, not a full call-graph analysis.

# Find the character offset of the `{` that opens the body of the function
# whose parameter list opens at `paren_open` (the position of the `(`
# immediately after the function name). Balances parens first (to skip past
# the parameter list, including any nested parens in default arguments), then
# returns the position of the next unmatched `{`.
find_body_open_brace <- function(text, paren_open) {
  chars <- strsplit(text, "", fixed = TRUE)[[1]]
  n <- length(chars)
  depth <- 0
  i <- paren_open
  # Balance the parameter-list parens.
  repeat {
    if (i > n) return(NA_integer_)
    if (chars[i] == "(") depth <- depth + 1
    if (chars[i] == ")") depth <- depth - 1
    i <- i + 1
    if (depth == 0) break
  }
  # Skip forward (over `const`, `noexcept`, whitespace, etc.) to the `{`.
  while (i <= n && chars[i] != "{") i <- i + 1
  if (i > n) NA_integer_ else i
}

# Given the position of a function body's opening `{`, return the position of
# its matching closing `}` (simple depth count; no string/char-literal
# awareness needed for this codebase's *_impl bodies).
find_body_close_brace <- function(text, open_pos) {
  chars <- strsplit(text, "", fixed = TRUE)[[1]]
  n <- length(chars)
  depth <- 0
  for (i in open_pos:n) {
    if (chars[i] == "{") depth <- depth + 1
    if (chars[i] == "}") depth <- depth - 1
    if (depth == 0) return(i)
  }
  NA_integer_
}

test_that("no *_impl function in src/ calls stop() or warning()", {
  # tests/testthat/../../src -- the package source tree, present both under
  # devtools::test()/R CMD check (run from the package root) and in an
  # installed package's Meta/ build sources.
  src_dir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(src_dir), "src/ not found (not running against a source tree)")
  src_files <- list.files(src_dir, pattern = "\\.(cpp|h)$", full.names = TRUE)
  expect_true(length(src_files) > 0)

  violations <- character(0)
  def_pattern <- "\\bstatic\\b[^;{]*?\\b([A-Za-z_][A-Za-z0-9_]*_impl)\\s*\\("

  for (f in src_files) {
    text <- paste(readLines(f, warn = FALSE), collapse = "\n")
    # Strip // line comments so a comment mentioning "stop(" inside a
    # docstring (as several of these wrappers' RT-433 explanations do) can't
    # produce a false positive.
    text <- gsub("//[^\n]*", "", text)

    matches <- gregexpr(def_pattern, text, perl = TRUE)[[1]]
    if (matches[1] == -1) next
    match_lens <- attr(matches, "match.length")
    cap_start <- attr(matches, "capture.start")[, 1]
    cap_len   <- attr(matches, "capture.length")[, 1]

    for (k in seq_along(matches)) {
      fn_name <- substr(text, cap_start[k], cap_start[k] + cap_len[k] - 1)
      paren_open <- cap_start[k] + cap_len[k]
      # paren_open should land on "(" (possibly after whitespace).
      while (substr(text, paren_open, paren_open) != "(") paren_open <- paren_open + 1

      open_brace <- find_body_open_brace(text, paren_open)
      if (is.na(open_brace)) next
      close_brace <- find_body_close_brace(text, open_brace)
      if (is.na(close_brace)) next

      body <- substr(text, open_brace, close_brace)
      for (construct in c("stop", "warning")) {
        if (!grepl(sprintf("\\b%s\\s*\\(", construct), body, perl = TRUE)) next
        line_no <- lengths(regmatches(
          substr(text, 1, matches[k]), gregexpr("\n", substr(text, 1, matches[k]))
        )) + 1
        violations <- c(violations, sprintf(
          "%s:%d (%s) calls %s()", basename(f), line_no, fn_name, construct
        ))
      }
    }
  }

  expect_true(
    length(violations) == 0,
    info = paste(
      "RT-433/RT-700 regression: the following *_impl functions leave their",
      "frame by a longjmp, which can segfault on aarch64 when it unwinds out",
      "of a large frame. Carry the message out on the result struct and raise",
      "it from the wrapper instead:",
      paste(violations, collapse = "; ")
    )
  )
})


# #1134 extends the same invariant to the OTHER way an implementation frame can
# be left by a longjmp: calling back into R. A user-supplied ties `densityFun`
# can `stop()`, and coercing whatever it returns with `as<double>()` can throw
# in its own right. Both are closed by construction -- `.SafeCallback()` catches
# the error in R, between the user's function and the C++ call site, and
# `callback_ok()` reads the result with no operation that can throw -- but only
# for as long as every call site keeps that shape. The scan below is what stops
# a future call site reverting to the naive `as<double>(eng.tiesCallback(...))`,
# which no amount of x86-64 CI can discriminate.
test_that("every tiesCallback call site reads its result without throwing", {
  src_dir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(src_dir), "src/ not found (not running against a source tree)")
  src_files <- list.files(src_dir, pattern = "\\.(cpp|h)$", full.names = TRUE)
  expect_true(length(src_files) > 0)

  callSites <- 0L
  violations <- character(0)

  for (f in src_files) {
    lines <- readLines(f, warn = FALSE)
    # `eng->tiesCallback` too: impls holding an XPtr spell it that way. Matching
    # the member name is what a site reached through an alias
    # (`Function& cb = eng.tiesCallback; cb(args);`) evades -- and since it adds
    # rather than renames a site, the floor below still passes.
    hits <- grep("\\beng\\s*(\\.|->)\\s*tiesCallback\\s*\\(", lines)
    for (i in hits) {
      callSites <- callSites + 1L
      # The result must be captured as an RObject (protected, and not yet
      # coerced) and then read through callback_ok() close by.
      captured <- grepl(
        "RObject\\s+\\w+\\s*=\\s*eng\\s*(\\.|->)\\s*tiesCallback\\s*\\(",
        lines[i])
      window <- paste(lines[i:min(length(lines), i + 10L)], collapse = " ")
      if (!captured || !grepl("callback_ok\\s*\\(", window)) {
        violations <- c(violations,
                        sprintf("%s:%d: %s", basename(f), i, trimws(lines[i])))
      }
    }
  }

  # A zero count would make this test vacuous: it must fail, not silently pass
  # over nothing, if the callback is renamed.
  expect_true(callSites >= 3L)
  expect_true(
    length(violations) == 0,
    info = paste(
      "#1134 regression: these tiesCallback call sites can throw from inside an",
      "implementation frame. Capture the result as an RObject and read it with",
      "callback_ok(), which records the message on the engine for the exported",
      "wrapper to raise:", paste(violations, collapse = "; ")
    )
  )
})


# #1144 is the same hazard through the custom-prior door: `Prior(R = , D = )`
# takes two arbitrary R functions, and the engine calls them from
# `compute_logpost()`, the gradient's finite-difference fallback,
# `sample_all_from_prior()` and `sb_logpost_impl()`. Every one of those results
# must be read by a callback_ok()/sb_callback_ok() that cannot throw, never by
# `as<double>()` or `as<NumericVector>()`.
test_that("every custom-prior callback site reads its result without throwing", {
  src_dir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(src_dir), "src/ not found (not running against a source tree)")
  src_files <- list.files(src_dir, pattern = "\\.(cpp|h)$", full.names = TRUE)

  # `do_call_r(fn, args)` is the engine's own wrapper round `do.call`; the raw
  # `doCall(...)` inside its definition is the one place it legitimately
  # appears un-guarded, so match the wrapper name rather than `doCall`.
  patterns <- c("\\bdo_call_r\\s*\\(", "\\bdoCall\\s*\\(\\s*rFn\\b")
  callSites <- 0L
  violations <- character(0)

  for (f in src_files) {
    lines <- readLines(f, warn = FALSE)
    hits <- sort(unique(unlist(lapply(patterns, grep, x = lines))))
    for (i in hits) {
      if (grepl("^\\s*static\\b", lines[i])) next  # the definition itself
      # A comment naming the wrapper is not a call site. Without this, a
      # comment explaining the pairing counts as an unguarded call.
      if (grepl("^\\s*(//|\\*)", lines[i])) next
      callSites <- callSites + 1L
      captured <- grepl(
        paste0("RObject\\s+\\w+\\s*=\\s*(", paste(patterns, collapse = "|"), ")"),
        lines[i])
      window <- paste(lines[i:min(length(lines), i + 6L)], collapse = " ")
      if (!captured || !grepl("\\bsb_callback_ok\\s*\\(|\\bcallback_ok\\s*\\(",
                              window)) {
        violations <- c(violations,
                        sprintf("%s:%d: %s", basename(f), i, trimws(lines[i])))
      }
    }
  }

  # Three engine sites (density in compute_logpost, generator in
  # sample_all_from_prior, two FD evaluations in the gradient) plus
  # sb_logpost_impl's. A rename must fail here, not pass over nothing.
  expect_true(callSites >= 5L)
  expect_true(
    length(violations) == 0,
    info = paste(
      "#1144 regression: these custom-prior callback sites can throw from",
      "inside an implementation frame. Capture the result as an RObject and",
      "read it with callback_ok() / sb_callback_ok(), which record the message",
      "for the exported wrapper to raise:", paste(violations, collapse = "; ")
    )
  )
})
