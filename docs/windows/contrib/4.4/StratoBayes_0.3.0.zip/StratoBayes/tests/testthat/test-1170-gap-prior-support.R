# GH #1170: nothing checked that a gap-duration prior has non-negative support.
# A negative gap makes two partitions overlap in age, so one age inverts to two
# heights and `.CalculateRefHeightToHeights()` silently returns the one from the
# lower-indexed partition.

MakeGapPriors <- function(gapPrior) {
  structure(list(
    "alpha_2" = UniformPrior(min = -5, max = 5),
    "gammaLog_3" = Fixed(1),
    "gammaLog_2" = NormalPrior(mean = 0, sd = 0.5),
    "gap_2_1" = gapPrior),
    class = c("StratPrior", "list"))
}

BuildModel <- function(gapPrior) {
  data("stratData3", package = "StratoBayes")
  StratModel(stratData = stratData3, priors = MakeGapPriors(gapPrior),
             alignmentScale = "h", sedModel = "p", alphaPosition = "m",
             nKnots = 10, aLambda = 1, bLambda = 10, sigmaFixed = FALSE)
}

test_that("a gap prior with negative support is rejected", {
  for (bad in list(NormalPrior(5, 10), UniformPrior(-5, 5), Fixed(-3),
                   TruncNormalPrior(0, 1, -1, 1))) {
    expect_error(.CheckGapPriorSupport(MakeGapPriors(bad)), "gap_2_1")
    expect_error(.CheckGapPriorSupport(MakeGapPriors(bad)), "cannot be negative")
  }
  expect_error(BuildModel(NormalPrior(5, 10)), "cannot be negative")
})

test_that("gap priors with non-negative support are accepted", {
  for (ok in list(ExponentialPrior(1), UniformPrior(0, 1), Fixed(0), Fixed(3),
                  LogNormalPrior(0, 1), TruncNormalPrior(0, 1, 0, 5))) {
    expect_true(.CheckGapPriorSupport(MakeGapPriors(ok)))
  }
  expect_s3_class(BuildModel(UniformPrior(0, 1)), "StratModel")
})

test_that("non-gap priors may have negative support", {
  expect_true(.CheckGapPriorSupport(MakeGapPriors(ExponentialPrior(1))))
  # alpha_2 is Uniform(-5, 5) throughout, and must stay legal
  expect_s3_class(BuildModel(ExponentialPrior(1)), "StratModel")
})

test_that("a prior whose quantile function cannot be evaluated is not rejected", {
  # `.CheckGapPriorSupport()` must not newly error on a custom `Prior()` whose
  # `Q` is unusable; it can only rule *out* negative support, never assert it.
  opaque <- Prior(function(n, a) rexp(n, a),
                  function(x, a, log = FALSE) dexp(x, a, log = log),
                  function(p, a) stop("no quantile function"), a = 1)
  expect_true(.CheckGapPriorSupport(MakeGapPriors(opaque)))
})

test_that("overlapping partitions warn rather than silently picking one height", {
  # A negative gap is now unreachable through `priors`, but a hand-supplied
  # `parameters` vector still reaches `.CalculateRefHeightToHeights()`.
  data("stratPosterior3", package = "StratoBayes")
  pars <- ExtractParameters(stratPosterior3)[1, ]
  pars[["gap_2_1"]] <- -1
  # At this draw partitions 1 and 3 of site 2 span [-2.551, -1.447] and
  # [-2.447, -1.129], so -2.0 lies inside both and the two invert to heights
  # ~1.5 units apart. The constant is fixture-dependent: the shipped
  # `stratPosterior3` was regenerated since this test was written, and the
  # original -1.3 now falls in partition 3 alone.
  expect_warning(Tops(stratPosterior3, refHeights = -2.0, parameters = pars),
                 "overlap in age")

  # a genuine shared boundary must not trip the warning: sweep the reference
  # site's whole range at the unmodified draw
  expect_no_warning(
    Tops(stratPosterior3, refHeights = seq(-5, 0, by = 0.01))
  )
})
