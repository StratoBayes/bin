# GH #1168: the overlay `par()` at the end of TopsPlot() is unconditional, so
# with `overridePar = FALSE` (no capture/restore) it leaked into the caller's
# device.

.ParState <- function() par(c("mfrow", "mar", "fig", "xaxt", "yaxt", "xpd"))

test_that("TopsPlot(overridePar = FALSE) leaves par() untouched", {
  skip_if_not_installed("grDevices")
  data("stratPosterior1", package = "StratoBayes")
  f <- tempfile(fileext = ".png")
  grDevices::png(f)
  on.exit({
    grDevices::dev.off()
    unlink(f)
  }, add = TRUE)

  par(mfrow = c(1, 3))
  before <- .ParState()
  invisible(TopsPlot(stratPosterior1, overridePar = FALSE, display = TRUE))
  expect_equal(.ParState(), before)
})

test_that("TopsPlot(overridePar = TRUE) still restores par()", {
  data("stratPosterior1", package = "StratoBayes")
  f <- tempfile(fileext = ".png")
  grDevices::png(f)
  on.exit({
    grDevices::dev.off()
    unlink(f)
  }, add = TRUE)

  par(mfrow = c(1, 3))
  before <- .ParState()
  invisible(TopsPlot(stratPosterior1, overridePar = TRUE, display = TRUE))
  expect_equal(.ParState(), before)
})
