# #1433, #1434, #1435, #1436, #1437: posterior summary / ESS / cache bugs
# that all live in R/StratPosterior.R's summary() and ExtractIterations.R's
# maxSamples-decimation machinery.

# ─────────────────────────────────────────────────────────────────────────
# Shared fixture: one small signalOffsets = TRUE, 2-run posterior, built once
# and reused by every test below -- MCMC diagnostic counts are nondeterministic
# across separate model constructions, and #1434 specifically needs offsets.
# ─────────────────────────────────────────────────────────────────────────
.Area10cFixture <- local({
  cached <- NULL
  function() {
    if (!is.null(cached)) return(cached)
    set.seed(4827)
    n <- 30
    h <- seq(0, 10, length.out = n)
    sig <- data.frame(
      site   = c(rep("site_1", n), rep("site_2", n)),
      height = c(h, h),
      value  = c(sin(h) + rnorm(n, 0, 0.1),
                 sin(h) + 2 + rnorm(n, 0, 0.1))
    )
    grp <- data.frame(site = c("site_1", "site_2"), group = c("A", "B"),
                      stringsAsFactors = FALSE)
    d <- StratData(signal = sig, group = grp)
    m <- StratModel(d, priors = NULL, alignmentScale = "height",
                    sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                    sigmaFixed = FALSE)
    post <- suppressWarnings(RunStratModel(
      stratObject = d, stratModel = m,
      nIter = 100, nChains = 2, nRun = 2, nThreads = 2L,
      convergenceStop = FALSE, engine = "cpp", quiet = TRUE
    ))
    cached <<- post
    post
  }
})

# ══════════════════════════════════════════════════════════════════════════
# #1434: signalOffsets = TRUE parameters missing from summary, R-hat, AutoBurnIn
# ══════════════════════════════════════════════════════════════════════════

test_that("#1434: delta_*/tau_* appear in summary() with sane values", {
  post <- .Area10cFixture()
  s <- suppressWarnings(summary(post, burnIn = 0))
  rn <- rownames(s[["alignment1"]][["summary"]])
  deltaRows <- grep("^delta_", rn, value = TRUE)
  tauRows <- grep("^tau_", rn, value = TRUE)

  expect_gt(length(deltaRows), 0)
  expect_gt(length(tauRows), 0)

  deltaMean <- s[["alignment1"]][["summary"]][deltaRows, "mean"]
  tauMean <- s[["alignment1"]][["summary"]][tauRows, "mean"]
  expect_true(all(is.finite(deltaMean)))
  expect_true(all(is.finite(tauMean)))
  # Not merely present but degenerate: the simulated 2-unit inter-site shift
  # should show up as a real, non-trivial signed offset, not sit at 0.
  expect_true(any(abs(deltaMean) > 0.1))
})

test_that("#1434: delta_*/tau_* appear in R-hat", {
  post <- .Area10cFixture()
  s <- suppressWarnings(summary(post, burnIn = 0))
  psrfNames <- names(s[["general"]][["psrf"]])
  offsetPsrf <- s[["general"]][["psrf"]][grepl("^delta_|^tau_", psrfNames)]

  expect_gt(length(offsetPsrf), 0)
  expect_true(all(is.finite(offsetPsrf)))
})

test_that("#1434: delta_*/tau_* are checked for convergence by AutoBurnIn", {
  post <- .Area10cFixture()
  draws <- .AutoBurnInDraws(post)
  dn <- colnames(draws[["drawList"]][[1]])

  expect_true(any(grepl("^delta_", dn)))
  expect_true(any(grepl("^tau_", dn)))
})

# ══════════════════════════════════════════════════════════════════════════
# #1435: ess/multiESS order-dependence and concatenation bias
# ══════════════════════════════════════════════════════════════════════════

# Two runs of very different length with a huge mean shift between them: a
# run-boundary seam this large dominates a naive pooled autocorrelation
# estimate, matching the mechanism AutoBurnIn.R's own docstring describes
# (R/AutoBurnIn.R:31-35): "joining runs injects a discontinuity at each seam
# and charges between-run disagreement to autocorrelation."
.Area10cEssFixture <- function() {
  post <- .Area10cFixture()
  target1 <- post[["model"]][["parametersNames"]][[1]]
  target2 <- post[["model"]][["parametersNames"]][[2]]
  n1 <- 30L
  n2 <- 70L

  set.seed(1)
  post2 <- post
  post2[["samples"]][seq_len(n1), target1, 1, "chain1"] <- rnorm(n1, 0, 1)
  post2[["samples"]][seq_len(n2), target1, 2, "chain1"] <- rnorm(n2, 40, 1)
  post2[["samples"]][seq_len(n1), target2, 1, "chain1"] <- rnorm(n1, 0, 1)
  post2[["samples"]][seq_len(n2), target2, 2, "chain1"] <- rnorm(n2, -40, 1)
  post2[["mcmcSummary"]][["completedIter"]] <- c(n1, n2)
  post2[["mcmcSummary"]][["saveIter"]][[1]] <-
    post2[["mcmcSummary"]][["saveIter"]][[1]][seq_len(n1)]
  post2[["mcmcSummary"]][["saveIter"]][[2]] <-
    post2[["mcmcSummary"]][["saveIter"]][[2]][seq_len(n2)]
  post2[["mcmcSummary"]][["completedIterIndex"]] <- c(n1, n2)

  list(post = post2, target1 = target1, target2 = target2)
}

test_that("#1435: ExtractParameters()'s run concatenation is itself order-sensitive", {
  # Establishes the mechanism directly: do.call(rbind, ...) over runs in a
  # different order hands .EssFunc() a genuinely different sequence, so its
  # estimate moves with it -- the seam this creates is what summary()'s fix
  # has to avoid relying on.
  fx <- .Area10cEssFixture()
  sr <- ExtractIterations(fx[["post"]], alignment = "all", burnIn = 0,
                          maxSamples = Inf, runs = "all")
  p12 <- ExtractParameters(fx[["post"]], parameters = fx[["target1"]],
                           runs = c(1, 2), selectRows = sr)
  p21 <- ExtractParameters(fx[["post"]], parameters = fx[["target1"]],
                           runs = c(2, 1), selectRows = sr)

  expect_false(identical(p12[[1]], p21[[1]]))
  expect_false(isTRUE(all.equal(.EssFunc(p12[[1]]), .EssFunc(p21[[1]]))))
})

test_that("#1435: summary()'s pooled ess equals the sum of each run's own ess", {
  # The actual user-visible bug: pre-fix, summary()'s `ess` for the pooled
  # runs is the ess of the concatenated (seamed) sequence, not the sum of
  # each run's own ess -- and the two differ hugely under this fixture
  # (verified against the pre-fix code: ~3.8 concatenated vs. ~99.8 summed).
  fx <- .Area10cEssFixture()
  post2 <- fx[["post"]]
  target <- fx[["target1"]]

  sPooled <- suppressWarnings(summary(post2, runs = c(1, 2), burnIn = 0,
                                       maxSamples = Inf, alignment = "none"))
  s1 <- suppressWarnings(summary(post2, runs = 1, burnIn = 0,
                                  maxSamples = Inf, alignment = "none"))
  s2 <- suppressWarnings(summary(post2, runs = 2, burnIn = 0,
                                  maxSamples = Inf, alignment = "none"))

  essPooled <- sPooled[["alignmentAll"]][["summary"]][target, "ess"]
  essSum <- s1[["alignmentAll"]][["summary"]][target, "ess"] +
    s2[["alignmentAll"]][["summary"]][target, "ess"]

  expect_equal(essPooled, essSum)
  # A weak oracle (`expect_equal` alone) would also pass if both sides were
  # trivially the same tiny concatenated value -- pin that the shared value
  # is actually the large, correct (summed, non-seamed) one.
  expect_gt(essPooled, 50)
})

test_that("#1435: summary()'s pooled multiESS equals the sum of each run's own multiESS", {
  skip_if_not_installed("mcmcse")
  fx <- .Area10cEssFixture()
  post2 <- fx[["post"]]

  sPooled <- suppressWarnings(summary(post2, runs = c(1, 2), burnIn = 0,
                                       maxSamples = Inf, alignment = "none"))
  s1 <- suppressWarnings(summary(post2, runs = 1, burnIn = 0,
                                  maxSamples = Inf, alignment = "none"))
  s2 <- suppressWarnings(summary(post2, runs = 2, burnIn = 0,
                                  maxSamples = Inf, alignment = "none"))

  multiPooled <- sPooled[["alignmentAll"]][["multiESS"]]
  multiSum <- s1[["alignmentAll"]][["multiESS"]] + s2[["alignmentAll"]][["multiESS"]]

  expect_equal(multiPooled, multiSum)
  expect_gt(multiPooled, 50)
})

# ══════════════════════════════════════════════════════════════════════════
# #1436: a run allocated exactly one maxSamples row
# ══════════════════════════════════════════════════════════════════════════

test_that("#1436: a run allocated exactly one row gets the midpoint, not the first", {
  # rowCounts = 10, maxIterations = 1 forces baseRowsPerRun = 1 for the only
  # run -- seq(1, 10, length.out = 1) returns 1 (the sequence's first value),
  # systematically the least-equilibrated draw available pre-fix.
  selectRows <- list(1:10)
  out <- .maxSampleDeterministicRows(selectRows, 1L)

  expect_identical(out[[1]], 6L)
  expect_false(identical(out[[1]], 1L))
})

test_that("#1436: multi-run allocation only changes the run(s) landing on exactly one row", {
  # run 1 gets many rows (unaffected by the fix); run 2's tiny share floors
  # to exactly one.
  selectRows <- list(1:190, 1:10)
  out <- .maxSampleDeterministicRows(selectRows, 20L)

  expect_length(out[[2]], 1L)
  expect_identical(out[[2]], 6L)
  expect_gt(length(out[[1]]), 1L)
})

# ══════════════════════════════════════════════════════════════════════════
# #1437: ess capped at maxSamples, now documented
# ══════════════════════════════════════════════════════════════════════════

test_that("#1437: the maxSamples cap on ess is documented", {
  # R CMD check runs tests against the INSTALLED package, where `man/` isn't
  # a plain file on disk -- fall back to the installed Rd database so this
  # still runs (rather than silently skipping) under that layout.
  rdFile <- testthat::test_path("..", "..", "man", "summary.StratPosterior.Rd")
  if (file.exists(rdFile)) {
    # Raw text, not tools::parse_Rd()/Rd2txt(): the file's \insertCite{}
    # macros are Rdpack-only and unregistered outside the full Rd render
    # pipeline, so parsing here would warn on content unrelated to this check.
    rdText <- paste(readLines(rdFile, warn = FALSE), collapse = "\n")
  } else {
    skip_if_not_installed("StratoBayes")
    db <- tools::Rd_db("StratoBayes")
    key <- grep("^summary\\.StratPosterior\\.Rd$", names(db), value = TRUE)
    skip_if(length(key) == 0, "summary.StratPosterior.Rd not in the installed Rd db")
    rdText <- paste(suppressWarnings(capture.output(
      tools::Rd2txt(db[[key[[1]]]], out = stdout()))), collapse = "\n")
  }

  # "capped" and "maxSamples" alone are each already present pre-fix (the
  # `maxSamples` parameter itself, and an unrelated pre-existing "capped at
  # the number of samples" sentence that never mentions maxSamples) -- so
  # only phrases distinctive to the actual addition can discriminate.
  expect_match(rdText, "is misleading", fixed = TRUE)
  expect_match(rdText, "decimation", fixed = TRUE)
})

# ══════════════════════════════════════════════════════════════════════════
# #1433: .PosteriorCache() surviving a saveRDS()/readRDS() round trip
#
# The original defect was fastmatch stamping the live samples. dimnames after
# load, desyncing them from the stamp. Nothing stamps since #1982; the round
# trip and the no-recompute guarantee are still worth pinning.
# ══════════════════════════════════════════════════════════════════════════

.Area10cCacheFixture <- function() {
  post <- .Area10cFixture()
  # Normalise to a known-good baseline: a fresh stamp matching the object's
  # current samples/model/data. (RunStratModel()'s own pipeline may already
  # have touched dimnames for unrelated reasons by this point, which would
  # otherwise contaminate the specific %in% mechanism under test here.)
  post[[".cache"]][["stamp"]] <- .PosteriorStamp(post)
  post
}

test_that("#1433: the cache survives a saveRDS()/readRDS() round trip", {
  post <- .Area10cCacheFixture()
  expect_false(is.null(.PosteriorCache(post)))

  tmp <- withr::local_tempfile(fileext = ".rds")
  saveRDS(post, tmp)
  reloaded <- readRDS(tmp)

  # Per the mechanism: identical() still passes immediately after load...
  expect_false(is.null(.PosteriorCache(reloaded)))

  # ...and stays valid through a call that reads dimnames(samples), which
  # pre-fix desynced the live object from the stamp captured at load time.
  invisible(ExtractParameters(reloaded, parameters = "prior", burnIn = 0))
  expect_false(is.null(.PosteriorCache(reloaded)))
})

test_that("#1433: a saveRDS()/readRDS()-ed posterior does not recompute its cache on repeat access", {
  post <- .Area10cCacheFixture()
  tmp <- withr::local_tempfile(fileext = ".rds")
  saveRDS(post, tmp)
  reloaded <- readRDS(tmp)

  # Prime the clustering cache once, then make a call that desynced the stamp
  # pre-fix.
  invisible(reloaded[["stratCluster"]])
  invisible(ExtractParameters(reloaded, parameters = "prior", burnIn = 0))

  # A counter local to this test_that() block is invisible to trace()'s
  # tracer expression, which evaluates in the traced function's own call
  # environment (the package namespace), not this block's -- so the counter
  # has to live somewhere that environment's `<<-` search can actually reach.
  counterEnv <- globalenv()
  assign(".rt1433Count", 0L, envir = counterEnv)
  on.exit(rm(".rt1433Count", envir = counterEnv), add = TRUE)
  trace("Cluster.StratPosterior",
       tracer = quote(assign(".rt1433Count",
                             get(".rt1433Count", envir = globalenv()) + 1L,
                             envir = globalenv())),
       print = FALSE, where = asNamespace("StratoBayes"))
  on.exit(untrace("Cluster.StratPosterior", where = asNamespace("StratoBayes")),
         add = TRUE)
  invisible(reloaded[["stratCluster"]])
  invisible(reloaded[["stratCluster"]])

  # Recomputation, not correctness, is the discriminator here -- a broken
  # cache still returns the right (deterministically-seeded) clustering, just
  # by recomputing it every time instead of once.
  expect_identical(get(".rt1433Count", envir = counterEnv), 0L)
})
