# GH #1169: `TopsPlot()` clamps a StratMap-derived reference height to the
# reference site's range, but drew the reference site's own panel from the
# *unclamped* value, and recovered the horizon index by matching that value --
# so two heights clamped to the same bound both matched the first index.

test_that("an out-of-range reference height is clamped consistently, with a warning", {
  data("stratPosterior1", package = "StratoBayes")

  expect_warning(
    res <- TopsPlot(stratPosterior1, refHeights = 2.19, refHeightsSite = 2,
                    display = FALSE),
    "outside the reference site"
  )

  refSite <- levels(res$site)[1]
  medianTop <- function(site) {
    res$top[res$site == site & res$quantile == 0.5]
  }
  # every panel must draw the horizon at the same reference height
  expect_equal(medianTop(refSite), 10)
})

test_that("two reference heights clamping to the same bound stay distinct horizons", {
  data("stratPosterior1", package = "StratoBayes")

  expect_warning(
    res <- TopsPlot(stratPosterior1, refHeights = c(2.18, 2.19),
                    refHeightsSite = 2, display = FALSE),
    "outside the reference site"
  )

  expect_setequal(unique(res$refHeight), c(2.18, 2.19))
  # one row per (site, horizon, quantile): the two horizons must be represented
  # equally, not collapsed onto the first
  expect_equal(unname(table(res$refId)[["1"]]), unname(table(res$refId)[["2"]]))
  expect_equal(res$refHeight, c(2.18, 2.19)[res$refId])
})

test_that("in-range reference heights neither warn nor change", {
  data("stratPosterior1", package = "StratoBayes")
  expect_no_warning(
    res <- TopsPlot(stratPosterior1, refHeights = c(0.5, 1), refHeightsSite = 2,
                    display = FALSE)
  )
  expect_setequal(unique(res$refHeight), c(0.5, 1))
})
