# RT-181 / RT-023 / RT-116: `.sb_logpost` (src/LogPost.cpp) dispatches
# TruncLogNormalPrior through a CLOSED-interval bounds check (`x <= lower ||
# x >= upper`), rejecting the boundary itself, while the sibling
# TruncNormalPrior and the R reference (TruncLogNormDensity()) both use an
# OPEN check (`x < lower || x > upper`) that accepts it. A parameter sitting
# exactly on a truncation boundary therefore got -Inf from the C++ engine but
# a finite density everywhere else. Fixed by aligning TruncLogNormalPrior to
# the same open-interval convention (LogPost.cpp, MCMCEngine.cpp x2,
# Gradient_impl.h).
#
# `.sb_logpost()` is called directly with a single metro parameter and no
# signal/overlap components (empty B_list/beta_list/signalValues, sigma of
# length 0, overlapPenalty = FALSE), isolating the prior computation from the
# rest of the log-posterior.

.sb_logpost_prior_only <- function(x, priorType, priorArgs) {
  StratoBayes:::.sb_logpost(
    x                    = x,
    priorTypes           = priorType,
    priorArgs            = list(priorArgs),
    rCustomFns           = list(),
    B_list               = list(),
    beta_list            = list(),
    signalValues         = list(),
    sigma                = numeric(0),
    overlapPenalty        = FALSE,
    signalSectionOverlap = list(),
    adjustments           = list(),
    overlapWeights        = list()  # sedSmooth added this arg to .sb_logpost
  )
}

test_that(".sb_logpost gives a finite TruncLogNormalPrior density at the upper bound", {
  meanlog <- 0
  sdlog   <- 1
  lower   <- 0.1
  upper   <- 2

  cpp <- .sb_logpost_prior_only(upper, "TruncLogNormalPrior",
                                list(meanlog = meanlog, sdlog = sdlog,
                                     min = lower, max = upper))

  r_ref <- TruncLogNormDensity(upper, meanlog, sdlog, min = lower, max = upper,
                               log = TRUE)

  expect_true(is.finite(cpp[1]))
  expect_equal(cpp[1], r_ref, tolerance = 1e-10)
})

test_that(".sb_logpost gives a finite TruncLogNormalPrior density at the lower bound", {
  meanlog <- 0
  sdlog   <- 1
  lower   <- 0.1
  upper   <- 2

  cpp <- .sb_logpost_prior_only(lower, "TruncLogNormalPrior",
                                list(meanlog = meanlog, sdlog = sdlog,
                                     min = lower, max = upper))

  r_ref <- TruncLogNormDensity(lower, meanlog, sdlog, min = lower, max = upper,
                               log = TRUE)

  expect_true(is.finite(cpp[1]))
  expect_equal(cpp[1], r_ref, tolerance = 1e-10)
})

test_that("TruncLogNormalPrior and TruncNormalPrior agree on boundary inclusion", {
  # Same relative construction: x sits exactly at `upper` for both prior
  # families. TruncNormalPrior has always used the open-interval (inclusive)
  # convention; TruncLogNormalPrior must now match it.
  meanlog <- 0
  sdlog <- 1
  lower <- 0.1
  upper <- 2

  cpp_ln <- .sb_logpost_prior_only(upper, "TruncLogNormalPrior",
                                   list(meanlog = meanlog, sdlog = sdlog,
                                        min = lower, max = upper))
  cpp_n <- .sb_logpost_prior_only(upper, "TruncNormalPrior",
                                  list(mean = meanlog, sd = sdlog,
                                       lower = lower, upper = upper))

  expect_true(is.finite(cpp_ln[1]))
  expect_true(is.finite(cpp_n[1]))
})

test_that("outside the truncation bounds still returns the -1e30 sentinel", {
  meanlog <- 0
  sdlog <- 1
  lower <- 0.1
  upper <- 2

  above <- .sb_logpost_prior_only(upper + 1e-6, "TruncLogNormalPrior",
                                  list(meanlog = meanlog, sdlog = sdlog,
                                       min = lower, max = upper))
  below <- .sb_logpost_prior_only(lower - 1e-6, "TruncLogNormalPrior",
                                  list(meanlog = meanlog, sdlog = sdlog,
                                       min = lower, max = upper))

  expect_equal(above[1], -1e30)
  expect_equal(below[1], -1e30)
})
