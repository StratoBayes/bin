# summary.StratPosterior works with single cluster

    Code
      summary(stratPosterior1)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 30%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01496
        alpha_site_3    1.01033
        gammaLog_site_2 1.01172
        gammaLog_site_3 1.01591
        lambda_value    1.00854
        log prior       1.01117
        log likelihood  1.00492
        log posterior   1.00141
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 300 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 287.9
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.25186 0.0652973   6.13232   6.20805   6.25044   6.28599
      alpha_site_3      1.72747  0.116446   1.51700   1.64466   1.72934   1.81641
      gammaLog_site_2 -0.684502 0.0476176 -0.774690 -0.716116 -0.680719 -0.651796
      gammaLog_site_3  0.128863 0.0422487 0.0552986 0.0975720  0.126434  0.156633
      lambda_value      2.13564  0.865657  0.902249   1.51479   2.00227   2.50541
      log prior        -111.096   2.30732  -115.742  -112.765  -111.212  -109.701
      log likelihood    149.242   2.28695   144.316   147.829   149.506   151.026
      log posterior     38.1457   1.71736   34.2700   37.3067   38.4228   39.3555
                          97.5%     ess
      alpha_site_2      6.38893 203.019
      alpha_site_3      1.91833 227.240
      gammaLog_site_2 -0.596833 193.880
      gammaLog_site_3  0.209139 259.793
      lambda_value      4.10083 246.667
      log prior        -106.659 232.198
      log likelihood    153.017 232.285
      log posterior     40.6398 274.433
      

# print.summary.StratPosterior works with change sigDigits

    Code
      print(summary(stratPosterior1), sigDigits = 2)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 30%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.0
        alpha_site_3    1.0
        gammaLog_site_2 1.0
        gammaLog_site_3 1.0
        lambda_value    1.0
        log prior       1.0
        log likelihood  1.0
        log posterior   1.0
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 300 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 287.9
                          mean      sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2         6.3 6.5e-02      6.1      6.2      6.3      6.3      6.4
      alpha_site_3         1.7    0.12      1.5      1.6      1.7      1.8      1.9
      gammaLog_site_2    -0.68 4.8e-02    -0.77    -0.72    -0.68    -0.65    -0.60
      gammaLog_site_3     0.13 4.2e-02  5.5e-02  9.8e-02     0.13     0.16     0.21
      lambda_value         2.1    0.87     0.90      1.5      2.0      2.5      4.1
      log prior       -1.1e+02     2.3 -1.2e+02 -1.1e+02 -1.1e+02 -1.1e+02 -1.1e+02
      log likelihood   1.5e+02     2.3  1.4e+02  1.5e+02  1.5e+02  1.5e+02  1.5e+02
      log posterior         38     1.7       34       37       38       39       41
                          ess
      alpha_site_2      2e+02
      alpha_site_3    2.3e+02
      gammaLog_site_2 1.9e+02
      gammaLog_site_3 2.6e+02
      lambda_value    2.5e+02
      log prior       2.3e+02
      log likelihood  2.3e+02
      log posterior   2.7e+02
      

# summary.StratPosterior works with two clusters

    Code
      summary(stratPosterior5a, stratCluster = bimodal)
    Output
      
      Posterior of stratigraphic model from 3 runs after 10000 iterations:
      
        Total samples: 1203 (401 per run).
        Statistics summarise 429 samples (126 to 156 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site2    1.09362
        gammaLog_site2 1.00573
        lambda_value   1.00164
        log prior      1.00747
        log likelihood 0.99723
        log posterior  0.99937
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 245 samples (57.1%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 245
                         mean        sd     2.5%      25%      50%      75%    97.5%
      alpha_site2     9.43655 0.0349414  9.37712  9.41134  9.43689  9.45932  9.50659
      gammaLog_site2 0.895111 0.0180694 0.859432 0.882466 0.896117 0.908545 0.926976
      lambda_value    1.41115  0.472130 0.667572  1.11331  1.33990  1.64759  2.58757
      log prior      -188.530   1.27079 -190.188 -188.880 -188.857 -187.571 -186.271
      log likelihood  329.468   1.57293  325.305  328.499  329.860  330.681  331.373
      log posterior   140.938   1.05857  138.652  140.300  141.103  141.753  142.464
                         ess
      alpha_site2    232.853
      gammaLog_site2 219.059
      lambda_value   232.964
      log prior      235.682
      log likelihood 199.150
      log posterior  169.925
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 177 samples (41.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 177
                         mean        sd     2.5%      25%      50%      75%    97.5%
      alpha_site2     15.7271 0.0387258  15.6664  15.7009  15.7242  15.7527  15.8086
      gammaLog_site2 0.897044 0.0173504 0.860622 0.886944 0.897985 0.907518 0.935437
      lambda_value    1.46031  0.490288 0.625756  1.13012  1.34879  1.77829  2.35344
      log prior      -188.737   1.36248 -191.448 -188.884 -188.859 -187.588 -185.518
      log likelihood  329.593   1.70704  325.321  328.899  330.066  330.930  331.469
      log posterior   140.856   1.30552  137.355  140.160  141.096  141.817  142.519
                         ess
      alpha_site2    157.603
      gammaLog_site2 174.854
      lambda_value   165.618
      log prior      167.908
      log likelihood 172.019
      log posterior  165.135
      
      Summary statistics for 7 samples (1.6%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 7
                         mean        sd     2.5%      25%      50%      75%    97.5%
      alpha_site2     13.0365   3.34521  9.42463  9.48158  15.6336  15.7312  15.7709
      gammaLog_site2 0.887165 0.0486603 0.845890 0.847419 0.852290 0.937038 0.942317
      lambda_value    1.31398  0.497790 0.725850 0.871840  1.37858  1.71717  1.90256
      log prior      -187.762   3.53074 -192.531 -190.821 -184.999 -184.990 -184.988
      log likelihood  326.110   3.03449  323.275  323.688  324.328  328.942  329.900
      log posterior   138.349  0.705326  137.304  138.089  138.340  138.698  139.287
                         ess
      alpha_site2    7.00000
      gammaLog_site2 7.00000
      lambda_value   7.00000
      log prior      7.00000
      log likelihood 7.00000
      log posterior  7.00000
      

# summary.StratPosterior works with no burn-in

    Code
      summary(stratPosterior2, burnIn = 0)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 804 samples (201 per run), discarding no iterations as burn-in.
        The acceptance rate of proposals across the selected iterations was 22%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.00145
        alpha_site2    0.99940
        alpha_site3    1.01768
        gammaLog_site1 1.00791
        gammaLog_site2 1.00845
        gammaLog_site3 1.01756
        gap_site2_1    1.06056
        lambda_a       1.01086
        lambda_b       1.00387
        log prior      1.03504
        log likelihood 1.01242
        log posterior  1.01947
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 777 samples (96.6%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 721.7
                          mean        sd      2.5%        25%       50%      75%
      alpha_site1      13.8772   1.39479   11.1470    13.0419   13.8657  14.8283
      alpha_site2      29.7950  0.745660   28.3587    29.2761   29.7576  30.3154
      alpha_site3      44.1948   1.64064   41.1367    43.1163   44.1518  45.2207
      gammaLog_site1   1.38280 0.0760365   1.23581    1.33013   1.37698  1.43366
      gammaLog_site2   1.02100  0.100881  0.854079   0.955109   1.01328  1.07842
      gammaLog_site3 0.0406521  0.157253 -0.226567 -0.0684739 0.0335860 0.129027
      gap_site2_1      2.45593  0.930700  0.932073    1.77406   2.28596  3.01815
      lambda_a        0.452628  0.254999  0.116318   0.281176  0.395078 0.569793
      lambda_b        0.867807  0.522836  0.241335   0.494193  0.740922  1.08101
      log prior       -162.021   4.07967  -170.814   -164.265  -161.840 -159.479
      log likelihood  -275.251   4.37954  -285.074   -277.383  -274.610 -272.353
      log posterior   -437.272   3.68682  -444.625   -438.424  -436.708 -435.189
                        97.5%     ess
      alpha_site1     16.5759 403.138
      alpha_site2     31.2900 615.771
      alpha_site3     47.7637 595.805
      gammaLog_site1  1.53744 445.666
      gammaLog_site2  1.21708 297.531
      gammaLog_site3 0.365043 450.223
      gap_site2_1     4.46512 212.066
      lambda_a        1.17880 696.637
      lambda_b        2.19232 413.105
      log prior      -154.879 355.720
      log likelihood -269.339 562.993
      log posterior  -433.088 230.948
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 16 samples (2%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 16
                         mean        sd      2.5%       25%      50%      75%
      alpha_site1     13.5324   1.25936   11.5597   12.8247  13.6406  14.6040
      alpha_site2     30.0776  0.692694   28.8854   29.5260  30.2274  30.4384
      alpha_site3     18.2747  0.906710   16.7456   17.9721  18.3751  18.9471
      gammaLog_site1  1.34891 0.0682368   1.24465   1.30373  1.33714  1.39380
      gammaLog_site2 0.963694 0.0742191  0.827468  0.933953 0.976215  1.01273
      gammaLog_site3 0.694385  0.188300  0.328962  0.616765 0.764428 0.824004
      gap_site2_1     2.81333  0.730000   1.70024   2.27124  2.99198  3.38077
      lambda_a       0.141431 0.0982874 0.0511494 0.0749883 0.142787 0.163996
      lambda_b        1.01941  0.463384  0.332366  0.625888  1.15763  1.39708
      log prior      -174.590   3.11402  -180.513  -176.234 -173.909 -172.986
      log likelihood -274.017   3.88471  -282.890  -275.609 -272.821 -271.275
      log posterior  -448.607   3.74121  -456.883  -449.707 -447.376 -446.271
                        97.5%     ess
      alpha_site1     15.2047 9.58338
      alpha_site2     31.2696 13.1307
      alpha_site3     19.3387 9.54543
      gammaLog_site1  1.47172 10.3741
      gammaLog_site2  1.05381 10.0915
      gammaLog_site3 0.933677 10.8647
      gap_site2_1     3.78461 16.0000
      lambda_a       0.356774 13.4918
      lambda_b        1.69780 15.8460
      log prior      -169.677 16.0000
      log likelihood -270.459 11.1859
      log posterior  -444.697 5.74156
      
      Summary statistics for 11 samples (1.4%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 11
                          mean        sd         2.5%          25%       50%
      alpha_site1      13.8485   4.02826      8.44503      9.76555   16.7160
      alpha_site2      29.1730   4.28613      21.2510      28.2260   29.1734
      alpha_site3      27.1282   8.61216      14.8744      20.8870   24.2471
      gammaLog_site1   1.48188  0.344307     0.965458      1.15824   1.61710
      gammaLog_site2   1.36267  0.374562     0.772339      1.17908   1.33237
      gammaLog_site3  0.873918  0.314346     0.497839     0.584550  0.917203
      gap_site2_1      2.66943   1.95162     0.280930      1.60708   2.13112
      lambda_a       0.0658239 0.0839090 0.0000100000 0.0000100000 0.0526803
      lambda_b        0.519721  0.652857 0.0000100000 0.0000100000  0.373560
      log prior       -193.252   34.9746     -268.033     -197.427  -177.462
      log likelihood  -542.297   397.339     -1330.14     -768.827  -291.652
      log posterior   -735.549   412.084     -1516.39     -1025.79  -475.598
                           75%    97.5%     ess
      alpha_site1      17.0987  17.9256 9.62654
      alpha_site2      30.5803  35.6246 11.0000
      alpha_site3      33.7632  38.2717 10.0562
      gammaLog_site1   1.67749  1.97260 11.0000
      gammaLog_site2   1.53752  1.95329 10.3893
      gammaLog_site3   1.09397  1.36489 10.0463
      gap_site2_1      3.67859  5.93797 11.0000
      lambda_a       0.0847995 0.239620 11.0000
      lambda_b        0.633458  1.90389 10.5009
      log prior       -173.645 -167.795 9.61479
      log likelihood  -282.902 -275.848 11.0000
      log posterior   -454.337 -449.895 11.0000
      

# summary.StratPosterior works with iteration burn-in

    Code
      summary(stratPosterior1, burnIn = 4900)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 12 samples (4 per run), after discarding the first 98% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 25%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    NA
        alpha_site_3    NA
        gammaLog_site_2 NA
        gammaLog_site_3 NA
        lambda_value    NA
        log prior       NA
        log likelihood  NA
        log posterior   NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 2 draws and at least 4 are needed (retained draws per run: 4, 4, 4).
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 12 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 12
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.24903 0.0743613   6.15255   6.19881   6.22573   6.28967
      alpha_site_3      1.76752  0.118092   1.58646   1.66728   1.78114   1.86176
      gammaLog_site_2 -0.689065 0.0362720 -0.754311 -0.707710 -0.683349 -0.669095
      gammaLog_site_3  0.151215 0.0380097 0.0937487  0.121147  0.162564  0.177796
      lambda_value      1.85370  0.819877  0.923039   1.29436   1.87385   2.07221
      log prior        -112.115   2.18278  -115.358  -113.152  -112.730  -110.829
      log likelihood    149.639   2.19828   145.749   148.457   150.117   151.170
      log posterior     37.5237   1.27015   35.4411   36.9347   37.5495   38.4109
                          97.5%     ess
      alpha_site_2      6.37807 11.3545
      alpha_site_3      1.92650 12.0000
      gammaLog_site_2 -0.639580 11.4425
      gammaLog_site_3  0.197629 12.0000
      lambda_value      3.50813 11.6940
      log prior        -108.617 12.0000
      log likelihood    152.392 12.0000
      log posterior     39.5099 10.7708
      

# summary.StratPosterior works with iterations

    Code
      summary(stratPosterior2, iterations = 500:800)
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 28 samples (7 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 14%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    NA
        alpha_site2    NA
        alpha_site3    NA
        gammaLog_site1 NA
        gammaLog_site2 NA
        gammaLog_site3 NA
        gap_site2_1    NA
        lambda_a       NA
        lambda_b       NA
        log prior      NA
        log likelihood NA
        log posterior  NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 3 draws and at least 4 are needed (retained draws per run: 7, 7, 7, 7).
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 21 samples (75%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 21
                         mean        sd      2.5%        25%      50%      75%
      alpha_site1     13.8740   1.87119   10.0595    13.1628  14.0110  15.3309
      alpha_site2     29.9436  0.692562   29.0173    29.5259  29.8158  30.4414
      alpha_site3     43.6136   1.77421   40.6118    42.4148  42.9576  45.2866
      gammaLog_site1  1.38395 0.0999795   1.19473    1.34706  1.38213  1.47241
      gammaLog_site2  1.04534 0.0978523  0.862712   0.987670  1.04717  1.14558
      gammaLog_site3 0.131237  0.224041 -0.156703 -0.0719248 0.102730 0.229493
      gap_site2_1     2.75248   1.49692  0.801797    1.64823  2.03595  4.08858
      lambda_a       0.390539  0.233991 0.0996604   0.254894 0.395388 0.525351
      lambda_b       0.828084  0.666209  0.196732   0.380616 0.532303  1.08905
      log prior      -163.356   5.90273  -172.533   -166.197 -164.904 -160.224
      log likelihood -276.114   4.07476  -284.129   -279.117 -275.039 -273.174
      log posterior  -439.470   4.00641  -445.968   -442.227 -438.621 -436.797
                        97.5%     ess
      alpha_site1     16.4618 18.2629
      alpha_site2     31.2728 19.2615
      alpha_site3     45.9160 17.3936
      gammaLog_site1  1.51863 19.5569
      gammaLog_site2  1.18540 18.2170
      gammaLog_site3 0.565233 17.6424
      gap_site2_1     5.20272 18.9683
      lambda_a       0.832814 17.3194
      lambda_b        2.43736 19.1287
      log prior      -153.077 17.0959
      log likelihood -270.794 20.2896
      log posterior  -434.050 16.4694
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 7 samples (25%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 7
                         mean        sd      2.5%       25%       50%      75%
      alpha_site1     14.5188   1.19780   13.3423   13.6640   14.3659  14.9516
      alpha_site2     29.9803  0.559712   29.0798   29.7353   30.1412  30.2927
      alpha_site3     18.9665  0.700983   18.3071   18.4563   18.9407  19.1461
      gammaLog_site1  1.41505  0.113149   1.32399   1.33638   1.38314  1.44524
      gammaLog_site2  1.00938 0.0744271  0.940184  0.970194  0.984976  1.02189
      gammaLog_site3 0.792666  0.150310  0.624734  0.689957  0.776726 0.876784
      gap_site2_1     2.61257  0.840094   1.68460   1.76343   2.95838  3.31350
      lambda_a       0.102614 0.0450048 0.0546171 0.0707207 0.0788581 0.142780
      lambda_b       0.890479  0.530226  0.296228  0.455450  0.732439  1.39841
      log prior      -172.606   3.70163  -176.899  -175.022  -172.942 -170.839
      log likelihood -274.015   4.23301  -281.800  -274.202  -272.791 -271.809
      log posterior  -446.620   1.78778  -449.324  -447.694  -446.124 -445.368
                        97.5%     ess
      alpha_site1     16.5304 6.46808
      alpha_site2     30.6104 7.00000
      alpha_site3     20.1697 6.61069
      gammaLog_site1  1.61393 7.00000
      gammaLog_site2  1.14302 7.00000
      gammaLog_site3  1.00656 7.00000
      gap_site2_1     3.48663 7.00000
      lambda_a       0.159382 7.00000
      lambda_b        1.48670 7.00000
      log prior      -167.055 6.52599
      log likelihood -270.533 7.00000
      log posterior  -444.608 7.00000
      

# summary.StratPosterior works with unassigned iterations

    Code
      summary(stratPosterior2, iterations = 1:100, runs = 4)
    Output
      
      Posterior of stratigraphic model from 1 run after 10000 iterations:
      
        Total samples: 201
        Statistics summarise 3 samples (3 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 0%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    NA
        alpha_site2    NA
        alpha_site3    NA
        gammaLog_site1 NA
        gammaLog_site2 NA
        gammaLog_site3 NA
        gap_site2_1    NA
        lambda_a       NA
        lambda_b       NA
        log prior      NA
        log likelihood NA
        log posterior  NA
        NA: too few chain splits are available to compute a split-chain R-hat.
      
      Summary statistics for alignment 1 (of 1 alignments), comprising 3 samples (100%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 3
                         mean        sd       2.5%       25%      50%      75%
      alpha_site1     12.7829   3.76130    9.38046   10.8164  12.4118  14.5639
      alpha_site2     27.2904   6.19340    20.6795   25.1852  30.1914  30.8461
      alpha_site3     27.1203   18.7092    13.5910   16.4786  19.6870  34.0454
      gammaLog_site1  1.15884 0.0659587    1.10642   1.12212  1.13957  1.18593
      gammaLog_site2 0.920906  0.208265   0.743899  0.807888 0.878986  1.01296
      gammaLog_site3 0.656381  0.779090  -0.104366  0.280304 0.707715  1.05812
      gap_site2_1     5.06352  0.806518    4.50972   4.60162  4.70374  5.34553
      lambda_a       0.156142  0.157304 0.00770078 0.0769178 0.153826 0.234209
      lambda_b        1.35163   1.18516  0.0921030  0.920940  1.84187  2.02744
      log prior      -199.713   30.4678   -232.289  -209.390 -183.947 -182.153
      log likelihood -463.438   315.140   -800.370  -559.398 -291.652 -281.585
      log posterior  -663.151   345.597   -1032.66  -768.788 -475.598 -463.738
                        97.5%     ess
      alpha_site1     16.5008 3.00000
      alpha_site2     31.4353 3.00000
      alpha_site3     46.9679 3.00000
      gammaLog_site1  1.22766 3.00000
      gammaLog_site2  1.13354 3.00000
      gammaLog_site3  1.37349 3.00000
      gap_site2_1     5.92313 3.00000
      lambda_a       0.306553 3.00000
      lambda_b        2.19446 3.00000
      log prior      -180.539 3.00000
      log likelihood -272.525 3.00000
      log posterior  -453.064 3.00000
      

# summary.StratPosterior works with alignment 2

    Code
      summary(stratPosterior5a, alignment = 2)
    Output
      
      Posterior of stratigraphic model from 3 runs after 10000 iterations:
      
        Total samples: 1203 (401 per run).
        Statistics summarise 600 samples (200 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 20%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site2    1.06971
        gammaLog_site2 0.99936
        lambda_value   0.99941
        log prior      0.99911
        log likelihood 0.99922
        log posterior  0.99766
      
      Summary statistics for alignment 2 (of 3 alignments), comprising 181 samples (30.2%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 181
                         mean        sd     2.5%      25%      50%      75%    97.5%
      alpha_site2     15.7269 0.0391060  15.6584  15.7009  15.7243  15.7527  15.8080
      gammaLog_site2 0.896465 0.0184943 0.855117 0.885813 0.897920 0.907518 0.935759
      lambda_value    1.46314  0.488061 0.625846  1.13012  1.35292  1.79525  2.35259
      log prior      -188.683   1.43439 -191.448 -188.884 -188.858 -187.584 -185.004
      log likelihood  329.490   1.84229  324.962  328.603  330.031  330.891  331.466
      log posterior   140.808   1.33372  137.363  140.094  141.046  141.801  142.519
                         ess
      alpha_site2    169.893
      gammaLog_site2 175.772
      lambda_value   169.618
      log prior      173.829
      log likelihood 179.598
      log posterior  177.343
      

# summary.StratPosterior works with no clusters (all it)

    Code
      summary.StratPosterior(stratPosterior2, alignment = "none")
    Output
      
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
      
        Total samples: 804 (201 per run).
        Statistics summarise 400 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 24%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site1    1.02137
        alpha_site2    1.00277
        alpha_site3    1.00719
        gammaLog_site1 1.03269
        gammaLog_site2 1.03479
        gammaLog_site3 0.99966
        gap_site2_1    1.03476
        lambda_a       1.01093
        lambda_b       1.00155
        log prior      1.00662
        log likelihood 1.01045
        log posterior  0.99703
      
      Summary statistics for the posterior, comprising 400 samples:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 395
                          mean        sd      2.5%        25%       50%      75%
      alpha_site1      13.8666   1.30801   11.3849    13.0188   13.8870  14.7751
      alpha_site2      29.7601  0.762094   28.3281    29.2347   29.7065  30.2917
      alpha_site3      44.3512   1.58031   41.4479    43.3489   44.3409  45.3701
      gammaLog_site1   1.38146 0.0679665   1.26047    1.33099   1.37701  1.42754
      gammaLog_site2   1.00995 0.0857356  0.853728   0.953926   1.01042  1.06545
      gammaLog_site3 0.0202476  0.137696 -0.241828 -0.0719715 0.0243415 0.107163
      gap_site2_1      2.26274  0.810233   1.03261    1.68868   2.15626  2.69751
      lambda_a        0.463524  0.268887  0.145000   0.275797  0.400443 0.570953
      lambda_b        0.850440  0.514377  0.255129   0.509561  0.744600  1.03488
      log prior       -161.484   3.45284  -168.270   -163.804  -161.339 -159.313
      log likelihood  -275.305   3.90985  -285.443   -277.584  -274.548 -272.699
      log posterior   -436.789   2.50908  -442.582   -438.203  -436.489 -434.915
                        97.5%     ess
      alpha_site1     16.2500 230.898
      alpha_site2     31.2419 344.043
      alpha_site3     47.8026 340.253
      gammaLog_site1  1.52320 235.303
      gammaLog_site2  1.18460 236.356
      gammaLog_site3 0.279985 276.892
      gap_site2_1     4.21404 164.374
      lambda_a        1.19585 383.205
      lambda_b        2.09060 316.664
      log prior      -154.855 317.802
      log likelihood -269.729 297.959
      log posterior  -433.064 341.632
      

# summary.StratPosterior works with new cluster object and many clusters

    Code
      summary.StratPosterior(stratPosterior1, alignment = "all", stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 30%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01496
        alpha_site_3    1.01033
        gammaLog_site_2 1.01172
        gammaLog_site_3 1.01591
        lambda_value    1.00854
        log prior       1.01117
        log likelihood  1.00492
        log posterior   1.00141
      
      Summary statistics for alignment 1 (of 9 alignments), comprising 30 samples (10%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 30
                           mean         sd      2.5%       25%       50%       75%
      alpha_site_2      6.25952  0.0215924   6.20952   6.25123   6.26187   6.27407
      alpha_site_3      1.74970  0.0587504   1.63190   1.70846   1.75427   1.78690
      gammaLog_site_2 -0.677161 0.00871221 -0.695531 -0.680945 -0.677101 -0.673175
      gammaLog_site_3  0.131788  0.0152504  0.105332  0.121022  0.132331  0.144651
      lambda_value      1.96972   0.501930   1.23218   1.59999   1.81089   2.34139
      log prior        -111.467   0.796612  -112.728  -111.240  -111.215  -111.212
      log likelihood    151.281   0.547652   150.410   151.003   151.280   151.568
      log posterior     39.8138   0.704624   38.4851   39.3680   39.8362   40.2873
                          97.5%     ess
      alpha_site_2      6.28850 25.4115
      alpha_site_3      1.84872 26.2355
      gammaLog_site_2 -0.661952 26.2764
      gammaLog_site_3  0.159140 24.1609
      lambda_value      2.97453 25.9956
      log prior        -109.724 27.6614
      log likelihood    152.503 28.5237
      log posterior     40.8094 30.0000
      
      Summary statistics for alignment 2 (of 9 alignments), comprising 14 samples (4.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 14
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.26573 0.0198540   6.23683   6.24933   6.26718   6.28506
      alpha_site_3      1.62238 0.0461784   1.54689   1.57772   1.63731   1.65930
      gammaLog_site_2 -0.683233 0.0131236 -0.701808 -0.695949 -0.681435 -0.673376
      gammaLog_site_3 0.0765733 0.0148302 0.0516719 0.0627195 0.0836477 0.0866409
      lambda_value      2.38263  0.666609   1.39121   1.86548   2.41451   2.81675
      log prior        -108.968  0.990562  -110.752  -109.736  -108.215  -108.203
      log likelihood    149.147  0.935244   147.694   148.174   149.606   149.907
      log posterior     40.1789  0.846208   38.6822   39.8772   39.9962   40.4697
                          97.5%     ess
      alpha_site_2      6.28836 14.0000
      alpha_site_3      1.67726 12.9797
      gammaLog_site_2 -0.663078 12.8969
      gammaLog_site_3 0.0917323 14.0000
      lambda_value      3.41292 12.5418
      log prior        -108.191 11.8911
      log likelihood    150.199 12.6123
      log posterior     41.6856 14.0000
      
      Summary statistics for alignment 3 (of 9 alignments), comprising 12 samples (4%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 12
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.23168 0.0291910   6.19052   6.21069   6.23268   6.25623
      alpha_site_3      1.86970 0.0401253   1.78417   1.86187   1.87446   1.89128
      gammaLog_site_2 -0.714424 0.0109459 -0.732158 -0.722363 -0.714880 -0.704524
      gammaLog_site_3  0.185451 0.0114044  0.167003  0.176781  0.187502  0.195945
      lambda_value      1.87847   1.02353  0.703001   1.22128   1.64844   2.31645
      log prior        -114.158  0.425521  -114.301  -114.294  -114.276  -114.268
      log likelihood    152.460   1.04691   150.506   151.732   152.959   153.193
      log posterior     38.3015  0.969033   36.3238   37.9097   38.6804   38.9125
                          97.5%     ess
      alpha_site_2      6.26782 9.55737
      alpha_site_3      1.91654 11.5961
      gammaLog_site_2 -0.699691 9.05352
      gammaLog_site_3  0.199229 12.0000
      lambda_value      3.93275 12.0000
      log prior        -113.208 11.5972
      log likelihood    153.481 11.0466
      log posterior     39.2122 11.0568
      
      Summary statistics for alignment 4 (of 9 alignments), comprising 11 samples (3.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 11
                           mean         sd      2.5%       25%       50%       75%
      alpha_site_2      6.21440  0.0238813   6.18345   6.20519   6.20943   6.22149
      alpha_site_3      1.74306  0.0445812   1.66657   1.71967   1.75069   1.77611
      gammaLog_site_2 -0.757672 0.00696631 -0.766803 -0.761286 -0.759517 -0.753764
      gammaLog_site_3  0.149246  0.0125931  0.131944  0.136917  0.155212  0.160256
      lambda_value      2.56846   0.952762   1.30675   1.93374   2.46160   3.06426
      log prior        -113.111   0.907566  -114.353  -113.595  -112.835  -112.826
      log likelihood    151.034   0.849808   149.644   150.335   151.333   151.589
      log posterior     37.9236   0.930517   36.0427   37.5624   38.2053   38.5554
                          97.5%     ess
      alpha_site_2      6.26033 11.0000
      alpha_site_3      1.79670 10.3980
      gammaLog_site_2 -0.745068 11.0000
      gammaLog_site_3  0.161430 11.0000
      lambda_value      4.21590 11.0000
      log prior        -111.715 11.0000
      log likelihood    152.015 10.6048
      log posterior     38.7796 11.0000
      
      Summary statistics for alignment 5 (of 9 alignments), comprising 10 samples (3.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 10
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.22106 0.0221258   6.18642   6.20896   6.21990   6.24059
      alpha_site_3      1.66343 0.0503248   1.59693   1.63639   1.65314   1.68493
      gammaLog_site_2 -0.738029 0.0117391 -0.752547 -0.745448 -0.740791 -0.732486
      gammaLog_site_3 0.0974188 0.0195186 0.0806055 0.0855295 0.0881951  0.108241
      lambda_value      2.64936  0.985066   1.45008   1.98455   2.53036   2.87754
      log prior        -110.998   1.17362  -112.776  -111.317  -111.296  -109.807
      log likelihood    149.831   1.53641   146.999   149.540   149.750   150.466
      log posterior     38.8325   1.11361   36.8490   38.2447   39.0547   39.7943
                          97.5%     ess
      alpha_site_2      6.24788 10.0000
      alpha_site_3      1.74560 10.0000
      gammaLog_site_2 -0.719082 10.0000
      gammaLog_site_3  0.135462 10.0000
      lambda_value      4.51243 9.47530
      log prior        -109.798 10.0000
      log likelihood    152.070 10.0000
      log posterior     39.9705 10.0000
      
      Summary statistics for alignment 6 (of 9 alignments), comprising 8 samples (2.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 8
                           mean         sd      2.5%       25%       50%       75%
      alpha_site_2      6.22369  0.0353842   6.18864   6.19705   6.21521   6.24008
      alpha_site_3      1.65646  0.0254903   1.62461   1.64524   1.65544   1.65905
      gammaLog_site_2 -0.650732  0.0142516 -0.663946 -0.661864 -0.655572 -0.641940
      gammaLog_site_3  0.123421 0.00831725  0.111955  0.117427  0.123728  0.129970
      lambda_value      1.70622   0.574249   1.03249   1.12523   1.77964   2.14065
      log prior        -107.996   0.976987  -109.437  -108.198  -108.190  -107.798
      log likelihood    147.283   0.800991   145.864   147.058   147.375   147.643
      log posterior     39.2865    1.12860   37.6357   38.8165   39.1841   39.6438
                          97.5%     ess
      alpha_site_2      6.28275 8.00000
      alpha_site_3      1.70223 8.00000
      gammaLog_site_2 -0.628997 8.00000
      gammaLog_site_3  0.134110 8.00000
      lambda_value      2.43443 6.23844
      log prior        -106.655 8.00000
      log likelihood    148.277 7.27823
      log posterior     41.0452 8.00000
      
      Summary statistics for alignment 7 (of 9 alignments), comprising 7 samples (2.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 7
                           mean         sd      2.5%       25%       50%       75%
      alpha_site_2      6.29882  0.0387641   6.24276   6.28694   6.28951   6.31806
      alpha_site_3      1.87894  0.0289051   1.83290   1.87199   1.87390   1.89519
      gammaLog_site_2 -0.623205  0.0156284 -0.648575 -0.625831 -0.623783 -0.617136
      gammaLog_site_3  0.191843 0.00920065  0.180096  0.184196  0.193039  0.200000
      lambda_value      1.79214   0.607524  0.950128   1.36326   1.87944   2.25587
      log prior        -110.523   0.796798  -111.195  -111.157  -111.134  -109.673
      log likelihood    149.749   0.755258   148.746   149.223   149.840   150.216
      log posterior     39.2256    1.06719   37.8319   38.5549   39.0549   40.0345
                          97.5%     ess
      alpha_site_2      6.35345 7.00000
      alpha_site_3      1.91529 7.00000
      gammaLog_site_2 -0.602657 7.00000
      gammaLog_site_3  0.201643 7.00000
      lambda_value      2.50199 7.00000
      log prior        -109.669 7.00000
      log likelihood    150.724 7.00000
      log posterior     40.5954 7.00000
      
      Summary statistics for alignment 8 (of 9 alignments), comprising 7 samples (2.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 7
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.25763 0.0217816   6.23327   6.23664   6.26711   6.27223
      alpha_site_3      1.84938 0.0311382   1.80566   1.83300   1.85397   1.86217
      gammaLog_site_2 -0.654479 0.0178546 -0.672635 -0.671387 -0.652004 -0.642400
      gammaLog_site_3  0.174817 0.0167089  0.155876  0.163520  0.170133  0.186661
      lambda_value      1.89091   1.04295  0.848303   1.27159   1.71409   2.11078
      log prior        -111.842   1.20450  -112.731  -112.726  -112.692  -111.178
      log likelihood    150.817   1.24144   149.176   150.174   150.371   151.724
      log posterior     38.9746  0.709211   37.7819   38.7245   39.1297   39.4025
                          97.5%     ess
      alpha_site_2      6.28438 7.00000
      alpha_site_3      1.89279 7.00000
      gammaLog_site_2 -0.630216 7.00000
      gammaLog_site_3  0.198025 7.00000
      lambda_value      3.71066 7.00000
      log prior        -109.889 7.00000
      log likelihood    152.474 7.00000
      log posterior     39.7459 7.00000
      
      Summary statistics for alignment 9 (of 9 alignments), comprising 5 samples (1.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 5
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.24797 0.0327073   6.20240   6.23886   6.25213   6.26462
      alpha_site_3      1.64350 0.0121334   1.62670   1.64457   1.64469   1.64478
      gammaLog_site_2 -0.669925 0.0172081 -0.695120 -0.676313 -0.662096 -0.658404
      gammaLog_site_3 0.0964946 0.0103396 0.0825806 0.0938710 0.0964050  0.101513
      lambda_value      1.80995   1.32804  0.665462   1.15356   1.51589   1.70321
      log prior        -109.402  0.683404  -109.738  -109.710  -109.690  -109.687
      log likelihood    148.721   1.56078   146.927   147.223   149.369   149.779
      log posterior     39.3194   1.21233   37.6530   38.7146   39.6793   40.0690
                          97.5%     ess
      alpha_site_2      6.28377 5.00000
      alpha_site_3      1.65733 5.00000
      gammaLog_site_2 -0.655881 5.00000
      gammaLog_site_3  0.108574 5.00000
      lambda_value      3.82958 5.00000
      log prior        -108.330 5.00000
      log likelihood    150.284 5.00000
      log posterior     40.5461 5.00000
      
      Summary statistics for 196 samples (65.3%) not assigned to any cluster:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 196
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.25397 0.0769481   6.12712   6.19716   6.24973   6.30225
      alpha_site_3      1.72053  0.124955   1.49890   1.62690   1.72406   1.80936
      gammaLog_site_2 -0.682058 0.0516695 -0.780136 -0.716484 -0.682040 -0.642453
      gammaLog_site_3  0.126304 0.0437844 0.0548242 0.0963564  0.122501  0.154827
      lambda_value      2.15548  0.885891  0.959781   1.50885   2.02823   2.51328
      log prior        -111.059   2.47495  -115.840  -112.770  -111.199  -109.683
      log likelihood    148.627   2.33500   143.346   147.288   148.659   150.348
      log posterior     37.5683   1.69588   34.0499   36.6958   37.7352   38.7080
                          97.5%     ess
      alpha_site_2      6.40745 125.853
      alpha_site_3      1.93090 169.497
      gammaLog_site_2 -0.590633 126.887
      gammaLog_site_3  0.214492 185.600
      lambda_value      4.09555 170.431
      log prior        -106.638 156.529
      log likelihood    152.682 164.353
      log posterior     39.9095 187.333
      

# summary.StratPosterior works with new cluster object and iterations before burnIn

    Code
      summary.StratPosterior(stratPosterior1, stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 3 samples (1 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 0%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    NA
        alpha_site_3    NA
        gammaLog_site_2 NA
        gammaLog_site_3 NA
        lambda_value    NA
        log prior       NA
        log likelihood  NA
        log posterior   NA
        NA: too few retained draws to compute R-hat: the shortest chain split holds 1 draw and at least 4 are needed (retained draws per run: 1, 1, 1).
      
      Summary statistics for alignment 1 (of 2 alignments), comprising 2 samples (66.7%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 2
                          mean        sd     2.5%      25%      50%      75%    97.5%
      alpha_site_2     5.96088 0.0904887  5.90009  5.92888  5.96088  5.99287  6.02166
      alpha_site_3     2.07168  0.339768  1.84344  1.95155  2.07168  2.19180  2.29992
      gammaLog_site_2 -1.26971  0.249034 -1.43700 -1.35776 -1.26971 -1.18167 -1.10242
      gammaLog_site_3 0.323465  0.142066 0.228032 0.273238 0.323465 0.373693 0.418899
      lambda_value     3.06780   1.24001  2.23482  2.62939  3.06780  3.50621  3.90078
      log prior       -129.751   6.03587 -133.806 -131.885 -129.751 -127.617 -125.696
      log likelihood   116.448   26.1661  98.8706  107.197  116.448  125.699  134.025
      log posterior   -13.3032   32.2020 -34.9350 -24.6884 -13.3032 -1.91811  8.32850
                          ess
      alpha_site_2    2.00000
      alpha_site_3    2.00000
      gammaLog_site_2 2.00000
      gammaLog_site_3 2.00000
      lambda_value    2.00000
      log prior       2.00000
      log likelihood  2.00000
      log posterior   2.00000
      
      Summary statistics for alignment 2 (of 2 alignments), comprising 1 samples (33.3%):
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): NA
                           mean    sd      2.5%       25%       50%       75%
      alpha_site_2      6.31784 0e+00   6.31784   6.31784   6.31784   6.31784
      alpha_site_3      9.56545 0e+00   9.56545   9.56545   9.56545   9.56545
      gammaLog_site_2 -0.598850 0e+00 -0.598850 -0.598850 -0.598850 -0.598850
      gammaLog_site_3 -0.223648 0e+00 -0.223648 -0.223648 -0.223648 -0.223648
      lambda_value      1.91625 0e+00   1.91625   1.91625   1.91625   1.91625
      log prior        -177.202 0e+00  -177.202  -177.202  -177.202  -177.202
      log likelihood    137.714 0e+00   137.714   137.714   137.714   137.714
      log posterior    -39.4885 0e+00  -39.4885  -39.4885  -39.4885  -39.4885
                          97.5%     ess
      alpha_site_2      6.31784 1.00000
      alpha_site_3      9.56545 1.00000
      gammaLog_site_2 -0.598850 1.00000
      gammaLog_site_3 -0.223648 1.00000
      lambda_value      1.91625 1.00000
      log prior        -177.202 1.00000
      log likelihood    137.714 1.00000
      log posterior    -39.4885 1.00000
      

# summary.StratPosterior works with new cluster object and iterations before burnIn - alignment none

    Code
      summary.StratPosterior(stratPosterior1, alignment = "none", stratCluster = clustNew)
    Output
      
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
      
        Total samples: 603 (201 per run).
        Statistics summarise 300 samples (100 per run), after discarding the first 50% of
        iterations from each run as burn-in.
        The acceptance rate of proposals across the selected iterations was 30%.
        'ess' is a measure of effective sample size (Geyer, 1992), capped at the number of samples summarised (see `maxSamples`).
      
      R-hat (rank-normalized, split-chain): (Convergence when ~1.00)
        alpha_site_2    1.01496
        alpha_site_3    1.01033
        gammaLog_site_2 1.01172
        gammaLog_site_3 1.01591
        lambda_value    1.00854
        log prior       1.01117
        log likelihood  1.00492
        log posterior   1.00141
      
      Summary statistics for the posterior, comprising 300 samples:
        Multivariate effective sample size of age-height parameters, using
        mcmcse::multiESS(): 287.9
                           mean        sd      2.5%       25%       50%       75%
      alpha_site_2      6.25186 0.0652973   6.13232   6.20805   6.25044   6.28599
      alpha_site_3      1.72747  0.116446   1.51700   1.64466   1.72934   1.81641
      gammaLog_site_2 -0.684502 0.0476176 -0.774690 -0.716116 -0.680719 -0.651796
      gammaLog_site_3  0.128863 0.0422487 0.0552986 0.0975720  0.126434  0.156633
      lambda_value      2.13564  0.865657  0.902249   1.51479   2.00227   2.50541
      log prior        -111.096   2.30732  -115.742  -112.765  -111.212  -109.701
      log likelihood    149.242   2.28695   144.316   147.829   149.506   151.026
      log posterior     38.1457   1.71736   34.2700   37.3067   38.4228   39.3555
                          97.5%     ess
      alpha_site_2      6.38893 203.019
      alpha_site_3      1.91833 227.240
      gammaLog_site_2 -0.596833 193.880
      gammaLog_site_3  0.209139 259.793
      lambda_value      4.10083 246.667
      log prior        -106.659 232.198
      log likelihood    153.017 232.285
      log posterior     40.6398 274.433
      

