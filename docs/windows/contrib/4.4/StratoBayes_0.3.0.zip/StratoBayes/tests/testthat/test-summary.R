test_that("summary.StratPosterior works with single cluster", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior1))
})

test_that("print.summary.StratPosterior works with change sigDigits", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(summary(stratPosterior1), sigDigits = 2))
})

test_that("summary.StratPosterior works with two clusters", {
  skip_if_not_snapshot_os()
  bimodal <- Cluster(stratPosterior5a, selectRows = .BimodalRows5a())
  expect_snapshot(summary(stratPosterior5a, stratCluster = bimodal))
})

test_that("summary.StratPosterior works with no burn-in", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, burnIn = 0))
})

test_that("summary.StratPosterior works with iteration burn-in", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior1, burnIn = 4900))
})

test_that("summary.StratPosterior works with iterations", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, iterations = 500:800))
})

test_that("summary.StratPosterior works with unassigned iterations", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior2, iterations = 1:100, runs = 4))
})

test_that("summary.StratPosterior works with alignment 2", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratPosterior5a, alignment = 2))
})

test_that("summary.StratPosterior works with no clusters (all it)", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    summary.StratPosterior(stratPosterior2, alignment = "none")
  )
})

test_that("summary.StratPosterior works with new cluster object and many clusters", {
  skip_if_not_snapshot_os()
  clustNew <- Cluster(stratPosterior1, clusterMethod = "hdbscan")

  expect_snapshot(
    summary.StratPosterior(stratPosterior1, alignment = "all",
                           stratCluster = clustNew)
  )
})


test_that("summary.StratPosterior works with new cluster object and iterations before burnIn", {
  skip_if_not_snapshot_os()
  clustNew <- Cluster(stratPosterior1, iterations = 100)

  expect_snapshot(
    summary.StratPosterior(stratPosterior1,
                           stratCluster = clustNew)
  )

})

test_that("summary.StratPosterior works with new cluster object and iterations before burnIn - alignment none", {
            skip_if_not_snapshot_os()
            clustNew <- Cluster(stratPosterior1, iterations = 100)

            expect_snapshot(
              summary.StratPosterior(stratPosterior1, alignment = "none",
                                     stratCluster = clustNew)
            )


          })

# hit NA line in .RoundToSigDigits
test_that(".RoundToSigDigits deals with NA", {
expect_equal(.RoundToSigDigits(NA)[[1]], "NA")
})

test_that("summary.StratPosterior includes sigma rows when sigma is estimated (RT-180)", {
  # stratPosterior3 has an estimated sigma_value column in object[["samples"]];
  # the containsSigma lookup previously always failed due to a paste() sep
  # mismatch ("sigma value" vs "sigma_value"), so sigma was silently omitted.
  s <- summary(stratPosterior3)
  expect_true("sigma_value" %in% rownames(s[[1]][["summary"]]))
})

test_that("summary.StratPosterior reports correct per-run sample count for a run subset (RT-117)", {
  s <- summary(stratPosterior2, runs = 2)
  expect_equal(s[["general"]][["nSamplesUsedPerRun"]], 100)
  expect_length(s[["general"]][["nSamplesUsedPerRun"]], 1)
})

test_that("summary.StratPosterior reports the number of *selected* runs", {
  s <- summary(stratPosterior2, runs = 2)
  expect_equal(s[["general"]][["nRun"]], 1)

  s2 <- summary(stratPosterior2)
  expect_equal(s2[["general"]][["nRun"]], stratPosterior2[["nRun"]])
})

test_that(".AllArgumentsDefault compares the evaluated formal, not the raw match.call() expression (RT-122)", {
  # args[[argName]] from match.call() is an unevaluated call for compound
  # expressions like quantiles = c(...); identical() against the evaluated
  # default always returned FALSE, permanently missing the summary cache even
  # when the user passed the exact default value.
  defaults <- list(quantiles = c(0.025, 0.25, 0.5, 0.75, 0.975))
  args <- list(quantiles = quote(c(0.025, 0.25, 0.5, 0.75, 0.975)))

  hitEnv <- list2env(list(quantiles = c(0.025, 0.25, 0.5, 0.75, 0.975)))
  expect_true(StratoBayes:::.AllArgumentsDefault(args, defaults, hitEnv))

  missEnv <- list2env(list(quantiles = c(0.025, 0.25, 0.5, 0.75, 0.99)))
  expect_false(StratoBayes:::.AllArgumentsDefault(args, defaults, missEnv))
})

test_that("summary.StratPosterior computes split-chain Rhat for single-run posteriors (RT-140)", {
  # .RhatRankNorm(list(mat)) splits a single chain in half and returns a finite
  # split-chain estimate.
  s <- summary(stratPosterior3)
  expect_equal(stratPosterior3[["nRun"]], 1)
  expect_false(is.null(s[["general"]][["psrf"]]))
  expect_true(all(s[["general"]][["psrf"]] > 0.99))
  expect_true(all(s[["general"]][["psrf"]] < 2))

  expect_output(print(s), "R-hat")
})

test_that("summary.StratPosterior tolerates legacy posteriors missing proposal_accepted (RT-191)", {
  # Legacy posteriors compiled before proposal_accepted was saved have no such
  # column in savedParameters; ExtractParameters() unconditionally requested
  # it and failed deep inside .ValidateModelParams with a message that gave no
  # indication the error originated in summary().
  legacy <- unclass(stratPosterior3)
  keepCols <- dimnames(legacy$samples)[[2]] != "proposal_accepted"
  legacy$samples <- legacy$samples[, keepCols, , , drop = FALSE]
  legacy$savedParameters <- legacy$savedParameters[legacy$savedParameters != "proposal_accepted"]
  legacy$.cache <- new.env(parent = emptyenv())
  legacy$.cache$stratCluster <- NULL
  legacy$.cache$summary <- NULL
  legacy$.cache$clusterCache <- list()
  # stamp against the trimmed samples, or the cache is disowned (RT-454)
  legacy$.cache$stamp <- .PosteriorStamp(legacy)
  class(legacy) <- c("StratPosterior", "list")

  expect_false("proposal_accepted" %in% legacy$savedParameters)
  s <- expect_no_error(summary(legacy))
  expect_true(is.na(s[["general"]][["meanAcceptancePercent"]]))
})

test_that("summary's maxSamples default agrees with Cluster()'s (#903)", {
  # Above maxClusterSamples, a smaller default here than Cluster()'s would
  # put summary() on the outlier-blind subsample path while a default
  # Cluster() call on the same object stays on the full path (#393's defect
  # class; see the sibling pin test in test-Cluster.R).
  expect_equal(
    eval(formals(summary.StratPosterior)[["maxSamples"]]),
    eval(formals(Cluster.StratPosterior)[["maxSamples"]])
  )
})
