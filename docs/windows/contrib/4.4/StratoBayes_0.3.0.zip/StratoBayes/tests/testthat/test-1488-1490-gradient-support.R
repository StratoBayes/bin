# Support and self-transition parity between the MH and gradient kernels.
#
#   #1488 `ratesRange` is hard support for MH but was invisible to the HMC/NUTS
#         gradient and accept leaves, so the two kernels targeted different
#         distributions under a narrowed range.
#   #1489 the R engine's `!gradResult$ok` early return skipped the unconditional
#         (beta, sigma, lambda) sweep every other reject path runs.
#   #1490 R's MH accept path had no twin for the C++ engine's non-finite
#         Hastings clamp; and the NUTS `totalLeapfrog > 0L` guard, reported as
#         dead code, is not (see the last test).
#
# Deliberately ungated: every fixture below is a ~1 s R-engine run, and
# `NOT_CRAN` is false on pull requests, so a `skip_on_cran()` here would assert
# nothing on the CI that reviews the change.

# ── Fixtures ────────────────────────────────────────────────────────────────

# One short R-engine chain supplies fully initialised state (mass matrix, dual
# averaging, adapted proposal arguments).  `gradientProposals` selects the
# proposal set: "on" registers NUTS, "off" registers NeighbourScaled.
.sup_setup <- function(gradientProposals) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12), sigmaFixed = TRUE
  )
  td <- file.path(tempdir(),
                  paste0("sup_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4200)
  RunStratModel(gradientProposals = gradientProposals, stratData1, model,
                nIter = 30, nChains = 1, seed = 1, quiet = TRUE,
                visualise = FALSE, modelDir = td, modelName = "s",
                engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  list(data = stratData1, model = model, mcmc = mcmc,
       state = mcmc$recentState[[1]])
}

.sup_cache <- new.env(parent = emptyenv())
.sup <- function(gradientProposals) {
  if (is.null(.sup_cache[[gradientProposals]]))
    .sup_cache[[gradientProposals]] <- .sup_setup(gradientProposals)
  .sup_cache[[gradientProposals]]
}

# An engine over the same data/state, differing only in `ratesRange`.  Written
# straight onto `proposeChecks` because `StratMCMC()` refuses an initial state
# outside the range, which is precisely the state these tests need to score.
.sup_engine <- function(s, ratesRange = NULL) {
  model <- s$model
  if (!is.null(ratesRange)) {
    model$proposeChecks$ratesMin <- ratesRange[[1]]
    model$proposeChecks$ratesMax <- ratesRange[[2]]
  }
  StratoBayes:::.sb_create_engine(s$data, model, s$mcmc, s$mcmc$recentState)
}


# ── #1488: ratesRange is support for the gradient kernel too ────────────────

test_that("#1488: the gradient leaf scores an out-of-range rate as zero density", {
  s <- .sup("on")
  params <- s$state$metro$parameters
  rates <- params[s$model$indRates]

  # Ranges chosen from the fixture's own rates so the only thing that varies
  # between the three arms is the support boundary.
  inside <- c(min(rates) - 0.01, max(rates) + 0.01)
  outside <- c(max(rates) + 0.5, max(rates) + 1.5)

  wide <- StratoBayes:::.sb_gradient_at(.sup_engine(s), 1L, params)
  narrowIn <- StratoBayes:::.sb_gradient_at(.sup_engine(s, inside), 1L, params)
  narrowOut <- StratoBayes:::.sb_gradient_at(.sup_engine(s, outside), 1L, params)

  # Controls: without them a gradient leaf that failed for any other reason
  # would pass the assertion that matters.
  expect_true(wide$ok)
  expect_true(is.finite(wide$logPost))
  expect_true(narrowIn$ok)
  expect_equal(narrowIn$logPost, wide$logPost)

  # The discriminator: same parameters, same data, same state — only the range
  # moved, and the state left the support.
  expect_false(narrowOut$ok)
  expect_identical(narrowOut$logPost, -Inf)
})

test_that("#1488: the C++ engine's own leapfrog leaf refuses an out-of-range rate", {
  # The two tests above reach `sb_gradient_at_impl` / `sb_eval_logpost_impl`,
  # which is what the R engine's leapfrog calls. This one drives the production
  # C++ sampler, whose gradient leaf is `hmc_eval_gradient` -- a different call
  # site of the same check.
  s <- .sup("on")
  slot <- which(names(s$mcmc$propose) == "NUTS")
  mcmc <- s$mcmc
  mcmc$metro$proposalProbability[, ] <- 0
  mcmc$metro$proposalProbability[, slot] <- 1

  model <- s$model
  rates <- s$state$metro$parameters[model$indRates]
  model$proposeChecks$ratesMin <- max(rates) + 0.5
  model$proposeChecks$ratesMax <- max(rates) + 1.5

  eng <- StratoBayes:::.sb_create_engine(s$data, model, mcmc, s$mcmc$recentState)
  StratoBayes:::.sb_configure_monitor(eng, ncol(mcmc$metro$proposalProbability))
  before <- StratoBayes:::.sb_extract_state(eng)[[1]]
  set.seed(99)
  StratoBayes:::.sb_run_block(eng, 5L)
  mon <- StratoBayes:::.sb_get_monitor(eng)
  after <- StratoBayes:::.sb_extract_state(eng)[[1]]

  # The discriminator: `recordGradient()` runs only where a trajectory was
  # actually integrated, so a leapfrog leaf that refuses the state records
  # nothing. Pre-fix the gradient succeeded here and all five iterations built
  # real trees.
  expect_identical(mon$nGradientTransitions, 0L)
  expect_identical(mon$maxTreeDepth, 0L)

  # No proposal was made, so the alignment cannot have moved...
  expect_equal(after$metro$parameters, before$metro$parameters)
  expect_false(after$metro$accept)
  # ...but each iteration is still a self-transition, not a bare skip.
  expect_false(isTRUE(all.equal(before$gibbs$lambda, after$gibbs$lambda)))
})

test_that("#1488: the shared log-posterior leaf agrees with the gradient leaf", {
  s <- .sup("on")
  params <- s$state$metro$parameters
  rates <- params[s$model$indRates]
  outside <- c(max(rates) + 0.5, max(rates) + 1.5)

  expect_true(is.finite(
    StratoBayes:::.sb_eval_logpost(.sup_engine(s), 1L, params)))
  expect_identical(
    StratoBayes:::.sb_eval_logpost(.sup_engine(s, outside), 1L, params),
    -Inf)
})


# ── #1489: R-side gradient-failure self-transition ──────────────────────────

# `alpha_site_2 = 20` puts the site's ages outside `knotRange`, so
# `age_convert_and_validate()` rejects and `.sb_gradient_at()` reports
# ok = FALSE — the trigger this branch exists for, forced deterministically.
.sup_poison <- function(state) {
  state$metro$parameters[["alpha_site_2"]] <- 20
  # Sentinels: pre-fix the early return left both fields untouched, so a value
  # that could not arise from the fix makes staleness visible.
  state$metro$logPostNew <- 12345
  state$metro$logPostOld <- 12345
  state
}

for (.prop in c("HMC", "NUTS")) local({
  prop <- .prop

  test_that(paste0("#1489: R-engine ", prop,
                   " gradient failure runs the Gibbs sweep"), {
    s <- .sup("on")
    slot <- which(names(s$mcmc$propose) == "NUTS")
    mcmc <- s$mcmc
    if (prop == "HMC") {
      names(mcmc$propose)[slot] <- "HMC"
      colnames(mcmc$metro$proposalProbability)[slot] <- "HMC"
    }
    Update <- if (prop == "HMC") StratoBayes:::.UpdateStateHMC else
      StratoBayes:::.UpdateStateNUTS

    before <- .sup_poison(s$state)

    # The branch under test is actually entered.  Without this the whole test
    # could pass on an ordinary rejection.
    expect_false(StratoBayes:::.sb_gradient_at(
      .sup_engine(s), 1L, before$metro$parameters)$ok)

    set.seed(11)
    after <- Update(s$data, s$model, mcmc, before, 1L, slot)

    # No proposal was made: the alignment is untouched and the iteration is a
    # rejection.
    expect_false(after$metro$accept)
    expect_equal(after$metro$parameters, before$metro$parameters)
    expect_identical(after$metro$proposalNumber, slot)

    # The (beta, sigma, lambda) block was refreshed.  Pre-fix it was returned
    # bit-identical, because the early return ran no sweep at all.
    expect_false(isTRUE(all.equal(before$gibbs$beta, after$gibbs$beta)))
    expect_false(isTRUE(all.equal(before$gibbs$lambda, after$gibbs$lambda)))

    # ...and the log posteriors describe the state carried forward, not the
    # previous iteration's.
    expect_identical(after$metro$logPostNew, -Inf)
    expect_equal(after$metro$logPostOld, after$metro$logPost)
    expect_false(isTRUE(all.equal(before$metro$logPost, after$metro$logPost)))
  })
})

test_that("#1489: an ordinary R-engine NUTS rejection already moved the block", {
  # Comparator for the two tests above: if a plain rejection ever stopped
  # refreshing the Gibbs block, their "changed" assertions would be vacuous.
  s <- .sup("on")
  slot <- which(names(s$mcmc$propose) == "NUTS")
  set.seed(11)
  after <- StratoBayes:::.UpdateStateNUTS(s$data, s$model, s$mcmc, s$state,
                                          1L, slot)
  expect_true(StratoBayes:::.sb_gradient_at(
    .sup_engine(s), 1L, s$state$metro$parameters)$ok)
  # Without this the comparator would also pass on an ACCEPTED step, where the
  # block moves for a different reason.
  expect_false(after$metro$accept)
  expect_false(isTRUE(all.equal(s$state$gibbs$beta, after$gibbs$beta)))
})


# ── #1490: non-finite Hastings ratio, and the totalLeapfrog guard ───────────

# NeighbourScaled with a zero proposal factor is a degenerate kernel: the draw
# is a point mass at the current state, so `dnorm(0, 0, 0, log = TRUE)` is +Inf
# in both directions and the q-ratio is Inf - Inf = NaN.  That is the C++
# engine's documented "non-positive covariance diagonal" case, reached here
# through the real density code rather than a mock.
.sup_degenerate_mcmc <- function(s, proposalFactor) {
  mcmc <- s$mcmc
  slot <- which(names(mcmc$propose) == "NeighbourScaled")
  mcmc$metro$proposalProbability[, ] <- 0
  mcmc$metro$proposalProbability[, slot] <- 1
  mcmc$metro$proposalProbabilityWeights[, ] <- 0
  mcmc$metro$proposalProbabilityWeights[, slot] <- 1
  mcmc$metro$proposalFactor[1, slot] <- proposalFactor
  mcmc
}

test_that("#1490: a non-finite Hastings ratio is clamped, not propagated", {
  s <- .sup("off")
  mcmc <- .sup_degenerate_mcmc(s, proposalFactor = 0)
  slot <- which(names(mcmc$propose) == "NeighbourScaled")
  params <- s$state$metro$parameters

  # The precondition: the q-ratio really is NaN at this configuration.
  oneSided <- StratoBayes:::.ProposalLogDensity(
    "NeighbourScaled", s$model, params, params,
    mcmc$metro$proposalArgs[[1]][[slot]], 0, mcmc$metro$dimFactor)
  expect_true(is.nan(oneSided - oneSided))

  # Pre-fix the NaN reached `.AcceptProposal`, whose NA return errored at the
  # `if (accept)` below it.  Post-fix the step degrades to logHastings = 0,
  # i.e. exp(0) = 1 > runif(1): a certain accept of the (unmoved) state.
  set.seed(5)
  out <- StratoBayes:::.UpdateState(s$data, s$model, mcmc, s$state, 1L)
  expect_true(out$metro$accept)
  expect_identical(out$metro$proposalNumber, slot)
  expect_equal(out$metro$parameters, params)

  # Control: the same slot with an ordinary factor keeps the ratio finite, so
  # the clamp is not silently swallowing every NeighbourScaled step. Asserted on
  # the ratio itself -- `accept` being non-NA is true by construction once the
  # clamp exists, and would pass however over-scoped the clamp were.
  mcmcOK <- .sup_degenerate_mcmc(s, proposalFactor = 1)
  moved <- params
  moved[[1]] <- moved[[1]] + 0.01
  arg <- mcmcOK$metro$proposalArgs[[1]][[slot]]
  ratio <-
    StratoBayes:::.ProposalLogDensity("NeighbourScaled", s$model, moved, params,
                                      arg, 1, mcmcOK$metro$dimFactor) -
    StratoBayes:::.ProposalLogDensity("NeighbourScaled", s$model, params, moved,
                                      arg, 1, mcmcOK$metro$dimFactor)
  expect_true(is.finite(ratio))
  expect_false(ratio == 0)

  set.seed(5)
  ok <- StratoBayes:::.UpdateState(s$data, s$model, mcmcOK, s$state, 1L)
  expect_false(is.na(ok$metro$accept))
})

test_that("#1490: the NUTS totalLeapfrog guard is reachable, not dead code", {
  # Reported as dead on the grounds that every `.NUTSBuildTree` return carries
  # nLeapfrog >= 1.  It does — but `.ValidateGradientProposalArgs()` checks only
  # that `maxTreeDepth` is present, so `maxTreeDepth = 0L` reaches
  # `seq_len(0)`, the doubling loop never runs, and removing the guard would
  # divide 0 by 0 into `alpha_tree`.  The C++ engine carries the same guard.
  s <- .sup("on")
  slot <- which(names(s$mcmc$propose) == "NUTS")
  mcmc <- s$mcmc
  mcmc$metro$proposalArgs[[1]][[slot]]$maxTreeDepth <- 0L

  set.seed(3)
  out <- StratoBayes:::.UpdateStateNUTS(s$data, s$model, mcmc, s$state, 1L, slot)
  expect_false(out$metro$accept)
  expect_identical(out$metro$acceptProb, 0)
  expect_identical(out$metro$nutsTreeDepth, 0L)
})
