# Gradient support under flexibleKnots = TRUE.
#
# Two independent things had to be added, and they need two different checks:
#
#   Gap 1  the joint-at-beta potential was missing log p(beta | lambda, D_a),
#          which is alignment-dependent when the knots move
#   Gap 2  the chain rule params -> ageRange -> knots -> B was missing
#
# Finite differences catch Gap 2 and, because the potential and the gradient
# are compared against each other, also catch any inconsistency introduced by
# Gap 1's term. They cannot by themselves prove the POTENTIAL is the right
# target; that is what the stationarity harness in
# dev/red-team/heavy-tests/ is for.
#
# ─── FIXTURE CHOICE IS LOAD-BEARING ─────────────────────────────────────────
# The correction is identically zero whenever the reference section defines
# BOTH ends of the age range, because then lo and hi do not depend on any free
# parameter. On the height scale site 1 is the reference and its ages are its
# raw heights, so stratData1 -- where site 1 spans [0, 10] and encloses sites 2
# and 3 -- cannot discriminate: deleting either new term leaves its finite
# differences passing. stratData0 puts the argmax on site 2 and does
# discriminate. `expect_range_is_parameter_dependent()` asserts that precondition
# so this file fails loudly if a fixture changes rather than going quietly
# vacuous.

make_flex_engine <- function(sData, sModel, tag) {
  td <- file.path(tempdir(), paste0("fkg_", tag))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(7261)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "fk",
    engine = "R"
  )

  model_obj <- result$model
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  mcmc_obj  <- readRDS(file.path(td, "fk_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  list(
    ptr    = StratoBayes:::.sb_create_engine(
               data = result$data, model = model_obj,
               mcmc = mcmc_obj, state = state_obj, tiesCallback = NULL),
    model  = model_obj,
    data   = result$data,
    params = state_obj[[1]]$metro$parameters,
    free   = model_obj$ind$paramNotFixed,
    td     = td
  )
}

# Both ends of range(signalFlat) must not sit on the reference section, or the
# knot-path correction vanishes and this file proves nothing.
expect_range_is_parameter_dependent <- function(setup) {
  conv <- StratoBayes:::.sb_age_convert(setup$data, setup$model$ind, setup$params)
  flat <- unlist(conv$signal, use.names = FALSE)
  siteOf <- rep(seq_along(conv$signal), vapply(conv$signal, length, integer(1)))
  endpointSites <- c(siteOf[which.min(flat)], siteOf[which.max(flat)])
  expect_false(
    all(endpointSites == 1L),
    label = paste0(
      "fixture regression: both age-range endpoints fall on the reference ",
      "section, so the flexible-knot gradient correction is identically zero ",
      "and these finite-difference checks cannot discriminate it")
  )
}

# Single coordinate only: the refinement ladder discards every other element,
# so recomputing the whole vector cost 2 * nFree * (1 + 3m) evaluations where
# 2 * (1 + 3m) suffice.
fd_gradient_at <- function(setup, p, k, h_rel = 1e-5) {
  j <- setup$free[[k]]
  h <- h_rel * max(1, abs(p[j]))
  pp <- p
  pp[j] <- pp[j] + h
  pm <- p
  pm[j] <- pm[j] - h
  (StratoBayes:::.sb_eval_logpost(setup$ptr, 1L, pp, FALSE, FALSE) -
   StratoBayes:::.sb_eval_logpost(setup$ptr, 1L, pm, FALSE, FALSE)) / (2 * h)
}

fd_gradient <- function(setup, p, h_rel = 1e-5) {
  # unname: `free` carries parameter names, the C++ gradient is a bare vector
  unname(vapply(seq_along(setup$free),
                function(k) fd_gradient_at(setup, p, k, h_rel), numeric(1)))
}

# Tolerance stays tighter here than test-cpp-gradient.R's 1e-3: this fixture is
# 2 free parameters on stratModel0, which does meet 1e-4.  The ladder and the
# per-element comparison are shared (helper-fd-gradient.R); only the threshold
# is per-fixture.
# nolint next: object_name_linter. Matches expect_*() and its sibling helper.
expect_fd_matches <- function(analytic, setup, p, tolerance = 1e-4,
                              info = NULL) {
  expect_fd_close(
    analytic, fd_gradient(setup, p),
    refine = function(i, h) fd_gradient_at(setup, p, i, h),
    h0 = 1e-5, tol = tolerance,
    param_names = names(setup$free), info = info
  )
}


test_that("flexible-knots gradient matches finite differences", {
  skip_on_cran()

  setup <- make_flex_engine(stratData0, stratModel0, "d0")
  on.exit(unlink(setup$td, recursive = TRUE))

  expect_true(isTRUE(setup$model$flexibleKnots))
  expect_range_is_parameter_dependent(setup)

  analytic <- StratoBayes:::.sb_gradient_at(setup$ptr, 1L, setup$params)
  expect_true(isTRUE(analytic$ok))
  expect_length(analytic$grad, length(setup$free))
  expect_true(all(is.finite(analytic$grad)))

  expect_fd_matches(analytic$grad, setup, setup$params)
})


test_that("flexible-knots gradient matches FD away from the current state", {
  skip_on_cran()

  setup <- make_flex_engine(stratData0, stratModel0, "d0jit")
  on.exit(unlink(setup$td, recursive = TRUE))
  expect_range_is_parameter_dependent(setup)

  set.seed(4021)
  for (rep in seq_len(4)) {
    p <- setup$params
    p[setup$free] <- p[setup$free] + stats::rnorm(length(setup$free), 0, 0.15)

    analytic <- StratoBayes:::.sb_gradient_at(setup$ptr, 1L, p)
    if (!isTRUE(analytic$ok)) next          # out of support: nothing to compare
    expect_fd_matches(analytic$grad, setup, p,
                      info = paste("jitter replicate", rep))
  }
})


test_that("fixed-knots gradient is unchanged", {
  skip_on_cran()

  fixedModel <- StratModel(
    stratData = stratData0, priors = stratModel0$priors$metro,
    alignmentScale = stratModel0$alignmentScale,
    sedModel = stratModel0$sedModel,
    flexibleKnots = FALSE, knotRange = c(-10, 40)
  )
  setup <- make_flex_engine(stratData0, fixedModel, "d0fix")
  on.exit(unlink(setup$td, recursive = TRUE))

  expect_false(isTRUE(setup$model$flexibleKnots))
  analytic <- StratoBayes:::.sb_gradient_at(setup$ptr, 1L, setup$params)
  expect_true(isTRUE(analytic$ok))
  expect_fd_matches(analytic$grad, setup, setup$params)
})


test_that("gradient reuses the potential's roughness quadform, bit-for-bit", {
  skip_on_cran()

  # beta'D_base*beta is computed once per signal per gradient evaluation and
  # shared with the roughness term. A WRONG cached value shows up in the
  # finite-difference tests above, not here; what this pins is that caching it
  # leaves the potential alone -- .sb_eval_logpost computes it fresh, the
  # gradient path reads the cache, and the two logPosts must agree to the last
  # bit -- and that the debug entry point sees the same cache as the sampler.
  fixedModel <- StratModel(
    stratData = stratData0, priors = stratModel0$priors$metro,
    alignmentScale = stratModel0$alignmentScale,
    sedModel = stratModel0$sedModel,
    flexibleKnots = FALSE, knotRange = c(-10, 40)
  )

  for (case in list(list(m = stratModel0, tag = "d0q",    flex = TRUE),
                    list(m = fixedModel,  tag = "d0fixq", flex = FALSE))) {
    setup <- make_flex_engine(stratData0, case$m, case$tag)
    on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)
    expect_identical(isTRUE(setup$model$flexibleKnots), case$flex)

    at <- StratoBayes:::.sb_gradient_at(setup$ptr, 1L, setup$params)
    expect_true(isTRUE(at$ok))
    expect_identical(
      at$logPost,
      unname(StratoBayes:::.sb_eval_logpost(setup$ptr, 1L, setup$params,
                                            FALSE, FALSE)),
      info = case$tag
    )

    # debug = TRUE routes through the same production gradient (RT-307), so it
    # must see the same cache.
    plain <- StratoBayes:::.sb_compute_gradient(setup$ptr, 1L, FALSE)
    dbg   <- StratoBayes:::.sb_compute_gradient(setup$ptr, 1L, TRUE)
    expect_identical(plain$grad, dbg$grad, info = case$tag)
    expect_identical(plain$logPost, dbg$logPost, info = case$tag)
  }
})


test_that("gradientProposals controls NUTS registration", {
  auto <- StratMCMC(stratModel1, nIter = 10, nChains = 2)
  on   <- StratMCMC(stratModel1, nIter = 10, nChains = 2,
                    gradientProposals = "on")
  off  <- StratMCMC(stratModel1, nIter = 10, nChains = 2,
                    gradientProposals = "off")

  # "auto": no NUTS under flexible knots
  expect_true(isTRUE(stratModel1$flexibleKnots))
  expect_false("NUTS" %in% names(auto$propose))
  expect_true(all(c("SiteBlock", "NeighbourScaled") %in% names(auto$propose)))

  # "on" registers NUTS and DISPLACES the two MH-only proposals
  expect_true("NUTS" %in% names(on$propose))
  expect_false(any(c("SiteBlock", "NeighbourScaled") %in% names(on$propose)))

  expect_identical(names(off$propose), names(auto$propose))

  expect_error(
    StratMCMC(stratModel1, nIter = 10, nChains = 2, gradientProposals = "yes"),
    "should be one of"
  )
})


test_that("gradientProposals = 'auto' does not register NUTS with fixed knots", {
  skip_on_cran()

  fixedModel <- StratModel(
    stratData = stratData0, priors = stratModel0$priors$metro,
    alignmentScale = stratModel0$alignmentScale,
    sedModel = stratModel0$sedModel,
    flexibleKnots = FALSE, knotRange = c(-10, 40)
  )
  mcmc <- StratMCMC(fixedModel, nIter = 10, nChains = 2)
  expect_false("NUTS" %in% names(mcmc$propose))
  expect_true(all(c("SiteBlock", "NeighbourScaled") %in% names(mcmc$propose)))

  # "on" is the route to NUTS under either knot setting.
  mcmcOn <- StratMCMC(fixedModel, nIter = 10, nChains = 2,
                      gradientProposals = "on")
  expect_true("NUTS" %in% names(mcmcOn$propose))
})


test_that("gradientProposals = 'off' with fixed knots is a working combination", {
  skip_on_cran()

  # "off" is the only route to SiteBlock/NeighbourScaled on a fixed-knots model,
  # and nothing else in the suite exercises that pairing.
  fixedModel <- StratModel(
    stratData = stratData0, priors = stratModel0$priors$metro,
    alignmentScale = stratModel0$alignmentScale,
    sedModel = stratModel0$sedModel,
    flexibleKnots = FALSE, knotRange = c(-10, 40)
  )
  mcmc <- StratMCMC(fixedModel, nIter = 10, nChains = 4,
                    gradientProposals = "off")
  expect_false("NUTS" %in% names(mcmc$propose))
  expect_true(all(c("SiteBlock", "NeighbourScaled") %in% names(mcmc$propose)))

  td <- file.path(tempdir(), "fkg_offfixed")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  res <- RunStratModel(
    stratObject = stratData0, stratModel = fixedModel,
    seed = 11L, nRun = 1L, nIter = 200, nChains = 4, nThin = 2,
    gradientProposals = "off", nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "offfix"
  )
  expect_true(all(is.finite(as.numeric(res$samples))))
})


test_that("a supplied StratMCMC object's gradientProposals wins, with a warning", {
  skip_on_cran()

  # Consistent with nIter/nChains: the object's value takes precedence. Warn,
  # because silently ignoring this one changes the SAMPLER, not just a tuning
  # constant.
  mAuto <- StratMCMC(stratModel0, nIter = 40, nChains = 4)
  expect_false("NUTS" %in% names(mAuto$propose))

  td <- file.path(tempdir(), "fkg_inherit")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  expect_warning(
    RunStratModel(
      stratObject = stratData0, stratModel = stratModel0, stratMCMC = mAuto,
      seed = 3L, nRun = 1L, gradientProposals = "on", nThreads = 1L,
      quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "inh"
    ),
    "gradientProposals"
  )

  # And the object's own setting is what actually ran.
  mm <- readRDS(file.path(td, "inh_mcmc_run_1.rds"))
  expect_false("NUTS" %in% names(mm$propose))
})


test_that("R engine refuses gradient proposals under flexible knots", {
  skip_on_cran()

  # A scope guard, not a known-wrong-answer guard: the shared log-posterior
  # primitive is parity-correct on both sides (see
  # test-cpp-logpost-equivalence.R), but per docs/r-engine-contract.md the R
  # engine's NUTS/HMC orchestration is C++-authoritative and carries no
  # value-parity test, so this combination is not enabled there.
  expect_error(
    RunStratModel(
      stratObject = stratData0, stratModel = stratModel0,
      nIter = 20, nChains = 4, seed = 1,
      gradientProposals = "on", engine = "R",
      quiet = TRUE, visualise = FALSE
    ),
    "engine = \"cpp\"",
    fixed = TRUE
  )
})


test_that("NUTS runs end to end under flexible knots on the C++ engine", {
  skip_on_cran()

  td <- file.path(tempdir(), "fkg_e2e")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  res <- RunStratModel(
    stratObject = stratData0, stratModel = stratModel0,
    seed = 7L, nRun = 1L, runParallel = FALSE, nCores = 2L, nThreads = 1L,
    nIter = 400, nChains = 4, nThin = 2,
    gradientProposals = "on",
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "e2e"
  )

  expect_s3_class(res, "StratPosterior")
  expect_true(all(is.finite(as.numeric(res$samples))))
})
