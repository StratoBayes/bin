# Regression tests for #676: summary.StratPosterior() erroring on two
# degenerate-but-tolerated sample states that ExtractIterations()/
# .RhatRankNorm() already handle gracefully.

test_that("#676: a run fully emptied by burnIn does not crash per-run PSRF", {
  # A run that completed far fewer iterations than the others (as a
  # short-lived CombineModelRuns() member would), with a burnIn that
  # discards it entirely while runs 1-2 still have plenty of samples.
  post <- stratPosterior1
  post[[c("mcmcSummary", "completedIter")]][3] <- 100
  post[[c("mcmcSummary", "completedIterIndex")]][3] <- 5L

  # ExtractIterations() is called twice inside summary() (once for the row
  # selection, once for the acceptance rate), so the warning below fires
  # twice; expect_warning() only muffles the first, so withCallingHandlers()
  # confirms both without letting either escape.
  warned <- FALSE
  s <- withCallingHandlers(
    summary(post, burnIn = 500),
    warning = function(w) {
      if (grepl("contribute no samples", conditionMessage(w))) warned <<- TRUE
      invokeRestart("muffleWarning")
    }
  )
  expect_true(warned)
  expect_output(print(s), "R-hat")

  psrf <- s[[c("general", "psrf")]]
  expect_false(anyNA(psrf))  # computed from runs 1-2 alone

  expect_equal(unname(s[[c("general", "nSamplesUsedPerRun")]]), c(180, 180, 0))
})

test_that("#676: a non-finite retained draw does not crash summary()", {
  # An interior row (not the newest, so a later complete row keeps
  # .CompleteSampleRows() from treating the run as incomplete) is NaN --
  # the state RT-422 hardened .RhatRankNorm() for, but nothing else was.
  # `.cache` is an environment, so this copy shares the shipped object's: until
  # #1992 the single edited draw fell between `.CacheStamp()`'s probe points,
  # the stamp still matched, and the summary below was memoised back onto
  # `stratPosterior1` itself -- which a later test file then read.
  post <- stratPosterior1
  post[["samples"]][150, "alpha_site_2", 1, 1] <- NaN

  s <- expect_no_error(suppressWarnings(summary(post)))
  expect_output(print(s), "R-hat")

  stats <- s[[1]][["summary"]]
  expect_true(all(is.na(stats["alpha_site_2", ])))
  # every other parameter is untouched by the one contaminated draw
  expect_false(anyNA(stats[rownames(stats) != "alpha_site_2", ]))

  psrf <- s[[c("general", "psrf")]]
  expect_true(is.na(psrf["alpha_site_2"]))
  expect_false(anyNA(psrf[names(psrf) != "alpha_site_2"]))
})

test_that("#676: a NaN-contaminated constant column does not break multiESS", {
  # A constant column contaminated by one NaN draw: elementwise differences
  # are all 0 or NaN, so the constancy check alone would be NA, and an NA in
  # a column-selecting logical vector errors "undefined columns selected".
  post <- stratPosterior1
  post[["samples"]][, "alpha_site_2", 1, 1] <- 1  # constant
  post[["samples"]][150, "alpha_site_2", 1, 1] <- NaN

  s <- expect_no_error(suppressWarnings(summary(post)))
  expect_length(s[[1]][["multiESS"]], 1L)  # value is incidental
})
