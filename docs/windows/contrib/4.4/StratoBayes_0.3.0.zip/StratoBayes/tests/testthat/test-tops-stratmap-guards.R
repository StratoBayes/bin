test_that("Tops() rejects a stratData that does not match the StratModel", {
  expect_error(
    Tops(stratModel3, refHeights = c(1, 2), stratData = stratData1),
    "does not correspond to `stratObject`"
  )
})

test_that("StratMap() rejects an empty heights vector", {
  expect_error(
    StratMap(stratPosterior1, heights = numeric(0), site = 2),
    "heights must not be empty"
  )
})

test_that("StratMap()/Tops() collapse duplicated quantiles", {
  map <- StratMap(stratPosterior1, heights = 1, site = 2,
                  quantiles = c(0.5, 0.5, 0.1))
  expect_identical(colnames(map)[-(1:3)], c("10%", "50%"))
  tops <- Tops(stratPosterior1, refHeights = 1, quantiles = c(0.5, 0.5))
  expect_identical(sum(colnames(tops) == "50%"), 1L)
  expect_identical(.ValidateMapQuantiles("samples"), "samples")
})

test_that("Tops() rejects a stratData with fewer sites than the model", {
  expect_error(
    Tops(stratModel1, refHeights = c(-4, -1), stratData = stratData3),
    "does not correspond to `stratObject`"
  )
})

test_that("StratMapPlot() tolerates duplicated quantiles", {
  skip_on_cran()
  expect_no_error(
    StratMapPlot(stratPosterior1, quantiles = c(0.5, 0.5, 0.975), site = 2,
                 xResolution = 5)
  )
})
