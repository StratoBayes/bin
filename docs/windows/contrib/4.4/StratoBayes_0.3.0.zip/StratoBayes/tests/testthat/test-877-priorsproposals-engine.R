# RT-691 (#877): the C++ engine's `sample_all_from_prior()` draws every
# built-in prior from `model$priors$metro`, never from `priorsProposals`, so
# the documented override is inert under the default engine while the R engine
# honours it. For a built-in prior the posterior stays exact either way -- the
# C++ Hastings term is self-consistent precisely because it ignores the
# override -- so that is a knob that silently does nothing, not a wrong answer.
#
# A CUSTOM prior is the opposite case: the C++ engine does draw its sampler
# from `priorsProposals`, so the override is live and the `Prior` move proposes
# from a distribution that is not the prior. Here the two cases only have to
# warn differently, so neither is mistaken for the other.

WarnIgnored <- StratoBayes:::.WarnPriorsProposalsIgnored

set.seed(877)
.pp877Data <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
tmulti877 <- StratData(.pp877Data$signal, parts = .pp877Data$parts,
                       ties = .pp877Data$ties,
                       signalColumn = c("a", "b"), zColumn = "Hight",
                       siteColumn = "SIT")

.priors877 <- function() {
  structure(list(alpha_site1    = UniformPrior(min = 10, max = 60),
                 alpha_site2    = UniformPrior(min = 10, max = 60),
                 alpha_site3    = UniformPrior(min = -10, max = 60),
                 gammaLog_site1 = NormalPrior(mean = 1, sd = 1),
                 gammaLog_site2 = NormalPrior(mean = 2, sd = 0.5),
                 gammaLog_site3 = NormalPrior(mean = 3, sd = 2),
                 gap_site2_1    = ExponentialPrior(rate = 0.1)),
            class = c("StratPrior", "list"))
}

.model877 <- function(priorsProposals = NULL, priors = .priors877()) {
  StratModel(tmulti877, priors = priors,
             priorsProposals = priorsProposals,
             alignmentScale = "age", sedModel = "site",
             alphaPosition = "bottom")
}

test_that("#877: a built-in priorsProposals override warns under engine = cpp", {
  wider <- .priors877()
  wider[["alpha_site1"]] <- UniformPrior(min = -100, max = 200)

  expect_warning(WarnIgnored(.model877(wider), "cpp"),
                 "alpha_site1")
  expect_warning(WarnIgnored(.model877(wider), "cpp"),
                 "engine = \"R\"")
})

test_that("#877: the same override is silent under engine = R", {
  wider <- .priors877()
  wider[["alpha_site1"]] <- UniformPrior(min = -100, max = 200)

  expect_no_warning(WarnIgnored(.model877(wider), "R"))
})

test_that("#877: an absent or identical priorsProposals is silent", {
  expect_no_warning(WarnIgnored(.model877(), "cpp"))
  expect_no_warning(WarnIgnored(.model877(.priors877()), "cpp"))
})

test_that("#877: a differing distribution family is caught too", {
  swapped <- .priors877()
  swapped[["gammaLog_site1"]] <- UniformPrior(min = -5, max = 5)

  expect_warning(WarnIgnored(.model877(swapped), "cpp"), "gammaLog_site1")
})

# ── custom priors: the override is live ─────────────────────────────────────

# `.PrepareLogPostArgs()` classifies a prior as custom by failing to match its
# density against a built-in, so the density must not be `stats::dexp` itself.
.customExp <- function(rate) {
  Prior(R = function(n, lambda) stats::rexp(n, lambda),
        D = function(x, lambda, log = FALSE) stats::dexp(x, lambda, log = log),
        Q = function(p, lambda) stats::qexp(p, lambda),
        lambda = rate)
}

.customPriors877 <- function(rate = 0.1) {
  out <- .priors877()
  out[["gap_site2_1"]] <- .customExp(rate)
  out
}

test_that("#877: the fixture's custom prior really is custom", {
  model <- .model877(NULL, .customPriors877())
  types <- StratoBayes:::.PrepareLogPostArgs(model)[["priorTypes"]]
  gap <- match("gap_site2_1", names(model[[c("priors", "metro")]]))

  expect_false(is.na(gap))
  expect_identical(types[[gap]], "")
  expect_true(all(nzchar(types[-gap])))
})

test_that("#877: a custom priorsProposals override warns that it is honoured", {
  model <- .model877(.customPriors877(rate = 0.5), .customPriors877(0.1))

  expect_warning(WarnIgnored(model, "cpp"), "gap_site2_1")
  expect_warning(WarnIgnored(model, "cpp"), "is honoured for custom")
  expect_warning(WarnIgnored(model, "cpp"),
                 "not the parameter's prior")
})

test_that("#877: a custom override warns even when class and args agree", {
  # Same class ("Prior") and same `args`, different sampler -- the case class
  # and argument comparison alone cannot see.
  shifted <- .customPriors877()
  shifted[["gap_site2_1"]][["R"]] <- function(n, lambda) stats::rexp(n, 10)

  expect_warning(WarnIgnored(.model877(shifted, .customPriors877()), "cpp"),
                 "gap_site2_1")
})

test_that("#877: the custom-prior warning is not the built-in wording", {
  model <- .model877(.customPriors877(rate = 0.5), .customPriors877(0.1))
  msg <- tryCatch(WarnIgnored(model, "cpp"),
                  warning = function(w) conditionMessage(w))

  expect_false(grepl("is simply inert", msg, fixed = TRUE))
  expect_false(grepl("is ignored for built-in priors", msg, fixed = TRUE))
})

test_that("#877: an identical custom priorsProposals is silent", {
  expect_no_warning(
    WarnIgnored(.model877(.customPriors877(), .customPriors877()), "cpp"))
  expect_no_warning(WarnIgnored(.model877(NULL, .customPriors877()), "cpp"))
})

test_that("#877: the warning reaches the user through RunStratModel()", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  # A built-in override, so the C++ engine ignores it and the run is unchanged
  # -- only the setup-time warning differs.
  overridden <- stratModel1
  # Narrowly wider than the prior's own U(-6, 12), not U(-1e3, 1e3): a proposal
  # that wide makes every draw land outside the support, the run saves no
  # complete sample row, and `StratPosterior()` then dies reporting a
  # header-only file -- masking the warning this test is about. See #2012.
  overridden[["priorsProposals"]][[1]] <-
    UniformPrior(min = -6.5, max = 12.5)
  expect_true(nzchar(StratoBayes:::.PrepareLogPostArgs(
    overridden)[["priorTypes"]][[1]]))

  td <- file.path(tempdir(), "rt691")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE, showWarnings = FALSE)

  expect_warning(
    RunStratModel(stratObject = stratData1, stratModel = overridden,
                  nIter = 10, nChains = 1, seed = 1, quiet = TRUE,
                  visualise = FALSE, runParallel = FALSE, nThreads = 1L,
                  modelDir = td, modelName = "rt691"),
    "priorsProposals"
  )
})
