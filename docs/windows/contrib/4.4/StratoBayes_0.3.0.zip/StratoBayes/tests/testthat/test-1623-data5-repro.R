test_that("documented stratData5a/5b reproductions match the shipped data", {
  # R/data.R must reproduce data-raw/data5.R's calls exactly (#820, #1623).
  # `expect_identical()`, not `expect_equal()` with attributes excused: since
  # #1982 nothing stamps its inputs, so a fresh build is bit-identical to the
  # shipped object and any difference at all is a real one.
  expect_identical(StratData(signalData5, siteColumn = "site"), stratData5a)
  expect_identical(StratData(signalData5, ties = tiesData5, siteColumn = "site"),
                   stratData5b)
})
