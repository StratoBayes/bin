# Regression tests for the area-2 (run management) fixes: #1182, #1183, #1185,
# #1187.

# ── #1182: `timeLimit` is divided across sequential waves of runs ────────────

test_that(".RunConcurrency() counts runs that truly execute at once", {
  # `runParallel = 1` is truthy, so the run dispatches through `future` -- but
  # on a single worker, so the four runs are strictly sequential. Before the
  # fix, `!runParallel` was FALSE here and each of the four waves was granted
  # the entire `timeLimit`.
  expect_identical(.RunConcurrency(1, NULL, 4L), 1L)
  expect_identical(.RunConcurrency(3, NULL, 4L), 3L)
  expect_identical(.RunConcurrency(TRUE, 2L, 4L), 2L)
  expect_identical(.RunConcurrency(FALSE, 8L, 4L), 1L)
  # Never more workers than runs, and never fewer than one.
  expect_identical(.RunConcurrency(TRUE, 8L, 4L), 4L)
  expect_identical(.RunConcurrency(TRUE, NULL, 1L), 1L)
  expect_identical(.RunConcurrency(0, NULL, 4L), 1L)
  expect_identical(.RunConcurrency(TRUE, NA_integer_, 4L), 1L)

  # The wave count the time budget is divided by.
  Waves <- function(runParallel, nCores, nRun) {
    ceiling(nRun / .RunConcurrency(runParallel, nCores, nRun))
  }
  expect_identical(Waves(1, NULL, 4L), 4)     # was 1 before the fix
  expect_identical(Waves(3, NULL, 4L), 2)     # was 1 before the fix
  expect_identical(Waves(FALSE, NULL, 4L), 4) # unchanged
  expect_identical(Waves(TRUE, 4L, 4L), 1)    # unchanged
})

# ── #1183: a supplied StratMCMC template must still contain chain 1 ──────────

test_that("a fresh run rejects a supplied template whose saveChains omits 1", {
  template <- StratMCMC(stratModel1, nIter = 4, nChains = 2, saveChains = c(1, 2))
  template[["saveChains"]] <- 2

  # Before the fix this ran to completion: `StratMCMC()` never sees the
  # tampered template on this path, so nothing checked it, and convergence
  # stopping plus the adaptation timer silently no-opped for the whole run
  # (both select the cold chain by the value 1).
  expect_error(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = template,
                  visualise = FALSE, quiet = TRUE, runParallel = FALSE),
    "saveChains"
  )

  # The untampered template is unaffected.
  template[["saveChains"]] <- c(1, 2)
  run <- RunStratModel(stratData1, stratModel = stratModel1,
                       stratMCMC = template, visualise = FALSE, quiet = TRUE,
                       runParallel = FALSE)
  expect_equal(run[["mcmcSummary"]][["saveChains"]][[1]], c(1, 2))
})

# ── #1185: the live-plot iteration marker is read defensively ────────────────

test_that(".ReadPlotIteration() returns a single usable iteration number", {
  stem <- file.path(tempdir(), paste0("plotIterTest", as.integer(runif(1, 1e6, 1e7))))
  readFile <- paste0(stem, "_read.txt")
  on.exit(unlink(readFile), add = TRUE)

  # No file yet: nothing has been plotted.
  expect_identical(.ReadPlotIteration(stem), 0L)

  writeLines("17", readFile)
  expect_identical(.ReadPlotIteration(stem), 17L)

  # A zero-byte file used to return `integer(0)`, which reached the caller's
  # `if (i > lastPlotIteration)` and aborted the whole run with "argument is
  # of length zero".
  unlink(readFile)
  file.create(readFile)
  expect_identical(.ReadPlotIteration(stem), 0L)

  # A file that will never parse used to spin the retry loop forever. It now
  # gives up after `maxAttempts` and reports "nothing plotted yet", which at
  # worst re-plots one iteration.
  writeLines("not-a-number", readFile)
  elapsed <- system.time(value <- .ReadPlotIteration(stem, maxAttempts = 5L))
  expect_identical(value, 0L)
  expect_lt(elapsed[["elapsed"]], 5)
})

# ── #1187: profiling averages over every run, not only runs that sampled ─────

test_that(".AggregateProfilingData() treats an unsampled function as zero", {
  BySelf <- function(functions, selfTime, totalTime) {
    data.frame(self.time = selfTime, self.pct = 100 * selfTime / sum(selfTime),
               total.time = totalTime,
               total.pct = 100 * totalTime / sum(totalTime),
               row.names = functions)
  }
  summaries <- list(
    list(by.self = BySelf(c("f", "g"), c(10, 6), c(10, 6))),
    list(by.self = BySelf("g", 6, 6))
  )

  aggregated <- .AggregateProfilingData(summaries)

  # "f" cost 10 s in one run and nothing in the other: a 5 s per-run mean, and
  # a minimum of 0. Before the fix it was averaged over the single run it
  # appeared in (mean 10, min 10)...
  fRow <- aggregated[aggregated[["Function"]] == "f", ]
  expect_equal(fRow[["total.time.mean"]], 5)
  expect_equal(fRow[["total.time.min"]], 0)
  expect_equal(fRow[["total.time.max"]], 10)

  gRow <- aggregated[aggregated[["Function"]] == "g", ]
  expect_equal(gRow[["total.time.mean"]], 6)
  expect_equal(gRow[["total.time.min"]], 6)

  # ...which put "f" (10) above "g" (6) at the head of the summary, though "g"
  # is the more expensive function per run.
  expect_identical(aggregated[["Function"]][[1]], "g")
  expect_identical(aggregated[["Function"]][[2]], "f")
})
