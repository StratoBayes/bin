# GH #1910: the .sb_sed_spline_* exports indexed formations and sedBeta
# unchecked, so formationIdx = 0 segfaulted and a short sedBeta was read past
# its end. GH #1911: sedSplineAges extrapolated the cubic above hHigh while the
# partial integral clipped there.

SedSplineInfo <- function(nForm = 2L) {
  forms <- lapply(seq_len(nForm), function(f) {
    .BuildFormationSpline(10 * (f - 1), 10 * f, 8L, f)
  })
  nBasis <- forms[[1]][["nBasis"]]
  list(nFormations = nForm, nBasis = nBasis, totalBeta = nForm * nBasis,
       betaStart = as.integer(1L + nBasis * (seq_len(nForm) - 1L)),
       betaMap = matrix(seq_len(nForm), ncol = 1L), formations = forms)
}

test_that(".sb_sed_spline_* reject an out-of-range formationIdx (#1910)", {
  info <- SedSplineInfo()
  beta <- rep(0, info[["totalBeta"]])
  for (idx in c(0L, 3L, NA_integer_)) {
    expect_error(.sb_sed_spline_full_integral(beta, info, idx), "formationIdx")
    expect_error(.sb_sed_spline_partial_integral(beta, info, idx, 0, 1),
                 "formationIdx")
    expect_error(.sb_sed_spline_ages(beta, info, idx, 1, 0, 1), "formationIdx")
  }
  expect_equal(.sb_sed_spline_full_integral(beta, info, 2L), 10)
})

test_that(".sb_sed_spline_* reject a sedBeta shorter than totalBeta (#1910)", {
  info <- SedSplineInfo()
  short <- rep(0, info[["totalBeta"]] - 1L)
  expect_error(.sb_sed_spline_full_integral(short, info, 2L), "sedBeta")
  expect_error(.sb_sed_spline_partial_integral(short, info, 2L, 10, 11),
               "sedBeta")
  expect_error(.sb_sed_spline_ages(short, info, 2L, 11, 0, 1), "sedBeta")

  info[["betaStart"]][1] <- 0L
  expect_error(.sb_sed_spline_full_integral(rep(0, info[["totalBeta"]]),
                                            info, 1L), "betaStart")
})

test_that("sedSplineAges clips out-of-range heights (#1911)", {
  info <- SedSplineInfo(1L)
  beta <- seq(-0.5, 0.5, length.out = info[["totalBeta"]])
  full <- .sb_sed_spline_full_integral(beta, info, 1L)
  expect_equal(.sb_sed_spline_partial_integral(beta, info, 1L, -5, 20), full)

  ages <- .sb_sed_spline_ages(beta, info, 1L, c(-5, 0, 10, 15, 20), 100, 1)
  expect_equal(ages, c(100, 100, 100 + full, 100 + full, 100 + full))
  expect_equal(.sb_sed_spline_ages(beta, info, 1L, 20, 100, -1), 100 - full)
})
