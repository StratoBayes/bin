# Area 7: Prior() construction and prior validation.
# GH #1263 (Q return unchecked), #1264 (args need not be uniquely named),
# #1265 (Fixed inferred from an argument name), #1266 (four validation gaps),
# #1267 (typed prior with mutated args diverges between engines).

MakeCustom <- function(R = function(n, ...) rnorm(n),
                       D = function(x, log = FALSE, ...) dnorm(x, log = log),
                       Q = function(p, ...) qnorm(p)) {
  structure(list(theParam = Prior(R, D, Q)),
            class = c("list", "StratPrior"))
}

# ── #1264: `...` must be fully and uniquely named ────────────────────────────

test_that("GH #1264: unnamed `Prior()` arguments are rejected", {
  # `modifyList()` drops these, so every smoke test ran against the density's
  # own defaults, while production splices them in positionally.
  expect_error(Prior(runif, dunif, qunif, 5, 2), "no name")
  expect_error(Prior(runif, dunif, qunif, min = 0, 2), "argument 2 of 2")
})

test_that("GH #1264: duplicated `Prior()` argument names are rejected", {
  expect_error(Prior(runif, dunif, qunif, min = 0, min = 1),
               "supplied more than once")
})

test_that("GH #1264: correctly named and argument-free priors still build", {
  expect_s3_class(Prior(runif, dunif, qunif, min = 0, max = 1), "Prior")
  expect_s3_class(Prior(rnorm, dnorm, qnorm), "Prior")
  expect_s3_class(UniformPrior(0, 1), "Prior")
})

test_that("GH #1264: `.PriorsValidity()` catches a hand-built unnamed args list", {
  # A prior list assembled without `Prior()` bypasses the constructor check.
  handBuilt <- structure(
    list(theParam = list(R = runif, D = dunif, Q = qunif,
                         args = list(5, 2))),
    class = c("list", "StratPrior"))
  expect_error(.PriorsValidity(handBuilt), "theParam")
  expect_error(.PriorsValidity(handBuilt), "no name")
})

# ── #1263: Q's smoke-test return value ───────────────────────────────────────

test_that("GH #1263: a non-finite Q(0.5) is rejected", {
  # `CreateSplineS()` derives the knot range from Q(0.5); a non-finite median
  # used to surface much later as an unrelated CreateSplineS error.
  expect_error(.PriorsValidity(MakeCustom(Q = function(p, ...) Inf)),
               "single finite numeric value")
  expect_error(.PriorsValidity(MakeCustom(Q = function(p, ...) NA_real_)),
               "single finite numeric value")
})

test_that("GH #1263: a wrong-shaped Q return is rejected", {
  expect_error(.PriorsValidity(MakeCustom(Q = function(p, ...) c(1, 2))),
               "single finite numeric value")
  expect_error(.PriorsValidity(MakeCustom(Q = function(p, ...) "middle")),
               "single finite numeric value")
})

test_that("GH #1263: a well-formed Q still validates", {
  expect_true(.PriorsValidity(MakeCustom()))
  expect_true(.PriorsValidity(stratPrior1))
})

# ── #1266 item 1: the log-consistency check must not depend on the RNG ───────

test_that("GH #1266: D log-consistency is checked at deterministic points", {
  # Log-consistent for x >= 0, natural-scale (so, wrong) below it. Evaluated at
  # a single R() draw, this passed or failed according to ambient RNG state.
  halfBad <- function(x, log = FALSE, ...) {
    d <- dnorm(x)
    if (x < 0) d else if (isTRUE(log)) log(d) else d
  }
  verdicts <- vapply(1:8, function(s) {
    set.seed(s)
    inherits(try(.PriorsValidity(MakeCustom(D = halfBad)), silent = TRUE),
             "try-error")
  }, logical(1))
  expect_true(all(verdicts))
})

test_that("GH #1266: a fully log-consistent D still passes at every seed", {
  for (s in 1:4) {
    set.seed(s)
    expect_true(.PriorsValidity(MakeCustom()))
  }
})

# ── #1266 item 2: Fixed value comparison is numeric, not type-sensitive ──────

test_that("GH #1266: Fixed(1L) and Fixed(1) are not treated as different", {
  pri <- structure(list(a = Fixed(1L), b = UniformPrior(0, 1)),
                   class = c("list", "StratPrior"))
  pps <- structure(list(a = Fixed(1), b = UniformPrior(0, 1)),
                   class = c("list", "StratPrior"))
  expect_true(.CheckFixedPriorsProposals(pri, pps))
})

test_that("GH #1266: a genuinely different Fixed value is still rejected", {
  pri <- structure(list(a = Fixed(1)), class = c("list", "StratPrior"))
  expect_error(
    .CheckFixedPriorsProposals(
      pri, structure(list(a = Fixed(2)), class = c("list", "StratPrior"))),
    "differently-valued")
  expect_error(
    .CheckFixedPriorsProposals(
      pri, structure(list(a = UniformPrior(0, 1)),
                     class = c("list", "StratPrior"))),
    "differently-valued")
})

# ── #1266 item 4: the R warning handler is not a format string ───────────────

test_that("GH #1266: a warning containing `%` is reported, not swallowed", {
  pct <- MakeCustom(R = function(n, ...) {
    warning("probability > 100% of the time")
    rnorm(n)
  })
  # Previously `stop(sprintf(w$message))` used the warning text as the format
  # string, so the `%` broke sprintf and the real diagnostic was discarded.
  expect_error(.PriorsValidity(pct), "probability > 100% of the time",
               fixed = TRUE)
  expect_error(.PriorsValidity(pct), "theParam", fixed = TRUE)
})

# ── #1265: Fixed-ness is structural, not an argument-name heuristic ──────────

test_that("GH #1265: a custom prior whose first arg is `value` is not Fixed", {
  valued <- Prior(function(n, value, ...) rnorm(n, value),
                  function(x, value, log = FALSE, ...) dnorm(x, value,
                                                             log = log),
                  function(p, value, ...) qnorm(p, value),
                  value = 5)
  expect_false(.FixedMetroParams(list(theParam = valued), "theParam")[[1]])
})

test_that("GH #1265: a prior with no named args does not crash the check", {
  expect_false(
    .FixedMetroParams(list(theParam = Prior(rnorm, dnorm, qnorm)),
                      "theParam")[[1]])
})

test_that("GH #1265: genuine Fixed priors are still detected", {
  metro <- list(f = Fixed(3), u = UniformPrior(0, 1),
                bare = Prior(.fixed_R, .fixed_D, .fixed_Q, value = 3))
  expect_identical(unname(.FixedMetroParams(metro, c("f", "u", "bare"))),
                   c(TRUE, FALSE, TRUE))
  expect_identical(unname(.FixedMetroParams(metro, character(0))), logical(0))
})

# ── #1267: a typed prior's args must match its class ─────────────────────────

MetroModel <- function(...) list(priors = list(metro = list(...)))

test_that("GH #1267: a typed prior with a dropped arg is rejected in R", {
  # The C++ engine reads args["sd"] unguarded; the R engine would silently fall
  # back to dnorm()'s own sd = 1. Both must now fail here instead.
  mutated <- NormalPrior(0, 2)
  mutated[["args"]][["sd"]] <- NULL
  expect_error(.PrepareLogPostArgs(MetroModel(gammaLog_site_2 = mutated)),
               "classed `NormalPrior`")
  expect_error(.PrepareLogPostArgs(MetroModel(gammaLog_site_2 = mutated)),
               "gammaLog_site_2")
})

test_that("GH #1267: a reordered LogNormalPrior is rejected", {
  # `parsePriorFromR()` reads meanlog/sdlog positionally.
  swapped <- LogNormalPrior(0, 2)
  swapped[["args"]] <- swapped[["args"]][c("sdlog", "meanlog")]
  expect_error(.PrepareLogPostArgs(MetroModel(a = swapped)),
               "classed `LogNormalPrior`")
})

test_that("GH #1267: every bundled prior type still resolves to its type", {
  built <- list(UniformPrior(0, 1), NormalPrior(0, 1), LogNormalPrior(0, 1),
                ExponentialPrior(1), TruncNormalPrior(0, 1, -2, 2),
                TruncLogNormalPrior(0, 1, 0.1, 2), Fixed(1))
  expect_identical(
    do.call(.PrepareLogPostArgs, list(list(priors = list(metro = built))))[[
      "priorTypes"]],
    c("UniformPrior", "NormalPrior", "LogNormalPrior", "ExponentialPrior",
      "TruncNormalPrior", "TruncLogNormalPrior", "Fixed"))
  # a bare custom prior is still routed to the R density callback
  expect_identical(
    .PrepareLogPostArgs(MetroModel(Prior(rnorm, dnorm, qnorm)))[["priorTypes"]],
    "")
})

# An attribute on the args names makes a bare `identical(names(args), required)`
# FALSE for names that are plainly equal. `StratMCMC()` used to stamp one via
# fastmatch's `.match.hash`; fastmatch has since left the package (#1982), so
# the two tests below stamp it themselves rather than testing nothing.
.StampArgNames <- function(model) {
  metro <- model[[c("priors", "metro")]]
  for (i in seq_along(metro)) {
    args <- metro[[i]][["args"]]
    nm <- names(args)
    attr(nm, "stamp") <- "x"
    # `attr(args, "names")` and not `names(args)`: the replacement function
    # coerces with `as.character()`, which drops exactly the attribute under
    # test here.
    attr(args, "names") <- nm
    metro[[i]][["args"]] <- args
  }
  model[["priors"]][["metro"]] <- metro
  model
}

test_that("GH #1267: the args check survives an attribute on the names", {
  # Only a *typed* prior reaches the guard, hence the typed fixture.
  typed <- structure(list(alpha_site_2 = UniformPrior(-6, 12),
                          alpha_site_3 = UniformPrior(-6, 12),
                          gammaLog_site_2 = NormalPrior(0, 0.7),
                          gammaLog_site_3 = NormalPrior(0, 0.7)),
                     class = c("StratPrior", "list"))
  m <- StratModel(stratData1, typed, alignmentScale = "height",
                  sedModel = "site")
  m <- .StampArgNames(m)
  expect_false(is.null(attributes(
    names(m[[c("priors", "metro")]][[1]][["args"]]))))
  expect_identical(.PrepareLogPostArgs(m)[["priorTypes"]],
                   c("UniformPrior", "UniformPrior", "NormalPrior",
                     "NormalPrior"))
})

test_that("a bare LogNormal Prior() is still inferred with a stamped name", {
  # `.InferPriorType()`'s ordered check had the same fragility: with the names
  # stamped, the prior was demoted to custom, swapping the native C++ density
  # for an R callback and its bounded transform for the identity.
  pri <- structure(list(
    alpha_site_2 = Prior(rlnorm, dlnorm, qlnorm, meanlog = 0, sdlog = 0.7),
    alpha_site_3 = UniformPrior(-6, 12),
    gammaLog_site_2 = NormalPrior(0, 0.7),
    gammaLog_site_3 = NormalPrior(0, 0.7)), class = c("StratPrior", "list"))
  m <- StratModel(stratData1, pri, alignmentScale = "height",
                  sedModel = "site")
  m <- .StampArgNames(m)
  expect_identical(.InferPriorType(m[[c("priors", "metro")]][[1]]),
                   "LogNormalPrior")
})
