test_that(".GenerateTestData generates valid data", {
testData <- .GenerateTestData("multi", "gap-3-sites-dates-longer")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("a", "b"))
expect_s3_class(stratD, "StratData")
expect_equal(stratD[["S"]], 3)
expect_true(nrow(testData$signal) > 0)

testData <- .GenerateTestData("single", "1c")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")
expect_true(nrow(testData$signal) > 0)

testData <- .GenerateTestData("single", "4")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")
expect_true(nrow(testData$signal) > 0)
expect_true(nrow(testData$parts) > 0)

})

test_that(".GenerateTestData rejects a version it no longer ships", {
  # "2" was byte-identical to "1c" and has been withdrawn.
  expect_error(.GenerateTestData("single", "2"), "Unrecognised `version`")
})

test_that('.GenerateTestData("multi") is pinned to its seed-1 stream', {
  # Every "multi" fixture in the suite is built from these draws, so any
  # inserted, removed or reordered rnorm() call in the generator -- including
  # deleting the unread `hb2` -- moves them all. Values are those of the
  # generator as shipped; a change here is a fixture change, not a test bug.
  signal <- .GenerateTestData("multi")[["signal"]]
  # Shape only: nrow is n1 + 2 * n2, with no RNG dependence.
  expect_identical(nrow(signal), 164L)
  # Leading values localise a break to the first draws; the column sums are
  # what make the pin whole-stream, catching a reordering confined to the tail.
  expect_equal(signal[["a"]][1:2], c(2.0454451, 2.8349948), tolerance = 1e-7)
  expect_equal(signal[["b"]][c(1, 2, 4)],
               c(9.8068785, 9.8383991, 10.641400), tolerance = 1e-7)
  expect_equal(sum(signal[["a"]], na.rm = TRUE), 3012.0711018, tolerance = 1e-9)
  expect_equal(sum(signal[["b"]], na.rm = TRUE), 1531.7356160, tolerance = 1e-9)
})

test_that(".GenerateTestData builds site 3 without a `gap` token (#1230)", {
  # `3-sites` used to be nested inside the `gap` branch, so this composition
  # silently produced two sites -- and, with `dates`, a tie on the absent
  # third.
  noGap <- .GenerateTestData("multi", "3-sites-dates")
  expect_setequal(unique(noGap[["signal"]][["site"]]),
                  c("site1", "site2", "site3"))
  expect_true("site3" %in% noGap[["parts"]][["site"]])
  expect_true("site3" %in% noGap[["ties"]][["site"]])

  # Every tie names a site the signal actually holds.
  expect_true(all(noGap[["ties"]][["site"]] %in% noGap[["signal"]][["site"]]))

  # Discriminator: the two-site composition still has no site 3 and no tie
  # naming one, so the assertions above are not true of every version.
  twoSites <- .GenerateTestData("multi", "dates")
  expect_false("site3" %in% twoSites[["signal"]][["site"]])
  expect_false("site3" %in% twoSites[["ties"]][["site"]])
})

test_that(".GenerateTestData rejects an unrecognised multi token (#1230)", {
  # A typo used to fall through to a different, incomplete fixture in silence.
  expect_error(.GenerateTestData("multi", "date"), "Unrecognised token .date.")
  expect_error(.GenerateTestData("multi", "3sites"), "Unrecognised token")
  expect_error(.GenerateTestData("multi", "gap-nmaes"),
               "Unrecognised token .nmaes.")

  # Every composition the test suite and data-raw/ actually pass must survive.
  inUse <- c("1", "gap", "gap-names", "gap-names-3-sites",
             "gap-names-3-sites-dates", "gap-3-sites-dates-longer")
  for (version in inUse) {
    expect_s3_class(.GenerateTestData("multi", version)[["signal"]],
                    "data.frame")
  }
})

test_that("a repeated token is rejected, not silently collapsed (#1230)", {
  # `sub()`'s single pass is what leaves a residue here; a `gsub()` would strip
  # `"gap-gap"` to `""` and accept it. This pins the choice, which reads like an
  # oversight and is not.
  expect_error(.GenerateTestData("multi", "gap-gap"), "Unrecognised token")
  expect_error(.GenerateTestData("multi", "3-sites-3-sites"), "Unrecognised token")
  # The over-rejection control: a legitimate composition sharing a token still
  # strips cleanly.
  expect_named(.GenerateTestData("multi", "gap-3-sites"), c("signal", "parts"))
})
