# #1312 / #1313 / #1314: SiteBlock block assembly and covariance construction,
# the HMC/NUTS mass-matrix floors, and two hygiene items in the R-engine
# proposal machinery.


# ── #1312 item 4: SiteBlock block assembly under "site x partition" ──────────
# gamma is per *partition* under this sedModel and shared across sites; the
# per-site sedimentation factor is `zeta`. `.BuildMassBlocks()` already pairs
# alpha with zeta here (RT-344, test-mass-blocks.R); `.BuildSiteBlocks()` used
# the same alpha[k] <-> gamma[k] rule for both sedModels.

.sbModel <- function(alpha, gamma, zeta = NULL, sedModel, nParam,
                     fixed = integer(0)) {
  list(
    parametersLength = nParam,
    parametersLengthNotFixed = nParam - length(fixed),
    siteIndices = seq_along(alpha),
    ind = list(paramNotFixed = setdiff(seq_len(nParam), fixed),
               alpha = alpha, gamma = gamma, zeta = zeta,
               sedModel = sedModel),
    priors = list(metro = rep(list(list(args = list(min = 0, max = 10))),
                              nParam))
  )
}

.blockIdx <- function(blocks) lapply(blocks, `[[`, "indices")

test_that("SiteBlock pairs alpha with zeta under site x partition (#1312)", {
  # Age scale, S = 3, L = 2 unique partitions -- the RT-344 fixture shape:
  #   alpha 1:3 (sites), gamma 4:5 (partitions), zeta 6:7 (sites 2-3), gap 8.
  model <- .sbModel(alpha = 1:3, gamma = 4:5, zeta = 6:7,
                    sedModel = "site x partition", nParam = 8L)
  blocks <- .BuildSiteBlocks(model)
  idx <- .blockIdx(blocks)

  # PRE-FIX: list(c(1, 4), c(2, 5), 3) -- alpha_site1 with partition 1's gamma,
  # alpha_site2 with partition 2's gamma, alpha_site3 with nothing, and zeta
  # absent from every block.
  paired <- Filter(function(i) length(i) > 1L, idx)
  expect_equal(paired, list(c(2L, 6L), c(3L, 7L)))

  # No gamma may share a block with anything: under this sedModel a gamma is
  # not a per-site parameter, so it correlates with no particular alpha.
  expect_false(any(4:5 %in% unlist(paired)))

  # Coverage grows and never shrinks: zeta -- the parameter alpha actually
  # trades off against -- was in no block at all before.
  expect_setequal(unlist(idx), c(1:5, 6:7))
  singles <- unlist(Filter(function(i) length(i) == 1L, idx))
  expect_setequal(singles, c(1L, 4L, 5L))
})

test_that("SiteBlock does not pair alpha with gamma when L == S (#1312)", {
  # The sharpest red case: length(alpha) == length(gamma) == 3, so the pre-fix
  # 1:1 loop produced three *fully populated* wrong blocks rather than
  # silently short ones.
  model <- .sbModel(alpha = 1:3, gamma = 4:6, zeta = 7:8,
                    sedModel = "site x partition", nParam = 8L)
  idx <- .blockIdx(.BuildSiteBlocks(model))

  paired <- Filter(function(i) length(i) > 1L, idx)
  # PRE-FIX: list(c(1, 4), c(2, 5), c(3, 6)).
  expect_equal(paired, list(c(2L, 7L), c(3L, 8L)))
  expect_false(any(4:6 %in% unlist(paired)))
  expect_setequal(unlist(idx), 1:8)
})

test_that("SiteBlock leaves the plain site model unchanged (#1312)", {
  # Same index layout as the L == S case above, minus zeta: pins that the fix
  # discriminates on sedModel, not on shape.
  model <- .sbModel(alpha = 1:3, gamma = 4:6, sedModel = "site", nParam = 6L)
  expect_equal(.blockIdx(.BuildSiteBlocks(model)),
               list(c(1L, 4L), c(2L, 5L), c(3L, 6L)))

  # ... and a fixed partner still leaves the free member proposing alone.
  fixedModel <- .sbModel(alpha = 1:3, gamma = 4:6, sedModel = "site",
                         nParam = 6L, fixed = 5L)
  expect_equal(.blockIdx(.BuildSiteBlocks(fixedModel)),
               list(c(1L, 4L), 2L, c(3L, 6L)))
})

test_that("both block builders derive the same pairing (#1312)", {
  # The two builders answer the same question -- which rate parameter does
  # each alpha trade off against -- from the same `ind` fields, and only
  # `.BuildMassBlocks()` was fixed (RT-344). With every parameter free its
  # free indices equal its full ones, so the pairs are directly comparable.
  pairsOf <- function(blocks, field) {
    Filter(function(i) length(i) > 1L, lapply(blocks, `[[`, field))
  }
  for (model in list(
    .sbModel(alpha = 1:3, gamma = 4:5, zeta = 6:7,
             sedModel = "site x partition", nParam = 8L),
    .sbModel(alpha = 1:3, gamma = 4:6, sedModel = "site", nParam = 6L)
  )) {
    expect_equal(pairsOf(.BuildSiteBlocks(model), "indices"),
                 pairsOf(.BuildMassBlocks(model), "idx"))
  }
})

test_that("SiteBlock keeps the joint block for other sedModels (#1312)", {
  model <- .sbModel(alpha = 1:3, gamma = 4:6, sedModel = "partition",
                    nParam = 6L)
  expect_equal(.blockIdx(.BuildSiteBlocks(model)), list(1:6))
})


# ── #1312 items 1-3: SiteBlock covariance regularisation and singletons ──────
# Tested through `.UpdateProposal()` so the block gate itself is exercised, not
# just the covariance arithmetic.

# 6 free parameters on a [0, 10] prior (fallback SD = 10 / 8 = 1.25):
#   block A = (1, 2): column 2 constant over the whole retained history
#   block B = (3)   : a singleton, which adaptation skipped entirely
#   block C = (4, 5, 6): rank 2 in 3 dimensions (col 6 = col 4 + col 5)
.blockFixture <- function(nRow = 12L) {
  nParam <- 6L
  set.seed(1312)
  hist <- matrix(0, nRow, nParam)
  hist[, 1] <- seq(1, 2, length.out = nRow)
  hist[, 2] <- 3.5
  hist[, 3] <- seq(5, 6, length.out = nRow)
  hist[, 4] <- rnorm(nRow, 100, 20)
  hist[, 5] <- rnorm(nRow, 0, 1)
  hist[, 6] <- hist[, 4] + hist[, 5]

  blocks <- list(
    list(indices = 1:2, chol = NULL, fallbackSD = c(1.25, 1.25)),
    list(indices = 3L,  chol = NULL, fallbackSD = 1.25),
    list(indices = 4:6, chol = NULL, fallbackSD = rep(1.25, 3L))
  )
  model <- list(
    parametersLength = nParam, parametersLengthNotFixed = nParam,
    ind = list(paramNotFixed = seq_len(nParam))
  )
  mcmc <- list(
    nChains = 1L, currentIter = 10L, endAdapting = 100L, startAdapting = 1L,
    propose = setNames(vector("list", 1L), "SiteBlock"),
    temper = list(temperatures = 1, tempering = FALSE),
    metro = list(
      historySize = nRow, historyLength = nRow, historyRingPos = 1L,
      enableRingBuffer = FALSE, clustWithParametersMCMC = TRUE,
      nProposals = 1L,
      proposalValid = matrix(FALSE, 1L, 1L,
                             dimnames = list(NULL, "SiteBlock")),
      proposalProbability = matrix(1, 1L, 1L,
                                   dimnames = list(NULL, "SiteBlock")),
      proposalArgs = list(chain1 = list(SiteBlock = list(blocks = blocks))),
      adaptProposal = TRUE,
      chainHistory = list(cbind(hist, 0)),
      historyStamp = list(seq_len(nRow)),
      historyStampNext = nRow + 1L
    )
  )
  list(model = model, mcmc = mcmc, hist = hist)
}

.adaptedBlocks <- function(f) {
  metro <- .UpdateProposal(data = list(), model = f[["model"]],
                           mcmc = f[["mcmc"]], chain = 1L,
                           inLateAdaptation = FALSE)
  metro[["proposalArgs"]][["chain1"]][["SiteBlock"]][["blocks"]]
}

test_that("a constant block column clears the distinct-row gate (#1312)", {
  f <- .blockFixture()
  # The premise: the gate counts distinct *rows* of the block, so a constant
  # column reaches cov() rather than being screened out.
  expect_gte(nrow(unique(f[["hist"]][, 1:2])), 3L)
  expect_identical(stats::sd(f[["hist"]][, 2]), 0)
})

test_that("a degenerate SiteBlock column is floored to scale (#1312)", {
  f <- .blockFixture()
  blk <- .adaptedBlocks(f)[[1]]

  # PRE-FIX the only regularisation was `diag(covMat) + 1e-10`, so this was
  # 1e-5 -- a step of 1e-5 * proposalFactor whatever units the parameter is in.
  # POST-FIX the floor is 1% of this proposal's OWN prior-range fallback SD,
  # the same 1% of the same kind of basis the Univariate floor uses (#1191).
  floorSD <- 0.01 * 1.25
  raw <- stats::cov(f[["hist"]][, 1:2])
  expect_equal(blk[["chol"]][2, 2], sqrt(floorSD ^ 2 * 1.001 + 1e-10))
  expect_gt(blk[["chol"]][2, 2], 1e-3)

  # The informative column keeps its empirical variance, up to the ridge: the
  # floor must touch only the degenerate entries. Its variance is two orders
  # of magnitude above the floor, so the floor cannot be what sets it.
  expect_equal(blk[["chol"]][1, 1], sqrt(raw[1, 1] * 1.001 + 1e-10))
  expect_gt(raw[1, 1] / floorSD ^ 2, 100)
})

test_that("SiteBlock regularisation is scale-relative (#1312)", {
  f <- .blockFixture()
  blk <- .adaptedBlocks(f)[[3]]
  raw <- stats::cov(f[["hist"]][, 4:6])

  # Rank 2 in 3 dimensions: the third direction carries no empirical variance
  # at all, so what it gets is entirely the regularisation.
  expect_equal(qr(raw)[["rank"]], 2L)
  L <- blk[["chol"]]
  reconstructed <- L %*% t(L)
  minEig <- min(eigen(reconstructed, symmetric = TRUE)[["values"]])

  # PRE-FIX the ridge was the absolute 1e-10, so the null direction got a
  # proposal SD of 1e-5 on parameters whose own SD is ~20.
  # POST-FIX every coordinate is ridged by 0.1% of its OWN variance, so the
  # null direction lifts to a fixed fraction of the block's scale without the
  # widest coordinate setting the floor for the narrowest.
  expected <- raw
  diag(expected) <- diag(raw) * 1.001 + 1e-10
  expect_equal(reconstructed, expected)
  # The columns differ in variance by ~400x, so a `mean(diag)`-relative ridge
  # would put a visibly different number here.
  expect_gt(max(diag(raw)) / min(diag(raw)), 100)
  expect_gt(minEig, 0.001 * min(diag(raw)))

  # Scale-invariance is the point: rescaling the block rescales the ridge.
  g <- .blockFixture()
  g[["hist"]][, 4:6] <- g[["hist"]][, 4:6] * 1000
  g[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(g[["hist"]], 0))
  scaled <- .adaptedBlocks(g)[[3]]
  expect_equal(min(eigen(scaled[["chol"]] %*% t(scaled[["chol"]]),
                         symmetric = TRUE)[["values"]]) - 1e-10,
               1e6 * (minEig - 1e-10))
})

test_that("a singleton SiteBlock adapts (#1312)", {
  f <- .blockFixture()
  blk <- .adaptedBlocks(f)[[2]]

  # PRE-FIX `if (k < 2L) next` skipped every 1-parameter block, so `chol` stayed
  # NULL for the whole run and the parameter kept its prior-range fallback SD,
  # adapted only through the scalar proposalFactor.
  expect_false(is.null(blk[["chol"]]))
  v <- stats::var(f[["hist"]][, 3])
  expect_equal(as.vector(blk[["chol"]]), sqrt(v * 1.001 + 1e-10))
  # It must stay a matrix: the C++ engine reads it with as<NumericMatrix>().
  expect_true(is.matrix(blk[["chol"]]))
  expect_equal(dim(blk[["chol"]]), c(1L, 1L))
})

test_that("SiteBlock adaptation still refuses a too-short history (#1312)", {
  f <- .blockFixture(nRow = 12L)
  short <- f[["hist"]]
  short[] <- rep(short[1, ], each = 12L)      # every row identical
  f[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(short, 0))
  expect_true(all(vapply(.adaptedBlocks(f),
                         function(b) is.null(b[["chol"]]), logical(1))))
})


# ── #1313: HMC/NUTS mass-matrix floors ───────────────────────────────────────
# `massMatInv` (= `invMat`) holds M^{-1} = Sigma, and `cholMat` is the lower
# Cholesky of M = Sigma^{-1}. The floors apply to Sigma, so raising them
# enlarges the frozen coordinate's leapfrog step. `.BuildMassBlocks()` stamps
# each block with the prior-range variance its coordinates fall back to.

# ranges[i] is parameter i's prior support width; `sedModel = "partition"`
# takes the unpaired branch, so every block is 1x1 -- the branch that carries
# most coordinates in every model, and *all* of them here.
.massModel <- function(ranges, sedModel = "partition") {
  n <- length(ranges)
  list(
    parametersLength = n, parametersLengthNotFixed = n,
    ind = list(paramNotFixed = seq_len(n), alpha = 1L, gamma = 2L,
               zeta = NULL, sedModel = sedModel),
    priors = list(metro = lapply(ranges, function(r) {
      list(args = list(min = 0, max = r))
    }))
  )
}

# Fill one block's Welford state so it reconstructs `sigma` exactly.
.withHistory <- function(block, sigma, mean = 0, wN = 20L) {
  block[["wN"]] <- wN
  block[["wM2"]] <- as.vector(sigma) * (wN - 1L)
  block[["wMean"]] <- rep(mean, block[["k"]])
  block
}

test_that("the mass-matrix gate is joint, not per-coordinate (#1313)", {
  # The premise: plenty of joint variation with one constant column still
  # passes `nrow(unique(freeHistory)) < 3L`.
  set.seed(1313)
  freeHistory <- cbind(rnorm(20), 7)
  expect_gte(nrow(unique(freeHistory)), 3L)
  expect_identical(stats::var(freeHistory[, 2]), 0)
})

# Widths of 1e4 and 1e2 put both floors (1 and 1e-4) far above testthat's
# absolute tolerance, which would otherwise call any two sub-1e-8 variances
# equal and let a wrong floor pass.
test_that("the block builder carries a prior-range variance floor (#1313)", {
  blocks <- .BuildMassBlocks(.massModel(c(1e4, 1e2)))
  expect_equal(vapply(blocks, `[[`, integer(1), "k"), c(1L, 1L))
  # 1% of `.PriorRangeSDs()` = 1% of 1% of the prior width, squared: the
  # Univariate SD floor (#1191) on the variance scale.
  expect_equal(vapply(blocks, `[[`, numeric(1), "varFloor"), c(1, 1e-4))
})

test_that("a constant 1x1 coordinate is floored to prior scale (#1313)", {
  # The dominant path: `.BuildMassBlocks()` emits a 1x1 block for every
  # coordinate it does not pair, and under this sedModel that is all of them.
  blocks <- .BuildMassBlocks(.massModel(c(1e4, 1e2)))
  # A coordinate pinned at 42 for the whole history: variance exactly 0.
  out <- .AdaptMassBlocks(list(.withHistory(blocks[[2]], matrix(0), mean = 42)))

  # PRE-FIX `max(v, 1e-12)` left M^{-1} at 1e-12 whatever the parameter's
  # units, so the leapfrog position step eps * M^{-1} p had scale 1e-6 * eps
  # for a coordinate ranging over 100 Myr.
  expect_equal(out[[1]][["invMat"]], 1e-4)
  expect_equal(sqrt(out[[1]][["invMat"]]) / sqrt(1e-12), 1e4)
  # cholMat is chol(M) = 1/sqrt(Sigma), not sqrt(Sigma): inverting the two
  # leaves stationarity correct and wrecks mixing. PRE-FIX this was 1e6.
  expect_equal(out[[1]][["cholMat"]], 100)
})

test_that("the 1x1 floor tracks the parameter's own prior width (#1313)", {
  blocks <- .BuildMassBlocks(.massModel(c(1e4, 1e2)))
  adapt <- function(b) {
    .AdaptMassBlocks(list(.withHistory(b, matrix(0), mean = 1)))[[1]][["invMat"]]
  }
  # PRE-FIX both were 1e-12, so any ratio between them held vacuously. The
  # widths differ by 100x, so the variance floors must differ by 100^2.
  expect_equal(adapt(blocks[[1]]), 1)
  expect_equal(adapt(blocks[[2]]), 1e-4)
  expect_equal(adapt(blocks[[1]]) / adapt(blocks[[2]]), 1e4)
})

test_that("a constant column in a 2x2 block is floored to scale (#1313)", {
  # Coordinate 1 varies on a Myr-like scale; coordinate 2 is constant.
  model <- .massModel(c(100, 100), sedModel = "site")
  block <- .BuildMassBlocks(model)[[1]]
  expect_equal(block[["k"]], 2L)                     # the paired branch
  out <- .AdaptMassBlocks(list(.withHistory(block, diag(c(100, 0)))))[[1]]

  # PRE-FIX invMat[2, 2] was the bare 1e-10 ridge: a position step of
  # 1e-5 * eps for this coordinate.
  Minv <- matrix(out[["invMat"]], 2L)
  expect_equal(Minv[2, 2], 1e-4 + 1e-10)
  expect_equal(Minv[1, 1], 100 + 1e-10)
  expect_identical(Minv[1, 2], 0)
  # Convention: cholMat is the lower Cholesky of M = Sigma^{-1}, NOT of Sigma.
  expect_equal(out[["cholMat"]],
               as.vector(diag(1 / sqrt(c(100 + 1e-10, 1e-4 + 1e-10)))))
})

test_that("a narrow but informative coordinate is NOT inflated (#1313)", {
  # The discriminating case for a *per-coordinate* floor against a
  # block-relative (Haario `0.001 * mean(diag)`) one: both coordinates carry
  # genuine variance, but they differ by 1e8. A block-relative ridge would
  # raise the narrow coordinate's Sigma by ~5e4x -- the metric adaptation is
  # there to estimate that variance, and inflating it makes dual averaging
  # shrink the step size for every other coordinate too.
  model <- .massModel(c(1, 1), sedModel = "site")
  block <- .BuildMassBlocks(model)[[1]]
  sigma <- diag(c(1e4, 1e-4))
  out <- .AdaptMassBlocks(list(.withHistory(block, sigma, mean = 1)))[[1]]

  expect_equal(matrix(out[["invMat"]], 2L), sigma + diag(1e-10, 2L))
  # Pinned alone as well: compared against the whole 2x2, whose scale is 1e4,
  # a wrong entry here could hide inside the tolerance.
  expect_equal(matrix(out[["invMat"]], 2L)[2, 2], 1e-4 + 1e-10)
  # 1e-4 is far above this block's floor, so the floor must not reach it.
  expect_gt(1e-4, .MassVarFloor(block)[2])
})

test_that("a legacy mass block keeps the absolute floor (#1313)", {
  # A block restored from a StratPosterior built before `varFloor` existed
  # carries no scale, so it falls back to the historical 1e-12.
  out <- .AdaptMassBlocks(list(list(idx = 1L, k = 1L, wN = 20L, wMean = 0,
                                    wM2 = 0, cholMat = 1, invMat = 1)))[[1]]
  # As a ratio: `expect_equal(x, 1e-12)` compares absolutely at that magnitude,
  # so it would admit 0 -- which is the one value that must never appear here,
  # since cholMat = 1/sqrt(0) is an absorbing Inf.
  expect_equal(out[["invMat"]] / 1e-12, 1)
  expect_equal(out[["cholMat"]] / 1e6, 1)
})


# ── #1191's finiteness invariant, on the two new consumers of prior scale ──
# A one-sided truncation names both bounds and yields an infinite width, so a
# private name match on the prior's args returns Inf where `.PriorRanges()`
# substitutes the prior's central 99% interval. An Inf floor is not a floor:
# `chol()` succeeds on it and every proposal from the block becomes +/-Inf.

.halfBounded <- function(n) rep(list(TruncNormalPrior(0, 1, 0, Inf)), n)

test_that("SiteBlock fallback SDs stay finite on an unbounded prior", {
  model <- .sbModel(alpha = 1:2, gamma = 3:4, sedModel = "site", nParam = 4L)
  model[[c("priors", "metro")]] <- .halfBounded(4L)
  sds <- unlist(lapply(.BuildSiteBlocks(model), `[[`, "fallbackSD"))
  expect_true(all(is.finite(sds)))
  expect_true(all(sds > 0))
  # Sourced from `.PriorRanges()`, not a private copy of the bound match.
  expect_equal(sds, rep(.PriorRanges(model)[1] / 8, 4L))
})

test_that("an unbounded prior does not poison the adapted SiteBlock chol", {
  f <- .blockFixture()
  # Blocks from the builder itself, not hand-written, so the fallback SD is
  # whatever the real path produces. alpha 1 pairs with gamma 2, and column 2
  # of the fixture history is the constant one, so the floor is exercised.
  model <- .sbModel(alpha = 1L, gamma = 2L, sedModel = "site", nParam = 6L)
  model[[c("priors", "metro")]] <- .halfBounded(6L)
  blocks <- .BuildSiteBlocks(model)
  expect_equal(.blockIdx(blocks), list(1:2))
  f[["mcmc"]][[c("metro", "proposalArgs")]][["chain1"]][["SiteBlock"]] <-
    list(blocks = blocks)
  blk <- .adaptedBlocks(f)[[1]]

  # PRE-FIX (with an Inf fallback SD) the floor was Inf, chol() succeeded on
  # it, and both coordinates -- including the informative one -- proposed Inf.
  expect_true(all(is.finite(blk[["chol"]])))
  expect_gt(blk[["chol"]][2, 2], 0)
  set.seed(1312)
  proposed <- .ProposeSiteBlock(
    1L, rep(1, 6L), list(blocks = list(blk)), proposalFactor = 1,
    dimFactor = 1, model = f[["model"]])
  expect_true(all(is.finite(proposed)))
})

test_that("mass-block varFloor stays finite on an unbounded prior", {
  model <- .massModel(c(1, 1))
  model[[c("priors", "metro")]] <- .halfBounded(2L)
  floors <- vapply(.BuildMassBlocks(model), function(b) b[["varFloor"]],
                   numeric(1))
  expect_true(all(is.finite(floors)))
  expect_true(all(floors > 0))
})


# ── #1314 item 1: `metro$multivarReset` is dead state ────────────────────────

.resetFixture <- function() {
  list(
    nChains = 1L, currentIter = 2000L, endAdapting = 1000L,
    propose = setNames(vector("list", 1L), "Univariate"),
    temper = list(temperatures = 1, tempering = FALSE),
    metro = list(
      nProposals = 1L, enablePostAdaptDecay = FALSE,
      acceptance = array(0.3, dim = c(1L, 8L, 1L)),
      acceptanceIndex = matrix(1L, 1L, 1L), acceptanceLength = 8L,
      proposalFactor = matrix(1, 1L, 1L,
                              dimnames = list(NULL, "Univariate")),
      proposalProbability = matrix(1, 1L, 1L,
                                   dimnames = list(NULL, "Univariate")),
      proposalValid = matrix(TRUE, 1L, 1L,
                             dimnames = list(NULL, "Univariate")),
      proposalTimeNs = matrix(0, 1L, 1L),
      proposalTimeCount = matrix(0L, 1L, 1L),
      proposalSqJump = matrix(0, 1L, 1L),
      proposalSqJumpSq = matrix(0, 1L, 1L),
      probUpdateCount = 0L, scaleMultivariateProposals = FALSE
    )
  )
}

test_that("no dead multivarReset slot is created or carried (#1314)", {
  mcmc <- .resetFixture()
  model <- list(parametersLength = 1L, parametersLengthNotFixed = 1L,
                ind = list(paramNotFixed = 1L))
  metro <- .UpdateProposalProbAndFac(model, mcmc, inLateAdaptation = TRUE)
  # PRE-FIX a legacy guard created the slot here and wrote it straight back,
  # unread by anything in R/ or src/.
  expect_false("multivarReset" %in% names(metro))
})
