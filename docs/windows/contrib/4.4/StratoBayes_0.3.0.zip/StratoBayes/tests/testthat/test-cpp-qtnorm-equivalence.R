# ── RT-244 sampler unification: one shared truncated-normal quantile core ─────
#
# The truncated-normal inverse CDF used to exist as three copies: the R
# `.qtnorm_core` (R's qnorm/pnorm), a C++ main-thread twin `qtnorm_core_R`
# (R::qnorm/pnorm), and the thread-safe engine core `qtnorm_std` (Acklam + a
# log-space Halley polish, no R API). The main-thread twin has been removed and
# every caller — R `.qtnorm_core` (via the `.sb_qtnorm` export) and the parallel
# MCMC engine's own prior sampler — now routes through the single core
# `ThreadRNG::qtnorm_std`. (The standalone `.sb_prior_sample` export was a third
# caller until RT-383 deleted it as dead code.)
#
# Because there is now ONE implementation, its correctness cannot be checked by
# comparing it to a sibling copy (that would be a tautology, as the RT-274
# density-side self-equivalence became post-unification). Correctness here is a
# GENUINE cross-*algorithm* check: `qtnorm_std` is Acklam+Halley, an entirely
# independent algorithm from R's Wichura `qnorm`, so agreement to ~machine
# precision is real evidence, not 1 == 1. Frozen golden values (computed once
# from R's log.p qnorm) guard against the core and the oracle drifting together.

skip_on_cran()

# Independent oracle: standardized truncated-N(0,1) quantile via R's log-space
# qnorm/pnorm. Same tail-reflected factoring the sampler uses internally, but
# built entirely from R's own (Wichura) routines — a different algorithm from
# the Acklam+Halley core under test.
qtnorm_oracle <- function(u, zL, zU) {
  if (zL > 0) {
    lsl <- pnorm(zL, lower.tail = FALSE, log.p = TRUE)
    lsh <- pnorm(zU, lower.tail = FALSE, log.p = TRUE)
    qnorm(lsl + log1p(u * expm1(lsh - lsl)), lower.tail = FALSE, log.p = TRUE)
  } else if (zU < 0) {
    lpl <- pnorm(zL, log.p = TRUE)
    lph <- pnorm(zU, log.p = TRUE)
    # log(u) direct, not (1 - u): the latter rounds to 1 below u = 2^-54 and
    # would make the oracle fail exactly as the core did before #1771, so a
    # widened u grid would read spurious agreement as a pass.
    la <- log(u)
    lb <- log1p(-u) + (lpl - lph)
    m <- pmax(la, lb)
    qnorm(lph + m + log1p(exp(pmin(la, lb) - m)), log.p = TRUE)
  } else {
    plo <- pnorm(zL)
    phi <- pnorm(zU)
    qnorm(plo + u * (phi - plo))
  }
}

# Every truncation regime the core branches on: straddle (incl. wide/narrow and
# one-sided-infinite), deep upper tail, deep lower tail.
regimes <- list(
  "straddle [-3, 3]"        = c(-3, 3),
  "straddle wide [-40, 40]" = c(-40, 40),
  "straddle [-2, 0.5]"      = c(-2, 0.5),
  "upper tail [1, 2]"       = c(1, 2),
  "upper deep [5, 6]"       = c(5, 6),
  "upper very deep [10, 12]" = c(10, 12),
  "lower tail [-2, -1]"     = c(-2, -1),
  "lower deep [-6, -5]"     = c(-6, -5),
  "half-open [-Inf, 1.5]"   = c(-Inf, 1.5),
  "half-open [-1.5, Inf]"   = c(-1.5, Inf),
  "untruncated [-Inf, Inf]" = c(-Inf, Inf)
)

test_that("RT-244: shared qtnorm core matches an independent R qnorm oracle", {
  u <- seq(0.01, 0.99, by = 0.01)
  for (nm in names(regimes)) {
    zL <- regimes[[nm]][1]
    zU <- regimes[[nm]][2]
    ref <- vapply(u, qtnorm_oracle, numeric(1), zL = zL, zU = zU)
    got <- .sb_qtnorm(u, zL, zU)
    expect_true(all(is.finite(got)),
                info = sprintf("%s: non-finite draw", nm))
    expect_true(all(got >= zL & got <= zU),
                info = sprintf("%s: out of [zL, zU]", nm))
    # Cross-algorithm accuracy: Acklam+Halley vs Wichura qnorm. Observed max
    # abs error ~1e-14 across all regimes; 1e-10 leaves platform margin while
    # still catching any real accuracy regression (e.g. a dropped Halley step).
    expect_equal(got, ref, tolerance = 1e-10,
                 info = sprintf("%s: core vs R qnorm oracle", nm))
  }
})

test_that("RT-244: qtnorm core reproduces frozen golden quantiles", {
  # Values frozen once from R's log.p qnorm (the oracle). If both the core AND
  # the oracle drift together this still catches it; the accuracy test above
  # would not.
  golden <- list(
    list(u = 0.5,  zL = -3, zU = 3,   z =  0),
    list(u = 0.25, zL = -3, zU = 3,   z = -0.67236729506305859),
    list(u = 0.5,  zL = 5,  zU = 6,   z =  5.1313717632839193),
    list(u = 0.1,  zL = 10, zU = 12,  z = 10.010428370089279),
    list(u = 0.9,  zL = 10, zU = 12,  z = 10.225526810998913),
    list(u = 0.5,  zL = -6, zU = -5,  z = -5.1313717632839193),
    list(u = 0.3,  zL = 1,  zU = 2,   z =  1.1856325685206255),
    list(u = 0.7,  zL = -2, zU = 0.5, z = -0.022940762771432362)
  )
  for (g in golden) {
    got <- .sb_qtnorm(g$u, g$zL, g$zU)
    expect_equal(got, g$z, tolerance = 1e-12,
                 info = sprintf("golden u=%g [%g, %g]", g$u, g$zL, g$zU))
  }
})

test_that("RT-244: qtnorm core returns exact bounds at u = 0 and u = 1", {
  for (nm in names(regimes)) {
    zL <- regimes[[nm]][1]
    zU <- regimes[[nm]][2]
    expect_identical(.sb_qtnorm(0, zL, zU), zL, info = sprintf("%s u=0", nm))
    expect_identical(.sb_qtnorm(1, zL, zU), zU, info = sprintf("%s u=1", nm))
  }
})

test_that("RT-244: R .qtnorm_core routes through the shared core", {
  # The R helper is now a thin affine wrapper over .sb_qtnorm; confirm the
  # public path and the core agree exactly (bar the endpoint pinning).
  p <- seq(0.05, 0.95, by = 0.05)
  mean <- 5
  sd <- 3
  lower <- 2
  upper <- 8
  zL <- (lower - mean) / sd
  zU <- (upper - mean) / sd
  expect_equal(
    .qtnorm_core(p, mean, sd, lower, upper),
    mean + sd * .sb_qtnorm(p, zL, zU),
    tolerance = 1e-15
  )
})
