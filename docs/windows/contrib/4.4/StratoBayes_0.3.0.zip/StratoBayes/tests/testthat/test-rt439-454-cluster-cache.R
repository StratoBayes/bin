# Four red-team Round-114 findings against the #264 object-attached cluster
# cache: RT-439 cache key identity, RT-451 `burninIndex` vs `selectRows`,
# RT-453 no fixture carried a `.cache`, RT-454 `.cache` shared by reference.
# `.WithClusterCache()` lives in helper-cluster-cache.R.

# ---------------------------------------------------------------------------
# RT-439: the cache key must compare by content
#
# RT-439's other half -- a key mutated in place *after* it was stored -- needed
# a matcher that writes to its table at the C level. Nothing does any more
# (#1982), so `.StripKeyAttr()` no longer has to return a detached copy, and
# the test pinning that property is retired with the hazard. What still earns
# a test is that the cache hits at all.
# ---------------------------------------------------------------------------

test_that("the cluster cache hits with a clean runSelect (RT-439)", {
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]

  for (i in seq_len(4)) {
    StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, seq_len(nRun), NULL)
  }

  expect_length(ce$clusterCache, 1L)
  # `runSelect` left the key when the memo moved into `Cluster.StratPosterior()`
  # (#1605), and is now reported in `options`, where any attribute breaks
  # `identical()` on two equal calls just the same (#1607)
  expect_null(attributes(
    StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, seq_len(nRun),
                                   NULL)[[c("options", "runSelect")]]))
})

test_that("repeated alignment extraction reuses the cached clustering (RT-439)", {
  # `.ExtractAlignmentIterations()` reads `selectRows[[x]]` after the key
  # holding that same list has been stored
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")

  for (i in seq_len(3)) {
    ExtractIterations(sp, alignment = 1, burnIn = 0.9)
  }

  expect_length(ce$clusterCache, 1L)
  expect_true(all(vapply(ce$clusterCache[[1]][["key"]][[1]],
                         function(k) is.null(attributes(k)), logical(1))))
})

# ---------------------------------------------------------------------------
# RT-451: burninIndex must describe the rows that were actually used
# ---------------------------------------------------------------------------

test_that("burninIndex is read off selectRows when one is supplied (RT-451)", {
  sr <- ExtractIterations(stratPosterior1, burnIn = 0.5)

  low <- Cluster(stratPosterior1, burnIn = 0.5, selectRows = sr)
  high <- Cluster(stratPosterior1, burnIn = 0.75, selectRows = sr)

  # same rows in, so the same analysis out - including its reported index
  expect_identical(low[["cluster"]], high[["cluster"]])
  expect_identical(low[["rowIndex"]], high[["rowIndex"]])
  expect_identical(low[["burninIndex"]], high[["burninIndex"]])
  expect_equal(low[["burninIndex"]], min(unlist(sr)) - 1)
})

test_that("an irrelevant burnIn no longer aborts a selectRows call (RT-451)", {
  sr <- ExtractIterations(stratPosterior1, burnIn = 0.5)

  # `burnIn` would discard every saved iteration, but `sr` determines the rows
  expect_no_error(cl <- Cluster(stratPosterior1, burnIn = 1e9, selectRows = sr))
  expect_identical(cl[["rowIndex"]], sr)

  # without selectRows, burnIn does determine the rows and is still checked
  expect_error(Cluster(stratPosterior1, burnIn = 1e9), "burnIn must")
})

# ---------------------------------------------------------------------------
# RT-453: a fixture variant that carries a live cache
# ---------------------------------------------------------------------------

test_that("a posterior with a live .cache exercises both lazy [[ paths (RT-453)", {
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")
  expect_null(ce$stratCluster)
  expect_null(ce$summary)

  sc <- sp[["stratCluster"]] # deferred-clustering branch
  expect_s3_class(sc, "StratCluster")
  expect_identical(ce$stratCluster, sc)
  expect_identical(sp[["stratCluster"]], sc) # served from cache

  # nested access must reach through the cached object
  expect_identical(sp[[c("stratCluster", "rowIndex")]], sc[["rowIndex"]])

  sm <- sp[["summary"]] # deferred-summary branch
  expect_false(is.null(ce$summary))
  expect_identical(sp[["summary"]], sm)
})

# ---------------------------------------------------------------------------
# RT-454: a cache belongs to the samples it was computed from
# ---------------------------------------------------------------------------

test_that("a derived posterior is not served the parent's cache (RT-454)", {
  sp <- .WithClusterCache(stratPosterior2, lazy = TRUE)
  ce <- .subset2(sp, ".cache")
  parentCluster <- sp[["stratCluster"]]
  expect_false(is.null(ce$stratCluster))

  # derive by field assignment: one run instead of three
  derived <- sp
  derived[["samples"]] <- derived[["samples"]][, , 1L, , drop = FALSE]
  derived[["nRun"]] <- 1L

  # the environment is literally shared, but must be disowned
  expect_identical(.subset2(derived, ".cache"), ce)
  expect_null(.PosteriorCache(derived))
  expect_false(is.null(.PosteriorCache(sp)))

  # baseline before anything touches `derived`: the parent's own `[[` access
  # above legitimately memoised into `clusterCache` once the memo moved into
  # Cluster.StratPosterior(), and a leak from `derived` must not hide inside it
  nOwn <- length(ce$clusterCache)

  derivedCluster <- derived[["stratCluster"]]
  expect_equal(derivedCluster[["runs"]], 1L)
  expect_false(identical(derivedCluster[["cluster"]],
                         parentCluster[["cluster"]]))

  # and nothing is written back into the parent's cache
  expect_identical(ce$stratCluster, parentCluster)
  StratoBayes:::.ClusterInternal(derived, 0.9, NULL, 2000, 1L, NULL)
  expect_length(ce$clusterCache, nOwn)
})

test_that("an unstamped or foreign cache is disowned, never trusted (RT-454)", {
  sp <- .WithClusterCache(stratPosterior2)
  expect_false(is.null(.PosteriorCache(sp)))

  # a cache that claims no samples claims nothing about this object
  unstamped <- sp
  ce <- new.env(parent = emptyenv())
  ce$stratCluster <- NULL
  ce$summary <- NULL
  ce$clusterCache <- list()
  unstamped[[".cache"]] <- ce
  expect_null(.PosteriorCache(unstamped))

  # nRun alone is enough to disown
  renumbered <- sp
  renumbered[["nRun"]] <- 99L
  expect_null(.PosteriorCache(renumbered))
})
