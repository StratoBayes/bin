# Regression tests for five low-severity red-team findings (RT-405, RT-406,
# RT-407, RT-408, RT-411). See dev/red-team/findings.md for full detail; each
# is a confirmed-latent guard or parity gap, not a demonstrated live bug (the
# PR description states this explicitly per finding).

# ── Helper: prepared data/model/mcmc/state (mirrors test-cpp-logpost-
# equivalence.R's equiv_setup, without building the C++ engine) ─────────────
rt_lows_setup <- function(sData, sModel, seed = 7261, nChains = 1L) {
  td <- file.path(tempdir(),
                  paste0("rtlows_", paste(sample(c(letters, 0:9), 10L, TRUE),
                                         collapse = "")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = nChains, seed = 1,
    quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "rtlows", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "rtlows_mcmc_run_1.rds"))

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  if (is.null(model_obj$.tiesDispatch))
    model_obj$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(data_obj, model_obj)

  list(data = data_obj, model = model_obj, mcmc = mcmc_obj,
       state = mcmc_obj$recentState, td = td)
}

# ── RT-405: overlap-index guard parity + upper-bound guard ──────────────────
#
# `src/LogPost.cpp`'s overlap-adjustment lookup lacked the `ov[i] > 0` guard
# that `src/MCMCEngine.cpp`'s twin has carried since T-070 (8755ac1e) -- a
# Tier-1 parity divergence, and (per Rcpp::Vector::operator[] being unchecked)
# a latent OOB read had a 0 or an out-of-range index ever reached it. Neither
# side had an upper-bound guard either. This test drives `.sb_logpost`
# directly with a hand-built `signalSectionOverlap` containing a 0 and an
# out-of-range index and asserts they are skipped (contribute 0), not read.

test_that(".sb_logpost skips zero and out-of-range overlap indices (RT-405)", {
  adj <- c(1.5, 2.5)  # adjustments[1] = 1.5, adjustments[2] = 2.5

  call_overlap <- function(ov) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      # nSignal is taken from signalValues' length (LogPost.cpp), so a dummy
      # single-signal entry is needed to make the overlap loop body execute
      # at all; its own likelihood contribution is irrelevant to this test.
      rCustomFns = list(), B_list = list(matrix(0, 1, 1)),
      beta_list = list(0), signalValues = list(0), sigma = 1,
      overlapPenalty = TRUE,
      signalSectionOverlap = list(ov), adjustments = list(adj))
  }

  # A 0 (no overlap) and an out-of-range 5 (beyond length(adj) == 2) must both
  # be skipped; only the valid index 2 (-> adj[2] == 2.5) contributes.
  res <- call_overlap(c(0L, 2L, 5L))
  expect_equal(res[3], 2.5)

  # Control: every index valid -> full sum, proving the harness discriminates.
  res_valid <- call_overlap(c(1L, 2L))
  expect_equal(res_valid[3], sum(adj))
})

# ── RT-406: raw -Inf marginal logPost is clamped, not left to trip the next
# MH step's unconditional-accept escape branch ───────────────────────────────
#
# `.UpdateState` step 8 (the post-Gibbs marginal-logPost refresh) stored a raw
# `-Inf` with no `-1e30` guard, unlike `.GenerateInitialState`. Left as -Inf,
# the NEXT call's `.AcceptProposal(logPostOld == -Inf, ...)` escape branch
# would accept unconditionally regardless of the ratio. `.LogPost` is mocked
# to force this fail-closed value deterministically (no real design in the
# bundled datasets is rank-deficient enough to reach it via the real Gibbs
# state), isolating step 8's clamp from the earlier accept/reject decision.

test_that(".UpdateState step 8 clamps a raw -Inf marginal logPost to -1e30 (RT-406)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- rt_lows_setup(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  testthat::local_mocked_bindings(
    .LogPost = function(...) -Inf,
    .package = "StratoBayes"
  )

  set.seed(42)
  result <- StratoBayes:::.UpdateState(
    data = setup$data, model = setup$model, mcmc = setup$mcmc,
    state = setup$state[[1L]], chain = 1L
  )

  expect_identical(result[[c("metro", "logPost")]], -1e30)
  expect_false(is.infinite(result[[c("metro", "logPost")]]))
})

# ── RT-407: NaN-blind fail-closed path in signal_logmarginal_one's callers ───
#
# The fail-closed check tested `contrib == R_NegInf`, which is NaN-blind (any
# IEEE754 comparison with NaN is false) -- a NaN contribution fell through to
# `logLikSignal += contrib` and was then silently DROPPED by the caller's
# `sum(..., na.rm = TRUE)` rather than rejecting the state. No production
# route to a NaN contribution was demonstrated (sigma/lambda are positive
# Gibbs draws); this test forces one directly via a NaN in the observed
# signal values, which propagates through `yy` into a NaN `contrib` without
# depending on any Cholesky failure behaviour.

test_that(".sb_logpost(marginal = TRUE) rejects (not drops) a NaN signal contribution (RT-407)", {
  p <- 4L
  n <- 5L
  sigma <- 1
  lambda <- 1

  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D <- crossprod(Delta)

  set.seed(1)
  B <- matrix(stats::rnorm(n * p), n, p)  # full rank: Cholesky succeeds

  call_marginal <- function(y) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(B), beta_list = list(numeric(p)),
      signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)
  }

  y_nan <- as.numeric(seq_len(n))
  y_nan[3] <- NaN
  res_nan <- call_marginal(y_nan)
  expect_identical(res_nan[2], -Inf)  # rejected, not dropped as a missing 0

  # Control: no NaN -> finite, proving the harness discriminates.
  y_ok <- as.numeric(seq_len(n))
  res_ok <- call_marginal(y_ok)
  expect_true(is.finite(res_ok[2]))
})

# ── RT-408: .HMCCreateEngine guards .tiesDispatch symmetrically with
# .logpost_cpp ────────────────────────────────────────────────────────────────
#
# Confirmed latent only: production callers (inside RunStratModel) always
# have .tiesDispatch set before .HMCCreateEngine runs. This characterises the
# guard directly so a future caller lacking .tiesDispatch does not silently
# route ties through RT-249's positional-mis-binding legacy fallback.

test_that(".HMCCreateEngine builds .tiesDispatch when the caller omits it (RT-408)", {
  skip_on_cran()
  data(stratData2, package = "StratoBayes")  # has ties
  data(stratModel2, package = "StratoBayes")

  sModel <- StratModel(
    stratData = stratData2, priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale, sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE, knotRange = c(0, 100)
  )

  setup <- rt_lows_setup(stratData2, sModel)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  model_no_dispatch <- setup$model
  model_no_dispatch$.tiesDispatch <- NULL
  expect_null(model_no_dispatch$.tiesDispatch)

  engine_ptr <- StratoBayes:::.HMCCreateEngine(
    data = setup$data, model = model_no_dispatch, state = setup$state[[1L]]
  )
  expect_true(!is.null(engine_ptr))
})

# ── RT-411: unrecognised non-empty prior type errors clearly and identically
# in both C++ log-posterior implementations ─────────────────────────────────
#
# `logprior_one`'s comment claimed an unknown type falls back to R; it
# actually collapsed to -Inf (out-of-support), while the C++ engine's twin
# treated the same NA sentinel as "call the next registered custom prior" --
# an out-of-range access if a genuinely unrecognised type ever reached it.
# Both files now error clearly and identically on an unrecognised non-empty
# type name (safe by construction today: `.PrepareLogPostArgs` never writes
# one), closing the sentinel disagreement rather than choosing a side.

test_that(".sb_logpost errors clearly on an unrecognised non-empty prior type (RT-411)", {
  expect_error(
    StratoBayes:::.sb_logpost(
      x = 1, priorTypes = "NotARealPriorType", priorArgs = list(list()),
      rCustomFns = list(), B_list = list(), beta_list = list(),
      signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()),
    "Unknown prior type"
  )
})

test_that("sb_create_engine errors clearly on an unrecognised non-empty prior type (RT-411)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- rt_lows_setup(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  lp <- setup$model$.logpost_cpp
  lp$priorTypes[1] <- "NotARealPriorType"
  model_bad <- setup$model
  model_bad$.logpost_cpp <- lp

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data, model = model_bad, mcmc = setup$mcmc,
      state = setup$state
    ),
    "Unknown prior type"
  )
})
