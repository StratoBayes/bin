# #1472: RunStratModel() forwarded 20 of StratModel()'s formals to the
# internal StratModel() call but omitted signalOffsets/offsetPriorScale, and
# has no `...` catch-all -- so `RunStratModel(..., signalOffsets = TRUE)`
# errored "unused argument (signalOffsets = TRUE)" before ever reaching
# StratModel(), making signal offsets unreachable via the documented
# one-call convenience path.

# Site 2 carries a simulated +4 constant shift under alignment priors too
# tight for the shared spline to absorb it (mirrors test-1421's fixture), so
# a working offset sampler must move delta for that group away from zero --
# not merely accept the argument without error.
.offsetRunFixture <- function() {
  set.seed(1472)
  n <- 25
  h <- seq(0, 10, length.out = n)
  signal <- data.frame(
    site   = c(rep("s1", n), rep("s2", n)),
    height = c(h, h),
    value  = c(sin(h) + rnorm(n, 0, 0.1), sin(h) + 4 + rnorm(n, 0, 0.1))
  )
  group <- data.frame(site = c("s1", "s2"), group = c("A", "B"),
                      stringsAsFactors = FALSE)
  data <- StratData(signal = signal, group = group)
  priors <- structure(list(
    "alpha_s2"    = NormalPrior(mean = 0, sd = 0.05),
    "gammaLog_s2" = NormalPrior(mean = 0, sd = 0.05)),
    class = c("list", "StratPrior"))
  list(data = data, priors = priors)
}

test_that("#1472: RunStratModel() forwards signalOffsets/offsetPriorScale", {
  skip_on_cran()
  fix <- .offsetRunFixture()

  td <- file.path(tempdir(), paste0("run1472_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  post <- RunStratModel(
    stratObject = fix$data, priors = fix$priors,
    alignmentScale = "height", sedModel = "site", nKnots = 8,
    signalOffsets = TRUE, offsetPriorScale = 1,
    nIter = 80, nThin = 1, nChains = 2, seed = 1472,
    quiet = TRUE, visualise = FALSE, convergenceStop = FALSE,
    modelDir = td, modelName = "run1472", nThreads = 1L, nCores = 1L
  )

  # The offset configuration must actually have reached StratModel(): a
  # dropped-but-silently-accepted argument (e.g. captured into an unused
  # local) would build a StratModel with offsets disabled.
  expect_true(isTRUE(post[[c("model", "offsetConfig", "active")]]))
  expect_identical(post[[c("model", "offsetConfig", "tauFixedValue")]], 1)

  deltaCols <- grep("^delta_", post[["savedParameters"]], value = TRUE)
  expect_true(length(deltaCols) >= 2L)

  draws <- ExtractParameters(post, parameters = deltaCols, burnIn = 0)
  deltaMedians <- vapply(draws[deltaCols], stats::median, numeric(1))
  # Under the sum-to-zero prior alone (tau^2(1 - 1/G) = 0.5, G = 2), the two
  # groups' medians separate by O(1) on noise; the fixture's alignment
  # priors are too tight to absorb site 2's simulated +4 shift any other
  # way, so a working offset sampler must separate the groups by far more
  # than that -- not merely wander away from zero.
  expect_gt(max(deltaMedians) - min(deltaMedians), 2)
})

# #1470: StratMapPlot()'s StratModel (prior) branch forwarded only
# `stratData`/`heights`/`site`/`maxSamples`/`parameters`/`quantiles` to the
# nested StratMap() call, silently dropping `alignment`/`runs`/`iterations`
# instead of triggering StratMap()'s own RT-717 guard against them -- so
# `StratMapPlot(model, stratData = d, runs = 2)` was silently accepted and
# `runs = 2` simply ignored, where the equivalent direct `StratMap()` call
# errors clearly.
test_that("#1470: StratMapPlot() prior branch rejects alignment/runs/iterations", {
  expect_error(
    StratMapPlot(stratModel0, stratData = stratData0, runs = 99,
                display = FALSE, overridePar = FALSE),
    "do not apply when `stratObject` is a `StratModel`"
  )
  expect_error(
    StratMapPlot(stratModel0, stratData = stratData0, alignment = 1,
                display = FALSE, overridePar = FALSE),
    "do not apply when `stratObject` is a `StratModel`"
  )
  expect_error(
    StratMapPlot(stratModel0, stratData = stratData0, iterations = 1:10,
                display = FALSE, overridePar = FALSE),
    "do not apply when `stratObject` is a `StratModel`"
  )
  # defaults (i.e. not explicitly supplying these args) still work
  expect_no_error(
    StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 20,
                display = FALSE, overridePar = FALSE)
  )
})
