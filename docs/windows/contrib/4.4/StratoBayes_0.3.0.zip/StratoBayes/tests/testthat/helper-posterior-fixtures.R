# Shared MCMC fixtures for the posterior-diagnostics regression tests
# (test-rt414-rt415-posterior-diagnostics.R and
# test-rt416-rt432-posterior-summary.R).
#
# Two single-run models recorded at different `nThin`, assembled into one
# directory and compiled by `StratPosterior()`. This is the shape
# `CombineModelRuns()` produces for mismatched `nThin` (a warning, not an
# error -- #654), and the shape `timeLimit` still produces for run lengths.
#
# Each `RunStratModel()` call is by far the dominant cost of those files, so runs
# are memoised by (nThin, seed) and shared between them.
#
# NOTE: the sampled values themselves are NOT reproducible across sessions here
# (clustering and the acceptance summary vary run to run), so tests built on
# these fixtures must assert only structural quantities -- row counts,
# `completedIter`, `burnInPercent`, printed layout -- and never an absolute
# `psrf`, `ess` or acceptance value.

.posteriorFixtureCache <- new.env(parent = emptyenv())

# NOTE the deliberate absence of `withr::local_tempdir(.local_envir =
# teardown_env())` here. The cache lives for the whole test run, but a
# teardown-scoped tempdir lives only as long as the *file* that first created
# it -- and when testthat sources helpers once for the whole directory (which
# `test_dir()`/`R CMD check` do, unlike a bare `test_file()`), the file that
# creates a fixture is not necessarily the file that later reads it. A plain
# `tempfile()` matches the cache's own lifetime; the session tempdir is removed
# when R exits.
.PosteriorFixtureRun <- function(thin, seed) {
  key <- paste0("t", thin, "s", seed)
  if (is.null(.posteriorFixtureCache[[key]])) {
    dir <- tempfile(paste0("sbfixture-", key, "-"))
    dir.create(dir, recursive = TRUE)
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 1000,
                  nChains = 2, nThreads = 1L, nThin = thin, visualise = FALSE,
                  seed = seed, runParallel = FALSE, quiet = TRUE,
                  adaptTemperatures = FALSE,
                  modelDir = dir, modelName = key)
    .posteriorFixtureCache[[key]] <- dir
  }
  .posteriorFixtureCache[[key]]
}

# Assemble the two runs into one model directory. `damage` optionally replaces
# run 2's TSV sample file, for the RT-416 failure paths, or deletes run 2's
# binary samples while keeping its `_mcmc_run_2.rds`, for #928; `binary = FALSE`
# drops the `_binarysamples_*.rds` fast path so `.CompileSamplesAfterMCMC()` is
# forced down the TSV branch where TSV damage is visible at all.
.PosteriorFixtureCombine <- function(thinA, thinB, envir = parent.frame(),
                                     binary = TRUE, damage = NULL) {
  dirA <- .PosteriorFixtureRun(thinA, seed = 1)
  dirB <- .PosteriorFixtureRun(thinB, seed = 2)
  nameA <- paste0("t", thinA, "s1")
  nameB <- paste0("t", thinB, "s2")
  dirC <- withr::local_tempdir(.local_envir = envir)

  runFiles <- c("mcmc_run_1.rds", "samples_run_1.txt")
  if (binary) runFiles <- c(runFiles, "binarysamples_run_1.rds")
  Copy <- function(from, to) {
    expect_true(file.copy(from, to), info = paste("failed to copy", from))
  }
  for (f in runFiles) {
    Copy(file.path(dirA, paste0(nameA, "_", f)), file.path(dirC, paste0("mC_", f)))
    Copy(file.path(dirB, paste0(nameB, "_", f)),
         file.path(dirC, paste0("mC_", sub("run_1", "run_2", f))))
  }
  Copy(file.path(dirA, paste0(nameA, "_data.rds")), file.path(dirC, "mC_data.rds"))
  Copy(file.path(dirA, paste0(nameA, "_model.rds")), file.path(dirC, "mC_model.rds"))

  if (identical(damage, "drop-binary-run2")) {
    # Run 2 keeps its metadata but loses the samples the RDS fast path reads,
    # so the two file sets cover different runs (#928).
    unlink(file.path(dirC, "mC_binarysamples_run_2.rds"))
    return(dirC)
  }

  if (identical(damage, "drop-samples-run2")) {
    # The same #928 mismatch on the TSV branch: use with `binary = FALSE`, or
    # the RDS fast path never reads the file this removes.
    unlink(file.path(dirC, "mC_samples_run_2.txt"))
    return(dirC)
  }

  if (isTRUE(damage %in% c("leading-gap", "all-rows-bad"))) {
    # #2012: an intact, well-formed file whose chain-1 rows carry a non-finite
    # value -- from the first saved iteration on, as an out-of-support start
    # writes. Nothing here is a truncated or header-only file.
    target <- file.path(dirC, "mC_samples_run_2.txt")
    lines <- readLines(target)
    fields <- strsplit(lines, "\t", fixed = TRUE)
    chainCol <- match("chain", fields[[1]])
    lastCol <- length(fields[[1]])
    rows <- which(vapply(fields[-1], function(f) f[[chainCol]] == "1",
                         logical(1)))
    if (identical(damage, "leading-gap")) rows <- rows[[1]]
    for (i in rows) {
      fields[[i + 1L]][[lastCol]] <- "NA"
      lines[[i + 1L]] <- paste(fields[[i + 1L]], collapse = "\t")
    }
    writeLines(lines, target)
    return(dirC)
  }

  if (!is.null(damage)) {
    target <- file.path(dirC, "mC_samples_run_2.txt")
    unlink(target)
    if (identical(damage, "header-only")) {
      # Exactly what a run killed before its first flush leaves behind:
      # R/RunStratModel.R writes the header at run start.
      writeLines(readLines(file.path(dirC, "mC_samples_run_1.txt"), n = 1), target)
    } else {
      file.create(target)  # zero bytes
    }
    return(dirC)
  }

  suppressMessages(StratPosterior(readDir = dirC, modelName = "mC"))
}
