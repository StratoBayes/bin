test_that(".AgeConversionGeneral works and fails gracefully", {

  expect_error(.AgeConversionGeneral(NULL, 1, 1),
               "`parameters`.* be a numeric")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = 1),
               "`stratPosterior`.* an object")

  expect_error(.AgeConversionGeneral(1, 1, 1),
               "If `stratPosterior` is not supplied, `stratData` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratData = stratData1),
               "If neither `stratPosterior` nor `indices` .* supplied, `stratModel` must be")

  expect_error(.AgeConversionGeneral(1, 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* be a numeric of")

  expect_error(.AgeConversionGeneral(data.frame(a = 1:3, b = 1:3), 1, 1, stratPosterior = stratPosterior1),
               "`parameters` .* a numeric vector")

  expect_error(.AgeConversionGeneral(1:4, "a", 1,
                                     stratPosterior = stratPosterior1),
               "`heights` .* be numeric")

  expect_error(.AgeConversionGeneral(1:4, 1, "b",
                                     stratPosterior = stratPosterior1),
               "`site` .* be exactly one of the sites")

  expect_equal(.AgeConversionGeneral(stratPosterior1$samples[100, 1:4, 1, 1],
                                     1, 2, stratData = stratData1,
                                     stratModel = stratModel1),
               8.2, tolerance = 0.1)

})

test_that(".AgeConversionGeneral preserves input order for non-ascending heights (RT-017/RT-110)", {
  # heights are supplied out of order; the internal sort-then-restore logic
  # (`output[order(heightsOrder)]`) must return ages aligned to the *input*
  # order, not the sorted order.
  heightsUnsorted <- c(1.8, 0.3, 1.0)
  outUnsorted <- .AgeConversionGeneral(stratPosterior1$samples[100, 1:4, 1, 1],
                                       heightsUnsorted, 2,
                                       stratData = stratData1,
                                       stratModel = stratModel1)
  outIndividual <- vapply(heightsUnsorted, function(h) {
    .AgeConversionGeneral(stratPosterior1$samples[100, 1:4, 1, 1],
                          h, 2, stratData = stratData1, stratModel = stratModel1)
  }, numeric(1))

  expect_equal(outUnsorted, outIndividual)
})

test_that(".AgeConversionGeneral warns (not silently NA) for a height in no partition (RT-179)", {
  # stratData2's partition boundaries are all zero-width (Bound == next
  # BoundLow), so hand-widen one to create a genuine height-space gap that
  # the global [minBound, maxBound] guard does not catch.
  d <- stratData2
  d[["partsAttr"]][["Bound"]][1, 2] <- 5   # was 10.5; opens gap [5, 10.5)

  indices <- stratModel2[["ind"]]
  set.seed(1)
  params <- rnorm(length(indices[["names"]]), sd = 1)

  expect_warning(
    result <- .AgeConversionGeneral(params, 7, 2, stratData = d,
                                    stratModel = stratModel2),
    "lie in no partition of site 2"
  )
  expect_true(is.na(result))
})

test_that(".AgeConversionBatch warns (not silently NA) for a height in no partition (RT-521)", {
  # stratData2's partition boundaries are all zero-width (Bound == next
  # BoundLow), so hand-widen one to create a genuine height-space gap that
  # the global [minBound, maxBound] guard does not catch.
  d <- stratData2
  d[["partsAttr"]][["Bound"]][1, 2] <- 5   # was 10.5; opens gap [5, 10.5)

  indices <- stratModel2[["ind"]]
  set.seed(1)
  params <- rnorm(length(indices[["names"]]), sd = 1)
  parameterMatrix <- matrix(params, nrow = 1)

  expect_warning(
    result <- .AgeConversionBatch(parameterMatrix, 7, 2, stratData = d,
                                  indices = indices),
    "lie in no partition of site 2"
  )
  expect_true(is.na(result[1, 1]))
})

test_that(".AgeConversionBatch errors clearly when bounds are all NA, mirroring .AgeConversionGeneral", {
  fakeData <- list(
    sites = c("A", "B"),
    partsAttr = list(
      BoundLow = matrix(NA_real_, nrow = 2, ncol = 2),
      Bound = matrix(NA_real_, nrow = 2, ncol = 2)
    )
  )
  indices <- list(alignmentScale = "t")

  expect_error(
    .AgeConversionBatch(matrix(1, nrow = 1, ncol = 1), heights = 1, site = 2,
                        stratData = fakeData, indices = indices),
    "bounds are all NA"
  )
})

test_that(".AgeConversionGeneral() and .AgeConversionBatch() raise identical bounds errors (RT-725, #917)", {
  # Both functions delegate their site/height-bounds guard to the same
  # .ValidateAgeConversionBounds() helper; this pins that they stay identical
  # rather than silently re-diverging into hand-mirrored copies.
  indices <- stratModel2[["ind"]]

  genErr <- tryCatch(
    .AgeConversionGeneral(rep(0, length(indices[["names"]])), 1e6, 2,
                          stratData = stratData2, indices = indices),
    error = conditionMessage)
  batchErr <- tryCatch(
    .AgeConversionBatch(matrix(0, 1, length(indices[["names"]])), 1e6, 2,
                        stratData = stratData2, indices = indices),
    error = conditionMessage)
  expect_match(genErr, "extrapolation is not supported")
  expect_identical(genErr, batchErr)

  fakeData <- structure(
    list(
      sites = c("A", "B"),
      partsAttr = list(
        BoundLow = matrix(NA_real_, nrow = 2, ncol = 2),
        Bound = matrix(NA_real_, nrow = 2, ncol = 2)
      )
    ),
    class = "StratData")
  fakeIndices <- list(alignmentScale = "t", sedModel = "site", names = "a")
  genNaErr <- tryCatch(
    .AgeConversionGeneral(1, 1, 2, stratData = fakeData, indices = fakeIndices),
    error = conditionMessage)
  batchNaErr <- tryCatch(
    .AgeConversionBatch(matrix(1, 1, 1), 1, 2, stratData = fakeData,
                        indices = fakeIndices),
    error = conditionMessage)
  expect_match(genNaErr, "bounds are all NA")
  expect_identical(genNaErr, batchNaErr)
})

test_that(".AgeConversionGeneral works when sitenames are identical to indices", {
  # Create a StratData object with site names that are numeric
  data_i <- StratData(
    signal = data.frame(
      value = c(1, 2, 2, 2, 3, 1, 1.5, 3, 4, 3),
      well = c(1, 1, 1, 2, 2, 2, 3, 4, 4, 4),
      height = c(10, 15, 16, 20, 30, 35, 40, 20, 21, 22)
    ),
    selectSites = c(1, 2, 4),
    siteColumn = "well")
  stratModel2 <- StratModel(data_i,
                            alignmentScale = "h",
                            sedModel = "s",
                            priors = NULL,
                            individualSplineIter = 4)

  expect_equal(.AgeConversionGeneral(1:4, 21, 3, stratData = data_i,
                        stratModel = stratModel2), 2)

})
