# Regression tests for a batch of low-severity C++ engine findings
# (RT-010/278, RT-103, RT-131, RT-260). See dev/red-team/findings.md.
#
# RT-011 was listed here but never had a surviving test: PR #337 drafted one, then
# reverted it wholesale when Round 109 refuted the finding (the C++ raw-momentum
# `nuts_u_turn` is correct). Reference removed so it does not read as coverage of
# a criterion nothing here pins. See RT-375.

# ── Helper: create engine from data/model (mirrors test-cpp-gradient.R) ──────

make_guard_test_engine <- function(sData, sModel, seed = 7261, knotRange = NULL) {
  # If the model uses flexible knots, recreate with fixed knots: since #522
  # "auto" registers NUTS nowhere, so the explicit `gradientProposals = "on"`
  # below is what supplies it, and that is refused for flexible knots under
  # `engine = "R"` (RunStratModel.R).
  if (isTRUE(sModel$flexibleKnots) && !is.null(knotRange)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      sigmaFixed = sModel$sigmaFixed,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }

  td <- file.path(tempdir(), paste0("guard_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    gradientProposals = if (isTRUE(sModel$flexibleKnots)) "auto" else "on",
    stratObject = sData,
    stratModel  = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gtest",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gtest_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  list(
    data_obj = data_obj, model_obj = model_obj,
    mcmc_obj = mcmc_obj, state_obj = state_obj,
    tiesCallback = tiesCallback, td = td
  )
}

# ── RT-010 / RT-278: splineOrder <= 32 guard ─────────────────────────────────
#
# N_lower[32] (Gradient_impl.h), left[32]/right[32] and N[32]
# (MCMCEngine.cpp basis_funs_local/spline_design_local) all overflow if
# splineOrder > 32. Not reachable via the public R API (splineOrder is
# hardcoded to 4 in BayesianSpline.R/CreateSplineS.R), but sb_create_engine
# is directly callable, so exercise the guard there.

test_that("sb_create_engine rejects splineOrder > 32", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_model <- setup$model_obj
  bad_model$splineBase$splineOrder <- 33L

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = bad_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "splineOrder.*exceeds the maximum supported value of 32"
  )
})

test_that("sb_create_engine accepts splineOrder == 32 (boundary, not a fixed-buffer overflow)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  ok_model <- setup$model_obj
  ok_model$splineBase$splineOrder <- 32L

  expect_no_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = ok_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    )
  )
})


# ── #1582: the engine's OWN TruncLogNormal density, not LogPost.cpp's twin ───
#
# `logprior_density()` (MCMCEngine.cpp) and `logprior_one()` (LogPost.cpp) are
# two implementations of the same densities. Every `.sb_logpost()` test drives
# only the latter, so the engine's copy of the `min <= 0` fix needs its own pin.

test_that("the C++ engine's TruncLogNormal density honours `min <= 0` (#1582)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # `min < 0` is unreachable through TruncLogNormalPrior(), which rejects it;
  # a bare Prior() carrying the same argument names is routed to the same C++
  # branch by .InferPriorType().
  priorSep <- function(minVal) {
    pr <- Prior(R = function(n, ...) rep(1.5, n), D = TruncLogNormDensity,
                Q = function(p, ...) rep(1.5, length(p)),
                meanlog = 0, sdlog = 1, min = minVal, max = 20)
    priors <- stratModel1[["priors"]][["metro"]]
    priors[["alpha_site_2"]] <- pr
    sModel <- StratModel(
      stratData = stratData1, priors = priors,
      alignmentScale = stratModel1[["alignmentScale"]],
      sedModel = stratModel1[["sedModel"]],
      sigmaFixed = stratModel1[["sigmaFixed"]],
      flexibleKnots = FALSE, knotRange = c(0, 100)
    )
    setup <- make_guard_test_engine(stratData1, sModel)
    on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)
    ep <- StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    )
    # A fixed parameter vector, so the two arms are comparable.
    StratoBayes:::.sb_eval_logpost(
      ep, 1L, c(1.5, 3, 0.4, -0.24), debug = TRUE
    )[["logPostSep"]][[1]]
  }

  noTruncation <- priorSep(0)
  # Finite, so "both arms are the -1e30 sentinel" cannot satisfy the equality.
  expect_true(is.finite(noTruncation))
  # `min <= 0` means no lower truncation, so the two must agree. Before the fix
  # the min = -1 arm took log() of a negative bound: NaN for every x.
  expect_equal(priorSep(-1), noTruncation)
})


# ── Stage-A partial tempering: the gradient guard belongs in the WRAPPER ─────
#
# Only mask {signal} has a component-selective gradient. The three sites that
# would otherwise have to refuse another partial mask — find_reasonable_epsilon,
# update_state_hmc, update_state_nuts — all sit inside sb_run_block_impl's frame,
# and throwing out of that frame segfaults on aarch64 (RT-433). So the guard has
# to reject the combination at CONSTRUCTION time. Assert that against
# .sb_create_engine directly: a test that only checks RunStratModel() errors
# cannot tell a wrapper guard from a sampler guard, and Windows/x86-64 cannot
# tell them apart at runtime either.

test_that("sb_create_engine rejects a non-signal tempering mask with a gradient proposal", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  skip_if_not("NUTS" %in% names(setup$mcmc_obj[["propose"]]),
              "no gradient proposal registered")

  withMask <- function(mask) {
    m <- setup$mcmc_obj
    m[[c("temper", "tempering")]] <- TRUE
    m[[c("temper", "mask")]] <- mask
    m
  }
  callEngine <- function(mcmc) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = mcmc, state = setup$state_obj, tiesCallback = setup$tiesCallback
    )
  }

  for (mask in c(4L, 6L)) {          # "ties", "signal+ties"
    expect_error(callEngine(withMask(mask)), "MH-only",
                 label = paste0("mask = ", mask))
  }
  for (mask in c(2L, 15L)) {         # "signal", "full" — both supported
    expect_no_error(callEngine(withMask(mask)))
  }
})


# ── RT-103: per-chain RNGs seeded once, not per sb_run_block call ───────────
#
# One continuous nIter=10 block must give identical results to two
# consecutive nIter=5 blocks on a fresh engine, given the same R RNG state
# before the first call. Before the fix, per-chain RNGs were reseeded from
# R's RNG at every block boundary, so splitting a run into blocks silently
# changed the sample sequence even with the same initial seed.

test_that("splitting sb_run_block into two blocks reproduces one continuous block", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  setupA <- make_guard_test_engine(stratData1, stratModel1, seed = 4242)
  on.exit(unlink(setupA$td, recursive = TRUE), add = TRUE)
  engineA <- StratoBayes:::.sb_create_engine(
    data = setupA$data_obj, model = setupA$model_obj,
    mcmc = setupA$mcmc_obj, state = setupA$state_obj,
    tiesCallback = setupA$tiesCallback
  )
  set.seed(31337)
  StratoBayes:::.sb_run_block(engineA, nIter = 10L)
  stateA <- StratoBayes:::.sb_extract_state(engineA)

  setupB <- make_guard_test_engine(stratData1, stratModel1, seed = 4242)
  on.exit(unlink(setupB$td, recursive = TRUE), add = TRUE)
  engineB <- StratoBayes:::.sb_create_engine(
    data = setupB$data_obj, model = setupB$model_obj,
    mcmc = setupB$mcmc_obj, state = setupB$state_obj,
    tiesCallback = setupB$tiesCallback
  )
  set.seed(31337)
  StratoBayes:::.sb_run_block(engineB, nIter = 5L)
  StratoBayes:::.sb_run_block(engineB, nIter = 5L)
  stateB <- StratoBayes:::.sb_extract_state(engineB)

  expect_equal(stateA, stateB)
})


# ── RT-131: temperPositions removed from sb_get_ring_buffer() ──────────────
#
# R only ever read temperSwapOrder/temperAccept (RunStratModel.R); the ring
# buffer must no longer expose the unused temperPositions field.

test_that("sb_get_ring_buffer() does not return temperPositions", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  engine <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  StratoBayes:::.sb_run_block(engine, nIter = 3L)
  buf <- StratoBayes:::.sb_get_ring_buffer(engine)

  expect_false("temperPositions" %in% names(buf))
})


# ── RT-260: H/tBy rescaled to match sigma immediately after a NUTS accept ──
#
# gibbs_sample_all() draws a new sigma but does not itself rescale H/tBy
# (mirrors R's .GibbsSampleBspline, which always rescales as its own final
# step). The standard-MH accept path already rescales unconditionally after
# its post-decision Gibbs sweep (the marginal-MH/"Option B" refactor), so
# only the HMC/NUTS accept paths were missing this rescale -- fixed here.
# Forces a fixed-knot rebuild of stratData3/stratModel3 (sigmaFixed = FALSE)
# so the helper's `gradientProposals = "on"` registers NUTS, and specifically
# checks a NUTS-accepted iteration,
# not just any accept -- a plain MH accept would pass on main's code alone
# and not discriminate this fix.

test_that("H matches BtB/sigma^2 immediately after a NUTS-accepted proposal", {
  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData3, stratModel3, seed = 909,
                                   knotRange = c(-5, 15))
  on.exit(unlink(setup$td, recursive = TRUE))

  nutsIdx <- which(names(setup$mcmc_obj$propose) %in% c("HMC", "NUTS"))
  expect_length(nutsIdx, 1)

  # Force NUTS selection every iteration -- the freshly-bootstrapped mcmc_obj's
  # proposalProbability is still all-Prior this early in adaptation (nIter=10
  # warm-start), so a probabilistic search for a NUTS draw is unreliable.
  mcmc_obj <- setup$mcmc_obj
  mcmc_obj$metro$proposalProbability[, ] <- 0
  mcmc_obj$metro$proposalProbability[, nutsIdx] <- 1

  engine <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )

  set.seed(2024)
  found_accept <- FALSE
  for (i in seq_len(200)) {
    StratoBayes:::.sb_run_block(engine, nIter = 1L)
    state <- StratoBayes:::.sb_extract_state(engine)
    acceptedChain <- which(vapply(state, function(cs)
      isTRUE(cs$metro$accept) && cs$metro$proposalNumber == nutsIdx, logical(1)))
    if (length(acceptedChain) > 0) {
      found_accept <- TRUE
      break
    }
  }
  expect_true(found_accept, info = "no accepted NUTS proposal in 200 iterations")

  for (c in acceptedChain) {
    cs <- state[[c]]
    nSig <- length(cs$metro$B)
    for (m in seq_len(nSig)) {
      B <- cs$metro$B[[m]]
      sigma <- cs$gibbs$sigma[m]
      H_expected <- crossprod(B) / sigma^2
      expect_equal(cs$metro$H[[m]], H_expected, tolerance = 1e-8,
                   info = paste("chain", c, "signal", m))
    }
  }
})

# ── RT-397: .IsDuplicateInHistory bounds guard ──────────────────────────────
#
# m(i, j) and v[j] are unchecked raw pointer arithmetic (Rcpp's Matrix/Vector
# operator[] do not bounds-check), so nRows > m.nrow() or v.size() != m.ncol()
# is an out-of-bounds read, not a catchable exception. Round 75 recorded these
# as "guards are correct"; there were no guards at all. Production safety is
# an R-side invariant only (historySize <= historyLength, chainHistory
# allocated to historyLength rows) - these tests exercise the guard directly
# rather than relying on that invariant always holding.

test_that(".IsDuplicateInHistory works correctly within bounds", {
  m <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 3, ncol = 2)
  expect_true(StratoBayes:::.IsDuplicateInHistory(c(1, 4), m, 3L, -1L))
  expect_false(StratoBayes:::.IsDuplicateInHistory(c(9, 9), m, 3L, -1L))
  # only scanning the first 2 rows must miss a match that only exists in row 3
  expect_false(StratoBayes:::.IsDuplicateInHistory(c(3, 6), m, 2L, -1L))
  # skipCol ignores that column in the comparison
  expect_true(StratoBayes:::.IsDuplicateInHistory(c(99, 4), m, 3L, 0L))
})

test_that(".IsDuplicateInHistory rejects nRows beyond the history matrix's own row count (RT-397)", {
  m <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 3, ncol = 2)
  v <- c(1, 4)
  expect_error(
    StratoBayes:::.IsDuplicateInHistory(v, m, 10L, -1L),
    "nRows"
  )
  expect_error(
    StratoBayes:::.IsDuplicateInHistory(v, m, -1L, -1L),
    "nRows"
  )
})

test_that(".IsDuplicateInHistory rejects a v not matching m's column count (RT-397)", {
  m <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 3, ncol = 2)
  expect_error(
    StratoBayes:::.IsDuplicateInHistory(c(1), m, 3L, -1L),
    "length"
  )
  expect_error(
    StratoBayes:::.IsDuplicateInHistory(c(1, 4, 7), m, 3L, -1L),
    "length"
  )
})

# ── The premise of StratMCMC()'s no-op tempering-mask warning ─────────────────
#
# compute_logpost leaves logPostSep[2] (ties) at exactly 0 unless eng.hasTies,
# which R sets only when the StratData carries a `ties` element. So on a tie-free
# model `temperingComponents = "ties"` divides zero by T -- every chain keeps the
# cold target and every swap ratio is exp(0). StratMCMC() warns about that; this
# pins the arithmetic the warning rests on, so the warning cannot outlive its
# cause silently.
test_that("the ties log-posterior component is exactly 0 without ties", {
  skip_on_cran()
  sepOf <- function(sData, sModel, knotRange = NULL) {
    setup <- make_guard_test_engine(sData, sModel, knotRange = knotRange)
    ep <- StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj, mcmc = setup$mcmc_obj,
      state = setup$state_obj, tiesCallback = setup$tiesCallback)
    params <- setup$state_obj[[1]]$metro$parameters
    out <- StratoBayes:::.sb_eval_logpost(ep, 1L, params, debug = TRUE)
    list(sep = out[["logPostSep"]], hasCallback = !is.null(setup$tiesCallback))
  }

  noTies <- sepOf(stratData1, stratModel1, knotRange = c(0, 100))
  expect_false(noTies$hasCallback)            # no ties -> no callback -> hasTies FALSE
  expect_identical(noTies$sep[[3]], 0)        # the ties component, exactly zero

  withTies <- sepOf(stratData2, stratModel2)
  expect_true(withTies$hasCallback)
  expect_true(is.finite(withTies$sep[[3]]))
  expect_false(withTies$sep[[3]] == 0)        # a real ties term, so the mask bites
})


# ── RT-738 (#933): R->C++ boundary shapes are validated in the WRAPPER ───────
#
# propose_univariate's `sds[i]`, multivariate_sigma's `center[j]`,
# propose_site_block's `out[indices[i]]` and mass_sample_momentum's
# `p[block.idx[i]]`/`cholMat[...]` all index an R-supplied object with no bound
# of their own, from frames that must not throw (worker threads, and
# sb_create_engine_impl). check_proposal_args_shapes() therefore runs in both
# write-site wrappers. Windows may return garbage rather than crash on the
# unguarded read, so assert the guard fires, not that the old code crashed.

test_that("sb_create_engine rejects mis-shaped proposalArgs", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  nPar <- setup$model_obj$parametersLength
  nFree <- setup$model_obj$parametersLengthNotFixed
  propNames <- names(setup$mcmc_obj[["propose"]])

  callWith <- function(mcmc) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = mcmc, state = setup$state_obj, tiesCallback = setup$tiesCallback
    )
  }
  # Replace chain 1's entry for proposal `type`, leaving the rest intact.
  withArg <- function(type, value) {
    m <- setup$mcmc_obj
    p <- match(type, propNames)
    skip_if(is.na(p), paste("no", type, "proposal registered"))
    m[["metro"]][["proposalArgs"]][[1]][[p]] <- value
    m
  }

  expect_error(callWith(withArg("Univariate", rep(0.1, nPar - 1L))),
               "one entry per parameter")
  # Zero-length is the documented "use the engine defaults" signal.
  expect_no_error(callWith(withArg("Univariate", numeric(0))))
  expect_no_error(callWith(withArg("Univariate", rep(0.1, nPar))))

  expect_error(
    callWith(withArg("Multivariate", list(list(rep(0, nFree - 1L),
                                               diag(nFree))))),
    "centre"
  )
  expect_error(
    callWith(withArg("Multivariate", list(list(rep(0, nFree),
                                               diag(nFree - 1L))))),
    "covariance"
  )
  expect_no_error(
    callWith(withArg("Multivariate", list(list(rep(0, nFree), diag(nFree)))))
  )

  expect_error(
    callWith(withArg("SiteBlock",
                     list(blocks = list(list(indices = c(1L, nPar + 5L)))))),
    "indices"
  )
  expect_error(
    callWith(withArg("SiteBlock",
                     list(blocks = list(list(indices = c(1L, 2L),
                                             chol = diag(3)))))),
    "chol"
  )
})

test_that("sb_create_engine rejects mis-shaped HMC massBlocks", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))

  propNames <- names(setup$mcmc_obj[["propose"]])
  p <- which(propNames %in% c("HMC", "NUTS"))[1]
  skip_if(is.na(p), "no gradient proposal registered")
  nFree <- setup$model_obj$parametersLengthNotFixed

  withBlocks <- function(blocks) {
    m <- setup$mcmc_obj
    m[["metro"]][["proposalArgs"]][[1]][[p]] <-
      list(stepSize = 0.1, nSteps = 5L, massBlocks = blocks)
    m
  }
  callWith <- function(mcmc) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = mcmc, state = setup$state_obj, tiesCallback = setup$tiesCallback
    )
  }

  expect_no_error(callWith(withBlocks(list(list(idx = 1L, cholMat = 1,
                                                invMat = 1)))))

  # idx is 1-based on the FREE parameters; nFree + 1 writes past momentum's end.
  expect_error(
    callWith(withBlocks(list(list(idx = as.integer(nFree + 1L),
                                  cholMat = 1, invMat = 1)))),
    "idx must lie in"
  )
  expect_error(
    callWith(withBlocks(list(list(idx = 0L, cholMat = 1, invMat = 1)))),
    "idx must lie in"
  )
  # k = 2 reads cholMat[0..3]; a 2-entry cholMat reads two doubles past the end.
  expect_error(
    callWith(withBlocks(list(list(idx = c(1L, 2L), cholMat = c(1, 0),
                                  invMat = rep(1, 4))))),
    "must each hold 4 entries"
  )
})

test_that("sb_update_temperatures and sb_update_proposals check their dimensions", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  eng <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nChains <- setup$mcmc_obj[["nChains"]]
  metro <- setup$mcmc_obj[["metro"]]

  expect_error(StratoBayes:::.sb_update_temperatures(eng, rep(1, nChains + 1L)),
               "one entry per chain")
  expect_no_error(StratoBayes:::.sb_update_temperatures(eng, rep(1, nChains)))

  expect_error(
    StratoBayes:::.sb_update_proposals(
      eng, metro[["proposalArgs"]],
      metro[["proposalFactor"]][, -1, drop = FALSE],
      metro[["proposalProbability"]]),
    "must both be"
  )
  expect_no_error(
    StratoBayes:::.sb_update_proposals(
      eng, metro[["proposalArgs"]], metro[["proposalFactor"]],
      metro[["proposalProbability"]])
  )
})


# ── RT-740 (#935): a gradient slot must never be selectable without its args ──
#
# extract_hmc_args leaves hmcState.initialized FALSE when the HMC/NUTS entry in
# proposalArgs is absent, NULL or not a list; update_state_hmc/_nuts then
# self-transition silently. The only thing that made that unreachable was an
# undocumented R-side convention (proposalProbability rises in the same
# .UpdateProposal branch that populates the args). Pin it.

test_that("an HMC/NUTS slot with positive probability must carry its args", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))

  propNames <- names(setup$mcmc_obj[["propose"]])
  p <- which(propNames %in% c("HMC", "NUTS"))[1]
  skip_if(is.na(p), "no gradient proposal registered")

  bad <- setup$mcmc_obj
  bad[["metro"]][["proposalArgs"]][[1]][p] <- list(NULL)
  bad[["metro"]][["proposalProbability"]][1, p] <- 0.5

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = bad, state = setup$state_obj, tiesCallback = setup$tiesCallback
    ),
    "silently self-transition"
  )
})


# ── RT-741 (#936): +Inf is out of support, not a licence to accept everything ─
#
# A degenerate uniform prior (min == max) gives -log(0) = +Inf. The old guard
# tested only `logPrior <= -Inf || is.nan(logPrior)`, so +Inf propagated: a
# chain whose OLD state is +Inf accepts every proposal, and once the parameter
# leaves support and is clamped to -1e30 the ratio is exp(0) = 1 forever.

test_that("compute_logpost treats a +Inf log-prior as out of support", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  params <- setup$state_obj[[1]]$metro$parameters
  degenerate <- setup$model_obj
  v <- unname(params[[1]])
  degenerate$.logpost_cpp$priorTypes[[1]] <- "UniformPrior"
  degenerate$.logpost_cpp$priorArgs[[1]] <- list(min = v, max = v)

  eng <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = degenerate, mcmc = setup$mcmc_obj,
    state = setup$state_obj, tiesCallback = setup$tiesCallback
  )
  out <- StratoBayes:::.sb_eval_logpost(eng, 1L, params, debug = TRUE)
  expect_identical(out[["logPost"]], -1e30)
  expect_true(is.na(out[["logPostSep"]][[2]]))
})


# ── #1045: two construction-time preconditions the engine used to take on trust ─
#
# `ind$paramNotFixed` / `ind$alphaNotFixed` index a parametersLength-sized mask
# that sb_create_engine_impl fills unconditionally, so an out-of-range entry is a
# silent heap write in a frame that must not throw. And every chain's imported
# `metro$B` feeds sparse_Bv on the gradient path — which writes one output per B
# ROW into a buffer sized by the SIGNAL — whether or not that chain carries `H`,
# which is exactly the shape `.HMCCreateEngine` builds.

test_that("sb_create_engine range-checks the free-parameter index vectors", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  callWith <- function(model) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    )
  }
  nPar <- setup$model_obj$parametersLength

  for (field in c("paramNotFixed", "alphaNotFixed")) {
    for (bad in list(nPar + 1L, 0L, -3L, NA_integer_)) {
      m <- setup$model_obj
      m[["ind"]][[field]] <- c(m[["ind"]][[field]], bad)
      expect_error(callWith(m), paste0(field, ".*must lie in 1\\.\\."),
                   label = paste(field, "=", bad))
    }
  }
  expect_no_error(callWith(setup$model_obj))
})

test_that("sb_create_engine checks state B dimensions for a chain with no H", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  callWith <- function(state) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = setup$mcmc_obj, state = state, tiesCallback = setup$tiesCallback
    )
  }
  # A NULL H is legitimate — the gradient engine builds such a state — but its B
  # is imported and read all the same. A DELETED H is not: the impl indexes the
  # name, so the wrapper has to refuse it rather than let Rcpp throw from there.
  noH <- lapply(setup$state_obj, function(cs) {
    cs[["metro"]]["H"] <- list(NULL)
    cs[["metro"]]["tBy"] <- list(NULL)
    cs
  })
  expect_no_error(callWith(noH))

  shortB <- lapply(noH, function(cs) {
    b <- cs[["metro"]][["B"]][[1]]
    cs[["metro"]][["B"]][[1]] <- b[seq_len(nrow(b) - 1L), , drop = FALSE]
    cs
  })
  expect_error(callWith(shortB), "does not match this data/model")

  longB <- lapply(noH, function(cs) {
    b <- cs[["metro"]][["B"]][[1]]
    cs[["metro"]][["B"]][[1]] <- rbind(b, b[1, , drop = FALSE])
    cs
  })
  expect_error(callWith(longB), "does not match this data/model")

  noB <- lapply(noH, function(cs) {
    cs[["metro"]][["B"]] <- NULL
    cs
  })
  expect_error(callWith(noB), "one design matrix per signal")

  droppedH <- lapply(setup$state_obj, function(cs) {
    cs[["metro"]][["H"]] <- NULL
    cs
  })
  expect_error(callWith(droppedH), "must carry an H entry")
})

test_that("sb_create_engine checks imported sedSmooth state lengths", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE, flexibleKnots = FALSE,
                       knotRange = c(-5, 12))
  setup <- suppressMessages(make_guard_test_engine(stratData1, sModel))
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  callWith <- function(state) {
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = setup$mcmc_obj, state = state, tiesCallback = setup$tiesCallback
    )
  }
  expect_no_error(callWith(setup$state_obj))

  # Both are indexed per formation and sedLambda is WRITTEN (sed_gibbs_lambda),
  # so a short vector is a heap overrun, not a wrong number.
  for (field in c("sedBeta", "sedLambda")) {
    short <- lapply(setup$state_obj, function(cs) {
      v <- cs[["gibbs"]][[field]]
      cs[["gibbs"]][[field]] <- v[-length(v)]
      cs
    })
    expect_error(callWith(short), "does not match this data/model")
  }

  # Absent is not an error: the impl sizes it from the model instead.
  dropped <- lapply(setup$state_obj, function(cs) {
    cs[["gibbs"]][["sedLambda"]] <- NULL
    cs
  })
  expect_no_error(callWith(dropped))
})
