# RT-588 (issue #694): `StratPosterior` objects saved before the #264
# object-attached cache carry no `.cache`, but still hold a raw,
# never-stamp-checked `stratCluster` list element. Both `[[.StratPosterior` and
# `.ClusterInternal()`'s fast path used to serve that element verbatim whenever
# `.cache` was absent, bypassing cache invalidation entirely. The shipped
# datasets were regenerated with a cache (#1622), so the legacy shape is
# rebuilt here from `stratPosterior1`.
LegacyPosterior <- function(sp) {
  stale <- Cluster(sp)
  sp[[".cache"]] <- NULL
  sp[["stratCluster"]] <- stale
  sp
}

test_that("the legacy shape has no cache but a stored stratCluster (precondition)", {
  sp <- LegacyPosterior(stratPosterior1)
  expect_null(.subset2(sp, ".cache"))
  expect_false(is.null(.subset2(sp, "stratCluster")))
})

test_that("[[.StratPosterior recomputes stratCluster instead of trusting the uncached, unstamped stored element (RT-588)", {
  sp <- LegacyPosterior(stratPosterior1)
  stale <- .subset2(sp, "stratCluster")
  expect_length(stale[["rowIndex"]], 3L) # stored clustering: all 3 runs

  # Derive a 1-run posterior by field assignment, as in the RT-454 tests.
  # A correct recompute must reflect this; the stale stored element cannot.
  derived <- sp
  derived[["samples"]] <- derived[["samples"]][, , 1L, , drop = FALSE]
  derived[["nRun"]] <- 1L

  sc <- derived[["stratCluster"]]
  expect_length(sc[["rowIndex"]], 1L)
  expect_false(identical(sc, stale))
})

test_that(".ClusterInternal's fast path does not fall back to the raw, unstamped stratCluster element (RT-588)", {
  sp <- LegacyPosterior(stratPosterior1)
  stale <- .subset2(sp, "stratCluster")
  # selectRows chosen to match the stored element's rowIndex exactly, so a
  # naive fast path would consider it a hit and return the stale object as-is.
  sr <- stale[["rowIndex"]]

  res <- StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2000, 1:3, sr)
  expect_false(identical(res, stale))
})
