# RT-433 blast-radius sweep: regression tests for the validation now living in
# thin wrappers (AGENTS.md, "C++ error paths -- wrapper validates,
# implementation never throws"). Each of these throws was moved out of a large
# `*_impl` frame; these tests exist so the arm64-only CI run actually exercises
# every throw path added or relocated by the sweep, not just that the package
# builds. See test-cpp-engine-guards.R for the pre-existing splineOrder guard
# tests this file complements.
#
# make_guard_test_engine() is duplicated (not sourced) from
# test-cpp-engine-guards.R: top-level helpers defined in a `test-*.R` file are
# not shared across files under `R CMD check`/`devtools::test()` (only
# `helper-*.R` files are), so each test file that needs it carries its own copy
# -- the same reason memcheck/SplineOrderGuardTest.R duplicates it rather than
# sourcing a testthat file.

make_guard_test_engine <- function(sData, sModel, seed = 7261, knotRange = NULL) {
  if (isTRUE(sModel$flexibleKnots) && !is.null(knotRange)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      sigmaFixed = sModel$sigmaFixed,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }

  td <- file.path(tempdir(), paste0("errwrap_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = sData,
    stratModel  = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gtest",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gtest_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  list(
    data_obj = data_obj, model_obj = model_obj,
    mcmc_obj = mcmc_obj, state_obj = state_obj,
    tiesCallback = tiesCallback, td = td
  )
}

test_that("sb_create_engine rejects an unknown alignmentScale", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_model <- setup$model_obj
  bad_model$ind$alignmentScale <- "not-a-real-scale"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = bad_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown alignment scale"
  )
})

test_that("sb_create_engine rejects an unknown sedModel", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_model <- setup$model_obj
  bad_model$ind$sedModel <- "not-a-real-sedModel"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = bad_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown sedModel"
  )
})

test_that("sb_create_engine rejects an unknown proposal type", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_mcmc <- setup$mcmc_obj
  names(bad_mcmc$propose)[1] <- "NotARealProposalType"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = bad_mcmc, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown proposal type"
  )
})

# RT-325's construction-time refusal of flexibleKnots + a gradient proposal is
# gone: compute_logpost_gradient (Gradient_impl.h) carries the
# params -> ageRange -> knots -> B chain rule. Coverage of the surviving
# behaviour is test-flexible-knots-gradient.R's end-to-end NUTS run, which
# reaches .sb_create_engine through a legitimately NUTS-registered mcmc object.

test_that("sb_eval_logpost rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_eval_logpost(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_eval_logpost(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_compute_gradient rejects an out-of-range chain", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )

  expect_error(
    StratoBayes:::.sb_compute_gradient(engine_ptr, 99L),
    "chain must be between"
  )
})

test_that("sb_gradient_at rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_gradient_at(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_gradient_at(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_hmc_eval_logpost rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_hmc_eval_logpost(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_hmc_eval_logpost(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_sync_gibbs rejects an out-of-range chain", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nSig <- setup$model_obj$nSignals %||% length(setup$model_obj$sedModel)

  expect_error(
    StratoBayes:::.sb_sync_gibbs(engine_ptr, 99L, list(0), 1, 1),
    "chain must be between"
  )
})

test_that("sb_compute_gradient returns a finite gradient under flexibleKnots (both paths)", {
  # RT-307 made debug = TRUE call the production compute_logpost_gradient, so
  # both paths inherit the flexible-knot chain rule and neither refuses.
  # Value-level agreement with finite differences is
  # test-flexible-knots-gradient.R's job; this only pins that the wrappers do
  # not reject the combination.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)  # flexibleKnots = TRUE
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nFree <- setup$model_obj$parametersLengthNotFixed

  plain <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L, debug = FALSE)
  expect_length(plain$grad, nFree)
  expect_true(all(is.finite(plain$grad)))

  dbg <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L, debug = TRUE)
  expect_equal(dbg$grad, plain$grad)
  expect_length(dbg$grad_prior, setup$model_obj$parametersLength)
})

test_that(".sb_logpost(marginal = TRUE) requires lambda and Dmat", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  model_obj <- setup$model_obj
  data_obj  <- setup$data_obj

  x <- model_obj$metroParams %||% rep(0.1, model_obj$parametersLength)
  priorTypes <- vapply(model_obj$priors$metro, function(p) p$prior %||% "", character(1))

  expect_error(
    StratoBayes:::.sb_logpost(
      x = x, priorTypes = priorTypes, priorArgs = list(), rCustomFns = list(),
      B_list = list(), beta_list = list(), signalValues = list(),
      sigma = rep(1, data_obj$S), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = TRUE, lambda = NULL, Dmat = NULL
    ),
    "requires lambda and Dmat"
  )
})

test_that(".sb_logpost validates the joint-at-beta lambda/Dmat conformability", {
  # The flexible-knot joint branch indexes lambda per signal and Dmat up to each
  # signal's basis dimension. Those three checks live in the wrapper, not in the
  # ~140-line impl frame they guard (RT-433).
  # No parameters: the prior loop is a no-op, so the call exercises the joint
  # signal branch alone.
  nBas <- 4L
  B <- matrix(1, nrow = 3L, ncol = nBas)

  callJoint <- function(lambda, Dmat) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0),
      priorArgs = list(), rCustomFns = list(),
      B_list = list(B), beta_list = list(rep(0, nBas)),
      signalValues = list(rep(0, 3L)),
      sigma = 1, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = FALSE, lambda = lambda, Dmat = Dmat
    )
  }

  expect_error(callJoint(numeric(0), diag(nBas)),
               "lambda is shorter than the number of signals")
  expect_error(callJoint(1, matrix(1, nBas, nBas - 1L)), "Dmat must be square")
  expect_error(callJoint(1, diag(nBas - 1L)),
               "does not match the spline basis")
  expect_silent(callJoint(1, diag(nBas)))
})

test_that("sb_age_convert rejects an unknown alignmentScale and sedModel", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_ind_scale <- setup$model_obj$ind
  bad_ind_scale$alignmentScale <- "not-a-real-scale"
  expect_error(
    StratoBayes:::.sb_age_convert(setup$data_obj, bad_ind_scale, rep(0, setup$model_obj$parametersLength)),
    "Alignment must be on height or age scale"
  )

  bad_ind_sed <- setup$model_obj$ind
  bad_ind_sed$sedModel <- "not-a-real-sedModel"
  expect_error(
    StratoBayes:::.sb_age_convert(setup$data_obj, bad_ind_sed, rep(0, setup$model_obj$parametersLength)),
    "Unknown sedModel"
  )
})

# #1949: the wrapper/impl split closes off `stop()`, but `as<>()` and by-name
# List lookups throw too, and several sat inside `sb_logpost_impl`'s frame --
# the same aarch64 hazard by a different door. These pin the wrapper's own
# messages, so a regression that pushes the coercion back into the impl fails
# here (on x86-64 with a bare Rcpp `not_compatible`, on arm64 with a segfault).
test_that(".sb_logpost validates priorArgs shapes in the wrapper (#1949)", {
  callPrior <- function(priorType, args) {
    StratoBayes:::.sb_logpost(
      x = 0.5, priorTypes = priorType, priorArgs = list(args),
      rCustomFns = list(), B_list = list(), beta_list = list(),
      signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    )
  }

  # Something `as<List>()` cannot coerce at all is rejected whatever the type.
  expect_error(callPrior("NormalPrior", quote(x)),
               "priorArgs..1.. must be a list or a vector")
  expect_error(callPrior("NormalPrior", sum),
               "priorArgs..1.. must be a list or a vector")
  # A built-in density reads its args with as<double>(), so a character vector
  # cannot serve one even though `as<List>()` would coerce it -- but a custom
  # prior, whose args go to R untouched, still takes one.
  expect_error(callPrior("NormalPrior", "mean"),
               "priorArgs..1.. must be a list or a numeric vector")
  # NULL is what `as<List>()` reads as an empty list, so it fails on the name
  # its type needs rather than on the container's shape.
  expect_error(callPrior("NormalPrior", NULL),
               "is classed .NormalPrior. but has no .mean. argument")
  expect_error(callPrior("LogNormalPrior", NULL), "needs meanlog and sdlog")

  # A list missing a name its declared type reads: the by-name lookup threw
  # "index out of bounds" from the impl frame.
  expect_error(callPrior("NormalPrior", list(mean = 0)),
               "is classed .NormalPrior. but has no .sd. argument")
  expect_error(callPrior("UniformPrior", list(min = 0)),
               "is classed .UniformPrior. but has no .max. argument")
  expect_error(callPrior("TruncNormalPrior", list(mean = 0, sd = 1, lower = 0)),
               "is classed .TruncNormalPrior. but has no .upper. argument")
  expect_error(callPrior("ExponentialPrior", list()),
               "is classed .ExponentialPrior. but has no .rate. argument")

  # Present but not something as<double>() can read.
  expect_error(callPrior("NormalPrior", list(mean = 0, sd = "wide")),
               "priorArgs..1..[$]sd must be a single number")
  expect_error(callPrior("NormalPrior", list(mean = 0, sd = c(1, 2))),
               "priorArgs..1..[$]sd must be a single number")

  # LogNormalPrior is read positionally, so arity -- not names -- is the
  # constraint, and the message names the position.
  expect_error(callPrior("LogNormalPrior", list(meanlog = 0)),
               "needs meanlog and sdlog")
  expect_error(callPrior("LogNormalPrior", list(0, "wide")),
               "priorArgs..1....2.. .sdlog. must be a single number")

  # TruncLogNormalPrior is the one type whose C++ names diverge from its
  # constructor's (`min`/`max`, not `lower`/`upper`).
  expect_error(callPrior("TruncLogNormalPrior",
                         list(meanlog = 0, sdlog = 1, lower = 0.1, upper = 2)),
               "is classed .TruncLogNormalPrior. but has no .min. argument")

  # An atomic named vector is what `as<List>()` coerces, so it reached the impl
  # before these checks and still must.
  expect_equal(callPrior("NormalPrior", c(mean = 0, sd = 1))[[1]],
               stats::dnorm(0.5, 0, 1, log = TRUE))
  expect_equal(callPrior("LogNormalPrior", c(0, 1))[[1]],
               stats::dlnorm(0.5, 0, 1, log = TRUE))

  # Well-formed priors are untouched, and `Fixed` reads no argument at all.
  expect_equal(callPrior("NormalPrior", list(mean = 0, sd = 1))[[1]],
               stats::dnorm(0.5, 0, 1, log = TRUE))
  expect_equal(callPrior("LogNormalPrior", list(meanlog = 0, sdlog = 1))[[1]],
               stats::dlnorm(0.5, 0, 1, log = TRUE))
  # `Fixed` reads no argument, so any args shape serves it -- including the
  # NULL that `as<List>()` reads as an empty list.
  expect_equal(callPrior("Fixed", list(value = 0.5))[[1]], 0)
  expect_equal(callPrior("Fixed", NULL)[[1]], 0)
  expect_equal(callPrior("Fixed", "anything")[[1]], 0)
  # A custom prior's args go to R untouched, including an absent list and a
  # character argument its density reads by name.
  expect_equal(
    StratoBayes:::.sb_logpost(
      x = 0.5, priorTypes = "", priorArgs = list(c(family = "norm")),
      rCustomFns = list(function(x, family, log) {
        stopifnot(identical(family, "norm"))
        stats::dnorm(x, log = log)
      }),
      B_list = list(), beta_list = list(), signalValues = list(),
      sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    )[[1]],
    stats::dnorm(0.5, log = TRUE)
  )
  expect_equal(
    StratoBayes:::.sb_logpost(
      x = 0.5, priorTypes = "", priorArgs = list(NULL),
      rCustomFns = list(function(x, log) stats::dnorm(x, log = log)),
      B_list = list(), beta_list = list(), signalValues = list(),
      sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    )[[1]],
    stats::dnorm(0.5, log = TRUE)
  )
})

test_that(".sb_logpost type-checks the overlap lists without weights (#1949)", {
  # The pre-existing coercion of signalSectionOverlap lives in the
  # overlapWeights loop, so an empty `overlapWeights` reached the impl's
  # as<IntegerVector>() unchecked.
  callOverlap <- function(overlap, adjustments, weights = NULL) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0),
      priorArgs = list(), rCustomFns = list(),
      B_list = list(matrix(1, nrow = 3L, ncol = 2L)),
      beta_list = list(c(0, 0)), signalValues = list(c(1, 2, 3)),
      sigma = 1, overlapPenalty = TRUE,
      signalSectionOverlap = list(overlap), adjustments = list(adjustments),
      overlapWeights = weights
    )
  }

  expect_error(callOverlap(c("a", "b", "c"), 0.5),
               "signalSectionOverlap..1.. must be an integer vector")
  expect_error(callOverlap(list(1, 2, 3), 0.5),
               "signalSectionOverlap..1.. must be an integer vector")
  expect_error(callOverlap(c(1L, 1L, 1L), "big"),
               "adjustments..1.. must be a numeric vector")

  # The penalty itself is unchanged: three observations at overlap count 1.
  expect_equal(callOverlap(c(1L, 1L, 1L), 0.5)[[3]], 1.5)
  expect_equal(callOverlap(c(1L, 1L, 1L), 0.5, list(c(1, 1, 0)))[[3]], 1)
})

test_that(".sb_logpost type-checks lambda and Dmat on both branches (#1949)", {
  # `Nullable<>` stores the SEXP unchecked, so the impl's own
  # `NumericVector lam(lambda.get())` was the first thing to see its type --
  # and on the marginal branch nothing checked Dmat's shape at all.
  nBas <- 4L
  B <- matrix(1, nrow = 3L, ncol = nBas)

  callBranch <- function(marginal, lambda, Dmat) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0),
      priorArgs = list(), rCustomFns = list(),
      B_list = list(B), beta_list = list(rep(0, nBas)),
      signalValues = list(rep(0, 3L)),
      sigma = 1, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = marginal, lambda = lambda, Dmat = Dmat
    )
  }

  for (marginal in c(FALSE, TRUE)) {
    expect_error(callBranch(marginal, "1", diag(nBas)),
                 "lambda must be a numeric vector")
    expect_error(callBranch(marginal, 1, "D"), "Dmat must be a numeric matrix")
    expect_error(callBranch(marginal, 1, rep(1, nBas * nBas)),
                 "Dmat must be a numeric matrix")
    expect_error(callBranch(marginal, numeric(0), diag(nBas)),
                 "lambda is shorter than the number of signals")
    expect_error(callBranch(marginal, 1, diag(nBas - 1L)),
                 "does not match the spline basis")
    expect_silent(callBranch(marginal, 1, diag(nBas)))
  }
})
