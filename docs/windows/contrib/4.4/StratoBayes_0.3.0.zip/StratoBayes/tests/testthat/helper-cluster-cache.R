# A shipped `stratPosterior*` fixture carries an empty `.cache`, so a test that
# needs a known cache state must set one up rather than inherit whichever
# earlier test populated it.
#
# `lazy = FALSE` pre-populates `stratCluster` from the stored element, matching
# an object already clustered; `lazy = TRUE` leaves it empty so the deferred
# branches of `[[.StratPosterior` run. `stamp` is required, or RT-454 disowns
# the cache as inherited.
.WithClusterCache <- function(stratPosterior, lazy = FALSE) {
  ce <- new.env(parent = emptyenv())
  ce$stratCluster <- if (lazy) NULL else .subset2(stratPosterior, "stratCluster")
  ce$summary <- NULL
  ce$clusterCache <- list()
  ce$stamp <- .PosteriorStamp(stratPosterior)
  stratPosterior[[".cache"]] <- ce
  stratPosterior
}

# No shipped posterior is bimodal, so drop the third of `stratPosterior5a`'s
# three alignments to leave one that is.
.BimodalRows5a <- function() {
  cl <- Cluster(stratPosterior5a)
  Map(function(rows, clusters) rows[clusters %in% 1:2],
      cl[["rowIndex"]], cl[["clusterList"]])
}
