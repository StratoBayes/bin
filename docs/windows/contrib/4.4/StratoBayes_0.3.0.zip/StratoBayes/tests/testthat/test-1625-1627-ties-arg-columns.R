# `arg` columns are zipped onto a density's formals by position, so every
# consumer must order them by numeric suffix rather than trusting the ties
# data frame's own column order (#1625).

tieSignal <- function() {
  data.frame(site = rep(c("a", "b"), each = 11),
             height = rep(seq(0, 10, length.out = 11), 2),
             value = rep(seq(0, 1, length.out = 11), 2))
}

# Same tie, canonical vs permuted column order. dnorm's mean and sd are far
# apart so a positional swap cannot coincide with the correct value.
canonicalTies <- function() {
  data.frame(site = "a", height = 5, densityFun = "dnorm",
             arg1 = 30, arg2 = 0.2, stringsAsFactors = FALSE)
}
permutedTies <- function() canonicalTies()[, c("site", "height", "densityFun",
                                               "arg2", "arg1")]

tieModel <- function() {
  list(alignmentScale = "age", tiesActive = matrix(TRUE, 1, 2))
}

tieLogLik <- function(ties, age) {
  sData <- StratData(signal = tieSignal(), ties = ties)
  .LogLikTies(sData, tieModel(),
              list(age = list(ties = list(age, numeric(0)))))
}

test_that("a permuted `arg` column order gives the same tie log-likelihood (#1625)", {
  age <- 30.1
  expect_equal(tieLogLik(canonicalTies(), age),
               stats::dnorm(age, mean = 30, sd = 0.2, log = TRUE))
  expect_equal(tieLogLik(permutedTies(), age), tieLogLik(canonicalTies(), age))

  # the pre-fix value, asserted absent so a regression cannot pass silently
  expect_false(isTRUE(all.equal(tieLogLik(permutedTies(), age),
                                stats::dnorm(age, mean = 0.2, sd = 30,
                                             log = TRUE))))
})

test_that("StratData() stores tiesAttr `arg` columns in numeric order (#1625)", {
  sData <- StratData(signal = tieSignal(), ties = permutedTies())
  argNames <- grep("^arg", as.character(names(sData[["tiesAttr"]])),
                   value = TRUE)
  expect_identical(argNames, c("arg1", "arg2"))
})

test_that(".ArgColumns() sorts by numeric suffix, not lexically (#1625)", {
  expect_identical(.ArgColumns(c("site", "arg10", "arg2", "arg1")),
                   c("arg1", "arg2", "arg10"))
  expect_identical(.ArgColumns(c("site", "argument", "arg")), character(0))
})

test_that(".CollectArgs() reads permuted `arg` columns in numeric order (#1625)", {
  sData <- StratData(signal = tieSignal(), ties = permutedTies())
  expect_equal(.CollectArgs(sData, 1, 1), c(30, 0.2))
})

test_that("the C++ engine's ties callback builds args in numeric order (#1625)", {
  sData <- StratData(signal = tieSignal(), ties = permutedTies())
  dispatch <- .BuildTiesDispatch(sData, tieModel())
  args <- dispatch[["dispatch"]][[1]][[1]][["args"]]
  expect_equal(args[["mean"]], 30)
  expect_equal(args[["sd"]], 0.2)
})

test_that(".TieCentralAges() reads permuted `arg` columns in numeric order (#1625)", {
  # dunif's median is (min + max) / 2, so a swap of arg1/arg2 is invisible;
  # dlnorm's median is exp(meanlog), independent of arg2, so a swap moves it.
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  ties <- data.frame(site = "a", height = c(1, 5, 9), densityFun = "dlnorm",
                     arg1 = c(1, 2, 3), arg2 = c(0.5, 0.6, 0.7),
                     stringsAsFactors = FALSE)
  permuted <- ties[, c("site", "height", "densityFun", "arg2", "arg1")]

  got <- Partitions(signal, nStrata = 3, distribute = "height",
                    ties = permuted)[["height"]]
  expect_equal(got, Partitions(signal, nStrata = 3, distribute = "height",
                               ties = ties)[["height"]])

  # anchored against the true medians, so a consistently-wrong ordering on
  # both sides could not agree its way to a pass. The signal spans 0-10 but the
  # ties only 1-9, so the mapping must extrapolate off the terminal segment;
  # `rule = 2` would clamp every boundary inside the tie range, which is the
  # bug #1456 fixed. Written out here rather than calling `.ApproxExtrap()`, so
  # the anchor stays independent of the code it checks.
  extrap <- function(x, y, xout) {
    n <- length(x)
    vapply(xout, function(v) {
      if (v <= x[[1]]) {
        y[[1]] + (v - x[[1]]) * (y[[2]] - y[[1]]) / (x[[2]] - x[[1]])
      } else if (v >= x[[n]]) {
        y[[n]] + (v - x[[n]]) * (y[[n]] - y[[n - 1]]) / (x[[n]] - x[[n - 1]])
      } else {
        stats::approx(x, y, xout = v)[["y"]]
      }
    }, numeric(1))
  }
  medians <- stats::qlnorm(0.5, meanlog = c(1, 2, 3), sdlog = c(0.5, 0.6, 0.7))
  ageAt <- extrap(c(1, 5, 9), medians, c(0, 10))
  expect_equal(got, extrap(medians, c(1, 5, 9),
                           seq(ageAt[1], ageAt[2], length.out = 4)[-1]))
})

test_that("an `arg` beyond the density's arity is rejected, not silently dropped (#1625)", {
  # dexp takes only `rate`, so arg2 would land on its `log` formal.
  strayArg2 <- data.frame(site = "a", height = 5, densityFun = "dexp",
                          arg1 = 0.05, arg2 = 7, stringsAsFactors = FALSE)
  expect_error(.CheckTies(strayArg2, "height", "site"),
               "'dexp' takes 1 argument, so arg2 is not one of them")

  # A one-argument density alongside an unused arg2 column is still legal.
  unusedArg2 <- strayArg2
  unusedArg2[["arg2"]] <- NA_real_
  expect_silent(.CheckTies(unusedArg2, "height", "site"))
})

# ── #1626: a half-supplied densityFun/arg1 pair must not be reinterpreted ────

test_that(".CheckTies() rejects a `densityFun` supplied without `arg1` (#1626)", {
  halfPair <- data.frame(site = "a", height = 5, mean = 10, sd = 2,
                         densityFun = "dlnorm", stringsAsFactors = FALSE)
  expect_error(.CheckTies(halfPair, "height", "site"), "densityFun")
})

test_that(".CheckTies() rejects an `arg1` supplied without `densityFun` (#1626)", {
  halfPair <- data.frame(site = "a", height = 5, mean = 10, sd = 2, arg1 = 99)
  expect_error(.CheckTies(halfPair, "height", "site"), "densityFun")
})

# ── #1627: a zero-row ties table must name itself in the error ──────────────

test_that("a zero-row ties table errors naming `ties` (#1627)", {
  empty <- data.frame(site = character(0), height = numeric(0),
                      mean = numeric(0), sd = numeric(0))
  expect_error(.CheckTies(empty, "height", "site"), "ties has no rows")
  expect_error(StratData(signal = tieSignal(), ties = empty), "ties has no rows")

  # the densityFun/arg1 arm reached the same degenerate StratData silently
  emptyDensity <- data.frame(site = character(0), height = numeric(0),
                             densityFun = character(0), arg1 = numeric(0))
  expect_error(.CheckTies(emptyDensity, "height", "site"), "ties has no rows")
})

test_that("an all-NA orphan column is not a half-supplied pair (#1626)", {
  # nothing was supplied, so there is nothing to reinterpret
  blank <- data.frame(site = "a", height = 5, mean = 10, sd = 2,
                      densityFun = NA_character_, stringsAsFactors = FALSE)
  expect_silent(.CheckTies(blank, "height", "site"))
})

# ── #1534: summary() must print a one-argument density's actual parameter ───

test_that("summary.StratData() prints a one-argument tie density's parameter (#1534)", {
  ties <- data.frame(site = "a", height = c(2, 5), densityFun = "dexp",
                     arg1 = c(0.5, 0.25), stringsAsFactors = FALSE)
  sData <- StratData(signal = tieSignal(), ties = ties)
  out <- paste(utils::capture.output(summary(sData)), collapse = "\n")
  expect_match(out, "dexp\\(0\\.5\\), dexp\\(0\\.25\\)")
  expect_false(grepl("dexp(NA)", out, fixed = TRUE))
})
