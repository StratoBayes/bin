# #1425: the flexible-knot branch of .CreateSplineS() must span the same
# thing as the fixed-knot branch (only converted "signal", never "ties"),
# and must tolerate an NA in that signal via na.rm, matching the fixed-knot
# branch's `range(..., na.rm = TRUE)`.

test_that("flexible-knot ageSpan ignores ties, like the fixed-knot branch (#1425)", {
  fakeData <- list(signalAttr = list(signalValuesVec = 1, siteHeights = 1))

  # signal spans 0-10; ties span -100-100. If ties leak into the span, it
  # balloons to 200 instead of the correct 10.
  testthat::local_mocked_bindings(
    .sb_age_convert = function(data, ind, parameters) {
      list(signal = list(c(0, 10)), ties = list(c(-100, 100)))
    },
    .package = "StratoBayes"
  )

  out <- .CreateSplineS(nKnots = 4, knotRange = NULL, flexibleKnots = TRUE,
                        metroPriors = list(), ind = list(), data = fakeData)
  expect_equal(out[["ageSpan"]], 10)
})

test_that("flexible-knot ageSpan tolerates an NA in signal via na.rm (#1425)", {
  fakeData <- list(signalAttr = list(signalValuesVec = 1, siteHeights = 1))

  # An NA reaches "signal" (e.g. a partially-unresolved conversion at one
  # site); the fixed-knot branch would silently drop it via na.rm = TRUE.
  testthat::local_mocked_bindings(
    .sb_age_convert = function(data, ind, parameters) {
      list(signal = list(c(0, NA, 10)))
    },
    .package = "StratoBayes"
  )

  out <- .CreateSplineS(nKnots = 4, knotRange = NULL, flexibleKnots = TRUE,
                        metroPriors = list(), ind = list(), data = fakeData)
  expect_equal(out[["ageSpan"]], 10)
})

# #1426: PredictSpline() must not silently return sd = NA and degenerate
# quantiles when exactly one posterior iteration is selected -- it must warn.

test_that("PredictSpline warns when exactly one iteration is selected (#1426)", {
  set.seed(1426)
  x <- seq(0, 8, length.out = 30)
  y <- sin(x) + rnorm(30, 0, 0.2)
  fit <- BayesianSpline(x, y, nKnots = 6, nIter = 5, nThin = 1)

  # burnIn = 4 (an integer >= 1) discards the first 4 of 5 stored iterations,
  # leaving exactly one.
  expect_warning(
    pred <- PredictSpline(fit, at = x, burnIn = 4),
    "one.*iteration"
  )
  expect_true(all(is.na(pred[["sd"]])))
  # the quantiles are the single retained draw, repeated -- not fabricated
  expect_equal(pred[["0.5"]], pred[["mu"]])
  expect_equal(pred[["0.025"]], pred[["mu"]])
  expect_equal(pred[["0.975"]], pred[["mu"]])

  # a normal multi-iteration burnIn is unaffected
  expect_silent(PredictSpline(fit, at = x, burnIn = 1))
})
