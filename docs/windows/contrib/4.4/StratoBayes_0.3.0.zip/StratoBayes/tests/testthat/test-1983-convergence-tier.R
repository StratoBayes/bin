# #1983: one classifier decides which columns convergence is judged on.
#
# Guards against recurrence: a new `.GenerateOutput()` column family is Gate
# (checked) unless this file is deliberately updated to exempt it, and
# `summary()`, `burnIn = "auto"` and `convergenceStop` all monitor exactly the
# Gate set.

.kDensity1983 <- c("posterior", "prior_parameters", "prior_overlap",
                   "likelihood_spline", "likelihood_ties")

.OffsetData1983 <- function() {
  n <- 30
  h <- seq(0, 10, length.out = n)
  sig <- data.frame(
    site = rep(c("site_1", "site_2"), each = n),
    height = c(h, h),
    value = c(sin(h), sin(h) + 2) +
      withr::with_seed(1983, rnorm(2 * n, 0, 0.1))
  )
  grp <- data.frame(site = c("site_1", "site_2"), group = c("A", "B"),
                    stringsAsFactors = FALSE)
  StratData(signal = sig, group = grp)
}

.Configs1983 <- list(
  defaults = function() list(data = stratData1, model = StratModel(
    stratData1, alignmentScale = "height", sedModel = "site")),
  sigmaFree = function() list(data = stratData1, model = StratModel(
    stratData1, alignmentScale = "height", sedModel = "site",
    sigmaFixed = FALSE)),
  ties = function() list(data = stratData2, model = StratModel(
    stratData2, alignmentScale = "height", sedModel = "site")),
  noOverlap = function() list(data = stratData1, model = StratModel(
    stratData1, alignmentScale = "height", sedModel = "site",
    overlapPenalty = FALSE)),
  signalOffsets = function() {
    d <- .OffsetData1983()
    list(data = d, model = StratModel(d, alignmentScale = "height",
                                      sedModel = "site", nKnots = 8,
                                      signalOffsets = TRUE))
  },
  sedSmooth = function() list(data = stratData1, model = StratModel(
    stratData1, alignmentScale = "height", sedModel = "site, partition",
    sedSmooth = TRUE, nKnots = 10)),
  age = function() list(data = stratData2, model = StratModel(
    stratData2, priors = stratPrior2, alignmentScale = "age",
    sedModel = "site", alphaPosition = c("top", "middle", "bottom"),
    nKnots = 10))
)

.ConfigCache1983 <- new.env(parent = emptyenv())
.Config1983 <- function(name) {
  if (is.null(.ConfigCache1983[[name]])) {
    .ConfigCache1983[[name]] <- suppressWarnings(.Configs1983[[name]]())
  }
  .ConfigCache1983[[name]]
}

# Written out independently of the classifier: changing either list is the
# deliberate decision that a family need not converge on its own.
.ExpectedTiers1983 <- function(cfg) {
  out <- cfg$model$outputParams
  sigNames <- cfg$data$signalAttr$signalNames
  covered <- as.vector(outer(paste("beta", sigNames, sep = "_"),
                             seq_len(cfg$model$splineBase$num_basis),
                             paste, sep = "_"))
  bookkeeping <- c("proposal_accepted", "proposal_number")
  list(covered = covered, bookkeeping = bookkeeping,
       gate = setdiff(out, c(covered, bookkeeping)))
}

.Summed1983 <- function(gate) {
  c(setdiff(gate, .kDensity1983),
    "log prior", "log likelihood", "log posterior")
}

test_that("#1983: every output column is classified as expected", {
  for (name in names(.Configs1983)) {
    cfg <- .Config1983(name)
    expected <- .ExpectedTiers1983(cfg)
    tier <- .ConvergenceTier(cfg$model$outputParams,
                             cfg$model$parametersNames,
                             cfg$data$signalAttr$signalNames)

    expect_identical(names(tier), as.character(cfg$model$outputParams),
                     info = name)
    expect_setequal(names(tier)[tier == "covered"], expected$covered)
    expect_setequal(names(tier)[tier == "bookkeeping"], expected$bookkeeping)
    expect_setequal(names(tier)[tier == "gate"], expected$gate)
    expect_true(all(cfg$model$parametersNames %in% expected$gate), info = name)
  }
})

test_that("#1983: configurations exercise the families they are here for", {
  Out <- function(name) .Config1983(name)$model$outputParams
  Gate <- function(name) .ExpectedTiers1983(.Config1983(name))$gate
  expect_true(any(startsWith(Out("sigmaFree"), "sigma_")))
  expect_true("likelihood_ties" %in% Out("ties"))
  expect_true("prior_overlap" %in% Out("defaults"))
  expect_false("prior_overlap" %in% Out("noOverlap"))
  expect_true(any(startsWith(Gate("signalOffsets"), "delta_")))
  expect_true(any(startsWith(Gate("signalOffsets"), "tau_")))
  expect_true(any(startsWith(Gate("sedSmooth"), "sedBeta_")))
  expect_true(any(startsWith(Gate("sedSmooth"), "sedLambda_")))
})

test_that("#1983: an unrecognised column is Gate", {
  tier <- .ConvergenceTier(
    c("iteration", "chain", "alpha_site2", "newFamily_1", "beta_d13C_1",
      "beta_1", "beta_d13C_x", "proposal_number"),
    parametersNames = "alpha_site2", signalNames = "d13C")
  expect_identical(unname(tier), c("bookkeeping", "bookkeeping", "gate",
                                   "gate", "covered", "gate", "gate",
                                   "bookkeeping"))
})

test_that("#1983: convergenceStop monitors exactly the Gate set", {
  for (name in names(.Configs1983)) {
    cfg <- .Config1983(name)
    binaryColNames <- c("iteration", "chain", cfg$model$outputParams)
    idx <- .ConvergenceMonitorCols(binaryColNames, cfg$model$parametersNames,
                                   cfg$data$signalAttr$signalNames)
    expect_setequal(binaryColNames[idx], .ExpectedTiers1983(cfg)$gate)
  }
})

test_that("#1983: summary() and burnIn = 'auto' monitor exactly the Gate set", {
  skip_on_cran()
  for (name in names(.Configs1983)) {
    cfg <- .Config1983(name)
    dir <- withr::local_tempdir()
    post <- suppressWarnings(RunStratModel(
      stratObject = cfg$data, stratModel = cfg$model, nIter = 20L,
      nChains = 1L, nRun = 1L, nThreads = 1L, seed = 1, quiet = TRUE,
      visualise = FALSE, convergenceStop = FALSE, modelDir = dir,
      modelName = name
    ))
    expect_identical(as.character(dimnames(post$samples)[[2]]),
                     as.character(cfg$model$outputParams), info = name)

    summed <- .Summed1983(.ExpectedTiers1983(cfg)$gate)
    s <- suppressWarnings(summary(post, burnIn = 0, alignment = "none"))
    expect_setequal(rownames(s$alignmentAll$summary), summed)
    expect_setequal(names(s$general$psrf), summed)
    # multiESS reads the alignment parameters by position.
    parNames <- as.character(cfg$model$parametersNames)
    expect_identical(rownames(s$alignmentAll$summary)[seq_along(parNames)],
                     parNames, info = name)

    draws <- .AutoBurnInDraws(post)
    expect_setequal(colnames(draws$drawList[[1]]), summed)
  }
})

test_that("#1983: allParameters = TRUE adds the Covered columns to both the table and psrf", {
  skip_on_cran()
  cfg <- .Config1983("defaults")
  dir <- withr::local_tempdir()
  suppressWarnings(RunStratModel(
    stratObject = cfg$data, stratModel = cfg$model, nIter = 20L,
    nChains = 1L, nRun = 1L, nThreads = 1L, seed = 1, quiet = TRUE,
    visualise = FALSE, convergenceStop = FALSE, modelDir = dir,
    modelName = "allParameters"
  ))
  post <- suppressWarnings(StratPosterior(readDir = dir))
  expected <- .ExpectedTiers1983(cfg)

  sDefault <- suppressWarnings(summary(post, burnIn = 0, alignment = "none"))
  expect_setequal(names(sDefault$general$psrf), .Summed1983(expected$gate))
  expect_setequal(rownames(sDefault$alignmentAll$summary),
                  .Summed1983(expected$gate))

  s <- suppressWarnings(summary(post, burnIn = 0, alignment = "none",
                                allParameters = TRUE))
  expect_setequal(names(s$general$psrf),
                  c(.Summed1983(expected$gate), expected$covered))
  expect_setequal(rownames(s$alignmentAll$summary),
                  c(.Summed1983(expected$gate), expected$covered))

  # burnIn = "auto" and convergenceStop always judge the Gate set, whatever
  # allParameters is asked for downstream.
  draws <- .AutoBurnInDraws(post)
  expect_setequal(colnames(draws$drawList[[1]]), .Summed1983(expected$gate))

  # A default summary() call is memoised (#1281); a non-default one
  # (allParameters = TRUE here) must neither read nor overwrite it -- mirrors
  # how `betaRHat` was covered before the #1983 rename.
  cache <- .PosteriorCache(post)
  expect_false(is.null(cache))
  expect_null(cache$summary)

  trueDefault <- suppressMessages(summary(post))
  expect_identical(cache$summary, trueDefault)

  suppressWarnings(summary(post, allParameters = TRUE))
  expect_identical(cache$summary, trueDefault)
})
