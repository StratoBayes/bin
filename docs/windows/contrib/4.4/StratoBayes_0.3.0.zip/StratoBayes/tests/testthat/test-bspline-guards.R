# BayesianSpline() / PredictSpline() argument and burn-in guards.

.GuardFit <- function(nIter = 20, nThin = 1, nKnots = 5) {
  set.seed(1)
  x <- seq(0, 8, length.out = 30)
  y <- sin(x) + rnorm(30, 0, 0.2)
  BayesianSpline(x, y, nKnots = nKnots, nIter = nIter, nThin = nThin)
}

test_that("PredictSpline() validates `at` (#1831)", {
  fit <- .GuardFit()
  expect_error(PredictSpline(fit, at = NA_real_), "`at`")
  expect_error(PredictSpline(fit, at = numeric(0)), "`at`")
  expect_error(PredictSpline(fit, at = "a"), "`at`")
  expect_s3_class(PredictSpline(fit, at = c(1, 2)), "data.frame")
})

test_that("proportion burnIn keeps the last row, as StratPosterior does (#1829)", {
  fit <- .GuardFit(nIter = 12)
  expect_equal(nrow(fit[["beta"]]), 12L)
  pred <- PredictSpline(fit, at = c(1, 2), burnIn = 0.95)
  expect_s3_class(pred, "data.frame")
  expect_error(PredictSpline(fit, at = c(1, 2), burnIn = 1.5 * 12), "burnIn")
})

test_that("fractional nThin is rounded to what C++ stores (#1830)", {
  fit <- .GuardFit(nIter = 20, nThin = 2.5)
  expect_identical(fit[["nThin"]], 2)
  expect_equal(nrow(fit[["beta"]]), length(seq(1, 20, fit[["nThin"]])))
})

test_that("BayesianSpline() guards smooth.spline's initialiser (#1744)", {
  fit <- BayesianSpline(x = c(1, 2, 3), y = c(1, 3, 2), nKnots = 3, nIter = 5)
  expect_true(all(is.finite(fit[["beta"]])))
})

test_that("BayesianSpline() rounds a fractional nKnots (#1744)", {
  fit <- .GuardFit(nKnots = 5.4)
  expect_identical(fit[[c("model", "splineBase", "nKnots")]], 5)
  expect_equal(ncol(fit[["beta"]]), 5 + 4 - 2)
})

test_that("BayesianSpline() rejects vector xMin / xMax by name (#1744)", {
  x <- seq(0, 8, length.out = 30)
  y <- sin(x)
  expect_error(BayesianSpline(x, y, nKnots = 5, nIter = 5, xMin = c(-1, 0)),
               "xMin")
  expect_error(BayesianSpline(x, y, nKnots = 5, nIter = 5, xMax = range(x)),
               "xMax")
})
