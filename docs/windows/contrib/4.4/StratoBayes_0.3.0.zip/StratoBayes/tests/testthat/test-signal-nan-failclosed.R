# GH #551 (secondary): the signal log-likelihood must never reach the log-posterior
# as NaN.
#
# WHY. sum_narm() in src/MCMCEngine.cpp skips ISNAN components:
#
#     for (int i = 0; i < 4; ++i) if (!ISNAN(v[i])) s += v[i];
#
# so a NaN signal term is not propagated -- it is silently DROPPED, and the state is
# then scored on prior + ties + overlap alone. That is fail-OPEN: the missing term is
# a large negative number, so omitting it inflates the state and can make it
# acceptable when it should be rejected. It is the same shape as the ties accumulator
# bug whose -1e30 clamp carries the note that it "would pin the chain".
#
# +/-Inf is deliberately NOT affected: sum_narm keeps it, so an -Inf signal already
# propagates and rejects correctly. Only NaN is dangerous, and only NaN is remapped.
#
# sb_cholesky() does not catch this. dpotrf's pivot test is `ajj <= 0`, false for NaN
# under IEEE754, so a NaN in M passes with info == 0 and poisons L, logdet and quad.
#
# SCOPE OF THIS FILE. It exercises the shared primitive signal_logmarginal_one()
# through .sb_logpost(), which is the only route reachable from R. The engine-side
# joint-at-beta path (compute_loglik_signal + flexknot_beta_logprior, used by
# HMC/NUTS) is guarded by the ISNAN fold in compute_logpost() but is NOT covered
# here: it is not callable from R without a live engine, and a NaN beta/sigma cannot
# be injected through the model constructor. That guard rests on inspection.

test_that(".sb_logpost signal slot is -Inf, never NaN, when M contains NaN", {
  p <- 4L
  n <- 5L
  lambda <- 1

  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D <- crossprod(Delta)
  y <- as.numeric(seq_len(n))

  call_marginal <- function(B, sigma) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(B), beta_list = list(numeric(p)),
      signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)
  }

  # sigma underflow: sigma^2 == 0, so inv_sig2 == Inf. B has structural zeros, so
  # BtB does too, and 0 * Inf == NaN puts NaN directly into M. This is a genuinely
  # different failure from the rank-deficient case in test-marginal-neginf.R, which
  # makes dpotrf fail cleanly (info != 0) rather than succeed on poisoned input.
  set.seed(551)
  B <- matrix(0, n, p)
  B[cbind(seq_len(n), rep_len(seq_len(p), n))] <- stats::rnorm(n)
  expect_true(any(crossprod(B) == 0))          # structural zeros present in BtB

  res <- call_marginal(B, sigma = 1e-200)
  expect_false(is.nan(res[2]))                 # the invariant that matters
  expect_identical(res[2], -Inf)               # fail closed

  # Control: the same B at a sane sigma is finite, proving the -Inf is caused by the
  # underflow and not by the harness or the zero pattern.
  resOk <- call_marginal(B, sigma = 1)
  expect_true(is.finite(resOk[2]))
})

test_that("an -Inf signal term is preserved rather than remapped", {
  # Guards the other half of the contract: the fix must not turn -Inf into something
  # else. A rank-deficient design makes dpotrf fail and must still yield exactly
  # -Inf, so "impossible" stays distinguishable from "numerically failed".
  p <- 4L
  n <- 5L
  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D <- crossprod(Delta)
  res <- StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(matrix(1, n, p)),
    beta_list = list(numeric(p)), signalValues = list(as.numeric(seq_len(n))),
    sigma = 1, overlapPenalty = FALSE, signalSectionOverlap = list(),
    adjustments = list(), marginal = TRUE, lambda = 1, Dmat = D, flexTerm = 0)
  expect_identical(res[2], -Inf)
})
