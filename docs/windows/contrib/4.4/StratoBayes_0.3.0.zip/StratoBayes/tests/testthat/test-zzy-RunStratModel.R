{ # Initialize test objects
  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  testDataMulti[[c("parts", "Hight")]] <- c(80.0, 10.5, 20.0, 20.0, 31, 20)
  tmulti <- StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
                      ties = testDataMulti[["ties"]],
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  #StratModelTemplate(tmulti, alignmentScale = "age", sedModel = "s", alphaPosition = "b")
  priorsm <- structure(list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)),
      class = c("StratPrior", "list"))

  modelm <- StratModel(tmulti, priorsm, alignmentScale = "age", sedModel = "site",
                       alphaPosition = "bottom")
  mcmcm <- StratMCMC(modelm, nIter = 10, nChains = 2)
}

test_that("RunStratModel throws appropriate errors for invalid input", {

  expect_error(RunStratModel(1),
               "'StratData' or 'StratPosterior' object",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = 1, alignmentScale = "age",
                             sedModel = "site", alphaPosition = "bottom"),
               "`priors` must be an object of class 'StratPrior'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,stratModel = NA),
               "`StratModel` must be `NULL`, or an object of class 'StratModel'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, stratModel = modelm, stratMCMC = FALSE),
               "`stratMCMC` must be `NULL`, or an object of class 'StratMCMC'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = 1),
               "`alignmentScale` must be either 'height' or 'age'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = "age", sedModel = NA),
               "Invalid 'sedModel' input. Please choose from 'site', 'partition', 'site x partition', or 'site, partition'.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = "age", sedModel = "s",
                             nKnots = 1.1),
               "'nKnots' must be an integer >= 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             overlapPenalty = "no"),
               "Invalid `overlapPenalty`",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             overlapPenalty =  1),
               "Invalid `overlapPenalty`",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  c(1,NA)),
               "'sigmaFixed' must not contain NA values.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  c(1)),
               "'sigmaFixed' must be of length 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  "no"),
               "'sigmaFixed' must be numeric.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             flexibleKnots =  0),
               "'flexibleKnots' must be logical.",
               fixed = TRUE)



  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             knotRange = c(NA,50), flexibleKnots = FALSE),
               "'knotRange' must not contain NA values.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             knotRange = c(0,Inf), flexibleKnots = FALSE),
               "'knotRange' must be finite.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             countGaps = NA),
               "'countGaps' must be logical.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             aLambda = NA),
               "aLambda must be numeric",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             bSigma = "wrong"),
               "bSigma must be numeric.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             minSignalOverlap = TRUE),
               "minSignalOverlap must be an integer or FALSE",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             priorsProposals  = TRUE),
               "`priorsProposals` must be an object of class 'StratPrior'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             ratesRange  = 1),
               "'ratesRange' must be of length 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(1)),
               "parametersInitial",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(rep(c("a", rep(1,6))))),
               "parametersInitial",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(rep(-1,7))),
               "parametersInitial",
               fixed = TRUE)

  # RT-222: an initial rate parameter within the priors' support but outside
  # [ratesMin, ratesMax] passes the prior check yet would hang
  # .GenerateValidProposal(); it must be rejected at validation time instead.
  # gammaLog_site1 = 20 has finite Normal(1, 1) density but exceeds the default
  # ratesMax of 14.
  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(40, 35, 35, 20, 1, 1, 1)),
               "outside the permitted range",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             colourScale = "dark"),
               "Invalid colourScale",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             nIter = 1:2),
               "`nIter`",
               fixed = TRUE)
})



test_that("RunStratModel throws warnings when overwriting arguments", {
  expect_warning(
    r1 <- RunStratModel(stratObject = stratData1,
                        stratModel = stratModel1,
                        sigmaFixed = FALSE,
                        priors = FALSE,
                        alignmentScale = "age", sedModel = "s",
                        visualise = FALSE, runParallel = FALSE,
                        nIter = 1, saveChains = 1:2, nRun = 1),
    regexp = "priors|alignmentScale|sedModel|sigmaFixed"
  )
  expect_s3_class(r1, "StratPosterior")

  stratMCMC1b <- StratMCMC(stratModel1, nIter = 3L, nChains = 2L, nThreads = 2L)
  expect_warning(
    r2 <- RunStratModel(stratObject = stratData1,
                        stratModel = stratModel1,
                        stratMCMC = stratMCMC1b,
                        visualise = FALSE, runParallel = FALSE,
                        nIter = 6, saveChains = 1:2, nRun = 1,
                        nChains = 4),
    regexp = "nIter|saveChains|nChains"
  )
  expect_s3_class(r2, "StratPosterior")
})

test_that("RunStratModel warns with duplicated seeds", {
  expect_warning(
    r1 <- RunStratModel(tmulti, priors = priorsm,
                    alignmentScale = "age", sedModel = "s",
                    visualise = FALSE, runParallel = FALSE,
                    nIter = 6, nRun = 5, seed = c(0, 4, 2, 4, 0)),
      "Identical seeds specified \\(4, 0\\); these runs will be identical"
  )
  expect_s3_class(r1, "StratPosterior")
  expect_equal(r1[["samples"]][, , 5, ], r1[["samples"]][, , 1, ])
  expect_equal(r1[["samples"]][, , "run2", ], r1[["samples"]][, , "run4", ])
})


test_that("RunStratModel works with standard settings", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 2, seed = 0,
                      sigmaFixed = 1:2)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with fixed knots", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, seed = TRUE,
                      flexibleKnots = FALSE, knotRange = c(20,50),
                      sigmaFixed = 1:2)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with nRun >1", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, seed = 1:2,
                      nRun = 2, sigmaFixed = 1:2,
                      visualise = FALSE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with sigmaFixed = FALSE", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, sigmaFixed = FALSE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with sigmaFixed = FALSE & saveMCMC = TRUE", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 2, sigmaFixed = FALSE,
                      saveMCMC = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with minSignalOverlap = T and overlapPenalty = F", {
  set.seed(0)
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 4, minSignalOverlap = 15,
                      overlapPenalty = FALSE, nKnots = 10,
                      nRun = 2)
  expect_s3_class(r1, "StratPosterior")
})

# parallel run
test_that("RunStratModel parallel runs", {
  skip_if_not_installed("future.apply")
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("oversubscription warning uses min(nThreads, nChains), not nChains (#566)", {
  skip_if_not_installed("future.apply")
  local_mocked_bindings(detectCores = function(...) 2L, .package = "parallel")

  # nThreads = 2, nChains = 8 -> threadsPerRun should be min(2, 8) = 2, not 8.
  expect_warning(
    RunStratModel(tmulti, priors = priorsm,
                  alignmentScale = "age", sedModel = "s",
                  nIter = 1, nChains = 8, nThreads = 2L, nCores = 2L,
                  nRun = 2, seed = 1:2, runParallel = TRUE,
                  visualise = FALSE),
    "x 2 concurrent",
    fixed = TRUE
  )
})

test_that("oversubscription warning reads the resolved nChains, not the outer formal (#534)", {
  skip_if_not_installed("future.apply")
  local_mocked_bindings(detectCores = function(...) 16L, .package = "parallel")

  # A directly-supplied `stratMCMC=` object's own nChains (2) wins over the
  # outer (ignored, per the existing "will be overwritten" warning) formal
  # nChains = 20. The pre-fix formula read the unresolved formal and warned
  # spuriously (1 x 20 > 16 available).
  smallMcmc <- StratMCMC(modelm, nIter = 1, nChains = 2, nThreads = 2L)

  warnings <- character(0)
  withCallingHandlers(
    RunStratModel(tmulti, stratModel = modelm, stratMCMC = smallMcmc,
                  nChains = 20, nThreads = 2L, nCores = 1L,
                  nRun = 2, seed = 1:2, runParallel = TRUE,
                  visualise = FALSE),
    warning = function(w) {
      warnings[[length(warnings) + 1]] <<- conditionMessage(w)
      invokeRestart("muffleWarning")
    }
  )
  expect_false(any(grepl("oversubscribe", warnings)))
})

# continued run
test_that("RunStratModel continuing runs", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE)
  skip_if_not_installed("future.apply")
  r2 <- RunStratModel(r1, nIter = 3, runParallel = TRUE, visualise = FALSE)
  r3 <- RunStratModel(r2, nIter = 1, visualise = FALSE)
  # #209: a continuation cannot switch thinning interval -- the run's single
  # samples file would end up on two schedules -- so `nThin = 2` is reported
  # and dropped in favour of the stored `nThin = 1`.
  expect_warning(
    r4 <- RunStratModel(r3, stratModel = stratModel1, nIter = 6,
                        runParallel = FALSE, nThin = 2, visualise = FALSE),
    "two different schedules"
  )
  expect_s3_class(r4, "StratPosterior")
  expect_equal(r4[["mcmcSummary"]][["saveIter"]][[1]], 1:12)
})

# continued run with different directory option
test_that("RunStratModel continuing runs - custom directory", {
  tempDir <- tempdir()
  modelDir <- paste0(tempDir, "\\")
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, modelDir = modelDir,
                      modelName = "testName")
  # continue from directory

  r2 <- RunStratModel(nIter = 1, visualise = FALSE, modelDir = r1$modelDir, modelName = r1$modelName)
  r3 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, modelDir = tempDir,
                      modelName = "testName")
  # continue from directory

  r4 <- RunStratModel(nIter = 1, visualise = FALSE, modelDir = r3$modelDir, modelName = r3$modelName)
  expect_s3_class(r2, "StratPosterior")
  expect_s3_class(r4, "StratPosterior")
})

# save other chains
test_that("RunStratModel continuing runs", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, saveChains = c(1, 3))
  # continued
  r2 <- RunStratModel(r1, nIter = 2, runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")
  expect_equal(dim(r2[["samples"]]), c(length(r2$mcmcSummary$saveIter[[1]]),
                                       length(r2$model$outputParams),
                                       r2$nRun,
                                       length(r2$mcmcSummary$saveChains[[1]])))

  # not continued
  r3 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, saveChains = c(2,1))

  expect_equal(colnames(r3$samples[,1,1,]), c("chain2", "chain1"))
})


# continued run, mixing adaptation and no adaptation
test_that("RunStratModel changing adaptation", {
  r1 <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, startAdapting = 4,
                      endAdapting = 10, adaptTemperatures = FALSE)

  r2 <- RunStratModel(r1, nIter = 2, runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")


  # see that continued run keeps previous saveChains and nChains
  r3 <- RunStratModel(r2, nIter = 2,
                      nKnots = 5, visualise = FALSE, seed = 2:3,
                      runParallel = FALSE, saveChains = c(2, 1), nChains = 4,
                      startAdapting = 1, endAdapting = 2)

  expect_s3_class(r3, "StratPosterior")

})

# continued run, passing MCMC rather than reading from folder
test_that("RunStratModel passing mcmc", {
  r1 <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, startAdapting = 4,
                      endAdapting = 10, adaptTemperatures = FALSE,
                      modelDir = tempdir(), saveMCMC = TRUE)
  modelDir <- r1$modelDir
  # delete files
  files <- list.files(modelDir, full.names = TRUE, recursive = TRUE,
                      pattern = paste0("^", r1$modelName))
  unlink(files, recursive = TRUE)

  # check that directory is empty
  expect_equal(length(list.files(modelDir, full.names = TRUE, recursive = TRUE,
                                 pattern = paste0("^", r1$modelName))), 0)

  r2 <- RunStratModel(r1, stratMCMC = r1[["mcmc"]], nIter = 2,
                      runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")

})

test_that("RunStratModel warns when a continuation argument cannot take effect (#574)", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 2, nChains = 2, saveChains = 1,
                      visualise = FALSE, runParallel = FALSE, seed = 1,
                      modelDir = tempdir(), saveMCMC = TRUE)
  checkpoint <- r1[["mcmc"]]

  # nChains/saveChains/temperingComponents: accepted but always overridden
  # by the checkpoint's own value on a continuation.
  expect_warning(
    RunStratModel(r1, stratMCMC = checkpoint, nIter = 1,
                  visualise = FALSE, nChains = 4),
    "nChains"
  )
  expect_warning(
    RunStratModel(r1, stratMCMC = checkpoint, nIter = 1,
                  visualise = FALSE, saveChains = c(1, 2)),
    "saveChains"
  )
  expect_warning(
    RunStratModel(r1, stratMCMC = checkpoint, nIter = 1,
                  visualise = FALSE, temperingComponents = "signal"),
    "temperingComponents"
  )

  # gradientProposals: not inherited from the checkpoint at all, so an
  # explicit value that differs from the checkpoint's own setting silently
  # changes the registered proposal set instead of being ignored outright.
  # "off" is used rather than "on" because it registers the same MH-only
  # proposals as the checkpoint's "auto" default under flexible knots, so the
  # scenario isolates the missing-inheritance warning from the unrelated,
  # pre-existing crash when a continuation's registered proposal *count*
  # actually changes (proposal-state transfer in `.UpdateMCMCforContinuedRun`
  # assumes an unchanged proposal set).
  expect_warning(
    RunStratModel(r1, stratMCMC = checkpoint, nIter = 1,
                  visualise = FALSE, gradientProposals = "off"),
    "gradientProposals"
  )

  # A continuation that supplies none of these should stay silent.
  expect_no_warning(
    RunStratModel(r1, stratMCMC = checkpoint, nIter = 1, visualise = FALSE)
  )
})

# test time limits
test_that("RunStratModel runs with time limits and terminates early", {
  stratPosterior0a <- RunStratModel(stratObject = stratData0,
                                   stratModel = stratModel0,
                                   nRun = 5,
                                   runParallel = FALSE,
                                   nIter = 5000,
                                   nThin = 5,
                                   saveMCMC = TRUE,
                                   timeLimit = 7/(60^2), # 4.5 seconds,
                                   seed = 1:5,
                                   quiet = TRUE)

  expect_true(stratPosterior0a[[c("mcmcSummary", "completedIter")]][[1]] < 5000)

  stratPosterior0b <- RunStratModel(stratObject = stratPosterior0a,
                                    nRun = 5,
                                    runParallel = FALSE,
                                    nIter = 2000,
                                    nThin = 1,
                                    saveMCMC = FALSE,
                                    timeLimit = 4/(60^2), # 3 seconds,
                                    seed = 1:5,
                                    quiet = TRUE,
                                    visualise = FALSE)

  stratPosterior0c <- RunStratModel(stratObject = stratPosterior0b,
                                    runParallel = FALSE,
                                    nIter = 1,
                                    nThin = 5,
                                    saveMCMC = TRUE, seed = 1:5)

  # try a different data set and only 1 run
  stratPosterior2a <- RunStratModel(stratObject = stratData2,
                                    stratModel = stratModel2,
                                    nRun = 1,
                                    runParallel = FALSE,
                                    nIter = 1000,
                                    nThin = 5,
                                    timeLimit = 4/(60^2), # 4 seconds
                                    saveMCMC = TRUE, seed = 1,
                                    quiet = TRUE,
                                    saveChains = c(1,4, 8))

  stratPosterior2b <- RunStratModel(stratObject = stratPosterior2a,
                                    nRun = 1,
                                    runParallel = FALSE,
                                    nIter = 10,
                                    nThin = 8,
                                    timeLimit = 2/(60^2), # 2 seconds
                                    saveMCMC = TRUE, seed = 1,
                                    quiet = TRUE)


  expect_equal(dim(stratPosterior2b[["samples"]])[4], 3)

  skip_if_not_installed("future.apply")
  # time limit with parallel runs
  stratPosterior3a <- RunStratModel(stratObject = stratData3,
                                    stratModel = stratModel3,
                                    nRun = 2,
                                    runParallel = TRUE,
                                    nIter = 5000,
                                    nThin = 3,
                                    timeLimit = 0.5/(60^2), # 2.5 seconds
                                    seed = 1:2,
                                    quiet = TRUE,
                                    saveChains = 1,
                                    visualise = FALSE)
  expect_true(stratPosterior3a[[c("mcmcSummary", "completedIter")]][[1]] < 5000)

})

  # simple test run with more iterations
test_that("RunStratModel works for 100 iterations", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 100,
                      nChains = 3, visualise = FALSE, seed = 1)
  expect_s3_class(r1, "StratPosterior")
})

# test run with different MCMC options - 1
test_that("RunStratModel works with tempering = FALSE and adaptProposal = FALSE", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 50,
                      nChains = 2, tempering = FALSE,
                      adaptProposal = FALSE,
                      visualise = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

# test run with different MCMC options - 1
test_that("RunStratModel works with  adaptTemperatures = FALSE and
different adaptation window and interval", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 50,
                      nChains = 2, adaptTemperatures = FALSE,
                      startAdapting = 30, endAdapting = 40,
                      adaptProposalInterval = 3,
                      proposalProbabilityWeights = 1:8,
                      temperatures = c(1,100),
                      visualise = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

# test plotting every iteration in parallel
test_that("RunStratModel works frequent plotting in 8 parallel runs", {
  skip_on_ci()
  # Skip if running via R CMD check
  if (nzchar(Sys.getenv("R_CMD_CHECK"))) {
    skip("Skipping this test during R CMD check")
  }
  r1 <- RunStratModel(stratData0, stratModel = stratModel0,
                      nRun = 8, nIter = 100,
                      nChains = 1, adapt = FALSE,
                      visualise = c(1,1,1),
                      runParallel = TRUE)
  expect_s3_class(r1, "StratPosterior")
})


test_that("StratPosterior() can restore StratPosterior object and can resume
          run from directory", {
  r1a <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 2,
                       nChains = 3, visualise = FALSE, seed = 1:2,
                       runParallel = FALSE, startAdapting = 4,
                       endAdapting = 10, adaptTemperatures = FALSE,
                       modelDir = tempdir())

  r1b <- StratPosterior(r1a$modelDir, r1a$modelName, stratData0, stratModel0, NULL)
  # check that stratData and stratModel are read from dir
  r1c <- StratPosterior(r1a$modelDir, r1a$modelName)

  expect_equal(r1a, r1b, ignore_attr = TRUE)
  expect_equal(r1b, r1c, ignore_attr = TRUE)

  r1d <- RunStratModel(modelDir = r1a$modelDir, modelName = r1a$modelName, nIter = 3)

  expect_s3_class(r1d, "StratPosterior")

})

test_that("RunStratModel errors clearly when a StratPosterior's modelDir
          is gone (#837)", {
  r1a <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 1,
                       nIter = 2, nChains = 3, visualise = FALSE, seed = 1,
                       runParallel = FALSE, startAdapting = 4,
                       endAdapting = 10, adaptTemperatures = FALSE,
                       modelDir = tempdir())

  r1a$modelDir <- file.path(tempdir(), "does-not-exist-837")

  expect_error(
    RunStratModel(r1a, nIter = 2),
    "modelDir.*no longer exists"
  )
})

test_that(".CheckSeed() throws errors", {
  expect_error(.CheckSeed(1, 2), "seed must")
  expect_error(.CheckSeed(c(TRUE, FALSE), 1), "seed must")
  expect_error(.CheckSeed("a", 1), "seed must")
  expect_error(.CheckSeed("a", 1), "seed must")
  expect_error(.CheckSeed(NULL, 1), "seed must")
})


# ensure results are identical with identical seeds

test_that("RunStratModel behaves consistently with random seeds", {
  test1 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1,
                         visualise = FALSE)
  test2 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1,
                         visualise = FALSE)

  testthat::expect_equal(test1$samples[3, 1, 1, 1],
                         test2$samples[3, 1, 1, 1],
                         tolerance = 0.001)

  skip_if_not_installed("future.apply")
  test3 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1:2,
                         runParallel = TRUE, nRun = 2, visualise = FALSE)

  testthat::expect_equal(test1$samples[3, 1, 1, 1],
                         test3$samples[3, 1, 1, 1],
                         tolerance = 0.001)
})


# test 7 (using ties):
test_that("RunStratModel still works with legacy test data 7", {

dat7 <- StratData(
  signal = testthat::test_path("testdata", "test-7", "test-7-signal.csv"),
  ties = testthat::test_path("testdata", "test-7", "test-7-date-high-sd.csv"))

priors <- structure(list(
  `alpha_site 1` = NormalPrior(mean = 49.7, sd = 1),
  `alpha_site 2` = UniformPrior(min = -120, max = 120),
  `gammaLog_site 1` = NormalPrior(mean = 0, sd = 0.05),
  `gammaLog_site 2` = NormalPrior(mean = 0, sd = 1)
),
class = c("StratPrior", "list"))

set.seed(7)
skip_if_not_installed("future.apply")
test_7_result_1b <- RunStratModel(
  stratObject = dat7, alignmentScale = "age", sedModel = "site",
  # 100 iterations let the chains settle into a mode (T-262). Adaptation ends
  # at 50 and summary() burns in half, so nThin sets how many draws the
  # mode-recovery check below is scored on: nThin = 25 left 2 per run, too
  # few for clustering to keep the two modes apart. Thinning is output-only,
  # so nThin = 5 adds draws without moving the chain.
  nChains = 8, nIter = 100, nThin = 5, convergenceStop = FALSE,
  nKnots = 15, priors = priors, nRun = 2, runParallel = TRUE,
  nCores = 2L, nThreads = 1L,
  seed = 1:2, sigmaFixed = TRUE, visualise = interactive() * 50,
  quiet = FALSE, flexibleKnots = TRUE
)

estimates <- summary(test_7_result_1b)

nAln <- estimates[[c("general", "overallAlignments")]]
correctAlignment1 <-
  abs(vapply(
    seq_len(nAln),
    function(a) estimates[[a]][["summary"]]["alpha_site 2", "mean"],
    numeric(1)
  ) - 83) < 8

correctAlignment2 <-
  abs(vapply(
    seq_len(nAln),
    function(a) estimates[[a]][["summary"]]["alpha_site 2", "mean"],
    numeric(1)
  ) - 35) < 8


# at least one correct alignment:
expect_gte(sum(correctAlignment1,correctAlignment2), 1)
})

test_that(".RemoveResidualPlotFiles works", {
  testDir <- tempfile("testDir")
  dir.create(testDir)
  on.exit(unlink(testDir))
  modelName <- "testModel"
  path1 <- file.path(testDir, paste0(modelName,"_plot_samples_run_2.rds"))
  path2 <- file.path(testDir, paste0(modelName, "_plot_run_2_sig_2.png"))
  path3 <- file.path(testDir, paste0(modelName, "_plot_run_1_sig_1.png"))
  path4 <- file.path(testDir, paste0(modelName, "_plot_parameter_posterior.png"))
  path5 <- file.path(testDir, paste0(modelName, "_plot_parameter_alpha_site1.png"))
  path6 <- file.path(testDir, paste0(modelName, "_plot_run_1_sig_1_task_1_temp.png")) # RT-308: orphaned temp file
  saveRDS(1, file = path1)
  png(path2)
  plot.new()
  dev.off()
  png(path3)
  plot.new()
  dev.off()
  png(path4)
  plot.new()
  dev.off()
  png(path5)
  plot.new()
  dev.off()
  png(path6)
  plot.new()
  dev.off()
  Sys.sleep(0.025) # delay to allow finishing file writing
  expect_true(file.exists(path1))
  expect_true(file.exists(path2))
  expect_true(file.exists(path3))
  expect_true(file.exists(path4))
  expect_true(file.exists(path5))
  expect_true(file.exists(path6))

  parametersToPlot <- c("posterior", "alpha_site1")
  # remove potential residual plot files from previous run (on.exit deletion
  # doesn't always work on Mac):
  StratoBayes:::.RemoveResidualPlotFiles(saveVisualiseDir = testDir, modelDir = testDir,
                                         modelName = modelName, nRun = 2,
                                         sigIndices = 1:2, parameters =
                                           parametersToPlot)

  expect_true(all(c(file.exists(path1), file.exists(path2), file.exists(path3),
                    file.exists(path4), file.exists(path5), file.exists(path6)) == FALSE))

})


# ── Fix-3 regression: C++ engine bulk history during adaptation ──────────────
#
# Root cause: with engine="cpp", batches span full adaptProposalInterval.
# After each batch only one state was saved to chainHistory via sb_extract_metro.
# Over ~20 intervals, UpdateProposal saw ≤20 sparse samples spanning the
# adaptation trajectory — covariance was inflated 10–100× relative to the
# posterior, causing near-zero cold-chain MVN acceptance after hard-freeze.
#
# Fix (RunStratModel.R T-156 block): extract accumulated C++ per-iteration
# snapshots (sb_extract_history) at EVERY adaptation checkpoint, not just
# post-adaptation, so UpdateProposal receives ~adaptProposalInterval samples
# per interval instead of 1.
#
# Test 1 (structural): historySize for the cold chain should be close to
# historyLength (buffer full) after adaptation — many more than the ~20
# sparse checkpoint saves the buggy code produced.
#
# Test 2 (structural, in-adaptation snapshot): historySize measured the
# instant adaptation ends (endAdapting == nIter, so no post-adaptation flush
# can backfill the buffer) should be much denser than the ~n_intervals sparse
# checkpoint saves the buggy code produces.
#
# Test 2 used to assert cold-chain Multivariate proposal acceptance > 0.05
# post-adaptation. That functional check was removed (see PR replacing this
# comment): a full RunStratModel run's proposal mix is re-weighted between
# adaptation checkpoints from measured wall-clock cost (.UpdateProposalProbAndFac's
# "cost-aware weighting"), so which iterations draw an MVN proposal — and hence
# the whole downstream accept/reject RNG path — depends on machine timing, not
# just the seed. Empirically (stratData1, nIter=1200, onlyMultivariateProposalsAfterAdapt
# = TRUE to maximise the MVN sample count, cold chain, C++ engine, 30 seeds):
# with the bug reintroduced, cold-chain MVN acceptance ranged 0.00-0.93; with
# the fix in place, healthy runs also ranged 0.00-0.93 — total overlap, no
# threshold discriminates. Worse, re-running the *same* seed against the *same*
# build repeatedly gave different values each time (e.g. seed 1, bug
# reintroduced: 0.20, 0.10, 0.11 across three invocations) — the statistic
# isn't even reproducible for a fixed seed, so no amount of seed-averaging
# (fast-suite or heavy-test) can stabilise it either. Test 2 below replaces it
# with a mechanism-level count (dense vs. sparse history), which is
# iteration-count-driven rather than RNG/timing-driven and empirically
# reproducible.

test_that("Fix-3: C++ engine populates dense chain history during adaptation", {
  skip_on_cran()
  skip_if_not_installed("pkgbuild")

  set.seed(7)
  sm <- StratModel(stratData1, stratPrior1,
                   alignmentScale = "height", sedModel = "site",
                   alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE)
  mc <- StratMCMC(sm, nIter = 800L, nChains = 4L, nThreads = 2L,
                  saveMCMC = TRUE)

  post <- suppressMessages(
    RunStratModel(stratData1, stratModel = sm, stratMCMC = mc,
                  engine = "cpp", nRun = 1L,
                  visualise = FALSE, quiet = TRUE, seed = 7L)
  )

  mcmc1  <- post[["mcmc"]][[1L]]
  hSize  <- mcmc1[[c("metro", "historySize")]][1L]   # cold chain
  hLen   <- mcmc1[[c("metro", "historyLength")]]
  endAdp <- mcmc1[["endAdapting"]]
  intv   <- mcmc1[[c("metro", "adaptProposalInterval")]]
  nIntervals <- ceiling(endAdp / intv)

  # Structural: history must be much richer than n_intervals (without fix ~20)
  # and should be at or near historyLength (with fix, buffer fills from bulk flush).
  expect_gte(hSize, min(hLen, nIntervals * 5L),
             label = paste0(
               "cold chain historySize=", hSize,
               " should be >> n_intervals=", nIntervals,
               " (fix: bulk history flushed at adaptation checkpoints)"))
})

test_that("Fix-3: cold chain history is dense at the in-adaptation checkpoint (C++ engine, stratData1)", {
  skip_on_cran()
  skip_if_not_installed("pkgbuild")

  set.seed(7)
  sm <- StratModel(stratData1, stratPrior1,
                   alignmentScale = "height", sedModel = "site",
                   alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE)
  # The config is chosen so that the buggy regime has a *computable* ceiling
  # rather than an empirically calibrated range (see the threshold note below):
  #
  # endAdapting == nIter        the run stops the instant adaptation ends, so no
  #                             post-adaptation bulk-history flush can backfill
  #                             the buffer and mask what happened *during*
  #                             adaptation (Test 1 above measures historySize
  #                             after a further post-adapt window, which the
  #                             fixed and buggy code both fill in equally — it
  #                             does not discriminate this bug on its own).
  # adaptTemperatures = FALSE   temperature-adaptation iterations are external
  # writeMCMCfile = FALSE       checkpoints, as are the file-write iterations;
  #                             both add in-adaptation checkpoints, and each
  #                             checkpoint hands the buggy code another history
  #                             row.  Disabling them leaves the
  #                             adaptProposalInterval checkpoints as the only
  #                             ones, which is what makes the ceiling below
  #                             computable.  Neither affects the flush itself.
  # adaptProposalInterval = 40  20 adaptation checkpoints over 800 iterations:
  #                             frequent enough that the proposal still adapts
  #                             (a larger interval starves adaptation and
  #                             collapses the *fixed* regime's density too),
  #                             few enough to keep the ceiling far below
  #                             historyLength.
  # adaptProposalWindow = 100   historyLength; the fixed regime fills it or
  #                             comes close (90-100 measured), so its density is
  #                             capped and cannot drift upward indefinitely.
  mc <- StratMCMC(sm, nIter = 800L, nChains = 4L, nThreads = 1L,
                  saveMCMC = TRUE, endAdapting = 800L,
                  adaptTemperatures = FALSE, writeMCMCfile = FALSE,
                  adaptProposalWindow = 100L, adaptProposalInterval = 40L)

  # convergenceStop = FALSE: this test is about the chain-history buffer, not
  # convergence stopping, and `writeMCMCfile = FALSE` above (chosen for the
  # reason explained there) would otherwise trigger #1484's new "convergenceStop
  # has no effect" warning.
  post <- suppressMessages(
    RunStratModel(stratData1, stratModel = sm, stratMCMC = mc,
                  engine = "cpp", nRun = 1L,
                  visualise = FALSE, quiet = TRUE, seed = 7L,
                  convergenceStop = FALSE)
  )

  mcmc1  <- post[["mcmc"]][[1L]]
  hSize  <- mcmc1[[c("metro", "historySize")]][1L]   # cold chain
  hLen   <- mcmc1[[c("metro", "historyLength")]]
  endAdp <- mcmc1[["endAdapting"]]
  intv   <- mcmc1[[c("metro", "adaptProposalInterval")]]
  nIntervals <- ceiling(endAdp / intv)

  # ── Why the threshold is 2.5 * nIntervals ────────────────────────────────
  #
  # The threshold is anchored to a STRUCTURAL CEILING on the buggy regime, not
  # to a platform-calibrated floor on the fixed one.  With the bulk-history
  # flush disabled during adaptation (the pre-Fix-3 bug, commit 59e63c0b), the
  # only writer of chainHistory is the per-checkpoint .SaveMCMChistory call,
  # and that raises historySize by AT MOST ONE per call
  # (R/mcmcFunctions.R — one candidate state, added only if not a duplicate).
  # So under the bug
  #
  #     historySize <= (number of in-adaptation checkpoints)
  #
  # and with temperature adaptation and file writes disabled the only
  # in-adaptation checkpoints left are the adaptProposalInterval ones (each
  # visited at i and again at i + 1).  That count is fixed by the checkpoint
  # schedule alone — pure arithmetic over startAdapting / endAdapting /
  # adaptProposalInterval, with no RNG and no acceptance rate in it — so it does
  # not move across platforms.  For this config it is 40, measured on both
  # x86_64 and aarch64.  A threshold above 40 therefore CANNOT be reached by the
  # buggy code on any platform.
  #
  # 40 happens to equal 2 * nIntervals here, but do NOT read that as a formula:
  # it depends on where startAdapting falls relative to the interval grid
  # (nIter = 1200 / interval = 60 gives 42 against a 2 * nIntervals of 40).
  # Hence the threshold is set with headroom above the measured count rather
  # than exactly on it — it survives the count landing a few higher.
  #
  # Measured, cold chain, this exact config, with the flush disabled and then
  # enabled.  x86_64: seeds 1-12 x nThreads in {1, 2} (n = 24).  aarch64: seeds
  # 1-8 at nThreads = 1 plus seeds 1-3 at nThreads = 2 (n = 11), from a
  # dispatched ubuntu-24.04-arm / R-devel leg.
  #
  #   regime                     x86_64-w64-mingw32   aarch64-unknown-linux-gnu
  #   pre-Fix-3 bug                    21-26                    17-26
  #   Fix-3 present                    90-100                   97-100
  #   in-adaptation checkpoints        40                       40
  #   threshold                        50 (= 2.5 * nIntervals), both platforms
  #
  # So the threshold clears the worst observed buggy value by ~1.9x and sits
  # ~1.8x below the worst observed fixed value, on both platforms — and the
  # checkpoint count came out identical on the two, as the schedule-arithmetic
  # argument above predicts.
  #
  # The previous form of this test used ceiling(1.9 * nIntervals) against a
  # config whose in-adaptation checkpoint count was 59 = 2.7 * nIntervals —
  # i.e. the threshold sat BELOW the buggy regime's ceiling, so it was unsound
  # in both directions: it could fail with the fix present (it did, on
  # aarch64: 40 against a threshold of 42) and it could pass with the bug
  # present on a higher-acceptance platform.
  threshold <- ceiling(nIntervals * 2.5)
  expect_gt(hSize, threshold,
            label = paste0(
              "cold chain historySize=", hSize, " (historyLength=", hLen,
              ", n_intervals=", nIntervals, ", threshold=", threshold, ") ",
              "should be dense (bulk history flushed at every in-adaptation ",
              "checkpoint); the sparse-history bug writes at most one row per ",
              "in-adaptation checkpoint, of which this config has 40, so it ",
              "cannot clear this threshold on any platform"))
})
