# #1933: a non-finite overlap penalty folds onto the -1e30 sentinel instead of
#   NaN, which sum(na.rm = TRUE) and sum_narm() drop from the log-posterior.
# #1934: the HMC/NUTS gradient path rejects a -Inf signal log-likelihood rather
#   than dropping it from the Hamiltonian.
# #1935: .sb_create_engine checks overlapPenalty$weights against the signals.

OverlapLogPost <- function(overlap, adjustments, weights = NULL) {
  StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0),
    priorArgs = list(), rCustomFns = list(),
    B_list = list(matrix(1, nrow = 3L, ncol = 2L)),
    beta_list = list(c(0, 0)), signalValues = list(c(1, 2, 3)),
    sigma = 1, overlapPenalty = TRUE,
    signalSectionOverlap = list(overlap), adjustments = list(adjustments),
    overlapWeights = weights
  )[[3]]
}

test_that(".sb_logpost folds a non-finite overlap penalty (#1933)", {
  # -Inf + Inf: NaN before the fold.
  expect_identical(OverlapLogPost(c(1L, 2L, 1L), c(-Inf, Inf)), -1e30)
  expect_identical(OverlapLogPost(c(2L, 2L, 2L), c(0, Inf)), -1e30)
  expect_identical(OverlapLogPost(c(1L, 1L, 1L), c(-Inf, 0)), -1e30)
  expect_equal(OverlapLogPost(c(1L, 2L, 1L), c(0.5, 1)), 2)
  # A zero taper weight carries no penalty, not 0 * -Inf = NaN.
  expect_identical(
    OverlapLogPost(c(1L, 2L, 2L), c(-Inf, 0.5), list(c(0, 1, 1))), 1)
})

setupCache <- new.env()
OverlapEngineSetup <- function() {
  if (!is.null(setupCache$s)) return(setupCache$s)
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  sModel <- StratoBayes::StratModel(
    stratData      = stratData1,
    priors         = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel       = stratModel1$sedModel,
    flexibleKnots  = FALSE,
    knotRange      = c(-5, 12),
    overlapPenalty = TRUE
  )
  td <- tempfile("overlap_nonfinite_")
  dir.create(td)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "ov", engine = "R"
  )
  mcmc <- readRDS(file.path(td, "ov_mcmc_run_1.rds"))
  unlink(td, recursive = TRUE)
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  setupCache$s <- list(data = result$data, model = model, mcmc = mcmc,
                       state = mcmc$recentState)
  setupCache$s
}

NewEngine <- function(s) {
  StratoBayes:::.sb_create_engine(data = s$data, model = s$model,
                                  mcmc = s$mcmc, state = s$state)
}

test_that("engine overlap penalty folds non-finite values (#1933)", {
  skip_on_cran()
  s <- OverlapEngineSetup()
  params <- s$state[[1]]$metro$parameters
  # Count 1 scores -Inf and every higher count +Inf: whichever counts the state
  # holds, the unfolded sum is -Inf, +Inf or NaN -- never finite.
  s$model$overlapPenalty$adjustments <- lapply(
    s$model$overlapPenalty$adjustments,
    function(a) c(-Inf, rep(Inf, length(a) - 1L)))
  out <- StratoBayes:::.sb_eval_logpost(NewEngine(s), 1L, params, debug = TRUE)
  expect_identical(out$logPostSep[[4]], -1e30)
})

test_that("HMC gradient path rejects a -Inf signal log-likelihood (#1934)", {
  skip_on_cran()
  s <- OverlapEngineSetup()
  params <- s$state[[1]]$metro$parameters
  # Residuals near 1e200 square to Inf at a finite sigma: a clean -Inf.
  s$state[[1]]$gibbs$beta <- lapply(s$state[[1]]$gibbs$beta,
                                    function(b) b * 0 + 1e200)
  hmc <- StratoBayes:::.sb_hmc_eval_logpost(NewEngine(s), 1L, params)
  expect_true(isTRUE(hmc$ok))
  expect_identical(hmc$logPostSep[[2]], -Inf)
  expect_identical(hmc$logPost, -1e30)
})

test_that(".sb_create_engine checks overlapPenalty weights (#1935)", {
  skip_on_cran()
  s <- OverlapEngineSetup()
  nObs <- lengths(s$data$signalAttr$signalValuesVec)
  WithWeights <- function(w) {
    s$model$overlapPenalty$weights <- w
    NewEngine(s)
  }
  sAdj <- s
  sAdj$model$overlapPenalty$adjustments <- list()
  expect_error(NewEngine(sAdj), "adjustments must have one element per signal")
  sAdj$model$overlapPenalty$adjustments <- lapply(
    s$model$overlapPenalty$adjustments, as.character)
  expect_error(NewEngine(sAdj), "adjustments\\[\\[1\\]\\] must be numeric")
  expect_error(WithWeights(rep(1, sum(nObs))), "must be a list")
  expect_error(WithWeights(lapply(c(nObs, 1L), function(n) rep(1, n))),
               "one element per signal")
  expect_error(WithWeights(lapply(nObs, function(n) rep(1, n - 1L))),
               "weights\\[\\[1\\]\\] has length")
  expect_error(WithWeights(lapply(nObs, function(n) rep("1", n))),
               "must be numeric")
  # Empty is unweighted, as .sb_logpost reads it.
  expect_identical(typeof(WithWeights(list())), "externalptr")
  expect_identical(typeof(WithWeights(lapply(nObs, function(n) rep(1, n)))),
                   "externalptr")
})
