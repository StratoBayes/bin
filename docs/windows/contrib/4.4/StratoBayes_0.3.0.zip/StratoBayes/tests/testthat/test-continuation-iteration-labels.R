# A continued run resumes from the checkpoint's `recentState`, which is the
# sampler state after the checkpoint's `completedIter`. Its first iteration must
# therefore be `completedIter + 1`, even when `completedIter` is not a save
# iteration; restarting from the last saved row relabels up to `nThin - 1`
# iterations and shifts every later save off the original grid.

.UninterruptedGrid <- function(endIter, nThin) {
  unique(c(1, seq(nThin, endIter, by = nThin)))
}

.ExpectSegment <- function(dir, name, posterior, startIter, endIter, nThin) {
  grid <- .UninterruptedGrid(endIter, nThin)
  mcmc <- readRDS(file.path(dir, paste0(name, "_mcmc_run_1.rds")))
  expect_equal(mcmc[["startIter"]], startIter)
  expect_equal(mcmc[["endIter"]], endIter)
  expect_equal(mcmc[["completedIter"]], endIter)
  expect_equal(mcmc[["saveIter"]], grid)

  onDisk <- .CompileSamplesAfterMCMC(dir, name, posterior[["model"]],
                                     saveChainsList = list(mcmc[["saveChains"]]))
  expect_equal(as.numeric(dimnames(onDisk)[[1]]), grid)

  expect_equal(unname(posterior[[c("mcmcSummary", "startIter")]]), startIter)
  expect_equal(unname(posterior[[c("mcmcSummary", "endIter")]]), endIter)
  expect_equal(posterior[[c("mcmcSummary", "saveIter")]][[1]], grid)
  expect_equal(dim(posterior[["samples"]])[1], length(grid))
}

for (engine in c("cpp", "R")) {
  test_that(paste0("continuing an off-grid run keeps its iteration labels (", engine, " engine)"), {
    skip_on_cran()
    data(stratData1, package = "StratoBayes")
    data(stratModel1, package = "StratoBayes")

    td <- file.path(tempdir(), paste0("continue_labels_", engine))
    unlink(td, recursive = TRUE)
    dir.create(td, recursive = TRUE)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)
    name <- paste0("labels", engine)
    nThin <- 5

    r1 <- RunStratModel(stratData1, stratModel1, nIter = 23, nThin = nThin,
                        nChains = 2L, nThreads = 1L, seed = 1, quiet = TRUE,
                        visualise = FALSE, runParallel = FALSE, modelDir = td,
                        modelName = name, engine = engine)
    .ExpectSegment(td, name, r1, 1, 23, nThin)
    if (engine == "cpp") {
      expect_true(file.exists(
        file.path(td, paste0(name, "_binarysamples_run_1.rds"))))
    }

    # From the in-memory posterior; on cpp its rows come from the binary RDS.
    r2 <- RunStratModel(r1, nIter = 9, nThreads = 1L, quiet = TRUE,
                        visualise = FALSE, runParallel = FALSE, engine = engine)
    .ExpectSegment(td, name, r2, 24, 32, nThin)
    expect_length(list.files(td, pattern = "_binarysamples_run_"), 0L)

    # From the directory; the rows now come from the TSV alone.
    r3 <- RunStratModel(NULL, nIter = 5, modelDir = td, modelName = name,
                        nThreads = 1L, quiet = TRUE, visualise = FALSE,
                        runParallel = FALSE, engine = engine)
    .ExpectSegment(td, name, r3, 33, 37, nThin)
  })
}

test_that("a continuation's saves stay on the uninterrupted run's grid", {
  data(stratModel1, package = "StratoBayes")
  prior <- StratMCMC(stratModel1, nIter = 100, nThin = 5, nThreads = 1L)

  # Only iteration 1 was saved before the checkpoint at 3.
  early <- StratMCMC(stratModel1, stratMCMC = prior, completedIter = 3,
                     nIter = 9, nThin = 5, nThreads = 1L)
  expect_equal(early[["startIter"]], 4)
  expect_equal(early[["saveIter"]], .UninterruptedGrid(12, 5))

  offGrid <- StratMCMC(stratModel1, stratMCMC = prior, completedIter = 23,
                       nIter = 9, nThin = 5, nThreads = 1L)
  expect_equal(offGrid[["startIter"]], 24)
  expect_equal(offGrid[["saveIter"]], .UninterruptedGrid(32, 5))
})

test_that(".ContinuationCompletedIter trusts the checkpoint only when the rows reach it", {
  saveIter <- c(1, 5, 10, 15, 20, 25)
  # Healthy off-grid checkpoint: rows end at the last save before it.
  expect_equal(.ContinuationCompletedIter(20, 23, saveIter), 23)
  expect_equal(.ContinuationCompletedIter(1, 3, saveIter), 3)
  # On the grid: both sources agree.
  expect_equal(.ContinuationCompletedIter(20, 20, saveIter), 20)
  # Legacy or unreadable checkpoint count: fall back to the rows.
  expect_equal(.ContinuationCompletedIter(20, NULL, saveIter), 20)
  expect_equal(.ContinuationCompletedIter(20, NA, saveIter), 20)
  # Rows stop short of the checkpoint's last save (non-finite rows, or samples
  # lagging the checkpoint): the rows are the conservative answer.
  expect_equal(.ContinuationCompletedIter(15, 23, saveIter), 15)
  # Rows run ahead of the checkpoint: never relabel already-written rows.
  expect_equal(.ContinuationCompletedIter(25, 23, saveIter), 25)
  # No complete rows.
  expect_equal(.ContinuationCompletedIter(0, 23, saveIter), 0)
})

test_that("a continuation whose samples lag its checkpoint restarts after the last saved row", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "continue_labels_lagging")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  name <- "labelslagging"

  RunStratModel(stratData1, stratModel1, nIter = 23, nThin = 5, nChains = 2L,
                nThreads = 1L, seed = 1, quiet = TRUE, visualise = FALSE,
                runParallel = FALSE, modelDir = td, modelName = name,
                engine = "R")
  samplesPath <- file.path(td, paste0(name, "_samples_run_1.txt"))
  samples <- readLines(samplesPath)
  iteration <- suppressWarnings(as.numeric(sub("\t.*", "", samples)))
  writeLines(samples[is.na(iteration) | iteration <= 15], samplesPath)

  RunStratModel(NULL, nIter = 4, modelDir = td, modelName = name,
                nThreads = 1L, quiet = TRUE, visualise = FALSE,
                runParallel = FALSE, engine = "R")
  mcmc <- readRDS(file.path(td, paste0(name, "_mcmc_run_1.rds")))
  expect_equal(mcmc[["startIter"]], 16)
  expect_equal(mcmc[["endIter"]], 19)
})

test_that("the GUI's RunStratModelShiny() continues on the same labels", {
  skip_on_cran()
  guiFile <- system.file("gui", "R", "RunStratModelShiny.R",
                         package = "StratoBayes")
  skip_if(guiFile == "", "GUI sources not available")
  gui <- new.env(parent = asNamespace("StratoBayes"))
  sys.source(guiFile, envir = gui)

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  td <- file.path(tempdir(), "continue_labels_gui")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  name <- "labelsgui"

  r1 <- RunStratModel(stratData1, stratModel1, nIter = 23, nThin = 5,
                      nChains = 2L, nThreads = 1L, seed = 1, quiet = TRUE,
                      visualise = FALSE, runParallel = FALSE, modelDir = td,
                      modelName = name, engine = "R")

  # Without the TSV, the GUI rebuilds it from the posterior's own rows.
  unlink(file.path(td, paste0(name, "_samples_run_1.txt")))
  r2 <- gui$RunStratModelShiny(r1, nIter = 9, quiet = TRUE, visualise = FALSE,
                               runParallel = FALSE)
  .ExpectSegment(td, name, r2, 24, 32, 5)

  r3 <- gui$RunStratModelShiny(NULL, nIter = 5, modelDir = td,
                               modelName = name, quiet = TRUE,
                               visualise = FALSE, runParallel = FALSE)
  .ExpectSegment(td, name, r3, 33, 37, 5)
})
