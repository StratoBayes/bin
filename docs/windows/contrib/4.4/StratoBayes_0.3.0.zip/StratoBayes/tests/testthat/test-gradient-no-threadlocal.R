# `thread_local` in src/ is banned, and the ban has to be read off the source:
# the defect it guards against is a hard process death on Windows with no R-level
# error, which no ordinary test can catch and which macOS and Linux never
# reproduce. See the comment in Gradient_impl.h for the mechanism.

test_that("no src/ file declares a thread_local", {
  # tests/testthat/../../src -- the package source tree, present both under
  # devtools::test()/R CMD check and in an installed package's build sources.
  src_dir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(src_dir), "src/ not found (not running against a source tree)")
  src_files <- list.files(src_dir, pattern = "[.](cpp|h)$", full.names = TRUE)
  expect_true(length(src_files) > 0)

  violations <- character(0)
  for (f in src_files) {
    lines <- readLines(f, warn = FALSE)
    # Strip // comments so this file's own explanation, and the one in
    # Gradient_impl.h, cannot trip the scan.
    code <- sub("//.*$", "", lines)
    hits <- grep("\\bthread_local\\b", code)
    if (length(hits)) {
      violations <- c(violations, sprintf("%s:%d", basename(f), hits))
    }
  }

  expect_equal(
    violations, character(0),
    info = paste0(
      "thread_local found in src/. It crashed the Windows suite once already ",
      "(bisected: CI runs 35425808036 red / 35439581181 green on three such ",
      "lines). Reuse a buffer by hanging it off per-chain engine state instead."
    )
  )
})
