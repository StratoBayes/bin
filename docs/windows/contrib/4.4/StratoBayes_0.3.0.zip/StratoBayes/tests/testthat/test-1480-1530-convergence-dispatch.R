# Area-2 tranche: convergence-stopping gaps (#1484, #1530) plus four small
# parallel-dispatch/continuation defects found alongside them (#1485, #1481,
# #1482, #1480). #1482 is a pure hoist/dead-code hygiene fix with no
# behavioural change, so it has no dedicated regression test here -- the
# existing continuation suites (test-mcmc-history-parity.R,
# test-rt-lows-resume-continuation.R) already cover the loop it touches.

# ── #1484: convergenceStop is silently inert when writeMCMCfile = 0/FALSE ───

test_that("#1484: convergenceStop warns rather than silently doing nothing when writeMCMCfile = 0", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  expect_warning(
    RunStratModel(stratData1, stratModel1, nIter = 20, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "wm0", visualise = FALSE,
                  convergenceStop = TRUE, writeMCMCfile = 0),
    "convergenceStop.*no effect"
  )
})

test_that("#1484: the same call with writeMCMCfile = FALSE also warns", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  expect_warning(
    RunStratModel(stratData1, stratModel1, nIter = 20, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "wmF", visualise = FALSE,
                  convergenceStop = TRUE, writeMCMCfile = FALSE),
    "convergenceStop.*no effect"
  )
})

test_that("#1484: the default writeMCMCfile does not trigger the warning", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  expect_no_warning(
    RunStratModel(stratData1, stratModel1, nIter = 20, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "wmDefault", visualise = FALSE,
                  convergenceStop = TRUE)
  )
})

test_that("#1484: convergenceStop = FALSE with writeMCMCfile = 0 does not warn", {
  skip_on_cran()
  dir <- withr::local_tempdir()
  expect_no_warning(
    RunStratModel(stratData1, stratModel1, nIter = 20, nChains = 2, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "wmOff", visualise = FALSE,
                  convergenceStop = FALSE, writeMCMCfile = 0)
  )
})

# ── #1530: .ConvergenceMonitorCols() omits signalOffsets' delta_*/tau_* ─────

test_that("#1530: the monitored columns now include delta_*/tau_*", {
  cols <- c("iteration", "chain", "alpha_site2", "delta_groupA_d13C",
           "tau_d13C", "beta_d13C_1")
  idx <- .ConvergenceMonitorCols(cols, "alpha_site2", "d13C")

  expect_identical(cols[idx],
                   c("alpha_site2", "delta_groupA_d13C", "tau_d13C"))
  # betas remain excluded, as in summary()'s psrfPar (unchanged behaviour).
  expect_false("beta_d13C_1" %in% cols[idx])
})

test_that("#1530: a non-offset model's monitored columns are unaffected (no-op)", {
  # Mirrors test-convergence-store.R's fixture, with no delta_/tau_ columns
  # present -- the fix must not change selection when offsets are inactive.
  cols <- c("iteration", "chain", "alpha_site2", "gamma_site2",
           "sigma_d13C", "lambda_d13C", "posterior", "prior_parameters",
           "prior_overlap", "likelihood_spline", "likelihood_ties",
           "proposal_accepted", "proposal_number", "beta_d13C_1",
           "beta_d13C_2")
  idx <- .ConvergenceMonitorCols(cols, c("alpha_site2", "gamma_site2"), "d13C")

  expect_identical(cols[idx],
                   c("alpha_site2", "gamma_site2", "sigma_d13C", "lambda_d13C",
                     "posterior", "prior_parameters", "prior_overlap",
                     "likelihood_spline", "likelihood_ties"))
})

test_that("#1530: convergenceStop does not certify a run whose offsets haven't converged", {
  # A direct fixture against the real decision pipeline
  # (.ConvergenceMonitorCols -> .ConvergenceAppend -> .ConvergenceCheckpoint),
  # rather than a real signalOffsets = TRUE MCMC run: the offset parameters'
  # convergence is what is under test, not the sampler's ability to produce
  # it, and a hand-built series makes the non-convergence deterministic
  # instead of dependent on a short run's random draws.
  binaryColNames <- c("iteration", "chain", "alpha_site2",
                      "delta_groupA_d13C", "tau_d13C")
  parametersNames <- "alpha_site2"
  cols <- .ConvergenceMonitorCols(binaryColNames, parametersNames, "d13C")

  set.seed(42)
  n <- 400L
  iters <- seq_len(n)
  alpha <- rnorm(n)                                    # stationary: converges
  delta <- seq(0, 50, length.out = n) + rnorm(n, sd = 0.1)  # drifts: never does
  tauv  <- rnorm(n, mean = 5, sd = 0.5)

  mat <- cbind(iteration = iters, chain = 1, alpha_site2 = alpha,
              delta_groupA_d13C = delta, tau_d13C = tauv)

  criteria <- list(rHat = 1.02, ess = 5)
  dir <- withr::local_tempdir()

  store <- .ConvergenceAppend(.ConvergenceStore(), mat, cols = cols,
                              floorIter = 0)
  # Two consecutive checkpoints are needed to declare convergence
  # (.kConvergenceStreak); run enough to reach that if it were ever going to.
  for (k in 1:3) {
    store <- .ConvergenceCheckpoint(store, criteria, dir, "off", run = 1,
                                    nRun = 1, endAdapting = 0,
                                    crossRun = FALSE, useSentinel = FALSE)
  }

  expect_false(isTRUE(store[["met"]]))

  # Confirm the fixture is otherwise capable of stopping: the pre-fix column
  # selection (offsets excluded) sees only the converged alpha column and
  # wrongly certifies convergence -- this is the bug #1530 fixes.
  colsOffsetsExcluded <- which(binaryColNames %in% parametersNames)
  storeOld <- .ConvergenceAppend(.ConvergenceStore(), mat,
                                 cols = colsOffsetsExcluded, floorIter = 0)
  for (k in 1:3) {
    storeOld <- .ConvergenceCheckpoint(storeOld, criteria, dir, "offOld",
                                       run = 1, nRun = 1, endAdapting = 0,
                                       crossRun = FALSE, useSentinel = FALSE)
  }
  expect_true(isTRUE(storeOld[["met"]]))
})

# ── #1485.1: an explicit nCores is clamped to nRun, like the auto-path ──────

test_that("#1485: an explicit nCores oversized for nRun is clamped before dispatch", {
  skip_if_not_installed("future.apply")
  # The clamped value is only observable indirectly, via the oversubscription
  # warning's own reported nCores (RunStratModel.R does not return nCores to
  # the caller). detectCores() mocked to 1 so any nCores >= 2 oversubscribes,
  # letting the warning text distinguish "2 parallel run(s)" (clamped, post-
  # fix) from "8 parallel run(s)" (raw, pre-fix).
  testthat::local_mocked_bindings(
    detectCores = function(...) 1L, .package = "parallel"
  )
  dir <- withr::local_tempdir()

  w <- tryCatch({
    RunStratModel(stratData1, stratModel1, nRun = 2, nIter = 2, nChains = 1,
                  nThreads = 1L, visualise = FALSE, seed = 1:2, quiet = TRUE,
                  modelDir = dir, modelName = "clamp",
                  runParallel = TRUE, nCores = 8L)
    NULL
  }, warning = function(w) w)

  expect_false(is.null(w))
  expect_match(conditionMessage(w), "2 parallel run\\(s\\)")
  expect_false(grepl("8 parallel run(s)", conditionMessage(w), fixed = TRUE))
})

# ── #1481: acceptance-ring transfer must not be gated on chainHistory ──────

test_that("#1481: the acceptance ring transfers on continuation even without chainHistory", {
  # A legacy/hand-built checkpoint: acceptance/acceptanceIndex populated,
  # chainHistory entirely absent. Content is asserted directly (not merely
  # that continuation completes), per the campaign's vacuous-oracle rule.
  oldLen <- 5L
  newLen <- 5L
  nextWrite <- 3L
  oldAcc <- array(as.numeric(seq_len(oldLen)), dim = c(1L, oldLen, 1L))

  mcmc <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      acceptanceLength = oldLen,
      acceptance = oldAcc,
      acceptanceIndex = matrix(nextWrite, nrow = 1L, ncol = 1L)
      # chainHistory deliberately absent.
    )
  )
  mcmcNew <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      adaptProposal = TRUE,
      acceptanceLength = newLen,
      acceptance = array(NA_real_, dim = c(1L, newLen, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    ),
    recentState = NULL
  )

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  # Equal-length grow/equal branch: verbatim copy, write pointer unchanged.
  expect_identical(out[["metro"]][["acceptance"]], oldAcc)
  expect_equal(out[["metro"]][["acceptanceIndex"]][1, 1], nextWrite)
})

# ── #1480: .SummariseProfiles()/.AggregateProfilingData() error messages ───

test_that("#1480: nRun = 0 gives an informative error, not aggregate()'s cryptic one", {
  dir <- withr::local_tempdir()
  err <- tryCatch(
    .SummariseProfiles(modelDir = dir, modelName = "empty", nRun = 0),
    error = function(e) e
  )
  expect_s3_class(err, "error")
  expect_match(conditionMessage(err), "at least one profiled run")
  expect_false(grepl("'Function' not found", conditionMessage(err), fixed = TRUE))
})

test_that("#1480: an unrecognised sortColumns entry names the offending column", {
  summaries <- list(
    list(by.self = data.frame(
      self.time = c(1, 2), self.pct = c(50, 50),
      total.time = c(1, 2), total.pct = c(50, 50),
      row.names = c("f1", "f2")
    ))
  )
  err <- tryCatch(
    .AggregateProfilingData(summaries, sortColumns = "not_a_column"),
    error = function(e) e
  )
  expect_s3_class(err, "error")
  expect_match(conditionMessage(err), "not_a_column")
  expect_false(grepl("invalid argument to unary operator",
                     conditionMessage(err), fixed = TRUE))
})
