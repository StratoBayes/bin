# Area 13 red-team round 11: eight findings in Tops()/Partitions()/StratMap()/
# TopsPlot()'s tie-age and boundary machinery.

## ---- #1457: stratCluster from a different StratPosterior ----------------

test_that("Tops() rejects a stratCluster built from a different StratPosterior", {
  data("stratPosterior1", package = "StratoBayes")
  data("stratPosterior3", package = "StratoBayes")
  foreignCluster <- Cluster(stratPosterior1)

  expect_error(
    Tops(stratPosterior3, refHeights = -1, alignment = 1,
         stratCluster = foreignCluster),
    "does not match `stratPosterior`"
  )
  # the matching posterior must still work
  expect_s3_class(
    Tops(stratPosterior1, refHeights = 1, alignment = 1,
         stratCluster = foreignCluster),
    "data.frame"
  )
})

test_that("StratMap() rejects a stratCluster built from a different StratPosterior", {
  data("stratPosterior1", package = "StratoBayes")
  data("stratPosterior3", package = "StratoBayes")
  foreignCluster <- Cluster(stratPosterior1)

  expect_error(
    StratMap(stratPosterior3, heights = 1, site = 2, alignment = 1,
             stratCluster = foreignCluster),
    "does not match `stratPosterior`"
  )
})

test_that("ExtractParameters() rejects a stratCluster built from a different StratPosterior", {
  data("stratPosterior1", package = "StratoBayes")
  data("stratPosterior3", package = "StratoBayes")
  foreignCluster <- Cluster(stratPosterior1)

  expect_error(
    ExtractParameters(stratPosterior3, alignment = 1,
                      stratCluster = foreignCluster),
    "does not match `stratPosterior`"
  )
})

test_that(".ValidateClusterStamp() discriminates on content, not just run count", {
  # Same nRun, different sample content -- isolates the *stamp* comparison
  # from the cheaper rowIndex-length hardening exercised by the tests above.
  data("stratPosterior1", package = "StratoBayes")
  cluster <- Cluster(stratPosterior1)

  modified <- stratPosterior1
  modified[["samples"]][1, 1, 1, 1] <- modified[["samples"]][1, 1, 1, 1] + 1

  expect_error(
    StratoBayes:::.ValidateClusterStamp(cluster, modified),
    "does not match `stratPosterior`"
  )
  expect_true(StratoBayes:::.ValidateClusterStamp(cluster, stratPosterior1))
  expect_true(StratoBayes:::.ValidateClusterStamp(NULL, stratPosterior1))

  # a stratCluster with no stamp (pre-fix object, or hand-built) cannot be
  # verified and must pass through unchanged, so old serialized objects and
  # the package's own shipped `stratCluster1`/`stratCluster2` fixtures are
  # not broken by this check
  legacy <- cluster
  legacy[["stamp"]] <- NULL
  expect_true(StratoBayes:::.ValidateClusterStamp(legacy, modified))
})

## ---- #1450: ExtractParameters() row-bound guard holes --------------------

test_that("ExtractParameters() rejects a negative selectRows index instead of complement-indexing", {
  data("stratPosterior1", package = "StratoBayes")
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = -1),
    "Row indices must be at least 1"
  )
})

test_that("ExtractParameters() rejects a zero selectRows index instead of silently dropping it", {
  data("stratPosterior1", package = "StratoBayes")
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = 0),
    "Row indices must be at least 1"
  )
})

test_that("ExtractParameters() gives a clear message for an NA selectRows index", {
  data("stratPosterior1", package = "StratoBayes")
  # pre-fix, `any(NA)` throws R's generic "missing value where TRUE/FALSE
  # needed" instead of naming the actual cause -- assert the real message,
  # which also rules out the generic one by being a distinct, non-matching
  # string
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = NA_integer_),
    "Row indices must be at least 1"
  )
})

## ---- #1456: distribute='height' + ties confines boundaries -------------

test_that("Partitions(distribute='height', ties=) extrapolates beyond the tie range", {
  signal <- data.frame(site = "a", height = seq(0, 100, length.out = 21))
  # affine map height->age: age = 20 - height/4 (age 10 at h=40, age 5 at h=60)
  ties <- data.frame(site = "a", height = c(40, 60), densityFun = "dnorm",
                     arg1 = c(10, 5), arg2 = c(0.001, 0.001))

  got <- Partitions(signal, nStrata = 4, distribute = "height", ties = ties)

  # equal age steps over the FULL section (extrapolating the tie relation),
  # not confined to [40, 60] -- matches the affine map's own equal-height
  # steps because the map is linear
  expect_equal(got[["height"]], c(25, 50, 75, 100))
})

test_that("Partitions(distribute='height', ties=) matches pre-fix output when ties span the section", {
  # control: extrapolation must never activate when every boundary is
  # interior to the tie range, so this must stay bit-identical to the old
  # (confined) behaviour
  signal <- data.frame(site = "a", height = seq(0, 100, length.out = 21))
  ties <- data.frame(site = "a", height = c(0, 100), densityFun = "dnorm",
                     arg1 = c(20, 0), arg2 = c(0.001, 0.001))

  got <- Partitions(signal, nStrata = 4, distribute = "height", ties = ties)
  wanted <- stats::approx(c(20, 0), c(0, 100),
                          xout = seq(20, 0, length.out = 5)[-1],
                          rule = 2)[["y"]]
  expect_equal(sort(got[["height"]]), sort(wanted))
})

test_that("Partitions(distribute='height', ties=) still errors when the section is entirely outside the tie range", {
  signal <- data.frame(site = "a", height = seq(200, 300, length.out = 11))
  ties <- data.frame(site = "a", height = c(40, 60), densityFun = "dnorm",
                     arg1 = c(10, 5), arg2 = c(0.001, 0.001))
  expect_error(
    Partitions(signal, nStrata = 4, distribute = "height", ties = ties),
    "entirely outside the tie height range"
  )
})

## ---- #1451: non-monotone tie ages ----------------------------------------

test_that("Partitions(distribute='height', ties=) errors on non-monotone tie ages", {
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  # age reversal: age goes 0 -> 20 -> 10 as height increases 0 -> 5 -> 10
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dnorm",
                     arg1 = c(0, 20, 10), arg2 = rep(0.01, 3))

  expect_error(
    Partitions(signal, nStrata = 3, distribute = "height", ties = ties),
    "not monotone in height"
  )
})

test_that("Partitions(distribute='height', ties=) accepts monotone tie ages", {
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dnorm",
                     arg1 = c(20, 10, 0), arg2 = rep(0.01, 3))
  expect_no_error(
    Partitions(signal, nStrata = 3, distribute = "height", ties = ties)
  )
})

## ---- #1452: .TieCentralAges() surplus positional arg ---------------------

test_that(".TieCentralAges() ignores a surplus non-NA arg on a lower-arity density", {
  # dt's only required arg is `df`; a non-NA arg2 would otherwise forward
  # positionally into `ncp`, shifting the central age off qt(0.5, df) == 0
  ties <- data.frame(site = "a", height = 0, densityFun = "dt",
                     arg1 = 5, arg2 = 2.11)

  expect_warning(
    got <- StratoBayes:::.TieCentralAges(ties),
    "ignoring the surplus"
  )
  expect_equal(got, qt(0.5, 5))
  expect_false(isTRUE(all.equal(got, 2.11)))
})

test_that(".TieCentralAges() leaves a fully-specified dt tie unwarned", {
  ties <- data.frame(site = "a", height = 0, densityFun = "dt",
                     arg1 = 5, arg2 = NA_real_)
  expect_no_warning(got <- StratoBayes:::.TieCentralAges(ties))
  expect_equal(got, qt(0.5, 5))
})

test_that(".TieCentralAges() does not warn on dbeta's explicitly-allowed arg3 = 0", {
  # `.CheckTies()` already permits a trailing `arg3 = 0` on `dbeta` (a no-op
  # ncp); the surplus-arg warning must not fire on this already-sanctioned,
  # value-preserving pattern, or every ordinary `dbeta` tie using it would
  # warn for no reason.
  ties <- data.frame(site = "a", height = 0, densityFun = "dbeta",
                     arg1 = 2, arg2 = 5, arg3 = 0)
  expect_no_warning(got <- StratoBayes:::.TieCentralAges(ties))
  expect_equal(got, qbeta(0.5, 2, 5))
})

test_that("Partitions() boundaries discriminate a dropped dt surplus arg (integration)", {
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  # monotone both pre- and post-fix: dnorm(10) at h=0, dt(df=5, surplus
  # arg2=2.11) at h=5, dnorm(-10) at h=10
  ties <- data.frame(site = "a", height = c(0, 5, 10),
                     densityFun = c("dnorm", "dt", "dnorm"),
                     arg1 = c(10, 5, -10), arg2 = c(0.01, 2.11, 0.01))

  got <- suppressWarnings(
    Partitions(signal, nStrata = 3, distribute = "height", ties = ties))
  tieAges <- c(10, qt(0.5, 5), -10)
  wanted <- stats::approx(tieAges, c(0, 5, 10),
                          xout = seq(tieAges[1], tieAges[3], length.out = 4)[-1],
                          rule = 2)[["y"]]
  expect_equal(sort(got[["height"]]), sort(wanted))
})

## ---- #1453: nStrata guards count NA heights -------------------------------

test_that("Partitions(distribute='height') rejects an oversized nStrata for a mostly-NA site", {
  signal <- data.frame(site = "a", height = c(1, 2, rep(NA_real_, 98)))
  expect_error(
    Partitions(signal, nStrata = 50, distribute = "height"),
    "must be less than the number of points at site 'a' \\(2\\)"
  )
})

test_that("Partitions(distribute='points') rejects an oversized nStrata for a mostly-NA site", {
  signal <- data.frame(site = "a", height = c(1, 2, rep(NA_real_, 98)))
  expect_error(
    Partitions(signal, nStrata = 50, distribute = "points"),
    "must be less than the number of points at site 'a' \\(2\\)"
  )
})

## ---- #1454: Tops() vs TopsPlot() on a non-finite partition bound ---------

test_that("Tops() tolerates a non-finite partition bound like TopsPlot() does", {
  # stratPosterior1's site 1 has only one partition boundary, so its `bounds`
  # vector never exceeds length 2 and always falls into the *other* default
  # branch regardless of this fix; stratPosterior3's site 1 has four, which
  # actually exercises the `length(bounds) > 2` branch this issue is about.
  data("stratPosterior3", package = "StratoBayes")
  spInf <- stratPosterior3
  spInf[["data"]][["partsAttr"]][["Bound"]][1, 1] <- Inf

  expect_no_error(res <- Tops(spInf, alignment = 1))
  expect_s3_class(res, "data.frame")
  expect_true(all(is.finite(res[["refHeight"]])))

  # TopsPlot() must still behave the same way it always did (control)
  expect_no_error(TopsPlot(spInf, alignment = 1, display = FALSE))
})

## ---- #1455: TopsPlot() medianIdx vs refQMedianIdx ------------------------

test_that(".QuantileMedianIdx() finds the true median, not the positional middle", {
  expect_equal(StratoBayes:::.QuantileMedianIdx(c(0.1, 0.2, 0.5, 0.9)), 3)
  expect_equal(StratoBayes:::.QuantileMedianIdx(c(0.1, 0.5, 0.9)), 2)
  # no exact 0.5 present: falls back to the positional middle, matching the
  # pre-fix fallback both call sites already used
  expect_equal(StratoBayes:::.QuantileMedianIdx(c(0.1, 0.2, 0.3, 0.9)), 2)
})

test_that("TopsPlot() runs with an asymmetric quantile set using the shared median index", {
  # `medianIdx` only governs which quantile's line is drawn solid on the
  # input panel -- a `display = FALSE` graphical side effect with no trace in
  # the returned data.frame, so this is an integration smoke check, not an
  # independent discriminator of the medianIdx/refQMedianIdx mismatch; the
  # `.QuantileMedianIdx()` unit tests above are the mechanism-level pin.
  data("stratPosterior1", package = "StratoBayes")
  res <- suppressWarnings(TopsPlot(stratPosterior1, refHeights = c(1, 2),
                                   refHeightsSite = 2,
                                   quantiles = c(0.1, 0.2, 0.5, 0.9),
                                   display = FALSE))
  expect_s3_class(res, "data.frame")
})
