# ── #1771: the deep-u regime of the lower-tail qtnorm branch ─────────────────
#
# `qtnorm_std`'s lower-tail branch interpolates log(u + (1 - u)·Φ(zL)/Φ(zU)).
# Forming that via `1 - u` rounds to 1 for any u below 2^-54, so the draw
# collapses onto Φ(zL): on main that is the zL clamp (-Inf when zL is -Inf); on
# top of #1648, whose NaN escape no longer clamps, it is NaN. `.qtnorm` takes
# p from the caller, so the regime is always reachable by direct call; whether an
# engine draw can reach it depends on the implementation-defined granularity of
# uniform_real_distribution below 2^-53.
#
# The oracle below is R's own log-space qnorm, driven by the same identity but
# carrying log(u) directly. Only its *inverter* is independent (Wichura, not
# Acklam+Halley); it shares the identity with the code, so the identity itself
# is pinned by the frozen goldens and by the definitional check below.

# Deliberately NOT skip_on_cran(): three scalar quantile calls, no fixture and
# no sampler, so gating it would take the #1771 detector off every future PR.

OracleLower <- function(u, zL, zU) {
  lpl <- pnorm(zL, log.p = TRUE)
  lph <- pnorm(zU, log.p = TRUE)
  la <- log(u)
  lb <- log1p(-u) + (lpl - lph)
  m <- pmax(la, lb)
  qnorm(lph + m + log1p(exp(pmin(la, lb) - m)), log.p = TRUE)
}

test_that("#1771: lower-tail qtnorm keeps u's precision for u << 2^-54", {
  us <- c(1e-8, 1e-16, 1e-100, 1e-300)
  for (u in us) {
    expect_equal(.sb_qtnorm(u, -Inf, -3), OracleLower(u, -Inf, -3),
                 tolerance = 1e-12, info = paste("u =", u))
  }
  # Half-open bounds must not return -Inf: the quantile is finite for any u > 0.
  expect_true(is.finite(.sb_qtnorm(1e-300, -Inf, -3)))
  # Frozen golden, from R's log.p qnorm at the time of writing.
  expect_equal(.sb_qtnorm(1e-300, -Inf, -3), -37.224900733555721,
               tolerance = 1e-12)
})

test_that("#1771: a finite deep lower bound is not mistaken for the answer", {
  # Pre-fix this returned exactly zL = -50, the clamp, rather than the quantile.
  got <- .sb_qtnorm(1e-300, -50, -3)
  expect_equal(got, OracleLower(1e-300, -50, -3), tolerance = 1e-12)
  expect_gt(got, -50)
  expect_equal(got, -37.224900733555721, tolerance = 1e-12)
})

# Pins the identity itself, not just the inverter: in this well-conditioned
# regime the textbook linear-space definition is usable as an oracle.
test_that("#1771: the interpolation identity matches the linear-space definition", {
  u <- c(0.25, 0.5, 0.75)
  expect_equal(.sb_qtnorm(u, -6, -5),
               qnorm(pnorm(-6) + u * (pnorm(-5) - pnorm(-6))),
               tolerance = 1e-12)
})

# A no-regression pin, not a detector: both formulations agree for ordinary u
# to well within this tolerance, though the last ulps do move.
test_that("#1771: ordinary u in the lower tail is unchanged", {
  u <- c(0.25, 0.5, 0.75)
  # Includes zU just below zero, where this branch meets the straddling one.
  for (b in list(c(-Inf, -3), c(-50, -3), c(-6, -5), c(-Inf, -1e-8))) {
    expect_equal(.sb_qtnorm(u, b[1], b[2]), OracleLower(u, b[1], b[2]),
                 tolerance = 1e-12, info = paste(b[1], b[2]))
  }
})
