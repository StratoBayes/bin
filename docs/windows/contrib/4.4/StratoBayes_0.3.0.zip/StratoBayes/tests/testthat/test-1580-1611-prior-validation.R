# A non-finite value entering the prior system is discovered late, or never:
# #1580-#1584, #1610, #1611 are all instances of that one seam.

# ── #1581: prior-constructor input validation ────────────────────────────────

test_that("NormalPrior()/LogNormalPrior() reject a non-finite location (#1581)", {
  expect_error(NormalPrior(Inf, 1), "'mean' must be finite")
  expect_error(NormalPrior(-Inf, 1), "'mean' must be finite")
  expect_error(LogNormalPrior(Inf, 1), "'meanlog' must be finite")
  # A finite location is untouched.
  expect_s3_class(NormalPrior(0, 1), "NormalPrior")
  expect_s3_class(LogNormalPrior(0, 1), "LogNormalPrior")
})

test_that("UniformPrior() still accepts improper (-Inf, Inf) bounds (#1581)", {
  # Deliberately NOT guarded: `plot.StratPrior()` supports an improper uniform
  # prior, and `.PriorsValidity()` already rejects one at model construction.
  expect_s3_class(UniformPrior(-Inf, Inf), "UniformPrior")
})

test_that("NormalToLogNormal() guards its arguments like its siblings (#1581)", {
  expect_error(NormalToLogNormal(NA, 1), "'mu' must not be NA")
  expect_error(NormalToLogNormal(1, NA), "'sigma' must not be NA")
  expect_error(NormalToLogNormal(c(1, 2), 1), "'mu' must be a single numeric")
  expect_error(NormalToLogNormal(Inf, 1), "'mu' must be finite")
  expect_error(NormalToLogNormal(1, Inf), "'sigma' must be finite")
  # The existing positivity check still fires, and valid input is unchanged.
  expect_error(NormalToLogNormal(-1, 0), "must be positive")
  expect_equal(NormalToLogNormal(1, 0.5),
               list(mu = log(1) - log(0.5 ^ 2 + 1) / 2,
                    sigma = sqrt(log(0.5 ^ 2 + 1))))
})

test_that("TruncLogNormalPrior() rejects bounds that collapse on the log scale (#1581)", {
  expect_error(
    TruncLogNormalPrior(0, 1, lower = 1e300, upper = 1e300 * (1 + 2 ^ -50)),
    "log scale"
  )
  # Bounds that are distinct once logged still construct, including lower = 0.
  expect_s3_class(TruncLogNormalPrior(0, 1, 0.1, 2), "TruncLogNormalPrior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 0, 2), "TruncLogNormalPrior")
})

# ── #1582: R vs C++ prior-density divergences ────────────────────────────────

# Prior-only call: no signal or overlap components, so the returned vector's
# first element is the log-prior.
.pvLogPrior <- function(x, priorType, priorArgs) {
  StratoBayes:::.sb_logpost(
    x = x, priorTypes = priorType, priorArgs = list(priorArgs),
    rCustomFns = list(), B_list = list(), beta_list = list(),
    signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list()
  )[[1]]
}

test_that("C++ UniformPrior rejects a NaN parameter, as R does (#1582)", {
  # max = 2, not 1: -log(1) is 0, which is also what the pre-fix code returned
  # for NaN, so the control would coincide with the bug's value.
  args <- list(min = 0, max = 2)
  # -1e30 is `.sb_logpost`'s out-of-support short-circuit sentinel.
  expect_equal(.pvLogPrior(NaN, "UniformPrior", args), -1e30)
  # In-support values are unaffected.
  expect_equal(.pvLogPrior(0.5, "UniformPrior", args), -log(2))
})

test_that("C++ TruncLogNormal matches R's `min <= 0` guard (#1582)", {
  # `min < 0` is unreachable through TruncLogNormalPrior(), which rejects it:
  # this drives the C++ primitive as `.InferPriorType()` reaches it from a
  # bare Prior() carrying the same argument names.
  args <- list(meanlog = 0, sdlog = 1, min = -1, max = 2)
  for (x in c(0.25, 1, 1.5)) {
    expect_equal(.pvLogPrior(x, "TruncLogNormalPrior", args),
                 TruncLogNormDensity(x, 0, 1, min = -1, max = 2, log = TRUE))
  }
  # x at or below 0 pinned as the sentinel contract, not as the new `x <= 0`
  # clause: pre-fix these were NaN, which the impl already mapped to -1e30, so
  # the clause makes the intent explicit without changing the returned value.
  expect_equal(.pvLogPrior(0, "TruncLogNormalPrior", args), -1e30)
  expect_equal(.pvLogPrior(-0.5, "TruncLogNormalPrior", args), -1e30)
  # min = 0 (no lower truncation) was already fine and stays so.
  expect_equal(.pvLogPrior(1, "TruncLogNormalPrior",
                           list(meanlog = 0, sdlog = 1, min = 0, max = 2)),
               TruncLogNormDensity(1, 0, 1, min = 0, max = 2, log = TRUE))
})

# ── #1580: `.sb_logpost()` wrapper length checks ─────────────────────────────

# Two signals, one sigma: the impl read sigma[1] out of bounds and returned a
# fabricated log-posterior rather than erroring. The garbage value is not
# assertable (the read is undefined behaviour), so the guard is what we pin.
# The guard itself landed on main in 27e5ace5 while this branch was open; these
# two blocks are its only test, so they stay here rather than being deleted.
.pvTwoSignal <- function(sigma) {
  B <- matrix(1, nrow = 3L, ncol = 2L)
  StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(B, B),
    beta_list = list(c(0, 0), c(0, 0)),
    signalValues = list(c(1, 2, 3), c(1, 2, 3)), sigma = sigma,
    overlapPenalty = FALSE, signalSectionOverlap = list(), adjustments = list()
  )
}

test_that(".sb_logpost() rejects a sigma shorter than the signal list (#1580)", {
  expect_error(.pvTwoSignal(1), "sigma has 1 element")
  expect_length(.pvTwoSignal(c(1, 1)), 3L)
})

test_that(".sb_logpost() rejects mismatched prior/signal argument lengths (#1580)", {
  args <- list(list(min = 0, max = 1))
  expect_error(
    StratoBayes:::.sb_logpost(
      x = c(0.5, 0.5), priorTypes = "UniformPrior", priorArgs = args,
      rCustomFns = list(), B_list = list(), beta_list = list(),
      signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    ),
    "priorTypes"
  )
  expect_error(
    StratoBayes:::.sb_logpost(
      x = c(0.5, 0.5), priorTypes = rep("UniformPrior", 2L), priorArgs = args,
      rCustomFns = list(), B_list = list(), beta_list = list(),
      signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    ),
    "priorArgs"
  )
  expect_error(
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(), beta_list = list(c(0, 0)),
      signalValues = list(c(1, 2, 3)), sigma = 1, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    ),
    "B_list"
  )
})

# ── #1583: startup check must not choke on a NaN custom density ──────────────

test_that("StratMCMC() reports a NaN prior density at parametersInitial (#1583)", {
  model <- stratModel1
  model[["priors"]][["metro"]][[1]][["D"]] <-
    function(x, log = FALSE, ...) NaN
  init <- rep(1, length(model[["parametersNames"]]))
  # Match the new clause, not the bare argument name: `parametersInitial` alone
  # also matches this function's length and type errors.
  expect_error(StratMCMC(stratModel = model, parametersInitial = init),
               "finite prior density")
})

# ── #1584: a NULL customPriors element means "no override" ───────────────────

test_that("AutoPrior() treats a NULL customPriors element as no override (#1584)", {
  auto <- AutoPrior(stratData0)
  withNull <- AutoPrior(stratData0, customPriors = list(gammaLog_site2 = NULL))
  expect_equal(withNull, auto)
  # A non-NULL override still applies.
  override <- NormalPrior(0, 3)
  withBoth <- AutoPrior(stratData0,
                        customPriors = list(gammaLog_site2 = NULL,
                                            alpha_site2 = override))
  expect_equal(withBoth[["gammaLog_site2"]], auto[["gammaLog_site2"]])
  expect_equal(withBoth[["alpha_site2"]], override)
})

# ── #1610: `.PriorsValidity()` must reject a non-finite R() draw ─────────────

.pvPrior <- function(rValue) {
  structure(
    # `R` must draw: a generator that consumes nothing leaves `.Random.seed`
    # untouched however `.PriorsValidity()` is written, so the RNG-neutrality
    # block below would pass with `.WithPreservedSeed()` deleted.
    list(bad = Prior(R = function(n, ...) {
                       stats::runif(n)
                       rep(rValue, n)
                     },
                     D = function(x, log = FALSE, ...) dnorm(x, 0, 0.7,
                                                             log = log),
                     Q = function(p, ...) rep(0, length(p)))),
    class = c("StratPrior", "list")
  )
}

test_that(".PriorsValidity() rejects a non-finite generative draw (#1610)", {
  expect_error(StratoBayes:::.PriorsValidity(.pvPrior(Inf)), "non-finite")
  expect_error(StratoBayes:::.PriorsValidity(.pvPrior(NaN)), "non-finite")
  expect_error(StratoBayes:::.PriorsValidity(.pvPrior(NA_real_)), "non-finite")
  expect_silent(StratoBayes:::.PriorsValidity(.pvPrior(0)))
})

test_that(".PriorsValidity() leaves the RNG stream untouched (#1610, GH #1400)", {
  set.seed(1)
  runif(1)
  before <- .Random.seed
  StratoBayes:::.PriorsValidity(.pvPrior(0))
  expect_identical(.Random.seed, before)
  # The failing path must not consume the stream either.
  try(StratoBayes:::.PriorsValidity(.pvPrior(Inf)), silent = TRUE)
  expect_identical(.Random.seed, before)
})

# ── #1611: `.ValidateParams()` checks both paths ─────────────────────────────

test_that(".ValidateParams() rejects non-finite supplied parameters (#1611)", {
  expect_error(StratoBayes:::.ValidateParams(rep(Inf, 3), len = 3,
                                             ifNull = NULL),
               "finite")
  expect_error(StratoBayes:::.ValidateParams(c(1, -Inf, 3), len = 3,
                                             ifNull = NULL),
               "finite")
  # The pre-existing NA message is unchanged.
  expect_error(StratoBayes:::.ValidateParams(c(1, NA, 3), len = 3,
                                             ifNull = NULL),
               "must not contain missing values")
})

test_that(".ValidateParams() checks the prior-draw path too (#1611)", {
  bad <- matrix(c(1, NaN, 3), nrow = 1L)
  expect_error(StratoBayes:::.ValidateParams(NULL, len = 3, ifNull = bad),
               "finite")
  expect_error(StratoBayes:::.ValidateParams(NULL, len = 3,
                                             ifNull = matrix(c(1, Inf, 3),
                                                             nrow = 1L)),
               "finite")
  good <- matrix(c(1, 2, 3), nrow = 1L)
  expect_identical(StratoBayes:::.ValidateParams(NULL, len = 3, ifNull = good),
                   good)
})

test_that("the truncated families guard their location parameter too (#1581)", {
  expect_error(TruncNormalPrior(Inf, 1, -1, 1), "'mean' must be finite")
  expect_error(TruncLogNormalPrior(Inf, 1, 0.1, 2), "'meanlog' must be finite")
  # One-sided truncation keeps its infinite bound.
  expect_s3_class(TruncNormalPrior(0, 1, 0, Inf), "TruncNormalPrior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 0, Inf), "TruncLogNormalPrior")
})

test_that(".ValidateParams() passes a non-numeric ifNull through untouched", {
  expect_identical(StratoBayes:::.ValidateParams(NULL, 1, "NULL"), "NULL")
  expect_null(StratoBayes:::.ValidateParams(NULL, 1, NULL))
})

test_that(".sb_logpost() rejects a non-conformable B/beta/signal (#1580)", {
  B <- matrix(1, nrow = 3L, ncol = 4L)
  call1 <- function(beta, y) StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(B), beta_list = list(beta),
    signalValues = list(y), sigma = 1, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list())
  # Conformable: the joint-at-beta likelihood with a zero fit, so the signal
  # term is -n(log sigma + log sqrt(2 pi)) - 0.5 sum(y^2) / sigma^2.
  expect_equal(call1(rep(0, 4), c(1, 2, 3))[[2]],
               -3 * log(sqrt(2 * pi)) - 0.5 * sum(c(1, 2, 3) ^ 2))
  expect_error(call1(rep(0, 4), c(1, 2, 3, 4, 5)), "signalValues")
  expect_error(call1(rep(0, 2), c(1, 2, 3)), "beta_list")
})

test_that(".sb_logpost(overlapPenalty = TRUE) needs one entry per signal (#1580)", {
  expect_error(
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(matrix(1, nrow = 3L, ncol = 2L)),
      beta_list = list(c(0, 0)), signalValues = list(c(1, 2, 3)), sigma = 1,
      overlapPenalty = TRUE, signalSectionOverlap = list(),
      adjustments = list()),
    "one entry per signal"
  )
})

test_that(".CheckParamsFinite() sees numeric columns of a mixed frame (#1611)", {
  # `as.matrix()` on a mixed frame makes every column character, which would
  # hide the Inf rather than reject it. Exercised directly: `.ValidateParams()`
  # now rejects a mixed frame as non-numeric before the finiteness check is
  # reached (#1172), so going through it would no longer test this function.
  mixed <- data.frame(a = c(1, Inf), b = c("x", "y"), c = c(1, 2))
  expect_error(StratoBayes:::.CheckParamsFinite(mixed, "`parameters`"),
               "finite")

  # ...and the earlier guard is what a caller actually meets.
  expect_error(
    StratoBayes:::.ValidateParams(mixed, len = 3, ifNull = NULL),
    "must be numeric"
  )
})
