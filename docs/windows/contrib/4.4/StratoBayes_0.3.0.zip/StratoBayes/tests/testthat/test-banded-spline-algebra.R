# ── Banded spline algebra (issue #116) ───────────────────────────────────────
#
# The spline precision matrix M = B'B/sigma^2 + lambda*D is exactly banded
# (bandwidth splineOrder-1), so signal_logmarginal_one and the engine's Gibbs
# sweep factor the band (src/sb_band.h) instead of the dense matrix, and the
# Gibbs Q = M^{-1} is materialised from the stored band factor only at state
# extraction rather than by dpotri every sweep. These tests pin both halves
# against independent dense R oracles.
#
# Callers may still pass arbitrary dense inputs (e.g. test-marginal-neginf.R's
# hand-built B); those take the dense path, unchanged — covered there.

# Dense R oracle for the beta-marginal signal log-likelihood (the formula of
# src/SignalMarginal.h, computed with base R dense algebra).
marg_oracle <- function(B, y, sigma, lambda, D) {
  p <- ncol(B)
  n <- length(y)
  M <- crossprod(B) / sigma^2 + lambda * D
  R <- chol(M)
  tBy <- as.numeric(crossprod(B, y)) / sigma^2
  mu <- backsolve(R, forwardsolve(t(R), tBy))
  quad <- 0.5 * sum(tBy * mu)
  logdet <- sum(log(diag(R)))
  -n * log(sigma) - 0.5 * sum(y^2) / sigma^2 + 0.5 * (p - 2) * log(lambda) +
    quad - logdet
}

call_marginal <- function(B, y, sigma, lambda, D) {
  StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(B), beta_list = list(numeric(ncol(B))),
    signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list(),
    marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)
}

test_that("banded marginal path matches a dense R oracle on a real B-spline design", {
  set.seed(42)
  ord <- 4L
  n <- 300L
  x <- sort(runif(n, 0, 10))
  y <- sin(x) + rnorm(n, 0, 0.3)

  # K = 4 gives p = 6, near the small-p edge of the banded regime
  # (kd = 3 <= p - 2 = 4). Fully dense small inputs must instead decline to
  # the dense path (sb_band_detect's p-2 cap) — the p = 4 rank-deficient
  # fixture in test-marginal-neginf.R pins that side.
  for (K in c(4L, 8L, 25L, 60L)) {
    knots <- seq(0, 10, length.out = K)
    ek <- c(rep(knots[1], ord - 1), knots, rep(knots[K], ord - 1))
    B <- StratoBayes:::.sb_spline_design(ek, x, ord)
    D <- StratoBayes:::.bsplinepen(knots, norder = ord)
    # Off-band entries of B'B are exact zeros, so this exercises the band path
    bw <- max(abs(which(crossprod(B) != 0, arr.ind = TRUE) %*% c(1, -1)))
    expect_lte(bw, ord - 1)

    res <- call_marginal(B, y, sigma = 0.4, lambda = 2.5, D = D)
    expect_equal(res[2], marg_oracle(B, y, 0.4, 2.5, D), tolerance = 1e-10)
  }
})

test_that("band detection uses M's own band, not either input's (kd = 2 penalty)", {
  # A second-difference penalty has bandwidth 2 < the design's 3: detection
  # must use the wider of the two (M's own band), not either input's.
  set.seed(7)
  p <- 12L
  n <- 80L
  ord <- 4L
  knots <- seq(0, 1, length.out = p - 2L)
  ek <- c(rep(knots[1], ord - 1), knots, rep(knots[p - 2L], ord - 1))
  x <- sort(runif(n))
  B <- StratoBayes:::.sb_spline_design(ek, x, ord)
  y <- as.numeric(B %*% rnorm(p)) + rnorm(n, 0, 0.1)
  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D2 <- crossprod(Delta)

  res <- call_marginal(B, y, sigma = 0.2, lambda = 1.3, D = D2)
  expect_equal(res[2], marg_oracle(B, y, 0.2, 1.3, D2), tolerance = 1e-10)
})

test_that("engine takes the banded path for a standard spline model (#621)", {
  # The banded and dense paths agree numerically, so no result-comparing test
  # can catch the engine silently reverting to dense algebra; routing is only
  # observable through ModelData::bandKd. Deliberately NOT skip_on_cran():
  # the PR gate runs without NOT_CRAN, exactly where a silent revert would land.
  data(stratData1, envir = environment())
  data(stratModel1, envir = environment())
  td <- withr::local_tempdir()

  result <- suppressMessages(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10L, nChains = 2L, nCores = 1L, nThreads = 1L, seed = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bandguard",
    engine = "R"))

  model_obj <- result[["model"]]
  if (is.null(model_obj[[".logpost_cpp"]]))
    model_obj[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  mcmc_obj <- readRDS(file.path(td, "bandguard_mcmc_run_1.rds"))

  tiesCallback <- if ("ties" %in% names(result[["data"]])) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        result[["data"]], model_obj[["ind"]], parameters, FALSE)
      tmpState <- list(age = list(ties = ageResult[["ties"]]))
      StratoBayes:::.LogLikTies(result[["data"]], model_obj, tmpState)
    }
  }

  engine <- StratoBayes:::.sb_create_engine(
    data = result[["data"]], model = model_obj,
    mcmc = mcmc_obj, state = mcmc_obj[["recentState"]],
    tiesCallback = tiesCallback)

  # splineOrder = 4 and .bsplinepen's D share the basis support, so the
  # verified structural bandwidth must be order - 1; -1 would mean every
  # spline factorisation runs dense.
  expect_identical(StratoBayes:::.sb_engine_band_kd(engine), 3L)
})

test_that("extracted Gibbs Q is the exact inverse of H + lambda*D (deferred materialisation)", {
  skip_on_cran()
  data(stratData1, envir = environment())
  data(stratModel1, envir = environment())
  td <- withr::local_tempdir()

  post <- suppressMessages(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 200L, nChains = 2L, nThin = 10L, nRun = 1L,
    nCores = 1L, nThreads = 1L, seed = 11L,
    quiet = TRUE, visualise = FALSE, modelDir = td))

  mcmcFile <- list.files(td, pattern = "_mcmc_run_1\\.rds$", full.names = TRUE)
  mc <- readRDS(mcmcFile[[1]])
  D <- stratModel1[["splineBase"]][["D"]]

  for (chain in seq_along(mc[["recentState"]])) {
    st <- mc[["recentState"]][[chain]]
    Qm <- st[["gibbs"]][["Q"]][[1]]
    H <- st[["metro"]][["H"]][[1]]

    expect_true(isTRUE(all.equal(Qm, t(Qm))))
    ev <- eigen(Qm, symmetric = TRUE, only.values = TRUE)[["values"]]
    expect_gt(min(ev), 0)

    # Q^{-1} - H must be lambda_pre * D for the (scalar) lambda the sweep
    # factorised with: elementwise ratio constant across the band. This fails
    # if the band factor, its storage, or the materialising solve is wrong.
    # Holds only because stratModel1 fixes sigma: with a sampled sigma the
    # extracted H is rescaled to sigma_post after the sweep factorised at
    # sigma_pre, and the ratio is no longer constant.
    ratio <- (solve(Qm) - H)[abs(D) > 1e-8] / D[abs(D) > 1e-8]
    expect_lt(diff(range(ratio)) / abs(mean(ratio)), 1e-6)
  }
})
