# Regression tests for RT-265 / RT-266.
#
# Prior lists (`priors`, `priorsProposals`) are name-keyed, but every downstream
# consumer builds and indexes the parameter vector in the canonical order from
# `.CreateIndices()` (`ind[["names"]]`): `.MetroPriorSample()` / `.MetroPriorLog()`
# iterate the list positionally, and the free-parameter indices
# `ind$paramNotFixed` / `ind$alphaNotFixed` are derived from list position.
# `.PriorsValidity()` only checks set membership (`setequal`), so a set-equal but
# reordered list used to be stored verbatim (age-scale `priors`; `priorsProposals`
# on both scales) — silently binding each prior to the wrong parameter with no
# error. Fix: `.CanonicalisePriorOrder()`, called in `StratModel()` after
# `.PriorsValidity()`. These tests assert the model canonicalises order so that a
# reordered input produces bindings identical to the canonical-order model.

set.seed(0)
.rtOrderData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
tmulti <- StratData(.rtOrderData$signal, parts = .rtOrderData$parts,
                    ties = .rtOrderData$ties,
                    signalColumn = c("a", "b"), zColumn = "Hight",
                    siteColumn = "SIT")

# Canonical order == `ind[["names"]]` for sedModel "site" on the age scale.
# A `Fixed()` prior is included on purpose: `ind$paramNotFixed`/`ind$alphaNotFixed`
# are derived from the *position* of the Fixed prior in the list, so a
# canonicalisation that ran too late (after those indices are computed) would
# leave the Fixed path wrong even if the stored priors look right.
.makeCanonicalPriors <- function() {
  structure(list(
    "alpha_site1"    = UniformPrior(min = 10, max = 60),
    "alpha_site2"    = Fixed(20),
    "alpha_site3"    = UniformPrior(min = -10, max = 60),
    "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site2" = NormalPrior(mean = 2, sd = 0.5),
    "gammaLog_site3" = NormalPrior(mean = 3, sd = 2),
    "gap_site2_1"    = ExponentialPrior(rate = 0.1)),
    class = c("StratPrior", "list"))
}

# A deliberately non-canonical (reversed) ordering of the same set of priors.
.reorderPriors <- function(priors) {
  structure(rev(priors), class = class(priors))
}

.buildAgeModel <- function(priors, priorsProposals = NULL) {
  StratModel(tmulti, priors = priors, priorsProposals = priorsProposals,
             alignmentScale = "age", sedModel = "site", alphaPosition = "bottom")
}

test_that("age-scale `priors` are canonicalised, not stored verbatim (RT-265)", {
  canonical <- .makeCanonicalPriors()
  reversed  <- .reorderPriors(canonical)

  # sanity: the reversed list really is a different (but set-equal) order
  expect_false(identical(names(canonical), names(reversed)))
  expect_setequal(names(canonical), names(reversed))

  mCanon <- .buildAgeModel(canonical)
  mRev   <- .buildAgeModel(reversed)

  # the stored prior-to-parameter binding must be identical regardless of the
  # order the user supplied the priors in
  expect_identical(mRev[["priors"]][["metro"]], mCanon[["priors"]][["metro"]])
  expect_identical(mRev[["parametersNames"]], mCanon[["parametersNames"]])
  expect_identical(names(mRev[["priors"]][["metro"]]),
                   mCanon[["ind"]][["names"]])

  # the Fixed-parameter indices (derived from list position) must match too
  expect_identical(mRev[[c("ind", "paramNotFixed")]],
                   mCanon[[c("ind", "paramNotFixed")]])
  expect_identical(mRev[[c("ind", "alphaNotFixed")]],
                   mCanon[[c("ind", "alphaNotFixed")]])

  # class preserved through the reorder
  expect_s3_class(mRev[["priors"]][["metro"]], "StratPrior")

  # a seeded prior draw lands each value in the same parameter slot
  set.seed(42)
  drawCanon <- .MetroPriorSample(1, mCanon)
  set.seed(42)
  drawRev   <- .MetroPriorSample(1, mRev)
  expect_identical(drawRev, drawCanon)
})

test_that("`priorsProposals` are canonicalised, not stored verbatim (RT-266)", {
  canonical <- .makeCanonicalPriors()
  # priors canonical; only priorsProposals reordered -> isolates the RT-266 path
  proposalsRev <- .reorderPriors(canonical)

  mCanon <- .buildAgeModel(canonical, priorsProposals = canonical)
  mRev   <- .buildAgeModel(canonical, priorsProposals = proposalsRev)

  expect_identical(mRev[["priorsProposals"]], mCanon[["priorsProposals"]])
  expect_identical(names(mRev[["priorsProposals"]]), mCanon[["ind"]][["names"]])
  expect_s3_class(mRev[["priorsProposals"]], "StratPrior")

  # `.MetroPriorSample` draws from `priorsProposals` positionally; a reordered
  # proposal list must not change which slot each draw lands in
  set.seed(7)
  drawCanon <- .MetroPriorSample(1, mCanon)
  set.seed(7)
  drawRev   <- .MetroPriorSample(1, mRev)
  expect_identical(drawRev, drawCanon)
})

test_that("canonical-order input is stored untouched (no-op fast path)", {
  canonical <- .makeCanonicalPriors()
  m <- .buildAgeModel(canonical, priorsProposals = canonical)
  # `StratModel()` stamps both `priors` and `priorsProposals` with the
  # resolved alphaPosition (see .agent/specs/stamp-alphaposition/spec.md), so
  # the untouched-round-trip comparison must expect that stamp too.
  attr(canonical, "alphaPosition") <- .MatchAlphaPosition("bottom", tmulti,
                                                           "age",
                                                           toNumeric = TRUE)
  # already-canonical lists must round-trip unchanged (bit-identical bindings)
  expect_identical(m[["priors"]][["metro"]], canonical)
  expect_identical(m[["priorsProposals"]], canonical)
})

test_that(".CanonicalisePriorOrder guards a set-equal-but-length-mismatch list", {
  ind <- .CreateIndices(tmulti, alignmentScale = "age", sedModel = "site",
                        alphaPosition = "bottom")
  canonical <- .makeCanonicalPriors()

  # duplicate one name and drop another: `setequal` still passes but subsetting
  # by canonical names would silently drop the extra -> must error, not corrupt
  bad <- canonical
  names(bad)[[length(bad)]] <- names(bad)[[1]]  # gap_* renamed to alpha_site1 (dup)
  expect_error(.CanonicalisePriorOrder(bad, ind, "priors"),
               "do not match requirements")

  # already-canonical list is returned unchanged
  expect_identical(.CanonicalisePriorOrder(canonical, ind, "priors"), canonical)

  # NULL ind is a pass-through
  expect_identical(.CanonicalisePriorOrder(canonical, NULL), canonical)
})
