# ── β-marginal value branch, its Cholesky fail-closed (-Inf) path, and the MH
# ── accept step that consumes both ───────────────────────────────────────────
#
# `docs/r-engine-contract.md` lists the base MH acceptance ratio (including the
# marginal Occam term) as Tier 1. These are that row's PR-time pin (#582 layers
# 1 and 2); the RT-282* and RT-582 calibration harnesses under
# `dev/red-team/heavy-tests/` are manual. These tests establish that the shipped
# formula IS the model's marginal likelihood; the companion heavy oracle,
# `dev/red-team/heavy-tests/RT-582-marginal-mh-invariant-density.R`, establishes
# that the sampler actually targets it. Layer 1 is the half that cannot see a
# sampler targeting the wrong density; the refresh test at the foot of this file
# would have caught #338's own defect, but not a wrong formula.
#
# Deliberately NOT an R-vs-C++ equivalence test: `signal_logmarginal_one` is a
# single shared primitive both engines call, so a cross-engine assertion
# compares it to itself. PR #338's bug was present identically in both arms.
#
# The β-marginal signal likelihood (Option B / T-162, src/SignalMarginal.h) forms
# M_a = BᵀB/σ² + λD and Cholesky-decomposes it. When the design is rank-deficient
# (e.g. an alignment that collapses observations, or too few observations for the
# basis) M_a is singular and `sb_cholesky` fails; per proof §B.5 the core returns
# −∞ ("fail-closed") rather than a NaN. `.sb_logpost` propagates that as an −∞
# signal component, and the alignment MH accept step must then reject (if the
# current state is finite) or explore (if it too is −∞) — never error on a
# −∞ − (−∞) = NaN ratio.
#
# Both branches (the core's −∞ return and the accept step's −∞ handling) were
# added with T-162/PR #338 but left uncovered: the existing marginal parity tests
# in test-cpp-logpost-equivalence.R all use well-conditioned designs where the
# Cholesky succeeds, and the "-Inf" tests there exercise the *prior* short-circuit
# (the −1e30 sentinel), a different path. These two tests close that gap.
#
# The tests call `.sb_logpost` directly with a hand-built rank-deficient B so the
# singular M_a is reached deterministically (a genuinely singular *alignment* is
# hard to force through the model constructor, and unnecessary — the engine's own
# marginal wrapper, signal_logmarginal in MCMCEngine.cpp, feeds the IDENTICAL
# shared core signal_logmarginal_one, so this covers the −∞ return for both
# engines; only the input plumbing differs).

test_that(".sb_logpost(marginal = TRUE) returns -Inf when B'B/sigma^2 + lambda*D is singular", {
  p <- 4L
  n <- 5L
  sigma <- 1
  lambda <- 1

  # Second-order difference penalty D = Delta' Delta (p x p, rank p-2 = 2): its
  # 2-dim null space (constants + linear) is exactly the (p-2) in the marginal
  # normaliser 0.5*(p-2)*log(lambda). With a rank-deficient B'B, M_a is singular.
  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D <- crossprod(Delta)
  y <- as.numeric(seq_len(n))

  call_marginal <- function(B) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(B), beta_list = list(numeric(p)),
      signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)
  }

  # Rank-deficient design: every row identical -> rank-1 B'B -> M_a singular.
  B_singular <- matrix(1, n, p)
  res_singular <- call_marginal(B_singular)
  # c(logPrior, logLikSignal, logLikOverlap); no priors -> logPrior == 0.
  expect_equal(res_singular[1], 0)                 # prior slot finite (no short-circuit)
  expect_identical(res_singular[2], -Inf)          # signal slot fail-closed to -Inf
  expect_equal(res_singular[3], 0)

  # Control: a full-rank design makes M_a positive-definite, so the Cholesky
  # succeeds and every component is finite. This proves the test discriminates
  # (the -Inf is caused by the rank deficiency, not the harness).
  set.seed(1)
  B_full <- matrix(stats::rnorm(n * p), n, p)
  res_full <- call_marginal(B_full)
  expect_true(all(is.finite(res_full)))
})

test_that(".AcceptProposal handles a -Inf marginal logPost without a NaN ratio", {
  # A finite temperature; the -Inf branches never touch it or the RNG, so these
  # are deterministic. `.AcceptProposal` short-circuits on == -Inf BEFORE forming
  # (logPostNew - logPostOld)/temperature, so -Inf - (-Inf) = NaN is never
  # computed (which would make `if (accept)` error). This mirrors the C++
  # accept_proposal !isfinite() logic (MCMCEngine.cpp) that the frozen-reference
  # contract requires the base MH acceptance to match.
  temp <- 1

  # New alignment is singular (-Inf), current state finite -> reject, stay put.
  expect_false(StratoBayes:::.AcceptProposal(
    logPostOld = -12.3, logPostNew = -Inf, temperature = temp))

  # Both singular (-Inf) -> accept, so the chain can explore out of a bad region
  # rather than deadlock (the "auto-accept-escape").
  expect_true(StratoBayes:::.AcceptProposal(
    logPostOld = -Inf, logPostNew = -Inf, temperature = temp))

  # Current state singular (-Inf), proposal finite -> always accept (escape).
  expect_true(StratoBayes:::.AcceptProposal(
    logPostOld = -Inf, logPostNew = -12.3, temperature = temp))
})


# ══ #582 layer 1 — the β-marginal VALUE, against the model definition ════════
#
# Reference: the Gaussian integral itself,
#   logML = log ∫ N(y; Bβ, σ²I) · π(β) dβ,   π(β) = N(0, (λD)⁻),
# written from the model rather than translated from `signal_logmarginal_one`,
# so it cannot inherit that function's bugs. D is the second-difference penalty
# and is rank p−2, so π is improper (flat on the 2-dim constant+linear null
# space); its density w.r.t. Lebesgue measure on R^p is
#   π(β) = (2π)^(−r/2) · pdet(λD)^(1/2) · exp(−½ λ β'Dβ),   r = rank(D) = p−2,
# proper on row(D) and flat on null(D). Completing the square in β gives
#
#   logML = ½(p − r − n)·log 2π − n·log σ − ½·y'y/σ²
#           + ½·log pdet(λD) − ½·log det M + ½·(B'y/σ²)' M⁻¹ (B'y/σ²)
#
# with M = B'B/σ² + λD.  The shipped core drops two additive constants — the
# log-2π bookkeeping and ½·log pdet(D_base) — because both are independent of
# the alignment, λ and σ, so they cancel in every acceptance ratio. Hence
#
#   implementation = logML − C,   C = (1 − n/2)·log 2π + ½·log pdet(D_base)
#
# and C depends on n and D_base ONLY. That is what makes the tests below
# non-circular: C cannot absorb an error in any term that varies with the
# alignment, λ or σ, and the difference tests need no C at all.
#
# Under flexibleKnots the D passed in is already D_a = scale³·D_base and the
# caller adds flexTerm = 1.5·(p−2)·log scale; since D_a shares D_base's
# eigenvectors, ½·log pdet(λD_a) = ½(p−2)log λ + flexTerm + ½·log pdet(D_base),
# so the SAME C (built from D_base) applies (proof §B.9.2).
#
# The integral is finite iff null(B) ∩ null(D) = {0}, which is exactly the
# condition for M to be positive-definite — i.e. exactly when the core's
# Cholesky succeeds. On the singular designs of the first two tests in this file
# logML genuinely diverges to +∞; the core's −∞ there is the deliberate
# fail-closed choice of proof §B.5, not a value of logML, so the reference below
# is only ever applied to well-conditioned designs.

.mnEigvals <- function(A) {
  eigen(A, symmetric = TRUE, only.values = TRUE)[["values"]]
}

.mnRank <- function(A) {
  ev <- .mnEigvals(A)
  sum(ev > 1e-9 * max(ev))
}
# Pseudo-determinant as the product of the top-rank eigenvalues, taken in
# `eigen`'s decreasing order rather than by a tolerance filter: the null
# eigenvalues come out tiny and NEGATIVE (order -1e-16 here, -1e-13 for the
# production .bsplinepen penalty), one boundary case away from log(negative).
.mnLogPdet <- function(A, r = .mnRank(A)) sum(log(.mnEigvals(A)[seq_len(r)]))

# Second-difference penalty D = Delta'Delta, rank p-2.
.mnPenalty <- function(p) {
  Delta <- matrix(0, p - 2L, p)
  for (i in seq_len(p - 2L)) Delta[i, i:(i + 2L)] <- c(1, -2, 1)
  crossprod(Delta)
}

# The reference integral, from the definition (see header).
.mnRefMarginal <- function(B, y, sigma, lambda, D) {
  n <- length(y)
  p <- ncol(B)
  r <- .mnRank(D)
  M <- crossprod(B) / sigma^2 + lambda * D
  tBy <- crossprod(B, y) / sigma^2
  0.5 * (p - r - n) * log(2 * pi) -
    n * log(sigma) - 0.5 * sum(y^2) / sigma^2 +
    0.5 * (r * log(lambda) + .mnLogPdet(D)) -
    0.5 * as.numeric(determinant(M, logarithm = TRUE)[["modulus"]]) +
    0.5 * sum(tBy * solve(M, tBy))
}

# The additive constant the shipped normalisation drops.
.mnDropped <- function(n, Dbase) {
  (1 - n / 2) * log(2 * pi) + 0.5 * .mnLogPdet(Dbase)
}

# The shipped normalisation, with knobs for the mutants tested further down.
# With the default knobs this equals .mnRefMarginal() - .mnDropped(), asserted
# before any mutant is used.
.mnShippedForm <- function(B, y, sigma, lambda, D, flexTerm = 0,
                           logdetCoef = -0.5, quadCoef = 0.5,
                           lambdaExp = ncol(B) - 2) {
  M <- crossprod(B) / sigma^2 + lambda * D
  tBy <- crossprod(B, y) / sigma^2
  -length(y) * log(sigma) - 0.5 * sum(y^2) / sigma^2 +
    0.5 * lambdaExp * log(lambda) + flexTerm +
    logdetCoef * as.numeric(determinant(M, logarithm = TRUE)[["modulus"]]) +
    quadCoef * sum(tBy * solve(M, tBy))
}

# `.sb_logpost`'s signal slot under marginal = TRUE. bList/sigma/lambda are
# per-signal; Dmat and flexTerm are shared.
.mnSignalMarginal <- function(bList, yList, sigma, lambda, D, flexTerm = 0) {
  if (!is.list(bList)) bList <- list(bList)
  if (!is.list(yList)) yList <- list(yList)
  StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = bList,
    beta_list = lapply(bList, function(B) numeric(ncol(B))),
    signalValues = yList, sigma = sigma, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list(),
    marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = flexTerm)[2]
}

# One well-conditioned fixture reused by the whole layer.
.mnFixture <- function(p = 5L, n = 7L, seed = 11L) {
  set.seed(seed)
  list(p = p, n = n, D = .mnPenalty(p),
       B = matrix(stats::rnorm(n * p), n, p), y = stats::rnorm(n))
}

test_that(".mnShippedForm is the reference integral, less an (n, D) constant", {
  # Anchors the mutant generator to the definition: every regression case below
  # mutates .mnShippedForm, so if it did not itself equal the model's own
  # integral those cases would be measuring nothing.
  f <- .mnFixture()
  for (sigma in c(0.4, 1.7)) for (lambda in c(0.05, 9)) {
    expect_equal(
      .mnShippedForm(f$B, f$y, sigma, lambda, f$D),
      .mnRefMarginal(f$B, f$y, sigma, lambda, f$D) - .mnDropped(f$n, f$D),
      tolerance = 1e-12)
  }
})

test_that(".sb_logpost(marginal = TRUE) equals the closed-form integral", {
  f <- .mnFixture()
  # The core hard-codes the rank of D as p-2 in its 0.5*(p-2)*log(lambda)
  # normaliser, so this fixture is a valid oracle only if its D really has that
  # rank. A D of any other rank would disagree with the definition by design,
  # not by defect, and must not be used here.
  expect_identical(.mnRank(f$D), f$p - 2L)
  expect_identical(qr(f$D)$rank, as.integer(f$p - 2L))

  C <- .mnDropped(f$n, f$D)
  # C is constant across this grid by construction, so the agreement pins every
  # sigma- and lambda-dependent term individually.
  for (sigma in c(0.4, 1.7, 3.3)) for (lambda in c(0.05, 0.35, 9)) {
    expect_equal(
      .mnSignalMarginal(f$B, f$y, sigma, lambda, f$D),
      .mnRefMarginal(f$B, f$y, sigma, lambda, f$D) - C,
      tolerance = 1e-10)
  }

  # And across designs: B is where the alignment enters, so this is the term the
  # MH move actually varies.
  for (k in 1:4) {
    set.seed(100L + k)
    Bk <- matrix(stats::rnorm(f$n * f$p), f$n, f$p)
    expect_equal(.mnSignalMarginal(Bk, f$y, 1.7, 0.35, f$D),
                 .mnRefMarginal(Bk, f$y, 1.7, 0.35, f$D) - C,
                 tolerance = 1e-10)
  }
})

test_that("beta-marginal DIFFERENCES match the definition, no constant", {
  # The acceptance ratio only ever sees differences, in which C cancels
  # identically. These assertions therefore contain no fitted constant.
  f <- .mnFixture()
  set.seed(202)
  B2 <- matrix(stats::rnorm(f$n * f$p), f$n, f$p)
  sigma <- 1.7
  lambda <- 0.35

  # a -> a' at fixed (sigma, lambda): the actual MH increment.
  expect_equal(
    .mnSignalMarginal(B2, f$y, sigma, lambda, f$D) -
      .mnSignalMarginal(f$B, f$y, sigma, lambda, f$D),
    .mnRefMarginal(B2, f$y, sigma, lambda, f$D) -
      .mnRefMarginal(f$B, f$y, sigma, lambda, f$D),
    tolerance = 1e-10)

  # lambda and sigma differences: what a tempering swap compares (proof §B.9.3).
  expect_equal(
    .mnSignalMarginal(f$B, f$y, sigma, 9, f$D) -
      .mnSignalMarginal(f$B, f$y, sigma, 0.05, f$D),
    .mnRefMarginal(f$B, f$y, sigma, 9, f$D) -
      .mnRefMarginal(f$B, f$y, sigma, 0.05, f$D),
    tolerance = 1e-10)
  expect_equal(
    .mnSignalMarginal(f$B, f$y, 3.3, lambda, f$D) -
      .mnSignalMarginal(f$B, f$y, 0.4, lambda, f$D),
    .mnRefMarginal(f$B, f$y, 3.3, lambda, f$D) -
      .mnRefMarginal(f$B, f$y, 0.4, lambda, f$D),
    tolerance = 1e-10)
})

test_that("the BANDED Cholesky path agrees with the definition too", {
  # The core takes one of two branches on the structure of M = B'B/sigma^2 +
  # lambda*D: `sb_band_detect` returns -1 for a dense M and the bandwidth
  # otherwise, and the two branches accumulate the log-determinant through
  # different code (sb_band_logdet vs summing log L[j,j]). A real B-spline
  # design is banded, so production always takes the banded branch; the random
  # designs elsewhere in this file only reach the dense one.
  ord <- 4L
  p <- 6L
  knots <- c(rep(0, ord), seq_len(p - ord) / (p - ord + 1), rep(1, ord))
  B <- splines::splineDesign(knots, seq(0.02, 0.98, length.out = 14), ord = ord)
  D <- .mnPenalty(p)
  set.seed(404)
  y <- stats::rnorm(nrow(B))
  sigma <- 1.7
  lambda <- 0.35

  M <- crossprod(B) / sigma^2 + lambda * D
  # sb_band_detect scans for exact zeros and needs a bandwidth <= p - 2.
  bandwidth <- max(abs(row(M) - col(M))[M != 0])
  expect_lte(bandwidth, p - 2L)
  expect_identical(qr(D)$rank, as.integer(p - 2L))
  expect_identical(qr(B)$rank, as.integer(p))

  expect_equal(.mnSignalMarginal(B, y, sigma, lambda, D),
               .mnRefMarginal(B, y, sigma, lambda, D) -
                 .mnDropped(length(y), D),
               tolerance = 1e-10)
})

test_that("the beta-marginal sums over signals, flexTerm once per signal", {
  f <- .mnFixture()
  set.seed(303)
  B2 <- matrix(stats::rnorm(f$n * f$p), f$n, f$p)
  y2 <- stats::rnorm(f$n)
  sig <- c(1.7, 0.9)
  lam <- c(0.35, 2.5)
  flexTerm <- 1.5 * (f$p - 2) * log(1.37)

  one1 <- .mnSignalMarginal(f$B, f$y, sig[1], lam[1], f$D, flexTerm)
  one2 <- .mnSignalMarginal(B2, y2, sig[2], lam[2], f$D, flexTerm)
  expect_equal(
    .mnSignalMarginal(list(f$B, B2), list(f$y, y2), sig, lam, f$D, flexTerm),
    one1 + one2, tolerance = 1e-10)
  # flexTerm therefore enters twice, not once: proof §B.9.3 stores the full
  # marginal per signal m, and the shared scalar is part of each.
  expect_equal(
    .mnSignalMarginal(list(f$B, B2), list(f$y, y2), sig, lam, f$D, flexTerm) -
      .mnSignalMarginal(list(f$B, B2), list(f$y, y2), sig, lam, f$D, 0),
    2 * flexTerm, tolerance = 1e-10)
})

test_that("flexTerm 1.5*(p-2)*log(scale) is the pdet of the rescaled D", {
  # Under flexibleKnots the caller passes D_a = scale^3 * D_base and adds
  # flexTerm; the definition says the pair must reproduce
  # 0.5*log pdet(lambda*D_a) up to the SAME constant built from D_base.
  f <- .mnFixture()
  scale <- 1.37
  Da <- scale^3 * f$D
  flexTerm <- 1.5 * (f$p - 2) * log(scale)
  expect_equal(
    .mnSignalMarginal(f$B, f$y, 1.7, 0.35, Da, flexTerm),
    .mnRefMarginal(f$B, f$y, 1.7, 0.35, Da) - .mnDropped(f$n, f$D),
    tolerance = 1e-10)

  # A constant-free check of the same exponent: the increment between two spans
  # must equal the increment of the pdet term.
  scale2 <- 0.61
  Da2 <- scale2^3 * f$D
  expect_equal(
    .mnSignalMarginal(f$B, f$y, 1.7, 0.35, Da2, 1.5 * (f$p - 2) * log(scale2)) -
      .mnSignalMarginal(f$B, f$y, 1.7, 0.35, Da, flexTerm),
    .mnRefMarginal(f$B, f$y, 1.7, 0.35, Da2) -
      .mnRefMarginal(f$B, f$y, 1.7, 0.35, Da),
    tolerance = 1e-10)
})

# ── Regression cases: each mutation of the shipped formula must move the value
# ── by a stated, non-zero amount, so these tests demonstrably discriminate. ──

test_that("regression: the Occam log-det term carries a MINUS sign", {
  f <- .mnFixture()
  sigma <- 1.7
  lambda <- 0.35
  M <- crossprod(f$B) / sigma^2 + lambda * f$D
  logdetM <- as.numeric(determinant(M, logarithm = TRUE)[["modulus"]])
  expect_gt(abs(logdetM), 1)          # the mutant is not numerically degenerate

  got <- .mnSignalMarginal(f$B, f$y, sigma, lambda, f$D)
  flipped <- .mnShippedForm(f$B, f$y, sigma, lambda, f$D, logdetCoef = +0.5)
  expect_equal(got - flipped, -logdetM, tolerance = 1e-10)
  # A sign flip turns the Bayesian Occam penalty into a reward, biasing the
  # posterior SPREAD over alignments while leaving the mode roughly alone --
  # invisible to a recovery test, which is why it needs its own pin.
})

test_that("regression: the quadratic term carries a factor of one half", {
  f <- .mnFixture()
  sigma <- 1.7
  lambda <- 0.35
  M <- crossprod(f$B) / sigma^2 + lambda * f$D
  tBy <- crossprod(f$B, f$y) / sigma^2
  quad <- sum(tBy * solve(M, tBy))
  expect_gt(abs(quad), 0.01)

  got <- .mnSignalMarginal(f$B, f$y, sigma, lambda, f$D)
  noHalf <- .mnShippedForm(f$B, f$y, sigma, lambda, f$D, quadCoef = 1)
  expect_equal(got - noHalf, -0.5 * quad, tolerance = 1e-10)
})

test_that("regression: the log-lambda normaliser uses (p - 2), not p", {
  f <- .mnFixture()
  sigma <- 1.7
  lambda <- 0.35
  expect_true(lambda != 1)            # otherwise the two forms coincide

  got <- .mnSignalMarginal(f$B, f$y, sigma, lambda, f$D)
  # (p-2) is the RANK of D: the prior is flat on its 2-dim null space, so only
  # p-2 directions carry a lambda.
  expect_identical(.mnRank(f$D), f$p - 2L)
  usesP <- .mnShippedForm(f$B, f$y, sigma, lambda, f$D, lambdaExp = f$p)
  expect_equal(got - usesP, -log(lambda), tolerance = 1e-10)

  usesPminus1 <- .mnShippedForm(f$B, f$y, sigma, lambda, f$D,
                                lambdaExp = f$p - 1)
  expect_equal(got - usesPminus1, -0.5 * log(lambda), tolerance = 1e-10)
})

test_that("the core adds flexTerm with unit multiplicity", {
  # NOT a pin on the 1.5 coefficient. Both calls here are the real core
  # differing only in the flexTerm ARGUMENT, and the core adds it once, so the
  # gap below is an algebraic identity of any implementation that does. The
  # coefficient's correctness is pinned by the pdet test further up, which
  # compares against the definition; what neither reaches is the production
  # callers that COMPUTE it -- `src/MCMCEngine.cpp` and `R/ModelFunctions.R`
  # each build 1.5*(p-2)*log(scale) and D_a = scale^3*D_base from the state, and
  # a mutation there would pass every test in this file.
  f <- .mnFixture()
  scale <- 1.37
  Da <- scale^3 * f$D
  a <- .mnSignalMarginal(f$B, f$y, 1.7, 0.35, Da, 1.5 * (f$p - 2) * log(scale))
  b <- .mnSignalMarginal(f$B, f$y, 1.7, 0.35, Da, (f$p - 2) * log(scale))
  expect_equal(a - b, 0.5 * (f$p - 2) * log(scale), tolerance = 1e-10)
})

test_that("the PRODUCTION penalty .bsplinepen also has rank p - 2", {
  # The whole 0.5*(p-2)*log(lambda) normaliser rests on this one fact, and every
  # other test here uses the exact second-difference penalty rather than the
  # quadrature-built one the package actually fits with.
  knots <- seq(0, 1, length.out = 5L)
  D <- StratoBayes:::.bsplinepen(knots, 4L)
  p <- ncol(D)
  expect_identical(.mnRank(D), as.integer(p - 2L))
  expect_identical(qr(D)$rank, as.integer(p - 2L))

  extKnots <- c(rep(knots[1], 3L), knots, rep(knots[length(knots)], 3L))
  B <- splines::splineDesign(extKnots, seq(0.02, 0.98, length.out = 16L),
                             ord = 4L)
  expect_identical(ncol(B), p)
  set.seed(505)
  y <- stats::rnorm(nrow(B))
  expect_equal(.mnSignalMarginal(B, y, 1.7, 0.35, D),
               .mnRefMarginal(B, y, 1.7, 0.35, D) - .mnDropped(length(y), D),
               tolerance = 1e-10)
})


# ══ #582 layer 2 — the accept step's arithmetic ══════════════════════════════
#
# Separate concern from the density: given (logPostOld, logPostNew, temperature,
# logHastings), does the accept step combine them correctly? Fixed numbers only
# -- never an acceptance rate, which cost-aware proposal reweighting makes
# non-reproducible across runs of the same seed and build (RT-323, wontfix).

test_that(".AcceptProposal tempers the DIFFERENCE, logHastings after", {
  # `.AcceptProposal` draws runif(1) exactly once on the finite branch, so
  # replaying the seed recovers the threshold the implementation saw and each
  # decision below is exact rather than a rate.
  set.seed(582L)
  u <- stats::runif(1)

  # Correct form: (new - old)/T, and only then plus logHastings.
  # Mutant A tempers the Hastings term too: (new - old + logHastings)/T.
  # Chosen so the two straddle u: log(u) + 0.3 against log(u) - 0.3.
  temperature <- 4
  logHastings <- 0.8
  old <- -50
  new <- old + temperature * (log(u) - 0.5)
  correct <- (new - old) / temperature + logHastings
  mutantA <- (new - old + logHastings) / temperature

  set.seed(582L)
  expect_true(StratoBayes:::.AcceptProposal(old, new, temperature, logHastings))
  expect_false(exp(mutantA) > u)      # the mutant would have rejected

  # Mutant B: tempering each term rather than the difference, new/T - old.
  old2 <- -1000
  new2 <- -1600
  temp2 <- 100
  expect_lt(exp((new2 - old2) / temp2), u)
  expect_gt(new2 / temp2 - old2, 0)   # mutant would accept unconditionally
  set.seed(582L)
  expect_false(StratoBayes:::.AcceptProposal(old2, new2, temp2))

  # T = 1 must be the plain Metropolis ratio.
  set.seed(582L)
  expect_true(StratoBayes:::.AcceptProposal(-10, -10 + log(u) + 0.3, 1))
  set.seed(582L)
  expect_false(StratoBayes:::.AcceptProposal(-10, -10 + log(u) - 0.3, 1))
})

test_that("a -Inf proposal rejects however large logHastings is", {
  # The -Inf branches short-circuit BEFORE logHastings is added, so a large
  # asymmetric-proposal correction cannot resurrect a zero-density proposal, and
  # -Inf never reaches an arithmetic comparison that would be NaN. The plain
  # -Inf/temperature combinations are covered by the accept-step test
  # above.
  expect_false(StratoBayes:::.AcceptProposal(
    logPostOld = -12.3, logPostNew = -Inf, temperature = 1, logHastings = 1e6))
  expect_true(StratoBayes:::.AcceptProposal(
    logPostOld = -Inf, logPostNew = -12.3, temperature = 1, logHastings = -1e6))
})


# The #338-shaped concern: the value used as "old" in the NEXT iteration's ratio
# must be the marginal recomputed at the post-sweep (sigma, lambda), not the
# pre-sweep one. Proof §B.2 calls this "the single most likely correctness slip
# in the port": the Gibbs sweep moves sigma and lambda, so a cached logPost is
# evaluated at the wrong nuisance values even when the alignment has not moved.
#
# Structural, not a rate: every iteration must satisfy the loop invariant
# `cs.logPost == the beta-marginal at the current (a, sigma, lambda)`, and at
# least one REJECTED iteration must show a changed logPost at an unchanged
# alignment -- which is only possible if the refresh happened.

.mnRefreshEngine <- function(td) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  priors <- list(alpha_site_2 = UniformPrior(-6, 12), alpha_site_3 = Fixed(4),
                 gammaLog_site_2 = Fixed(0), gammaLog_site_3 = Fixed(0))
  set.seed(5821)
  # sigmaFixed = FALSE and the default lambda prior so the sweep genuinely moves
  # the nuisance block; a pinned sigma/lambda would make staleness invisible.
  model <- StratModel(stratData1, priors = priors,
                      alignmentScale = stratModel1[["alignmentScale"]],
                      sedModel = stratModel1[["sedModel"]],
                      sigmaFixed = FALSE, flexibleKnots = FALSE,
                      knotRange = c(-12, 20))
  RunStratModel(stratData1, model, nIter = 10L, nChains = 1L, seed = 1L,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "mn582", engine = "cpp", nThreads = 1L)
  mcmc <- readRDS(file.path(td, "mn582_mcmc_run_1.rds"))
  if (is.null(model[[".logpost_cpp"]]))
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)

  # Freeze the kernel: Univariate only, factor 1, explicit SD. Driving
  # .sb_run_block directly bypasses RunStratModel's adaptation, so nothing here
  # depends on a reweighting schedule.
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, "Univariate"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
  pw[, ] <- 1
  mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw
  pf <- mcmc[[c("metro", "proposalFactor")]]
  pf[, ] <- 1
  mcmc[[c("metro", "proposalFactor")]] <- pf
  ua <- mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]]
  ua[] <- 0.5
  mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]] <- ua

  set.seed(4242L)
  StratoBayes:::.sb_create_engine(stratData1, model, mcmc,
                                  mcmc[["recentState"]])
}

test_that("the stored logPost is the marginal REFRESHED after the sweep", {
  td <- file.path(tempdir(),
                  paste0("mn582_", as.integer(stats::runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  e <- .mnRefreshEngine(td)

  nIter <- 40L
  gaps <- numeric(nIter)
  rejected <- 0L
  acceptedCount <- 0L
  refreshedOnReject <- 0L
  prevPar <- NULL
  prevLogPost <- NULL
  for (i in seq_len(nIter)) {
    StratoBayes:::.sb_run_block(e, 1L)
    st <- StratoBayes:::.sb_extract_state(e)[[1]]
    par <- st[[c("metro", "parameters")]]
    logPost <- st[[c("metro", "logPost")]]

    # The invariant: recomputing the marginal from scratch at the state the
    # engine is now in reproduces what it stored.
    gaps[i] <- abs(logPost - as.numeric(StratoBayes:::.sb_eval_logpost(
      e, 1L, par, debug = FALSE, marginal = TRUE)))

    accepted <- isTRUE(st[[c("metro", "accept")]])
    # Only from the second iteration on: a rejection needs a predecessor to be
    # compared against, so counting the first one would put `rejected` ahead of
    # `refreshedOnReject` by one whenever the RNG stream happens to reject there.
    if (!is.null(prevPar)) {
      if (accepted) {
        acceptedCount <- acceptedCount + 1L
      } else {
        rejected <- rejected + 1L
        if (identical(par, prevPar) && abs(logPost - prevLogPost) > 1e-8)
          refreshedOnReject <- refreshedOnReject + 1L
      }
    }
    prevPar <- par
    prevLogPost <- logPost
  }

  expect_lt(max(gaps), 1e-8)
  # Discrimination: a stale logPost would be unchanged across a rejection, since
  # the alignment is unchanged. Requiring every rejection to show a moved value
  # is what makes the invariant above non-vacuous.
  expect_gt(rejected, 0L)
  # And at least one acceptance, so the invariant is rehearsed on the swap path
  # too and not only on the retained-alignment one.
  expect_gt(acceptedCount, 0L)
  expect_identical(refreshedOnReject, rejected)

  # And the marginal flag is load-bearing: the joint-at-beta
  # log-posterior at the same state is a different number, so the
  # invariant is not passing by virtue of the two evaluations being
  # trivially the same quantity.
  st <- StratoBayes:::.sb_extract_state(e)[[1]]
  joint <- as.numeric(StratoBayes:::.sb_eval_logpost(
    e, 1L, st[[c("metro", "parameters")]], debug = FALSE, marginal = FALSE))
  expect_gt(abs(joint - st[[c("metro", "logPost")]]), 1)
})
