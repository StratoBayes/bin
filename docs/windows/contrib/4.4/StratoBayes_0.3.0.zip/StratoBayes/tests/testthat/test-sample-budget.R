# Issue #129 stage 5: the ceiling on a run's sample store.
#
# Pure numbers, so this runs on every PR.

test_that("the reachable ESS is half the store", {
  # Successive draws are never independent, so a store of n draws carries an
  # effective sample size below n. `RunStratModel()` refuses an `ess` target
  # above this rather than spinning against something unreachable.
  expect_identical(.ReachableEss(), .kMaxStoreDefault / 2)
  expect_identical(.ReachableEss(4096L), 2048)

  withr::local_options(StratoBayes.maxStore = 4096L)
  expect_identical(.ReachableEss(), 2048)
})

test_that("the budget message says the run did not converge, and the way past it", {
  msg <- .SampleBudgetMessage(.kMaxStoreDefault)

  expect_match(msg, "WITHOUT converging")
  expect_match(msg, as.character(.kMaxStoreDefault))
  expect_match(msg, "maxStore")
})
