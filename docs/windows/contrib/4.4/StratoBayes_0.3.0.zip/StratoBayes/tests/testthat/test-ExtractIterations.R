test_that("ExtractIterations works", {

  # errors
  expect_error(ExtractIterations(stratPosterior1, runs = 4),
               "runSelect. vector must contain whole numbers")
  expect_error(ExtractIterations(stratPosterior1, burnIn = -1),
               "burnIn must")
})

test_that("ExtractIterations() delegates runs= to .ValidateRunSelect and rejects NA (RT-476)", {
  # ExtractIterations() had its own inline `runSelect[1] == "all"` copy of the
  # NA guard .ValidateRunSelect() already carries; NA == "all" NA-poisons to
  # `if (NA)` -- "missing value where TRUE/FALSE needed"
  expect_error(ExtractIterations(stratPosterior1, runs = NA),
               "`runSelect` cannot contain NA")
  expect_error(ExtractIterations(stratPosterior1, runs = c(1, NA)),
               "`runSelect` cannot contain NA")
  expect_error(ExtractIterations(stratPosterior1, runs = NULL),
               "`runSelect` cannot be NULL")
})

test_that("ExtractIterations() rejects NA_real_ burnIn instead of crashing with an opaque error (RT-477)", {
  # is.numeric(NA_real_) is TRUE and length(.) == 1, so `burnIn < 0` NA-poisons
  # to `if (NA)` -- "missing value where TRUE/FALSE needed". A logical NA was
  # already handled cleanly (is.numeric(NA) is FALSE), which is preserved here.
  expect_error(ExtractIterations(stratPosterior1, burnIn = NA_real_),
               "burnIn must")
  expect_error(ExtractIterations(stratPosterior1, burnIn = NA),
               "burnIn must")
})

test_that("ExtractIterations works continued", {
  # trigger edge case were last iterations are not saved
  stratPosterior1modified <- stratPosterior1
  stratPosterior1modified$mcmcSummary$saveIter[[1]] <- stratPosterior1modified[[c("mcmcSummary", "saveIter")]][[1]][-201]
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 4999, runs = 1),
               "all iterations were discarded")
  expect_error(ExtractIterations(stratPosterior1modified, burnIn = 0.999),
               "all iterations were discarded")
  # burnIn
  iter <- ExtractIterations(stratPosterior1, burnIn = 0.9999)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, burnIn = 1)
  expect_equal(sapply(iter,length),
               rep(length(stratPosterior1[[c("mcmcSummary", "saveIter")]][[1]]) - 1,3))

  # iterations
  iter <- ExtractIterations(stratPosterior1, iterations = 25)
  expect_equal(sapply(iter,length), c(1,1,1))
  iter <- ExtractIterations(stratPosterior1, iterations = 1:100)
  expect_equal(sapply(iter,length), c(5,5,5))
  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, 1))
  expect_equal(sapply(iter,length), c(5,3,1))

  iter <- ExtractIterations(stratPosterior1, iterations =
                               list(1:100, 1:50, NULL))
  expect_equal(sapply(iter,length), c(5,3,0))

  # runSelect
  iter <- ExtractIterations(stratPosterior1, iterations = 25,
                             runs = c(1,3))
  expect_equal(sapply(iter,length), c(1,0,1))

  # cut iterations to maxSamples
  iter <- ExtractIterations(stratPosterior1, iterations = 1:1000,
                             maxSamples = 5)
  expect_equal(sum(sapply(iter,length)), 5)

  # alignment
  iter <- ExtractIterations(stratPosterior5a, alignment = 0:3)
  expect_equal(sapply(iter,length), rep(200, 3), tolerance = 0.1)

  iter <- ExtractIterations(stratPosterior2, alignment = 1, iterations = 100:200)
  iterN <- sum(sapply(iter,length))
  expect_true(iterN >= 1 && iterN <= 12)

  clustNew <- Cluster(stratPosterior1, runs = 2:3, iterations = 3900:4000)
  expect_true(any(
    ExtractIterations(stratPosterior1, alignment = 1, stratCluster = clustNew, burnIn = 0.95)[[2]]
    %in% 157:161))
  expect_equal(
    ExtractIterations(stratPosterior1, alignment = "all", stratCluster = clustNew, burnIn = 0.95)[[2]],
    192:201)
})

# A shipped fixture's `.cache` is empty, and it also carries a precomputed
# `stratCluster` element; `.WithClusterCache()` (helper-cluster-cache.R)
# pre-populates the cache from it, so the memoisation path starts where it
# would on an object that had already been clustered. samples <=
# maxClusterSamples, so proto clustering is deterministic.

test_that(".ClusterInternal memoises clustering on the object's .cache", {
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]
  runSelect <- seq_len(nRun)
  sr <- ExtractIterations(sp, "all", burnIn = 0.9, NULL, 2000, runSelect)

  cached <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, sr)
  # entry was stored on the object's cache
  expect_length(ce$clusterCache, 1)

  # cached result matches a fresh computation with the same inputs (compare the
  # meaningful components rather than whole-object identity)
  direct <- Cluster.StratPosterior(sp, burnIn = 0.9, iterations = NULL,
                                   maxSamples = 2000, runs = runSelect, selectRows = sr)
  expect_equal(cached[["cluster"]], direct[["cluster"]])
  expect_equal(cached[["rowIndex"]], direct[["rowIndex"]])
  expect_equal(cached[["nClust"]], direct[["nClust"]])

  # second call with identical inputs returns the stored object (hit path)
  cached2 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, sr)
  expect_identical(cached2, cached)
  expect_length(ce$clusterCache, 1)
})

test_that(".ClusterInternal with NULL selectRows is keyed on burnIn", {
  # Regression: a NULL-selectRows cache keyed only on selectRows would serve a
  # stale clustering when burnIn changes (e.g. the GUI burn-in slider).
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  nRun <- sp[["nRun"]]
  runSelect <- seq_len(nRun)

  cLow  <- StratoBayes:::.ClusterInternal(sp, 0.5, NULL, 2000, runSelect, NULL)
  cHigh <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, NULL)
  # different burn-in selects different rows, so the clustering must differ
  expect_false(identical(cLow[["rowIndex"]], cHigh[["rowIndex"]]))
  expect_length(ce$clusterCache, 2)

  # repeating burnIn = 0.9 hits the cache rather than recomputing
  cHigh2 <- StratoBayes:::.ClusterInternal(sp, 0.9, NULL, 2000, runSelect, NULL)
  expect_identical(cHigh2, cHigh)
  expect_length(ce$clusterCache, 2)
})

test_that("proportional burnIn discards the requested fraction per run regardless of nThin (RT-190)", {
  # Run A: nThin = 100 -> 10 saved rows over 1000 iterations.
  # Run B: nThin = 10  -> 100 saved rows over 1000 iterations.
  # A row-index-based burn-in (computed from the shortest run, A) applied
  # verbatim to B under-discards B's warm-up when B has more saved rows.
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(seq(100, 1000, by = 100), seq(10, 1000, by = 10)),
      completedIter = c(1000, 1000)
    )
  )

  selectRows <- ExtractIterations(fakePosterior, burnIn = 0.5, runs = "all")

  # Run A (10 rows): expect exactly the last 50% (5 rows) retained.
  expect_length(selectRows[[1]], 5)
  # Run B (100 rows): expect exactly the last 50% (50 rows) retained, not the
  # ~5% that the row-index bug produced.
  expect_length(selectRows[[2]], 50)

  # Both runs should discard iterations <= 500 (the absolute 50% threshold).
  saveIterA <- fakePosterior[[c("mcmcSummary", "saveIter")]][[1]]
  saveIterB <- fakePosterior[[c("mcmcSummary", "saveIter")]][[2]]
  expect_true(all(saveIterA[selectRows[[1]]] > 500))
  expect_true(all(saveIterB[selectRows[[2]]] > 500))
})

test_that("absolute burnIn warns (not errors) when it fully discards one of several runs (RT-417)", {
  # Run 1: 100 saved rows, completed to iteration 1000.
  # Run 2: 50 saved rows, completed to iteration 500 (a shorter run).
  # Pre-fix, the guard checked burnIn only against saveIterCompletedMax (run 1,
  # the run with the most saved rows) and passed (rows > 800 survive there),
  # silently leaving run 2 (whose iterations never exceed 500) with zero
  # selected rows and no warning at all.
  #
  # This must WARN, not error: TracePlot()/ScatterPlot()/hist.StratPosterior()/
  # BeanPlot()/boxplot() all call ExtractIterations() and tolerate a subset of
  # runs contributing zero rows (TracePlot's own guard only errors when EVERY
  # selected run is empty) - hard-erroring here would break that established,
  # working pattern for every one of those callers.
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(seq(10, 1000, by = 10), seq(10, 500, by = 10)),
      completedIter = c(1000, 500)
    )
  )

  expect_warning(
    selectRows <- ExtractIterations(fakePosterior, burnIn = 800, runs = "all"),
    "run\\(s\\) 2"
  )
  expect_true(length(selectRows[[1]]) > 0)
  expect_length(selectRows[[2]], 0)

  # A burnIn that leaves rows in both runs is unaffected (no warning).
  expect_no_warning(
    selectRows <- ExtractIterations(fakePosterior, burnIn = 400, runs = "all")
  )
  expect_true(length(selectRows[[1]]) > 0)
  expect_true(length(selectRows[[2]]) > 0)
})

test_that("absolute burnIn tolerates NA within a run's own saveIter without crashing (RT-417)", {
  # `!any(x > burnIn)` returns NA (not FALSE/TRUE) whenever x contains NA and
  # none of its non-NA values exceed burnIn, which would otherwise make
  # `if (any(runsFullyDiscarded))` throw "missing value where TRUE/FALSE
  # needed" instead of behaving like any other run whose data doesn't survive
  # burnIn. Put the NA mid-sequence (not last) so it survives truncation to
  # that run's own completedIterIndex.
  saveIter2 <- c(seq(10, 240, by = 10), NA, seq(260, 500, by = 10))
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(seq(10, 1000, by = 10), saveIter2),
      completedIter = c(1000, 500)
    )
  )

  expect_warning(
    selectRows <- ExtractIterations(fakePosterior, burnIn = 800, runs = "all"),
    "run\\(s\\) 2"
  )
  expect_true(length(selectRows[[1]]) > 0)
  expect_length(selectRows[[2]], 0)
})

test_that("absolute burnIn validates against the highest completed ITERATION, not the most saved ROWS (RT-709/#899)", {
  # Run 1: nThin = 1, 600 saved rows, completed to iteration 600 (most ROWS).
  # Run 2: nThin = 10, 500 saved rows, completed to iteration 5000 (highest
  # completed ITERATION, but fewer rows). Pre-fix, the guard validated
  # `burnIn` against `saveIterCompletedMax` picked by
  # `which.max(completedIterIndex)` (row count) -> run 1 -> whose whole
  # `saveIter` (1:600) never clears burnIn = 700, so the search hard-aborts
  # even though run 2 has hundreds of usable rows past 700.
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(1:600, seq(10, 5000, by = 10)),
      completedIter = c(600, 5000)
    )
  )

  expect_warning(
    selectRows <- ExtractIterations(fakePosterior, burnIn = 700, runs = "all"),
    "run\\(s\\) 1"
  )
  expect_length(selectRows[[1]], 0)
  expect_true(length(selectRows[[2]]) > 0)
})

test_that("burnIn's discard-all warning does not fire when `iterations` supersedes it (RT-711/#901)", {
  # burnIn = 700 would discard every one of run 1's saved rows on its own
  # (max saveIter is 500) - but `iterations` supersedes `burnIn` entirely for
  # row selection, and `iterations = c(100, 200)` actually DOES select 2 rows
  # from run 1. A warning claiming burnIn "discards all saved iterations" for
  # run 1 is simply wrong once `iterations` is supplied: burnIn played no
  # part in the selection.
  fakePosterior <- list(
    nRun = 2,
    mcmcSummary = list(
      saveIter = list(seq(10, 500, by = 10), seq(10, 5000, by = 10)),
      completedIter = c(500, 5000)
    )
  )

  expect_no_warning(
    selectRows <- ExtractIterations(fakePosterior, burnIn = 700,
                                     iterations = c(100, 200))
  )
  expect_length(selectRows[[1]], 2)
})

test_that(".maxSampleDeterministicRows warns when floor-division allocates 0 rows to a minority run (RT-038)", {
  # Highly skewed row counts: floor((5 / 10000) * 100) == 0 for the two
  # minority runs, silently producing integer(0) selections.
  selectRows <- list(1:9990, 1:5, 1:5)
  expect_warning(
    out <- StratoBayes:::.maxSampleDeterministicRows(selectRows, maxIterations = 100),
    "0 rows"
  )
  expect_length(out[[2]], 0)
  expect_length(out[[3]], 0)
  expect_length(out[[1]], 100)

  # no warning when every run with rows gets at least one allocated
  expect_no_warning(
    StratoBayes:::.maxSampleDeterministicRows(list(1:100, 1:100), maxIterations = 50)
  )
})

test_that(".maxSampleDeterministicRows rounds fractional row positions instead of truncating (RT-121)", {
  # seq(1, 101, length.out = 4) == 1, 34.333.., 67.666.., 101. Truncation (the
  # pre-fix behaviour) would retain position 67; rounding retains 68 - the two
  # differ, so this exercises the fix rather than a coincidental match.
  selectRows <- list(1:101)
  out <- StratoBayes:::.maxSampleDeterministicRows(selectRows, maxIterations = 4)
  expect_equal(out[[1]], c(1L, 34L, 68L, 101L))
})

test_that("ExtractIterations coerces runSelect to integer before keying the cluster cache (RT-251)", {
  # .ValidateRunSelect (used by summary()/plot()) always returns an integer
  # runSelect. ExtractIterations()/ExtractParameters() called directly with a
  # double `runs` vector (e.g. c(1,3) rather than 1:3) must canonicalise to
  # the same storage type before it reaches .ClusterInternal's cache key, or
  # logically identical selections key differently depending on the caller.
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")

  ExtractIterations(sp, alignment = 1, burnIn = 0.9, runs = c(1, 3))
  expect_length(ce$clusterCache, 1)
  # `runSelect` itself left the key when the memo moved into
  # `Cluster.StratPosterior()` (#1605), which makes the two storage types
  # dedupe whether or not it is coerced. The coercion is still owed, because
  # `runSelect` is now *reported*: assert it there instead. This is a
  # substitution for RT-251's original oracle, not a restoration of it.
  cl <- ExtractIterations(sp, alignment = 1, burnIn = 0.9, runs = c(1, 3),
                          stratCluster = NULL)
  expect_length(ce$clusterCache, 1)
  reported <- ce$clusterCache[[1]]$value[[c("options", "runSelect")]]
  expect_true(is.integer(reported))
  expect_equal(reported, c(1L, 3L))
})

test_that(".StripKeyAttr strips a list's own names, not just its elements' attributes (RT-420)", {
  # A named `iterations` list (e.g. iterations = list(run1 = 1:100, run2 =
  # 101:200)) is never consumed by name anywhere in ExtractIterations() -
  # only positionally - so it must key identically to the equivalent unnamed
  # list, or a caller happening to pass names causes a spurious cache miss.
  named <- StratoBayes:::.StripKeyAttr(list(run1 = 1:100, run2 = 101:200))
  unnamed <- StratoBayes:::.StripKeyAttr(list(1:100, 101:200))
  expect_identical(named, unnamed)
})

test_that(".StripKeyAttr returns attribute-free vectors, including from attribute-carrying input", {
  x <- structure(c(a = 1, b = 2, c = 3), .match.hash = "stamp", extra = 1L)
  y <- StratoBayes:::.StripKeyAttr(x)
  expect_null(attributes(y))
  expect_identical(y, c(1, 2, 3))

  nested <- StratoBayes:::.StripKeyAttr(list(a = x, b = matrix(1:4, 2)))
  expect_null(names(nested))
  expect_null(attributes(nested[[1]]))
  expect_null(attributes(nested[[2]]))
})

test_that(".ClusterInternal's fast-path probe does not force a default clustering on a true cache miss (RT-421)", {
  # Reading `stratPosterior[[c("stratCluster", "rowIndex")]]` dispatches to
  # `[[.StratPosterior`, which computes and stores a full *default* clustering
  # (maxSamples = 10000 etc.) as a side effect whenever cache$stratCluster is
  # NULL - wasted work when the caller's selection isn't the default, and the
  # probe discards the result anyway. Assert the mechanism directly: a probe
  # against a genuinely empty cache must not populate cache$stratCluster.
  sp <- .WithClusterCache(stratPosterior2)
  ce <- .subset2(sp, ".cache")
  ce$stratCluster <- NULL

  nRun <- sp[["nRun"]]
  runSelect <- seq_len(nRun)
  sr <- ExtractIterations(sp, "all", burnIn = 0.7, NULL, 20, runSelect)

  StratoBayes:::.ClusterInternal(sp, 0.7, NULL, 20, runSelect, sr)

  expect_null(ce$stratCluster)
  # Trade-off worth recording: in the all-defaults case, the old probe forced
  # cache$stratCluster to populate and could then hit it directly, whereas
  # this fix stores the result only in clusterCache - a later
  # `stratPosterior[["stratCluster"]]` access still computes once more via
  # `[[.StratPosterior`'s own lazy path. Net: 2 computes instead of 1 for
  # that one case, in exchange for never forcing a mismatched default
  # clustering for every other (non-default) case.
})
