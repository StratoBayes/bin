# Regression tests for the Hastings correction of the state-dependent,
# asymmetric MH proposals (RT-096/163 R engine; RT-256/257 C++ twins).
#
# Two default proposal types have a proposal density that depends on the current
# position, so q(x*|x) != q(x|x*):
#   * Multivariate    — jumps under the covariance of the cluster NEAREST the
#                       current position; the covariance differs by direction.
#   * NeighbourScaled — per-parameter SD is the gap to the current sorted
#                       neighbours / 8; the gaps change after the move.
# Omitting the Hastings term log q(x|x*) - log q(x*|x) biases the stationary
# distribution. These tests (a) pin the density against an independent
# computation in both directions, and (b) show, through the package's own
# .AcceptProposal, that the correction recovers a known target that the
# uncorrected sampler visibly distorts. The cross-engine equality tests proving
# the C++ densities match the R densities to machine tolerance are at the bottom
# of THIS file.
#
# What this file deliberately does NOT cover: whether the closed forms match the
# distribution the proposers actually SAMPLE. Every check here is
# analytic-vs-analytic, so a formula that is self-consistent, agrees across both
# engines, and still describes a different kernel than the RNG draws would pass
# (that is precisely the RT-162 M vs M^-1 failure mode, which survived review in
# this repo once). That gap is closed by
# dev/red-team/heavy-tests/RT-412-qratio-density-simulation.R, which estimates
# the densities non-parametrically from the proposers' own draws. Run it when
# touching any of these kernels.

# minimal `model` carrying only the fields the proposer/density helpers read
.mkQRatioModel <- function(free, nParam, alpha = integer(0), gamma = integer(0)) {
  list(ind = list(paramNotFixed = as.integer(free),
                  alpha = as.integer(alpha), gamma = as.integer(gamma)),
       parametersLength = as.integer(nParam),
       parametersLengthNotFixed = length(free))
}

# independent zero-mean MVN log density via det()/solve() — a different code
# path from .MvnLogDensity's chol()/backsolve(), so agreement is a real check.
.mvnLogRef <- function(x, S) {
  k <- length(x)
  -0.5 * (k * log(2 * pi) + log(det(S)) + as.numeric(t(x) %*% solve(S) %*% x))
}


# ── Multivariate: density pinned in both directions ─────────────────────────

test_that("multivariate proposal density matches an independent MVN, both directions (RT-096/256)", {
  model <- .mkQRatioModel(free = c(1L, 2L), nParam = 2L)
  C1 <- diag(c(0.25, 1))
  C2 <- diag(c(4, 1))
  # centres differ only in coord 1, so the nearest cluster is decided by sign(x1)
  proposeArg <- list(list(c(-4, 0), C1), list(c(4, 0), C2))
  pf <- 1
  df <- 1

  xFrom <- c(-3, 0.2)   # nearest cluster 1  -> forward uses C1
  xTo   <- c( 3, -0.1)  # nearest cluster 2  -> reverse uses C2

  S1 <- df * pf * C1
  diag(S1) <- diag(S1) + 1e-10
  S2 <- df * pf * C2
  diag(S2) <- diag(S2) + 1e-10

  fwd <- .ProposalLogDensity("Multivariate", model, xFrom, xTo, proposeArg, pf, df)
  rev <- .ProposalLogDensity("Multivariate", model, xTo, xFrom, proposeArg, pf, df)

  expect_equal(fwd, .mvnLogRef(xTo - xFrom, S1))   # forward centred/shaped at xFrom
  expect_equal(rev, .mvnLogRef(xFrom - xTo, S2))   # reverse centred/shaped at xTo

  # The two directions use different covariances, so the correction is non-zero
  # and, crucially, not the naive symmetric 0.
  expect_gt(abs(rev - fwd), 1)

  # .MvnLogDensity itself agrees with the reference.
  expect_equal(.MvnLogDensity(xTo - xFrom, S1), .mvnLogRef(xTo - xFrom, S1))
})


# ── NeighbourScaled: density pinned in both directions ──────────────────────

test_that("neighbour-scaled proposal density matches independent normals, both directions (RT-163/257)", {
  model <- .mkQRatioModel(free = 1:3, nParam = 3L, alpha = 1:3)
  fallback <- c(1, 1, 1)
  pf <- 1
  df <- 1
  xF <- c(0, 1, 5)
  xT <- c(0.1, 3, 5.2)

  nsSDref <- function(vals) {
    ord <- order(vals)
    gaps <- diff(vals[ord])
    n <- length(vals)
    sd <- numeric(n)
    for (j in seq_len(n)) {
      s <- if (n == 2) gaps[1] / 8 else if (j == 1) gaps[1] / 8 else
        if (j == n) gaps[n - 1] / 8 else (gaps[j - 1] + gaps[j]) / 16
      sd[ord[j]] <- max(abs(s), fallback[ord[j]] * 0.01)
    }
    sd
  }
  sdF <- nsSDref(xF)
  sdT <- nsSDref(xT)

  fwd <- .ProposalLogDensity("NeighbourScaled", model, xF, xT, fallback, pf, df)
  rev <- .ProposalLogDensity("NeighbourScaled", model, xT, xF, fallback, pf, df)

  expect_equal(fwd, sum(dnorm(xT - xF, 0, pf * sdF, log = TRUE)))
  expect_equal(rev, sum(dnorm(xF - xT, 0, pf * sdT, log = TRUE)))

  # SD field genuinely depends on the state (sorted gaps change), so q is
  # asymmetric and the helper matches the proposer's field exactly.
  expect_equal(.NeighbourScaledSDs(xF, fallback, model), sdF)
  expect_false(isTRUE(all.equal(sdF, sdT)))
  expect_true(abs(rev - fwd) > 1e-6)
})


# ── .ProposalLogDensity is a no-op for symmetric proposals ──────────────────

test_that(".ProposalLogDensity returns 0 for symmetric proposal types", {
  model <- .mkQRatioModel(free = c(1L, 2L), nParam = 2L)
  expect_identical(
    .ProposalLogDensity("Univariate", model, c(0, 0), c(1, 1), NULL, 1, 1), 0)
  expect_identical(
    .ProposalLogDensity("ShiftAlphas", model, c(0, 0), c(1, 1), NULL, 1, 1), 0)
})


# ── Multivariate: statistical recovery through the real accept rule ─────────
# Target N(0, I2). Proposal: nearest-cluster jump with C1 (narrow) for x1 < 0 and
# C2 (wide) for x1 > 0 — genuinely asymmetric across the x1 = 0 boundary. The
# correction must restore the symmetric target; omitting it visibly biases the
# x1 marginal (mass piles up on the narrow-step side).

test_that("multivariate Hastings correction recovers N(0, I2); omitting it biases (RT-096/256)", {
  model <- .mkQRatioModel(free = c(1L, 2L), nParam = 2L)
  proposeArg <- list(list(c(-4, 0), diag(c(0.25, 1))),
                     list(c( 4, 0), diag(c(4,    1))))
  pf <- 1
  df <- 1
  logPost <- function(x) sum(dnorm(x, log = TRUE))

  run <- function(useH, n = 1.2e5, seed = 1) {
    set.seed(seed)
    x <- c(0, 0)
    lpx <- logPost(x)
    keep <- matrix(0, n, 2)
    for (i in seq_len(n)) {
      xs  <- .ProposeMultivariate(1, x, proposeArg, pf, df, model)
      lps <- logPost(xs)
      lh  <- if (useH)
        .ProposalLogDensity("Multivariate", model, xs, x, proposeArg, pf, df) -
        .ProposalLogDensity("Multivariate", model, x, xs, proposeArg, pf, df) else 0
      if (.AcceptProposal(lpx, lps, 1, logHastings = lh)) {
        x <- xs
        lpx <- lps
      }
      keep[i, ] <- x
    }
    keep[-seq_len(n %/% 5), , drop = FALSE]
  }

  corrected <- run(TRUE)
  expect_equal(mean(corrected[, 1]), 0, tolerance = 0.05)
  expect_equal(sd(corrected[, 1]),   1, tolerance = 0.05)
  expect_equal(mean(corrected[, 1] > 0), 0.5, tolerance = 0.04)

  uncorrected <- run(FALSE)
  # Pre-fix behaviour: the x1 marginal is skewed toward the narrow-step half.
  expect_lt(mean(uncorrected[, 1]), -0.3)
  expect_lt(mean(uncorrected[, 1] > 0), 0.40)
})


# ── NeighbourScaled: statistical recovery through the real accept rule ──────
# Target N(0, 2) on three "alphas". The gap-scaled SDs make the proposal
# asymmetric; without the correction the chain collapses the gaps and comes out
# badly under-dispersed. With it, the marginal SDs return to 2.

test_that("neighbour-scaled Hastings correction recovers the target spread; omitting it under-disperses (RT-163/257)", {
  model <- .mkQRatioModel(free = 1:3, nParam = 3L, alpha = 1:3)
  fallback <- c(1, 1, 1)
  pf <- 4
  df <- 1
  logPost <- function(x) sum(dnorm(x, 0, 2, log = TRUE))

  run <- function(useH, n = 1e5, seed = 7) {
    set.seed(seed)
    x <- c(-1, 0, 1)
    lpx <- logPost(x)
    keep <- matrix(0, n, 3)
    for (i in seq_len(n)) {
      xs  <- .ProposeNeighbourScaled(1, x, fallback, pf, df, model)
      lps <- logPost(xs)
      lh  <- if (useH)
        .ProposalLogDensity("NeighbourScaled", model, xs, x, fallback, pf, df) -
        .ProposalLogDensity("NeighbourScaled", model, x, xs, fallback, pf, df) else 0
      if (.AcceptProposal(lpx, lps, 1, logHastings = lh)) {
        x <- xs
        lpx <- lps
      }
      keep[i, ] <- x
    }
    keep[-seq_len(n %/% 5), , drop = FALSE]
  }

  corrected <- run(TRUE)
  expect_equal(sd(corrected[, 1]), 2, tolerance = 0.15)
  expect_equal(sd(corrected[, 2]), 2, tolerance = 0.15)
  expect_equal(sd(corrected[, 3]), 2, tolerance = 0.15)

  uncorrected <- run(FALSE)
  # Pre-fix behaviour: gaps collapse, every marginal is far too narrow.
  expect_lt(max(apply(uncorrected, 2, sd)), 1.6)
})


# ── Cross-engine equality: C++ kernels match the R kernels ──────────────────
# The R q-ratio is validated statistically above. This proves the C++ engine
# computes the SAME proposal densities to machine tolerance, so the two engines
# stay mathematically identical (the reason RT-096/163/256/257 are one fix). The
# hooks call the engine's actual kernels (mvn_log_density, neighbour SD field).

test_that("C++ MVN log-density kernel matches the R kernel to machine tolerance (RT-096/256)", {
  set.seed(101)
  for (k in c(1L, 2L, 3L, 5L)) {
    A <- matrix(rnorm(k * k), k, k)
    S <- crossprod(A) + diag(k)          # SPD
    x <- rnorm(k)
    expect_equal(.sb_mvn_log_density_cpp(x, S), .MvnLogDensity(x, S),
                 tolerance = 1e-10,
                 info = sprintf("k = %d", k))
  }
  # Also match on the exact scaled + ridged covariance the multivariate proposal
  # builds, so both engines agree on the actual proposal density.
  C <- diag(c(0.25, 1))
  S <- 1 * 1 * C
  diag(S) <- diag(S) + 1e-10
  d <- c(0.7, -1.3)
  expect_equal(.sb_mvn_log_density_cpp(d, S), .MvnLogDensity(d, S), tolerance = 1e-10)
})

# NOTE: an end-to-end wiring guard that drives the real engine and asserts on the
# multivariate-dominant posterior lives in
# dev/red-team/heavy-tests/RT-256-257-qratio-wiring.R (not in this fast suite).
# It uses a platform-robust *relative* check — a multivariate-only sampler and a
# univariate-only sampler of the same target must agree — rather than absolute
# posterior values, which are not portable across RNG platforms (a short-chain
# value threshold here failed on CI while passing locally). The tests in this
# file therefore cover the kernels and the accept rule; the assembled term inside
# the engine's update step is covered by that heavy test plus code inspection.

# ── RT-412: the Cholesky-failure branch must price BACTRIAN, not a Gaussian ──
# `propose_multivariate` falls back to independent *Bactrian* steps with
# sd = sqrt(diag(sigma)) when LAPACK cannot factor the scaled cluster covariance.
# An earlier revision of this branch priced that case as a diagonal Gaussian, so
# the Hastings term was a ratio of two *different* kernels — and because the
# branch is selected from the from-state, it can be taken in one direction only.

test_that("mvn log density prices the Bactrian fallback on a singular sigma (RT-412)", {
  S <- matrix(c(1, 1, 1, 1), 2, 2)   # rank 1 => dpotrf fails
  x <- c(0.7, -1.3)
  m <- 0.95

  # Independent reference: product of two-component Bactrian mixture densities.
  bactrianLogDens <- function(t, sd, m) {
    s <- sd * sqrt(1 - m * m)
    log(0.5 * dnorm(t, m * sd, s) + 0.5 * dnorm(t, -m * sd, s))
  }
  ref <- sum(mapply(bactrianLogDens, x, sqrt(diag(S)), m))
  expect_equal(.sb_mvn_log_density_cpp(x, S, m), ref, tolerance = 1e-12)

  # DISCRIMINATION: the pre-fix answer was the diagonal Gaussian. Without a
  # material gap the assertion above would be vacuous.
  gaussian <- sum(dnorm(x, 0, sqrt(diag(S)), log = TRUE))
  expect_gt(abs(ref - gaussian), 1)

  # m = 0 is the one case where the sampler really does draw a Gaussian
  # (ThreadRNG::bactrian delegates to rnorm), so the density must follow.
  expect_equal(.sb_mvn_log_density_cpp(x, S, 0), gaussian, tolerance = 1e-12)

  # The Bactrian density must normalise to 1 and have variance sd^2 (the whole
  # point of the kernel). A mispriced mixture weight or a wrong `s` shows up
  # here even when a single point value looks plausible.
  for (sd in c(0.3, 1, 4)) {
    dens <- function(t) exp(vapply(t, bactrianLogDens, numeric(1), sd = sd, m = m))
    expect_equal(integrate(dens, -Inf, Inf)$value, 1, tolerance = 1e-6)
    expect_equal(integrate(function(t) t^2 * dens(t), -Inf, Inf)$value,
                 sd^2, tolerance = 1e-6)
  }
})

test_that("a positive-definite sigma is unaffected by the fallback change (RT-412)", {
  # Guards against the fallback edit perturbing the ordinary path.
  set.seed(4120)
  for (k in c(1L, 2L, 4L)) {
    A <- matrix(rnorm(k * k), k, k)
    S <- crossprod(A) + diag(k)
    x <- rnorm(k)
    expect_equal(.sb_mvn_log_density_cpp(x, S), .MvnLogDensity(x, S),
                 tolerance = 1e-10, info = sprintf("k = %d", k))
    # bactrianM is ignored entirely when the Cholesky succeeds
    expect_identical(.sb_mvn_log_density_cpp(x, S, 0.95),
                     .sb_mvn_log_density_cpp(x, S, 0.10))
  }
})


test_that("C++ neighbour-scaled SD field matches the R field to machine tolerance (RT-163/257)", {
  model <- .mkQRatioModel(free = 1:5, nParam = 6L, alpha = 1:3, gamma = 4:5)
  fallback <- c(0.5, 0.5, 0.5, 0.3, 0.3, 1)
  set.seed(202)
  for (rep in 1:5) {
    params <- rnorm(6, sd = 3)
    rSD <- .NeighbourScaledSDs(params, fallback, model)
    # C++ takes 0-based group indices
    cppSD <- .sb_neighbour_scaled_sds_cpp(params, fallback,
                                          model[[c("ind", "alpha")]] - 1L,
                                          model[[c("ind", "gamma")]] - 1L)
    expect_equal(cppSD, rSD, tolerance = 1e-12, info = sprintf("rep %d", rep))
  }
})
