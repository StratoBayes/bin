# GH #1171: an inverse sedimentation rate that underflows to exactly zero was
# divided by, giving silent +/-Inf heights. The opposite extreme (an infinite
# rate) already warned and returned NA.

test_that("a zero inverse sedimentation rate warns and yields NA, not +/-Inf", {
  data("stratPosterior1", package = "StratoBayes")
  pars <- ExtractParameters(stratPosterior1)[1, ]
  # `.AdjustParams()` computes exp(-gammaLog), so +800 underflows to exactly 0
  pars[["gammaLog_site_2"]] <- 800

  # every partition of site 2 is affected, so the pre-existing "no well-defined
  # age limits" warning follows the new one
  expect_warning(
    expect_warning(
      res <- Tops(stratPosterior1, refHeights = c(1, 5, 9), parameters = pars),
      "zero inverse sedimentation rate"
    ),
    "well-defined age limits"
  )
  bad <- res[res$site == "site_2", "mean"]
  expect_true(all(is.na(bad)))
  expect_false(any(is.infinite(bad)))

  # the unaffected site is untouched
  good <- res[res$site == "site_3", "mean"]
  expect_true(all(is.finite(good)))
})

test_that("the infinite-rate extreme still behaves as before", {
  data("stratPosterior1", package = "StratoBayes")
  pars <- ExtractParameters(stratPosterior1)[1, ]
  pars[["gammaLog_site_2"]] <- -800
  expect_warning(
    res <- Tops(stratPosterior1, refHeights = c(1, 5, 9), parameters = pars),
    "well-defined age limits"
  )
  expect_true(all(is.na(res[res$site == "site_2", "mean"])))
})

test_that("ordinary draws raise no zero-rate warning", {
  data("stratPosterior1", package = "StratoBayes")
  expect_no_warning(Tops(stratPosterior1, refHeights = c(1, 5, 9)))
})
