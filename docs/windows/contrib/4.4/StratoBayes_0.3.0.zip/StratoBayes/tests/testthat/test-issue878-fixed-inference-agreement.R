# Regression test for RT-692 (#878): whether a prior counts as `Fixed` was
# decided by `inherits(prior, "Fixed")` in `R/StratModel.R`'s index-building
# (a class check) but by `identical(R, .fixed_R)` in `.InferPriorType()`
# (a function-identity check). A hand-built bare `Prior(.fixed_R, .fixed_D,
# .fixed_Q, value = v)` -- e.g. a legacy saved model, or `.fixed_R` reached
# via `:::` -- carries no "Fixed" class, so it was proposed as a free
# parameter by the sampler while both engines still scored it `PT_FIXED`
# (density 0), an improper flat prior over an unbounded parameter.
#
# Fix: `.IsFixedPrior()` is the single source of truth for fixed-ness,
# combining the class check and the `.InferPriorType()` fallback, used at
# every site that previously relied on `inherits(x, "Fixed")` alone.

test_that(".IsFixedPrior() recognises a properly-classed Fixed() prior", {
  expect_true(.IsFixedPrior(Fixed(3)))
})

test_that(".IsFixedPrior() recognises a declassed Fixed-shaped Prior() (RT-692, #878)", {
  bare <- Prior(.fixed_R, .fixed_D, .fixed_Q, value = 3)
  expect_false(inherits(bare, "Fixed"))
  expect_equal(.InferPriorType(bare), "Fixed")
  expect_true(.IsFixedPrior(bare))
})

test_that(".IsFixedPrior() rejects non-fixed priors", {
  expect_false(.IsFixedPrior(NormalPrior(0, 1)))
  expect_false(.IsFixedPrior(UniformPrior(0, 1)))
})

test_that("a declassed Fixed-shaped prior is not proposed as a free parameter (RT-692, #878)", {
  set.seed(0)
  rtData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  tData <- StratData(rtData$signal, parts = rtData$parts, ties = rtData$ties,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")

  bareFixed <- Prior(.fixed_R, .fixed_D, .fixed_Q, value = 20)

  priors <- structure(
    list(alpha_site1    = UniformPrior(min = 10, max = 60),
         alpha_site2    = bareFixed,
         alpha_site3    = UniformPrior(min = -10, max = 60),
         gammaLog_site1 = NormalPrior(mean = 1, sd = 1),
         gammaLog_site2 = NormalPrior(mean = 2, sd = 0.5),
         gammaLog_site3 = NormalPrior(mean = 3, sd = 2),
         gap_site2_1    = ExponentialPrior(rate = 0.1)),
    class = c("StratPrior", "list")
  )

  m <- StratModel(tData, priors = priors, alignmentScale = "age",
                   sedModel = "site", alphaPosition = "bottom")

  alphaSite2Index <- which(names(priors) == "alpha_site2")
  expect_false(alphaSite2Index %in% m[["ind"]][["paramNotFixed"]])
})
