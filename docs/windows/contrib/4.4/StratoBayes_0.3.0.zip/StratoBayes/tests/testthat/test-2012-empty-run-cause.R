# #2012: `completeIter = 0` has three unrelated causes, and the guard used to
# state the rarest of them -- an interrupted run's header-only file -- as fact.
# A user whose run merely started outside the support of its priors was sent to
# repair a file with nothing wrong with it.

Slice <- function(...) {
  rows <- rbind(...)
  array(rows, dim = c(nrow(rows), ncol(rows), 1, 1))
}

test_that(".EmptyRunCause() tells the three zero-row states apart (#2012)", {
  # Padding rows are wholly NA; a row the sampler wrote carries its labels.
  expect_equal(.EmptyRunCause(Slice(c(NA, NA, NA), c(NA, NA, NA)), 1L),
               "noRows")
  expect_equal(.EmptyRunCause(array(numeric(0), dim = c(0, 3, 1, 1)), 1L),
               "noRows")

  expect_equal(.EmptyRunCause(Slice(c(1, 1, NA), c(2, 1, 5), c(3, 1, 6)), 1L),
               "leadingGap")
  expect_equal(.EmptyRunCause(Slice(c(1, 1, NA), c(2, 1, NA)), 1L),
               "noneComplete")

  # -Inf is a legitimate out-of-support `logPostSep` component, not damage --
  # the same reading `.CompleteSampleRows()` takes, so a row holding one still
  # counts as a complete row here.
  expect_equal(.EmptyRunCause(Slice(c(1, 1, NA), c(2, 1, -Inf)), 1L),
               "leadingGap")

  # Vectorised over runs, in the order asked for.
  two <- array(NA_real_, dim = c(2, 3, 2, 1))
  two[, , 1, 1] <- rbind(c(1, 1, NA), c(2, 1, 5))
  expect_equal(.EmptyRunCause(two, c(2L, 1L)), c("noRows", "leadingGap"))
})

test_that(".CompletedIterIndex() names the real cause (#2012)", {
  Message <- function(samples) {
    conditionMessage(expect_error(
      .CompletedIterIndex(list(c(1, 2, 3)), 0, "m", samples)))
  }

  interrupted <- Message(Slice(c(NA, NA, NA)))
  expect_match(interrupted, "m_samples_run_1.txt", fixed = TRUE)
  expect_match(interrupted, "interrupted before its first flush")

  # The two intact-file causes must not repeat the interrupted-run diagnosis,
  # and must not send the user to repair anything.
  for (msg in c(Message(Slice(c(1, 1, NA), c(2, 1, 5))),
                Message(Slice(c(1, 1, NA), c(2, 1, NA))))) {
    expect_match(msg, "no complete sample rows were found for run 1")
    expect_match(msg, "intact")
    expect_match(msg, "support")
    expect_match(msg, "priorsProposals", fixed = TRUE)
    expect_false(grepl("interrupted", msg))
    expect_false(grepl("repair the", msg))
  }

  # One message per cause where runs disagree, each naming its own runs.
  mixed <- array(NA_real_, dim = c(2, 3, 2, 1))
  mixed[, , 2, 1] <- rbind(c(1, 1, NA), c(2, 1, 5))
  both <- conditionMessage(expect_error(
    .CompletedIterIndex(list(c(1, 2), c(1, 2)), c(0, 0), "m", mixed)))
  expect_match(both, "for run 1[.].*interrupted")
  expect_match(both, "for run 2[.].*intact")

  # Omitting `samples` keeps the pre-#2012 message: the callers that cannot
  # supply it have no way to tell the causes apart.
  generic <- conditionMessage(expect_error(
    .CompletedIterIndex(list(c(1, 2, 3)), 0, "m")))
  expect_match(generic, "interrupted before its first flush")
  expect_match(generic, "m_samples_run_1.txt", fixed = TRUE)
})

test_that("#2012: an intact file with a bad first row is diagnosed end-to-end", {
  # The unit tests above pin the guard; this pins that `StratPosterior()`
  # actually reaches it with the samples array, so the cause is classified from
  # the real compile path rather than a hand-built slice. `binary = FALSE` is
  # load-bearing: with a `_binarysamples_run_*.rds` present the RDS fast path
  # compiles a one-run posterior and the damaged TSV is never read.
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  binary = FALSE, damage = "leading-gap")
  err <- expect_error(
    suppressWarnings(suppressMessages(StratPosterior(readDir = dir,
                                                     modelName = "mC"))))
  expect_match(conditionMessage(err), "run 2")
  expect_match(conditionMessage(err), "intact")
  expect_false(grepl("interrupted", conditionMessage(err)))
  expect_false(grepl("mC_samples_run_2.txt", conditionMessage(err),
                     fixed = TRUE))
})

test_that("#2012: a file whose every row is bad is diagnosed end-to-end", {
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  binary = FALSE, damage = "all-rows-bad")
  err <- expect_error(
    suppressWarnings(suppressMessages(StratPosterior(readDir = dir,
                                                     modelName = "mC"))))
  expect_match(conditionMessage(err), "run 2")
  expect_match(conditionMessage(err), "every saved row")
  expect_false(grepl("interrupted", conditionMessage(err)))
})
