test_that("Matrix multiplication works", {

  # check that conversion to double and matrix multiplication works
  expect_equal(.MatrixMult(matrix(1:4,2),matrix(2:5,2)),
               matrix(c(11,16,19,28),2))

  # wrong input
  expect_error(.MatrixMult(c(1,2),c(2,3)), "`A` must be a matrix")
  expect_error(.MatrixMult(matrix(1:4,2),c(2,3)), "`B` must be a matrix")
  expect_error(.MatrixMult(matrix(1:4,2),matrix(1:6,3)),
               "columns in `A` must equal the number of rows in `B`")

})

test_that("Matrix times Vector multiplication works", {

  # check that conversion to double and matrix multiplication works
  expect_equal(.MatrixVectorMult(matrix(1:4+0.1,2),c(1.2,2.1)),
               c(7.83, 11.13))
  # check that conversion to double and matrix multiplication works
  expect_equal(.MatrixVectorMult(matrix(1:4,2),c(2:3)),
               c(11, 16))
  # wrong input
  expect_error(.MatrixVectorMult(c(1,2,3),c(1,2,3)), "`A` must be a matrix")
  expect_error(.MatrixVectorMult(matrix(1:4,2),matrix(2:5,2)),
               "`B` is not a vector")
  expect_error(.MatrixVectorMult(matrix(1:4,2),c(1,2,3)),
               "columns in `A` must equal the length of `B`")

})
