# RT-381 / RT-413: the C++ MH support checks must REJECT, not redraw.
#
# `check_prior_bounds`, the `!ageOK` twin and `check_rates` used to `continue`
# inside the trial loop, redrawing a fresh proposal from the same kernel (or,
# for `check_rates`, resampling the whole vector from the prior). That made the
# realised kernel q(y|x)1_A(y)/Z(x) while `accept_proposal` still applied
# logHastings = 0, so the invariant density was pi(x)Z(x) rather than pi(x).
# They now fall through to the ordinary rejection branch via the -1e30
# out-of-support sentinel.
#
# The load-bearing consequence tested here is the post-decision Gibbs sweep.
# Under the old control flow a state whose every proposal failed a check
# exhausted 20 inner trials x 500 outer retries and then returned the state
# UNCHANGED from `update_state_internal` — bypassing the unconditional
# beta/sigma/lambda Gibbs sweep that every other rejection gets. With
# reject-not-redraw there is nothing left to exhaust: one failed check is one
# clean rejection, and the sweep still runs.
#
# Statistical calibration of the fix (exact grid tail probability vs sampler,
# pre- and post-fix) lives in
# dev/red-team/heavy-tests/RT-381-boundary-reject-calibration.R.

# Fixture: a single free parameter whose Uniform prior support is 1e-9 wide,
# proposed with SD 1. Every proposal is therefore out of support with
# probability ~1, so every iteration is an all-checks-fail iteration. sigma is
# free so the Gibbs sweep is observable: if it runs, sigma moves.
#
# `failVia = "ageOK"` instead widens the prior (so `check_prior_bounds` cannot
# fire) and collapses the engine's knot-range window, which is checked INSIDE
# `age_convert_and_validate`. See the second helper below.
.rt381_engine <- function(failVia = c("priorBounds", "ageOK")) {
  failVia <- match.arg(failVia)
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  centre <- -2.2
  alphaPrior <- if (failVia == "priorBounds") {
    UniformPrior(centre, centre + 1e-9)
  } else {
    UniformPrior(centre - 5, centre + 5)
  }
  priors <- list(
    alpha_site_2    = alphaPrior,
    alpha_site_3    = Fixed(4),
    gammaLog_site_2 = Fixed(0),
    gammaLog_site_3 = Fixed(0)
  )
  model <- StratModel(
    stratData1, priors = priors,
    alignmentScale = stratModel1[["alignmentScale"]],
    sedModel = stratModel1[["sedModel"]],
    sigmaFixed = FALSE, flexibleKnots = FALSE, knotRange = c(-12, 20)
  )

  td <- file.path(tempdir(), paste0("rt381_", as.integer(runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  set.seed(3811)
  RunStratModel(stratData1, model, nIter = 10L, nChains = 1L, seed = 1L,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "r", engine = "cpp", nThreads = 1L)
  mcmc <- readRDS(file.path(td, "r_mcmc_run_1.rds"))
  if (is.null(model[[".logpost_cpp"]]))
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)

  # Univariate only, factor 1. SD 1 is 1e9 times the width of the narrow
  # support, and 1/5 of the wide one (where the knot window is what fails).
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, "Univariate"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
  pw[, ] <- 1
  mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw
  pf <- mcmc[[c("metro", "proposalFactor")]]
  pf[, ] <- 1
  mcmc[[c("metro", "proposalFactor")]] <- pf
  ua <- mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]]
  ua[] <- 1
  mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]] <- ua

  if (failVia == "ageOK") {
    # Collapse the knot-range validity window to a point. The engine reads it
    # from splineBase$knotRange (src/MCMCEngine.cpp:4294) and only ever applies
    # it to PROPOSALS (:2423) — the imported current state is never re-checked —
    # so this makes `age_convert_and_validate` fail for every proposal whatever
    # it does to the ages, without touching ext_knots (the actual spline basis)
    # and hence without changing the log-posterior geometry. Any site's own age
    # span is fixed and non-zero, so no alpha can satisfy a point window: the
    # failure is deterministic rather than data-dependent.
    ar <- StratoBayes:::.sb_extract_state(
      StratoBayes:::.sb_create_engine(stratData1, model, mcmc,
                                      mcmc[["recentState"]])
    )[[1L]][[c("age", "ageRange")]]
    model[[c("splineBase", "knotRange")]] <- mean(ar) + c(-1e-6, 1e-6)
  }

  StratoBayes:::.sb_create_engine(stratData1, model, mcmc, mcmc[["recentState"]])
}

test_that("RT-381: an out-of-support proposal still gets its post-decision Gibbs sweep", {
  skip_on_cran()

  eng <- .rt381_engine()
  set.seed(9137)

  nIter <- 4L
  sigma <- numeric(nIter)
  lambda <- numeric(nIter)
  alpha <- numeric(nIter)
  accepted <- logical(nIter)
  for (i in seq_len(nIter)) {
    StratoBayes:::.sb_run_block(eng, 1L)
    st <- StratoBayes:::.sb_extract_state(eng)[[1L]]
    sigma[i] <- st[[c("gibbs", "sigma")]][[1L]]
    lambda[i] <- st[[c("gibbs", "lambda")]][[1L]]
    alpha[i] <- st[[c("metro", "parameters")]][[1L]]
    accepted[i] <- st[[c("metro", "accept")]]
  }

  # Every proposal left the (1e-9-wide) prior support, so every iteration is a
  # rejection and the alignment parameter never moves.
  expect_false(any(accepted))
  expect_equal(length(unique(alpha)), 1L)

  # ...but the Gibbs sweep is unconditional, so sigma and lambda are redrawn on
  # every one of those rejections. This is what the pre-fix 500-retry bailout
  # skipped: pre-fix these vectors are constant.
  expect_equal(length(unique(sigma)), nIter)
  expect_equal(length(unique(lambda)), nIter)
})

test_that("RT-381: a rejected out-of-support proposal leaves the chain state coherent", {
  skip_on_cran()

  eng <- .rt381_engine()
  StratoBayes:::.sb_configure_monitor(eng, 8L)
  set.seed(4471)
  st0 <- StratoBayes:::.sb_extract_state(eng)[[1L]]
  StratoBayes:::.sb_run_block(eng, 20L)
  st1 <- StratoBayes:::.sb_extract_state(eng)[[1L]]

  # Alignment parameters unchanged (all proposals rejected) and the retained
  # log-posterior is the finite beta-marginal at the current state, refreshed at
  # the post-sweep sigma/lambda — not the -1e30 sentinel of the rejected draw.
  expect_equal(st1[[c("metro", "parameters")]], st0[[c("metro", "parameters")]])
  expect_true(is.finite(st1[[c("metro", "logPost")]]))
  expect_false(st1[[c("metro", "accept")]])

  # The rejected proposal's own log-posterior is recorded as the out-of-support
  # sentinel, i.e. it went through the ordinary accept/reject path.
  expect_lt(st1[[c("metro", "logPostNew")]], -1e29)

  # The monitor counted those iterations as proposed-and-rejected rather than
  # hiding them (pre-fix the redraws never reached the acceptance monitor).
  mon <- StratoBayes:::.sb_get_monitor(eng)
  expect_equal(sum(mon[["proposalCount"]]), 20L)
  expect_equal(sum(mon[["acceptCount"]]), 0L)
})

test_that("RT-381: a failed age conversion rejects the same way as a failed prior bound", {
  skip_on_cran()

  # The `!ageOK` twin is the branch where the new control flow does something
  # genuinely new: `age_convert_and_validate` has already mutated
  # proposed.parameters (alpha signs, rates -> exp(-rate)) and partially written
  # proposed.signalFlat before failing, and the proposal then skips
  # update_spline_state entirely. Nothing may leak from that half-built scratch
  # state into the retained chain.
  eng <- .rt381_engine("ageOK")
  set.seed(2208)

  nIter <- 20L
  sigma <- numeric(nIter)
  lambda <- numeric(nIter)
  alpha <- numeric(nIter)
  logPost <- numeric(nIter)
  logPostNew <- numeric(nIter)
  accepted <- logical(nIter)
  for (i in seq_len(nIter)) {
    StratoBayes:::.sb_run_block(eng, 1L)
    st <- StratoBayes:::.sb_extract_state(eng)[[1L]]
    sigma[i] <- st[[c("gibbs", "sigma")]][[1L]]
    lambda[i] <- st[[c("gibbs", "lambda")]][[1L]]
    alpha[i] <- st[[c("metro", "parameters")]][[1L]]
    logPost[i] <- st[[c("metro", "logPost")]]
    logPostNew[i] <- st[[c("metro", "logPostNew")]]
    accepted[i] <- st[[c("metro", "accept")]]
  }

  # Every proposal failed the collapsed knot window, not the prior bounds.
  expect_false(any(accepted))
  expect_true(all(logPostNew < -1e29))
  expect_equal(length(unique(alpha)), 1L)

  # The Gibbs sweep still runs on each of those rejections...
  expect_equal(length(unique(sigma)), nIter)
  expect_equal(length(unique(lambda)), nIter)

  # ...and 20 consecutive skipped-pipeline iterations leave the retained chain
  # coherent: cs.logPost stays the finite beta-marginal at the unchanged
  # alignment, tracking only the post-sweep sigma/lambda.
  expect_true(all(is.finite(logPost)))
  expect_equal(length(unique(logPost)), nIter)
})
