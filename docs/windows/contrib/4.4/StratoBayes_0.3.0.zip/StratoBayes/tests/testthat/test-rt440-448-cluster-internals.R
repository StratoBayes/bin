# Seven independent Area-11 (clustering) findings from red-team Round 114:
# RT-440 `selectRows` pairing, RT-441 `clustMax <= 1`, RT-442
# `silOutlierSDFromMean` validation, RT-444 `silOutlierThreshold` type,
# RT-446/RT-447 behaviour-preserving performance, RT-448 `.ClustInfo()` RNG
# use.

.rt44xData <- function(seed = 1) {
  set.seed(seed)
  rbind(matrix(rnorm(8 * 3, 0, 0.4), 8, 3),
        matrix(rnorm(8 * 3, 5, 0.4), 8, 3),
        matrix(rnorm(4 * 3, 0, 6), 4, 3))
}

# ---------------------------------------------------------------------------
# RT-440: `selectRows` is indexed by run number, not by position in `runs`
# ---------------------------------------------------------------------------

test_that(".FormatSelectRows keys a length-nRun selectRows by run number (RT-440)", {
  sr <- list(seq_len(25), seq_len(30), seq_len(35))

  # ascending runSelect: positional and run-indexed agree, so this is a control
  expect_identical(.FormatSelectRows(1:3, sr, 3L), sr)

  # non-ascending runSelect: positional pairing would permute the list
  expect_identical(.FormatSelectRows(3:1, sr, 3L), sr)
  expect_identical(.FormatSelectRows(c(2L, 1L, 3L), sr, 3L), sr)

  # a shorter selectRows - one entry per selected run - stays positional
  expect_identical(.FormatSelectRows(c(1L, 3L), list(seq_len(11), seq_len(13)),
                                     3L),
                   list(seq_len(11), NULL, seq_len(13)))
})

test_that("Cluster() gives each run its own rows for a permuted `runs` (RT-440)", {
  # `sr` below is hand-written for a 3-run fixture.  A reshaped stratPosterior1
  # must fail here so the fixture and the expectation are updated together --
  # skipping would silently delete RT-440's only end-to-end arm.
  expect_identical(stratPosterior1[["nRun"]], 3L)
  sr <- list(1:25, 1:30, 1:35)

  ascending <- Cluster(stratPosterior1, runs = 1:3, selectRows = sr)
  permuted <- Cluster(stratPosterior1, runs = 3:1, selectRows = sr)

  expect_identical(permuted[["rowIndex"]], ascending[["rowIndex"]])
  expect_identical(permuted[["rowIndex"]], sr)
})

# ---------------------------------------------------------------------------
# RT-441: clustMax <= 1
# ---------------------------------------------------------------------------

test_that("clustMax <= 1 returns a single cluster instead of crashing (RT-441)", {
  x <- .rt44xData()
  n <- nrow(x)

  expect_equal(as.vector(.ProtoClusterFast(x, clustMax = 1)), rep(1L, n))
  expect_equal(as.vector(.ProtoCluster(x, clustMax = 1)), rep(1L, n))
  expect_equal(as.vector(.PamCluster(x, clustMax = 1)), rep(1L, n))

  expect_equal(as.vector(Cluster(x, "proto", clustMax = 1)), rep(1L, n))
  expect_equal(as.vector(Cluster(x, "pam", clustMax = 1)), rep(1L, n))

  # clustMax <= 0 must take the same branch, not reach pam()'s own error
  expect_equal(as.vector(.ProtoCluster(x, clustMax = 0)), rep(1L, n))
  expect_equal(as.vector(.PamCluster(x, clustMax = -1)), rep(1L, n))
})

test_that("maxClusterSamples = 2 reaches the clustMax guard (RT-441)", {
  # A 2-row subsample makes `clustMax <- min(nrowCD - 1, 12)` equal 1. RT-441
  # (#461) is that the guard must catch that instead of `pam()` erroring with
  # "incorrect number of dimensions", and it still does -- asserted here on
  # the subsample entry point, because #1603 has since closed the *exported*
  # route: silently returning one cluster for a posterior with several
  # alignment modes is the wrong answer, not an acceptable degenerate one.
  x <- .rt44xData()
  expect_equal(as.vector(.ProtoClusterSubsample(x, maxClusterSamples = 2)),
               rep(1L, nrow(x)))

  expect_error(Cluster(stratPosterior1, burnIn = 0.9, maxClusterSamples = 2),
               "maxClusterSamples")
})

# ---------------------------------------------------------------------------
# RT-442 / RT-444: validation of the two silhouette-outlier arguments
# ---------------------------------------------------------------------------

test_that("silOutlierSDFromMean is validated (RT-442)", {
  x <- .rt44xData()

  for (branch in list(.ProtoCluster, .PamCluster)) {
    # NA/NaN would reach the `is.na(thresh)` guards and silently disable
    # outlier removal for every k rather than reporting the usage error
    expect_error(branch(x, clustMax = 4, silOutlierSDFromMean = NA_real_),
                 "must be a non-negative number")
    expect_error(branch(x, clustMax = 4, silOutlierSDFromMean = NaN),
                 "must be a non-negative number")
    expect_error(branch(x, clustMax = 4, silOutlierSDFromMean = -1),
                 "must be a non-negative number")
    expect_error(branch(x, clustMax = 4, silOutlierSDFromMean = "3"),
                 "must be a non-negative number")
    expect_error(branch(x, clustMax = 4, silOutlierSDFromMean = c(1, 2)),
                 "must be a single value")
  }

  # a legitimate multiplier is still honoured, and a smaller one flags more
  loose <- .ProtoCluster(x, clustMax = 4, silOutlierSDFromMean = 3)
  tight <- .ProtoCluster(x, clustMax = 4, silOutlierSDFromMean = 0.5)
  expect_true(sum(tight == 0) >= sum(loose == 0))
})

test_that("a non-logical, non-numeric silOutlierThreshold is rejected (RT-444)", {
  x <- .rt44xData()

  # unrejected, such a value means outlier removal OFF under pam and ON under
  # proto, from the same input
  expect_error(.PamCluster(x, clustMax = 4, silOutlierThreshold = "x"),
               "must be TRUE, FALSE or a number")
  expect_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = "x"),
               "must be TRUE, FALSE or a number")
  expect_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = list(1)),
               "must be TRUE, FALSE or a number")

  expect_no_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = TRUE))
  expect_no_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = FALSE))
  expect_no_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = 0.2))
})

# ---------------------------------------------------------------------------
# RT-446 / RT-447: behaviour-preserving performance fixes
# ---------------------------------------------------------------------------

test_that("pam() gives the same partition from data or its dissimilarity (RT-446)", {
  # the equivalence `.PamCluster()` relies on when passing `dissimilarities`
  x <- .rt44xData()
  rownames(x) <- paste0("obs", seq_len(nrow(x)))
  d <- dist(x, method = "euclidian")

  for (k in 2:5) {
    fromData <- cluster::pam(x, k = k)
    fromDist <- cluster::pam(d, k = k)
    expect_equal(unname(fromDist[["clustering"]]),
                 unname(fromData[["clustering"]]))
    expect_equal(fromDist[[c("silinfo", "avg.width")]],
                 fromData[[c("silinfo", "avg.width")]])
  }

  # RT-400 still holds: outlier removal fires on labelled input, and labelling
  # makes no difference
  expect_true(any(.PamCluster(x, clustMax = 5) == 0))
  expect_equal(unname(.PamCluster(x, clustMax = 5)),
               unname(.PamCluster(unname(x), clustMax = 5)))
})

test_that(".ProtoClusterSubsample's centroid assignment matches a per-point loop (RT-447)", {
  set.seed(3)
  dat <- rbind(matrix(rnorm(600), ncol = 2),
               matrix(rnorm(600, mean = 8), ncol = 2))
  maxClusterSamples <- 100L
  n <- nrow(dat)

  got <- .ProtoClusterSubsample(dat, maxClusterSamples = maxClusterSamples)

  # reference: reproduce the same subsample, then assign point by point
  mat <- as.matrix(dat)
  set.seed(.DeterministicSeed(mat))
  subIdx <- sort(sample.int(n, maxClusterSamples))
  matSub <- mat[subIdx, , drop = FALSE]
  clSub <- .ProtoCluster(matSub, clustMax = 12, silCutOff = 0.5)
  uniqueCl <- sort(unique(clSub[clSub != 0L]))
  expect_gt(length(uniqueCl), 1L) # else the assignment is never reached

  centroids <- matrix(vapply(uniqueCl, function(k) {
    colMeans(matSub[clSub == k, , drop = FALSE])
  }, numeric(ncol(mat))), nrow = ncol(mat))

  reference <- integer(n)
  for (i in seq_len(n)) {
    reference[i] <- uniqueCl[which.min(colSums((centroids - mat[i, ])^2))]
  }

  expect_equal(got, reference)
})

# ---------------------------------------------------------------------------
# RT-448: .ClustInfo must not touch the RNG
# ---------------------------------------------------------------------------

.rt448Data <- function() {
  set.seed(11)
  list(
    dat = rbind(matrix(rnorm(100), ncol = 2), # cluster 1: 50 points, PD
                matrix(rnorm(40, mean = 20), ncol = 2), # cluster 2: 20, PD
                matrix(5, nrow = 3, ncol = 2)), # cluster 3: 3 identical, not PD
    clusters = rep(1:3, c(50L, 20L, 3L))
  )
}

test_that(".ClustInfo leaves the RNG stream untouched (RT-448)", {
  d <- .rt448Data()

  # precondition: cluster 3's covariance is invalid, so the donor branch runs
  expect_false(.IsPositiveDefinite(cov(d[["dat"]][51 + (20:22), , drop = FALSE])))

  set.seed(42)
  before <- .Random.seed
  info <- .ClustInfo(d[["dat"]], d[["clusters"]])
  expect_identical(.Random.seed, before)
  expect_length(info, 3L)
})

test_that(".ClustInfo picks the largest valid cluster as donor (RT-448)", {
  d <- .rt448Data()

  donated <- lapply(seq_len(12), function(s) {
    set.seed(s)
    .ClustInfo(d[["dat"]], d[["clusters"]])[[3]][[2]]
  })

  # same donor whatever the ambient RNG state ...
  expect_true(all(vapply(donated, identical, logical(1), donated[[1]])))
  # ... and it is cluster 1 (50 points), not cluster 2 (20 points)
  info <- .ClustInfo(d[["dat"]], d[["clusters"]])
  expect_identical(donated[[1]], info[[1]][[2]])
  expect_false(identical(donated[[1]], info[[2]][[2]]))
})
