# A tie whose `densityFun` is outside the engine's native set reaches the R
# callback in the engine's per-tie shape, `list(site =, tie =, age =)`. Before
# #1130, `.HMCCreateEngine()` built a callback that expected a whole parameter
# vector, so the list landed in `.sb_age_convert()`'s NumericVector argument:
# a type error on x86-64, an abort unwinding out of a C++ frame on aarch64.

.Ties1130Fixture <- function() {
  set.seed(1)
  n1 <- 60L
  n2 <- 40L
  h1 <- seq(0, 10, length.out = n1)
  h2 <- seq(0, 6, length.out = n2)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(n1, 0, .1)),
    data.frame(site = "s2", height = h2, value = sin(h2 + 1) + rnorm(n2, 0, .1))
  )
  ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                     densityFun = c("dweibull", "dweibull"),
                     arg1 = c(2, 2), arg2 = c(3, 3))
  stratData <- StratData(signal = signal, ties = ties, siteColumn = "site",
                         zColumn = "height", signalColumn = "value")
  priors <- structure(
    list(alpha_s2 = UniformPrior(min = -5, max = 5),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list")
  )
  stratModel <- StratModel(stratData, priors, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "middle",
                           nKnots = 6, sigmaFixed = 1, flexibleKnots = FALSE,
                           knotRange = c(-15, 25))
  list(data = stratData, model = stratModel)
}

test_that("non-native ties densityFun runs under gradientProposals (#1130)", {
  fx <- .Ties1130Fixture()
  expect_s3_class(
    RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                  nIter = 10, nChains = 2L, seed = 1, quiet = TRUE,
                  visualise = FALSE, nThreads = 1L,
                  gradientProposals = "on", engine = "R",
                  modelDir = tempdir(), modelName = "ties1130R"),
    "StratPosterior"
  )
})

test_that(".MakeTiesCallback handles both engine calling shapes (#1130)", {
  fx <- .Ties1130Fixture()
  data <- fx[["data"]]
  model <- fx[["model"]]
  model[[".tiesDispatch"]] <- .BuildTiesDispatch(data, model)
  callback <- .MakeTiesCallback(data, model)

  # Per-tie shape: site 2, tie 1 is dweibull(shape = 2, scale = 3)
  expect_equal(callback(list(site = 2L, tie = 1L, age = 1.5)),
               dweibull(1.5, 2, 3, log = TRUE))

  # Whole-state shape: a list of tie ages, one vector per site
  ages <- list(NULL, 1.5)
  expect_equal(callback(ages),
               .LogLikTies(data, model, list(age = list(ties = ages))))
})

test_that("both engine constructors share one ties callback (#1130)", {
  hmcSrc <- deparse(body(StratoBayes:::.HMCCreateEngine))
  expect_true(any(grepl(".MakeTiesCallback", hmcSrc, fixed = TRUE)))
})
