# Regression tests for the area-10 run/row-selection tranche: which runs,
# rows and chains a StratPosterior accessor actually operates on.
#
# #1279/#678: `summary(stratCluster=, runs=<subset>)` leaked unselected runs'
#   rows into the main statistics table (#1279) and the divergence
#   diagnostics (#678) -- two independent consumers of the same
#   under-intersected `selectRows`.
# #686: the `Acceptance` figure re-derived its own row selection instead of
#   reusing the one already computed for the rest of the summary, so it could
#   describe a different set of rows than the statistics beside it.
# #679: `runs`/`selectRows`/`chain` lacked the validation their sibling
#   arguments (`parameters`, `alignment`, `burnIn`) already have.
# #684: proportional `burnIn` picked the run with the fewest saved ROWS to
#   supply the threshold, but the threshold itself is a proportion of the run
#   with the fewest completed ITERATIONS -- not always the same run.
# #685: `iterations` had undocumented, divergent semantics as an atomic
#   vector vs a list.

test_that("#1279: summary(stratCluster=, runs=<subset>) does not leak unselected runs' rows into the statistics", {
  # A stratCluster built over every run (the package default) must be
  # intersected with this call's own `runs = 1`, not used wholesale.
  clAll <- Cluster(stratPosterior1, burnIn = 0.5, runs = "all")
  expect_equal(clAll$nClust, 1)  # single cluster, so "alignment1" == every selected row
  sAll  <- suppressWarnings(summary(stratPosterior1, stratCluster = clAll, runs = 1))

  expect_equal(sAll$general$nRun, 1)
  # Pre-fix this was 300 (all 3 runs' rows pooled) instead of 100 (run 1's
  # own rows) -- a wrong SAMPLE COUNT, not merely a wrong label.
  expect_equal(sAll$general$nSamplesUsed, 100)

  # And the contamination reaches an actual posterior statistic, not just the
  # sample count: ParC (the statistics table) was extracted with no `runs=`,
  # pooling all 3 runs' rows regardless of the `runs = 1` request.
  groundTruth <- ExtractParameters(stratPosterior1, parameters = "alpha_site_2",
                                    runs = 1, selectRows = clAll$rowIndex)
  expect_equal(sAll$alignment1$summary["alpha_site_2", "mean"],
               mean(groundTruth[, 1]))
})

test_that("#1279 follow-up: an alignment absent from the selected runs reports an empty block instead of erroring", {
  # A stratCluster covering multiple alignments across runs, where the
  # currently selected run only ever visited one of them (multimodal
  # posteriors are exactly why alignments exist) -- intersecting `selectRows`
  # with `runs=` (the #1279 fix) can leave an alignment with zero rows in the
  # selected runs, which must not hard-stop the whole summary() call.
  clAll <- Cluster(stratPosterior1, burnIn = 0.5, runs = "all")
  clAll$clusterList <- list(rep(1L, 100), rep(2L, 100), rep(2L, 100))
  clAll$nClust <- 2L
  clAll$clustUnique <- c(1L, 2L)

  s <- suppressWarnings(summary(stratPosterior1, stratCluster = clAll, runs = 1))
  expect_equal(s$alignment1$samples, 100)
  expect_equal(s$alignment2$samples, 0)
  expect_true(all(is.na(s$alignment2$summary$mean)))
  expect_true(is.na(s$alignment2$multiESS))

  # runs = "all" still sees both alignments populated.
  sAll <- suppressWarnings(summary(stratPosterior1, stratCluster = clAll, runs = "all"))
  expect_equal(sAll$alignment2$samples, 200)
})

test_that("#1279 follow-up: a stratCluster covering none of the selected runs errors clearly, not from inside Acceptance", {
  # The #1279 intersection (`selectRows <- lapply(..., if (r %fin% runSelect)
  # stratCluster[["rowIndex"]][[r]] else NULL)`) can leave EVERY selected
  # run's selectRows empty when the stratCluster was built over disjoint
  # runs entirely -- not just one alignment within them (the case above).
  # Pre-guard, that reached ExtractParameters()'s Acceptance call first and
  # died on "Parameter selection resulted in zero iterations being
  # selected." -- a message naming neither `stratCluster` nor `runs`.
  clRun2 <- Cluster(stratPosterior1, burnIn = 0.5, runs = 2)

  err <- expect_error(
    summary(stratPosterior1, stratCluster = clRun2, runs = 1)
  )
  expect_match(conditionMessage(err), "runs = 1")
  expect_match(conditionMessage(err), "stratCluster")
})

test_that("#678: summary(..., runs=<subset>) subsets the divergence diagnostics", {
  # stratPosterior1 was compiled from a Metropolis run (no HMC/NUTS
  # divergence fields); inject visibly different per-run values, mirroring
  # the issue's own reproduction.
  post <- stratPosterior1
  post$mcmcSummary$nDivergent <- c(10L, 20L, 30L)
  post$mcmcSummary$nGradientTransitions <- c(100L, 200L, 300L)
  post$mcmcSummary$maxTreeDepth <- c(3L, 4L, 9L)
  post$mcmcSummary$divergenceLocations <- list(NULL, NULL, NULL)

  div <- suppressWarnings(summary(post, runs = 1))$general$divergences

  # Pre-fix these were the pooled totals across all 3 runs (60, 300, 9), not
  # run 1's own values.
  expect_equal(div$nDivergent, 10L)
  expect_equal(div$nGradientTransitions, 100L)
  expect_equal(div$maxTreeDepth, 3L)
  expect_equal(div$divergenceRate, 0.1)
  expect_equal(as.integer(div$perRun$run), 1L)
  expect_equal(nrow(div$perRun), 1L)
  expect_equal(div$perRun$nDivergent, 10L)
})

test_that("#686: the Acceptance figure reuses the already-computed selectRows instead of re-deriving one", {
  # A stratCluster scoped to run 1 with a much stricter burnIn than
  # summary()'s own default: `Acceptance`'s old re-derivation used summary()'s
  # burnIn (0.5) and ignored the stratCluster's actual row selection, so it
  # described a different (larger, earlier) row set than the rest of the
  # summary.
  clCustom <- Cluster(stratPosterior1, burnIn = 0.9, runs = 1)
  expect_equal(lengths(clCustom$rowIndex), c(20, 0, 0))

  s <- suppressWarnings(summary(stratPosterior1, stratCluster = clCustom, runs = 1))

  # Ground truth: proposal_accepted over the ACTUAL selected rows.
  trueAcceptance <- ExtractParameters(stratPosterior1, parameters = "proposal_accepted",
                                       runs = 1, selectRows = clCustom$rowIndex,
                                       chain = "chain1")
  trueRate <- mean(as.numeric(trueAcceptance[, 1])) * 100

  # Pre-fix this was 14 (the default-burnIn re-derivation); the correct rate
  # for the cluster's own 20 rows is 10.
  expect_equal(s$general$meanAcceptancePercent, trueRate)
  expect_equal(s$general$nSamplesUsed, 20)
})

test_that("#679 (1/4): runs rejects a duplicated run number", {
  # Pre-fix this silently doubled run 1, biasing R-hat toward 1 (false
  # convergence) rather than merely inflating the sample count.
  expect_error(
    summary(stratPosterior1, runs = c(1, 1)),
    "not contain the same run number"
  )
  expect_error(
    ExtractParameters(stratPosterior1, runs = c(2, 2, 3)),
    "not contain the same run number"
  )
})

test_that("#679 (2/4): selectRows rejects non-positive row indices", {
  # Pre-fix a negative index silently applied R's *exclude* semantics
  # (returning far more rows than requested) and a zero index was silently
  # dropped -- neither errored.
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = c(-1L, -2L)),
    "Row indices must be at least 1"
  )
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = c(0L, 1L)),
    "Row indices must be at least 1"
  )
})

test_that("#679 (3/4): a selectRows list matching neither nRun nor length(runs) errors instead of silently reusing the wrong run's rows", {
  # stratPosterior1 has 3 runs; a length-1 list against a 2-run request
  # matches neither nRun (3) nor length(runs) (2), so it must error rather
  # than falling back to `selectRows[[1]]` for every run (pre-fix: 5 rows of
  # run 2's own data reused, unlabelled, as run 3's too).
  expect_error(
    ExtractParameters(stratPosterior1, parameters = "alpha_site_2",
                       runs = c(2, 3), selectRows = list(1:5)),
    "one element per selected run"
  )

  # A length-nRun list is still read by absolute run number (unchanged,
  # already-tested behaviour -- RT-034/RT-035).
  byRunNumber <- ExtractParameters(stratPosterior1, parameters = "alpha_site_3",
                                    runs = c(3, 1),
                                    selectRows = list(100:101, NULL, 102:101))[, 1]
  expect_equal(byRunNumber,
               as.numeric(c(stratPosterior1$samples[102:101, 2, 3, 1],
                             stratPosterior1$samples[100:101, 2, 1, 1])),
               tolerance = 1e-6)

  # A list of length(runs) is positional (one entry per selected run) -- the
  # convention `Cluster.StratPosterior()`'s `.FormatSelectRows()` already
  # documents and relies on; ExtractParameters() now shares it.
  positional <- ExtractParameters(stratPosterior1, parameters = "alpha_site_2",
                                   runs = 2, selectRows = list(1:5))
  expect_equal(nrow(positional), 5)
  expect_equal(positional[, 1],
               as.numeric(stratPosterior1$samples[1:5, 1, 2, 1]))

  # With only one selected run, "positional index 1" and the pre-fix
  # fallback (`selectRows[[1]]` for any run beyond the list's length)
  # coincide -- so neither the `byRunNumber` nor the single-run `positional`
  # case above actually discriminates the fix from the bug it replaces. Two
  # selected runs are needed: pre-fix, run 2 (runR = 2, length(selectRows) =
  # 2 >= 2) reads `selectRows[[2]]`, and run 3 (runR = 3, 2 >= 3 is FALSE)
  # falls back to `selectRows[[1]]` -- the two entries silently SWAPPED
  # relative to the positional reading intended here.
  swapCheck <- ExtractParameters(stratPosterior1, parameters = "alpha_site_2",
                                  runs = c(2, 3),
                                  selectRows = list(10:11, 20:21))
  expect_equal(swapCheck[, 1],
               as.numeric(c(stratPosterior1$samples[10:11, 1, 2, 1],
                             stratPosterior1$samples[20:21, 1, 3, 1])),
               tolerance = 1e-6)
})

test_that("#679 (4/4): chain names an actual saved chain", {
  # Pre-fix this was a bare "subscript out of bounds" from the raw array
  # index, naming nothing.
  err <- expect_error(ExtractParameters(stratPosterior1, chain = "chain2"))
  expect_match(conditionMessage(err), "one of this posterior's saved chains")
  expect_match(conditionMessage(err), "chain1")
})

test_that("#684: proportional burnIn is quantized onto the run supplying minCompletedIter, not the run with fewest rows", {
  # Run A: nThin = 1, 650 completed iterations -> 650 rows (dense lattice).
  # Run B: nThin = 100, 5000 completed iterations -> 50 rows (coarse
  # lattice). Run B has fewer ROWS; run A has fewer completed ITERATIONS --
  # deliberately not the same run, which is exactly what #684 got wrong.
  stub <- structure(
    list(
      nRun = 2L,
      mcmcSummary = list(
        saveIter = list(1:650, seq(100L, 5000L, by = 100L)),
        completedIter = c(650, 5000)
      )
    ),
    class = "StratPosterior"
  )

  out <- ExtractIterations(stub, alignment = "all", burnIn = 0.5, runs = "all")

  # Pre-fix run A retained 350/650 rows (discarding 46.2%, quantized onto run
  # B's nThin = 100 lattice): the threshold landed on 300, not 325. The
  # correct 50% threshold for run A's own 650 iterations is 325, retaining
  # exactly half.
  expect_equal(length(out[[1]]), 325)
  expect_equal(length(out[[1]]) / length(1:650), 0.5)
})

test_that("#685: iterations as a list is indexed by absolute run number, and a mismatched length errors", {
  nRun <- stratPosterior1$nRun
  expect_equal(nRun, 3)

  # A list must have one element per run (NULL for a run to select nothing);
  # a shorter list used to silently supply only the first selected run and
  # leave the rest empty.
  expect_error(
    ExtractIterations(stratPosterior1, alignment = "all", burnIn = 0.5,
                       iterations = list(c(100, 5000))),
    "one element per run"
  )

  # A full-length list is read by absolute run number: only run 1's entry is
  # populated here, so runs 2 and 3 must select nothing.
  byList <- ExtractIterations(stratPosterior1, alignment = "all", burnIn = 0.5,
                               iterations = list(c(100, 5000), NULL, NULL))
  expect_equal(lengths(byList), c(2, 0, 0))

  # An atomic vector, by contrast, is the same exact-match filter shared
  # across every selected run.
  byAtomic <- ExtractIterations(stratPosterior1, alignment = "all", burnIn = 0.5,
                                 iterations = c(100, 5000))
  expect_equal(lengths(byAtomic), c(2, 2, 2))

  # A list entry containing a value off the run's saved-iteration lattice
  # falls back to an inclusive range match instead of an exact one, and
  # selects strictly more rows here (101 is off-lattice; 100 is on it).
  byRange <- ExtractIterations(stratPosterior1, alignment = "all", burnIn = 0.5,
                                iterations = list(c(101, 5000), NULL, NULL))
  expect_gt(length(byRange[[1]]), length(byList[[1]]))
})
