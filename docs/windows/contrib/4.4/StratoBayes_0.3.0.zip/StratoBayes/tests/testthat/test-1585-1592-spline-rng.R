# Spline entry-point and thread-RNG fixes (GH #1478, #1585, #1587, #1589,
# #1591). Each block is red on the parent commit.

test_that("BayesianSpline raises its default bLambda above the data's lambda scale (#1587)", {
  set.seed(1587)
  n <- 120
  x <- seq(0, 8, length.out = n)
  y <- sin(x) + rnorm(n, 0, 0.2)

  # At unit scale the healthy lambda sits far under the prior ceiling, so the
  # raise is the documented no-op.
  benign <- BayesianSpline(x = x, y = y, nKnots = 25, nIter = 10)
  expect_identical(benign[[c("model", "priors", "gibbs", "bLambda")]], 1000)

  # A wide x-span drives the healthy lambda ~9 orders above the ceiling that a
  # fixed bLambda = 1000 imposes, at which point the prior alone sets lambda.
  wide <- BayesianSpline(x = x * 1000, y = y, nKnots = 25, nIter = 10)
  bWide <- wide[[c("model", "priors", "gibbs", "bLambda")]]
  expect_gt(bWide, 1000)
  numBasis <- wide[[c("model", "splineBase", "num_basis")]]
  star <- .LambdaStar(wide[[c("model", "splineBase")]], y)
  expect_gt((1 + (numBasis - 2) / 2) * bWide, star)
  # lands the same distance above the scale that #1136 chose, not merely clear
  expect_equal(bWide, .BLambdaRel * star)

  # A small y scale is the other trigger for the same ceiling. 1e-4, not the
  # 1e-3 the issue quotes: lambda* goes as 1/sd(y)^2, and at 1e-3 it reaches
  # 1.33e4 against a 1.35e4 ceiling -- under it, so nothing should fire there.
  small <- BayesianSpline(x = x, y = y * 1e-4, nKnots = 25, nIter = 10)
  expect_gt(small[[c("model", "priors", "gibbs", "bLambda")]], 1000)

  # An explicit bLambda is the caller's to get wrong, as in StratModel().
  explicit <- BayesianSpline(x = x * 1000, y = y, nKnots = 25, nIter = 10,
                             bLambda = 1000)
  expect_identical(explicit[[c("model", "priors", "gibbs", "bLambda")]], 1000)
})

test_that("BayesianSpline rejects an x/y length mismatch that divides evenly (#1589)", {
  x <- seq(0, 8, length.out = 50)
  y <- sin(x)
  # data.frame() recycles silently here: the fit used to run against y twice.
  expect_error(BayesianSpline(x = x, y = y[1:25], nKnots = 6, nIter = 20),
               "same length")
  expect_error(BayesianSpline(x = x, y = y[1:7], nKnots = 6, nIter = 20),
               "same length")
})

test_that("BayesianSpline names nIter when it is not a positive count (#1589)", {
  x <- seq(0, 8, length.out = 30)
  y <- sin(x)
  expect_error(BayesianSpline(x = x, y = y, nKnots = 6, nIter = 0), "nIter")
  expect_error(BayesianSpline(x = x, y = y, nKnots = 6, nIter = -1), "nIter")
  expect_error(BayesianSpline(x = x, y = y, nKnots = 6, nIter = NA_integer_),
               "nIter")
  # nThin is the same seq() argument, one over
  expect_error(BayesianSpline(x = x, y = y, nKnots = 6, nIter = 20, nThin = 0),
               "nThin")
  expect_error(BayesianSpline(x = x, y = y, nKnots = 6, nIter = 20, nThin = -1),
               "nThin")
})

test_that("PredictSpline's subsample ignores the ambient RNG position (#1591)", {
  set.seed(1591)
  x <- seq(0, 8, length.out = 40)
  y <- sin(x) + rnorm(40, 0, 0.2)
  fit <- BayesianSpline(x, y, nKnots = 6, nIter = 2100)
  # > 1000 stored iterations post-burn-in, so the subsample cap actually fires
  expect_gt(sum(seq(1, fit[["nIter"]], fit[["nThin"]]) > fit[["nIter"]] / 2),
            1000)

  first <- PredictSpline(fit, at = x)
  invisible(rnorm(50))
  second <- PredictSpline(fit, at = x)
  expect_identical(first, second)

  # Rcpp's RNGScope creates .Random.seed where there was none, so the #1141
  # "no stream left behind" guarantee needs a guard on every fit size, not only
  # on the > 1000 branch that used to carry one.
  smallFit <- BayesianSpline(x, y, nKnots = 6, nIter = 100)
  savedSeed <- get(".Random.seed", envir = .GlobalEnv)
  rm(".Random.seed", envir = .GlobalEnv)
  invisible(PredictSpline(smallFit, at = x))
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
  assign(".Random.seed", savedSeed, envir = .GlobalEnv)
})

test_that("qtnorm_std's straddling branch is accurate in the upper half (#1585)", {
  # The Halley residual Phi(z) - p is ~3e-18 at p ~ 1, under the ~1e-16
  # cancellation noise of its own subtraction, so the polish was inert there
  # and Acklam's ~3e-9 error survived uncorrected.
  expect_lt(abs(.sb_qtnorm(1 - 1e-10, -Inf, Inf) - qnorm(1 - 1e-10)), 1e-12)
  # the lower half already reached machine accuracy; keep it there
  expect_lt(abs(.sb_qtnorm(1e-10, -Inf, Inf) - qnorm(1e-10)), 1e-12)

  u <- c(0.6, 0.9, 0.999, 1 - 1e-6, 1 - 1e-12)
  expect_lt(max(abs(.sb_qtnorm(u, -Inf, Inf) - qnorm(u))), 1e-12)
  # Truncated, against R's own (Wichura) qnorm rather than a sibling copy. The
  # looser bound is the oracle's: its own rounding is amplified by 1/phi(4) at
  # the bound, so it carries ~4e-13 of error the core is not answerable for.
  oracle <- qnorm(pnorm(-4) + u * (pnorm(4) - pnorm(-4)))
  expect_lt(max(abs(.sb_qtnorm(u, -4, 4) - oracle)), 1e-11)
})

test_that("qtnorm_std propagates NaN instead of clamping it to a bound (#1478)", {
  # min(zU, max(zL, NaN)) is zL under IEEE comparison semantics, so a numerical
  # failure used to come back as a plausible boundary draw.
  expect_true(is.nan(.sb_qtnorm(NaN, -1, 1)))
  expect_true(is.nan(.sb_qtnorm(NaN, 2, 3)))
  expect_true(is.nan(.sb_qtnorm(NaN, -3, -2)))
})
