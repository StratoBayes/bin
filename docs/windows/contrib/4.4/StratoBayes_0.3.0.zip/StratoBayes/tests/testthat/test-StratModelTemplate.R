test_that("StratModelTemplate works - 01", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s")
  )
})

test_that("StratModelTemplate works - 02", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s x p",
                       gammaLog = "normal", zetaLog = "truncated normal",
                       gap = "truncated log normal")
  )
})

test_that("StratModelTemplate works - 03", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that("StratModelTemplate works - 04", {
  skip_if_not_snapshot_os()
  expect_snapshot(
    StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
                       alpha = "fixed", gap = "log normal",
                       alphaPosition = c(100, "middle", "bottom"))
  )
})

test_that("StratModelTemplate auto-assigns alignmentScale and sedModel or produces helpful errors", {

  signal <- data.frame(a = 1:4, height = 1:4, site = c("a", "a", "b", "b"))
  # site "b"'s first boundary must sit strictly above its own data minimum
  # (3) or it becomes a phantom zero-width partition (RT-457); 3.5 keeps
  # both site-b partitions non-degenerate.
  parts <- data.frame(height = c(4, 3.5, 4), site = c("a", "b", "b"), partition = c("x", "x", "y"))
  ties <- data.frame(height = 2, site = "a", mean = 1, sd = 1)

  testData <- StratData(signal = signal, signalColumn = "a")
  template1 <- utils::capture.output(StratModelTemplate(testData))
  expect_true(any(grepl('alignmentScale = "height"', template1)))
  expect_true(any(grepl('sedModel = "site"', template1)))

  testData <- StratData(signal = signal, parts = parts, signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*'site', 'partition'")

  testData <- StratData(signal = signal, parts = parts, ties = ties,
                        signalColumn = "a")
  expect_error(StratModelTemplate(testData),
               "*Valid options are 'height'")

  expect_error(StratModelTemplate(testData, alignmentScale = "a"),
               "*'site', 'partition', 'site x partition', 'site, partition'")

})

test_that("StratModelTemplate errors on an unrecognised dist-type arg (RT-362)", {
  # A misspelled/unsupported distribution type used to fall through
  # printPrior()'s switch() silently, emitting a syntactically broken
  # generated line (e.g. `"alpha_site2" = ,`) rather than erroring at
  # generation time, so the user only discovered it as an opaque parse
  # error in the copied template script.
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       alpha = "gaussian"),
    "`alpha` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       gammaLog = "lognormal"),
    "`gammaLog` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       zetaLog = "truncated-normal"),
    "`zetaLog` must be one of"
  )
  expect_error(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       gap = "expo"),
    "`gap` must be one of"
  )

  # valid types (including case-insensitive matching, as printPrior()'s
  # switch() already relies on) must still pass validation
  template <- utils::capture.output(
    StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s",
                       alpha = "Uniform", gammaLog = "NORMAL", gap = "Fixed")
  )
  expect_true(any(grepl("UniformPrior", template)))
})
