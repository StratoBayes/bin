test_that("Multiple priors are plotted with plot.StratPrior", {
  skip_if_not_snapshot_os()

  priors <- structure(list(
    `alpha_site_2` = UniformPrior(min = -60, max = 60),
    `gammaLog_site_2` = NormalPrior(mean = 0, sd = log(2))),
    class = c("StratPrior", "list"))

  discard <- tempfile()
  png(filename = discard)
  on.exit(unlink(discard), add = TRUE)
  # expect_warning(
  #   plot(priors, 1:2),
  #   "unnamed arguments"
  # )
  dev.off()

  skip_if_not_installed("vdiffr")
  if (interactive()) {
    plot(priors, parameters = 1:2)
  }

  vdiffr::expect_doppelganger("multiple-priors",
                              function() plot(priors, parameters = 1:2))
})

  test_that("plot.StratPrior works with stratPrior1", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 1", function() {
      plot(stratPrior1, col = "grey",
           parameters = "alpha_site_2")
    })})

  test_that("plot.StratPrior works with stratPrior2", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 2", function() {
      plot(stratPrior2, alpha = .25, overridePar = TRUE,
           parameters = c("alpha_site3", 5, 1, 6, 5, "alpha", 6, "gap", 3))
    })})

  test_that("plot.StratPrior works with non-log gamma and prior from stratPosterior object", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 3", function() {
      plot(stratPosterior2$model$priors, log = FALSE, overridePar = FALSE, parameters = 5)
    })})

  test_that("plot.StratPrior works with fixed prior", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 4", function() {
      plot(stratPrior3, log = FALSE, parameters = "all")
    })})

  test_that("plot.StratPrior works with fixed prior - 2", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 5", function() {
      plot(stratPrior3, log = FALSE, parameters = 2)
    })})

  test_that("plot.StratPrior works with uniform non-log gamma", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("plot.stratPrior - 6", function() {
  plot(structure(list(
    "alpha_site2" = UniformPrior(min = -8, max = 8),
    "gammaLog_site2" = UniformPrior(min = log(1/4), max = log(4))),
    class = c("StratPrior", "list")), log = FALSE, parameters = "gamma", overridePar = FALSE)
    })
  })

  test_that("plot.StratPrior produces margin error message", {
    png(filename = tempfile(), width = 50, height = 50)
    expect_error({plot.StratPrior(stratPrior0)},
                 regexp = "The plot window is too small for the specified margins")
    dev.off()
  })

  test_that(".FindXRange falls back to a finite range for an improper (-Inf, Inf) prior", {
    improper <- UniformPrior(min = -Inf, max = Inf)
    expect_warning(
      xrange <- StratoBayes:::.FindXRange(
        improper[["D"]], improper[["Q"]], improper[["args"]], 1, logX = TRUE
      ),
      "falling back to a default range"
    )
    expect_true(all(is.finite(xrange)))
    expect_length(xrange, 2)
  })

  test_that("plot.StratPrior rejects 'prior'/'likelihood'/'lambda'/'sigma'/'beta' with a clear message instead of a downstream leak (RT-605)", {
    expect_error(plot(stratPrior1, parameters = "prior"),
                 "Invalid names specified for parameters")
    expect_error(plot(stratPrior1, parameters = "likelihood"),
                 "Invalid names specified for parameters")
    expect_error(plot(stratPrior1, parameters = "lambda"),
                 "not a valid `parameters` selection")
    expect_error(plot(stratPrior1, parameters = "sigma"),
                 "not a valid `parameters` selection")
    expect_error(plot(stratPrior1, parameters = "beta"),
                 "not a valid `parameters` selection")
  })

  test_that("plot.StratPrior reserves legend margin using cex.lab, matching what the legend is drawn with (RT-608)", {
    capturedCex <- NULL
    testthat::local_mocked_bindings(
      .EstimateLegendWidth = function(labels, cex = 1) {
        capturedCex <<- cex
        6
      },
      .package = "StratoBayes"
    )
    png(tempfile())
    # add = TRUE: a bare on.exit() discards local_mocked_bindings()'s restore,
    # leaking the mock into every later test in the session (#2000)
    on.exit(dev.off(), add = TRUE)
    invisible(plot(stratPrior1, parameters = "alpha_site_2", cex.lab = 3))
    expect_equal(capturedCex, 3)
  })

  test_that("plot.StratPrior does not crash for an improper (-Inf, Inf) prior", {
    priors <- structure(list(
      alpha_site2 = UniformPrior(min = -Inf, max = Inf)),
      class = c("StratPrior", "list"))

    png(tempfile())
    set.seed(1)
    expect_no_error(suppressWarnings(plot(priors, parameters = 1)))
    dev.off()
  })

test_that("plot.StratPrior draws a Fixed() prior as a single spike", {
  # Fixed()'s D() returns a constant 1 off the log scale (#1121), which would
  # otherwise be plotted as a density curve.
  out <- plot(stratPrior3, log = FALSE, parameters = "all", display = FALSE)
  expect_equal(sum(!is.na(out[[c("gammaLog", "gammaLog_3")]])), 1L)
  expect_equal(sum(!is.na(out[[c("gammaLog", "gammaLog_2")]])), 500L)
})
