.NullDevice <- function(env = parent.frame()) {
  grDevices::pdf(NULL)
  withr::defer(grDevices::dev.off(), envir = env)
}

test_that("topsAlpha, topsLwd are validated with named errors", {
  data("stratPosterior1", package = "StratoBayes")
  tp <- function(...) TopsPlot(stratPosterior1, display = FALSE, ...)
  expect_error(tp(topsAlpha = NA_real_), "topsAlpha")
  expect_error(tp(topsAlpha = 2), "topsAlpha")
  expect_error(tp(topsAlpha = -1), "topsAlpha")
  expect_error(tp(topsAlpha = c(0.1, 0.9)), "topsAlpha")
  expect_error(tp(topsLwd = NA_real_), "topsLwd")
  expect_error(tp(topsLwd = -5), "topsLwd")
  expect_error(tp(topsLwd = Inf), "topsLwd")
})

test_that("unknown topsColourScale warns and falls back", {
  data("stratPosterior1", package = "StratoBayes")
  expect_warning(
    TopsPlot(stratPosterior1, display = FALSE, topsColourScale = "Nope"),
    "topsColourScale")
})

test_that("marginFrac outside [0, 0.5) is rejected", {
  data("stratPosterior1", package = "StratoBayes")
  for (m in list(0.6, 0.5, -0.1, NA_real_, c(0.1, 0.2))) {
    expect_error(TopsPlot(stratPosterior1, display = FALSE, marginFrac = m),
                 "marginFrac")
  }
})

test_that("topsLty follows its quantile when quantiles are unsorted", {
  skip_if_not_installed("withr")
  data("stratPosterior1", package = "StratoBayes")
  .NullDevice()
  seen <- list()
  testthat::local_mocked_bindings(
    lines = function(x, y = NULL, ..., lty = 1) {
      seen[[length(seen) + 1L]] <<- lty
      invisible(NULL)
    },
    .package = "StratoBayes")
  TopsPlot(stratPosterior1, refHeights = 1, quantiles = c(0.9, 0.1, 0.5),
           topsLty = c(1, 2, 3), overridePar = TRUE)
  # plot.StratData() also calls lines(); the tops overlay comes last.
  # Sorted order 0.1, 0.5, 0.9 carries lty 2, 3, 1.
  expect_equal(utils::tail(rle(unlist(seen))$values, 3), c(2, 3, 1))
})

test_that("2-site default refHeights respect refHeightsSite", {
  data("stratPosterior3", package = "StratoBayes")
  expect_no_warning(
    res <- TopsPlot(stratPosterior3, refHeightsSite = 2, display = FALSE))
  site2 <- .DefaultRefHeightsSite2(stratPosterior3[["data"]])
  expect_equal(sort(unique(res$refHeight)), sort(site2))
})

test_that("explicit refHeights = NULL still means the default", {
  data("stratPosterior1", package = "StratoBayes")
  expect_equal(
    TopsPlot(stratPosterior1, refHeights = NULL, display = FALSE),
    TopsPlot(stratPosterior1, display = FALSE))
})

test_that("all-non-finite refHeights fall back to the default, with a warning", {
  data("stratPosterior1", package = "StratoBayes")
  def <- TopsPlot(stratPosterior1, display = FALSE)
  expect_warning(
    expect_warning(
      res <- TopsPlot(stratPosterior1, refHeights = NA_real_, display = FALSE),
      "non-finite"),
    "using the default")
  expect_equal(sort(unique(res$refHeight)), sort(unique(def$refHeight)))
})
