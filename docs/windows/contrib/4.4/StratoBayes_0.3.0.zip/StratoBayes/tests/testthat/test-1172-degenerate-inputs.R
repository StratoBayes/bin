# GH #1172: degenerate or wrong-type inputs reached opaque low-level errors.

test_that("a NULL or empty `alignment` gives the same clear message everywhere", {
  data("stratPosterior1", package = "StratoBayes")
  for (bad in list(NULL, character(0), integer(0))) {
    expect_error(StratMap(stratPosterior1, heights = 1, site = 2,
                          alignment = bad),
                 "`alignment` cannot be")
    expect_error(Tops(stratPosterior1, refHeights = 1, alignment = bad),
                 "`alignment` cannot be")
    expect_error(TopsPlot(stratPosterior1, alignment = bad, display = FALSE),
                 "`alignment` cannot be")
  }
})

test_that("an NA `alignment` is still rejected", {
  data("stratPosterior1", package = "StratoBayes")
  expect_error(Tops(stratPosterior1, refHeights = 1, alignment = NA),
               "must not contain missing values")
})

test_that("Partitions() names the empty `signal` rather than failing on NULL", {
  expect_error(
    Partitions(data.frame(site = character(0), height = numeric(0)),
               nStrata = 2, distribute = "points"),
    "no rows"
  )
})

test_that("`parameters` must be numeric", {
  data("stratPosterior1", package = "StratoBayes")
  nPar <- ncol(ExtractParameters(stratPosterior1))
  chr <- as.data.frame(matrix(as.character(seq_len(nPar)), nrow = 1))
  expect_error(Tops(stratPosterior1, refHeights = 1, parameters = chr),
               "`parameters` must be numeric")
  expect_error(Tops(stratPosterior1, refHeights = 1,
                    parameters = as.character(seq_len(nPar))),
               "`parameters` must be numeric")
  # a numeric data.frame is still accepted
  num <- ExtractParameters(stratPosterior1)[1, , drop = FALSE]
  expect_s3_class(Tops(stratPosterior1, refHeights = 1, parameters = num),
                  "data.frame")
})
