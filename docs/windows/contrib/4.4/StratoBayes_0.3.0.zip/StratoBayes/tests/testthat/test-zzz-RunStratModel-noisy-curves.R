# Smoke test for the curve-alignment wiring of RunStratModel() on NOISY data.
#
# This test deliberately makes NO assertion about *which* posterior value the
# short MCMC lands on. Absolute posterior summaries from a short chain are not a
# portable oracle: the mode a finite chain settles in depends on the platform's
# RNG/BLAS stream, so an `expect_equal(alpha_b "50%", 3/4*pi)`-style check passes
# on one platform and reddens on another (observed on PR #343 for the sibling
# smooth-curves file: same commit, green on GHA attempt 1, red on attempt 2,
# errors locally under thread nondeterminism). The old form here also hardcoded
# `alignment1`/`alignmentAll` as the correct mode, which breaks whenever a
# different alignment lands there. See the project note "MCMC value tests not
# portable".
#
# CI contract here = does-it-run + well-formed output:
#   * RunStratModel() + summary() complete without error on noisy data,
#   * summary carries the expected parameter rows and >=1 alignment,
#   * every reported estimate is finite (no NA/NaN),
#   * the alignment = "none" summary path (alignmentAll block) is exercised.
#
# The actual value-recovery oracle (matching noisy sine -> alpha_b ~ 3/4*pi,
# gammaLog_b ~ 0 across both sigma paths and two data sizes) lives in
# dev/red-team/heavy-tests/noisy-curve-alignment-recovery.R as a relative,
# multi-seed median check, where cross-platform variance is handled by the
# median over seeds rather than pretended away.

test_that("noisy curves: RunStratModel wiring runs and returns well-formed output", {

  skip_on_cran() # slow

  # Don't use parallel evaluation unless future.apply is installed
  canRunParallel <- requireNamespace("future.apply", quietly = TRUE)

  # Structural, platform-independent checks on a single summary block.
  expect_wellformed_block <- function(s, params = c("alpha_b", "gammaLog_b")) {
    expect_true(all(params %in% rownames(s)))
    expect_true(all(c("mean", "50%") %in% colnames(s)))
    # No NA/NaN in the estimates we key inference off. `$summary` is a
    # data.frame, so coerce the block to a numeric matrix before is.finite().
    expect_true(all(is.finite(as.matrix(s[params, c("mean", "50%")]))))
  }

  # Assert only structural facts about a default (all-alignment) summary().
  expect_wellformed_summary <- function(estimates,
                                        params = c("alpha_b", "gammaLog_b")) {
    expect_s3_class(estimates, "summary.StratPosterior")
    nAl <- estimates$general$overallAlignments
    expect_true(is.numeric(nAl) && nAl >= 1)
    for (a in seq_len(nAl)) {
      expect_wellformed_block(estimates[[a]][["summary"]], params)
    }
  }

  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))

  # Two matching noisy sine curves offset by 3/4*pi on the common (height) scale.
  set.seed(0)
  n1 <- 500
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1) + rnorm(n1, 0, 0.15)
  n2 <- 250
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2) + rnorm(n2, 0, 0.15)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)

  # Path 1: sigma fixed.
  modelFixed <- StratModel(stratData = stratD,
                           priors = priors,
                           alignmentScale = "height",
                           sedModel = "site",
                           alphaPosition = "middle",
                           nKnots = 10,
                           overlapPenalty = TRUE,
                           sigmaFixed = TRUE)

  rFixed <- RunStratModel(stratObject = stratD,
                          stratModel = modelFixed,
                          nRun = 2,
                          nIter = 200,
                          nThreads = 2L, # CLAUDE.md CPU cap
                          runParallel = canRunParallel,
                          visualise = FALSE,
                          seed = 1:2)

  expect_wellformed_summary(summary(rFixed))

  # Path 2: sigma estimated (a genuinely different code path).
  modelEst <- StratModel(stratData = stratD,
                         priors = priors,
                         alignmentScale = "height",
                         sedModel = "site",
                         alphaPosition = "middle",
                         nKnots = 10,
                         overlapPenalty = TRUE,
                         sigmaFixed = FALSE)

  rEst <- RunStratModel(stratObject = stratD,
                        stratModel = modelEst,
                        nRun = 2,
                        nIter = 200,
                        nThreads = 2L, # CLAUDE.md CPU cap
                        runParallel = canRunParallel,
                        visualise = FALSE,
                        seed = 1:2)

  expect_wellformed_summary(summary(rEst))

  # Path 3: low-n data through the alignment = "none" summary path, which yields
  # a single `alignmentAll` block instead of per-alignment blocks. Low-n +
  # estimated sigma is the fragile regime the value oracle pins; here we only
  # assert the alignmentAll summary is well-formed and finite.
  set.seed(0)
  n1 <- 30
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1) + rnorm(n1, 0, 0.1)
  n2 <- 15
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2) + rnorm(n2, 0, 0.1)
  x2 <- x2 - 1/2 * pi
  testDLow <- data.frame(height = c(x1, x2),
                         value = c(y1, y2),
                         site = c(rep("a", n1), rep("b", n2)))
  stratDLow <- StratData(testDLow)

  modelLowEst <- StratModel(stratData = stratDLow,
                            priors = priors,
                            alignmentScale = "height",
                            sedModel = "site",
                            alphaPosition = "middle",
                            nKnots = 10,
                            overlapPenalty = TRUE,
                            sigmaFixed = FALSE)

  rLowEst <- RunStratModel(stratObject = stratDLow,
                           stratModel = modelLowEst,
                           nRun = 2,
                           nIter = 200,
                           nThreads = 2L, # CLAUDE.md CPU cap
                           runParallel = canRunParallel,
                           visualise = FALSE,
                           seed = 1:2)

  estNone <- summary(rLowEst, alignment = "none")
  expect_s3_class(estNone, "summary.StratPosterior")
  expect_wellformed_block(estNone[[c("alignmentAll", "summary")]])
})
