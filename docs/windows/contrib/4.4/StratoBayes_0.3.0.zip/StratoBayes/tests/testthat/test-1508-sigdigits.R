# #1508: below 1 the leading zeros after the point ate the digit budget, so
# `sigDigits` under-delivered -- 1.05e-05 printed as "0.00001", one
# significant figure, as if exact.

test_that(".RoundToSigDigits() keeps the digit budget below 1 (#1508)", {
  Fmt <- function(x, digits = 6) {
    .RoundToSigDigits(data.frame(v = x), sigDigits = digits)[["v"]]
  }
  # Trailing zeros are significant in a fixed-decimal display; leading ones
  # after the point are not.
  SigFigs <- function(s) {
    nchar(gsub("\\.", "", sub("^0\\.0*", "", sub("^-", "", s))))
  }
  expect_identical(Fmt(0.5), "0.500000")
  expect_identical(Fmt(0.05), "0.0500000")
  expect_equal(SigFigs(Fmt(1.05e-05)), 6)

  # #682's family must not regress.
  expect_identical(Fmt(9.5), "9.50000")
  expect_identical(Fmt(99.5), "99.5000")
})
