# Targeted regression tests for #1891, #1894, #1895.

test_that("#1891: .CheckVisualise() rejects a length > 1 interval instead of
          letting it reach the loop and crash with 'the condition has length
          > 1' after files are already written", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  expect_error(
    StratoBayes:::.CheckVisualise(
      list(interval = c(1, 2), signal = 1, parameter = 1),
      stratData1, stratModel1
    ),
    "single non-negative, finite value"
  )
})

test_that("#1891: .CheckVisualise() still accepts interval = 0 -- an
          established sentinel (e.g. `visualise = interactive() * 50`,
          used by test-zzy-RunStratModel.R, resolves to 0 in a non-interactive
          CI run) meaning 'disabled', not an error", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  checked <- StratoBayes:::.CheckVisualise(
    list(interval = 0, signal = 1, parameter = 1),
    stratData1, stratModel1
  )
  expect_equal(checked[["interval"]], 0)
})

test_that("#1891: .CheckVisualise() rejects a negative interval rather than
          plotting at every checkpoint", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  expect_error(
    StratoBayes:::.CheckVisualise(
      list(interval = -1, signal = 1, parameter = 1),
      stratData1, stratModel1
    ),
    "single non-negative, finite value"
  )
})

test_that("#1891: .CheckVisualise() still accepts a valid single positive
          interval", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  checked <- StratoBayes:::.CheckVisualise(
    list(interval = 5, signal = 1, parameter = 1),
    stratData1, stratModel1
  )
  expect_equal(checked[["interval"]], 5)
})

test_that("#1894: writing the diagnostic from inside withCallingHandlers()'s
          own error handler captures the real call stack via sys.calls(),
          where the old tryCatch()+traceback() approach captured nothing", {
  # This pins the exact mechanism RunStratModel.R's parallel worker now uses
  # (R/RunStratModel.R:~1162-1224) to fix #1894: the diagnostic is written
  # directly inside `withCallingHandlers()`'s `error =` handler, which runs
  # *before* the stack unwinds, so `sys.calls()` there sees the real call
  # stack (including the deep frames) and the condition then keeps
  # propagating normally since the handler doesn't invoke a restart.
  #
  # Exercising this through an actual `RunStratModel(runParallel = TRUE)`
  # call is impractical to pin directly: that path unconditionally
  # dispatches via `future::plan(multisession, ...)`, which runs the worker
  # closure in a genuinely separate process where no in-process test double
  # can reach it. This test instead confirms the language-level mechanism
  # those lines rely on, reproduced verbatim in shape.
  deepFn <- function() stop("boom")
  midFn <- function() deepFn()

  callingHandlerText <- NULL
  expect_error(
    withCallingHandlers({
      midFn()
    }, error = function(e) {
      callingHandlerText <<- paste(
        conditionMessage(e), "\n",
        paste(utils::capture.output(print(sys.calls())), collapse = "\n")
      )
    }),
    "boom"
  )
  expect_true(grepl("midFn", callingHandlerText, fixed = TRUE))
  expect_true(grepl("deepFn", callingHandlerText, fixed = TRUE))

  # The old approach: no calling handler, just traceback() in a tryCatch()
  # handler -- reproduces the pre-fix bug (empty/no useful stack there).
  viaTraceback <- tryCatch({
    midFn()
  }, error = function(e) {
    utils::capture.output(traceback())
  })
  expect_true(grepl("No traceback available",
                    paste(viaTraceback, collapse = "\n"),
                    fixed = TRUE))
})

test_that("#1895: the sequential path's on.exit(Rprof(NULL)) guard is
          registered once, not once per run, so it doesn't accumulate on
          RunStratModel()'s exit list across nRun > 1 runs", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  rprofCalls <- character(0)
  fakeRprof <- function(filename = NULL, ...) {
    rprofCalls <<- c(rprofCalls, if (is.null(filename)) "stop" else "start")
  }

  testthat::local_mocked_bindings(
    .InnerRunMCMC = function(...) NULL,
    .package = "StratoBayes"
  )
  testthat::local_mocked_bindings(
    StratPosterior = function(...) NULL,
    .package = "StratoBayes"
  )
  testthat::local_mocked_bindings(Rprof = fakeRprof, .package = "utils")

  RunStratModel(stratData1, stratModel = stratModel1, nRun = 3, nIter = 2,
                nChains = 2, visualise = FALSE, seed = 1:3,
                runParallel = FALSE, profile = TRUE)

  # 3 explicit start/stop pairs from the loop, plus exactly one further
  # "stop" from the safety-net on.exit() firing once at function exit.
  # Before the fix, one on.exit(Rprof(NULL)) was registered *per run*
  # inside the loop, so all 3 fired at exit and the trailing run of
  # "stop"s was 3 long instead of 1.
  expect_equal(
    rprofCalls,
    c("start", "stop", "start", "stop", "start", "stop", "stop")
  )
})
