# RT-753: the set of built-in prior names is stated in R (`.priorTypeArgNames`)
# and in C++ (`src/sb_prior_types.h`), and the two cannot be derived from each
# other across the boundary. Drift in one direction is loud -- C++ stops with
# "Unknown prior type" -- but in the other it is silent: R pushes the density
# into `rCustomFns`, which makes `customPriorDensity` non-empty and switches
# threading off with no diagnostic.

test_that("R and C++ agree on which prior types are built in", {
  header <- test_path("..", "..", "src", "sb_prior_types.h")
  # This runs on a developer laptop and in NO CI lane at all: under `R CMD
  # check` the path resolves to `<pkg>.Rcheck/src`, which never exists, and both
  # the merge gate and the nightly cron go through `R CMD check`. Emitting the
  # names into `inst/` at build time would be the fix.
  skip_if_not(file.exists(header), "package source not available")

  lines <- readLines(header)
  # Scoped to `sb_is_known_prior_type`'s body: `sb_prior_arg_names` below it
  # states every name again in the same `s == "..."` form, so a scrape of the
  # whole file counts each type twice.
  start <- grep("^inline bool sb_is_known_prior_type", lines)
  expect_length(start, 1L)
  # `ends` takes the next such definition AFTER `start`, so reordering the
  # header widens the slice rather than silently reversing it.
  ends <- grep("^inline std::vector<std::string> sb_prior_arg_names", lines)
  ends <- c(ends[ends > start], length(lines) + 1L)
  known <- lines[seq(start, ends[[1]] - 1L)]
  named <- unlist(regmatches(known, gregexpr('(?<=s == ")[^"]+', known,
                                             perl = TRUE)))
  expect_length(named, length(.priorTypeArgNames))
  expect_setequal(named, names(.priorTypeArgNames))
})

test_that("every built-in prior constructor is registered", {
  # The classes `R/Prior.R` stamps are the third statement of the same set; a
  # constructor missing from `.priorTypeArgNames` would be scored as a custom
  # prior, again disabling threading.
  built <- list(UniformPrior(0, 1), NormalPrior(0, 1), LogNormalPrior(0, 1),
                ExponentialPrior(1), TruncNormalPrior(0, 1, -1, 1),
                TruncLogNormalPrior(0, 1, 0.1, 2), Fixed(1))
  expect_setequal(vapply(built, function(p) class(p)[[1]], character(1)),
                  names(.priorTypeArgNames))
})

test_that("R and C++ agree on each built-in prior's argument names", {
  # `sb_prior_arg_names` is what `.sb_logpost`'s wrapper demands of `priorArgs`
  # before delegating (#1949), so a name that drifts from `.priorTypeArgNames`
  # rejects a legitimate prior -- or, worse, lets one through to a read that
  # throws from inside the implementation frame.
  header <- test_path("..", "..", "src", "sb_prior_types.h")
  skip_if_not(file.exists(header), "package source not available")

  rows <- grep('s == "', grep("return \\{", readLines(header), value = TRUE),
               value = TRUE)
  types <- sub('.*s == "([^"]+)".*', "\\1", rows)
  cppArgs <- lapply(rows, function(row) {
    braced <- sub(".*return \\{", "", row)
    gsub('"', "", regmatches(braced, gregexpr('"[^"]+"', braced))[[1]])
  })
  names(cppArgs) <- types

  # `Fixed` is absent by design: `logprior_one()` returns log(1) without
  # reading its `value`.
  expect_false("Fixed" %in% types)
  expect_setequal(types, setdiff(names(.priorTypeArgNames), "Fixed"))
  expect_equal(cppArgs, .priorTypeArgNames[types])
})
