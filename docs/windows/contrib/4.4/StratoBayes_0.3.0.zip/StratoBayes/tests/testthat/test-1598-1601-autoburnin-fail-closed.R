# A diagnostic that excludes what it was asked to check is not a diagnostic.
# #1598, #1599 and #1600 each certified an outcome while silently dropping the
# thing under assessment: an interior bad draw, a poisoned parameter, and the
# adaptation phase respectively.

# Deterministic, well-mixed draws: two runs that agree, so R-hat passes and
# nothing but the injected poison can refute a candidate.
TwoGoodRuns <- function(n = 40L, seed = 1L) {
  set.seed(seed)
  lapply(1:2, function(r) {
    cbind(a = stats::rnorm(n), b = stats::rnorm(n))
  })
}

test_that(".CompleteSampleRows() stops at the first gap, not the last clean row (#1598)", {
  nRow <- 10L
  iter <- list(seq_len(nRow) * 10)
  Samples <- function() {
    array(stats::rnorm(nRow * 3), dim = c(nRow, 3, 1, 1),
          dimnames = list(NULL, c("a", "b", "posterior"), NULL, "chain1"))
  }

  set.seed(2)
  naAt5 <- Samples()
  naAt5[5, 2, 1, 1] <- NA_real_
  # Rows 6:10 are clean, so `max(which(complete.cases()))` reported row 10 and
  # #1311's degradation warning could never fire.
  expect_equal(.CompleteSampleRows(naAt5, 1L, iter), 40)

  set.seed(2)
  nanAt3 <- Samples()
  nanAt3[3, 1, 1, 1] <- NaN
  expect_equal(.CompleteSampleRows(nanAt3, 1L, iter), 20)

  # A `logPostSep` component is legitimately -Inf on an out-of-support state,
  # so it must NOT truncate the run -- least of all at row 1, which would
  # leave the whole posterior unloadable.
  set.seed(2)
  negInfAt1 <- Samples()
  negInfAt1[1, 3, 1, 1] <- -Inf
  expect_equal(.CompleteSampleRows(negInfAt1, 1L, iter), 100)

  set.seed(2)
  clean <- Samples()
  expect_equal(.CompleteSampleRows(clean, 1L, iter), 100)

  trailing <- clean
  trailing[8:10, 2, 1, 1] <- NA_real_
  expect_equal(.CompleteSampleRows(trailing, 1L, iter), 70)

  allBad <- clean
  allBad[, 2, 1, 1] <- NA_real_
  expect_equal(.CompleteSampleRows(allBad, 1L, iter), 0)
})

test_that("a healthy posterior's completeIter is a fixed point (#1598)", {
  # An invariant guard, not a detector: every shipped fixture is already free
  # of non-finite draws, so this pins that the first-gap rewrite leaves an
  # undamaged run exactly where the old code left it.
  for (nm in c("stratPosterior1", "stratPosterior2", "stratPosterior4")) {
    post <- get(nm, envir = asNamespace("StratoBayes"))
    samples <- post[["samples"]]
    expect_equal(
      .CompleteSampleRows(samples, dim(samples)[[3]],
                          post[[c("mcmcSummary", "saveIter")]]),
      post[[c("mcmcSummary", "completedIter")]]
    )
  }
})

test_that(".AutoBurnInCore() refuses to certify a parameter it could not assess (#1599)", {
  draws <- TwoGoodRuns()
  iter <- rep(list(seq_len(40L) * 10), 2)

  clean <- .AutoBurnInCore(draws, iter, essTarget = 0)
  expect_identical(clean[["status"]], "ok")
  expect_identical(clean[["parametersDropped"]], character(0))

  poisoned <- draws
  poisoned[[1]][7, "b"] <- NaN
  res <- .AutoBurnInCore(poisoned, iter, essTarget = 0)
  # Column `a` alone met every criterion, so the search certified "ok" while
  # `b` -- the reason the run is suspect -- was never assessed.
  expect_false(identical(res[["status"]], "ok"))
  expect_identical(res[["status"]], "nonFiniteDraws")
  expect_identical(res[["parametersDropped"]], "b")
  expect_match(.AutoBurnInMessage(res), "\\bb\\b")

  # Poisoning every column already failed closed, and still must -- though the
  # status it fails with is now `nonFiniteDraws` rather than `unevaluable`.
  bothBad <- draws
  bothBad[[1]][7, ] <- NaN
  expect_false(identical(.AutoBurnInCore(bothBad, iter)[["status"]], "ok"))

  # A column with no finite draw anywhere was never recorded rather than
  # damaged, and must stay a silent drop: the guard may not fire on it.
  unrecorded <- lapply(draws, function(m) {
    m[, "b"] <- NA_real_
    m
  })
  expect_identical(.AutoBurnInCore(unrecorded, iter)[["status"]], "ok")
})

test_that("the damage screen reads rows the search decimates away (#1599)", {
  # Above `searchMaxDraws` the search keeps every kth row, and `convergenceStop`
  # always is (its cap is 1000 against a 4096-row store) -- so screening the
  # decimated copy would fail open on precisely the long runs #1599 is about.
  n <- 500L
  set.seed(9)
  draws <- lapply(1:2, function(r) cbind(a = stats::rnorm(n), b = stats::rnorm(n)))
  iter <- rep(list(seq_len(n) * 10), 2)

  kept <- seq.int(1L, n, by = ceiling(n / 100))
  dropped <- setdiff(seq_len(n), kept)[[1]]

  poisoned <- draws
  poisoned[[1]][dropped, "b"] <- NaN
  res <- .AutoBurnInCore(poisoned, iter, searchMaxDraws = 100L)
  expect_identical(res[["status"]], "nonFiniteDraws")
  expect_identical(res[["parametersDropped"]], "b")
})

test_that("an out-of-support -Inf log density is not read as damage (#1599)", {
  # Only the summed `logPost` is clamped to -1e30; a `logPostSep` component is
  # left at -Inf, so vetoing every non-finite draw would refuse a healthy run.
  draws <- TwoGoodRuns()
  iter <- rep(list(seq_len(40L) * 10), 2)
  draws[[1]][6, "b"] <- -Inf

  res <- .AutoBurnInCore(draws, iter, essTarget = 0)
  expect_false(identical(res[["status"]], "nonFiniteDraws"))
})

test_that("convergenceStop does not certify a run holding a non-finite draw (#1599)", {
  draws <- TwoGoodRuns()
  iter <- rep(list(seq_len(40L) * 10), 2)
  draws[[2]][11, "b"] <- NaN

  drawSet <- list(drawList = draws, iterList = iter, floorIter = 0)
  criteria <- list(rHat = 1.5, ess = 5)
  expect_false(.ConvergenceCriteriaMet(drawSet, criteria))

  clean <- list(drawList = TwoGoodRuns(), iterList = iter, floorIter = 0)
  expect_true(.ConvergenceCriteriaMet(clean, criteria))
})

test_that("the burn-in fallback is an absolute iteration honouring floorIter (#1600)", {
  shortIter <- seq(10, 1000, 10)
  longIter <- seq(10, 100000, 10)
  endAdapting <- 50000

  set.seed(3)
  draws <- list(cbind(a = stats::rnorm(length(shortIter))),
                cbind(a = stats::rnorm(length(longIter))))
  res <- .AutoBurnInCore(draws, list(shortIter, longIter),
                         floorIter = endAdapting, essTarget = 1e9)
  expect_true(.AutoBurnInFellBack(res[["status"]]))

  chosen <- .ResolvedOrWarn(res)
  # The fallback used to return the proportion 0.95, which `.BurnInIteration()`
  # resolved against the SHORTEST run to iteration 950 -- retaining 99% of the
  # long run, 4905 rows of it adaptation-phase draws.
  expect_gte(chosen, endAdapting)
  expect_gte(chosen, 0.95 * max(longIter))

  applied <- .BurnInIteration(shortIter, longIter, max(shortIter), chosen)
  expect_gte(applied, endAdapting)
  expect_lte(mean(longIter > applied), 0.05)
  expect_equal(sum(longIter > applied & longIter <= endAdapting), 0)

  expect_match(.AutoBurnInMessage(res), "iterations after")
})

test_that("the fallback clamps up to floorIter when 95% falls short of it (#1600)", {
  iter <- seq(10, 1000, 10)
  set.seed(4)
  draws <- list(cbind(a = stats::rnorm(length(iter))))
  res <- .AutoBurnInCore(draws, list(iter), floorIter = 980, essTarget = 1e9)
  expect_true(.AutoBurnInFellBack(res[["status"]]))
  expect_gte(.ResolvedOrWarn(res), 980)
})

test_that("a run wholly inside adaptation still yields a plottable fallback (#1600)", {
  # No admissible burn-in exists here, so the fallback keeps everything rather
  # than erroring: `TracePlot()` and friends must still draw the run. The
  # message says it is not a posterior sample, which is the honest claim.
  iter <- seq(10, 500, 10)
  set.seed(5)
  draws <- list(cbind(a = stats::rnorm(length(iter))))
  res <- .AutoBurnInCore(draws, list(iter), floorIter = 5000, essTarget = 1e9)
  expect_warning(chosen <- .ResolvedOrWarn(res), "none certified")
  expect_identical(chosen, 0)
  expect_match(.AutoBurnInMessage(res), "keeping everything")
})

test_that("the fallback stays admissible for a single short run (#1600)", {
  # `.AutoBurnIn()` resolves over every run but its answer is applied to
  # whichever the caller selects, so a threshold past a shorter run's last
  # iteration would make `plot(x, runs = 2)` error where it used to work.
  shortIter <- seq(10, 1250, 10)
  longIter <- seq(10, 5000, 10)
  set.seed(8)
  draws <- list(cbind(a = stats::rnorm(length(longIter))),
                cbind(a = stats::rnorm(length(shortIter))))
  res <- .AutoBurnInCore(draws, list(longIter, shortIter), floorIter = 500,
                         essTarget = 1e9)
  chosen <- suppressWarnings(.ResolvedOrWarn(res))
  expect_gte(chosen, 500)
  expect_lt(chosen, max(shortIter))
  expect_gt(sum(shortIter > chosen), 0)
  expect_no_error(.BurnInIteration(shortIter, shortIter, max(shortIter), chosen))

  # A short run still inside adaptation cannot be accommodated, and must not
  # drag the threshold back down over the long run's adaptation phase.
  inAdapt <- .AutoBurnInCore(draws, list(longIter, shortIter), floorIter = 2500,
                             essTarget = 1e9)
  expect_gte(suppressWarnings(.ResolvedOrWarn(inAdapt)), 2500)
})

test_that("essNotReached names the draws available, not 'NA' (#1601)", {
  iter <- rep(list(seq_len(30L) * 10), 2)
  set.seed(6)
  draws <- lapply(1:2, function(r) cbind(a = stats::rnorm(30L)))
  res <- .AutoBurnInCore(draws, iter, essTarget = 1e6, stopAtFirst = TRUE)
  expect_identical(res[["status"]], "essNotReached")
  msg <- .AutoBurnInMessage(res)
  expect_false(grepl("ESS NA", msg, fixed = TRUE))
  expect_match(msg, "1e\\+06|1000000")
})

test_that("one non-finite acceptance draw does not NA the whole run's rate (#1601)", {
  post <- get("stratPosterior1", envir = asNamespace("StratoBayes"))
  clean <- summary(post, runs = 1)[[c("general", "meanAcceptancePercent")]]
  expect_false(is.na(clean))

  # The LAST saved row: `Acceptance` is extracted after burn-in, so an early
  # row is discarded before `mean()` ever sees it.
  poisoned <- post
  poisoned[["samples"]][dim(post[["samples"]])[[1]], "proposal_accepted",
                        1, 1] <- NA_real_
  got <- summary(poisoned, runs = 1)[[c("general", "meanAcceptancePercent")]]
  expect_false(is.na(got))
  expect_equal(got, clean, tolerance = 0.02)
})

test_that("the variance screen ignores the adaptation phase (#1601)", {
  iter <- seq(10, 400, 10)
  set.seed(7)
  # `b` varies only while adapting and is constant afterwards, so it pins
  # min-ESS at 1 for every admissible candidate -- exactly what the screen is
  # there to remove.
  b <- c(stats::rnorm(20), rep(0, 20))
  draws <- rep(list(cbind(a = stats::rnorm(40), b = b)), 2)
  res <- .AutoBurnInCore(draws, list(iter, iter), floorIter = 200,
                         essTarget = 10)
  expect_identical(res[["status"]], "ok")
})

test_that("print.StratModel() and summary.StratMCMC() emit no carriage returns (#1509)", {
  model <- get("stratModel1", envir = asNamespace("StratoBayes"))
  expect_false(any(grepl("\r", capture.output(print(model)), fixed = TRUE)))

  mcmc <- get("stratMCMC1", envir = asNamespace("StratoBayes"))
  expect_false(any(grepl("\r", capture.output(summary(mcmc)), fixed = TRUE)))
})
