test_that("sb_spline_design matches splines::splineDesign on uniform knots", {
  for (nKnots in c(5, 10, 20, 50)) {
    knots <- seq(0, 1, length.out = nKnots)
    ord <- 4L
    ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[nKnots], ord - 1))
    x <- seq(knots[1], knots[nKnots], length.out = 100)

    B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
    B_cpp <- .sb_spline_design(ext_knots, x, ord)

    expect_equal(dim(B_cpp), dim(B_r))
    expect_true(max(abs(B_cpp - B_r)) < 1e-12,
      info = paste("nKnots =", nKnots))
  }
})

test_that("sb_spline_design matches on non-uniform knots", {
  knots <- c(0, 0.1, 0.3, 0.35, 0.7, 0.9, 1.0)
  ord <- 4L
  ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
  x <- sort(runif(200, knots[1], knots[length(knots)]))

  B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
  B_cpp <- .sb_spline_design(ext_knots, x, ord)

  expect_equal(dim(B_cpp), dim(B_r))
  expect_true(max(abs(B_cpp - B_r)) < 1e-12)
})

test_that("sb_spline_design handles evaluation at knot boundaries", {
  knots <- seq(0, 10, by = 2)
  ord <- 4L
  ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
  # Evaluate exactly at internal knots + boundaries
  x <- knots

  B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
  B_cpp <- .sb_spline_design(ext_knots, x, ord)

  expect_equal(dim(B_cpp), dim(B_r))
  expect_true(max(abs(B_cpp - B_r)) < 1e-12)
})

test_that("sb_spline_design handles single evaluation point", {
  knots <- seq(0, 1, length.out = 8)
  ord <- 4L
  ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
  x <- 0.5

  B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
  B_cpp <- .sb_spline_design(ext_knots, x, ord)

  expect_equal(dim(B_cpp), dim(B_r))
  expect_true(max(abs(B_cpp - B_r)) < 1e-12)
})

test_that("sb_spline_design rows sum to 1 (partition of unity)", {
  knots <- seq(0, 5, length.out = 12)
  ord <- 4L
  ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
  x <- seq(knots[1], knots[length(knots)], length.out = 500)

  B_cpp <- .sb_spline_design(ext_knots, x, ord)
  row_sums <- rowSums(B_cpp)

  expect_true(all(abs(row_sums - 1.0) < 1e-12))
})

test_that("sb_spline_design matches with geological-scale ages", {
  # Typical StratoBayes use: ages in Ma
  knots <- seq(65, 100, length.out = 15)
  ord <- 4L
  ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
  x <- sort(runif(300, 65, 100))

  B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
  B_cpp <- .sb_spline_design(ext_knots, x, ord)

  expect_equal(dim(B_cpp), dim(B_r))
  expect_true(max(abs(B_cpp - B_r)) < 1e-12)
})

test_that("sb_spline_design rejects ord > 32 and accepts ord == 32", {
  # 2 * ord - 1 knots: the shortest vector order 32 can be evaluated on. The
  # previous 40-knot vector was too short, so this test used to read out of
  # bounds rather than exercise the ord boundary it was written for (#961).
  knots <- seq(0, 1, length.out = 2L * 32L - 1L)
  x <- 0.5

  expect_error(.sb_spline_design(knots, x, 33L), "32")
  expect_no_error(.sb_spline_design(knots, x, 32L))
})

test_that("sb_spline_design rejects a knot vector shorter than 2 * ord - 1 (#961)", {
  expect_error(.sb_spline_design(seq(0, 1, length.out = 40), 0.5, 32L),
               "2 \\* ord - 1")
  expect_error(.sb_spline_design(seq(0, 1, length.out = 6), 0.5, 4L),
               "2 \\* ord - 1")
  expect_no_error(.sb_spline_design(seq(0, 1, length.out = 7), 0.5, 4L))

  # ord < 1 escapes the length relation (2 * 0 - 1 = -1) but still makes
  # find_span read knots[nknots] on its first line.
  expect_error(.sb_spline_design(seq(0, 1, length.out = 10), 0.5, 0L), "ord")
  expect_error(.sb_spline_design(seq(0, 1, length.out = 10), 0.5, -1L), "ord")
})

test_that("sb_spline_design handles order 2 (linear) and 3 (quadratic)", {
  knots <- seq(0, 1, length.out = 8)
  x <- seq(0, 1, length.out = 50)

  for (ord in c(2L, 3L)) {
    ext_knots <- c(rep(knots[1], ord - 1), knots, rep(knots[length(knots)], ord - 1))
    B_r   <- splines::splineDesign(ext_knots, x, ord = ord, sparse = FALSE)
    B_cpp <- .sb_spline_design(ext_knots, x, ord)

    expect_equal(dim(B_cpp), dim(B_r), info = paste("order =", ord))
    expect_true(max(abs(B_cpp - B_r)) < 1e-12, info = paste("order =", ord))
  }
})

# This guard also keeps find_span() from ever seeing the below-range x that
# could stall it (RT-696), so that termination is no longer testable here.
test_that("sb_spline_design rejects x outside the knot range (#1912)", {
  knots <- seq(0, 10, length.out = 8)
  ord <- 4L
  extKnots <- c(rep(knots[1], ord - 1), knots, rep(knots[8], ord - 1))

  expect_error(.sb_spline_design(extKnots, c(-5, 0, 5), ord), "range")
  expect_error(.sb_spline_design(extKnots, c(0, 10.5), ord), "range")
  expect_error(splines::splineDesign(extKnots, 10.5, ord = ord), "range")
  expect_equal(.sb_spline_design(extKnots, c(0, 5, 10), ord),
               splines::splineDesign(extKnots, c(0, 5, 10), ord = ord))
})
