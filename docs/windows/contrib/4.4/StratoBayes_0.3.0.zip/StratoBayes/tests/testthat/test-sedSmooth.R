# tests/testthat/test-sedSmooth.R
# Tests for P-spline variable sedimentation rate (sedSmooth)

test_that("sedSmooth defaults to FALSE (backward compatibility)", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", nKnots = 10)
  expect_false(model[["sedSmooth"]])
  expect_null(model[["sedSmoothInfo"]])
  # gamma parameters should be present
  expect_true(length(model[["ind"]][["gamma"]]) > 0)
})

test_that(".SetupSedSmooth creates correct structures", {
  sedInfo <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)

  # stratData1 has 3 sites, height scale -> sites 2,3 each have 1 partition

  expect_equal(sedInfo$nFormations, 2)
  expect_equal(sedInfo$nBasis, 6)
  expect_equal(sedInfo$totalBeta, 12)  # 2 formations x 6 basis

  # Check betaMap
  expect_equal(sedInfo$betaMap[1, 2], 1L)
  expect_equal(sedInfo$betaMap[1, 3], 2L)
  expect_true(is.na(sedInfo$betaMap[1, 1]))  # site 1 is reference

  # Check formations
  for (f in seq_len(sedInfo$nFormations)) {
    form <- sedInfo$formations[[f]]
    expect_equal(form$nBasis, 6)
    expect_true(is.matrix(form$D))
    expect_equal(dim(form$D), c(6, 6))
    expect_true(is.numeric(form$nodes))
    expect_true(is.numeric(form$weights))
    expect_true(length(form$nodes) == length(form$weights))
    expect_true(is.matrix(form$basisAtNodes))
  }
})

test_that("Gauss-Legendre quadrature is correct for polynomials", {
  gl5 <- .GaussLegendre(5L)
  expect_length(gl5$x, 5L)
  # 5-point GL should exactly integrate polynomials up to degree 9
  # Test: integral of x^4 from -1 to 1 = 2/5
  expect_equal(sum(gl5$w * gl5$x^4), 2/5, tolerance = 1e-14)
  # Test: integral of x^2 from -1 to 1 = 2/3
  expect_equal(sum(gl5$w * gl5$x^2), 2/3, tolerance = 1e-14)
  # Degrees 6 and 8 are beyond a 3-point rule (exact to degree 5), so these
  # discriminate a 5-point rule from a silently-lower-order one
  expect_equal(sum(gl5$w * gl5$x^6), 2/7, tolerance = 1e-14)
  expect_equal(sum(gl5$w * gl5$x^8), 2/9, tolerance = 1e-14)
})

test_that("quadrature integration matches analytic results for constant s(t)", {
  sedInfo <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)
  sedBeta <- rep(0, sedInfo$totalBeta)

  # With beta=0, exp(s(t))=1, integral from a to b should = b - a
  for (f in seq_len(sedInfo$nFormations)) {
    form <- sedInfo$formations[[f]]
    fullInt <- .SedSplineFullIntegral(sedBeta, sedInfo, f)
    expected <- as.numeric(form$hHigh - form$hLow)
    expect_equal(fullInt, expected, tolerance = 1e-10,
                 label = paste("full integral formation", f))
  }

  # Partial integral
  partInt <- .SedSplinePartialIntegral(sedBeta, sedInfo, 1, 0, 1.0)
  expect_equal(partInt, 1.0, tolerance = 1e-10)
})

# ── Overlap taper weights ─────────────────────────────────────────────────────

test_that(".ComputeOverlapTaperWeights produces valid weights", {
  w <- .ComputeOverlapTaperWeights(stratData1, taperFraction = 0.15)

  expect_type(w, "list")
  expect_length(w, stratData1[["signalAttr"]][["signalN"]])

  wv <- w[[1]]
  expect_true(all(wv >= 0 & wv <= 1))
  # Boundary observations should get weight 0
  expect_equal(wv[1], 0)
  # Interior observations should get weight 1
  expect_true(any(wv == 1))
})

test_that("taper weights are stored in StratModel when sedSmooth = TRUE", {
  m <- StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                  priors = AutoPrior(stratData1, "height"), sedSmooth = TRUE)
  w <- m[["overlapPenalty"]][["weights"]]
  expect_type(w, "list")
  expect_length(w, 1)  # 1 signal
  expect_true(all(w[[1]] >= 0 & w[[1]] <= 1))
})

test_that("taper weights are absent when sedSmooth = FALSE", {
  m <- StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                  priors = AutoPrior(stratData1, "height"), sedSmooth = FALSE)
  expect_null(m[["overlapPenalty"]][["weights"]])
})

test_that("taper weights are absent when overlapPenalty = FALSE", {
  m <- StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                  priors = AutoPrior(stratData1, "height"), sedSmooth = TRUE,
                  overlapPenalty = FALSE)
  expect_null(m[["overlapPenalty"]][["weights"]])
})

test_that("taper weights are stored for a numeric sedSmooth config (RT-314)", {
  # RT-314: the taper-weight gate used isTRUE(sedSmooth), which is FALSE for a
  # numeric config (isTRUE(3L) == FALSE), so `sedSmooth = <int>` built the spline
  # but silently skipped the overlap taper -> untapered penalty biases boundary
  # rates. The gate must key off sedSmoothActive, not isTRUE(sedSmooth). A numeric
  # config must populate weights identically to sedSmooth = TRUE.
  mNum <- StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                     priors = AutoPrior(stratData1, "height"), sedSmooth = 3)
  w <- mNum[["overlapPenalty"]][["weights"]]
  expect_type(w, "list")
  expect_length(w, 1)  # 1 signal
  expect_true(all(w[[1]] >= 0 & w[[1]] <= 1))

  # ...and they match the TRUE-config weights (both go through the same taper)
  mTrue <- StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                      priors = AutoPrior(stratData1, "height"), sedSmooth = TRUE)
  expect_equal(w, mTrue[["overlapPenalty"]][["weights"]])
})

test_that("quadrature integration matches for constant s(t) = log(c)", {
  sedInfo <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)

  # With beta = log(3), exp(s(t)) = 3, integral from a to b = 3*(b-a)
  sedBeta <- rep(log(3), sedInfo$totalBeta)

  for (f in seq_len(sedInfo$nFormations)) {
    form <- sedInfo$formations[[f]]
    fullInt <- .SedSplineFullIntegral(sedBeta, sedInfo, f)
    expected <- 3 * as.numeric(form$hHigh - form$hLow)
    expect_equal(fullInt, expected, tolerance = 1e-6,
                 label = paste("full integral formation", f, "s(t)=log(3)"))
  }
})

test_that("sedSmooth beta=0 matches constant gammaLog=0", {
  # Create indices for both models
  ind_smooth <- .CreateIndices(stratData1, "height", "site, partition",
                               "middle", sedSmooth = TRUE)
  ind_const <- .CreateIndices(stratData1, "height", "site, partition",
                              "middle", sedSmooth = FALSE)

  sedInfo <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)
  sedBeta <- rep(0, sedInfo$totalBeta)

  # alpha_site2 = 5, alpha_site3 = 5
  params_smooth <- c(5, 5)
  params_const <- c(5, 5, 0, 0)  # + gammaLog = 0 for both sites

  ages_smooth <- .AgeConversionStratData(
    stratData1, ind_smooth, params_smooth,
    sedSmoothInfo = sedInfo, sedBeta = sedBeta
  )
  ages_const <- .AgeConversionStratData(stratData1, ind_const, params_const)

  for (s in 2:3) {
    expect_equal(ages_smooth[["signal"]][[s]], ages_const[["signal"]][[s]],
                 tolerance = 1e-10,
                 label = paste("signal ages site", s))
  }
})

test_that(".InitializeSedLambda seeds every formation", {
  # The conjugate Gamma draw for sedLambda used to be tested here against the R
  # `.GibbsSedLambda`. That function went with the R arm (sedSmooth is Tier-3
  # C++-only) and its replacement, `sed_gibbs_lambda` in src/MCMCEngine.cpp, has
  # no R entry point, so the draw itself is no longer unit-testable from R --
  # only the initial values this hands to the engine are.
  sedInfo <- .SetupSedSmooth(stratData1, "height", "site, partition", 6L)

  lambda0 <- .InitializeSedLambda(sedInfo)
  expect_length(lambda0, sedInfo$nFormations)
  expect_true(all(is.finite(lambda0)))
  expect_true(all(lambda0 > 0))
})

test_that("StratModel with sedSmooth=TRUE creates valid model", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)

  expect_true(model[["sedSmooth"]])
  expect_false(is.null(model[["sedSmoothInfo"]]))
  expect_equal(model[["sedSmoothInfo"]][["nFormations"]], 2)

  # No gamma in indices
  expect_equal(length(model[["ind"]][["gamma"]]), 0)
  expect_equal(length(model[["indRates"]]), 0)

  # Only alpha parameters in metro priors
  expect_gt(length(model[["parametersNames"]]), 0)
  expect_true(all(grepl("^alpha_", model[["parametersNames"]])))

  # Output should include sedBeta and sedLambda names
  outParams <- model[["outputParams"]]
  expect_true(any(grepl("^sedBeta_", outParams)))
  expect_true(any(grepl("^sedLambda_", outParams)))
})

test_that("sedSmooth MCMC runs and produces output", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)

  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  expect_s3_class(result, "StratPosterior")

  # Check that sedBeta columns are in the output
  samples <- result[["samples"]]
  colnames_out <- dimnames(samples)[[2]]
  expect_true(any(grepl("^sedBeta_", colnames_out)),
              "sedBeta columns should be in output")
  expect_true(any(grepl("^sedLambda_", colnames_out)),
              "sedLambda columns should be in output")
})

test_that("sedSmooth validates inputs", {
  # sedSmooth works with any sedModel (no restriction)
  expect_no_error(
    StratModel(stratData1, priors = NULL, alignmentScale = "height",
               sedModel = "site", sedSmooth = TRUE, nKnots = 10)
  )

  expect_error(
    StratModel(stratData1, priors = NULL, alignmentScale = "height",
               sedModel = "site, partition", sedSmooth = "invalid"),
    "sedSmooth must be"
  )
})

test_that("CreateIndices with sedSmooth=TRUE has no gamma for all sedModel types", {
  for (sm in c("site", "partition", "site x partition", "site, partition")) {
    ind <- .CreateIndices(stratData1, "height", sm, "middle", sedSmooth = TRUE)
    expect_equal(length(ind[["gamma"]]), 0, info = sm)
    expect_equal(length(ind[["rates"]]), 0, info = sm)
    expect_null(ind[["gammaInd"]], info = sm)
    expect_true(ind[["sedSmooth"]], info = sm)
    expect_equal(ind[["sedModel"]], sm, info = sm)
  }

  # Original specific checks on "site, partition"
  ind <- .CreateIndices(stratData1, "height", "site, partition",
                        "middle", sedSmooth = TRUE)
  expect_equal(length(ind[["gamma"]]), 0)
  expect_equal(length(ind[["rates"]]), 0)
  expect_null(ind[["gammaInd"]])
  expect_true(ind[["sedSmooth"]])
  # Only alpha names
  expect_gt(length(ind[["names"]]), 0)
  expect_true(all(grepl("^alpha_", ind[["names"]])))
})

test_that("sedSmooth=FALSE produces identical results to default", {
  # Explicit sedSmooth=FALSE should be same as not passing it
  ind1 <- .CreateIndices(stratData1, "height", "site, partition",
                         "middle", sedSmooth = FALSE)
  ind2 <- .CreateIndices(stratData1, "height", "site, partition", "middle")

  expect_equal(ind1[["alpha"]], ind2[["alpha"]])
  expect_equal(ind1[["gamma"]], ind2[["gamma"]])
  expect_equal(ind1[["names"]], ind2[["names"]])
})

# -- Age-scale alignment tests ------------------------------------------------

test_that("sedSmooth works with age-scale alignment (setup)", {
  # Age-scale: all sites get splines (startSite = 1)
  sedInfo <- .SetupSedSmooth(stratData1, "age", "site, partition", 6L)

  # stratData1 has 3 sites, 1 partition each → 3 formations on age scale
  expect_equal(sedInfo$nFormations, 3)
  expect_equal(sedInfo$totalBeta, 18)
  # Site 1 is included (unlike height scale)
  expect_false(is.na(sedInfo$betaMap[1, 1]))
})

test_that("CreateIndices age-scale sedSmooth has no gamma", {
  ind <- .CreateIndices(stratData2, "age", "site, partition",
                        "middle", sedSmooth = TRUE)
  expect_equal(length(ind[["gamma"]]), 0)
  expect_equal(length(ind[["rates"]]), 0)
  expect_null(ind[["gammaInd"]])
  expect_true(ind[["sedSmooth"]])
  # All sites get alpha
  expect_gt(length(ind[["names"]]), 0)
  expect_true(all(grepl("^alpha_|^gap_", ind[["names"]])))
})

test_that("sedSmooth age-scale model creation", {
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = -100, max = 100),
    "alpha_site2" = UniformPrior(min = -100, max = 100),
    "alpha_site3" = UniformPrior(min = -100, max = 100),
    "gap_site2_1" = ExponentialPrior(rate = 1)
  ), class = c("StratPrior", "list"))

  model <- StratModel(stratData2, priors = priors, alignmentScale = "age",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  expect_true(model[["sedSmooth"]])
  expect_equal(model[["sedSmoothInfo"]]$nFormations, 5)
  expect_true(any(grepl("^sedBeta_", model[["outputParams"]])))
  expect_true(any(grepl("^sedLambda_", model[["outputParams"]])))

  # No gamma priors remain
  expect_equal(length(grep("^gammaLog_", names(model[["priors"]][["metro"]]))), 0)
})

test_that("sedSmooth age-scale MCMC runs without error", {
  skip_on_cran()
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = -100, max = 100),
    "alpha_site2" = UniformPrior(min = -100, max = 100),
    "alpha_site3" = UniformPrior(min = -100, max = 100),
    "gap_site2_1" = ExponentialPrior(rate = 1)
  ), class = c("StratPrior", "list"))

  model <- StratModel(stratData2, priors = priors, alignmentScale = "age",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)

  result <- RunStratModel(stratData2, model, mcmc, visualise = FALSE)
  expect_s3_class(result, "StratPosterior")

  samples <- result[["samples"]]
  colnames_out <- dimnames(samples)[[2]]
  # sedBeta columns for 5 formations
  sedBetaCols <- grep("^sedBeta_", colnames_out, value = TRUE)
  expect_equal(length(sedBetaCols), 30)  # 5 formations x 6 basis
  # No duplicate column names
  expect_equal(length(unique(colnames_out)), length(colnames_out))
})

test_that("sedSmooth age-scale includes site 1 formations", {
  sedInfo <- .SetupSedSmooth(stratData2, "age", "site, partition", 6L)
  # Site 1 should have formations mapped
  site1Formations <- sedInfo$betaMap[, 1]
  expect_true(any(!is.na(site1Formations)))

  # Height scale: site 1 should NOT have formations
  sedInfoH <- .SetupSedSmooth(stratData2, "height", "site, partition", 6L)
  site1FormationsH <- sedInfoH$betaMap[, 1]
  expect_true(all(is.na(site1FormationsH)))
})

test_that("sedSmooth naming avoids duplicates for multi-partition sites", {
  # stratData2 site 2 has formations b=1,2,4 (b=3 is gap)
  # b=2 and b=4 share partition type "part 2.2" — names must differ
  sedInfo <- .SetupSedSmooth(stratData2, "height", "site, partition", 6L)
  names <- .SedSmoothNames(stratData2, sedInfo, "height")

  expect_equal(length(unique(names$betaNames)), length(names$betaNames))
  expect_equal(length(unique(names$lambdaNames)), length(names$lambdaNames))
  # Both formations of type "part 2.2" should have distinct names
  part22 <- grep("part 2.2", names$lambdaNames, value = TRUE)
  expect_equal(length(part22), 2)
  expect_equal(length(unique(part22)), 2)
})

# ── C++ engine integration tests ─────────────────────────────────────────────

test_that("sedSmooth C++ engine produces valid output (stratData0)", {
  skip_on_cran()
  model <- StratModel(stratData0, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 30)

  result <- RunStratModel(stratData0, model, mcmc, engine = "cpp",
                          visualise = FALSE)
  expect_s3_class(result, "StratPosterior")

  samples <- result[["samples"]]
  colnames_out <- dimnames(samples)[[2]]
  expect_true(any(grepl("^sedBeta_", colnames_out)))
  expect_true(any(grepl("^sedLambda_", colnames_out)))
  # Posterior values should be finite
  expect_true(all(is.finite(samples[, "posterior", , ])))
})

test_that("sedSmooth output columns match .SedSmoothNames", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)

  rC <- RunStratModel(stratData1, model, mcmc, engine = "cpp",
                      visualise = FALSE)

  # This used to compare the two engines' column layouts. sedSmooth is now
  # C++-only (Tier 3), and `engine = "R"` auto-switches to "cpp", so that
  # comparison would be cpp-vs-cpp — tautological. Check the layout against
  # `.SedSmoothNames`, the independent source of the names instead.
  expected <- .SedSmoothNames(stratData1, model[["sedSmoothInfo"]], "height")
  cn <- dimnames(rC[["samples"]])[[2]]

  expect_identical(grep("^sedBeta_", cn, value = TRUE), expected[["betaNames"]])
  expect_identical(grep("^sedLambda_", cn, value = TRUE),
                   expected[["lambdaNames"]])
})

test_that("sedSmooth C++ engine with threading", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 2, nIter = 30, nThreads = 2L)

  result <- RunStratModel(stratData1, model, mcmc, engine = "cpp",
                          visualise = FALSE)
  expect_s3_class(result, "StratPosterior")
  expect_true(all(is.finite(result[["samples"]][, "posterior", , ])))
})

test_that("sedSmooth C++ engine on stratData2 (complex multi-site)", {
  skip_on_cran()
  model <- StratModel(stratData2, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 2, nIter = 50)

  result <- RunStratModel(stratData2, model, mcmc, engine = "cpp",
                          visualise = FALSE)
  expect_s3_class(result, "StratPosterior")

  samples <- result[["samples"]]
  sedBetaCols <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)
  sedLambdaCols <- grep("^sedLambda_", dimnames(samples)[[2]], value = TRUE)
  # stratData2 height-scale has 4 formations × 6 basis = 24 sedBeta, 4 sedLambda
  expect_equal(length(sedBetaCols), 24)
  expect_equal(length(sedLambdaCols), 4)
})

# ── Rate-bound guard ─────────────────────────────────────────────────────────
# A proposal is rejected whenever any sedBeta coefficient leaves
# [ratesMin, ratesMax]; because B-spline bases are a partition of unity this
# keeps the implied log-inverse rate s(h) inside the same bound. Every stored
# sedBeta must therefore lie within ratesRange. Only the C++ engine is checked:
# sedSmooth is Tier-3 C++-only, and the guard lives in `sed_smooth_step`.

test_that("sedSmooth respects ratesRange bound (C++ engine)", {
  skip_on_cran()
  rr <- c(-2, 2)
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10, ratesRange = rr)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 200)
  result <- RunStratModel(stratData1, model, mcmc, engine = "cpp",
                          visualise = FALSE)
  samples <- result[["samples"]]
  sedBetaCols <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)
  betaVals <- samples[, sedBetaCols, , , drop = TRUE]
  expect_true(all(is.finite(betaVals)))
  expect_true(all(betaVals >= rr[1] - 1e-8 & betaVals <= rr[2] + 1e-8),
              "sedBeta within ratesRange")
})


# ─── Post-run tool support ──────────────────────────────────────────────────

test_that(".CalculateNewAgesSedSmooth converts arbitrary heights", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 50)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  samples <- result[["samples"]]
  metroNames <- model[["parametersNames"]]
  sedBetaNames <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)

  params <- as.numeric(samples[25, metroNames, 1, 1])
  sedBeta <- as.numeric(samples[25, sedBetaNames, 1, 1])

  indices <- model[["ind"]]
  sedSmoothInfo <- model[["sedSmoothInfo"]]

  # Heights within site 2 bounds
  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)
  test_heights <- seq(boundLow, boundHigh, length.out = 5)

  ages <- .CalculateNewAgesSedSmooth(
    stratData1, indices, params, site = 2, heights = test_heights,
    sedSmoothInfo = sedSmoothInfo, sedBeta = sedBeta
  )

  expect_length(ages, 5)
  expect_true(all(is.finite(ages)))
  # Ages should be monotonic (height-scale, increasing height → correlated ref height)
  expect_true(all(diff(ages) != 0), info = "ages should not be constant")
})

test_that(".AgeConversionBatch works with sedSmooth", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 50)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  samples <- result[["samples"]]
  metroNames <- model[["parametersNames"]]
  sedBetaNames <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)

  # Use rows 20-30
  metroPar <- samples[20:30, metroNames, 1, 1]
  sedBetaMatrix <- samples[20:30, sedBetaNames, 1, 1]

  indices <- model[["ind"]]
  sedSmoothInfo <- model[["sedSmoothInfo"]]

  heights <- model[["heightsForClustering"]][[2]]

  out <- .AgeConversionBatch(
    metroPar, heights, site = 2, stratData1, indices,
    sedSmoothInfo = sedSmoothInfo,
    sedBetaMatrix = sedBetaMatrix
  )

  expect_equal(nrow(out), length(heights))
  expect_equal(ncol(out), 11)
  expect_true(all(is.finite(out)))
})

test_that("plot.StratPosterior works with sedSmooth models", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 100)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  # plot should no longer error
  expect_no_error(plot(result, burnIn = 0.5, display = FALSE))
})

test_that(".AgeConversionGeneral works with sedSmooth", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 50)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  samples <- result[["samples"]]
  metroNames <- model[["parametersNames"]]
  sedBetaNames <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)

  params <- as.numeric(samples[25, metroNames, 1, 1])
  sedBeta <- as.numeric(samples[25, sedBetaNames, 1, 1])

  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)
  test_heights <- seq(boundLow, boundHigh, length.out = 5)

  ages <- .AgeConversionGeneral(
    parameters = params,
    heights = test_heights,
    site = 2,
    stratPosterior = result,
    sedBeta = sedBeta
  )

  expect_length(ages, 5)
  expect_true(all(is.finite(ages)))
})


# ─── Prior mapping is refused, not fabricated ───────────────────────────────

# Under sedSmooth the sedimentation rate is carried entirely by sedBeta, whose
# only prior is the second-derivative roughness penalty. That penalty is rank
# nBasis - 2 per formation, leaving the constant and linear parts of the log
# rate unpenalised and so improper, and StratModel() has already deleted the
# gammaLog_/zetaLog_ priors that pin the rate level in other models. There is
# therefore no prior draw to map heights with. Before this guard, StratMap()
# built sedSmoothInfo but left sedBetaMatrix NULL and .AgeConversionBatch()
# died in as.matrix(NULL) with "'data' must be of a vector type, was 'NULL'".

test_that("StratMap() refuses prior mapping for sedSmooth models", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)

  expect_error(
    StratMap(model, stratData = stratData1,
             heights = seq(boundLow, boundHigh, length.out = 5), site = 2),
    "does not support prior sampling for sedSmooth"
  )
  # and specifically not the old as.matrix(NULL) failure
  expect_error(
    StratMap(model, stratData = stratData1,
             heights = seq(boundLow, boundHigh, length.out = 5), site = 2),
    "improper"
  )
})

test_that("StratMapPlot() refuses prior mapping for sedSmooth models", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  expect_error(
    StratMapPlot(model, stratData = stratData1, sites = 2, display = FALSE),
    "does not support prior sampling for sedSmooth"
  )
})

test_that("StratMapPlot(prior = TRUE) refuses on a sedSmooth posterior", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 50)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  expect_error(
    StratMapPlot(result, sites = 2, prior = TRUE, display = FALSE),
    "does not support prior sampling for sedSmooth"
  )
  # the posterior mapping the same object supports must keep working
  expect_no_error(
    StratMapPlot(result, sites = 2, prior = FALSE, display = FALSE)
  )
  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)
  mapped <- StratMap(result, heights = seq(boundLow, boundHigh, length.out = 5),
                     site = 2)
  expect_equal(nrow(mapped), 5)
  expect_true(all(is.finite(mapped[["mean"]])))
})

test_that("prior mapping still works without sedSmooth", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = FALSE,
                      nKnots = 10)
  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)

  mapped <- StratMap(model, stratData = stratData1,
                     heights = seq(boundLow, boundHigh, length.out = 5),
                     site = 2, maxSamples = 20)
  expect_equal(nrow(mapped), 5)
  expect_true(all(is.finite(mapped[["mean"]])))
})

test_that(".AgeConversionBatch() names a missing sedBetaMatrix", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  indices <- model[["ind"]]
  heights <- model[["heightsForClustering"]][[2]]
  metroPar <- matrix(0, nrow = 2, ncol = model[["parametersLength"]],
                     dimnames = list(NULL, model[["parametersNames"]]))

  expect_error(
    .AgeConversionBatch(metroPar, heights, site = 2, stratData1, indices,
                        sedSmoothInfo = model[["sedSmoothInfo"]],
                        sedBetaMatrix = NULL),
    "requires both `sedSmoothInfo` and `sedBetaMatrix`"
  )
  expect_error(
    .AgeConversionBatch(metroPar, heights, site = 2, stratData1, indices,
                        sedSmoothInfo = model[["sedSmoothInfo"]],
                        sedBetaMatrix = matrix(
                          0, nrow = 1,
                          ncol = model[[c("sedSmoothInfo", "totalBeta")]])),
    "one row per parameter set"
  )
})

test_that(".AgeConversionBatch() rejects a column-short sedBetaMatrix (#1923)", {
  # nrow-correct but ncol-short: exactly the shape ExtractParameters() would
  # build when a caller subsets sedBeta names for a partial analysis.
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  indices <- model[["ind"]]
  heights <- model[["heightsForClustering"]][[2]]
  metroPar <- matrix(5, nrow = 1, ncol = model[["parametersLength"]],
                     dimnames = list(NULL, model[["parametersNames"]]))
  totalBeta <- model[[c("sedSmoothInfo", "totalBeta")]]

  expect_error(
    .AgeConversionBatch(metroPar, heights, site = 2, stratData1, indices,
                        sedSmoothInfo = model[["sedSmoothInfo"]],
                        sedBetaMatrix = matrix(0, nrow = 1,
                                              ncol = totalBeta - 3)),
    "one column per sedBeta coefficient"
  )
})

test_that(".AgeConversionGeneral() rejects an omitted or column-short sedBeta (#1924)", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  totalBeta <- model[[c("sedSmoothInfo", "totalBeta")]]
  heights <- model[["heightsForClustering"]][[2]]

  expect_error(
    .AgeConversionGeneral(c(5, 5), heights[1], site = 2,
                          stratData = stratData1, stratModel = model,
                          sedBeta = NULL),
    "`sedBeta` must be a numeric vector of length"
  )
  expect_error(
    .AgeConversionGeneral(c(5, 5), heights[1], site = 2,
                          stratData = stratData1, stratModel = model,
                          sedBeta = rep(0, totalBeta - 3)),
    "`sedBeta` must be a numeric vector of length"
  )
})

test_that(".CalculateAlphasSedSmooth guards site 1 and an unrecognised alignmentScale (#1925)", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  indices <- model[["ind"]]
  sedInfo <- model[["sedSmoothInfo"]]
  sedBeta <- rep(0, sedInfo[["totalBeta"]])

  expect_error(
    .CalculateAlphasSedSmooth(stratData1, indices, c(5, 5), s = 1,
                              sedInfo, sedBeta),
    "site 1 has no alpha parameters on the height scale"
  )

  indices[["alignmentScale"]] <- "bogus"
  expect_error(
    .CalculateAlphasSedSmooth(stratData1, indices, c(5, 5), s = 2,
                              sedInfo, sedBeta),
    "Alignment must be on height or age scale"
  )
})

test_that("StratMap() rejects a non-finite sedBeta sample from a sedSmooth posterior (#1948)", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  sedBetaCol <- grep("^sedBeta_", dimnames(result[["samples"]])[[2]])[1]
  # corrupt the last iteration, which survives StratMap()'s default 0.5 burnIn
  lastIter <- dim(result[["samples"]])[1]
  result[["samples"]][lastIter, sedBetaCol, 1, 1] <- Inf

  boundLow <- min(stratData1[[c("partsAttr", "BoundLow")]][, 2], na.rm = TRUE)
  boundHigh <- max(stratData1[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)

  expect_error(
    StratMap(result, heights = seq(boundLow, boundHigh, length.out = 5),
             site = 2),
    "sedBeta parameters.*finite"
  )
})

test_that("plot.StratPosterior() rejects a non-finite sedBeta sample (#1948)", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  sedBetaCol <- grep("^sedBeta_", dimnames(result[["samples"]])[[2]])[1]
  lastIter <- dim(result[["samples"]])[1]
  result[["samples"]][lastIter, sedBetaCol, 1, 1] <- Inf

  expect_error(
    plot(result, burnIn = 0, display = FALSE),
    "sedBeta parameters.*finite"
  )
})

test_that("Cluster() rejects a non-finite sedBeta sample (#1948)", {
  # plot.StratPosterior() clusters before it reaches its own finiteness check
  # (R/plot.StratPosterior.R:374), so that check alone would leave a
  # non-finite draw to reach .AgeConversionBatch() unguarded whenever
  # clustering assigns the corrupted row to an alignment other than the one
  # rendered. Cluster.StratPosterior() must gate it directly.
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 20)
  result <- RunStratModel(stratData1, model, mcmc, visualise = FALSE)

  sedBetaCol <- grep("^sedBeta_", dimnames(result[["samples"]])[[2]])[1]
  lastIter <- dim(result[["samples"]])[1]
  result[["samples"]][lastIter, sedBetaCol, 1, 1] <- Inf

  expect_error(
    Cluster(result, burnIn = 0),
    "sedBeta parameters.*finite"
  )
})
