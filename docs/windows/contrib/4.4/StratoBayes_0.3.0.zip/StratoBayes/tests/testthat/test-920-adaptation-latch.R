# RT-727 (#920): two compounding latches that silently stop HMC/NUTS tuning.
#
# 1. The mass-matrix doubling gate counted `historySize`, which is hard-capped
#    at `historyLength`. Once the buffer saturated, "twice as many states as
#    last time" became unreachable and the mass matrix froze for the rest of
#    the run -- in an instrumented 2000-iteration run (adaptation window
#    50-1000, `adaptProposalWindow = 100`) the last update landed at iteration
#    410 and the remaining 34 checkpoints all no-opped. The schedule now counts
#    unique states ever written, and past saturation asks for one complete
#    turnover of the buffer rather than a doubling it can never deliver.
# 2. `adaptStepSize` is only ever written `FALSE` (at the end of a warmup), and
#    `.UpdateMCMCforContinuedRun()` copies `proposalArgs` wholesale, so a
#    continuation that re-opens an adaptation window re-adapted neither the
#    step size nor the mass matrix: 0 of 66 `.AdaptMassMatrix()` calls updated
#    anything, and the step size stayed bit-identical.

AdaptMassMatrix <- StratoBayes:::.AdaptMassMatrix
UpdateForContinued <- StratoBayes:::.UpdateMCMCforContinuedRun

# A saturated buffer: `historySize == historyLength`, mid-window so the
# final-10% freeze branch cannot be what returns early.
fakeMCMC <- function(currentIter, startAdapting = 50, endAdapting = 1000,
                     historyLength = 100) {
  list(currentIter = currentIter,
       startAdapting = startAdapting,
       endAdapting = endAdapting,
       metro = list(historyLength = historyLength))
}

fakeHistory <- function(n = 100, p = 3, seed = 920) {
  set.seed(seed)
  matrix(rnorm(n * p), n, p)
}

fakeHMCArgs <- function(...) {
  c(list(massMatInv = rep(1, 3), massBlocks = NULL, stepSize = 0.05,
         adaptStepSize = TRUE, .hmcDA = NULL), list(...))
}

test_that("#920: a saturated history buffer does not freeze the mass matrix", {
  hist <- fakeHistory()

  # `historySize` is pinned at its 100-row cap throughout; only the cumulative
  # count of unique states written keeps rising.
  first <- AdaptMassMatrix(fakeHMCArgs(), hist, 100L, fakeMCMC(150L),
                           StratoBayes:::.NUTSRestartDualAvg,
                           uniqueTotal = 100L)
  expect_false(identical(first[["massMatInv"]], rep(1, 3)))

  # 200 further unique states -- the doubling schedule is due. Pre-fix the gate
  # asked for 200 *rows* of a 100-row buffer and could never be satisfied.
  later <- AdaptMassMatrix(first, hist * 3, 100L, fakeMCMC(650L),
                           StratoBayes:::.NUTSRestartDualAvg,
                           uniqueTotal = 300L)
  expect_false(identical(later[["massMatInv"]], first[["massMatInv"]]))
})

test_that("#920: the doubling schedule still throttles updates", {
  hist <- fakeHistory()
  first <- AdaptMassMatrix(fakeHMCArgs(), hist, 100L, fakeMCMC(150L),
                           StratoBayes:::.NUTSRestartDualAvg,
                           uniqueTotal = 100L)
  # Only 50 further states; the next update is not due until 200.
  tooSoon <- AdaptMassMatrix(first, hist * 3, 100L, fakeMCMC(200L),
                             StratoBayes:::.NUTSRestartDualAvg,
                             uniqueTotal = 150L)
  expect_identical(tooSoon[["massMatInv"]], first[["massMatInv"]])
})

test_that("#920: a continuation's inherited unique count does not close the gate", {
  hist <- fakeHistory()
  # A resumed chain carries a large cumulative count, so a pure doubling would
  # need another 5000 states; one buffer turnover is enough.
  opened <- AdaptMassMatrix(fakeHMCArgs(), hist, 100L, fakeMCMC(60L),
                            StratoBayes:::.NUTSRestartDualAvg,
                            uniqueTotal = 5000L)
  expect_false(identical(opened[["massMatInv"]], rep(1, 3)))

  later <- AdaptMassMatrix(opened, hist * 3, 100L, fakeMCMC(400L),
                           StratoBayes:::.NUTSRestartDualAvg,
                           uniqueTotal = 5200L)
  expect_false(identical(later[["massMatInv"]], opened[["massMatInv"]]))
})

test_that("#920: the final-10% mass-matrix freeze is still honoured", {
  hist <- fakeHistory()
  # freezeStart = 1000 - floor(0.1 * 950) = 905
  frozen <- AdaptMassMatrix(fakeHMCArgs(), hist, 100L, fakeMCMC(950L),
                            StratoBayes:::.NUTSRestartDualAvg,
                            uniqueTotal = 100L)
  expect_identical(frozen[["massMatInv"]], rep(1, 3))
})

# The four cases above name `uniqueTotal`, an argument that does not exist
# before the fix, so against `main` they error on the signature rather than
# failing on behaviour. These two call positionally and so run under either
# signature: the first is RED on `main` (the doubling gate wants 10000 and can
# never be satisfied), the second pins that a defaulted count reproduces the
# old latch exactly, so the fix's discrimination comes entirely from the
# caller supplying the cumulative count.

test_that("#920: the turnover cap is reachable with `uniqueTotal` defaulted", {
  hist <- fakeHistory()
  resumed <- fakeHMCArgs(.massMatUpdateCount = 5000L)

  out <- AdaptMassMatrix(resumed, hist, 5150L, fakeMCMC(400L),
                         StratoBayes:::.NUTSRestartDualAvg)
  expect_false(identical(out[["massMatInv"]], rep(1, 3)))
})

test_that("#920: with `uniqueTotal` defaulted a saturated buffer still latches", {
  hist <- fakeHistory()
  saturated <- fakeHMCArgs(.massMatUpdateCount = 100L)

  out <- AdaptMassMatrix(saturated, hist, 100L, fakeMCMC(400L),
                         StratoBayes:::.NUTSRestartDualAvg)
  expect_identical(out[["massMatInv"]], rep(1, 3))
})

# ── continuation re-arming ──────────────────────────────────────────────────

# `.UpdateMCMCforContinuedRun()` reads only a handful of fields; everything
# else it touches is NULL-guarded, and omitting `chainHistory` skips the
# history-transfer block entirely.
finishedRun <- function() {
  list(nChains = 1, temper = list(), propose = list(Prior = identity, NUTS = identity),
       metro = list(
         proposalProbability = matrix(0.5, 1, 2),
         proposalFactor = matrix(1, 1, 2),
         proposalValid = matrix(TRUE, 1, 2),
         proposalArgs = list(chain1 = list(
           Prior = NULL,
           NUTS = list(massMatInv = c(2, 2), stepSize = 0.01,
                       adaptStepSize = FALSE,
                       .massMatUpdateCount = 84L, .hmcDA = NULL)))))
}

newRunSkeleton <- function(adapting) {
  list(nChains = 1, startAdapting = 10, endAdapting = 1500, temper = list(),
       propose = list(Prior = identity, NUTS = identity),
       metro = list(
         adaptProposal = adapting,
         proposalProbability = matrix(0, 1, 2),
         proposalFactor = matrix(1, 1, 2),
         proposalValid = matrix(FALSE, 1, 2),
         proposalArgs = list(chain1 = list(Prior = NULL, NUTS = NULL))))
}

test_that("#920: a continuation that re-opens adaptation re-arms step size", {
  out <- UpdateForContinued(finishedRun(), newRunSkeleton(TRUE), newRun = FALSE)
  ha <- out[[c("metro", "proposalArgs")]][["chain1"]][["NUTS"]]

  expect_true(ha[["adaptStepSize"]])
  # The adapted step size and mass matrix are kept as the new window's
  # starting point; only the schedule counters are cleared.
  expect_equal(ha[["stepSize"]], 0.01)
  expect_equal(ha[["massMatInv"]], c(2, 2))
  expect_null(ha[[".massMatUpdateCount"]])
})

test_that("#920: a frozen (adaptProposal = FALSE) continuation is left alone", {
  out <- UpdateForContinued(finishedRun(), newRunSkeleton(FALSE), newRun = FALSE)
  ha <- out[[c("metro", "proposalArgs")]][["chain1"]][["NUTS"]]

  expect_false(ha[["adaptStepSize"]])
  expect_identical(ha[[".massMatUpdateCount"]], 84L)
})
