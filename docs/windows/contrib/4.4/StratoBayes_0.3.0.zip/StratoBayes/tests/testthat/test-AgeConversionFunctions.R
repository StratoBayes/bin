{ # Initialize
  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  testDataMulti$ties <- rbind(testDataMulti$ties,
                              c("site2", 12, 30, 3, "dnorm"),
                              c("site2", 25, 22, 3, "dnorm"))

  tmulti <-
    StratData(
      testDataMulti$signal,
      parts = testDataMulti$parts,
      ties = testDataMulti$ties,
      signalColumn = c("a", "b"),
      zColumn = "Hight",
      siteColumn = "SIT"
    )

  # test reverse height age calculation
  .ReverseTest <- function(data, indices, parameters, site, height) {

    refAge <- .CalculateNewAges(data, indices, parameters, site, height)

    oriHeight <- .CalculateRefHeightToHeights(data, indices, parameters, site, refAge)

    expect_equal(round(oriHeight, 5), round(height, 5))

  }

}


# Parameters were sampled with alpha anchored at the `parts` extent. Since
# #1233 anchors "bottom"/"top" at the signal extent instead, the affected
# alpha values are re-expressed at the new anchor, which leaves every pinned
# age unchanged.

test_that(".AgeConversionStratData works with a - s - b", {
  alScale <- "age"
  sedMod <- "s"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )

  # ras <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(ras,iterations = 500),3)
  parameters1 <- c(39.813495, 34.3, 39.3, 1.25, 0.914, 0.409, 1.63)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(ras,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 29.6, 25.8, 24.2))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(34.3, 30.8, 22.4, 20.1))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(40.1, 17.2))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(29.0, 22.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]

  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), c(34.0, 30.8, 22.4, 20.1))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with a - s - t", {
  alScale <- "age"
  sedMod <- "s"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"
  tmulti$tiesAttr$arg1[1, 3] <- 24
  tmulti$tiesAttr$arg2[1, 3] <- 1

  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 15, max  = 25),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 0.5),
      "gap_site2_1" = NormalPrior(mean = 2, sd = 1)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )

  # rasb <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasb,iterations = 500),3)
  parameters1 <- c(18, 19.596141, 32.317602, 1.31, 1.03, 0.355, 3.52)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  #   plot(rasb,iterations = 500, colourBy = "partition",overridePar = F)
  #   abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  #   abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  #   abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 30.1, 26.7, 23.2))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(34.3, 31.2, 21.6, 19.6))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.6, 18.0))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(29.6, 21.4))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(25.3))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})



test_that(".AgeConversionStratData works with a - p - b", {
  alScale <- "age"
  sedMod <- "p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )
  #
  # rap <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rap,iterations = 500),3)
  parameters1 <- c(39.598103, 35.7, 38.6, 1.6, 1.65, 1.31, 1.23, 2.32)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rap,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(35.7, 33.5, 30.9, 28.6))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(35.7, 27.4, 25.8))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.8, 23.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.1, 27.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(32.8))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]

  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with a - p - t", {
  alScale <- "age"
  sedMod <- "p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 15, max  = 25),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 0.5),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #
  # rapt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rapt,iterations = 500),3)
  parameters1 <- c(20.9, 23.668775, 31.648655, 1.61, 1.44, 2.49, 0.598, 4.79)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rapt,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(32.9, 30.1, 29.3, 24.5))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(32.9, 24.1, 23.7))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(36.9, 20.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(30.0, 24.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.1))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with a - s x p - b", {
  alScale <- "age"
  sedMod <- "s x p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 1),
      "zetaLog_site2" = Fixed(1.4),
      "zetaLog_site3" = Fixed(0.85),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )
  #
  # rasxp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasxp,iterations = 500),3)
  parameters1 <-
    c(40.03018, 33.9, 39.3, 1.31, 0.468,-0.664,-0.409, 1.4, 0.85, 4.26)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  # plot(rasxp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(33.9, 32.1, 27.5, 23.3))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(33.9, 21.1, 18.4))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(40.3, 18.7))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(31.4, 20.9))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.4))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})



test_that(".AgeConversionStratData works with a - s x p - t", {
  alScale <- "age"
  sedMod <- "s x p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 20, max  = 25),
      "gammaLog_part 1.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 1, sd  = 0.5),
      "zetaLog_site2" = Fixed(1.4),
      "zetaLog_site3" = Fixed(0.85),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #
  # rasxpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasxpt,iterations = 500),3)
  parameters1 <-
    c(22.6, 23.824566, 28.843256, 2.13, 0.546, 0.496, 0.461, 1.4, 0.85, 1.25)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  #
  # plot(rasxpt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(29.7, 28.0, 26.6, 25.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(29.7, 24.7, 23.8))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(32.1, 22.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(27.8, 24.6))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.1))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with a - s, p - b", {
  alScale <- "age"
  sedMod <- "s, p"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_part 1.1_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = "bottom"
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = "bottom"
    )

  #
  # rasp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rasp,iterations = 500),3)
  parameters1 <- c(39.324729, 34.3, 37.9, 1.29, 0.859, 1.2, 1.01, 1.03)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(rasp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(34.3, 29.4, 26.5, 25.5))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(34.3, 24.1, 22.4))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(39.6, 17.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(28.9, 24.0))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(30.6))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})



test_that(".AgeConversionStratData works with a - s, p - t", {
  alScale <- "age"
  sedMod <- "s, p"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = "b")
  priorsm <- structure(
    list(
      "alpha_site1" = UniformPrior(min  = 15, max  = 25),
      "alpha_site2" = UniformPrior(min  = 18, max  = 28),
      "alpha_site3" = UniformPrior(min  = 20, max  = 25),
      "gammaLog_part 1.1_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )

  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )

  #
  # raspt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(raspt,iterations = 500),3)
  parameters1 <- c(17.8, 22.996534, 34.402797, 1.14, 0.536,
               1.44, 0.283, 2.85)

  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)

  # plot(raspt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  # abline(h = agesAgeSite$alphas[[1]], col = hcl.colors(4, "Dark 3")[1])

  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(37.3, 30.5, 28.3, 25.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(37.3, 24.3, 23.0))
  expect_equal(signif(agesAgeSite$ties[[1]], 3), c(43.4, 17.8))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(30.2, 24.2))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(26.9))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


###
###
### Height scale
###
###

test_that(".AgeConversionStratData works with h - s - b", {
  alScale <- .MatchAlignmentScale("h")
  sedMod <- "site"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <- .CreateIndices(
    tmulti,
    alignmentScale = alScale,
    sedModel = sedMod,
    alphaPosition = alphaPos
  )
  #rhs <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  #signif(ExtractParams(rhs,iterations = 500),3)
  parameters1 <- c(19.5, 4.87, -0.316, -0.151, 5.38)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <- .AgeConversionStratData(tmulti, ind1, parameters1,
                                         returnAlphas = TRUE)
  # plot(rhs,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(agesAgeSite$alphas[[2]],
               c(19.5, 35.5, 48.5, 53.9), tolerance = 0.01)
  expect_equal(agesAgeSite$signal[[2]][c(1, 33, 58, 64)],
               c(19.5, 31.4, 60.1, 67.9), tolerance = 0.01)
  expect_equal(agesAgeSite$ties[[2]], c(37.6, 60.8), tolerance = 0.01)
  expect_equal(agesAgeSite$ties[[3]], c(28.1), tolerance = 0.01)

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(.AgeConversionGeneral(
    parameters1,
    heights1,
    site = 2, stratData = tmulti, indices = ind1),
    agesAgeSite$signal[[2]][indh],
    tolerance = 0.01
  )

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with h - s - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "site"
  alphaPos <- "top"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  #rhst <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  #signif(ExtractParams(rhst,iterations = 500),3)
  parameters1 <- c(59.647742, 30.49773,-0.138,-1.21, 2.41)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhst,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.3, 34.7, 45.6, 48.0))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(21.3, 31.2, 53.1, 59.6))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(36.4, 53.7))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(64))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with h - p - b", {
  alScale <- "h"
  sedMod <- "p"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhp,iterations = 500),3)
  parameters1 <- c(17.7, 3.29,-0.735, 0.132,-0.669, 3.64)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(17.7, 42.0, 50.4, 54.0))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(17.7, 57.9, 62.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(43.3, 58.4))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(42.3))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)


})


test_that(".AgeConversionStratData works with h - p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhpt,iterations = 500),3)
  parameters1 <- c(55.92665, 28.527187, 0.0413, 0.561,-1.12, 11.7)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhpt,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.8, 33.0, 38.4, 50.1))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(21.8, 52.7, 55.9))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.9, 53.0))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(59.2))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)


})

test_that(".AgeConversionStratData works with h - s x p - b", {
  alScale <- "h"
  sedMod <- "s x p"
  alphaPos <- "bottom"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "zetaLog_site3" = NormalPrior(mean  = 1, sd  = 0.1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsxp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsxp,iterations = 500),3)
  parameters1 <- c(22.6, 2.15, 0.373,-0.63,-1.78, 1.08, 6.24)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsxp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(22.6, 30.6, 48.5, 54.7))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(22.6, 63.1, 73.8))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(2.15, 15.1))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.5, 64.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(42.4))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with h - s x p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 5
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "s x p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1" = NormalPrior(mean  = 0, sd  = 1),
      "zetaLog_site3" = NormalPrior(mean  = 1, sd  = 0.1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsxpt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsxpt,iterations = 500),3)
  parameters1 <- c(59.833192, 27.165152,-0.0275, 0.0786,-2.16, 1.03, 9.21)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsxpt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(20.4, 32.4, 41.2, 50.4))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 58, 64)], 3), c(20.4, 54.6, 59.8))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(-3.79,  16.1))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(33.8, 55.1))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(58.1))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))
  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})


test_that(".AgeConversionStratData works with h - s,p - b", {
  alScale <- "h"
  sedMod <- "s, p"
  alphaPos <- "bottom"
  #StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 5, max  = 25),
      "alpha_site3" = UniformPrior(min  = -5, max  = 5),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhsp <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhsp,iterations = 500),3)
  parameters1 <- c(20.9, 2.65,-0.19,-0.279,-0.752, 5.14)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhsp,iterations = 500, colourBy = "partition",overridePar = F)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(20.9, 35.0, 47.6, 52.7))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(20.9, 31.4, 58.6, 66.2))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(2.65, 16.3))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(37.0, 59.3))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(45.1))
  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[c(2, 33, 58, 64)]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][indh], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)

})



test_that(".AgeConversionStratData works with h - s,p - t", {
  tmulti$tiesAttr$arg1[1, 3] <- 70
  tmulti$tiesAttr$arg2[1, 3] <- 1
  tmulti$tiesAttr$densityFun[1, 3] <- "dnorm"

  alScale <- "h"
  sedMod <- "s, p"
  alphaPos <- "t"
  # StratModelTemplate(tmulti, alignmentScale = alScale, sedModel = sedMod, alphaPosition = alphaPos)
  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min  = 50, max  = 90),
      "alpha_site3" = UniformPrior(min  = 70, max  = 90),
      "gammaLog_part 2.1_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean  = 0, sd  = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean  = 0, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = sedMod,
    alignmentScale = alScale,
    alphaPosition = alphaPos
  )
  ind1 <-
    .CreateIndices(
      tmulti,
      alignmentScale = alScale,
      sedModel = sedMod,
      alphaPosition = alphaPos
    )
  # rhspt <- RunStratModel(tmulti, priors = priorsm, nIter = 500)
  # signif(ExtractParams(rhspt,iterations = 500),3)
  parameters1 <- c(58.191917, 32.007394, 0.0609,-0.0905,-1.31, 4.31)
  #AgeConversion1 <- .CreateDataAgeConversion(tmulti, alignmentScale = alScale, sedModel = sedMod)
  agesAgeSite <-
    .AgeConversionStratData(tmulti, ind1, parameters1, returnAlphas = TRUE)
  # plot(rhspt,iterations = 500, colourBy = "partition",overridePar = F, signal = 2)
  # abline(h = agesAgeSite$alphas[[2]], col = hcl.colors(4, "Dark 3")[c(2,2,3,3)])
  # abline(h = agesAgeSite$alphas[[3]], col = hcl.colors(4, "Dark 3")[4])
  expect_equal(signif(agesAgeSite$alphas[[2]], 3), c(21.4, 32.3, 42.7, 47.1))
  expect_equal(signif(agesAgeSite$signal[[2]][c(1, 33, 58, 64)], 3), c(21.4, 29.5, 52.0, 58.2))
  expect_equal(signif(agesAgeSite$signal[[3]][c(1, 10)], 3), c(-5.05,  18.8))
  expect_equal(signif(agesAgeSite$ties[[2]], 3), c(34.0, 52.5))
  expect_equal(signif(agesAgeSite$ties[[3]], 3), c(69.1))

  indh <- c(2, 33, 58, 64)
  heights1 <- SignalLookUp(tmulti, "height", 2)[indh]
  expect_equal(signif(
    .AgeConversionGeneral(
      parameters1,
      heights1,
      site = 2,
      stratData = tmulti,
      indices = ind1
    ),
    3
  ), signif(agesAgeSite$signal[[2]][c(2, 33, 58, 64)], 3))

  .ReverseTest(tmulti, ind1, parameters1, 2, heights1)


})


test_that(".CalculateAlphas errors (not crashes) for site 1 on the height scale", {
  # Site 1 is the reference site on the height scale: it has no alpha/gamma
  # parameters of its own (structural NAs from index construction), so
  # querying it directly used to crash deep inside `.CalculateAlphas()`
  # with "missing value where TRUE/FALSE needed" instead of erroring
  # cleanly (regression test for the earlier-call-chain sibling of RT-360).
  ind1 <- .CreateIndices(tmulti, alignmentScale = "h", sedModel = "s, p",
                         alphaPosition = "t")
  parameters1 <- c(59.1, 87.6, 0.0609, -0.0905, -1.31, 4.31)

  # `inverseSedRate` (the last argument) is never read once the guard fires,
  # so it is left as NULL rather than actually computed via `.GetSedRates()`.
  expect_error(
    .CalculateAlphas(tmulti, ind1, parameters1, "height", "s, p", 1, NULL),
    "site 1 has no alpha parameters"
  )
})

test_that(".CalculateNewAges errors (not crashes) for site 1 on the height scale", {
  ind1 <- .CreateIndices(tmulti, alignmentScale = "h", sedModel = "s, p",
                         alphaPosition = "t")
  parameters1 <- c(59.1, 87.6, 0.0609, -0.0905, -1.31, 4.31)

  expect_error(
    .CalculateNewAges(tmulti, ind1, parameters1, site = 1, heights = c(1, 40.5, 80)),
    "site 1 has no alpha parameters"
  )
})

test_that(".CalculateRefHeightToHeights errors (not crashes) for site 1 on the height scale", {
  ind1 <- .CreateIndices(tmulti, alignmentScale = "h", sedModel = "s, p",
                         alphaPosition = "t")
  parameters1 <- c(59.1, 87.6, 0.0609, -0.0905, -1.31, 4.31)

  expect_error(
    .CalculateRefHeightToHeights(tmulti, ind1, parameters1,
                                 site = 1, refHeights = c(1, 40.5, 80)),
    "site 1 has no alpha parameters"
  )
})


test_that(".CalculateRefHeightToHeights works with h - p - m", {

# separate test for gaps and .CalculateRefHeightToHeights:
height0AtSite2 <- .CalculateRefHeightToHeights(stratData3,
                             stratModel3$ind,
                             c(-1.8, 1, 0.09, 0.7),
                                         2,
                                         0)
expect_equal(4, round(height0AtSite2, 0))

})

test_that(".CalculateRefHeightToHeights resolves an age exactly at an interior partition boundary (RT-018/RT-177)", {
  alScale <- "h"
  sedMod <- "s, p"
  alphaPos <- "t"
  ind1 <- .CreateIndices(tmulti, alignmentScale = alScale, sedModel = sedMod,
                         alphaPosition = alphaPos)
  parameters1 <- c(59.1, 87.6, 0.0609, -0.0905, -1.31, 4.31)

  # height 10.5 is the shared, non-gap boundary between "part 2.1" and
  # "part 2.2" for site2 -- both partitions' inversion formulas agree at
  # this height, so it must not resolve to NA.
  boundaryHeight <- tmulti[[c("partsAttr", "Bound")]][1, 2]
  expect_equal(tmulti[[c("partsAttr", "BoundLow")]][2, 2], boundaryHeight)

  boundaryAge <- .CalculateNewAges(tmulti, ind1, parameters1, site = 2,
                                   heights = boundaryHeight)
  invertedHeight <- .CalculateRefHeightToHeights(tmulti, ind1, parameters1,
                                                 site = 2,
                                                 refHeights = boundaryAge)

  expect_false(is.na(invertedHeight))
  expect_equal(round(unname(invertedHeight), 5), round(unname(boundaryHeight), 5))
})


test_that(".CalculateRefHeightToHeights tolerates a gap partition's NA sed rate (RT-360)", {

  ind1 <- .CreateIndices(tmulti, alignmentScale = "h", sedModel = "s, p",
                         alphaPosition = "t")
  parameters1 <- c(58.191917, 32.007394, 0.0609, -0.0905, -1.31, 4.31)

  # Site 2 has a gap, so `gammaInd[3, 2]` is a structural NA for any parameter
  # vector; `NA * 0` left `ageHigh[3]` NA and the un-`na.rm`'d domain reduction
  # then made `domainMin`/`domainMax` NA for the whole site. Pre-fix every
  # refHeight outside a single partition failed with
  # "missing value where TRUE/FALSE needed".
  expect_true(is.na(ind1[["gammaInd"]][3, 2]))

  # 1     -> below the site's domain      (extrapolate down)
  # 40.5  -> inside partition 2           (direct inversion; worked pre-fix)
  # 45    -> inside the temporal gap      (returns the gap height, 20 m)
  # 80    -> above the site's domain      (extrapolate up)
  heights <- .CalculateRefHeightToHeights(tmulti, ind1, parameters1, site = 2,
                                          refHeights = c(1, 40.5, 45, 80))

  expect_equal(round(heights, 5), c(-22.81665, 17.94645, 20, 50.09161))

  # The in-gap value is the shared partition boundary, exactly.
  expect_identical(heights[[3]], unname(tmulti[[c("partsAttr", "Bound")]][2, 2]))
  expect_identical(heights[[3]], unname(tmulti[[c("partsAttr", "BoundLow")]][4, 2]))

  # A gap-free site is unaffected by the reduction change.
  expect_equal(
    .CalculateRefHeightToHeights(tmulti, ind1, parameters1, site = 3,
                                 refHeights = c(1, 40.5, 80)),
    c(1.633583, 12.291475, 22.949368),
    tolerance = 1e-6
  )
})


test_that(".CalculateRefHeightToHeights returns NA for a site with no defined partition (RT-360)", {

  ind1 <- .CreateIndices(tmulti, alignmentScale = "h", sedModel = "s, p",
                         alphaPosition = "t")
  parameters1 <- c(59.1, 87.6, 0.0609, -0.0905, -1.31, 4.31)

  # Drive the degenerate case the `na.rm` reduction cannot answer: *every*
  # partition of the queried site has an undefined sedimentation rate. Extending
  # the same structural-NA mechanism to site 3's only partition is enough.
  # Without the guard, `min(..., na.rm = TRUE)` returns Inf and `which.min()`
  # then returns integer(0), giving "subscript out of bounds".
  indNA <- ind1
  indNA[["gammaInd"]][1, 3] <- NA_integer_

  expect_warning(
    heights <- .CalculateRefHeightToHeights(tmulti, indNA, parameters1, site = 3,
                                            refHeights = c(1, 40.5, 80)),
    "no partition of site 3 has well-defined age limits",
    ignore.case = TRUE
  )
  expect_equal(heights, rep(NA_real_, 3))
})


test_that(".CalculateRefHeightToHeights returns NA for an underflowed rate", {

  # a rate that underflows to zero leaves the site spanning no age at all: a
  # reference height on the partition's own alpha inverted to 0/0 = NaN, and
  # one beyond it extrapolated along a slope of zero
  ind <- .CreateIndices(stratData1, "height", "site, partition", "middle")
  parameters <- setNames(rep(0, length(ind[["names"]])), ind[["names"]])
  parameters[grep("^alpha", names(parameters))] <- 5
  parameters[grep("^gammaLog", names(parameters))] <- 800

  expect_warning(
    heights <- .CalculateRefHeightToHeights(stratData1, ind, parameters,
                                            site = 2, refHeights = c(4, 5, 6)),
    "well-defined age limits"
  )
  expect_identical(heights, rep(NA_real_, 3))
})


test_that("Tops() handles a gapped site at its own default refHeights (RT-360)", {

  priorsm <- structure(
    list(
      "alpha_site2" = UniformPrior(min = 50, max = 90),
      "alpha_site3" = UniformPrior(min = 70, max = 90),
      "gammaLog_part 2.1_site2" = NormalPrior(mean = 0, sd = 1),
      "gammaLog_part 2.2_site2" = NormalPrior(mean = 0, sd = 1),
      "gammaLog_part 3.1_site3" = NormalPrior(mean = 0, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 0.5)
    ),
    class = c("list", "StratPrior"),
    sedModel = "s, p",
    alignmentScale = "h",
    alphaPosition = "t"
  )
  mod <- StratModel(tmulti, priors = priorsm, alignmentScale = "h",
                    sedModel = "s, p", alphaPosition = "t")

  # `refHeights = NULL` falls back to the reference site's own range and midpoint,
  # c(1, 40.5, 80), which straddles site 2's modelled domain -- so the default
  # call halted with "missing value where TRUE/FALSE needed" pre-fix, taking the
  # whole posterior x site loop (and TopsPlot()) down with it.
  set.seed(1)
  tops <- Tops(stratObject = mod, stratData = tmulti, maxSamples = 5)

  expect_equal(sort(unique(tops[["refHeight"]])), c(1, 40.5, 80))
  expect_setequal(as.character(unique(tops[["site"]])), c("site2", "site3"))
  expect_true(all(is.finite(tops[["mean"]])))
})

test_that(".CalculateRefHeightToHeights resolves an age-scale gap correctly instead of erroring (RT-467)", {
  # On the height scale `ageHeightSign > 0` and partition index order tracks
  # age order, so hunting for the gap's "below"/"above" partition via
  # which.max()/[1] on the age axis happens to pick the height-adjacent
  # pair. On the age scale `ageHeightSign < 0`; the same hunt picks the
  # WRONG pair (site 2's real partitions instead of the pair either side of
  # the gap) and throws "cannot determine the partition".
  ind1 <- .CreateIndices(tmulti, alignmentScale = "a", sedModel = "s, p",
                         alphaPosition = "t")
  expect_equal(ind1[["ageHeightSign"]], -1)
  parameters1 <- c(62.4747452, 19.6726915, 90.0428286, -2.2110878,
                   0.3543974, 4.0638267, 2.8181225, 1.8995863)

  # site 2's boundaries are 10.5, 20, 20, 31 (a zero-width gap marker at 20);
  # 20.5 falls strictly inside the resulting age gap.
  height <- .CalculateRefHeightToHeights(tmulti, ind1, parameters1, site = 2,
                                        refHeights = 20.5)
  expect_equal(unname(height), 20)
  expect_identical(unname(height),
                   unname(tmulti[[c("partsAttr", "Bound")]][2, 2]))
  expect_identical(unname(height),
                   unname(tmulti[[c("partsAttr", "BoundLow")]][4, 2]))
})
