library('testthat')
library('StratoBayes')

# A hard process death in the suite (Windows CI) leaves no trace of WHICH file
# was running: CheckReporter prints nothing per file, and its stdout is buffered
# away by the crash. stderr is not buffered, so a second reporter writing there
# makes the last line before the truncation name the file. Opt-in, because it
# costs a line per file in every passing run too.
reporter <- if (identical(Sys.getenv("SB_TRACE_TEST_FILES"), "true")) {
  testthat::MultiReporter$new(reporters = list(
    testthat::CheckReporter$new(),
    # update_interval large enough that the spinner never redraws: one line per
    # file start and finish, rather than ~10 frames each.
    testthat::ProgressReporter$new(file = stderr(), update_interval = 1e9)
  ))
} else {
  testthat::check_reporter()
}

suppressPackageStartupMessages(test_check("StratoBayes", reporter = reporter))
