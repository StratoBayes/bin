# Shared small simulator for tests (deterministic when seed set)
make_test_sim <- function(n = 200, p = 2, changepoints = c(80L), seed = 42L) {
  simulate_welllog_trend(
    n = n,
    p = p,
    changepoints = changepoints,
    noise_sd = 0.2,
    seed = seed
  )
}
