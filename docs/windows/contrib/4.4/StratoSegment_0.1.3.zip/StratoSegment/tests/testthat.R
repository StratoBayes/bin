# Run with: testthat::test_check("StratoSegment")
library(testthat)
library(StratoSegment)

# Log each test file to stderr (unbuffered) so CI and R CMD check reveal
# exactly which file blocks if tests ever hang.
log_stage <- function(msg) {
  message(format(Sys.time(), "%H:%M:%OS3"), "  ", msg)
  flush(stderr())
}

log_stage("START tests/testthat.R")

test_dir <- "testthat"
log_stage(paste0("test_dir = ", normalizePath(test_dir, mustWork = FALSE)))

test_files <- list.files(test_dir, pattern = "^test.*\\.R$", full.names = TRUE)
log_stage(paste0("found ", length(test_files), " test files"))

any_fail <- FALSE
for (f in test_files) {
  log_stage(paste0("BEGIN: ", basename(f)))
  res <- testthat::test_file(f, reporter = "summary")
  df <- as.data.frame(res)
  n_fail <- sum(df$failed) + sum(df$error)
  log_stage(paste0("END:   ", basename(f),
                   " (tests=", nrow(df),
                   ", fail=", sum(df$failed),
                   ", error=", sum(df$error), ")"))
  if (n_fail > 0L) any_fail <- TRUE
}

log_stage("ALL TEST FILES COMPLETED")

if (any_fail) {
  stop("Some tests failed. See per-file summaries above.")
}
