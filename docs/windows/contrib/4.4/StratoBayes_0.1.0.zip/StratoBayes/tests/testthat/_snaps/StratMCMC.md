# StratMCMC methods work

    Code
      print(stratMCMC1)
    Output
      MCMC settings for a simulation with 8 chains (1 stored) of 5000 iterations (201 stored)

---

    Code
      summary(stratMCMC1)
    Output
      MCMC settings for a simulation with 8 chains (1 stored) of 5000 iterations (201 stored)
      
      Proposals (chain 1): 
                              Probability Prob.weight Factor
      Prior                           0.5           1      1
      Multivariate                    0.0           4      1
      Univariate                      0.0           1      1
      ShiftAlphas                     0.0           1      1
      ShiftAlphasRandJoint            0.0           1      1
      ShiftAlphasRandSeparate         0.0           1      1

---

    Code
      print(stratMCMC1)
    Output
      MCMC settings for a simulation that has been run with 8 chains (1 stored) of 100 iterations (5 stored)

