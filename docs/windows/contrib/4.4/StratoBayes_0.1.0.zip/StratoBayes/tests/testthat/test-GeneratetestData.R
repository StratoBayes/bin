test_that(".GenerateTestData generates valid data", {
testData <- .GenerateTestData("multi", "gap-3-sites-dates-longer")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("a", "b"))
expect_s3_class(stratD, "StratData")

testData <- .GenerateTestData("single", "1c")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")

testData <- .GenerateTestData("single", "2")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")

testData <- .GenerateTestData("single", "4")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")

})
