test_that(".FirstAndLast() works", {
  fail <- c(NA_real_, NA_real_)
  expect_equal(.FirstAndLast(logical(0)), fail)
  expect_equal(.FirstAndLast(FALSE), fail)
  expect_equal(.FirstAndLast(TRUE), c(1, 1))
  expect_equal(.FirstAndLast(!(1:5 %% 2)), c(2, 4))
  toEvaluate <- !!(1:5 %% 2) # error if used directly within .FirstAndLast in test
  expect_equal(.FirstAndLast(toEvaluate), c(1, 5))
  expect_equal(.FirstAndLast(1:5 == 3), c(3, 3))
})
