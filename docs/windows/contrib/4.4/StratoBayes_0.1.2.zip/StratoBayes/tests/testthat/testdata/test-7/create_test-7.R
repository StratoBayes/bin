# Create test data set 7: two sites
set.seed(1)

p1 <- StratoBayes:::.GenerateSignal(
  sites = c("site 1", "site 2"),
  nSignal = c(50, 20),
  limits = list(c(0, 100), c(50, 80)),
  excludes = list(list(), list()),
  SignalFun = function(x) {
    sin(0.04 * x) +
      sin(0.12 * x) +
      rnorm(length(x), 0, 0.25)
  }
)

if (interactive()) {
  plot(p1$age, p1$signal, col = as.factor(p1$site))
}

# translate to heights
p1$age <- p1$age * (1 + as.numeric(p1$site == "site 2")) -
  (as.numeric(p1$site == "site 2")) * 80

colnames(p1)[2] <- "height"
colnames(p1)[3] <- "value"

if (interactive()) {
  plot(p1$height, p1$value, col = as.factor(p1$site))
}

# save data for reading it in with StratData later
write.csv(p1, test_path("testdata", "test-7", "test-7-signal.csv"))
