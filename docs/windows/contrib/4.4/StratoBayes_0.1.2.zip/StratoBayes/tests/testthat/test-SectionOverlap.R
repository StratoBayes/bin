test_that(".SectionOverlap() works", {
  testSection <- list(c(1, 2, 4, 5, 10.1),
                   c(1, 5),
                   c(5, 6, 7),
                   c(25),
                   30,
                   c(-8, 12),
                   c(2, -2),
                   c(19, -20, 28))
  expectedResult <- list(c(5L, 5L, 4L, 5L, 3L),
                         c(5L, 5L),
                         c(5L, 4L, 4L),
                         2L,
                         1L,
                         c(2L, 2L),
                         c(5L, 3L),
                         c(1L, 1L, 1L))

  expect_error(.SectionOverlap(testSection, countGaps = FALSE),
               "`gapSegments` must be specified")
  overlapOutput <- .SectionOverlap(testSection)
  expect_equal(overlapOutput,expectedResult)
})

test_that(".SectionOverlap works with and without counting gaps", {
  testSection <- list(c(1,2,3), c(1, 4, 5), c(1, 7))

  expectedResult1 <- list(c(3L, 3L, 3L),
                         c(3L, 2L, 2L),
                         c(3L, 1L))

  overlapOutput1 <- .SectionOverlap(testSection)
  expect_equal(overlapOutput1,expectedResult1)


  expectedResult2 <- list(c(3L, 1L, 1L),
                          c(3L, 1L, 1L),
                          c(3L, 1L))

  g1 <- list(matrix(c(1,3)), matrix(c(1,1,2,3), nrow = 2), matrix(c(1,1,2,2), nrow = 2))
  overlapOutput2 <- .SectionOverlap(testSection, FALSE, g1)
  expect_equal(overlapOutput2,expectedResult2)

})

test_that("
.FindOverlappingSections throws errors when given wrong input and is able to work with non-doubles", {
  expect_equal(.FindOverlappingSections(list(1:4,3:5), c(1,3,4,5), 1:7),
               list(c(1,1,2,3),c(2,3,3)))
  expect_error(.FindOverlappingSections(list("char"), 1, list(1,2)))
  expect_error(.FindOverlappingSections(list("char"), 1, 2))
})
