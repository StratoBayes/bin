## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE
)


## ----ties-df------------------------------------------------------------------
tiesData4 <- data.frame(site = c("site1", "site1"),
                        height = c(2.5 * pi, 6.5 * pi),
                        mean = c(12, 10),
                        sd = c(0.1, 0.05))


## ----sed-rate-----------------------------------------------------------------
sedRateSite1 <- diff(tiesData4$height[c(2,1)]) / diff(tiesData4$mean)
print(round(sedRateSite1, 2)) # display result


## ----StratModelTemplate, eval = FALSE-----------------------------------------
# StratModelTemplate(stratData4b, alignmentScale = "age", sedModel = "partition",
#                    alpha = "normal", alphaPosition = c(4.5 * pi, "middle"))


## ----priors-------------------------------------------------------------------
library(StratoBayes)
stratPrior4b <- structure(list(
  "alpha_site1" = NormalPrior(mean = 11, sd = 1),
  "alpha_site2" = NormalPrior(mean = 11, sd = 1),
  "gammaLog_partition site 1" = NormalPrior(mean = log(sedRateSite1), sd = 1),
  "gammaLog_bottom partition" = NormalPrior(mean = log(sedRateSite1), sd = 1),
  "gammaLog_top partition" = NormalPrior(mean = log(sedRateSite1), sd = 1),
  "gap_site2_1" = ExponentialPrior(rate = 1)),
  class = c("StratPrior", "list"))


## ----plot-priors, fig.width = 4.5, fig.height = 6.5---------------------------
plot(stratPrior4b, log = FALSE)


## ----run-model, eval = FALSE--------------------------------------------------
# stratModel4b <- StratModel(stratData = stratData4b,
#                     priors = stratPrior4b,
#                     alignmentScale = "age",
#                     sedModel = "partition",
#                     alphaPosition = c(14.1371669411541, "middle"),
#                     nKnots = 15)
# 
# stratPosterior4b <- RunStratModel(stratObject = stratData4b,
#                         stratModel = stratModel4b,
#                         nRun = 3,
#                         runParallel = TRUE,
#                         nThin = 10,
#                         nIter = 1000) # user higher nIter for more accurate results


## ----plot.StratPosterior------------------------------------------------------
plot(stratPosterior4b, ylab = "age (Ma)")


## ----StratMapPlot, fig.width = 4, fig.height = 7.5----------------------------
StratMapPlot(stratPosterior4b, sites = c(1,2))


## ----StratMap-----------------------------------------------------------------
StratMap(stratPosterior4b, heights = c(0.5 * pi, 4.5 * pi), site = 1)

