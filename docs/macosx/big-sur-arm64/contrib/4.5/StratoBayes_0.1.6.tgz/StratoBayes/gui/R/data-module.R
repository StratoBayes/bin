##############################################################################
# Load data
##############################################################################

# Server-only module that binds all data-loading UI/logic

data_server <- function(input, output, session, r) {

  # local state moved from server.R
  uiTrigger <- reactiveVal(0)
  datasetId <- reactiveVal(0)

  UpdateData <- reactive({
    isolate({
      updateCheckboxGroupInput(session, "loadSiteSelect", choices = NULL, selected = NULL)
      updateCheckboxGroupInput(session, "viewSiteSelect", choices = NULL, selected = NULL)
    })

    req(!is.null(input$dataSource))

    source <- input$dataSource
    if (source == "file") {
      # If no file selected but we have persisted data, use it
      if (is.null(input$dataFile) && !is.null(r$persistedDataset)) {
        r$dataset <- r$persistedDataset
        updateDataPreview()
        showElement("siteColumn"); showElement("zColumn"); showElement("signalColumns")
        Notification(type = "message", paste("Loaded", nrow(r$dataset), "horizons (from previous session)"))
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
        return("Data restored from previous session")
      }

      # Require file input if no persisted data
      req(!is.null(input$dataFile))
      showElement("dataFile")
      runjs("console.log($('#dataFile-label'))")
      runjs(paste0(
        "$('#dataFile-label').parent()",
        ".css({'outline': 'dashed #428bca 20px', 'width': '100%'})",
        ".animate({'outline-width': '0px'}, 'slow');"))

      fileInput <- input$dataFile
      r$dataset <- NULL
      if (is.null(fileInput)) {
        Notification(type = "error", "No data file selected"); return("No data file selected.")
      }
      dataFile <- fileInput$datapath
      if (is.null(dataFile)) {
        Notification(type = "error", "No data file found."); return("No data file specified.")
      }

      LogMsg("UpdateData(): from file")
      r$readDataFile <- NULL

      if (length(grep("\\.xlsx?$", dataFile))) {
        if (!requireNamespace("readxl", quietly = TRUE)) {
          install.packages("readxl")
        }
        showElement("readxl.options", anim = TRUE)

        r$dataset <- tryCatch({
          sheets <- readxl::excel_sheets(dataFile)
          updateSelectInput(session, "readxl.sheet",
                            choices = setNames(sheets, sheets),
                            selected = if (input$readxl.sheet %in% sheets) input$readxl.sheet else sheets[1])

          tibble <- readxl::read_excel(
            path = dataFile,
            sheet = match(input$readxl.sheet, sheets, nomatch = 1L),
            skip = max(0L, input$readxlSkip - 2L),
            .name_repair = "minimal",
            col_types = "text"
          )
          tibble <- safe_colnames(tibble)

          firstCol <- input$readxlSkipCols - 1L
          dat <- as.matrix(tibble[, -seq_len(firstCol)])

          LogComment("Load data from spreadsheet", 2)
          if (r$excelFiles == 0 || tools::md5sum(dataFile) != tools::md5sum(paste0(tempdir(), "/", LastFile("excel")))) {
            CacheInput("excel", dataFile)
          }
          dat
        }, error = function(e) { NULL })
      } else {
        hideElement("readxl.options")
      }

      # CSV/TSV fallback
      if (is.null(r$dataset)) {
        suppressWarnings({
          r$dataset <- tryCatch(
            { safe_colnames(read.csv(dataFile, check.names = FALSE)) },
            error = function(e) {
              tryCatch({ read.table(dataFile) },
                       error = function(e) { r$readDataFile <- NULL; NULL })
            }
          )
        })
      }

    } else {
      LogMsg("UpdateData(): from package")
      dataFile <- system.file("extdata", source, package = "StratoBayes")
      if (dataFile == "") dataFile <- file.path(getwd(), source)
      if (!file.exists(dataFile)) {
        Notification(type = "error", paste("Could not find example data at", dataFile))
        return("Example data not found.")
      }
      LogMsg(dataFile)
      r$dataset <- safe_colnames(read.csv(dataFile, check.names = FALSE))
      LogComment("Load dataset file from StratoBayes package")
    }

    if (is.null(r$dataset)) {
      Notification(type = "error", "Could not read data from file")
      return ("Could not read data from file")
    } else {
      # Clear old column selections if this is a new dataset (not from saved dataset)
      if (!isTRUE(r$loadedSavedDataset)) {
        # Check if this is actually a new dataset (different from persisted)
        isNewDataset <- is.null(r$persistedDataset) ||
                       nrow(r$dataset) != nrow(r$persistedDataset) ||
                       !all(dim(r$dataset) == dim(r$persistedDataset)) ||
                       !identical(colnames(r$dataset), colnames(r$persistedDataset))

        if (isNewDataset) {
          # Clear persisted column selections for new dataset
          r$persistedColumnSelections$siteColumn <- NULL
          r$persistedColumnSelections$zColumn <- NULL
          r$persistedColumnSelections$signalColumns <- NULL
          # Clear alignment if it doesn't match new dataset
          r$alignment <- NULL
        }
      }

      # Update data preview - show signal data if available
      updateDataPreview()
      showElement("siteColumn"); showElement("zColumn"); showElement("signalColumns")
      Notification(type = "message", paste("Loaded", nrow(r$dataset), "horizons"))
      datasetId(datasetId() + 1)
      uiTrigger(uiTrigger() + 1)
    }
  })

  # Helper function to get signal data for preview
  getSignalDataForPreview <- reactive({
    # Only use alignment data if it matches the current dataset
    # Check if alignment exists and if it's from the current dataset
    if (!is.null(r$alignment) && inherits(r$alignment, "StratPosterior") &&
        !is.null(r$alignment$data) && inherits(r$alignment$data, "StratData") &&
        !is.null(r$dataset)) {
      # Check if alignment data matches current dataset (by comparing dimensions or structure)
      # If datasets don't match, use current dataset instead
      align_signal <- r$alignment$data$signal
      if (!is.null(align_signal) && nrow(align_signal) > 0) {
        # Use alignment data only if it seems to match current dataset
        # (This is a heuristic - if column names match, assume it's the same dataset)
        if (nrow(align_signal) == nrow(r$dataset) &&
            length(intersect(colnames(align_signal), colnames(r$dataset))) > 0) {
          return(align_signal)
        }
      }
    }
    # Otherwise use raw dataset
    return(r$dataset)
  })

  # Function to update data preview
  updateDataPreview <- function() {
    signal_data <- getSignalDataForPreview()
    if (!is.null(signal_data) && nrow(signal_data) > 0) {
      output$dataHead <- renderTable({
        head(signal_data, n = 5)
      })
    } else if (!is.null(r$dataset) && nrow(r$dataset) > 0) {
      output$dataHead <- renderTable({
        head(r$dataset, n = 5)
      })
    }
  }

  # mirror observers
  observeEvent(r$dataset, {
    req(r$dataset)
    updateCheckboxGroupInput(session, "loadSiteSelect", choices  = character(0), selected = character(0))
    updateCheckboxGroupInput(session, "viewSiteSelect", choices  = character(0), selected = character(0))
    # Clear alignment if dataset changes (new dataset means old results are invalid)
    # Only clear if alignment exists and doesn't match current dataset
    if (!is.null(r$alignment) && !is.null(r$alignment$data)) {
      align_signal <- tryCatch({
        if (inherits(r$alignment$data, "StratData")) {
          r$alignment$data$signal
        } else {
          NULL
        }
      }, error = function(e) NULL)

      # If alignment data doesn't match current dataset, clear it
      if (is.null(align_signal) ||
          nrow(align_signal) != nrow(r$dataset) ||
          length(intersect(colnames(align_signal), colnames(r$dataset))) == 0) {
        r$alignment <- NULL
      }
    }
    # Update preview when dataset changes
    updateDataPreview()
    # Force UI refresh to update column selectors
    datasetId(datasetId() + 1)
    uiTrigger(uiTrigger() + 1)
  })

  # Also update preview when alignment changes (for StratPosterior objects)
  # But only if data has actually been loaded (r$dataset is set)
  observeEvent(r$alignment, {
    if (!is.null(r$alignment) && inherits(r$alignment, "StratPosterior") &&
        !is.null(r$dataset)) {
      updateDataPreview()
    }
  }, ignoreInit = TRUE)

  output$siteColumn_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$siteColumn) &&
                    r$persistedColumnSelections$siteColumn %in% cols) {
      r$persistedColumnSelections$siteColumn
    } else if ("site" %in% cols) {
      "site"
    } else if (length(cols) > 0) {
      # If no default exists, just use empty (user must select)
      ""
    } else {
      ""
    }
    selectInput(paste0("siteColumn_", datasetId()), "Site column",
                choices, selected, selectize = TRUE)
  })

  output$zColumn_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$zColumn) &&
                    r$persistedColumnSelections$zColumn %in% cols) {
      r$persistedColumnSelections$zColumn
    } else if ("height" %in% cols) {
      "height"
    } else if (length(cols) > 0) {
      # If no default exists, just use empty (user must select)
      ""
    } else {
      ""
    }
    selectInput(paste0("zColumn_", datasetId()), "Height column",
                choices, selected, selectize = TRUE)
  })

  output$signalColumns_ui <- renderUI({
    uiTrigger(); req(r$dataset)
    cols    <- colnames(r$dataset)
    choices <- c(" " = "", setNames(cols, cols))
    # Restore persisted selection if available and valid, otherwise use default ONLY if it exists
    selected <- if (!is.null(r$persistedColumnSelections$signalColumns) &&
                    all(r$persistedColumnSelections$signalColumns %in% cols)) {
      r$persistedColumnSelections$signalColumns
    } else if ("value" %in% cols) {
      "value"
    } else {
      # If no default exists, return empty (user must select)
      character(0)
    }
    selectInput(paste0("signalColumns_", datasetId()), "Signal columns",
                choices, selected, multiple  = TRUE, selectize = TRUE)
  })

  siteColumn <- reactive({
    ds <- r$dataset; id <- paste0("siteColumn_", datasetId()); sc <- input[[id]]
    if (is.null(ds) || is.null(sc) || !(sc %in% colnames(ds))) return(NULL)
    sc
  })
  zColumn <- reactive({
    ds <- r$dataset; id <- paste0("zColumn_", datasetId()); zc <- input[[id]]
    if (is.null(ds) || is.null(zc) || !(zc %in% colnames(ds))) return(NULL)
    zc
  })
  signalColumns <- reactive({
    ds <- r$dataset; id <- paste0("signalColumns_", datasetId()); sigs <- input[[id]]
    if (is.null(ds) || is.null(sigs) || !all(sigs %in% colnames(ds))) return(NULL)
    sigs
  })

  # Function to create basic partitions from site tops
  # This creates partitions at the top of each site (with a miniscule buffer)
  createBasicPartitions <- function(df, site_col, z_col, z_scale) {
    if (is.null(df) || is.null(site_col) || is.null(z_col) || nrow(df) == 0) {
      return(NULL)
    }

    sites <- unique(trimws(as.character(df[[site_col]])))
    if (length(sites) == 0) {
      return(NULL)
    }

    parts_df <- data.frame(
      site = character(0),
      height = numeric(0),
      partition = character(0),
      stringsAsFactors = FALSE
    )

    for (site in sites) {
      site_data <- df[df[[site_col]] == site, ]
      if (nrow(site_data) > 0) {
        heights <- suppressWarnings(as.numeric(site_data[[z_col]]))
        heights <- heights[!is.na(heights)]
        if (length(heights) > 0) {
          # IMPORTANT: The "top" partition marks the upper boundary of the data
          # On height scale: top = max(height) because height increases upward (0=bottom, 30=top)
          # On depth scale: top = min(depth) because depth increases downward (0=top/surface, 30=bottom)
          # StratData expects partitions in RAW coordinates (positive for depth)
          # StratData will transform them itself (multiply by -1 for depth scale)

          if (z_scale == "depth") {
            # On depth scale: top partition is at minimum depth (depth 0 = surface)
            # This transforms to 0, which is the top in StratData's coordinate system
            top_height <- min(heights)
            # Use the minimum value directly (don't subtract buffer, as 0 is already the minimum)
            height_range <- diff(range(heights))
            buffer <- max(height_range * 0.001, 0.1, na.rm = TRUE)
            # For depth, ensure we're at or slightly above the minimum (which is the top)
            top_height_with_buffer <- max(0, top_height - buffer)
          } else {
            # On height scale: top partition is at maximum height
            top_height <- max(heights)
            height_range <- diff(range(heights))
            buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
            top_height_with_buffer <- top_height + buffer
          }

          parts_df <- rbind(parts_df, data.frame(
            site = site,
            height = top_height_with_buffer,
            partition = paste0("Top_", site),
            stringsAsFactors = FALSE
          ))
        }
      }
    }

    if (nrow(parts_df) > 0) {
      # Use actual column names
      colnames(parts_df)[colnames(parts_df) == "site"] <- site_col
      colnames(parts_df)[colnames(parts_df) == "height"] <- z_col
      parts_df$sedRatePartition <- parts_df$partition
    }

    return(parts_df)
  }

  # Reactive function to update basic partitions when data or scale changes
  observeEvent({
    r$dataset
    input$dataScale
    siteColumn()
    zColumn()
  }, {
    # Only update if we have valid data and columns
    if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
        siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
      # Recreate basic partitions from current data
      r$parts_df_basic <- createBasicPartitions(
        df = r$dataset,
        site_col = siteColumn(),
        z_col = zColumn(),
        z_scale = input$dataScale %||% "height"
      )
    } else {
      r$parts_df_basic <- NULL
    }
  }, ignoreInit = TRUE)

  # Reactive function to get partition data
  getPartitionData <- reactive({
    # CRITICAL: Always access input$nStrata to establish reactive dependency
    # Even if we don't use it, accessing it here ensures the reactive tracks changes
    nStrata_dependency <- input$nStrata

    if (is.null(input$partitionSource) || input$partitionSource == "none") {
      return(NULL)
    }

    if (input$partitionSource == "csv") {
      if (is.null(input$partitionFile)) {
        return(NULL)
      }

      tryCatch({
        parts_df <- read.csv(input$partitionFile$datapath, check.names = FALSE)

        # Get actual column names from data
        actual_site_col <- siteColumn()
        actual_z_col <- zColumn()

        if (is.null(actual_site_col) || is.null(actual_z_col)) {
          showNotification("Please select site and height columns first", type = "error")
          return(NULL)
        }

        # Check if CSV has the right column names, or if it uses generic names
        # If CSV uses generic "site" and "height", convert to actual names
        if ("site" %in% colnames(parts_df) && actual_site_col != "site") {
          colnames(parts_df)[colnames(parts_df) == "site"] <- actual_site_col
        }
        if ("height" %in% colnames(parts_df) && actual_z_col != "height") {
          colnames(parts_df)[colnames(parts_df) == "height"] <- actual_z_col
        }
        # Also handle "depth" if that's what the CSV uses
        if ("depth" %in% colnames(parts_df) && actual_z_col != "depth") {
          colnames(parts_df)[colnames(parts_df) == "depth"] <- actual_z_col
        }

        # Verify required columns exist
        if (!actual_site_col %in% colnames(parts_df)) {
          showNotification(paste("Partition CSV must contain column:", actual_site_col), type = "error")
          return(NULL)
        }
        if (!actual_z_col %in% colnames(parts_df)) {
          showNotification(paste("Partition CSV must contain column:", actual_z_col), type = "error")
          return(NULL)
        }

        # Add sedRatePartition column if it doesn't exist
        if (!"sedRatePartition" %in% colnames(parts_df)) {
          if ("partition" %in% colnames(parts_df)) {
            parts_df$sedRatePartition <- parts_df$partition
          } else {
            # If no partition column, create a default one
            parts_df$sedRatePartition <- seq_len(nrow(parts_df))
          }
        }

        return(parts_df)
      }, error = function(e) {
        showNotification(paste("Error reading partition file:", e$message), type = "error")
        return(NULL)
      })
    }

    if (input$partitionSource == "auto") {
      # CRITICAL: If we have saved partitionData from a saved dataset, use it instead of recalculating
      # This preserves the exact partitions that were saved, regardless of current nStrata value
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0 &&
          isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
        # We have saved partition data from a loaded dataset - use it
        return(r$partitionData)
      }

      # Otherwise, recalculate partitions based on current nStrata
      # CRITICAL: Use the nStrata value we accessed at the top to ensure reactive dependency
      # This ensures the reactive recalculates when nStrata changes
      nStrata_val <- nStrata_dependency

      if (is.null(nStrata_val) || is.na(nStrata_val) || nStrata_val < 1) {
        return(NULL)
      }
      if (is.null(input$distributeMethod)) {
        return(NULL)
      }

      tryCatch({
        # Get the raw data and create partitions
        df <- r$dataset
        if (is.null(df) || is.null(siteColumn()) || is.null(zColumn())) {
          return(NULL)
        }

        # Convert to integer to ensure correct type
        nStrata_int <- as.integer(nStrata_val)

        # Create partitions using StratoBayes Partitions function with ACTUAL column names
        # Partitions() handles depth scale transformation internally, so pass raw data
        parts_df_added <- StratoBayes::Partitions(
          signal = df,
          nStrata = nStrata_int,
          distribute = input$distributeMethod,
          siteColumn = siteColumn(),
          zColumn = zColumn(),
          zScale = input$dataScale
        )

        # Add the required sedRatePartition column that StratData expects
        parts_df_added$sedRatePartition <- parts_df_added$partition

        # Combine with basic partitions (site tops)
        parts_df_basic <- r$parts_df_basic
        if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
          # Combine: basic partitions + added partitions
          # Remove duplicates (if basic partition matches an added one)
          parts_df_full <- rbind(parts_df_basic, parts_df_added)
          if (nrow(parts_df_full) > 1) {
            site_col <- siteColumn()
            z_col <- zColumn()
            # Order by site and height
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            # Remove duplicates (same site and very close heights)
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {  # Very close heights are duplicates
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
          return(parts_df_full)
        } else {
          return(parts_df_added)
        }
      }, error = function(e) {
        showNotification(paste("Error creating auto partitions:", e$message), type = "error")
        return(NULL)
      })
    }

    if (input$partitionSource == "interactive") {
      # Combine basic partitions with user-added partitions
      parts_df_basic <- r$parts_df_basic
      parts_df_added <- r$parts_df_added

      # If we have added partitions, combine with basic
      if (!is.null(parts_df_added) && nrow(parts_df_added) > 0) {
        if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
          # Combine: basic partitions + added partitions
          parts_df_full <- rbind(parts_df_basic, parts_df_added)
          # Remove duplicates based on site and height (within small tolerance)
          if (nrow(parts_df_full) > 1) {
            site_col <- siteColumn()
            z_col <- zColumn()
            # Order by site and height
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            # Remove duplicates (same site and very close heights)
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {  # Very close heights are duplicates
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
          return(parts_df_full)
        } else {
          return(parts_df_added)
        }
      } else if (!is.null(parts_df_basic) && nrow(parts_df_basic) > 0) {
        # Only basic partitions
        return(parts_df_basic)
      } else {
        # Fallback to old partitionData for backward compatibility
        if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
          return(r$partitionData)
        }
        return(NULL)
      }
    }

    return(NULL)
  })

  stratData <- reactive({
    req(!is.null(r$dataset),
        !is.null(siteColumn())   && nzchar(siteColumn()),
        !is.null(zColumn())      && nzchar(zColumn()),
        !is.null(signalColumns()) && length(signalColumns()) > 0)

    # CRITICAL: Access partition source and partition data directly to create reactive dependencies
    # This ensures stratData recalculates when partitions are added
    partition_source <- input$partitionSource
    partition_data <- r$partitionData  # Direct access creates dependency

    tryCatch({
      df <- r$dataset
      df[[zColumn()]]    <- suppressWarnings(as.numeric(df[[zColumn()]]))
      df[[siteColumn()]] <- trimws(as.character(df[[siteColumn()]]))

      allSites <- unique(df[[ siteColumn() ]])
      userSel  <- input$loadSiteSelect
      selectSites <- if (is.null(userSel) || length(userSel) == 0 || setequal(userSel, allSites)) NULL else userSel

      if (!is.null(selectSites)) {
        badSig <- vapply(signalColumns(), function(sig) {
          nSites <- length(unique(df[[siteColumn()]][!is.na(df[[sig]]) & df[[siteColumn()]] %in% selectSites ]))
          nSites < 2
        }, logical(1))
        if (any(badSig)) {
          showNotification(paste("Subset leaves <2 sites with data for:", paste(signalColumns()[badSig], collapse = ", ")),
                           type = "error", duration = 8)
          return(NULL)
        }
      }

      # Get partition data (reactive) - this will be recalculated when partition_source or partition_data changes
      # The dependency on partition_data above ensures this reactive recalculates
      parts_df <- getPartitionData()

      StratoBayes::StratData(
        signal       = df,
        siteColumn   = siteColumn(),
        zColumn      = zColumn(),
        signalColumn = signalColumns(),
        selectSites  = selectSites,
        zScale       = input$dataScale,
        parts        = parts_df
      )
    }, error = function(e) {
      showNotification(paste("StratData error:", e$message), type = "error", duration = 8)
      LogMsg("StratData error: ", e$message)
      NULL
    })
  })

  signalValid <- reactive({inherits(stratData(), "StratData")})
  output$signalValid <- signalValid
  outputOptions(output, "signalValid", suspendWhenHidden = FALSE)

  observeEvent(siteColumn(), {
    req(r$dataset); col <- siteColumn(); ds <- r$dataset
    sites <- unique(trimws(as.character(ds[[col]])))

    # Restore persisted site selections if available, otherwise select all
    selectedSites <- if (!is.null(r$persistedSiteSelections) &&
                        all(r$persistedSiteSelections %in% sites)) {
      r$persistedSiteSelections
    } else {
      sites
    }

    updateCheckboxGroupInput(session, "loadSiteSelect", choices  = sites, selected = selectedSites)
    updateCheckboxGroupInput(session, "viewSiteSelect", choices  = sites, selected = selectedSites)
  })

  # Mirror observers for view controls
  observeEvent(r$dataset, {
    req(r$dataset)
    updateCheckboxGroupInput(session, "viewSiteSelect", choices  = character(0), selected = character(0))
  })

  output$previewSignal <- renderPlot({
    req(signalValid()); req(length(input$loadSiteSelect) > 0, length(signalColumns()) > 0)
    sd    <- stratData(); sites <- input$loadSiteSelect; sigs  <- signalColumns()
    oldpar <- par(mfrow = c(length(sigs), length(sites))); on.exit(par(oldpar), add = TRUE)
    plotType <- if (!is.null(input$sigPlotType_load) && !is.na(input$sigPlotType_load)) {
      input$sigPlotType_load
    } else {
      "l"  # default to lines
    }
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      do.call(plot, c(list(x = sd, signal = sig_idx, sites = sites, overridePar = FALSE),
                      list(type = plotType)))
    }
  })

  # View Signal controls and plot (similar to preview but with more controls)
  output$viewPlotControls <- renderUI({
    req(signalValid())
    sites <- stratData()$sites
    sigs  <- signalColumns()

    tagList(
      fluidRow(
        column(3,
               tags$strong("Sites to display"),
               div(style="column-count:2; column-gap:1em;",
                   checkboxGroupInput("viewSiteSelect", NULL, choices = sites,
                                      selected = input$viewSiteSelect %||% sites)
               )
        ),
        column(3,
               tags$strong("Signals to display"),
               div(style="column-count:2; column-gap:1em;",
                   checkboxGroupInput("viewSignalSelect", NULL, choices = sigs,
                                      selected = input$viewSignalSelect %||% sigs)
               )
        ),
        column(2,
               radioButtons("sigPlotType_view", "Style", c("Pts"="p","Lines"="l","Both"="o"),
                            selected = input$sigPlotType_load, inline = TRUE)
        ),
        column(2, sliderInput("viewCex", "● size", min=0.5, max=5, value=1, step=0.1, width="100%")),
        column(2, sliderInput("viewLwd", "— width", min=0.5, max=5, value=2, step=0.5, width="100%"))
      )
    )
  })

  output$viewSignal <- renderPlot({
    req(signalValid())
    req(length(input$viewSiteSelect) > 0)
    req(length(input$viewSignalSelect) > 0)
    req(!is.null(input$viewCex), !is.null(input$viewLwd))

    sd    <- stratData()
    sites <- intersect(input$viewSiteSelect, sd$sites)
    sigs  <- input$viewSignalSelect
    nSig  <- length(sigs)

    oldp <- par(mfrow = c(nSig, length(sites))); on.exit(par(oldp), add=TRUE)

    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      common  <- list(cex=input$viewCex, lwd=input$viewLwd,
                      type=input$sigPlotType_view %||% input$sigPlotType_load)
      do.call(plot, c(list(x = sd, signal = sig_idx, sites = sites, overridePar = FALSE), common))
    }
  })

  # Helper function to get alpha positions from model parameters
  getAlphaPositions <- function(stratData, alignmentScale, alphaPosition, session = NULL) {
    if (is.null(stratData) || is.null(alignmentScale) || is.null(alphaPosition)) {
      return(NULL)
    }

    tryCatch({
      # Handle "custom" by collecting custom numeric values from inputs
      if (length(alphaPosition) == 1 && alphaPosition == "custom") {
        sites <- stratData$sites
        customValues <- numeric(length(sites))

        if (alignmentScale == "height") {
          customValues[1] <- NA  # Reference site doesn't need value
          inputSites <- sites[-1]
          for (i in seq_along(inputSites)) {
            site <- inputSites[i]
            inputId <- paste0("customAlpha_", site)
            val <- if (!is.null(session)) session$input[[inputId]] else input[[inputId]]
            if (!is.null(val) && !is.na(val)) {
              customValues[i + 1] <- val
            } else {
              # Use middle as default if not provided
              heights <- tryCatch({
                StratoBayes::SignalLookUp(stratData, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                # Ensure heights are finite and valid
                heights <- heights[is.finite(heights) & !is.na(heights)]
                if (length(heights) > 0) {
                  height_range <- range(heights, na.rm = TRUE)
                  if (all(is.finite(height_range)) && diff(height_range) > 0) {
                    customValues[i + 1] <- mean(height_range)
                  } else if (length(heights) > 0) {
                    # Fallback to median if range is invalid
                    customValues[i + 1] <- median(heights, na.rm = TRUE)
                  } else {
                    customValues[i + 1] <- 0
                  }
                } else {
                  customValues[i + 1] <- 0
                }
              } else {
                customValues[i + 1] <- 0
              }
            }
          }
        } else {
          # Age scale - all sites need values
          for (i in seq_along(sites)) {
            site <- sites[i]
            inputId <- paste0("customAlpha_", site)
            val <- if (!is.null(session)) session$input[[inputId]] else input[[inputId]]
            if (!is.null(val) && !is.na(val)) {
              customValues[i] <- val
            } else {
              # Use middle as default
              heights <- tryCatch({
                StratoBayes::SignalLookUp(stratData, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                # Ensure heights are finite and valid
                heights <- heights[is.finite(heights) & !is.na(heights)]
                if (length(heights) > 0) {
                  height_range <- range(heights, na.rm = TRUE)
                  if (all(is.finite(height_range)) && diff(height_range) > 0) {
                    customValues[i] <- mean(height_range)
                  } else if (length(heights) > 0) {
                    # Fallback to median if range is invalid
                    customValues[i] <- median(heights, na.rm = TRUE)
                  } else {
                    customValues[i] <- 0
                  }
                } else {
                  customValues[i] <- 0
                }
              } else {
                customValues[i] <- 0
              }
            }
          }
        }
        resolvedAlphaPos <- customValues
      } else {
        # Use the same logic as StratoBayes to resolve alpha positions
        resolvedAlphaPos <- StratoBayes:::.MatchAlphaPosition(alphaPosition, stratData, alignmentScale, toNumeric = TRUE)
      }

      # Create a named list of alpha positions for each site
      sites <- stratData$sites
      alphaPositions <- list()

      for (i in seq_along(sites)) {
        site <- sites[i]
        if (alignmentScale == "height" && i == 1) {
          # Reference site doesn't have alpha position on height scale
          next
        }
        alphaPositions[[site]] <- resolvedAlphaPos[i]
      }

      return(alphaPositions)
    }, error = function(e) {
      return(NULL)
    })
  }

  # Plot for Model structure tab - identical to view tab but with alpha positions
  # Helper function to render data signal plots (used by both structureSignal and priorSignal)
  # includeAlphaPositions: show alpha position lines on sites 2, 3, etc.
  # showAlphaPriorMeans: show alpha prior mean lines on site 1 (for prior tab)
  renderDataSignalPlot <- function(includeAlphaPositions = TRUE, showAlphaPriorMeans = FALSE) {
    req(signalValid())

    sd    <- stratData()

    # Use view settings from the data_view module if available, otherwise use defaults
    # Module inputs are namespaced as "dataview-viewSiteSelect", etc.
    moduleSiteSelect <- input[["dataview-viewSiteSelect"]]
    moduleSignalSelect <- input[["dataview-viewSignalSelect"]]
    moduleCex <- input[["dataview-viewCex"]]
    moduleLwd <- input[["dataview-viewLwd"]]
    modulePlotType <- input[["dataview-sigPlotType_view"]]

    # Also check for global inputs (for backward compatibility)
    globalSiteSelect <- input$viewSiteSelect
    globalSignalSelect <- input$viewSignalSelect
    globalCex <- input$viewCex
    globalLwd <- input$viewLwd
    globalPlotType <- input$sigPlotType_view

    # Use module settings if available, otherwise fall back to global, then defaults
    sites <- if (!is.null(moduleSiteSelect) && length(moduleSiteSelect) > 0) {
      intersect(moduleSiteSelect, sd$sites)
    } else if (!is.null(globalSiteSelect) && length(globalSiteSelect) > 0) {
      intersect(globalSiteSelect, sd$sites)
    } else {
      sd$sites
    }

    sigs <- if (!is.null(moduleSignalSelect) && length(moduleSignalSelect) > 0) {
      moduleSignalSelect
    } else if (!is.null(globalSignalSelect) && length(globalSignalSelect) > 0) {
      globalSignalSelect
    } else {
      signalColumns()
    }

    # Filter to only valid signals
    sigs <- intersect(sigs, sd$signalAttr$signalNames)

    nSig  <- length(sigs)

    # Additional safety check: ensure we have sites and signals to plot
    req(length(sites) > 0)
    req(length(sigs) > 0)
    req(nSig > 0)

    # Calculate y-limits from height data (y-axis) across all selected sites for each signal
    # This ensures consistent y-limits across all site plots for the same signal
    all_ylims <- list()
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      # Collect all height values across all selected sites for this signal
      all_heights <- numeric(0)
      for (site_name in sites) {
        # Get height values for this site and signal
        site_heights <- tryCatch({
          StratoBayes::SignalLookUp(sd, "height", site_name, signal = sig_idx, includeNAsignal = FALSE)
        }, error = function(e) NULL)
        if (!is.null(site_heights) && length(site_heights) > 0) {
          all_heights <- c(all_heights, site_heights)
        }
      }
      # Calculate ylim from collected heights
      if (length(all_heights) > 0) {
        ylim_calc <- range(all_heights, na.rm = TRUE)
        # Only use if we have valid finite values
        if (all(is.finite(ylim_calc)) && length(ylim_calc) == 2) {
          all_ylims[[i]] <- ylim_calc
        } else {
          # Invalid values - don't set ylim, let plot.StratData handle it
          all_ylims[[i]] <- NULL
        }
      } else {
        # No height data found - don't set ylim, let plot.StratData handle it
        all_ylims[[i]] <- NULL
      }
    }

    oldp <- par(mfrow = c(nSig, length(sites))); on.exit(par(oldp), add=TRUE)

    # Create mapping from site names to their index numbers (2, 3, 4, etc., where 1 is reference site)
    # This is based on the order in sd$sites, not the order in the selected sites
    all_sites <- sd$sites
    site_number_map <- setNames(seq_along(all_sites), all_sites)  # site name -> index (1, 2, 3, ...)

    # Get alpha positions if we have the necessary inputs and includeAlphaPositions is TRUE
    alphaPositions <- NULL
    if (includeAlphaPositions && !is.null(input$alignmentScale) && !is.null(input$alphaPosition)) {
      alphaPositions <- getAlphaPositions(sd, input$alignmentScale, input$alphaPosition, session)
    }

    # Plot each signal for each site separately to ensure alpha lines appear in correct subplot
    for (i in seq_along(sigs)) {
      sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
      # Use view style settings from module if available, otherwise use defaults
      # (moduleCex, moduleLwd, etc. are defined above in the reactive)
      common  <- list(
        cex = if (!is.null(moduleCex)) moduleCex else if (!is.null(globalCex)) globalCex else 1,
        lwd = if (!is.null(moduleLwd)) moduleLwd else if (!is.null(globalLwd)) globalLwd else 1,
        type = if (!is.null(modulePlotType)) modulePlotType else if (!is.null(globalPlotType)) globalPlotType else if (!is.null(input$sigPlotType_load)) input$sigPlotType_load else "l"
      )
      # Only add ylim if we calculated valid limits, otherwise let plot.StratData handle it
      if (!is.null(all_ylims[[i]])) {
        common$ylim <- all_ylims[[i]]
      }

      for (j in seq_along(sites)) {
        site <- sites[j]

        # Get the site number from the mapping (1, 2, 3, etc.)
        site_num <- site_number_map[[site]]
        site_title <- if (!is.null(site_num) && is.finite(site_num)) {
          paste0(site, " (", site_num, ")")
        } else {
          site
        }

        # Plot individual site with site number in title
        plot_args <- c(list(x = sd, signal = sig_idx, sites = site, overridePar = FALSE, main = site_title), common)
        do.call(plot, plot_args)

        # Add alpha position line for this specific site (only if includeAlphaPositions is TRUE)
        if (includeAlphaPositions && !is.null(alphaPositions) && site %in% names(alphaPositions) && !is.na(alphaPositions[[site]])) {
          # Get the current plot's coordinates for THIS subplot
          usr <- par("usr")  # [xmin, xmax, ymin, ymax]
          xmax <- usr[2]

          # Draw dotted horizontal line at alpha position
          abline(h = alphaPositions[[site]], lty = 3, col = "grey40", lwd = 2)

          # Add Greek alpha label just to the right of the plot border (consistent across all signals)
          # Use a small offset from the right edge of the plot area
          text(x = xmax, y = alphaPositions[[site]],
               labels = expression(alpha), col = "grey40", cex = 1.2,
               pos = 4, xpd = TRUE)  # pos=4 means "to the right"
        }

        # For priorSignal plot: Add alpha prior mean lines on site 1 only
        # These show the mean values of Normal priors for alpha parameters of other sites
        # Only add when showAlphaPriorMeans is TRUE (which means we're in priorSignal)
        if (showAlphaPriorMeans && j == 1 && !is.null(r$alphaPriorMeans)) {
          # Get alpha prior means for sites with Normal priors
          alpha_means <- r$alphaPriorMeans
          if (length(alpha_means) > 0) {
            # Get the current plot's coordinates for THIS subplot (site 1)
            usr <- par("usr")  # [xmin, xmax, ymin, ymax]
            xmax <- usr[2]

            # Add a horizontal dashed line for each alpha prior mean
            for (site_name in names(alpha_means)) {
              mean_val <- alpha_means[[site_name]]
              if (!is.null(mean_val) && is.finite(mean_val)) {
                # Draw dotted horizontal line at alpha prior mean
                abline(h = mean_val, lty = 3, col = "grey40", lwd = 2)

                # Get site number from the mapping (2, 3, 4, etc. for sites after reference)
                # site_name is the actual site name (e.g., "SiteA", "site2", etc.)
                site_num <- site_number_map[[site_name]]
                if (!is.null(site_num) && is.finite(site_num) && site_num >= 2) {
                  # Use the site number directly (2, 3, 4, etc.)
                  label_text <- paste0("mu_", site_num)
                } else {
                  # Fallback: if site not found in mapping, try to extract from name
                  # This should rarely happen, but provides a safety net
                  site_num <- sub("^[^0-9]*", "", site_name)
                  if (nchar(site_num) == 0 || site_num == site_name) {
                    site_num <- sub("^.*site", "", site_name, ignore.case = TRUE)
                    if (nchar(site_num) == 0 || site_num == site_name) {
                      site_num <- site_name
                    }
                  }
                  label_text <- paste0("mu_", site_num)
                }

                # Add label: mu_2, mu_3, etc.
                text(x = xmax, y = mean_val,
                     labels = label_text, col = "grey40", cex = 1.2,
                     pos = 4, xpd = NA)  # pos=4 means "to the right"
              }
            }
          }
        }
      }
    }
  }

  output$structureSignal <- renderPlot({
    renderDataSignalPlot(includeAlphaPositions = TRUE)
  })

  output$priorSignal <- renderPlot({
    renderDataSignalPlot(includeAlphaPositions = TRUE, showAlphaPriorMeans = TRUE)  # Show both alpha position lines on sites 2,3,... and alpha prior means on site 1
  })


  # Helper function to normalize partition data structure
  normalizePartitionData <- function(parts_df) {
    if (is.null(parts_df) || nrow(parts_df) == 0) {
      return(data.frame(
        site = character(0),
        height = numeric(0),
        partition = character(0),
        stringsAsFactors = FALSE
      ))
    }
    # Ensure we only have the core columns (remove sedRatePartition if present)
    # We'll add it back when saving
    core_cols <- c("site", "height", "partition")
    if (all(core_cols %in% colnames(parts_df))) {
      return(parts_df[, core_cols, drop = FALSE])
    }
    # If structure is wrong, return empty
    return(data.frame(
      site = character(0),
      height = numeric(0),
      partition = character(0),
      stringsAsFactors = FALSE
    ))
  }

  # Partition creation state - will use actual column names when saving
  partitionState <- reactiveValues(
    data = data.frame(site = character(0), height = numeric(0), partition = character(0)),
    clickData = list()
  )

  # Helper to convert partition data to use actual column names
  convertPartitionColumns <- function(parts_df) {
    if (is.null(parts_df) || nrow(parts_df) == 0) {
      return(parts_df)
    }

    # Get actual column names from data
    actual_site_col <- siteColumn()
    actual_z_col <- zColumn()

    if (is.null(actual_site_col) || is.null(actual_z_col)) {
      return(parts_df)
    }

    # If partition data uses generic names, convert to actual names
    if ("site" %in% colnames(parts_df) && actual_site_col != "site") {
      colnames(parts_df)[colnames(parts_df) == "site"] <- actual_site_col
    }
    if ("height" %in% colnames(parts_df) && actual_z_col != "height") {
      colnames(parts_df)[colnames(parts_df) == "height"] <- actual_z_col
    }

    return(parts_df)
  }

  # When dataScale changes, recreate auto-generated top partitions to match new scale
  observeEvent(input$dataScale, {
    # Only recreate if we have auto-generated partitions (just "Top_site" partitions)
    if (!is.null(r$partitionData) && nrow(r$partitionData) > 0 &&
        !is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn())) {
      # Check if these are just default "Top_site" partitions
      parts_df <- r$partitionData
      partition_col <- if ("partition" %in% colnames(parts_df)) "partition" else if ("sedRatePartition" %in% colnames(parts_df)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && all(grepl("^Top_", parts_df[[partition_col]], ignore.case = TRUE))) {
        # These are auto-generated top partitions - recreate based on current raw data
        df <- r$dataset
        sites <- unique(trimws(as.character(df[[siteColumn()]])))

        # Recreate top partitions from current raw data
        # IMPORTANT: If dataScale is "depth", we need to transform heights (multiply by -1)
        # because StratData expects partitions in the transformed coordinate system
        dataScale <- input$dataScale %||% "height"
        top_partitions <- data.frame(
          site = character(0),
          height = numeric(0),
          partition = character(0),
          stringsAsFactors = FALSE
        )

        for (site in sites) {
          site_data <- df[df[[siteColumn()]] == site, ]
          if (nrow(site_data) > 0) {
            heights <- suppressWarnings(as.numeric(site_data[[zColumn()]]))
            heights <- heights[!is.na(heights)]
            if (length(heights) > 0) {
              max_height <- max(heights)
              height_range <- diff(range(heights))
              buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
              max_height_with_buffer <- max_height + buffer

              # If dataScale is "depth", transform to negative (StratData expects transformed coordinates)
              if (dataScale == "depth") {
                max_height_with_buffer <- max_height_with_buffer * -1
              }

              # Convert to proper column names
              site_col_name <- siteColumn()
              height_col_name <- zColumn()

              top_partitions <- rbind(top_partitions, data.frame(
                site = site,
                height = max_height_with_buffer,
                partition = paste0("Top_", site),
                stringsAsFactors = FALSE
              ))
            }
          }
        }

        if (nrow(top_partitions) > 0) {
          # Update with actual column names for saving
          colnames(top_partitions)[colnames(top_partitions) == "site"] <- siteColumn()
          colnames(top_partitions)[colnames(top_partitions) == "height"] <- zColumn()
          top_partitions$sedRatePartition <- top_partitions$partition
          r$partitionData <- top_partitions

          # Also update partitionState if partition modal is open
          if (!is.null(partitionState$data) && nrow(partitionState$data) > 0) {
            # Check if partitionState also has just top partitions
            if (all(grepl("^Top_", partitionState$data$partition, ignore.case = TRUE))) {
              # Convert back to generic names for partitionState
              parts_for_state <- top_partitions
              colnames(parts_for_state)[colnames(parts_for_state) == siteColumn()] <- "site"
              colnames(parts_for_state)[colnames(parts_for_state) == zColumn()] <- "height"
              partitionState$data <- normalizePartitionData(parts_for_state)
            }
          }
        }
      }
    }
  }, ignoreInit = TRUE)

  # Handle partition modal opening
  observeEvent(input$createPartitions, {
    # Don't require signalValid() since partitions might be causing the issue
    # Instead, check if we have raw data and required columns
    req(!is.null(r$dataset),
        !is.null(siteColumn()) && nzchar(siteColumn()),
        !is.null(zColumn()) && nzchar(zColumn()))

    # Get sites from raw data instead of stratData
    df <- r$dataset
    sites <- unique(trimws(as.character(df[[siteColumn()]])))
    updateSelectInput(session, "partitionSite", choices = sites)

    # Check if we already have partition data from previous session
    # IMPORTANT: Only use existing partitions if they're user-created (not auto-generated top partitions)
    # Auto-generated top partitions need to be recreated based on current raw data to match current dataScale
    use_existing <- FALSE
    if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # Check if these are just the default "Top_site" partitions
      # If so, recreate them based on current raw data (to match current dataScale)
      parts_df <- r$partitionData
      if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
        height_col <- zColumn()
      } else if ("height" %in% colnames(parts_df)) {
        height_col <- "height"
      } else {
        height_col <- NULL
      }

      if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
        site_col <- siteColumn()
      } else if ("site" %in% colnames(parts_df)) {
        site_col <- "site"
      } else {
        site_col <- NULL
      }

      if (!is.null(height_col) && !is.null(site_col)) {
        # Check if all partitions are just "Top_site" partitions (default auto-generated)
        partition_col <- if ("partition" %in% colnames(parts_df)) "partition" else if ("sedRatePartition" %in% colnames(parts_df)) "sedRatePartition" else NULL
        if (!is.null(partition_col)) {
          all_top_partitions <- all(grepl("^Top_", parts_df[[partition_col]], ignore.case = TRUE))
          if (!all_top_partitions) {
            # User-created partitions - use them
            use_existing <- TRUE
          }
        }
      }
    }

    if (use_existing) {
      # Use existing user-created partition data - normalize it to ensure consistent structure
      # Convert from actual column names back to generic for editing
      parts_df <- r$partitionData
      if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == siteColumn()] <- "site"
      }
      if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == zColumn()] <- "height"
      }
      partitionState$data <- normalizePartitionData(parts_df)
    } else {
      # Initialize with automatic top partitions for each site using CURRENT raw data
      # IMPORTANT: If dataScale is "depth", we need to transform heights (multiply by -1)
      # because StratData expects partitions in the transformed coordinate system
      dataScale <- input$dataScale %||% "height"
      top_partitions <- data.frame(
        site = character(0),
        height = numeric(0),
        partition = character(0),
        stringsAsFactors = FALSE
      )

      for (site in sites) {
        site_data <- df[df[[siteColumn()]] == site, ]
        if (nrow(site_data) > 0) {
          heights <- suppressWarnings(as.numeric(site_data[[zColumn()]]))
          heights <- heights[!is.na(heights)]
          if (length(heights) > 0) {
            # IMPORTANT: For the "top" partition boundary:
            # On height scale: top = max(height) because height increases upward (0=bottom, 30=top)
            # On depth scale: top = min(depth) because depth increases downward (0=top/surface, 30=bottom)
            # StratData expects partitions in RAW coordinates (positive for depth)
            # StratData will transform them itself (multiply by -1 for depth scale)

            if (dataScale == "depth") {
              # On depth scale: top partition is at minimum depth (depth 0 = surface)
              top_height <- min(heights)
              height_range <- diff(range(heights))
              buffer <- max(height_range * 0.001, 0.1, na.rm = TRUE)
              # For depth, ensure we're at or slightly above the minimum (which is the top)
              top_height_with_buffer <- max(0, top_height - buffer)
            } else {
              # On height scale: top partition is at maximum height
              top_height <- max(heights)
              height_range <- diff(range(heights))
              buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
              top_height_with_buffer <- top_height + buffer
            }

            top_partitions <- rbind(top_partitions, data.frame(
              site = site,
              height = top_height_with_buffer,
              partition = paste0("Top_", site),
              stringsAsFactors = FALSE
            ))
          }
        }
      }

      partitionState$data <- top_partitions
      # Also update r$partitionData if it was just default partitions
      if (!is.null(r$partitionData) && nrow(r$partitionData) > 0) {
        # Clear the old partition data since we're recreating
        r$partitionData <- NULL
      }
    }

    showModal(partitionModal())
  })

  # Handle partition plot clicks
  observeEvent(input$partitionClick, {
    req(input$partitionClick, input$partitionSite)

    # Shiny click coordinates are already in data coordinates
    # plot.StratData plots: x = signal, y = height
    # IMPORTANT: The plot shows StratData's transformed coordinates (negative for depth)
    # But StratData will transform partitions again, so we need RAW coordinates
    # Therefore, we must UNTRANSFORM the click coordinates if depth scale is used
    if (!is.null(input$partitionClick$y) && !is.na(input$partitionClick$y)) {
      # Y coordinate is height from plot (in StratData's transformed coordinate system)
      clickHeight_transformed <- input$partitionClick$y
      clickSignal <- input$partitionClick$x

      # Get data scale - if depth, StratData has already transformed (multiplied by -1)
      # So we need to untransform (multiply by -1) to get raw coordinates
      dataScale <- input$dataScale %||% "height"
      if (dataScale == "depth") {
        # Plot shows transformed (negative) coordinates, but we need raw (positive) for StratData
        clickHeight_raw <- clickHeight_transformed * -1
      } else {
        clickHeight_raw <- clickHeight_transformed
      }

      partitionState$clickData <- list(
        x = clickSignal,
        y = clickHeight_raw,  # Store in RAW coordinates (StratData will transform)
        site = input$partitionSite
      )

      showNotification(paste("Click recorded at height:", round(clickHeight_transformed, 2),
                            "- Enter a partition name and click 'Add Partition Top' to save"),
                      type = "message", duration = 3)
    }
  })

  # Handle brush events for click & drag
  observeEvent(input$partitionBrush, {
    req(input$partitionBrush, input$partitionSite)

    # Store brush data - use Y coordinate for height (plot.StratData: x=signal, y=height)
    # IMPORTANT: Plot shows StratData's transformed coordinates, but we need RAW coordinates
    if (!is.null(input$partitionBrush$ymin) && !is.na(input$partitionBrush$ymin)) {
      # Use the middle of the brush Y coordinate for height (in transformed coordinates)
      brushHeight_transformed <- (input$partitionBrush$ymin + input$partitionBrush$ymax) / 2
      brushSignal <- (input$partitionBrush$xmin + input$partitionBrush$xmax) / 2

      # Untransform if depth scale (plot shows transformed, but we need raw for StratData)
      dataScale <- input$dataScale %||% "height"
      if (dataScale == "depth") {
        brushHeight_raw <- brushHeight_transformed * -1
      } else {
        brushHeight_raw <- brushHeight_transformed
      }

      partitionState$clickData <- list(
        x = brushSignal,
        y = brushHeight_raw,  # Store in RAW coordinates (StratData will transform)
        site = input$partitionSite
      )

      showNotification(paste("Drag recorded at height:", round(brushHeight_transformed, 2),
                            "- Enter a partition name and click 'Add Partition Top' to save"),
                      type = "message", duration = 3)
    }
  })

  # Handle adding a partition
  observeEvent(input$addPartition, {
    req(input$partitionSite)

      # Check for manual height input first
      if (nzchar(input$manualHeight)) {
      if (!nzchar(input$partitionName)) {
        showNotification("Please enter a partition name", type = "warning")
        return()
      }

        # Parse manual heights
        manual_heights <- tryCatch({
          as.numeric(strsplit(input$manualHeight, ",")[[1]])
        }, error = function(e) {
          showNotification("Invalid height format. Use comma-separated numbers.", type = "error")
          return(NULL)
        })

        if (!is.null(manual_heights) && length(manual_heights) > 0) {
        # Ensure partitionState$data has the correct structure
        partitionState$data <- normalizePartitionData(partitionState$data)

        # IMPORTANT: Manual heights are entered in the coordinate system the user sees
        # If depth scale, user sees negative values on plot, but should enter positive depths
        # StratData expects partitions in original coordinates (positive for depth)
        # So manual heights should be interpreted as raw coordinates (positive for depth)
        # No transformation needed - user enters what they see as "depth" (positive)

          # Add partitions for each manual height
          for (height in manual_heights) {
            if (!is.na(height)) {
              newRow <- data.frame(
                site = input$partitionSite,
                height = height,  # Store in raw coordinates (StratData will transform if needed)
              partition = if (length(manual_heights) > 1) {
                paste0(input$partitionName, "_", height)
              } else {
                input$partitionName
              },
                stringsAsFactors = FALSE
              )
            # Ensure columns match before rbinding
            partitionState$data <- normalizePartitionData(partitionState$data)
              partitionState$data <- rbind(partitionState$data, newRow)
            }
          }

          # Clear manual height input
          updateTextInput(session, "manualHeight", value = "")
        updateTextInput(session, "partitionName", value = "")
          showNotification(paste("Partition tops added at heights:", paste(manual_heights, collapse = ", ")),
                         type = "message")
        }
      } else if (!is.null(partitionState$clickData) &&
                 !is.null(partitionState$clickData$y) &&
                 !is.null(partitionState$clickData$site) &&
                 partitionState$clickData$site == input$partitionSite) {
        # Use click data if available and matches current site
        if (!nzchar(input$partitionName)) {
          showNotification("Please enter a partition name", type = "warning")
          return()
        }

        # Y coordinate is height (plot.StratData: x=signal, y=height)
        # clickData$y should already be in raw coordinates (positive for depth) after untransformation
        # But add a safety check to ensure it's in the correct coordinate system
        clickHeight <- partitionState$clickData$y
        dataScale <- input$dataScale %||% "height"

        # If depth scale and clickHeight is negative, it might not have been untransformed
        # This shouldn't happen, but add a safeguard
        if (dataScale == "depth" && clickHeight < 0) {
          # If we get a negative click on depth scale, it wasn't untransformed - fix it
          clickHeight <- clickHeight * -1
        }

        # Ensure partitionState$data has the correct structure before rbinding
        partitionState$data <- normalizePartitionData(partitionState$data)

        newRow <- data.frame(
          site = input$partitionSite,
          height = clickHeight,  # Store in raw coordinates (StratData will transform if needed)
          partition = input$partitionName,
          stringsAsFactors = FALSE
        )

        partitionState$data <- rbind(partitionState$data, newRow)
        # Clear click data after adding
        partitionState$clickData <- list()

        showNotification(paste("Partition top", input$partitionName, "added at height",
                             round(clickHeight, 2)),
                       type = "message")

        # Clear the partition name input
        updateTextInput(session, "partitionName", value = "")
      } else {
      # No manual height and no click data - need to click first
      showNotification("Please click on the plot first, then enter a partition name and click 'Add Partition Top'", type = "warning")
    }
  })

  # Handle clearing all partitions (but preserve top boundaries)
  observeEvent(input$clearPartitions, {
    # Clear user-added partitions (parts_df_added), but keep basic partitions (parts_df_basic)
    # This should only clear parts_df_added, and force recalculation of parts_df_basic
    r$parts_df_added <- NULL

    # Force recalculation of parts_df_basic by triggering the observer
    # The observer will automatically update parts_df_basic based on current data and scale
    if (!is.null(r$dataset) && !is.null(siteColumn()) && !is.null(zColumn()) &&
        siteColumn() %in% colnames(r$dataset) && zColumn() %in% colnames(r$dataset)) {
      # Recreate basic partitions from current data
      r$parts_df_basic <- createBasicPartitions(
        df = r$dataset,
        site_col = siteColumn(),
        z_col = zColumn(),
        z_scale = input$dataScale %||% "height"
      )
    }

    # Update partitionState$data to only show basic partitions (for modal display)
    if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
      # Convert to generic names for partitionState
      parts_for_state <- r$parts_df_basic
      if (siteColumn() %in% colnames(parts_for_state)) {
        colnames(parts_for_state)[colnames(parts_for_state) == siteColumn()] <- "site"
      }
      if (zColumn() %in% colnames(parts_for_state)) {
        colnames(parts_for_state)[colnames(parts_for_state) == zColumn()] <- "height"
      }
      partitionState$data <- normalizePartitionData(parts_for_state)
    } else {
      partitionState$data <- data.frame(
        site = character(0),
        height = numeric(0),
        partition = character(0),
        stringsAsFactors = FALSE
      )
    }

    showNotification("User-added partitions cleared (top boundaries preserved)", type = "message")
  })

  # Store original partition data before modifications (for discard functionality)
  originalPartitionData <- reactiveVal(NULL)

  # Handle done button - show save/discard prompt
  observeEvent(input$donePartitions, {
    # Normalize partition data structure
    partitionState$data <- normalizePartitionData(partitionState$data)

    # Store current partition data as original (for discard)
    originalPartitionData(r$partitionData)

    # IMPORTANT: Save column selections and other settings BEFORE showing save modal
    # This ensures they're preserved when the modal closes
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Show save/discard modal
    partitionCount <- nrow(partitionState$data)
    currentDatasetName <- if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
      r$currentLoadedDatasetName
    } else {
      NULL
    }
    showModal(partitionSaveModal(partitionCount, currentDatasetName))
  })

  # Handle save partitions button (for both point & click and auto partitions)
  observeEvent(input$savePartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)

    if (isAutoPartitions) {
      # This is auto partitions
      # Extract only the non-basic partitions (exclude "Top_" partitions) and save to parts_df_added
      auto_parts <- r$tempAutoPartitions
      if (!is.null(auto_parts) && nrow(auto_parts) > 0) {
        # Filter out basic "Top_" partitions - only keep user-created auto partitions
        partition_col <- if ("partition" %in% colnames(auto_parts)) "partition" else if ("sedRatePartition" %in% colnames(auto_parts)) "sedRatePartition" else NULL
        if (!is.null(partition_col)) {
          # Keep only partitions that are NOT "Top_" partitions
          non_basic_mask <- !grepl("^Top_", auto_parts[[partition_col]], ignore.case = TRUE)
          if (any(non_basic_mask)) {
            # Save non-basic partitions to parts_df_added
            r$parts_df_added <- auto_parts[non_basic_mask, , drop = FALSE]
          } else {
            # If all are basic partitions, clear parts_df_added
            r$parts_df_added <- NULL
          }
        } else {
          # If no partition column, save all
          r$parts_df_added <- auto_parts
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # Add sedRatePartition column if needed
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      r$partitionData <- parts_df_full
      r$tempAutoPartitions <- NULL
      partitionSource <- "auto"
    } else {
      # This is point & click partitions
      # Normalize partition data structure before saving
      partitionState$data <- normalizePartitionData(partitionState$data)

      # Convert to use actual column names from data (not hardcoded "site", "height")
      if (nrow(partitionState$data) > 0 && !is.null(siteColumn()) && !is.null(zColumn())) {
        # Rename columns to match actual data column names
        colnames(partitionState$data)[colnames(partitionState$data) == "site"] <- siteColumn()
        colnames(partitionState$data)[colnames(partitionState$data) == "height"] <- zColumn()
      }

      # Filter out basic "Top_" partitions - only keep user-added partitions
      partition_col <- if ("partition" %in% colnames(partitionState$data)) "partition" else if ("sedRatePartition" %in% colnames(partitionState$data)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && nrow(partitionState$data) > 0) {
        # Keep only partitions that are NOT "Top_" partitions
        non_basic_mask <- !grepl("^Top_", partitionState$data[[partition_col]], ignore.case = TRUE)
        if (any(non_basic_mask)) {
          # Save non-basic partitions to parts_df_added
          user_added_parts <- partitionState$data[non_basic_mask, , drop = FALSE]
          # Add sedRatePartition column
          if (!"sedRatePartition" %in% colnames(user_added_parts)) {
            user_added_parts$sedRatePartition <- user_added_parts[[partition_col]]
          }
          r$parts_df_added <- user_added_parts
        } else {
          # If all are basic partitions, clear parts_df_added
          r$parts_df_added <- NULL
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # Add the required sedRatePartition column that StratData expects
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      # Save combined partition data to reactive values
      r$partitionData <- parts_df_full
      partitionSource <- "interactive"
    }

    # IMPORTANT: Save all current settings to preserve them
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Save partition source to persisted settings
    r$persistedPartitionSource <- partitionSource

    # Get save name (or generate one)
    saveName <- trimws(input$savePartitionDataName)
    if (is.null(saveName) || nchar(saveName) == 0) {
      saveName <- paste0("data-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"))
    }

    # Save the data with partitions
    dataState <- list(
      dataset = r$dataset,
      siteColumn = siteColumn(),
      zColumn = zColumn(),
      signalColumns = signalColumns(),
      siteSelections = input$loadSiteSelect,
      dataSource = input$dataSource,
      dataScale = input$dataScale,
      partitionSource = partitionSource,
      partitionData = r$partitionData,
      parts_df_added = r$parts_df_added  # Save user-added partitions separately
    )

    r$savedDatasets[[saveName]] <- dataState
    r$currentLoadedDatasetName <- saveName
    r$loadedSavedDataset <- TRUE
    r$lastSavedDataHash <- digest::digest(dataState)

    # CRITICAL: Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state and prevents issues with partition source
    shinyjs::delay(200, {
      # Restore all settings from the saved dataset
      if (!is.null(dataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- dataState$siteColumn
      }
      if (!is.null(dataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- dataState$zColumn
      }
      if (!is.null(dataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- dataState$signalColumns
      }
      if (!is.null(dataState$dataset)) {
        r$dataset <- dataState$dataset
        r$persistedDataset <- dataState$dataset
      }
      if (!is.null(dataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
        r$persistedDataScale <- dataState$dataScale
      }
      if (!is.null(dataState$partitionSource)) {
        updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
        r$persistedPartitionSource <- dataState$partitionSource
      }
      # CRITICAL: Restore partition data AFTER setting loadedSavedDataset flag
      # This ensures getPartitionData() knows to use saved data instead of recalculating
      if (!is.null(dataState$partitionData)) {
        r$partitionData <- dataState$partitionData
      }
      if (!is.null(dataState$parts_df_added)) {
        r$parts_df_added <- dataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }
      # Also restore parts_df_basic if needed (it should be recalculated, but ensure it's set)
      # The observer will handle this automatically when data/scale changes
      if (!is.null(dataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
        r$persistedSiteSelections <- dataState$siteSelections
      }
    })

    # Close ONLY the save modal (partitionSaveModal)
    # For auto partitions, the main modal should stay open
    # For point & click, close both modals and reopen main modal
    if (isAutoPartitions) {
      # Auto partitions: close save modal, then explicitly ensure main modal is visible
      # Use same pattern as point & click - close modal then show main modal
      removeModal()  # Close partitionSaveModal (topmost modal)
      # Explicitly show main modal to ensure it's visible (similar to point & click)
      # This ensures the main modal is definitely open and visible
      shinyjs::delay(50, {
        showModal(modelSelectionModal())
      })
    } else {
      # Point & click: close both modals and reopen main modal
      removeModal()  # Close partitionSaveModal
      removeModal()  # Close partitionModal
      showModal(modelSelectionModal())  # Reopen main modal
    }

    # Restore settings after modal is shown (only if partition modal was open)
    if (!isAutoPartitions) {
      shinyjs::delay(100, {
        # Restore dataset first
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }

        # Restore partition source
        updateSelectInput(session, "partitionSource", selected = partitionSource)
        r$persistedPartitionSource <- partitionSource

        # Restore dataScale
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Restore column selections - CRITICAL for non-standard column names
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }

        # Restore site selections
        if (!is.null(r$persistedSiteSelections)) {
          updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
        }

        # Restore data source if available
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        }

        # Restore data scale if available
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Clear the restoration flag after UI updates complete
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })
    } else {
      # For auto partitions, just update the partition source and restore column selections
      # Don't close the main modal - stay in load screen
      updateSelectInput(session, "partitionSource", selected = partitionSource)
      r$persistedPartitionSource <- partitionSource

      # IMPORTANT: Restore dataScale for auto partitions
      if (!is.null(r$persistedDataScale)) {
        updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
      }

      # Restore column selections to prevent deselection
      shinyjs::delay(100, {
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }
        # Also restore dataScale again after column selections (in case it got reset)
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })
    }

    partitionCount <- if (isAutoPartitions) {
      nrow(r$partitionData)
    } else {
      nrow(partitionState$data)
    }

    showNotification(paste("Data saved as:", saveName, "with", partitionCount, "partition boundary(ies)."),
                    type = "message", duration = 5)
  })

  # Handle overwrite partitions button
  observeEvent(input$overwritePartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)

    if (isAutoPartitions) {
      # This is auto partitions
      # Extract only the non-basic partitions (exclude "Top_" partitions) and save to parts_df_added
      auto_parts <- r$tempAutoPartitions
      if (!is.null(auto_parts) && nrow(auto_parts) > 0) {
        # Filter out basic "Top_" partitions - only keep user-created auto partitions
        partition_col <- if ("partition" %in% colnames(auto_parts)) "partition" else if ("sedRatePartition" %in% colnames(auto_parts)) "sedRatePartition" else NULL
        if (!is.null(partition_col)) {
          # Keep only partitions that are NOT "Top_" partitions
          non_basic_mask <- !grepl("^Top_", auto_parts[[partition_col]], ignore.case = TRUE)
          if (any(non_basic_mask)) {
            # Replace parts_df_added with new auto partitions
            r$parts_df_added <- auto_parts[non_basic_mask, , drop = FALSE]
          } else {
            # If all are basic partitions, clear parts_df_added
            r$parts_df_added <- NULL
          }
        } else {
          # If no partition column, save all
          r$parts_df_added <- auto_parts
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      r$partitionData <- parts_df_full
      r$tempAutoPartitions <- NULL
      partitionSource <- "auto"
    } else {
      # This is point & click partitions
      # Normalize partition data structure before saving
      partitionState$data <- normalizePartitionData(partitionState$data)

      # Convert to use actual column names from data (not hardcoded "site", "height")
      if (nrow(partitionState$data) > 0 && !is.null(siteColumn()) && !is.null(zColumn())) {
        # Rename columns to match actual data column names
        colnames(partitionState$data)[colnames(partitionState$data) == "site"] <- siteColumn()
        colnames(partitionState$data)[colnames(partitionState$data) == "height"] <- zColumn()
      }

      # Filter out basic "Top_" partitions - only keep user-added partitions
      partition_col <- if ("partition" %in% colnames(partitionState$data)) "partition" else if ("sedRatePartition" %in% colnames(partitionState$data)) "sedRatePartition" else NULL
      if (!is.null(partition_col) && nrow(partitionState$data) > 0) {
        # Keep only partitions that are NOT "Top_" partitions
        non_basic_mask <- !grepl("^Top_", partitionState$data[[partition_col]], ignore.case = TRUE)
        if (any(non_basic_mask)) {
          # Replace parts_df_added with new point & click partitions
          user_added_parts <- partitionState$data[non_basic_mask, , drop = FALSE]
          # Add sedRatePartition column
          if (!"sedRatePartition" %in% colnames(user_added_parts)) {
            user_added_parts$sedRatePartition <- user_added_parts[[partition_col]]
          }
          r$parts_df_added <- user_added_parts
        } else {
          # If all are basic partitions, clear parts_df_added
          r$parts_df_added <- NULL
        }
      } else {
        r$parts_df_added <- NULL
      }

      # Combine basic and added partitions for partitionData
      parts_df_full <- NULL
      if (!is.null(r$parts_df_basic) && nrow(r$parts_df_basic) > 0) {
        parts_df_full <- r$parts_df_basic
      }
      if (!is.null(r$parts_df_added) && nrow(r$parts_df_added) > 0) {
        if (!is.null(parts_df_full)) {
          parts_df_full <- rbind(parts_df_full, r$parts_df_added)
          # Remove duplicates
          site_col <- siteColumn()
          z_col <- zColumn()
          if (!is.null(site_col) && !is.null(z_col) &&
              site_col %in% colnames(parts_df_full) && z_col %in% colnames(parts_df_full)) {
            parts_df_full <- parts_df_full[order(match(parts_df_full[[site_col]], unique(parts_df_full[[site_col]])),
                                                     parts_df_full[[z_col]]), ]
            keep_rows <- rep(TRUE, nrow(parts_df_full))
            for (i in 2:nrow(parts_df_full)) {
              if (parts_df_full[[site_col]][i] == parts_df_full[[site_col]][i-1]) {
                height_diff <- abs(parts_df_full[[z_col]][i] - parts_df_full[[z_col]][i-1])
                if (height_diff < 0.01) {
                  keep_rows[i] <- FALSE
                }
              }
            }
            parts_df_full <- parts_df_full[keep_rows, ]
          }
        } else {
          parts_df_full <- r$parts_df_added
        }
      }

      # Add the required sedRatePartition column that StratData expects
      if (!is.null(parts_df_full) && nrow(parts_df_full) > 0 && !"sedRatePartition" %in% colnames(parts_df_full)) {
        partition_col <- if ("partition" %in% colnames(parts_df_full)) "partition" else NULL
        if (!is.null(partition_col)) {
          parts_df_full$sedRatePartition <- parts_df_full[[partition_col]]
        }
      }

      # Save combined partition data to reactive values
      r$partitionData <- parts_df_full
      partitionSource <- "interactive"
    }

    # IMPORTANT: Save all current settings to preserve them
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Save partition source to persisted settings
    r$persistedPartitionSource <- partitionSource

    # Check if we have a current loaded dataset name to overwrite
    if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
      # Overwrite the existing saved dataset
      dataState <- list(
        dataset = r$dataset,
        siteColumn = siteColumn(),
        zColumn = zColumn(),
        signalColumns = signalColumns(),
        siteSelections = input$loadSiteSelect,
        dataSource = input$dataSource,
        dataScale = input$dataScale,
        partitionSource = partitionSource,
        partitionData = r$partitionData,
        parts_df_added = r$parts_df_added  # Save user-added partitions separately
      )

      r$savedDatasets[[r$currentLoadedDatasetName]] <- dataState
      r$lastSavedDataHash <- digest::digest(dataState)

    # CRITICAL: Immediately load the saved dataset to ensure consistency
    # This ensures the UI reflects the saved state and prevents issues with partition source
    # IMPORTANT: Restore partitionData FIRST, before partitionSource, to prevent getPartitionData() from recalculating
    shinyjs::delay(200, {
      # Restore partition data FIRST (before partitionSource) to prevent recalculation
      if (!is.null(dataState$partitionData)) {
        r$partitionData <- dataState$partitionData
      }
      if (!is.null(dataState$parts_df_added)) {
        r$parts_df_added <- dataState$parts_df_added
      } else {
        r$parts_df_added <- NULL
      }

      # Then restore other settings
      if (!is.null(dataState$siteColumn)) {
        r$persistedColumnSelections$siteColumn <- dataState$siteColumn
      }
      if (!is.null(dataState$zColumn)) {
        r$persistedColumnSelections$zColumn <- dataState$zColumn
      }
      if (!is.null(dataState$signalColumns)) {
        r$persistedColumnSelections$signalColumns <- dataState$signalColumns
      }
      if (!is.null(dataState$dataset)) {
        r$dataset <- dataState$dataset
        r$persistedDataset <- dataState$dataset
      }
      if (!is.null(dataState$dataScale)) {
        updateRadioButtons(session, "dataScale", selected = dataState$dataScale)
        r$persistedDataScale <- dataState$dataScale
      }
      # Restore partitionSource AFTER partitionData to ensure getPartitionData() uses saved data
      if (!is.null(dataState$partitionSource)) {
        updateSelectInput(session, "partitionSource", selected = dataState$partitionSource)
        r$persistedPartitionSource <- dataState$partitionSource
      }
      if (!is.null(dataState$siteSelections)) {
        updateCheckboxGroupInput(session, "loadSiteSelect", selected = dataState$siteSelections)
        r$persistedSiteSelections <- dataState$siteSelections
      }
    })

      partitionCount <- if (isAutoPartitions) {
        nrow(r$partitionData)
      } else {
        nrow(partitionState$data)
      }

      showNotification(paste("Data overwritten:", r$currentLoadedDatasetName, "with", partitionCount, "partition boundary(ies)."),
                      type = "message", duration = 5)

      # Close ONLY the save modal (partitionSaveModal)
      if (isAutoPartitions) {
        # Auto partitions: close save modal, then explicitly show main modal
        removeModal()  # Close partitionSaveModal (topmost modal)
        # Explicitly show main modal to ensure it's visible
        shinyjs::delay(50, {
          showModal(modelSelectionModal())
          # Restore dataScale after modal is shown
          shinyjs::delay(100, {
            if (!is.null(r$persistedDataScale)) {
              updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
            }
          })
        })
      } else {
        removeModal()  # Close partitionSaveModal
        removeModal()  # Close partitionModal
        showModal(modelSelectionModal())  # Reopen main modal
        # Restore dataScale after modal is shown
        shinyjs::delay(100, {
          if (!is.null(r$persistedDataScale)) {
            updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
          }
        })
      }
    } else {
      showNotification("No saved dataset to overwrite. Please use 'Save with New Name' instead.", type = "error")
    }
  })

  # Handle discard partitions button (for both point & click and auto partitions)
  observeEvent(input$discardPartitions, {
    # Determine if this is auto partitions or point & click partitions
    isAutoPartitions <- !is.null(r$tempAutoPartitions)

    if (isAutoPartitions) {
      # This is auto partitions - just clear the temp data
      r$tempAutoPartitions <- NULL
      r$partitionData <- originalAutoPartitionData()

      # Close the save modal, then explicitly show main modal
      removeModal()  # Close partitionSaveModal (topmost modal)
      # Explicitly show main modal to ensure it's visible
      shinyjs::delay(50, {
        showModal(modelSelectionModal())
      })

      # Restore column selections to prevent deselection
      shinyjs::delay(100, {
        r$isRestoringData <- TRUE
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }
        # Restore dataScale
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })

      showNotification("Auto partitions discarded. Data restored to previous state.", type = "message", duration = 3)
    } else {
      # This is point & click partitions
      # Restore original partition data (or clear if there was none)
      r$partitionData <- originalPartitionData()

      # Clear partition state
      partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
      partitionState$clickData <- list()

      # Close the save modal
      removeModal()

      # Close the partition modal
    removeModal()

    # Show the main model selection modal again
    showModal(modelSelectionModal())

      # Restore settings after modal is shown
      shinyjs::delay(100, {
        # Restore dataset
        if (!is.null(r$persistedDataset)) {
          r$dataset <- r$persistedDataset
        }

        # Restore partition source to what it was before
        if (!is.null(r$persistedPartitionSource)) {
          updateSelectInput(session, "partitionSource", selected = r$persistedPartitionSource)
    } else {
          updateSelectInput(session, "partitionSource", selected = "none")
        }

        # Restore column selections - CRITICAL for non-standard column names
        if (!is.null(r$persistedColumnSelections$siteColumn)) {
          siteColId <- paste0("siteColumn_", datasetId())
          updateSelectInput(session, siteColId, selected = r$persistedColumnSelections$siteColumn)
        }
        if (!is.null(r$persistedColumnSelections$zColumn)) {
          zColId <- paste0("zColumn_", datasetId())
          updateSelectInput(session, zColId, selected = r$persistedColumnSelections$zColumn)
        }
        if (!is.null(r$persistedColumnSelections$signalColumns)) {
          sigColId <- paste0("signalColumns_", datasetId())
          updateSelectInput(session, sigColId, selected = r$persistedColumnSelections$signalColumns)
        }

        # Restore site selections
        if (!is.null(r$persistedSiteSelections)) {
          updateCheckboxGroupInput(session, "loadSiteSelect", selected = r$persistedSiteSelections)
        }

        # Restore data source if available
        if (!is.null(r$persistedDataSource)) {
          updateSelectInput(session, "dataSource", selected = r$persistedDataSource)
        }

        # Restore data scale if available
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }

        # Clear the restoration flag after UI updates complete
        shinyjs::delay(200, {
          r$isRestoringData <- FALSE
        })
      })

      showNotification("Partitions discarded. Data restored to previous state.", type = "message", duration = 3)
    }
  })

  # Handle previousStep button when in partition modal - close partition modal and return to main modal
  observeEvent(input$previousStep, {
    # Check if we're likely in the partition modal by checking for partition-specific inputs
    if (!is.null(input$partitionSite)) {
      # Save dataScale before closing modal
      if (!is.null(input$dataScale)) {
        r$persistedDataScale <- input$dataScale
      }
      # Close partition modal and return to main modal
      removeModal()
      showModal(modelSelectionModal())
      # Restore dataScale after modal is shown
      shinyjs::delay(100, {
        if (!is.null(r$persistedDataScale)) {
          updateRadioButtons(session, "dataScale", selected = r$persistedDataScale)
        }
      })
    }
  }, priority = 10)  # Higher priority to handle before the general previousStep handler

  # Render partition plot
  output$partitionPlot <- renderPlot({
    req(input$partitionSite, !is.null(r$dataset),
        !is.null(siteColumn()), !is.null(zColumn()))

    # Make reactive to click data changes
    partitionState$clickData
    partitionState$data

    site <- input$partitionSite

    # Try to use StratData if available (preferred - has correct axis orientation)
    if (signalValid()) {
      # Use the proper StratData plotting that was working before
      sd <- stratData()
      sigs <- signalColumns()

      if (length(sigs) > 0) {
        sig_idx <- match(sigs[1], sd$signalAttr$signalNames)

        # Use do.call with plot.StratData like in the view tab
        plotType <- if (!is.null(input$sigPlotType_view) && !is.na(input$sigPlotType_view)) {
          input$sigPlotType_view
        } else if (!is.null(input$sigPlotType_load) && !is.na(input$sigPlotType_load)) {
          input$sigPlotType_load
        } else {
          "l"
        }
        plotCex <- if (!is.null(input$viewCex) && !is.na(input$viewCex)) input$viewCex else 1
        plotLwd <- if (!is.null(input$viewLwd) && !is.na(input$viewLwd)) input$viewLwd else 2
        do.call(plot, c(list(x = sd, signal = sig_idx, sites = site, overridePar = FALSE),
                        list(type = plotType, cex = plotCex, lwd = plotLwd)))

        # Add existing partition lines for StratData plot (x=signal, y=height)
        site_partitions <- partitionState$data[partitionState$data$site == site, ]
        if (nrow(site_partitions) > 0) {
          # Get data scale to transform partition heights for display
          dataScale <- input$dataScale %||% "height"
          depthMultiplier <- if (dataScale == "depth") -1 else 1

          # Get plot limits to position text properly
          xlims <- par("usr")[1:2]
          ylims <- par("usr")[3:4]
          for (i in seq_len(nrow(site_partitions))) {
            # Transform partition height for display (plot shows StratData's transformed coordinates)
            display_height <- site_partitions$height[i] * depthMultiplier
            # Draw partition line as HORIZONTAL line at transformed height
            abline(h = display_height, col = "red", lty = 2, lwd = 2)
            # Add label on the right side of plot
            text(x = xlims[2] * 0.95, y = display_height,
                 labels = site_partitions$partition[i], col = "red", pos = 4, cex = 0.9)
          }
        }

        # Add click indicator if available (draw on top)
        # clickData is stored in RAW coordinates, but plot shows transformed, so transform for display
        if (!is.null(partitionState$clickData) &&
            !is.null(partitionState$clickData$y) &&
            is.numeric(partitionState$clickData$y) &&
            !is.na(partitionState$clickData$y) &&
            (!is.null(partitionState$clickData$site) && partitionState$clickData$site == site)) {
          # Transform click height for display (plot shows StratData's transformed coordinates)
          dataScale <- input$dataScale %||% "height"
          depthMultiplier <- if (dataScale == "depth") -1 else 1
          display_click_height <- partitionState$clickData$y * depthMultiplier

          xlims <- par("usr")[1:2]
          ylims <- par("usr")[3:4]
          # Draw a more visible indicator as HORIZONTAL line at transformed height
          abline(h = display_click_height, col = "blue", lty = 1, lwd = 3)
          # Add a point marker at the clicked location (x is signal, y is transformed height)
          points(x = partitionState$clickData$x, y = display_click_height,
                 col = "blue", pch = 19, cex = 2)
          # Add label on the right
          text(x = xlims[2] * 0.9, y = display_click_height,
               labels = paste("Click at height:", round(display_click_height, 2)),
               col = "blue", pos = 4, cex = 0.9, font = 2)
        }
      } else {
        plot(1, 1, type = "n", xlab = "Height", ylab = "Signal",
             main = paste("No signal data available for site:", site))
      }
    } else {
      # Fallback: Show informative message if StratData isn't available
      plot(1, 1, type = "n", xlab = "", ylab = "", axes = FALSE,
           xlim = c(0, 2), ylim = c(0, 2))
      text(1, 1.5, "Please ensure data is properly loaded",
           cex = 1.2, col = "black", font = 2)
      text(1, 1, "and all columns are selected",
           cex = 1.2, col = "black", font = 2)
      text(1, 0.5, "before creating partitions.",
           cex = 1.2, col = "black", font = 2)
    }
  })

  # Render partition table
  output$partitionTable <- renderTable({
    if (nrow(partitionState$data) > 0) {
      # Ensure we have the expected columns for ordering
      if ("site" %in% colnames(partitionState$data) && "height" %in% colnames(partitionState$data)) {
        # Order by site and height
        ordered_data <- partitionState$data[order(partitionState$data$site, partitionState$data$height), ]

        # IMPORTANT: Transform heights for display based on current dataScale
        # partitionState$data stores heights in raw coordinates (positive for depth)
        # But for display, we should show them as they appear on the plot
        # For depth scale, StratData transforms to negative, so we should show negative
        dataScale <- input$dataScale %||% "height"
        display_data <- ordered_data

        if (dataScale == "depth" && "height" %in% colnames(display_data)) {
          # Transform heights to match what's shown on the plot (negative for depth)
          display_data$height <- display_data$height * -1
          # Use the actual zColumn name if available, otherwise keep "height"
          z_col_name <- if (!is.null(zColumn()) && nzchar(zColumn())) {
            zColumn()
          } else {
            "height"
          }
          colnames(display_data)[colnames(display_data) == "height"] <- z_col_name
        } else if ("height" %in% colnames(display_data)) {
          # For height scale, also use the actual zColumn name
          z_col_name <- if (!is.null(zColumn()) && nzchar(zColumn())) {
            zColumn()
          } else {
            "height"
          }
          colnames(display_data)[colnames(display_data) == "height"] <- z_col_name
        }

        return(display_data)
      } else {
        # If columns don't exist, just return the data as-is
        return(partitionState$data)
      }
    } else {
      data.frame(Message = "No partitions created yet")
    }
  }, digits = 2)

  # Render top partition name editors
  output$topPartitionEditors <- renderUI({
    if (nrow(partitionState$data) == 0) return(NULL)

    # Get unique sites with their top partitions
    sites <- unique(partitionState$data$site)
    editors <- lapply(sites, function(site) {
      site_data <- partitionState$data[partitionState$data$site == site, ]
      top_partition <- site_data[which.max(site_data$height), ]

      textInput(
        inputId = paste0("topPartitionName_", site),
        label = paste("Top partition name for", site),
        value = top_partition$partition,
        width = "100%"
      )
    })

    do.call(tagList, editors)
  })

  # Observer to update top partition names when text inputs change
  observe({
    if (nrow(partitionState$data) == 0) return()

    sites <- unique(partitionState$data$site)
    for (site in sites) {
      input_id <- paste0("topPartitionName_", site)
      new_name <- input[[input_id]]

      if (!is.null(new_name) && nzchar(new_name)) {
        # Find the top partition for this site and update its name
        top_idx <- which(partitionState$data$site == site &
                        partitionState$data$height == max(partitionState$data$height[partitionState$data$site == site]))
        if (length(top_idx) > 0) {
          partitionState$data$partition[top_idx] <- new_name
        }
      }
    }
  })

  # Clear partitions when loading NEW data (not when restoring)
  observeEvent(input$dataSource, {
    # Don't proceed if dataSource is NULL (can happen on startup)
    if (is.null(input$dataSource)) {
      return()
    }

    # Only clear partitions if this is a new data source AND not loading saved dataset
    if (!isTRUE(r$loadedSavedDataset)) {
      # Check if this is different from persisted data source
      isNewSource <- is.null(r$persistedDataSource) || r$persistedDataSource != input$dataSource

      if (isNewSource) {
        # This is a new data source, clear partitions BEFORE loading data
    r$partitionData <- NULL
        partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
    partitionState$clickData <- list()
    # Reset partition source to none when loading new data
    updateSelectInput(session, "partitionSource", selected = "none")
        # Mark that we're loading from signal source, not saved dataset
        r$loadedSavedDataset <- FALSE
        r$currentLoadedDatasetName <- NULL  # Clear current loaded dataset name
        # Clear persisted dataset to force fresh load
        r$persistedDataset <- NULL
        # Clear hash to allow new saves
        r$lastSavedDataHash <- NULL
        # Clear persisted column selections so UI refreshes with new dataset columns
        r$persistedColumnSelections$siteColumn <- NULL
        r$persistedColumnSelections$zColumn <- NULL
        r$persistedColumnSelections$signalColumns <- NULL
        # Clear alignment/results from previous run so preview shows new data
        r$alignment <- NULL
        # Force UI refresh
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
      }
    }
    # Don't call UpdateData if we're restoring data (to prevent errors)
    if (isTRUE(r$isRestoringData)) {
      return()
    }

    # Automatically load data when source changes (only if dataSource is valid)
    # Don't call UpdateData if dataSource is NULL or empty - req() inside UpdateData will fail silently
    if (!is.null(input$dataSource) && nzchar(input$dataSource)) {
      tryCatch({
        # Access the reactive value to trigger it
        result <- UpdateData()
        # If UpdateData returns NULL due to req() failure, that's expected - don't show error
        if (is.null(result)) {
          # This is normal - req() stopped execution, not an error
          return()
        }
      }, error = function(e) {
        # Check if this is a shiny.silent.error (from req() failure) - ignore these
        error_class <- class(e)
        if ("shiny.silent.error" %in% error_class) {
          # This is expected when req() fails - don't show error
          return()
        }

        # Extract error message properly for real errors
        error_msg <- tryCatch({
          if (is.null(e)) {
            "Unknown error"
          } else if (!is.null(e$message) && nchar(trimws(e$message)) > 0) {
            e$message
          } else if (!is.null(conditionMessage(e)) && nchar(trimws(conditionMessage(e))) > 0) {
            conditionMessage(e)
          } else {
            paste("Error:", paste(error_class, collapse = ", "))
          }
        }, error = function(e2) {
          "Unknown error occurred"
        })

        # Only show error if it's a real error (not silent error from req())
        showNotification(paste("Error loading data:", error_msg), type = "error")
        LogMsg("Error in UpdateData(): ", error_msg)
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$dataFile, {
    # Only clear partitions if this is a new file (not restoring) AND not loading saved dataset
    if (!is.null(input$dataFile) && !isTRUE(r$loadedSavedDataset)) {
      # Check if this is different from persisted data
      isNewFile <- is.null(r$persistedDataset) ||
                   is.null(r$dataset) ||
                   (nrow(r$dataset) != nrow(r$persistedDataset)) ||
                   !all(dim(r$dataset) == dim(r$persistedDataset))

      if (isNewFile) {
        # This is a new file, clear partitions and column selections
    r$partitionData <- NULL
        partitionState$data <- data.frame(site = character(0), height = numeric(0), partition = character(0), stringsAsFactors = FALSE)
    partitionState$clickData <- list()
    # Reset partition source to none when loading new data
    updateSelectInput(session, "partitionSource", selected = "none")
        # Mark that we're loading from signal source, not saved dataset
        r$loadedSavedDataset <- FALSE
        # Clear persisted column selections so UI refreshes with new dataset columns
        r$persistedColumnSelections$siteColumn <- NULL
        r$persistedColumnSelections$zColumn <- NULL
        r$persistedColumnSelections$signalColumns <- NULL
        # Clear alignment/results from previous run so preview shows new data
        r$alignment <- NULL
        # Force UI refresh
        datasetId(datasetId() + 1)
        uiTrigger(uiTrigger() + 1)
      }
    }
    # Only call UpdateData if this is a real file change, not just restoration
    # Check if we're in the middle of restoring persisted data
    if (!is.null(input$dataFile) && !is.null(input$dataSource) && nzchar(input$dataSource)) {
      # Check if this is a restoration (we have persisted data and it matches)
      isRestoration <- !is.null(r$persistedDataset) &&
                      !is.null(r$dataset) &&
                      nrow(r$dataset) == nrow(r$persistedDataset) &&
                      all(dim(r$dataset) == dim(r$persistedDataset))

      # Only call UpdateData if it's not a restoration
      if (!isRestoration) {
        tryCatch({
          result <- UpdateData()
          if (is.null(result)) {
            return()
          }
        }, error = function(e) {
          # Check if this is a shiny.silent.error (from req() failure) - ignore these
          error_class <- class(e)
          if ("shiny.silent.error" %in% error_class) {
            # This is expected when req() fails - don't show error
            return()
          }

          error_msg <- tryCatch({
            if (is.null(e)) {
              "Unknown error"
            } else if (!is.null(e$message) && nchar(trimws(e$message)) > 0) {
              e$message
            } else if (!is.null(conditionMessage(e)) && nchar(trimws(conditionMessage(e))) > 0) {
              conditionMessage(e)
            } else {
              paste("Error:", paste(error_class, collapse = ", "))
            }
          }, error = function(e2) {
            "Unknown error occurred"
          })

          showNotification(paste("Error loading data file:", error_msg), type = "error")
          LogMsg("Error in UpdateData() from file: ", error_msg)
        })
      }
    }
  }, ignoreInit = TRUE)

  # Store original partition data before auto partition modifications (for discard functionality)
  originalAutoPartitionData <- reactiveVal(NULL)

  # Handle add auto partitions button
  observeEvent(input$addAutoPartitions, {
    # Store current partition data as original (for discard)
    originalAutoPartitionData(r$partitionData)

    # IMPORTANT: Save column selections and other settings BEFORE showing save modal
    # This ensures they're preserved when the modal closes
    if (!is.null(siteColumn())) {
      r$persistedColumnSelections$siteColumn <- siteColumn()
    }
    if (!is.null(zColumn())) {
      r$persistedColumnSelections$zColumn <- zColumn()
    }
    if (!is.null(signalColumns())) {
      r$persistedColumnSelections$signalColumns <- signalColumns()
    }
    if (!is.null(input$loadSiteSelect)) {
      r$persistedSiteSelections <- input$loadSiteSelect
    }
    if (!is.null(r$dataset)) {
      r$persistedDataset <- r$dataset
    }
    if (!is.null(input$dataSource)) {
      r$persistedDataSource <- input$dataSource
    }
    if (!is.null(input$dataScale)) {
      r$persistedDataScale <- input$dataScale
    }

    # Create auto partitions temporarily to show count
    tryCatch({
      df <- r$dataset
      if (is.null(df) || is.null(siteColumn()) || is.null(zColumn())) {
        showNotification("Please select site and height columns first", type = "error")
        return()
      }

      # Create partitions using StratoBayes Partitions function
      # CRITICAL: Read nStrata directly from input to ensure we get the current value
      # Access input$nStrata directly without any caching
      nStrata_val <- input$nStrata

      if (is.null(nStrata_val)) {
        showNotification("nStrata is NULL - please enter a number of strata", type = "error")
        return()
      }

      if (is.na(nStrata_val) || nStrata_val < 1 || nStrata_val > 8) {
        showNotification(paste("Invalid number of strata:", nStrata_val, "- Please enter a positive integer between 1 and 8."), type = "error")
        return()
      }

      # Convert to integer to ensure correct type
      nStrata_int <- as.integer(round(nStrata_val))

      # Debug notification to verify the value being used (can be removed later)
      # showNotification(paste("Creating", nStrata_int, "partitions (from input value:", nStrata_val, ")"), type = "message", duration = 2)

      parts_df <- StratoBayes::Partitions(
        signal = df,
        nStrata = nStrata_int,
        distribute = input$distributeMethod,
        siteColumn = siteColumn(),
        zColumn = zColumn(),
        zScale = input$dataScale
      )

      # CRITICAL: Ensure each site has a partition at the top boundary
      # On height scale: top = max(height)
      # On depth scale: top = min(depth)
      # Partitions() may not create a partition exactly at the top, which causes StratData errors
      sites <- unique(df[[siteColumn()]])
      z_col <- zColumn()
      dataScale <- input$dataScale %||% "height"

      for (site in sites) {
        site_data <- df[df[[siteColumn()]] == site, ]
        if (nrow(site_data) > 0) {
          heights <- suppressWarnings(as.numeric(site_data[[z_col]]))
          heights <- heights[!is.na(heights)]
          if (length(heights) > 0) {
            # Determine top boundary based on scale
            if (dataScale == "depth") {
              top_boundary <- min(heights)  # Top is at minimum depth
              height_range <- diff(range(heights))
              buffer <- max(height_range * 0.001, 0.1, na.rm = TRUE)
              required_top_height <- max(0, top_boundary - buffer)
            } else {
              top_boundary <- max(heights)  # Top is at maximum height
              height_range <- diff(range(heights))
              buffer <- max(height_range * 0.001, 1.0, na.rm = TRUE)
              required_top_height <- top_boundary + buffer
            }

            # Get existing partitions for this site
            site_parts <- parts_df[parts_df[[siteColumn()]] == site, ]
            if (nrow(site_parts) > 0) {
              # Check if we need to add/update top partition
              if (dataScale == "depth") {
                min_part_height <- min(site_parts[[z_col]])
                needs_top <- top_boundary < min_part_height || required_top_height < min_part_height
                top_part_idx <- which.min(site_parts[[z_col]])
                top_part_height <- site_parts[[z_col]][top_part_idx]
              } else {
                max_part_height <- max(site_parts[[z_col]])
                needs_top <- top_boundary > max_part_height || required_top_height > max_part_height
                top_part_idx <- which.max(site_parts[[z_col]])
                top_part_height <- site_parts[[z_col]][top_part_idx]
              }

              if (needs_top) {
                # Check if there's already a partition close to the top (within buffer)
                if (length(top_part_idx) > 0 &&
                    abs(top_part_height - required_top_height) < buffer * 10) {
                  # Update existing top partition to be at the top
                  parts_df[parts_df[[siteColumn()]] == site &
                           parts_df[[z_col]] == top_part_height, z_col] <- required_top_height
                } else {
                  # Add new top partition for this site
                  max_part_id <- max(parts_df$partition, na.rm = TRUE)
                  new_partition_id <- max_part_id + 1
                  new_row <- data.frame(
                    site = site,
                    height = required_top_height,
                    partition = new_partition_id,
                    stringsAsFactors = FALSE
                  )
                  colnames(new_row)[colnames(new_row) == "site"] <- siteColumn()
                  colnames(new_row)[colnames(new_row) == "height"] <- z_col
                  parts_df <- rbind(parts_df, new_row)
                }
              }
            } else {
              # No partitions for this site - add top partition
              max_part_id <- if (nrow(parts_df) > 0) max(parts_df$partition, na.rm = TRUE) else 0
              new_partition_id <- max_part_id + 1
              new_row <- data.frame(
                site = site,
                height = required_top_height,
                partition = new_partition_id,
                stringsAsFactors = FALSE
              )
              colnames(new_row)[colnames(new_row) == "site"] <- siteColumn()
              colnames(new_row)[colnames(new_row) == "height"] <- z_col
              parts_df <- rbind(parts_df, new_row)
            }
          }
        }
      }

      # Re-sort by site and height
      parts_df <- parts_df[order(match(parts_df[[siteColumn()]], sites), parts_df[[z_col]]), ]

      # Add the required sedRatePartition column
      parts_df$sedRatePartition <- parts_df$partition

      # Show save/discard modal with partition count
      partitionCount <- nrow(parts_df)
      currentDatasetName <- if (isTRUE(r$loadedSavedDataset) && !is.null(r$currentLoadedDatasetName)) {
        r$currentLoadedDatasetName
      } else {
        NULL
      }
      showModal(partitionSaveModal(partitionCount, currentDatasetName))

      # Store the auto partitions temporarily (will be saved or discarded based on user choice)
      r$tempAutoPartitions <- parts_df

    }, error = function(e) {
      showNotification(paste("Error creating auto partitions:", e$message), type = "error")
    })
  })


  # Make partition data reactive to partition source changes
  observeEvent(input$partitionSource, {
    # When switching to interactive, restore partition data if available
    if (input$partitionSource == "interactive" && !is.null(r$partitionData) && nrow(r$partitionData) > 0) {
      # Convert from actual column names back to generic for editing
      parts_df <- r$partitionData
      if (!is.null(siteColumn()) && siteColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == siteColumn()] <- "site"
      }
      if (!is.null(zColumn()) && zColumn() %in% colnames(parts_df)) {
        colnames(parts_df)[colnames(parts_df) == zColumn()] <- "height"
      }
      # Restore partition data when switching back to interactive - normalize structure
      partitionState$data <- normalizePartitionData(parts_df)
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxl.sheet, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
    UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxlSkip, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
        UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  observeEvent(input$readxlSkipCols, {
    if (!isTRUE(r$isRestoringData)) {
      tryCatch({
        UpdateData()
      }, error = function(e) {
        if (!"shiny.silent.error" %in% class(e)) {
          showNotification(paste("Error loading data:", conditionMessage(e)), type = "error")
        }
      })
    }
  }, ignoreInit = TRUE)

  # expose to other modules
  list(
    stratData    = stratData,
    signalValid  = signalValid,
    siteColumn   = siteColumn,
    zColumn      = zColumn,
    signalCols   = signalColumns,
    rawdata = reactive(r$dataset),
    updateDataPreview = updateDataPreview
  )
}
