model_server <- function(input, output, session, data_api, priorSettings, r) {

  output$siteModelNote <- renderUI({
    # Heading (bold)
    HeaderLine <- paste(
      "Distinct sedimentation rate for each",
      switch(
        input$sedModel,
        "site"             = "site",
        "partition"        = "partition",
        "site x partition" = "site × partition",
        "site, partition"  = "partition at each site",
        input$sedModel
      )
    )

    Idx   <- indices()
    if (is.null(Idx)) {
      # If indices() returned NULL (likely due to validation error), show error message
      return(tags$div(
        style = "color: #d9534f; padding: 10px; border: 1px solid #d9534f; border-radius: 4px;",
        tags$strong("⚠ Error: Invalid alpha position values"),
        tags$p("Please check the custom alpha position values and ensure they are within the valid range for each section.",
               style = "margin-top: 5px;")
      ))
    }
    Names <- if (!is.null(Idx) && length(Idx$names) > 0) Idx$names else character(0)

    # Categorise (case-insensitive); tidy with sort/unique
    Alphas <- sort(unique(Names[grepl("(^|_)alpha", Names, ignore.case = TRUE)]))
    Gammas <- sort(unique(Names[grepl("(^|_)gamma", Names, ignore.case = TRUE)]))
    Zetas  <- sort(unique(Names[grepl("(^|_)zeta",  Names, ignore.case = TRUE)]))
    Deltas <- sort(unique(Names[grepl("(^|_)(delta|gap)", Names, ignore.case = TRUE)]))

    GammaLabel <- if (!is.null(input$alignmentScale) &&
                      tolower(input$alignmentScale) == "height") {
      "Relative sedimentation rates"
    } else {
      "Sedimentation rates"
    }

    MakeSection <- function(Label, Items) {
      if (length(Items) == 0) return(NULL)  # hide empty sections entirely
      tags$div(
        tags$div(tags$u(paste0(Label, ":"))),   # subheading underlined
        lapply(Items, function(x) tags$div(x))   # one item per line
      )
    }

    Sections <- Filter(Negate(is.null), list(
      MakeSection("Shift parameters", Alphas),
      MakeSection(GammaLabel,        Gammas),
      MakeSection("Site-specific sedimentation rate multipliers", Zetas),
      MakeSection("Unconformities",  Deltas)
    ))

    # Interleave <br> between only the sections that exist
    Children <- if (length(Sections) > 0) {
      unlist(Map(function(s) list(s, tags$br()), Sections), recursive = FALSE)[-length(Sections)*2]
    } else NULL

    tags$div(
      tags$div(tags$strong(HeaderLine)),  # heading bold
      if (!is.null(Children)) list(tags$br(), Children)
    )
  })

  # Store last non-custom alpha position to default custom values
  lastAlphaPosition <- reactiveVal("top")

  # Store validated custom alpha values (only updated when Update button is clicked)
  storedCustomAlphaValues <- reactiveVal(list())

  # Track when alpha position changes from non-custom to custom
  # Don't clear stored values if we're loading settings (they'll be restored)
  isLoadingSettings <- reactiveVal(FALSE)

  observeEvent(input$alphaPosition, {
    if (input$alphaPosition != "custom") {
      lastAlphaPosition(input$alphaPosition)
      # Only clear stored custom values when switching away from custom (not when loading)
      if (!isLoadingSettings()) {
        storedCustomAlphaValues(list())
      }
    }
  })

  # Track if custom alpha inputs have been initialized to prevent auto-updates
  customAlphaInitialized <- reactiveVal(FALSE)

  # Reset initialization flag when switching away from custom
  observeEvent(input$alphaPosition, {
    if (input$alphaPosition != "custom") {
      customAlphaInitialized(FALSE)
    }
  })

  # UI output for custom alpha numeric inputs
  output$customAlphaInputs <- renderUI({
    req(data_api$signalValid())
    req(input$alphaPosition == "custom")

    sd <- data_api$stratData()
    sites <- sd$sites
    alignmentScale <- input$alignmentScale %||% "height"

    # Determine which sites need inputs
    # For height scale, skip the first site (reference)
    # For age scale, all sites need inputs
    if (alignmentScale == "height") {
      inputSites <- sites[-1]
      if (length(inputSites) == 0) {
        return(tags$p("No sites available for custom alpha position."))
      }
    } else {
      inputSites <- sites
      if (length(inputSites) == 0) {
        return(tags$p("No sites available for custom alpha position."))
      }
    }

    # Get the last selected position (top/middle/bottom) to default custom values
    lastPos <- isolate(lastAlphaPosition())
    storedValues <- isolate(storedCustomAlphaValues())

    # Get section boundaries for each site (same as .MatchAlphaPosition uses)
    # Only initialize defaults if inputs haven't been created yet
    isInitialized <- isolate(customAlphaInitialized())

    siteInputs <- lapply(seq_along(inputSites), function(i) {
      site <- inputSites[i]
      site_idx <- match(site, sites)

      # Get the valid range for alpha position (section boundaries, same as .MatchAlphaPosition)
      bottom <- tryCatch({
        sd[[c("partsAttr", "BoundLow")]][1, site_idx]
      }, error = function(e) NULL)
      top <- tryCatch({
        max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE)
      }, error = function(e) NULL)

      if (is.null(bottom) || is.null(top) || is.na(bottom) || is.na(top) || !is.finite(bottom) || !is.finite(top)) {
        # Fallback to height range if section boundaries not available
        heights <- tryCatch({
          StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
        }, error = function(e) NULL)
        if (!is.null(heights) && length(heights) > 0) {
          # Ensure heights are finite and valid
          heights <- heights[is.finite(heights) & !is.na(heights)]
          if (length(heights) > 0) {
            bottom <- min(heights, na.rm = TRUE)
            top <- max(heights, na.rm = TRUE)
            # Ensure bottom and top are valid
            if (!is.finite(bottom) || !is.finite(top) || bottom >= top) {
              # If range is invalid, use median ± some value
              median_height <- median(heights, na.rm = TRUE)
              if (is.finite(median_height)) {
                bottom <- median_height - 10
                top <- median_height + 10
              } else {
                bottom <- 0
                top <- 100
              }
            }
          } else {
            bottom <- 0
            top <- 100
          }
        } else {
          bottom <- 0
          top <- 100
        }
      }

      # Final validation - ensure bottom < top and both are finite
      if (!is.finite(bottom) || !is.finite(top) || bottom >= top) {
        # Use safe defaults
        bottom <- 0
        top <- 100
      }

      inputId <- paste0("customAlpha_", site)

      # Get current value - check existing input first, then stored, then default (only if not initialized)
      existingInput <- isolate(input[[inputId]])
      storedValue <- storedValues[[site]]

      # Determine value to use
      if (!is.null(existingInput) && !is.na(existingInput)) {
        # Always preserve existing input value - never auto-update
        currentVal <- existingInput
      } else if (!is.null(storedValue) && !is.na(storedValue)) {
        # Use stored value if available
        currentVal <- storedValue
      } else if (!isInitialized) {
        # Only set default on first initialization
        if (lastPos == "top") {
          currentVal <- top
        } else if (lastPos == "bottom") {
          currentVal <- bottom
        } else {
          currentVal <- (bottom + top) / 2
        }
      } else {
        # Already initialized - use a safe default to avoid errors
        currentVal <- (bottom + top) / 2
      }

      # Create numeric input
      numericInput(
        inputId = inputId,
        label = paste0("Alpha position for ", site),
        value = currentVal,
        step = (top - bottom) / 100
      )
    })

    # Mark as initialized after creating inputs
    if (!isInitialized) {
      customAlphaInitialized(TRUE)
    }

    tagList(
      tags$div(
        style = "margin-top: 10px;",
        tags$strong("Custom alpha positions:"),
        tags$p("Enter numeric values for each site (beyond reference site for height scale). Click 'Update' to validate.",
               style = "font-size: 0.9em; color: #666;")
      ),
      siteInputs
    )
  })

  # Handle Update button for alpha positions - validate and store on click only
  observeEvent(input$updateAlphaPositions, {
    req(data_api$signalValid())
    req(input$alphaPosition == "custom")

    sd <- data_api$stratData()
    sites <- sd$sites
    alignmentScale <- input$alignmentScale %||% "height"

    if (alignmentScale == "height") {
      inputSites <- sites[-1]
    } else {
      inputSites <- sites
    }

    errors <- character(0)
    storedValues <- list()

    for (site in inputSites) {
      inputId <- paste0("customAlpha_", site)
      val <- input[[inputId]]

      if (!is.null(val) && !is.na(val)) {
        # Get section boundaries for validation (same as .MatchAlphaPosition uses)
        site_idx <- match(site, sites)
        bottom <- tryCatch({
          sd[[c("partsAttr", "BoundLow")]][1, site_idx]
        }, error = function(e) NULL)
        top <- tryCatch({
          max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE)
        }, error = function(e) NULL)

        if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
          if (val < bottom || val > top) {
            errors <- c(errors, paste0(site, ": ", signif(val, 3),
                                      " is outside range [", signif(bottom, 3), ", ", signif(top, 3), "]"))
          } else {
            # Value is valid - store it
            storedValues[[site]] <- val
          }
        } else {
          # Fallback to height range validation
          heights <- tryCatch({
            StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
          }, error = function(e) NULL)

          if (!is.null(heights) && length(heights) > 0) {
            ymin <- min(heights, na.rm = TRUE)
            ymax <- max(heights, na.rm = TRUE)

            if (val < ymin || val > ymax) {
              errors <- c(errors, paste0(site, ": ", signif(val, 3),
                                        " is outside range [", signif(ymin, 3), ", ", signif(ymax, 3), "]"))
            } else {
              storedValues[[site]] <- val
            }
          } else {
            # No validation possible, store anyway
            storedValues[[site]] <- val
          }
        }
      }
    }

    if (length(errors) > 0) {
      showNotification(
        paste0("Validation error: ", paste(errors, collapse = "; ")),
        type = "error",
        duration = 10
      )
    } else {
      # All values are valid - store them
      storedCustomAlphaValues(storedValues)
      showNotification("Alpha positions updated successfully.", type = "message", duration = 3)
    }
  })

  # Helper reactive to resolve alphaPosition (uses stored custom values from Update button)
  resolvedAlphaPosition <- reactive({
    alphaPos <- input$alphaPosition

    if (!is.null(alphaPos) && length(alphaPos) == 1 && alphaPos == "custom") {
      # Use stored custom values (only updated when Update button is clicked)
      if (!data_api$signalValid()) {
        return("middle")  # Fallback if no valid data
      }

      sd <- data_api$stratData()
      sites <- sd$sites
      alignmentScale <- input$alignmentScale %||% "height"

      # Determine which sites need values
      if (alignmentScale == "height") {
        inputSites <- sites[-1]
      } else {
        inputSites <- sites
      }

      # Get stored custom values (from Update button) - only use these, not direct inputs
      storedValues <- storedCustomAlphaValues()

      # Collect custom values (use stored if available, otherwise use defaults)
      # Do NOT use input values directly - only use values that have been validated via Update button
      customValues <- numeric(length(sites))
      lastPos <- isolate(lastAlphaPosition())

      if (alignmentScale == "height") {
        customValues[1] <- NA  # Reference site doesn't need value
        for (i in seq_along(inputSites)) {
          site <- inputSites[i]

          # Use stored value if available (from Update button), otherwise use default
          val <- storedValues[[site]]

          if (!is.null(val) && !is.na(val)) {
            customValues[i + 1] <- val
          } else {
            # Use last selected position as default if not provided (use section boundaries)
            site_idx <- match(site, sites)
            bottom <- tryCatch({
              sd[[c("partsAttr", "BoundLow")]][1, site_idx]
            }, error = function(e) NULL)
            top <- tryCatch({
              max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE)
            }, error = function(e) NULL)

            if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
              if (lastPos == "top") {
                customValues[i + 1] <- top
              } else if (lastPos == "bottom") {
                customValues[i + 1] <- bottom
              } else {
                customValues[i + 1] <- (bottom + top) / 2
              }
            } else {
              # Fallback to height range
              heights <- tryCatch({
                StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                ymin <- min(heights, na.rm = TRUE)
                ymax <- max(heights, na.rm = TRUE)
                if (lastPos == "top") {
                  customValues[i + 1] <- ymax
                } else if (lastPos == "bottom") {
                  customValues[i + 1] <- ymin
                } else {
                  customValues[i + 1] <- mean(range(heights, na.rm = TRUE))
                }
              } else {
                customValues[i + 1] <- 0
              }
            }
          }
        }
      } else {
        # Age scale - all sites need values
        for (i in seq_along(inputSites)) {
          site <- inputSites[i]

          # Use stored value if available (from Update button), otherwise use default
          val <- storedValues[[site]]

          if (!is.null(val) && !is.na(val)) {
            customValues[i] <- val
          } else {
            # Use last selected position as default (use section boundaries)
            site_idx <- match(site, sites)
            bottom <- tryCatch({
              sd[[c("partsAttr", "BoundLow")]][1, site_idx]
            }, error = function(e) NULL)
            top <- tryCatch({
              max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE)
            }, error = function(e) NULL)

            if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
              if (lastPos == "top") {
                customValues[i] <- top
              } else if (lastPos == "bottom") {
                customValues[i] <- bottom
              } else {
                customValues[i] <- (bottom + top) / 2
              }
            } else {
              # Fallback to height range
              heights <- tryCatch({
                StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                ymin <- min(heights, na.rm = TRUE)
                ymax <- max(heights, na.rm = TRUE)
                if (lastPos == "top") {
                  customValues[i] <- ymax
                } else if (lastPos == "bottom") {
                  customValues[i] <- ymin
                } else {
                  customValues[i] <- mean(range(heights, na.rm = TRUE))
                }
              } else {
                customValues[i] <- 0
              }
            }
          }
        }
      }

      return(customValues)
    }

    return(alphaPos)
  })

  indices <- reactive({
    if (data_api$signalValid()) {
      # Try to create indices, catch any errors
      tryCatch({
        StratoBayes:::.CreateIndices(data_api$stratData(), input$alignmentScale, input$sedModel, resolvedAlphaPosition())
      }, error = function(e) {
        # If error is about alpha position, show user-friendly message
        if (grepl("alphaPosition", e$message, ignore.case = TRUE) ||
            grepl("must be >= 0 and <=", e$message)) {
          showNotification(
            paste0("Error: Custom alpha position value is outside the valid range for this section. ",
                   "Please check the alpha position values and click 'Update' to validate them."),
            type = "error",
            duration = 10
          )
        } else {
          # For other errors, show the original message
          showNotification(
            paste0("Error creating model indices: ", e$message),
            type = "error",
            duration = 10
          )
        }
        return(NULL)
      })
    } else NULL
  })


  output$priorSelectorUI <- renderUI({
    idx <- indices()
    req(!is.null(idx), length(idx$names) > 0)
    nms <- idx$names

    # Keep current selection if still valid; else pick first
    current <- isolate(input$activePrior)  # now a NAME (character), not a number
    selectedName <- if (!is.null(current) && current %in% nms) current else nms[[1]]

    tagList(
      radioButtons(
        "activePrior", "Prior to set",
        choices  = setNames(nms, nms),   # values = names
        selected = selectedName
      ),
      div(style = "margin-top: .5rem;",
          actionButton("resetPriors", "Auto Priors", icon = icon("rotate-left")))
    )
  })

  activePriorName <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)
    nm <- input$activePrior
    if (!is.null(nm) && nm %in% idx$names) return(nm)
    idx$names[[1]]
  })

  activePriorIndex <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)
    match(activePriorName(), idx$names)
  })

  activePrior <- reactive({
    nm <- activePriorName()
    if (length(nm) == 1 && nm %in% names(priorSettings)) priorSettings[[nm]]
    else NULL
  })

  # Use UI choice if present; otherwise fall back to the stored prior type
  activePriorType <- reactive({
    if (!is.null(input$priorType)) return(input$priorType)
    p <- activePrior()
    if (!is.null(p) && !is.null(p$priorType)) return(p$priorType)
    "Normal"
  })


  output$priorParams <- renderUI({
    # ensure both are available before building the UI
    req(activePriorType())
    req(activePrior())
    priorParams(activePriorType, activePrior)
  })
  output$viewPrior <- renderPlot({
    # Validate inputs before plotting to prevent errors
    switch(input$priorType,
           Uniform = {
             req(input$uniformMin, input$uniformMax)
             minVal <- as.numeric(input$uniformMin)
             maxVal <- as.numeric(input$uniformMax)
             # Validate that values are finite and valid
             if (any(is.na(c(minVal, maxVal))) || any(!is.finite(c(minVal, maxVal)))) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid numeric values", cex = 1.2, col = "red")
               return()
             }
             PlotUniform(sort(c(minVal, maxVal)), activePriorName())
           },
           Gamma = {
             req(input$gammaAlpha, input$gammaBeta)
             alpha <- as.numeric(input$gammaAlpha)
             beta <- as.numeric(input$gammaBeta)
             # Validate that values are finite, positive, and valid
             if (any(is.na(c(alpha, beta))) || any(!is.finite(c(alpha, beta))) ||
                 alpha <= 0 || beta <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid positive numeric values", cex = 1.2, col = "red")
               return()
             }
             PlotGamma(alpha, beta, activePriorName())
           },
           Normal = {
             req(input$normalMean, input$normalSD)
             meanVal <- as.numeric(input$normalMean)
             sdVal <- as.numeric(input$normalSD)
             # Validate that values are finite and SD is positive
             if (any(is.na(c(meanVal, sdVal))) || any(!is.finite(c(meanVal, sdVal))) ||
                 sdVal <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid numeric values (SD must be positive)", cex = 1.2, col = "red")
               return()
             }
             PlotNormal(meanVal, sdVal, activePriorName())
           },
           Exponential = {
             req(input$expRate)
             rate <- as.numeric(input$expRate)
             # Validate that rate is finite and positive
             if (is.na(rate) || !is.finite(rate) || rate <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter a valid positive numeric value", cex = 1.2, col = "red")
               return()
             }
             PlotExp(rate, activePriorName())
           }
    )
  })

  # Helper function to ensure priors are initialized with AutoPrior
  ensurePriorsInitialized <- function() {
    req(data_api$signalValid())
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    all_params <- idx$names
    missing_params <- setdiff(all_params, names(priorSettings))

    if (length(missing_params) > 0) {
      autoP <- AutoPrior(
        stratData      = data_api$stratData(),
        alignmentScale = input$alignmentScale,
        sedModel       = input$sedModel,
        alphaPosition  = resolvedAlphaPosition()
      )

      for (nm in missing_params) {
        if (!is.null(autoP[[nm]])) {
          priorSettings[[nm]] <- .map_prior(autoP[[nm]])
        }
      }
    }
  }

  priors <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    # Ensure all priors are initialized
    ensurePriorsInitialized()

    structure(
      class = c("list", "StratPrior"),
      names = idx$names,
      lapply(idx$names, function(param) {
        x <- priorSettings[[param]]
        if (is.null(x)) {
          # If still null after ensurePriorsInitialized, create a default Normal prior
          x <- list(priorType = "Normal", normalMean = 0, normalSD = 1)
          priorSettings[[param]] <- x
        }
        switch(
          x$priorType,
          "Exponential" = ExponentialPrior(x$expRate),
#          "Gamma"       = GammaPrior(x$gammaAlpha, x$gammaBeta),
          "Normal"      = NormalPrior(x$normalMean, x$normalSD),
          "Uniform"     = UniformPrior(x$uniformMin, x$uniformMax)
        )
      })
    )
  })


  # --- guard to avoid saving while we're programmatically syncing inputs ---
  .syncing <- reactiveVal(FALSE)

  # Keeps the controls in sync with the stored prior for the currently active parameter
  observeEvent(activePriorName(), ignoreInit = TRUE, {
    p <- activePrior(); req(p)

    .syncing(TRUE)  # prevent the save observer from firing on these programmatic updates

    if (!is.null(p$priorType)) {
      updateRadioButtons(session, "priorType", selected = p$priorType)  # Fixed: was updateSelectInput
    }

    switch(p$priorType,
           "Normal" = {
             if (!is.null(p$normalMean)) {
               # Only update if the value is actually different to prevent rapid-fire conflicts
               currentMean <- isolate(input$normalMean)
               if (is.null(currentMean) || abs(currentMean - p$normalMean) > 1e-10) {
                 updateNumericInput(session, "normalMean", value = signif(p$normalMean, digits = 4))
               }
             }
             if (!is.null(p$normalSD)) {
               currentSD <- isolate(input$normalSD)
               if (is.null(currentSD) || abs(currentSD - p$normalSD) > 1e-10) {
                 updateNumericInput(session, "normalSD", value = signif(p$normalSD, digits = 4))
               }
             }
           },
           "Gamma" = {
             if (!is.null(p$gammaAlpha)) {
               currentAlpha <- isolate(input$gammaAlpha)
               if (is.null(currentAlpha) || abs(currentAlpha - p$gammaAlpha) > 1e-10) {
                 updateNumericInput(session, "gammaAlpha", value = signif(p$gammaAlpha, digits = 4))
               }
             }
             if (!is.null(p$gammaBeta)) {
               currentBeta <- isolate(input$gammaBeta)
               if (is.null(currentBeta) || abs(currentBeta - p$gammaBeta) > 1e-10) {
                 updateNumericInput(session, "gammaBeta", value = signif(p$gammaBeta, digits = 4))
               }
             }
           },
           "Exponential" = {
             if (!is.null(p$expRate)) {
               currentRate <- isolate(input$expRate)
               if (is.null(currentRate) || abs(currentRate - p$expRate) > 1e-10) {
                 updateNumericInput(session, "expRate", value = signif(p$expRate, digits = 4))
               }
             }
           },
           "Uniform" = {
             if (!is.null(p$uniformMin)) {
               currentMin <- isolate(input$uniformMin)
               if (is.null(currentMin) || abs(currentMin - p$uniformMin) > 1e-10) {
                 updateNumericInput(session, "uniformMin", value = signif(p$uniformMin, digits = 4))
               }
             }
             if (!is.null(p$uniformMax)) {
               currentMax <- isolate(input$uniformMax)
               if (is.null(currentMax) || abs(currentMax - p$uniformMax) > 1e-10) {
                 updateNumericInput(session, "uniformMax", value = signif(p$uniformMax, digits = 4))
               }
             }
           }
    )

    # turn the guard off after the updates have been flushed to the client
    session$onFlushed(function() .syncing(FALSE), once = TRUE)
  })


  # Persist user edits into priorSettings for the active parameter
  # Use debounce to prevent rapid-fire updates from conflicting
  priorInputs <- reactive({
    list(
      priorType = input$priorType,
      normalMean = input$normalMean,
      normalSD = input$normalSD,
      gammaAlpha = input$gammaAlpha,
      gammaBeta = input$gammaBeta,
      expRate = input$expRate,
      uniformMin = input$uniformMin,
      uniformMax = input$uniformMax
    )
  })
  
  # Debounce the inputs to prevent rapid updates from conflicting
  debouncedPriorInputs <- debounce(priorInputs, millis = 300)
  
  observeEvent(debouncedPriorInputs(), {
    if (isTRUE(.syncing())) return()

    nm <- isolate(activePriorName()); req(nm)
    pt <- isolate(input$priorType);   if (is.null(pt)) return()

    # existing stored (could be from AutoPrior or earlier user edits)
    old <- priorSettings[[nm]]

    # build with safe fallbacks so we never write NULLs
    ps <- switch(pt,
                 "Normal" = {
                   m <- .get_or(isolate(input$normalMean), old$normalMean)
                   s <- .get_or(isolate(input$normalSD),   old$normalSD)
                   if (is.null(m) || is.null(s)) return()  # wait until inputs exist
                   list(priorType = "Normal", normalMean = m, normalSD = s)
                 },
                 "Gamma" = {
                   a <- .get_or(isolate(input$gammaAlpha), old$gammaAlpha)
                   b <- .get_or(isolate(input$gammaBeta),  old$gammaBeta)
                   if (is.null(a) || is.null(b)) return()
                   list(priorType = "Gamma", gammaAlpha = a, gammaBeta = b)
                 },
                 "Exponential" = {
                   r <- .get_or(isolate(input$expRate), old$expRate)
                   if (is.null(r)) return()
                   list(priorType = "Exponential", expRate = r)
                 },
                 "Uniform" = {
                   umin <- .get_or(isolate(input$uniformMin), old$uniformMin)
                   umax <- .get_or(isolate(input$uniformMax), old$uniformMax)
                   if (is.null(umin) || is.null(umax)) return()
                   list(priorType = "Uniform", uniformMin = umin, uniformMax = umax)
                 },
                 { return() } # unknown type
    )

    priorSettings[[nm]] <- ps
  }, ignoreInit = TRUE)

  # When priorType changes, prefill numeric inputs from stored values or AutoPrior
  observeEvent(input$priorType, {
    if (isTRUE(.syncing())) return()
    nm <- isolate(activePriorName()); req(nm)

    # Don't recalculate if dataScale just changed - wait for stratData to stabilize
    if (!data_api$signalValid()) return()

    stored <- priorSettings[[nm]]

    # Only compute AutoPrior if we have no stored prior OR if the stored prior is of a different type
    # AND we don't have any numbers for the newly selected type yet.
    # This avoids overwriting user-entered values when they come back.
    needs_prefill <- is.null(stored) || is.null(stored$priorType) || stored$priorType != input$priorType

    if (needs_prefill) {
      # Ensure stratData is valid before calculating AutoPrior
      # This prevents glitches when dataScale changes
      if (data_api$signalValid()) {
        ap <- AutoPrior(
          stratData      = data_api$stratData(),
          alignmentScale = input$alignmentScale,
          sedModel       = input$sedModel,
          alphaPosition  = resolvedAlphaPosition()
        )[[nm]]
        if (!is.null(ap)) {
          stored <- .map_prior(ap)
        } else {
          # no AutoPrior available -> keep whatever we have
          stored <- stored %||% list()
        }
      } else {
        # stratData not valid yet, keep stored value
        stored <- stored %||% list()
      }
    }

    .syncing(TRUE)
    switch(input$priorType,
           "Normal" = {
             if (!is.null(stored$normalMean)) updateNumericInput(session, "normalMean", value = signif(stored$normalMean, digits = 4))
             if (!is.null(stored$normalSD))   updateNumericInput(session, "normalSD",   value = signif(stored$normalSD, digits = 4))
           },
           "Gamma" = {
             if (!is.null(stored$gammaAlpha)) updateNumericInput(session, "gammaAlpha", value = signif(stored$gammaAlpha, digits = 4))
             if (!is.null(stored$gammaBeta))  updateNumericInput(session, "gammaBeta",  value = signif(stored$gammaBeta, digits = 4))
           },
           "Exponential" = {
             if (!is.null(stored$expRate))    updateNumericInput(session, "expRate",    value = signif(stored$expRate, digits = 4))
           },
           "Uniform" = {
             if (!is.null(stored$uniformMin)) updateNumericInput(session, "uniformMin", value = signif(stored$uniformMin, digits = 4))
             if (!is.null(stored$uniformMax)) updateNumericInput(session, "uniformMax", value = signif(stored$uniformMax, digits = 4))
           }
    )
    if (input$priorType != "Normal") {
      updateNumericInput(session, "normalMean", value = NA)
      updateNumericInput(session, "normalSD",   value = NA)
    }
    if (input$priorType != "Gamma") {
      updateNumericInput(session, "gammaAlpha", value = NA)
      updateNumericInput(session, "gammaBeta",  value = NA)
    }
    if (input$priorType != "Exponential") {
      updateNumericInput(session, "expRate",    value = NA)
    }
    if (input$priorType != "Uniform") {
      updateNumericInput(session, "uniformMin", value = NA)
      updateNumericInput(session, "uniformMax", value = NA)
    }
    session$onFlushed(function() .syncing(FALSE), once = TRUE)
  }, ignoreInit = TRUE)


  # Seed missing priors when Priors tab is opened (does not overwrite user edits)
  # Also handles the case where new params appear later (e.g., user changes sedModel elsewhere)
  observeEvent(input$modelTabs, {
    if (input$modelTabs != "prior") return()
    if (!data_api$signalValid())    return()

    ensurePriorsInitialized()

    LogMsg("Priors initialized for missing parameters (existing values preserved).")

    # Nudge the radio (so the UI re-renders but without firing saves)
    session$sendInputMessage("activePrior", list(value = input$activePrior))
  }, priority = 100)

  # Reset ALL priors to fresh AutoPrior
  observeEvent(input$resetPriors, {
    req(data_api$signalValid())
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    autoP <- AutoPrior(
      stratData      = data_api$stratData(),
      alignmentScale = input$alignmentScale,
      sedModel       = input$sedModel,
      alphaPosition  = input$alphaPosition
    )

    for (nm in idx$names) {
      if (!is.null(autoP[[nm]])) {
        priorSettings[[nm]] <- .map_prior(autoP[[nm]])
      }
    }

    # Sync visible controls to the new stored values (for active parameter only)
    cur <- isolate(activePrior()); req(cur)
    .syncing(TRUE)
    if (!is.null(cur$priorType)) {
      updateRadioButtons(session, "priorType", selected = cur$priorType)  # Fixed: was updateSelectInput
    }
    switch(cur$priorType,
           "Normal" = {
             if (!is.null(cur$normalMean)) updateNumericInput(session, "normalMean", value = signif(cur$normalMean, digits = 4))
             if (!is.null(cur$normalSD))   updateNumericInput(session, "normalSD",   value = signif(cur$normalSD, digits = 4))
           },
           "Gamma" = {
             if (!is.null(cur$gammaAlpha)) updateNumericInput(session, "gammaAlpha", value = signif(cur$gammaAlpha, digits = 4))
             if (!is.null(cur$gammaBeta))  updateNumericInput(session, "gammaBeta",  value = signif(cur$gammaBeta, digits = 4))
           },
           "Exponential" = {
             if (!is.null(cur$expRate))    updateNumericInput(session, "expRate",    value = signif(cur$expRate, digits = 4))
           },
           "Uniform" = {
             if (!is.null(cur$uniformMin)) updateNumericInput(session, "uniformMin", value = signif(cur$uniformMin, digits = 4))
             if (!is.null(cur$uniformMax)) updateNumericInput(session, "uniformMax", value = signif(cur$uniformMax, digits = 4))
           }
    )
    session$onFlushed(function() .syncing(FALSE), once = TRUE)

    showNotification("Priors reset to AutoPrior.", type = "message")
  })


  # enable/disable Priors tab
  paramsDefined <- reactive({
    !is.null(input$alignmentScale) && !is.null(input$sedModel) && !is.null(input$alphaPosition)
  })
  observeEvent(list(input$modelTabs, input$alignmentScale, input$sedModel, input$alphaPosition), {
    if (paramsDefined()) shinyjs::enable(selector = '#modelTabs li a[data-value="prior"]')
    else shinyjs::disable(selector = '#modelTabs li a[data-value="prior"]')
  })

  # Ensure priors are initialized when customRun view is shown
  # This will be triggered when priorUI is rendered

  # Combined prior UI output
  output$priorUI <- renderUI({
    req(data_api$signalValid())
    req(paramsDefined())

    ensurePriorsInitialized()

    tagList(
      uiOutput("priorSelectorUI"),
      br(),
      radioButtons("priorType", "Prior type",
                   choices = c("Normal", "Exponential", "Uniform"),
                   selected = isolate(activePriorType()),
                   inline = TRUE),
      uiOutput("priorParams"),
      br(),
      plotOutput("viewPrior", height = "300px")
    )
  })

  # --- static serving for StratoBayes progress HTML/PNGs ---
  # unique mount per module instance
  ns_id   <- gsub("\\W", "", session$ns(""))
  mountId <- paste0("strato-", ns_id)
  model_base <- normalizePath(file.path(tempdir(), mountId), mustWork = FALSE)
  dir.create(model_base, recursive = TRUE, showWarnings = FALSE)
  addResourcePath(mountId, model_base)

  # will hold the modelName created by RunStratModel
  modelNameRV <- reactiveVal(NULL)
  modelRunning <- reactiveVal(FALSE)
  modelProcess <- reactiveVal(NULL)

  # Run UI output (for custom run view)
  output$runUI <- renderUI({
    req(data_api$signalValid())

    tagList(
      tags$div(
        style = "text-align: center; padding: 20px;",
        tags$h4("Ready to run model"),
        tags$p("Configure your model settings above, then click 'Run Model' to start the analysis.")
      )
    )
  })

  # render the iframe inside Tab 5
  output$runIframeUI <- renderUI({
    if (is.null(modelNameRV())) {
      return(tags$div(
        style = "text-align: center; padding: 50px;",
        tags$h3("No model run initiated"),
        tags$p("Click 'Run Model' to start analysis and view live progress here.")
      ))
    }

    scale <- 1         # 60% magnification
    baseH <- 600         # your original iframe height in px

    tags$div(
      # scale the contents
      style = sprintf(
        "transform: scale(%f);
       transform-origin: 0 0;
       width: calc(100%% / %f);
       height: %fpx;
       overflow: hidden;",
        scale, scale, baseH / scale
      ),
      tags$iframe(
        src    = sprintf("/%s/%s/results.html", mountId, modelNameRV()),
        width  = "100%",
        height = as.character(baseH / scale),  # expand height before scaling
        style  = "border:0;"
      )
    )
  })

  # Helper function to get model parameters with defaults for QuickRun
  getModelParams <- function(useDefaults = FALSE) {
    if (useDefaults) {
      list(
        alignmentScale = "height",
        sedModel = "site",
        alphaPosition = "middle",
        nRun = 1,
        nIter = 1000,
        nThin = 1,
        nChains = 1,
        nKnots = 20
      )
    } else {
      list(
        alignmentScale = input$alignmentScale,
        sedModel = input$sedModel,
        alphaPosition = resolvedAlphaPosition(),
        nRun = input$nRun,
        nIter = input$nIter,
        nThin = input$nThin,
        nChains = input$nChains,
        nKnots = input$nKnots
      )
    }
  }

  # Replace your existing Align function with this version:
  Align <- function(useDefaults = FALSE) {
    # Prevent multiple simultaneous runs
    if (modelRunning()) {
      showNotification("A model is already running. Please wait for it to complete.", type = "warning")
      return()
    }

    # Validate data first
    if (!data_api$signalValid()) {
      showNotification("Please provide a valid data set before running the model.", type = "error")
      return()
    }

    modelRunning(TRUE)
    options(StratoBayes.openBrowser = FALSE)

    # Get model parameters
    params <- getModelParams(useDefaults)

    # For QuickRun or when priors might not be initialized, ensure AutoPriors are used
    if (useDefaults || length(names(priorSettings)) == 0) {
      # Generate AutoPriors with the current/default settings
      autoP <- AutoPrior(
        stratData      = data_api$stratData(),
        alignmentScale = params$alignmentScale,
        sedModel       = params$sedModel,
        alphaPosition  = params$alphaPosition
      )

      # Update priorSettings with AutoPriors
      for (nm in names(autoP)) {
        if (!is.null(autoP[[nm]])) {
          priorSettings[[nm]] <- .map_prior(autoP[[nm]])
        }
      }
    }

    thisModelName <- paste0("run_", format(Sys.time(), "%Y%m%d_%H%M%S"))
    modelNameRV(thisModelName)

    # Create a per-run subfolder
    model_dir <- file.path(model_base, thisModelName)
    dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)

    # Create initial placeholder results.html
    placeholder_html <- paste0('<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="3">
  <title>StratoBayes Progress</title>
  <style>
    body { font: 14px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial;
           margin: 20px; background: #f5f5f5; }
    .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .spinner { border: 3px solid #f3f3f3; border-top: 3px solid #3498db; border-radius: 50%;
               width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 20px auto; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .status { background: #e8f4fd; padding: 10px; border-radius: 4px; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="container">
    <h2>StratoBayes Model Running</h2>
    <div class="spinner"></div>
    <div class="status">
      <p><strong>Status:</strong> Initializing model parameters...</p>
      <p><strong>Started:</strong> ', format(Sys.time()), '</p>
    </div>
    <p>Live progress plots will appear here once the MCMC sampling begins.</p>
    <p><em>This page refreshes automatically every 3 seconds to show live updates.</em></p>
  </div>
</body>
</html>')

    writeLines(placeholder_html, file.path(model_dir, "results.html"))

    # Show notification
    if (useDefaults) {
      showNotification("Quick run started with default settings and AutoPriors. Live progress will appear below.",
                       type = "message", duration = 5)
    } else {
      showNotification("Model started. Live progress will appear in the viewer below.",
                       type = "message", duration = 5)
    }

    # Generate priors list for the current run
    current_priors <- if (useDefaults) {
      # Create priors based on default parameters
      idx <- StratoBayes:::.CreateIndices(data_api$stratData(), params$alignmentScale, params$sedModel, params$alphaPosition)
      structure(
        class = c("list", "StratPrior"),
        names = idx$names,
        lapply(idx$names, function(param) {
          x <- priorSettings[[param]]
          if (is.null(x)) {
            # Fallback to default Normal prior
            x <- list(priorType = "Normal", normalMean = 0, normalSD = 1)
          }
          switch(
            x$priorType,
            "Exponential" = ExponentialPrior(x$expRate),
#            "Gamma"       = GammaPrior(x$gammaAlpha, x$gammaBeta),
            "Normal"      = NormalPrior(x$normalMean, x$normalSD),
            "Uniform"     = UniformPrior(x$uniformMin, x$uniformMax)
          )
        })
      )
    } else {
      priors()
    }

    # Check if callr is available for async execution
    if (requireNamespace("callr", quietly = TRUE)) {

      # Run the model asynchronously using callr
      tryCatch({

        # Start the background R process
        process <- callr::r_bg(
          function(stratData, nRun, nIter, nThin, nChains, priors_list,
                   alignmentScale, sedModel, nKnots, model_dir, modelName) {

            # Load StratoBayes in the background process
            library(StratoBayes)

            # Set option to prevent browser opening
            options(StratoBayes.openBrowser = FALSE)

            # Run the model
            posterior <- RunStratModel(
              stratObject    = stratData,
              nRun           = nRun,
              nIter          = nIter,
              nThin          = nThin,
              nChains        = nChains,
              priors         = priors_list,
              alignmentScale = alignmentScale,
              sedModel       = sedModel,
              nKnots         = nKnots,
              runParallel    = TRUE,
              visualise      = list(interval = 50, signal = 1:3, parameter = 1), # More frequent updates
              modelDir       = file.path(model_dir, ""),
              modelName      = modelName
            )

            return(posterior)
          },
          args = list(
            stratData      = data_api$stratData(),
            nRun           = params$nRun,
            nIter          = params$nIter,
            nThin          = params$nThin,
            nChains        = params$nChains,
            priors_list    = current_priors,
            alignmentScale = params$alignmentScale,
            sedModel       = params$sedModel,
            nKnots         = params$nKnots,
            model_dir      = model_dir,
            modelName      = thisModelName
          ),
          supervise = TRUE
        )

        # Store the process so we can check on it
        modelProcess(process)

        showNotification("Background model process started successfully.", type = "message")

      }, error = function(e) {
        modelRunning(FALSE)
        showNotification(paste("Error starting background process:", e$message), type = "error")
      })

    } else {

      # Fallback to synchronous execution if callr not available
      showNotification("callr package not available. Running synchronously (UI will be blocked).",
                       type = "warning", duration = 10)

      tryCatch({
        posterior <- RunStratModel(
          stratObject    = data_api$stratData(),
          nRun           = params$nRun,
          nIter          = params$nIter,
          nThin          = params$nThin,
          nChains        = params$nChains,
          priors         = current_priors,
          alignmentScale = params$alignmentScale,
          sedModel       = params$sedModel,
          nKnots         = params$nKnots,
          runParallel    = TRUE,
          visualise      = list(interval = 100, signal = 1:3, parameter = 1),
          modelDir       = file.path(model_dir, ""),
          modelName      = thisModelName
        )

        r$alignment <- posterior
        modelRunning(FALSE)

        # Create a final success page
        final_results_path <- file.path(model_dir, "results.html")
        if (!file.exists(final_results_path)) {
          success_html <- paste0('<!doctype html>
        <html><head><meta charset="utf-8"><title>StratoBayes Complete</title>
        <style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
        .container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
        .success{background:#d4edda;border:1px solid #c3e6cb;color:#155724;padding:15px;border-radius:4px;margin:10px 0;}
        </style></head>
        <body><div class="container">
        <div class="success">
        <h2>✅ Model Run Complete</h2>
        <p><strong>Model:</strong> ', thisModelName, '</p>
        <p><strong>Completed:</strong> ', format(Sys.time()), '</p>
        <p>Results have been loaded into the application. You can now view alignment results in other tabs.</p>
        </div></div></body></html>')
          writeLines(success_html, final_results_path)
        }

        showNotification("Model completed successfully! Results are now available.",
                         type = "message", duration = 10)

        # Close any open modals after successful completion
        removeModal()

      }, error = function(e) {
        modelRunning(FALSE)

        # Create error page
        error_html <- paste0('<!doctype html>
      <html><head><meta charset="utf-8"><title>StratoBayes Error</title>
      <style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
      .container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
      .error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24;padding:15px;border-radius:4px;}
      </style></head>
      <body><div class="container">
      <div class="error">
      <h2>❌ Model Run Failed</h2>
      <p><strong>Error:</strong> ', as.character(e$message), '</p>
      <p><strong>Time:</strong> ', format(Sys.time()), '</p>
      </div></div></body></html>')
        writeLines(error_html, file.path(model_dir, "results.html"))

        showNotification(paste("Model run failed:", e$message), type = "error", duration = 15)
      })
    }
  }

  # Add this observer to check on the background process
  observe({
    invalidateLater(1000, session) # Check every second

    process <- modelProcess()
    if (!is.null(process) && modelRunning()) {

      # Check if process is still running
      if (process$is_alive()) {
        # Process still running - the iframe refresh will handle showing updates
        return()
      }

      # Process finished - get the result
      tryCatch({
        exit_status <- process$get_exit_status()
        if (is.null(exit_status)) {
          # Process might still be finishing up
          return()
        }

        if (exit_status == 0) {
          # Success - try to get result
          result <- tryCatch({
            process$get_result()
          }, error = function(e) {
            # If get_result fails, try to load from saved files
            model_dir <- file.path(model_base, modelNameRV())
            if (dir.exists(model_dir)) {
              tryCatch({
                StratPosterior(readDir = model_dir, modelName = modelNameRV())
              }, error = function(e2) {
                NULL
              })
            } else {
              NULL
            }
          })

          if (!is.null(result)) {
            r$alignment <- result
            modelRunning(FALSE)
            modelProcess(NULL)

            # Create a final success page
            model_dir <- file.path(model_base, modelNameRV())
            final_results_path <- file.path(model_dir, "results.html")
            if (!file.exists(final_results_path)) {
              success_html <- paste0('<!doctype html>
            <html><head><meta charset="utf-8"><title>StratoBayes Complete</title>
            <style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
            .container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
            .success{background:#d4edda;border:1px solid #c3e6cb;color:#155724;padding:15px;border-radius:4px;margin:10px 0;}
            </style></head>
            <body><div class="container">
            <div class="success">
            <h2>✅ Model Run Complete</h2>
            <p><strong>Model:</strong> ', modelNameRV(), '</p>
            <p><strong>Completed:</strong> ', format(Sys.time()), '</p>
            <p>Results have been loaded into the application. You can now view alignment results in other tabs.</p>
            </div></div></body></html>')
              writeLines(success_html, final_results_path)
            }

            showNotification("Model completed successfully! Results are now available.",
                             type = "message", duration = 10)

            # Close any open modals after successful completion
            removeModal()
          } else {
            # Couldn't retrieve result but process succeeded
            modelRunning(FALSE)
            modelProcess(NULL)
            showNotification("Model process completed but results could not be retrieved. Check the model directory for output files.",
                           type = "warning", duration = 15)
          }
        } else {
          # Error - process failed
          error_msg <- tryCatch({
            process$get_result()
          }, error = function(e) {
            # Try to read error from log files
            model_dir <- file.path(model_base, modelNameRV())
            error_files <- list.files(model_dir, pattern = "*error*.txt", full.names = TRUE)
            if (length(error_files) > 0) {
              paste(readLines(error_files[1], warn = FALSE), collapse = "\n")
            } else {
              paste("Process exited with status", exit_status)
            }
          })

          modelRunning(FALSE)
          modelProcess(NULL)

          # Create error page
          model_dir <- file.path(model_base, modelNameRV())
          error_html <- paste0('<!doctype html>
        <html><head><meta charset="utf-8"><title>StratoBayes Error</title>
        <style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
        .container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
        .error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24;padding:15px;border-radius:4px;}
        </style></head>
        <body><div class="container">
        <div class="error">
        <h2>❌ Model Run Failed</h2>
        <p><strong>Error:</strong> ', as.character(error_msg), '</p>
        <p><strong>Time:</strong> ', format(Sys.time()), '</p>
        </div></div></body></html>')
          writeLines(error_html, file.path(model_dir, "results.html"))

          showNotification(paste("Model run failed:", as.character(error_msg)), type = "error", duration = 15)
        }

      }, error = function(e) {
        modelRunning(FALSE)
        modelProcess(NULL)
        showNotification(paste("Error retrieving model results:", e$message), type = "error", duration = 15)
      })
    }
  })

  # Quick run with default settings - runs like normal model
  QuickRun <- function() {
    # Run the model with defaults
    Align(useDefaults = TRUE)
  }

  observeEvent(input$align,       { Align() })
  observeEvent(input$alignModal,  { Align() })
  observeEvent(input$setupRun,    { showModal(runModal()) })
  observeEvent(input$setupRunModal, { showModal(runModal()) })

  selectedAlignment <- reactive({
    req(r$alignment)
    sel <- input$alnToShow
    if (is.null(sel) || sel=="") return(1L)
    if (sel == "unassigned") return(0L)
    val <- as.integer(sel)
    if (is.na(val) || !(val %in% r$alignment$stratCluster$clustUnique)) {
      return(r$alignment$stratCluster$clustUnique[1])
    }
    val
  })

  stratCluster <- reactive({
    req(r$alignment)
    runs <- StratoBayes:::.ValidateRunSelect("all", r$alignment$nRun)
    StratoBayes:::.ClusterInternal(r$alignment,
                                   burnIn      = input$posteriorBurn/100,
                                   iterations  = NULL,
                                   maxSamples  = 2000,
                                   runSelect   = runs,
                                   selectRows  = NULL
    )
  })

  # Function to restore custom alpha values (for loading saved settings)
  restoreCustomAlphaValues <- function(values) {
    if (!is.null(values) && length(values) > 0) {
      isLoadingSettings(TRUE)
      storedCustomAlphaValues(values)
      # Reset flag after a short delay
      shinyjs::delay(500, {
        isLoadingSettings(FALSE)
      })
    }
  }

  list(
    indices      = indices,
    priors       = priors,
    alignment    = reactive(r$alignment),
    stratCluster = stratCluster,
    modelNameRV  = modelNameRV,
    mountId      = mountId,
    selectedAlignment = selectedAlignment,
    Align        = Align,
    QuickRun     = QuickRun,
    storedCustomAlphaValues = reactive(storedCustomAlphaValues()),
    restoreCustomAlphaValues = restoreCustomAlphaValues
  )
}

# helper
.map_prior <- function(p) {
  a <- p$args; cls <- class(p)[1]
  switch(
    cls,
    "UniformPrior"     = list(priorType="Uniform",     uniformMin=a$min,  uniformMax=a$max),
    "NormalPrior"      = list(priorType="Normal",      normalMean=a$mean, normalSD=a$sd),
    "ExponentialPrior" = list(priorType="Exponential", expRate=a$rate),
#    "GammaPrior"       = list(priorType="Gamma",       gammaAlpha=a$shape, gammaBeta=a$rate),
    list(priorType="Custom", object=p, class=cls)  # don't downgrade to Uniform
  )
}


.get_or <- function(x, or = NULL) if (is.null(x) || (length(x) == 1 && is.na(x))) or else x

`%||%` <- function(x, y) if (is.null(x)) y else x
