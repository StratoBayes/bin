test_that("modelName unable to name a run's files is refused (#2523)", {
  td <- withr::local_tempdir()
  for (bad in list(".m", "", NA_character_, c("a", "b"), 1)) {
    expect_error(
      RunStratModel(stratData1, stratModel1, nIter = 10, nChains = 1L,
                    nThreads = 1L, quiet = TRUE, visualise = FALSE,
                    modelDir = td, modelName = bad),
      "modelName"
    )
  }
  expect_length(list.files(td, all.files = TRUE, no.. = TRUE), 0L)
})

test_that("StratData() refuses a matrix cleanly (#2523)", {
  expect_error(StratData(as.matrix(signalData1)), "data.frame|data frame")
  expect_no_error(StratData(signalData1))
})

test_that("maxPointsPerSite must be a whole number (#2523)", {
  expect_error(StratData(signalData1, maxPointsPerSite = 2.5), "whole number")
  expect_no_error(StratData(signalData1, maxPointsPerSite = 50))
})

test_that("StratData() reports exact duplicate signal rows (#2523)", {
  expect_message(StratData(rbind(signalData1, signalData1)),
                 "duplicate row")
  expect_no_message(StratData(signalData1))
})

test_that("StratModel() warns when nKnots exceeds the observations (#2523)", {
  Model <- function(nKnots) {
    StratModel(stratData1, alignmentScale = "height", sedModel = "site",
               nKnots = nKnots)
  }
  expect_warning(Model(100), "nKnots")
  expect_no_warning(Model(5))
})

test_that("`runs` must be whole numbers (#2523)", {
  for (bad in list(1.7, TRUE, "a", 1.2)) {
    expect_error(.ValidateRunSelect(bad, 3L), "whole numbers")
  }
  expect_identical(.ValidateRunSelect(2, 3L), 2L)
  expect_identical(.ValidateRunSelect("all", 3L), 1:3)
})

test_that("NormalToLogNormal() keeps precision or refuses (#2523)", {
  res <- NormalToLogNormal(1, 1e-9)
  expect_gt(res$sigma, 0)
  expect_equal(res$sigma, 1e-9, tolerance = 1e-6)
  expect_error(NormalToLogNormal(1, 1e300), "too extreme")
  expect_error(NormalToLogNormal(1e-200, 1), "too extreme")
})

test_that("TruncLogNormDensity() validates its parameters (#2523)", {
  expect_error(TruncLogNormDensity(1, sdlog = 0), "sdlog")
  expect_error(TruncLogNormDensity(1, sdlog = -1), "sdlog")
  expect_error(TruncLogNormDensity(1, min = c(0, 1)), "'min'")
  expect_no_error(TruncLogNormDensity(1, min = 0.5, max = 2))
})

test_that("BayesianSpline() warns about infinite observations (#2523)", {
  x <- seq(0, 1, length.out = 30)
  y <- sin(2 * pi * x)
  y[5] <- Inf
  expect_warning(
    BayesianSpline(x, y, nKnots = 5, nIter = 20),
    "infinite"
  )
})

test_that("AutoPrior() validates its scale arguments up front (#2523)", {
  for (bad in list(NA_real_, -1, "a", c(1, 2), 0)) {
    expect_error(AutoPrior(stratData1, zetaLog_sd = bad), "zetaLog_sd")
    expect_error(AutoPrior(stratData1, delta_rate = bad), "delta_rate")
  }
  expect_no_error(AutoPrior(stratData1, zetaLog_sd = 1, delta_rate = 2))
})

test_that("StratModelTemplate() suggests several runs and no nIter (#2533)", {
  template <- capture.output(suppressMessages(StratModelTemplate(stratData1)))
  code <- paste(template, collapse = "\n")
  expect_match(code, "nRun = 3", fixed = TRUE)
  expect_no_match(code, "nIter", fixed = TRUE)
})

test_that("a finite nIter stop without convergence says so (#2533)", {
  td <- withr::local_tempdir()
  expect_message(
    suppressWarnings(RunStratModel(
      stratData1, stratModel1, nIter = 60L, nChains = 1L, seed = 2,
      nThreads = 1L, quiet = FALSE, visualise = FALSE, modelDir = td,
      modelName = "nconv"
    )),
    "without meeting the convergence criteria"
  )
})

test_that("a timeLimit stop without convergence says so (#2533)", {
  td <- withr::local_tempdir()
  expect_message(
    suppressWarnings(RunStratModel(
      stratData1, stratModel1, nIter = Inf, timeLimit = 1e-4, nChains = 1L,
      seed = 2, nThreads = 1L, quiet = FALSE, visualise = FALSE,
      modelDir = td, modelName = "tlim"
    )),
    "`timeLimit` without meeting the convergence criteria"
  )
})

.TiesWithoutCallbackFixture <- function(tieSite) {
  set.seed(1)
  h1 <- seq(0, 10, length.out = 60L)
  h2 <- seq(0, 6, length.out = 40L)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(60, 0, 0.1)),
    data.frame(site = "s2", height = h2,
               value = sin(h2 + 1) + rnorm(40, 0, 0.1))
  )
  ties <- data.frame(height = 3, site = tieSite, densityFun = "dnorm",
                     arg1 = 2, arg2 = 3)
  stratData <- StratData(signal = signal, ties = ties, siteColumn = "site",
                         zColumn = "height", signalColumn = "value")
  stratModel <- StratModel(stratData, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "middle",
                           nKnots = 6, sigmaFixed = 1, flexibleKnots = FALSE,
                           knotRange = c(-15, 25))
  td <- withr::local_tempdir(.local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = stratModel, nIter = 10,
    nChains = 1L, seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "ties"
  ))
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- .PrepareLogPostArgs(model)
  if (is.null(model$.tiesDispatch))
    model$.tiesDispatch <- .BuildTiesDispatch(result$data, model)
  mcmc <- readRDS(file.path(td, "ties_mcmc_run_1.rds"))
  list(data = result$data, model = model,
       args = list(data = result$data, model = model, mcmc = mcmc,
                   state = mcmc$recentState))
}

test_that(".sb_create_engine() refuses active ties without callback (#2526)", {
  skip_on_cran()
  fx <- .TiesWithoutCallbackFixture("s2")
  expect_error(do.call(.sb_create_engine, fx$args), "active ties")
  withCallback <- c(fx$args, list(
    tiesCallback = .MakeTiesCallback(fx$data, fx$model)
  ))
  expect_no_error(do.call(.sb_create_engine, withCallback))
})

test_that("a reference-site tie needs no callback on height scale (#2526)", {
  skip_on_cran()
  fx <- .TiesWithoutCallbackFixture("s1")
  expect_no_error(do.call(.sb_create_engine, fx$args))
})
