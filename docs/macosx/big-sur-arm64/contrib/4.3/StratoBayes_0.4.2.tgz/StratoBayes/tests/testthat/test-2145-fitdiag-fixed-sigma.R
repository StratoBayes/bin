test_that("sigma ratio and reference are NA under fixed sigma", {
  fixed <- stratPosterior1
  fixed[[c("model", "sdSpline")]] <- list(value = c(0.1, 0.2, 0.1))
  fd <- FitDiagnostics(fixed)
  expect_false(isFALSE(fixed[[c("model", "sigmaFixed")]]))
  expect_true(is.na(fd[[c("signals", "sigmaReference")]]))
  expect_true(is.na(fd[[c("signals", "sigmaRatio")]]))
  expect_true(fd[[c("general", "sigmaFixed")]])
  expect_output(print(fd), "Sigma is fixed")
  expect_false(any(grepl("noise floor", capture.output(print(fd)))))
})

test_that("the fixed-sigma caveat is absent under estimated sigma", {
  fd <- FitDiagnostics(stratPosterior3)
  expect_false(fd[[c("general", "sigmaFixed")]])
  expect_false(any(grepl("Sigma is fixed", capture.output(print(fd)))))
})
