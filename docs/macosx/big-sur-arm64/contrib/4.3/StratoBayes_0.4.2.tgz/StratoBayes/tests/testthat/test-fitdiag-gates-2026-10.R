GateMessages <- function(fit) {
  .FitGateMessages(fit[["general"]])
}

PlateauPosterior <- function(nPlateau = 3L) {
  sp <- stratPosterior4b
  nIter <- dim(sp[["samples"]])[[1]]
  level <- rep(seq_len(nPlateau), each = ceiling(nIter / nPlateau))
  sp[["samples"]][, "alpha_site1", 1, 1] <- 11 + 0.5 * level[seq_len(nIter)]
  sp
}

test_that("R-hat gate follows StratoBayes.rHatMax (#2414)", {
  withr::local_options(StratoBayes.rHatMax = 1.02)
  strict <- FitDiagnostics(stratPosterior4b, maxSamples = 60)
  expect_gt(strict[["general"]][["rhatMax"]], 1.02)
  expect_lt(strict[["general"]][["rhatMax"]], 1.05)
  expect_true(any(grepl("max R-hat .* > 1.02", GateMessages(strict))))

  withr::local_options(StratoBayes.rHatMax = 1.05)
  loose <- FitDiagnostics(stratPosterior4b, maxSamples = 60)
  expect_false(any(grepl("R-hat", GateMessages(loose))))
})

test_that("R-hat gate follows a persisted criterion (#2414)", {
  withr::local_options(StratoBayes.rHatMax = 1.5)
  sp <- stratPosterior4b
  sp[["mcmcSummary"]][["convergenceCriteria"]] <- list(list(rHat = 1.01))
  fit <- FitDiagnostics(sp, maxSamples = 60)
  expect_true(any(grepl("max R-hat .* > 1.01", GateMessages(fit))))
})

test_that("ESS gate names a badly mixed parameter (#2412)", {
  fit <- FitDiagnostics(PlateauPosterior(), maxSamples = 60, runs = 1)
  general <- fit[["general"]]
  expect_gte(general[["multiESS"]], 100)
  expect_lt(general[["minESS"]], 100)
  expect_identical(general[["minESSParam"]], "alpha_site1")
  expect_true(any(grepl("'alpha_site1' has an effective sample",
                        GateMessages(fit))))
  expect_false(any(grepl("Multivariate ESS is only", GateMessages(fit))))
})

test_that("Unassessed statistic is named in the printout (#2396)", {
  fit <- FitDiagnostics(stratPosterior2, maxSamples = 60)
  fit[["sites"]][["pppDrift"]] <- NA
  fit[["sites"]][["pppScatter"]] <- 0.5
  fit[["sites"]][["pppOffset"]] <- 0.5
  out <- capture.output(print(fit))
  expect_true(any(grepl("drift could not be assessed", out)))
  expect_true(any(grepl("No site's residuals depart", out)))

  fine <- capture.output(print(FitDiagnostics(stratPosterior2,
                                              maxSamples = 60)))
  expect_false(any(grepl("could not be assessed", fine)))
})

test_that("maxSamples is validated centrally (#2397)", {
  bad <- list("a", "x", NA, NA_real_, NULL, numeric(0), -1, 0, 0.5, 50.5, TRUE)
  for (value in bad) {
    expect_error(FitDiagnostics(stratPosterior1, maxSamples = value),
                 "maxSamples", info = format(value))
    expect_error(ExtractParameters(stratPosterior1, maxSamples = value),
                 "maxSamples", info = format(value))
  }
  expect_error(summary(stratPosterior1, maxSamples = -1), "maxSamples")
  expect_error(summary(stratPosterior1, maxSamples = "x"), "maxSamples")
  expect_no_error(ExtractParameters(stratPosterior1, maxSamples = Inf))
})

test_that("Cluster refuses an invalid maxSamples (#2397)", {
  expect_error(Cluster(stratPosterior1, maxSamples = -1), "maxSamples")
})

test_that("Fractional signal index is refused (#2397)", {
  expect_error(FitDiagnostics(stratPosterior2, signal = 1.7), "whole")
  expect_error(FitDiagnostics(stratPosterior2, signal = 0.5))
})

test_that("An empty run's zero budget is not a maxSamples error (#2397)", {
  expect_no_error(.ClusterRows(list(1:5000, NULL, 1:3000), cap = 5))
  expect_error(.maxSampleDeterministicRows(list(1:10), 0), "maxSamples")
})
