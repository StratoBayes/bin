# The sampling loop starts at iteration 2, so a first adaptation checkpoint at
# iteration 1 was never reached and the proposals adapted only once, at
# `endAdapting`.
test_that("startAdapting = 1 adapts the proposals on a fresh run (#2470)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  Adapted <- function(startAdapting, gradientProposals) {
    td <- withr::local_tempdir()
    set.seed(2470)
    suppressWarnings(RunStratModel(
      stratObject = stratData1, stratModel = stratModel1,
      nIter = 200, startAdapting = startAdapting, endAdapting = 150,
      convergenceStop = FALSE, nChains = 1, quiet = TRUE, visualise = FALSE,
      runParallel = FALSE, nThreads = 1L, modelDir = td, modelName = "sa",
      gradientProposals = gradientProposals
    ))
    readRDS(file.path(td, "sa_mcmc_run_1.rds"))[["metro"]]
  }

  # Iteration 1 is the starting state, so the two schedules are the same run.
  for (gradientProposals in c("off", "on")) {
    fromOne <- Adapted(1L, gradientProposals)
    fromTwo <- Adapted(2L, gradientProposals)
    expect_gt(fromOne[["probUpdateCount"]], 10L)
    expect_equal(fromOne[["probUpdateCount"]], fromTwo[["probUpdateCount"]])
    expect_equal(fromOne[["proposalArgs"]], fromTwo[["proposalArgs"]])
  }
  expect_lt(fromOne[["proposalArgs"]][[1]][["NUTS"]][["stepSize"]], 1)
})
