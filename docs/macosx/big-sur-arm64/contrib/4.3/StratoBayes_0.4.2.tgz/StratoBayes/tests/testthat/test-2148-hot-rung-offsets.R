# #2148: like lambda and sigma (#2227), the signal offsets delta and their scale
# tau are in the beta-marginal energy that the replica swap exchanges, so a
# hot rung must draw them from Pi_T rather than from their T = 1 conditionals.

test_that("default tempering keeps pinned offsets' posterior spread", {
  skip_on_cran()
  # A fixed tau far below the data's resolution pins delta to its prior, so
  # each offset's cold sd is known: tau * sqrt(1 - 1 / G) under the sum-zero
  # constraint. Untempered hot draws left it about 4% narrow.
  signal <- stratData1[["signal"]]
  siteColumn <- stratData1[["siteColumn"]]
  sites <- unique(signal[[siteColumn]])
  group <- data.frame(sites, paste0("g", seq_along(sites)))
  names(group) <- c(siteColumn, "group")
  data <- StratData(signal = signal, group = group)
  tau <- 0.001
  set.seed(2148)
  model <- suppressWarnings(StratModel(
    data, priors = stratPrior1, alignmentScale = "height", sedModel = "site",
    alphaPosition = "bottom", nKnots = 15, signalOffsets = TRUE,
    offsetPriorScale = tau, sigmaFixed = TRUE
  ))
  result <- suppressWarnings(RunStratModel(
    data, model, nIter = 40000L, nChains = 8L, temperingComponents = "full",
    nThreads = 1L, seed = 2148, runParallel = FALSE, convergenceStop = FALSE,
    quiet = TRUE, visualise = FALSE
  ))
  samples <- result[["samples"]]
  deltaCols <- grep("^delta", dimnames(samples)[[2]], value = TRUE)
  expect_length(deltaCols, length(sites))
  kept <- -seq_len(dim(samples)[[1]] %/% 2)
  spread <- apply(samples[kept, deltaCols, 1, 1, drop = FALSE], 2, sd)
  expect_lt(abs(mean(spread) / (tau * sqrt(1 - 1 / length(sites))) - 1), 0.02)
})

test_that("default tempering keeps a free offset scale's prior spread", {
  skip_on_cran()
  # With sigma fixed far above the data's spread, the offsets carry no
  # information, so tau^2 keeps its InvGamma(1, bTau) prior: log tau has mean
  # (log(bTau) - digamma(1)) / 2 and sd pi / sqrt(24). Untempered hot draws
  # gave an sd about 14% narrow and a mean about 0.13 low.
  signal <- stratData1[["signal"]]
  siteColumn <- stratData1[["siteColumn"]]
  sites <- unique(signal[[siteColumn]])
  group <- data.frame(sites, paste0("g", seq_along(sites)))
  names(group) <- c(siteColumn, "group")
  data <- StratData(signal = signal, group = group)
  set.seed(2148)
  model <- suppressWarnings(StratModel(
    data, priors = stratPrior1, alignmentScale = "height", sedModel = "site",
    alphaPosition = "bottom", nKnots = 15, signalOffsets = TRUE,
    sigmaFixed = 1000
  ))
  result <- suppressWarnings(RunStratModel(
    data, model, nIter = 40000L, nChains = 8L, temperingComponents = "full",
    nThreads = 1L, seed = 2148, runParallel = FALSE, convergenceStop = FALSE,
    quiet = TRUE, visualise = FALSE
  ))
  samples <- result[["samples"]]
  tauCol <- grep("^tau", dimnames(samples)[[2]], value = TRUE)
  expect_length(tauCol, 1L)
  kept <- -seq_len(dim(samples)[[1]] %/% 2)
  logTau <- log(samples[kept, tauCol, 1, 1])
  expect_lt(abs(sd(logTau) / (pi / sqrt(24)) - 1), 0.05)
  bTau <- unname(model[[c("offsetConfig", "bTau")]])
  expect_lt(abs(mean(logTau) - (log(bTau) - digamma(1)) / 2), 0.05)
})
