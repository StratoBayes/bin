# #2527: sedSmooth on the age scale started, and converted its setup ages, at
# one age unit per height unit, whatever the units. #521: the age-scale
# auto knotRange ignored the ties. #2528: ties whose ages increase upward
# were accepted on the age scale.

# vignette "Age-models" configuration, with ages multiplied by `ageScale`
AgeTies <- function(ageScale = 1, means = c(12, 10)) {
  data.frame(site = c("site1", "site1"), height = c(2.5, 6.5) * pi,
             mean = means * ageScale, sd = c(0.1, 0.05) * ageScale)
}

AgeData <- function(ageScale = 1, means = c(12, 10)) {
  StratData(signalData4, ties = AgeTies(ageScale, means), parts = partsData4)
}

AgeModel <- function(ageScale = 1, flexibleKnots = TRUE, sedSmooth = TRUE,
                     alpha = NormalPrior(mean = 11 * ageScale,
                                         sd = ageScale),
                     means = c(12, 10)) {
  logRate <- log(4 * pi / 2 / ageScale)
  priors <- structure(
    list(
      "alpha_site1" = alpha,
      "alpha_site2" = alpha,
      "gammaLog_partition site 1" = NormalPrior(mean = logRate, sd = 1),
      "gammaLog_bottom part., site 2" = NormalPrior(mean = logRate, sd = 1),
      "gammaLog_top part., site 2" = NormalPrior(mean = logRate, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 1 / ageScale)
    ),
    class = c("StratPrior", "list")
  )
  suppressWarnings(suppressMessages(
    StratModel(AgeData(ageScale, means), priors, alignmentScale = "age",
               sedModel = "partition",
               alphaPosition = c(4.5 * pi, "middle"), nKnots = 15,
               flexibleKnots = flexibleKnots, sedSmooth = sedSmooth)
  ))
}

test_that("sedSmooth starts at the ties' rate on the age scale (#2527)", {
  model <- AgeModel(1000)
  info <- model[["sedSmoothInfo"]]
  # ties 2000 ka apart over 4 pi m
  expect_equal(info[["startLogInvRate"]],
               rep(log(2000 / (4 * pi)), info[["nFormations"]]))
  sedBeta <- .InitializeSedBeta(info, NULL, NULL)
  # B-splines sum to one, so the start is a constant rate in each formation
  form <- info[["formations"]][[1]]
  heights <- seq(form[["hLow"]], form[["hHigh"]], length.out = 7)
  expect_equal(.SedSplineRate(sedBeta, info, 1L, heights),
               rep(2000 / (4 * pi), 7))
})

test_that("age-scale sedSmooth setup scales with the age units (#2527)", {
  fixedMa <- AgeModel(1, flexibleKnots = FALSE)
  fixedKa <- AgeModel(1000, flexibleKnots = FALSE)
  expect_equal(fixedKa[[c("splineBase", "knotRange")]],
               1000 * fixedMa[[c("splineBase", "knotRange")]])
  # as the constant-rate model, whose gammaLog priors match the ties
  expect_equal(
    fixedKa[[c("splineBase", "knotRange")]],
    AgeModel(1000, flexibleKnots = FALSE,
             sedSmooth = FALSE)[[c("splineBase", "knotRange")]]
  )

  flexMa <- AgeModel(1)
  flexKa <- AgeModel(1000)
  expect_equal(flexKa[[c("splineBase", "ageSpan")]],
               1000 * flexMa[[c("splineBase", "ageSpan")]])
})

test_that("an age-scale sedSmooth run in ka reaches its ties (#2527)", {
  set.seed(1)
  model <- AgeModel(1000)
  mcmc <- StratMCMC(model, nChains = 4, nIter = 1000, nThreads = 1L)
  posterior <- suppressWarnings(
    RunStratModel(AgeData(1000), model, mcmc, visualise = FALSE,
                  quiet = TRUE, runParallel = FALSE, nThreads = 1L)
  )
  ages <- StratMap(posterior, heights = c(2.5, 6.5) * pi,
                   site = "site1")[["50%"]]
  # the ties are 2000 ka apart; a start at 1 ka/m held them a few hundred
  # ka apart
  expect_gt(ages[[1]] - ages[[2]], 1500)
})

test_that("the age-scale auto knotRange covers the ties (#521)", {
  # a vague alpha prior puts the converted ages, but not the ties, at 12..19
  model <- AgeModel(1, flexibleKnots = FALSE, sedSmooth = FALSE,
                    alpha = UniformPrior(0, 30))
  knotRange <- model[[c("splineBase", "knotRange")]]
  expect_lt(knotRange[[1]], 10)
  expect_gt(knotRange[[2]], 12)
  expect_message(
    StratModel(AgeData(), model[[c("priors", "metro")]],
               alignmentScale = "age", sedModel = "partition",
               alphaPosition = c(4.5 * pi, "middle"), nKnots = 15,
               flexibleKnots = FALSE),
    "and the tie ages"
  )
})

test_that("ages increasing upward are refused on the age scale (#2528)", {
  expect_error(AgeModel(means = c(-12, -10)), "ages must decrease upward")
  expect_error(AgeModel(means = c(10, 12), sedSmooth = FALSE),
               "site 'site1'.*combined standard deviations")
  # within three combined standard deviations is left to the likelihood
  expect_s3_class(AgeModel(means = c(10, 10.3), sedSmooth = FALSE),
                  "StratModel")
})

test_that("a disabled tie is neither checked nor used (#2528, #2527)", {
  # the middle tie is an outlier, older than the one below it
  ties <- AgeTies()[c(1, 1, 2), ]
  ties[["height"]] <- c(2.5, 4.5, 6.5) * pi
  ties[["mean"]] <- c(12, 13, 10)
  data <- StratData(signalData4, ties = ties, parts = partsData4)
  priors <- AgeModel(sedSmooth = FALSE)[[c("priors", "metro")]]
  Build <- function(...) {
    suppressWarnings(suppressMessages(
      StratModel(data, priors, alignmentScale = "age",
                 sedModel = "partition", alphaPosition = c(4.5 * pi, "middle"),
                 nKnots = 15, sedSmooth = TRUE, ...)
    ))
  }
  expect_error(Build(), "ages must decrease upward")
  model <- Build(disableTies = list(site1 = 2))
  expect_equal(model[[c("sedSmoothInfo", "startLogInvRate")]][[1]],
               log(2 / (4 * pi)))
})

test_that("sedSmooth start rate without a tie pair, or out of range", {
  info <- list(formToSite = c(1L, 2L, 2L))
  siteTies <- .SiteTieAges(AgeData())
  expect_equal(.SedSmoothStartRate(siteTies, info, "height"), c(0, 0, 0))
  # site 2 has no ties, so takes site 1's rate
  expect_equal(.SedSmoothStartRate(siteTies, info, "age"),
               rep(log(2 / (4 * pi)), 3))
  expect_equal(.SedSmoothStartRate(siteTies, info, "age", c(2, 14)),
               rep(-2, 3))

  oneTie <- StratData(signalData4, ties = AgeTies()[1, ], parts = partsData4)
  expect_message(
    expect_equal(.SedSmoothStartRate(.SiteTieAges(oneTie), info, "age"),
                 c(0, 0, 0)),
    "no site has ties at two heights"
  )
  # the user's gammaLog priors stand in for a tie pair, and the start is held
  # within ratesRange whichever way it is found
  expect_equal(.SedSmoothStartRate(.SiteTieAges(oneTie), info, "age",
                                   rateMedians = c(1, 2, 3)), rep(-2, 3))
  expect_equal(.SedSmoothStartRate(NULL, info, "height", c(1, 14)),
               rep(-1, 3))
  # ages increasing upward, within three standard deviations
  reversed <- .SiteTieAges(AgeData(means = c(10, 10.1)))
  expect_message(.SedSmoothStartRate(reversed, info, "age"),
                 "ages decrease upward")
})

test_that("one tie per site takes the rate from the gammaLog priors (#2527)", {
  ties <- AgeTies(1000)[1, ]
  data <- StratData(signalData4, ties = ties, parts = partsData4)
  priors <- AgeModel(1000, sedSmooth = FALSE)[[c("priors", "metro")]]
  model <- suppressWarnings(suppressMessages(
    StratModel(data, priors, alignmentScale = "age", sedModel = "partition",
               alphaPosition = c(4.5 * pi, "middle"), nKnots = 15,
               sedSmooth = TRUE)
  ))
  expect_equal(model[[c("sedSmoothInfo", "startLogInvRate")]],
               rep(log(2000 / (4 * pi)), 3))
})

test_that("a vague tie barely moves the start rate", {
  ties <- AgeTies()[c(1, 2, 2), ]
  ties[3, c("height", "mean", "sd")] <- c(7.5 * pi, 0, 100)
  siteTies <- .SiteTieAges(
    StratData(signalData4, ties = ties, parts = partsData4)
  )
  expect_equal(.TieLogInverseRate(siteTies)[[1]], log(2 / (4 * pi)),
               tolerance = 1e-4)
})

test_that("the tie-order check allows for the number of ties (#2528)", {
  Ties <- function(age, spread = 1) {
    data.frame(index = seq_along(age), height = seq_along(age), age = age,
               spread = spread)
  }
  # 3.5 combined sd out of order: refused as a lone pair...
  pair <- Ties(c(0, 3.5 * sqrt(2)))
  expect_error(.CheckTieAgeOrder(list(pair), "s"), "tie 2 \\(age")
  # ...but chance among the 45 pairs of ten ties
  ten <- Ties(c(0, 3.5 * sqrt(2), -(1:8) * 10))
  expect_null(.CheckTieAgeOrder(list(ten), "s"))
  # and ties without a spread are not judged
  expect_null(.CheckTieAgeOrder(list(Ties(c(0, 100), NA)), "s"))
})
