ReadRdText <- function(rdName) {
  rdFile <- testthat::test_path("..", "..", "man", rdName)
  if (file.exists(rdFile)) {
    text <- paste(readLines(rdFile, warn = FALSE), collapse = "\n")
  } else {
    skip_if_not_installed("StratoBayes")
    db <- tools::Rd_db("StratoBayes")
    key <- grep(paste0("^", gsub(".", "\\.", rdName, fixed = TRUE), "$"),
                names(db), value = TRUE)
    skip_if(length(key) == 0, paste(rdName, "not in the installed Rd db"))
    text <- paste(suppressWarnings(
      capture.output(tools::Rd2txt(db[[key[[1]]]], out = stdout()))
    ), collapse = "\n")
  }
  gsub("\\s+", " ", text)
}

AgesOf <- function(params, heights, p) {
  StratoBayes:::.AgeConversionBatch(
    as.matrix(params), heights, 2, p$data, p$model$ind
  )
}

test_that("#2610: log terms come back under their internal names", {
  data(stratPosterior1, package = "StratoBayes")
  ep <- ExtractParameters(
    stratPosterior1,
    parameters = c("alpha_site_2", "log posterior")
  )
  expect_identical(colnames(ep), c("alpha_site_2", "posterior"))
  expect_null(ep[["log posterior"]])
})

test_that("#2610: ?ExtractParameters documents the returned names", {
  rdText <- ReadRdText("ExtractParameters.Rd")
  expect_match(rdText, "the returned column drops the", fixed = TRUE)
  expect_match(rdText, "Column names are the stored parameter names",
               fixed = TRUE)
})

test_that("#2613: StratMap() samples follow ascending run order", {
  data(stratPosterior1, package = "StratoBayes")
  p <- stratPosterior1
  h0 <- SignalLookUp(p$data, "height", 2)
  h <- seq(min(h0), max(h0), length.out = 3)
  sm <- as.matrix(
    StratMap(p, h, p$data$sites[2], runs = c(3, 1), quantiles = "samples")[, -1]
  )
  ascending <- AgesOf(ExtractParameters(p, "parameters", runs = c(1, 3)), h, p)
  requested <- AgesOf(ExtractParameters(p, "parameters", runs = c(3, 1)), h, p)
  expect_true(all(abs(sm[2, ] - ascending[2, ]) < 1e-8))
  expect_false(all(abs(sm[2, ] - requested[2, ]) < 1e-8))
})

test_that("#2613: StratMap() and Tops() docs state the sample-column order", {
  for (rd in c("StratMap.Rd", "Tops.Rd")) {
    expect_match(ReadRdText(rd), "ascending run order", fixed = TRUE,
                 info = rd)
  }
})

test_that("#2615: SedSmooth-technical no longer calls the quadrature exact", {
  path <- testthat::test_path("..", "..", "vignettes",
                              "SedSmooth-technical.qmd")
  skip_if_not(file.exists(path), "vignette source not available")
  text <- gsub("\\s+", " ", paste(readLines(path, warn = FALSE),
                                  collapse = "\n"))
  expect_false(grepl("quadrature is exact", text, fixed = TRUE))
  expect_match(text, "split into equal sub-cells", fixed = TRUE)
})
