test_that("loading and non-drawing exports leave no .Random.seed (#2050)",
          {
            # A fresh process is the only session guaranteed to have no seed;
            # this one has drawn already.
            libs <- paste(deparse(.libPaths()), collapse = "")
            script <- tempfile(fileext = ".R")
            on.exit(unlink(script), add = TRUE)
            writeLines(
              c(
                paste0(".libPaths(", libs, ")"),
                "Seeded <- function() exists('.Random.seed', globalenv(),",
                "                            inherits = FALSE)",
                "before <- Seeded()",
                "suppressMessages(loadNamespace('StratoBayes'))",
                "afterLoad <- Seeded()",
                "ns <- asNamespace('StratoBayes')",
                "invisible(ns$.sb_mat_vec_mult(diag(2), c(1, 2)))",
                "invisible(ns$.sb_qtnorm(0.5, -1, 1))",
                "invisible(ns$.sb_expired())",
                "cat(before, afterLoad, Seeded(), sep = ',')"
              ),
              script
            )
            out <- system2(
              file.path(R.home("bin"), "Rscript"),
              c("--vanilla", shQuote(script)),
              stdout = TRUE, stderr = TRUE
            )
            expect_identical(out[length(out)], "FALSE,FALSE,FALSE",
                             info = paste(out, collapse = "\n"))
          })
