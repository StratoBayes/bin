# signalData1 x 0.01 puts n * var(y) below 1, so the data-scaled bSigma
# default bites; at native scale it clips to 0.01 and cannot discriminate.
DerivedSigmaFixed <- function(k, nCopy, ...) {
  signal <- do.call(rbind, lapply(seq_len(nCopy), function(i) {
    copy <- signalData1
    copy[["site"]] <- paste0(copy[["site"]], "_copy", i)
    copy
  }))
  signal[["value"]] <- signal[["value"]] * k
  model <- StratModel(
    StratData(signal),
    nKnots = 5,
    alignmentScale = "height",
    sedModel = "site",
    ...
  )
  model[["sigmaFixed"]] / k
}

test_that("default fixed sigma does not grow with site count (#2522)", {
  set.seed(2522)
  one <- DerivedSigmaFixed(0.01, 1L)
  four <- DerivedSigmaFixed(0.01, 4L)
  native <- DerivedSigmaFixed(1, 1L)

  expect_equal(unname(four), unname(one), tolerance = 0.15)
  expect_lt(unname(one / native), 2)
  # A supplied rate still reaches the per-site fits.
  expect_gt(unname(DerivedSigmaFixed(0.01, 4L, bSigma = 0.01)), 1.5 * four)
})
