# #1064: a run can settle on a sedimentation rate that only its prior objects
# to -- six samples over 8.4 m stretched across 3 km -- and nothing said so.

rateChunks <- function(rates, chain = 1L) {
  rates <- as.matrix(rates)
  list(cbind(iteration = seq_len(nrow(rates)), chain = chain, rates))
}

ratePriors <- function(sd = log(2), sites = c("b", "c")) {
  stats::setNames(rep(list(NormalPrior(mean = 0, sd = sd)), length(sites)),
                  paste0("gammaLog_", sites))
}

WarnTail <- function(rates, priors = ratePriors(), scale = "height",
                     chain = 1L) {
  chunks <- rateChunks(rates, chain)
  .WarnSedRateTail(chunks, colnames(chunks[[1]]), 1L, priors, scale)
}

farOut <- -(.kSedRateTailSds + 1) * log(2)
withinTail <- -(.kSedRateTailSds - 1) * log(2)
nDraw <- 20L

test_that(".WarnSedRateTail names a stretched section and its stretch", {
  rates <- cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = 0)
  expect_warning(
    WarnTail(rates),
    sprintf(
      "1 fitted sedimentation rate lies.*b \\(gammaLog = %.2f, stretched x%.3g",
      farOut, exp(-farOut)
    )
  )
})

test_that(".WarnSedRateTail reports a squash and lists every flagged site", {
  rates <- cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = -farOut)
  expect_warning(WarnTail(rates),
                 "2 fitted sedimentation rates lie.*c \\(.*squashed to 1/")
})

test_that(".WarnSedRateTail is silent inside the prior's bulk", {
  rates <- cbind(gammaLog_b = rep(withinTail, nDraw), gammaLog_c = 0)
  expect_silent(WarnTail(rates))
})

test_that(".WarnSedRateTail reads the second half of the cold chain only", {
  escaped <- cbind(gammaLog_b = rep(c(farOut, 0), each = nDraw / 2),
                   gammaLog_c = 0)
  expect_silent(WarnTail(escaped))
  expect_silent(WarnTail(cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = 0),
                         chain = 2L))
})

test_that(".WarnSedRateTail judges any prior family by its quantiles", {
  # The same value is in the bulk of a wide prior and the tail of a narrow one.
  rates <- cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = 0)
  wide <- ratePriors(sd = 2 * abs(farOut))
  expect_silent(WarnTail(rates, wide))
  bounded <- wide
  bounded[["gammaLog_b"]] <- TruncNormalPrior(mean = 0, sd = log(2),
                                              lower = 2 * farOut, upper = 1)
  expect_warning(WarnTail(rates, bounded), "b \\(gammaLog")
})

test_that(".WarnSedRateTail skips a prior it cannot place", {
  rates <- cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = 0)
  noQuantile <- ratePriors()
  noQuantile[["gammaLog_b"]][["Q"]] <- function(p, ...) stop("no quantile")
  expect_silent(WarnTail(rates, noQuantile))
  missing <- ratePriors(sites = "c")
  expect_silent(WarnTail(rates, missing))
})

test_that(".WarnSedRateTail reports no stretch on the age scale", {
  rates <- cbind(gammaLog_b = rep(farOut, nDraw), gammaLog_c = 0)
  expect_warning(WarnTail(rates, scale = "age"),
                 sprintf("b \\(gammaLog = %.2f\\)\\.", farOut))
})

test_that("RunStratModel() hands .WarnSedRateTail the sampled rates' priors", {
  d <- StratData(signal = signalData1)
  m <- StratModel(d, alignmentScale = "height", sedModel = "site", nKnots = 8L)
  seen <- new.env()
  testthat::local_mocked_bindings(
    .WarnSedRateTail = function(chunks, colNames, run, priors, alignmentScale) {
      seen[["colNames"]] <- colNames
      seen[["priors"]] <- priors
      seen[["alignmentScale"]] <- alignmentScale
    },
    .package = "StratoBayes"
  )
  td <- withr::local_tempdir()
  RunStratModel(stratObject = d, stratModel = m, nIter = 10, nChains = 1L,
                seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
                modelDir = td, modelName = "t1064")
  rateNames <- grep("^gammaLog_", seen[["colNames"]], value = TRUE)
  expect_gt(length(rateNames), 0L)
  expect_true(all(vapply(seen[["priors"]][rateNames], inherits, logical(1),
                         "Prior")))
  expect_identical(seen[["alignmentScale"]], "height")
})
