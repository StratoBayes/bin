# An unbounded run ends adaptation when the cold chain's log posterior stops
# trending (port of MkPrime's `.CheckStabilisation()`), rather than at a fixed
# 2000 iterations that froze proposals tuned to a chain still burning in.

StableFeed <- function(lp, startIter = 1, every = 100) {
  iters <- startIter - 1 + seq_along(lp) * every
  store <- .AdaptStableStore(startIter, posterior = 3L)
  mat <- cbind(iters, 1, lp)
  for (k in seq_along(lp)) {
    store <- .AdaptStableAppend(store, mat[k, , drop = FALSE], Inf)
    store <- .AdaptStableCheck(store)
    if (store[["freeze"]]) {
      return(list(store = store, at = iters[[k]]))
    }
  }
  list(store = store, at = NA)
}

test_that("a stationary log posterior freezes adaptation", {
  set.seed(1)
  out <- StableFeed(rnorm(400, -100))
  expect_true(out[["store"]][["freeze"]])
  # Two full windows of snapshots plus a streak, never sooner: the first
  # snapshot is taken in bin 0.
  minBin <- 2L * .kStableWindow + .kStableStreak - 2L
  expect_gt(out[["at"]], minBin * .kStableSnapIter)
})

test_that("a climbing log posterior keeps adapting", {
  set.seed(1)
  climb <- seq(-1000, -100, length.out = 400) + rnorm(400)
  expect_false(StableFeed(climb)[["store"]][["freeze"]])
})

test_that("one snapshot is taken per grid bin, whatever the save density", {
  # Every save in a bin but the first is ignored, so a denser save grid or
  # checkpoint schedule cannot inflate the streak.
  store <- .AdaptStableStore(1, posterior = 3L)
  iters <- seq(1, 3 * .kStableSnapIter, by = 10)
  store <- .AdaptStableAppend(store, cbind(iters, 1, -iters), Inf)
  expect_length(store[["lp"]], 3L)
  # Hot chains and draws past the window are not the cold chain's burn-in.
  store <- .AdaptStableAppend(
    store, cbind(4 * .kStableSnapIter, c(2, 1), 0), 3 * .kStableSnapIter
  )
  expect_length(store[["lp"]], 3L)
})

test_that("a checkpoint judges every snapshot it has not yet seen", {
  # MkPrime takes a verdict on every snapshot; a checkpoint arriving after
  # several must reach the same streak as one arriving after each.
  set.seed(2)
  lp <- rnorm(3L * .kStableWindow, -100)
  each <- .AdaptStableStore(1, posterior = 3L)
  for (k in seq_along(lp)) {
    each[["lp"]] <- lp[seq_len(k)]
    each <- .AdaptStableCheck(each)
    if (each[["freeze"]]) break
  }
  expect_true(each[["freeze"]])
  once <- .AdaptStableStore(1, posterior = 3L)
  once[["lp"]] <- lp[seq_len(k)]
  once <- .AdaptStableCheck(once)
  expect_identical(once[c("streak", "freeze")], each[c("streak", "freeze")])
})

test_that("a repeated checkpoint without a fresh snapshot is not a verdict", {
  set.seed(1)
  store <- StableFeed(rnorm(2L * .kStableWindow * 5L, -100),
                      every = .kStableSnapIter / 5)[["store"]]
  streak <- store[["streak"]]
  for (k in 1:5) store <- .AdaptStableCheck(store)
  expect_identical(store[["streak"]], streak)
})

test_that("out of support, or a missing draw, is never stable", {
  lp <- rep(-1e30, 400)
  expect_false(StableFeed(lp)[["store"]][["freeze"]])
  expect_false(.AdaptStableVerdict(c(NA, rep(-100, 2L * .kStableWindow - 1L)),
                                   2L * .kStableWindow))
})

test_that("an unbounded run keeps the nominal tuning cadence", {
  # Updates fall every 5% of the window; scaled to the ceiling they would be
  # an order of magnitude sparser just when early tuning matters.
  unbounded <- StratMCMC(stratModel1, nChains = 2)
  nominal <- StratMCMC(stratModel1, nChains = 2,
                       endAdapting = .kDefaultAdaptIter)
  expect_gt(unbounded[["endAdapting"]], nominal[["endAdapting"]])
  for (field in list(c("metro", "adaptProposalInterval"),
                     c("metro", "historyLength"),
                     c("temper", "adaptTemperaturesIntervall"))) {
    expect_identical(unbounded[[field]], nominal[[field]])
  }
  # A finite window still scales its own cadence.
  expect_gt(
    StratMCMC(stratModel1, nIter = 1e5,
              nChains = 2)[[c("metro", "adaptProposalInterval")]],
    nominal[[c("metro", "adaptProposalInterval")]]
  )
})

test_that("only an unbounded default window runs the detector", {
  expect_true(StratMCMC(stratModel1, nChains = 2)[["adaptStabilise"]])
  expect_false(StratMCMC(stratModel1, nIter = 1000,
                         nChains = 2)[["adaptStabilise"]])
  expect_false(StratMCMC(stratModel1, nChains = 2,
                         endAdapting = 5000)[["adaptStabilise"]])
})

RunUnbounded <- function(seconds, ...) {
  dir <- withr::local_tempdir(.local_envir = parent.frame())
  RunStratModel(stratData1, stratModel1, nChains = 2, nRun = 1, seed = 1,
                timeLimit = seconds / 3600, visualise = FALSE,
                nThreads = 1L, modelDir = dir, modelName = "s",
                convergenceStop = FALSE, ...)
  readRDS(file.path(dir, "s_mcmc_run_1.rds"))
}

test_that("a stationary chain ends an unbounded run's adaptation", {
  skip_on_cran()
  # The timer would otherwise usually fire first on this easy model.
  withr::local_options(StratoBayes.adaptTimerEss = 1e12)
  mcmc <- RunUnbounded(10, quiet = TRUE)
  expect_identical(mcmc[["adaptFreeze"]][["reason"]], "stable")
  expect_lt(mcmc[["endAdapting"]], .DefaultEndAdapting(Inf, 1))
  minBin <- 2L * .kStableWindow + .kStableStreak - 2L
  expect_gt(mcmc[["endAdapting"]], minBin * .kStableSnapIter)
})

test_that("half the time limit ends an unbounded run's adaptation", {
  skip_on_cran()
  withr::local_options(StratoBayes.adaptTimerEss = 1e12)
  local_mocked_bindings(.AdaptStableCheck = function(store) store)
  # A coarse save grid raises the store's ceiling far beyond what two
  # seconds can reach.
  mcmc <- RunUnbounded(2, quiet = TRUE, nThin = 100)
  expect_identical(mcmc[["adaptFreeze"]][["reason"]], "time")
})

test_that("reaching the ceiling, or stopping inside it, is reported", {
  skip_on_cran()
  withr::local_options(StratoBayes.adaptTimerEss = 1e12,
                       StratoBayes.maxStore = 2L * .kDefaultAdaptIter)
  local_mocked_bindings(.AdaptStableCheck = function(store) store)
  expect_message(RunUnbounded(5, quiet = FALSE), "ceiling")

  withr::local_options(StratoBayes.maxStore = .kMaxStoreDefault)
  expect_warning(RunUnbounded(1e-6, quiet = TRUE), "still adapting")
})
