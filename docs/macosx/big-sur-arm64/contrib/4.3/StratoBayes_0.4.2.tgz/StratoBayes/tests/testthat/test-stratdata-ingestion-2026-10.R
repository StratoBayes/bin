MakeSignal <- function() {
  data.frame(
    site = rep(c("s1", "s2", "s3"), each = 4),
    z = rep(1:4, 3),
    v = c(1, 2, 3, 4, 2, 3, 4, 5, 3, 4, 5, 6)
  )
}
Build <- function(group, ...) {
  StratData(signal = MakeSignal(), signalColumn = "v", siteColumn = "site",
            zColumn = "z", group = group, ...)
}

test_that("a group with no site is rejected (#1232)", {
  g <- c(s1 = "A", s2 = "B", s3 = "B", s4 = "C")
  expect_error(Build(g), "no site in the data: C")
  expect_error(
    Build(c(s1 = "A", s2 = "A", s3 = "B"), selectSites = c("s1", "s2")),
    "no site in the data: B.*selectSites"
  )
})

test_that("conflicting duplicate site rows are rejected (#1232)", {
  g <- data.frame(site = c("s1", "s1", "s2", "s3"),
                  group = c("A", "B", "A", "B"))
  expect_error(Build(g), "conflicting group labels: s1")
  same <- data.frame(site = c("s1", "s1", "s2", "s3"),
                     group = c("A", "A", "A", "B"))
  expect_equal(Build(same)[["groupAttr"]][["nGroups"]], 2L)
})

test_that("blank and padded group labels are handled (#2114)", {
  g <- data.frame(site = c("s1", "s2", "s3"), group = c("A", "  ", "B"))
  expect_error(Build(g), "blank group label for site\\(s\\): s2")
  padded <- data.frame(site = c("s1", "s2", "s3"), group = c("A", "A ", "B"))
  expect_equal(Build(padded)[["groupAttr"]][["groups"]], c("A", "B"))
})

test_that("group labels sort by radix (#2114)", {
  g <- c(s1 = "b", s2 = "B", s3 = "a")
  expect_equal(Build(g)[["groupAttr"]][["groups"]], c("B", "a", "b"))
})

test_that("parameter prefix matches respect a `_` boundary (#2114)", {
  nms <- c(paste0("alpha_site_", 1:11), "gammaLog_x", "gammaLog_y")
  expect_equal(nms[.PrefixMatch(nms, "alpha")], paste0("alpha_site_", 1:11))
  expect_equal(nms[.PrefixMatch(nms, "gammaLog")],
               c("gammaLog_x", "gammaLog_y"))
  expect_warning(m <- .PrefixMatch(nms, "alpha_site_1"), "several")
  expect_equal(nms[m], c("alpha_site_1", "alpha_site_10", "alpha_site_11"))
})

test_that(".ValidateRunSelect() rejects coercions (#2114)", {
  expect_error(.ValidateRunSelect(1.5, 3), "whole numbers")
  expect_error(.ValidateRunSelect(TRUE, 3), "whole numbers")
  expect_error(.ValidateRunSelect(c("all", 2), 3), "combine")
  expect_error(.ValidateRunSelect(c(2, "all"), 3), "combine")
  expect_equal(.ValidateRunSelect("all", 3), 1:3)
  expect_equal(.ValidateRunSelect(c(2, 3), 3), 2:3)
  expect_equal(.ValidateRunSelect("2", 3), 2L)
})

WriteLasWithDepth <- function(dir, name, depthName = "DEPT") {
  writeLines(c(
    "~Version Information", "VERS. 2.0: ", "WRAP. NO: ",
    "~Well Information Block", "STRT.M 100.0: ", "STOP.M 101.5: ",
    "STEP.M 0.5: ", "NULL. -999.25: ", "WELL. TEST: WELL",
    "~Curve Information Block",
    paste0(depthName, ".M : Depth"), "GR.GAPI : Gamma Ray",
    paste("~A", depthName, "GR"),
    sprintf("%.4f %.4f", seq(100, by = 0.5, length.out = 4), c(50, 60, 55, 70))
  ), file.path(dir, paste0(name, ".las")))
}

test_that("zColumn aliases apply only to depth mnemonics (#2366)", {
  skip_if_not_installed("SDAR")
  dir <- withr::local_tempdir()
  WriteLasWithDepth(dir, "a")
  WriteLasWithDepth(dir, "b", "DEPTH")
  for (z in c("DEPT", "Depth", "md")) {
    expect_s3_class(
      suppressMessages(StratData(signal = dir, zColumn = z,
                                 signalColumn = "GR", zScale = "depth")),
      "StratData"
    )
  }
  for (z in c("TVD", "TVDSS")) {
    expect_error(
      StratData(signal = dir, zColumn = z, signalColumn = "GR",
                zScale = "depth"),
      "Missing required column"
    )
  }
})

test_that("ReadLasFiles() catches a '#' line cancelled by a blank (#2367)", {
  skip_if_not_installed("SDAR")
  dir <- withr::local_tempdir()
  WriteLasWithDepth(dir, "w1")
  writeLines(c(
    "~Version Information", "VERS. 2.0: ", "WRAP. NO: ",
    "~Well Information Block", "STRT.M 100.0: ", "STOP.M 101.0: ",
    "STEP.M 0.5: ", "NULL. -999.25: ", "WELL. TEST: WELL",
    "~Curve Information Block",
    "DEPT.M : Depth", "GR.GAPI : gamma tool #2", "RHOB.G/CC : Density", "",
    "~A",
    sprintf("%.4f %.4f %.4f", c(100, 100.5, 101), c(50, 60, 55),
            c(2.3, 2.4, 2.35))
  ), file.path(dir, "w3.las"))
  expect_warning(
    expect_warning(out <- ReadLasFiles(dir, quiet = TRUE),
                   "Failed to read LAS file: w3.las"),
    "Skipped 1 unreadable"
  )
  expect_named(out, "w1")
})
