# #2529: an automatic start was never checked against the ties, so with a
# narrow tie density with hard bounds it almost always sat on the -1e30
# plateau, which offers the sampler no way to the support. Fails before the
# fix: about 1 prior draw in 200 lands in the 0.1 m window below.
NarrowTieFixture <- function(width = 0.1) {
  ties <- data.frame(site = "site2", height = 3.72, densityFun = "dunif",
                     arg1 = 2.5 * pi - width / 2, arg2 = 2.5 * pi + width / 2)
  data <- StratData(signal = signalData5, ties = ties, referenceSite = "site1")
  site1 <- signalData5[["height"]][signalData5[["site"]] == "site1"]
  priors <- structure(
    list(
      "alpha_site2" = UniformPrior(min = min(site1), max = max(site1)),
      "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))
    ),
    class = c("StratPrior", "list")
  )
  model <- StratModel(
    stratData = data, priors = priors, alignmentScale = "height",
    sedModel = "site", alphaPosition = "middle", nKnots = 15,
    sigmaFixed = TRUE
  )
  list(data = data, model = model)
}

test_that("an automatic start lies inside a narrow tie's support (#2529)", {
  fix <- NarrowTieFixture()
  mcmc <- StratMCMC(fix[["model"]], nIter = 10, nChains = 1, nThreads = 1L)
  set.seed(2529)
  for (start in 1:20) {
    state <- .GenerateInitialState(fix[["data"]], fix[["model"]], mcmc, 1)
    expect_gt(.LogLikTies(fix[["data"]], fix[["model"]], state), -1e30)
    expect_gt(state[[c("metro", "logPost")]], -1e30)
  }
})

test_that("automatic starts stay independent draws (#2529)", {
  fix <- NarrowTieFixture()
  mcmc <- StratMCMC(fix[["model"]], nIter = 10, nChains = 1, nThreads = 1L)
  set.seed(1)
  starts <- vapply(1:5, function(start) {
    .GenerateInitialState(fix[["data"]], fix[["model"]], mcmc, 1)[[
      c("metro", "parameters")
    ]][[1L]]
  }, double(1))
  expect_length(unique(starts), 5L)
})

test_that("a user-supplied start outside the support is honoured (#2529)", {
  fix <- NarrowTieFixture()
  outside <- c(2, 0)
  mcmc <- StratMCMC(fix[["model"]], nIter = 10, nChains = 1, nThreads = 1L,
                    parametersInitial = outside)
  state <- .GenerateInitialState(fix[["data"]], fix[["model"]], mcmc, 1)
  expect_equal(unname(state[[c("metro", "parameters")]]), outside)
  expect_equal(.LogLikTies(fix[["data"]], fix[["model"]], state), -1e30)
})

test_that("an unreachable support falls back to an ordinary start (#2529)", {
  fix <- NarrowTieFixture()
  # A window beyond any offset the prior allows: the start must still be
  # generated, as before, for the run's collapse check to report.
  fix[["data"]][["tiesAttr"]][["arg1"]][] <- 1000
  fix[["data"]][["tiesAttr"]][["arg2"]][] <- 1001
  mcmc <- StratMCMC(fix[["model"]], nIter = 10, nChains = 1, nThreads = 1L)
  set.seed(1)
  state <- .GenerateInitialState(fix[["data"]], fix[["model"]], mcmc, 1)
  expect_equal(.LogLikTies(fix[["data"]], fix[["model"]], state), -1e30)
  expect_equal(state[[c("metro", "logPost")]], -1e30)
})
