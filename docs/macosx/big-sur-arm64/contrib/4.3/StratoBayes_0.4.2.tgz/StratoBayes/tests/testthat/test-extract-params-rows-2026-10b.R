TwoChainPosterior <- function() {
  x <- stratPosterior1
  samples <- x[["samples"]]
  dims <- dim(samples)
  dn <- dimnames(samples)
  dn[[4]] <- c("chain1", "chain2")
  x[["samples"]] <- array(
    c(samples, samples + 1000),
    dim = c(dims[1:3], 2L),
    dimnames = dn
  )
  x
}

# Row counts handed to ExtractParameters() by a plotting function, recorded
# while the real function still runs.
RowsRequested <- function(plotFn, ...) {
  seen <- new.env()
  seen$n <- integer(0)
  realExtract <- ExtractParameters
  testthat::local_mocked_bindings(
    ExtractParameters = function(...) {
      args <- list(...)
      if (!is.null(args[["selectRows"]])) {
        seen$n <- c(seen$n, sum(lengths(args[["selectRows"]])))
      }
      realExtract(...)
    }
  )
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  plotFn(..., display = FALSE)
  seen$n
}

test_that("alignment on a non-cold chain is refused (#2673)", {
  x <- TwoChainPosterior()
  expect_error(
    ExtractParameters(x, alignment = 1, chain = "chain2", maxSamples = 50),
    "chain 1"
  )
  expect_gt(
    nrow(ExtractParameters(x, chain = "chain2", maxSamples = 50)),
    0
  )
  expect_gt(
    nrow(ExtractParameters(x, alignment = 1, maxSamples = 50)),
    0
  )
})

test_that("alignment is validated even when selectRows overrides it (#2673)", {
  x <- stratPosterior1
  expect_error(ExtractParameters(x, selectRows = 1:3, alignment = "a"))
  expect_error(ExtractParameters(x, selectRows = 1:3, alignment = -1))
  expect_error(ExtractParameters(x, selectRows = 1:3, alignment = 1.5))
  expect_error(
    ExtractParameters(x, selectRows = 1:3, alignment = 99,
                      stratCluster = Cluster(x, maxSamples = 100)),
    "alignment"
  )
  expect_equal(
    nrow(ExtractParameters(x, selectRows = 1:3, alignment = "all")),
    3 * x[["nRun"]]
  )
})

test_that("ExtractParameters() caps rows with a stratCluster (#2402)", {
  x <- stratPosterior1
  sc <- Cluster(x, maxSamples = 100)
  capped <- ExtractParameters(x, stratCluster = sc, alignment = 1,
                              maxSamples = 50)
  expect_equal(nrow(capped), 50)
  expect_gt(
    nrow(ExtractParameters(x, stratCluster = sc, alignment = 1)),
    50
  )
})

test_that("plots honour maxSamples with a stratCluster (#2402)", {
  x <- stratPosterior5a
  sc <- Cluster(x)
  rowsPer <- function(plotFn, ..., maxSamples) {
    RowsRequested(plotFn, x, stratCluster = sc, alignment = 1,
                  maxSamples = maxSamples, ...)
  }
  expect_true(all(rowsPer(boxplot, maxSamples = 40) <= 40))
  expect_true(all(rowsPer(BeanPlot, maxSamples = 40) <= 40))
  expect_true(all(rowsPer(plot, maxSamples = 40) <= 40))
  expect_true(any(rowsPer(boxplot, maxSamples = Inf) > 40))
})

test_that("boxplot() without stratCluster keeps its rows (#2402)", {
  x <- stratPosterior5a
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  expect_equal(
    nrow(boxplot(x, alignment = 1, maxSamples = 100, display = FALSE)[[1]]),
    44
  )
})

test_that("alignment with NA names the cause under selectRows (#2673)", {
  expect_error(
    ExtractParameters(stratPosterior1, selectRows = 1:3,
                      alignment = c(1, NA)),
    "missing values"
  )
})
