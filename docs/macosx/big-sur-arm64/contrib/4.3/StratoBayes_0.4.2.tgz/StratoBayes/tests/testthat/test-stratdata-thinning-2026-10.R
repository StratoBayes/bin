thinSignal <- data.frame(
  site = rep(c("a", "b"), each = 4),
  height = rep(c(0, 4, 8, 12), 2),
  value = seq_len(8)
)

test_that("colliding z/site/partition columns are refused (#2368.1)", {
  expect_error(
    StratData(thinSignal, zColumn = "height", siteColumn = "height"),
    "`zColumn` and `siteColumn` cannot name the same column"
  )
  expect_error(
    StratData(thinSignal, zColumn = "height", partitionColumn = "height"),
    "`zColumn` and `partitionColumn` cannot name the same column"
  )
  expect_error(
    StratData(thinSignal, siteColumn = "site", partitionColumn = "site"),
    "`siteColumn` and `partitionColumn` cannot name the same column"
  )
})

test_that("a named Inf maxPointsPerSite disables thinning (#2368.2)", {
  expect_no_error(StratData(thinSignal, maxPointsPerSite = c(a = Inf)))
})

test_that("a subnormal blockLength gives sorted, finite blocks (#2368.3)", {
  signal <- data.frame(site = "a", height = c(0, 0, 1:5), value = 1:7)
  for (blockLength in c(5e-324, 1e-310)) {
    out <- ThinSignal(signal, blockLength = blockLength)
    expect_false(is.unsorted(out$height))
    expect_false(anyNA(out))
    expect_true(all(is.finite(out$height)))
  }
})

test_that("thinning that empties a partition is warned about (#2432)", {
  z <- seq(0, 100, length.out = 6000)
  signal <- data.frame(site = rep(c("A", "B"), each = 6000),
                       height = rep(z, 2), value = rep(sin(z / 7), 2))
  partsEdge <- c(50, 50.1, 100)
  parts <- data.frame(
    site = rep(c("A", "B"), each = 3),
    height = rep(partsEdge, 2),
    partition = rep(c("lo", "thin", "hi"), 2)
  )
  signal[nrow(signal) + 1:4, ] <- data.frame(
    site = "A", height = 50 + 0.02 * 1:4, value = 0
  )
  expect_warning(
    StratData(signal, parts = parts, maxPointsPerSite = 200),
    "removed every signal row from partition 'thin' \\(site 'A'\\)"
  )
  expect_no_warning(
    StratData(signal, parts = parts, maxPointsPerSite = Inf)
  )
})

test_that("a duplicate-header ties table is refused (#2119.1)", {
  ties <- data.frame(site = "b", height = 5, densityFun = "dnorm",
                     arg1 = 30, arg2 = 0.2)
  csv <- tempfile(fileext = ".csv")
  on.exit(unlink(csv))
  writeLines(c("site,height,densityFun,arg1,arg2,arg2", "b,5,dnorm,30,0.2,0.3"),
             csv)
  expect_error(StratData(thinSignal, ties = csv), "duplicate column names")
  dup <- cbind(ties, arg2 = 0.3)
  expect_error(StratData(thinSignal, ties = dup), "duplicate column names")
  expect_no_error(StratData(thinSignal, ties = ties))
})
