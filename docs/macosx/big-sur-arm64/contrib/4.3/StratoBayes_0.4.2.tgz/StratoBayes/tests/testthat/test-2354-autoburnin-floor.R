test_that("the survivor floor is the search's, not the candidate's", {
  set.seed(2354)
  iters <- list(1:300, 1:280)
  draws <- lapply(iters, function(it) {
    matrix(rnorm(length(it)), ncol = 1, dimnames = list(NULL, "a"))
  })

  # At 240 the runs keep 60/40 rows and the 40-row run vetoes under the 50-row
  # floor. The next candidate, 255, keeps 45/25: it must not fall back to the
  # 8-row floor and pass a weaker test than the one just refused.
  result <- .AutoBurnInCore(draws, iters, floorIter = 240, grid = 0)
  expect_equal(result[["status"]], "insufficientDraws")
  result <- .AutoBurnInCore(draws, iters, floorIter = 240)
  expect_equal(result[["status"]], "insufficientDraws")

  # Rows below `floorIter` do not raise the floor: the stopping rule never
  # stores them, and must reach the verdict the summary later gives.
  Status <- function(floorIter, tailOnly) {
    keep <- lapply(iters, function(it) !tailOnly | it >= floorIter)
    .AutoBurnInCore(
      Map(function(m, k) m[k, , drop = FALSE], draws, keep),
      Map(`[`, iters, keep),
      floorIter = floorIter, grid = 0
    )[["status"]]
  }
  for (floorIter in c(240, 255)) {
    expect_equal(Status(floorIter, FALSE), Status(floorIter, TRUE))
  }
  result <- .AutoBurnInCore(draws, iters, floorIter = 255)
  expect_equal(result[["status"]], "ok")

  result <- .AutoBurnInCore(draws, iters)
  expect_equal(result[["status"]], "ok")
  expect_gte(result[["minRunRows"]], 50L)
})
