# #2541: the offset prior scale tau was seeded at 1 under an Inverse-Gamma(1, 1)
# hyperprior, both in raw signal units. On large-valued signals that shrinks
# every offset to zero, a stable fixed point from which the alignment absorbs
# the offset instead. Rescaling the values must rescale tau and the offsets
# with them and leave the alignment alone.

# Site s2 carries a +4 shift. Its alignment priors are tight, so the offset can
# only be explained by delta; at k = 1000 the unfixed sampler pins delta at 0.
OffsetScaleFixture <- function(k) {
  set.seed(2541)
  n <- 25
  h <- seq(0, 10, length.out = n)
  signal <- data.frame(
    site   = rep(c("s1", "s2"), each = n),
    height = c(h, h),
    value  = k * c(sin(h) + rnorm(n, 0, 0.1), sin(h) + 4 + rnorm(n, 0, 0.1))
  )
  group <- data.frame(site = c("s1", "s2"), group = c("A", "B"))
  priors <- structure(
    list(
      "alpha_s2"    = NormalPrior(mean = 0, sd = 0.05),
      "gammaLog_s2" = NormalPrior(mean = 0, sd = 0.05)
    ),
    class = c("list", "StratPrior")
  )
  list(data = StratData(signal = signal, group = group), priors = priors)
}

OffsetScaleModel <- function(fix) {
  suppressWarnings(suppressMessages(StratModel(
    fix$data, fix$priors,
    alignmentScale = "height", sedModel = "site", nKnots = 8,
    signalOffsets = TRUE, sigmaFixed = FALSE
  )))
}

test_that("offset tau prior and seed scale with the signal (#2541)", {
  InitTau <- function(k) {
    fix <- OffsetScaleFixture(k)
    model <- OffsetScaleModel(fix)
    mcmc <- StratMCMC(model, nIter = 10, nChains = 1)
    state <- .GenerateValidProposal(fix$data, model, mcmc,
                                    stateOld = NULL,
                                    ProposeMetro = .MetroPriorSample,
                                    initialState = TRUE, chain = 1)
    state <- .FlexibleKnotsUpdateDB(fix$data, model, state)
    state <- .InitializeGibbs(fix$data, model, state)
    list(bTau = model$offsetConfig$bTau, tau = state$gibbs$tau)
  }
  unit <- InitTau(1)
  big <- InitTau(1e3)
  expect_equal(unname(unit$tau), unname(sqrt(unit$bTau)))
  expect_false(isTRUE(all.equal(unname(unit$bTau), 1)))
  expect_equal(big$bTau, unit$bTau * 1e6)
  expect_equal(big$tau, unit$tau * 1e3)
})

test_that("offsets and alignment are invariant to rescaling values (#2541)", {
  skip_on_cran()
  Fit <- function(k) {
    fix <- OffsetScaleFixture(k)
    post <- suppressWarnings(RunStratModel(
      stratObject = fix$data, stratModel = OffsetScaleModel(fix),
      nIter = 400, nThin = 2, nChains = 1, seed = 2541,
      quiet = TRUE, visualise = FALSE, convergenceStop = FALSE,
      nThreads = 1L, nCores = 1L, runParallel = FALSE
    ))
    draws <- ExtractParameters(
      post, parameters = c("delta_A_value", "delta_B_value", "alpha_s2"),
      burnIn = 0.5
    )
    vapply(draws, stats::median, numeric(1)) / c(k, k, 1)
  }
  unit <- Fit(1)
  big <- Fit(1e3)
  # Sum-to-zero halves the +4 shift: delta_B is near +2 at any scale.
  expect_gt(unit[["delta_B_value"]], 1.5)
  expect_gt(big[["delta_B_value"]], 1.5)
  expect_equal(big, unit, tolerance = 0.1)
})

test_that("the engine rejects a malformed tau prior rate (#2541)", {
  fix <- OffsetScaleFixture(1)
  model <- OffsetScaleModel(fix)
  RunWithBTau <- function(bTau) {
    model$offsetConfig$bTau <- bTau
    RunStratModel(
      stratObject = fix$data, stratModel = model,
      nIter = 4, nThin = 1, nChains = 1, seed = 2541,
      quiet = TRUE, visualise = FALSE, convergenceStop = FALSE,
      nThreads = 1L, nCores = 1L, runParallel = FALSE
    )
  }
  expect_error(RunWithBTau(c(1, 2)), "one value per signal")
  expect_error(RunWithBTau(0), "finite and positive")
})

# Two signals three orders of magnitude apart, in non-alphabetical column
# order, so a rate read from the wrong signal shows on both.
TwoSignalFixture <- function() {
  set.seed(2541)
  n <- 25
  h <- seq(0, 10, length.out = n)
  signal <- data.frame(
    site = rep(c("s1", "s2"), each = n),
    height = c(h, h),
    zbig = 1000 * (c(sin(h), sin(h) + 4) + rnorm(2 * n, 0, 0.1)),
    asmall = c(cos(h), cos(h) - 4) + rnorm(2 * n, 0, 0.1)
  )
  data <- StratData(
    signal = signal, signalColumn = c("zbig", "asmall"),
    group = data.frame(site = c("s1", "s2"), group = c("A", "B"))
  )
  model <- suppressWarnings(suppressMessages(StratModel(
    data, OffsetScaleFixture(1)$priors,
    alignmentScale = "height", sedModel = "site", nKnots = 8,
    signalOffsets = TRUE, sigmaFixed = FALSE
  )))
  list(data = data, model = model)
}

RunTwoSignal <- function(fix, nIter) {
  suppressWarnings(RunStratModel(
    stratObject = fix$data, stratModel = fix$model,
    nIter = nIter, nThin = 1, nChains = 1, seed = 2541,
    quiet = TRUE, visualise = FALSE, convergenceStop = FALSE,
    nThreads = 1L, nCores = 1L, runParallel = FALSE
  ))
}

test_that("the engine reads each signal's own tau prior rate (#2541)", {
  skip_on_cran()
  fix <- TwoSignalFixture()
  expect_equal(names(fix$model$offsetConfig$bTau), c("zbig", "asmall"))
  pars <- c("delta_B_zbig", "delta_B_asmall", "tau_zbig", "tau_asmall")
  draws <- ExtractParameters(RunTwoSignal(fix, 400), parameters = pars,
                             burnIn = 0.5)
  med <- vapply(draws, stats::median, numeric(1))
  expect_gt(med[["delta_B_zbig"]] / 1000, 1.5)
  expect_lt(med[["delta_B_asmall"]], -1.5)
  expect_equal(med[["tau_zbig"]] / med[["tau_asmall"]], 1000, tolerance = 0.5)
})

test_that("a model with one shared tau prior rate still runs (#2541)", {
  # Models built before the rate was per signal carry a single value, which
  # must act as that value for every signal.
  fix <- TwoSignalFixture()
  pars <- c("tau_zbig", "tau_asmall", "delta_B_zbig", "delta_B_asmall")
  fix$model$offsetConfig$bTau <- 1
  shared <- ExtractParameters(RunTwoSignal(fix, 20), parameters = pars,
                              burnIn = 0)
  fix$model$offsetConfig$bTau <- c(zbig = 1, asmall = 1)
  perSignal <- ExtractParameters(RunTwoSignal(fix, 20), parameters = pars,
                                 burnIn = 0)
  expect_identical(shared, perSignal)
})
