# #2227: the replica swap preserves the product of
# Pi_T = exp(E_T(a, lambda, sigma)) * pi(beta | a, lambda, sigma), E_T being the
# beta-marginal tempered energy. A hot rung that Gibbs-draws lambda and sigma
# from their T = 1 conditionals leaves some other law invariant, so the cold
# chain stops sampling the posterior. Hot rungs now take an MH step on E_T for
# lambda and sigma, then draw beta exactly; HMC and NUTS, which target the
# joint law at fixed beta, run on the cold rung only.

# Exact stationary law of a two-rung chain over a discrete joint
# pi(a, lambda, beta). This checks the scheme, not the engine, so it passes on
# either side of the fix; the engine tests follow it. Each variable lies in
# {1, 2, 3} and moves in the engine's order. The "gibbs" arm draws
# lambda | a, beta untempered on the hot rung; the "mh" arm takes an MH step on
# lambda against pi_m(a, lambda)^(1/T) before the beta draw, as the engine
# does now.
RungKernel <- function(joint, temperature, arm) {
  nVal <- dim(joint)[[1]]
  marginal <- apply(joint, c(1, 2), sum)
  states <- expand.grid(a = seq_len(nVal), l = seq_len(nVal), b = seq_len(nVal))
  StateIndex <- function(a, l, b) a + nVal * (l - 1L) + nVal^2 * (b - 1L)
  invT <- 1 / temperature
  MhStep <- function(densityRatio) min(1, densityRatio^invT) / (nVal - 1L)
  kernel <- matrix(0, nrow(states), nrow(states))
  for (i in seq_len(nrow(states))) {
    a <- states$a[[i]]
    l <- states$l[[i]]
    aDist <- numeric(nVal)
    for (aNew in setdiff(seq_len(nVal), a)) {
      move <- MhStep(marginal[aNew, l] / marginal[a, l])
      aDist[[aNew]] <- move
      aDist[[a]] <- aDist[[a]] + 1 / (nVal - 1L) - move
    }
    for (a2 in which(aDist > 0)) {
      if (arm == "gibbs" || temperature == 1) {
        betaDist <- joint[a2, l, ] / sum(joint[a2, l, ])
        for (b2 in seq_len(nVal)) {
          lambdaDist <- joint[a2, , b2] / sum(joint[a2, , b2])
          for (l2 in seq_len(nVal)) {
            j <- StateIndex(a2, l2, b2)
            kernel[i, j] <- kernel[i, j] + aDist[[a2]] * betaDist[[b2]] *
              lambdaDist[[l2]]
          }
        }
      } else {
        lambdaDist <- numeric(nVal)
        for (lNew in setdiff(seq_len(nVal), l)) {
          move <- MhStep(marginal[a2, lNew] / marginal[a2, l])
          lambdaDist[[lNew]] <- move
          lambdaDist[[l]] <- lambdaDist[[l]] + 1 / (nVal - 1L) - move
        }
        for (l2 in which(lambdaDist > 0)) {
          betaDist <- joint[a2, l2, ] / sum(joint[a2, l2, ])
          for (b2 in seq_len(nVal)) {
            j <- StateIndex(a2, l2, b2)
            kernel[i, j] <- kernel[i, j] + aDist[[a2]] * lambdaDist[[l2]] *
              betaDist[[b2]]
          }
        }
      }
    }
  }
  list(kernel = kernel, energy = log(marginal[cbind(states$a, states$l)]))
}

ColdLawError <- function(joint, hotTemperature, arm) {
  cold <- RungKernel(joint, 1, arm)
  hot <- RungKernel(joint, hotTemperature, arm)
  n <- nrow(cold[["kernel"]])
  pair <- expand.grid(hot = seq_len(n), cold = seq_len(n))
  swapRatio <- pmin(1, exp((hot[["energy"]][pair$hot] -
                              cold[["energy"]][pair$cold]) *
                             (1 - 1 / hotTemperature)))
  # kronecker(cold, hot) indexes the pair (i, j) at (i - 1) * n + j.
  from <- (pair$cold - 1L) * n + pair$hot
  to <- (pair$hot - 1L) * n + pair$cold
  swap <- matrix(0, n^2, n^2)
  swap[cbind(from, to)] <- swap[cbind(from, to)] + swapRatio
  swap[cbind(from, from)] <- swap[cbind(from, from)] + 1 - swapRatio
  chain <- kronecker(cold[["kernel"]], hot[["kernel"]]) %*% swap
  stationary <- qr.solve(rbind(t(chain) - diag(n^2), 1), c(numeric(n^2), 1))
  coldLaw <- rowSums(matrix(stationary, n, n, byrow = TRUE))
  max(abs(coldLaw - as.vector(joint)))
}

test_that("an exact two-rung chain keeps the cold law only under the MH arm", {
  set.seed(2227)
  for (hotTemperature in c(2, 5)) {
    joint <- array(rgamma(27, 1), c(3, 3, 3))
    joint <- joint / sum(joint)
    expect_gt(ColdLawError(joint, hotTemperature, "gibbs"), 1e-3)
    expect_lt(ColdLawError(joint, hotTemperature, "mh"), 1e-12)
  }
})

test_that("default tempering keeps a pinned lambda's posterior spread", {
  skip_on_cran()
  # aLambda = 1e5 pins lambda to its prior, so the cold chain's sd(log lambda)
  # is known exactly: sqrt(trigamma(1e5)). Before #2227 the default 8-rung
  # "full" ladder gave 0.00300 against 0.00316, about 5% narrow.
  set.seed(2227)
  model <- StratModel(stratData1, priors = stratPrior1,
                      alignmentScale = "height", sedModel = "site",
                      alphaPosition = "bottom", nKnots = 15, aLambda = 1e5,
                      sigmaFixed = TRUE)
  result <- RunStratModel(stratData1, model, nIter = 40000L, nChains = 8L,
                          temperingComponents = "full", nThreads = 1L,
                          seed = 2227, runParallel = FALSE,
                          convergenceStop = FALSE, quiet = TRUE,
                          visualise = FALSE)
  samples <- result[["samples"]]
  logLambda <- log(samples[, "lambda_value", 1, 1])
  logLambda <- logLambda[-seq_len(length(logLambda) %/% 2)]
  expect_lt(abs(sd(logLambda) / sqrt(trigamma(1e5)) - 1), 0.025)
})

HotNutsEngine <- function(nutsOnly) {
  model <- StratModel(stratData1, priors = stratPrior1,
                      alignmentScale = "height", sedModel = "site",
                      alphaPosition = "bottom", nKnots = 10, sigmaFixed = TRUE,
                      flexibleKnots = FALSE)
  modelDir <- withr::local_tempdir()
  RunStratModel(stratData1, model, nIter = 400L, nChains = 2L, nThin = 1L,
                nThreads = 1L, tempering = TRUE, gradientProposals = "on",
                adaptProposal = TRUE, nRun = 1L, runParallel = FALSE,
                visualise = FALSE, quiet = TRUE, seed = 1L,
                modelDir = modelDir, modelName = "hot2227")
  mcmc <- readRDS(file.path(modelDir, "hot2227_mcmc_run_1.rds"))
  if (is.null(model[[".logpost_cpp"]])) {
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  probability <- mcmc[[c("metro", "proposalProbability")]]
  probability[, ] <- 0
  probability[, "NUTS"] <- 1
  if (!nutsOnly) probability[, "Prior"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- probability

  engine <- StratoBayes:::.sb_create_engine(stratData1, model, mcmc,
                                            mcmc[["recentState"]])
  expect_gt(mcmc[[c("temper", "temperatures")]][[2]], 1)
  StratoBayes:::.sb_configure_monitor(engine, ncol(probability))
  set.seed(2227)
  StratoBayes:::.sb_run_block(engine, 50L)
  monitor <- StratoBayes:::.sb_get_monitor(engine)
  nutsIdx <- which(colnames(probability) == "NUTS")
  list(
    nuts = monitor[["proposalCount"]][, nutsIdx],
    nutsAccepted = monitor[["acceptCount"]][, nutsIdx],
    nGradient = monitor[["nGradientTransitions"]]
  )
}

test_that("hot rungs never select NUTS", {
  skip_on_cran()
  counts <- HotNutsEngine(nutsOnly = FALSE)
  expect_gt(counts[["nuts"]][[1]], 0L)
  expect_equal(counts[["nuts"]][[2]], 0L)
  expect_equal(counts[["nGradient"]], counts[["nuts"]][[1]])
})

test_that("a hot rung with only NUTS to draw stays put", {
  skip_on_cran()
  counts <- HotNutsEngine(nutsOnly = TRUE)
  # The refusals are booked against NUTS, as rejections.
  expect_equal(counts[["nuts"]], c(50L, 50L))
  expect_equal(counts[["nGradient"]], 50L)
  expect_equal(counts[["nutsAccepted"]][[2]], 0L)
})

test_that("a hot rung's lambda/sigma step reuses the stamped marginal", {
  skip_on_cran()
  # The sampler reuses the marginal stamped with the current factor; the probe
  # repeats the Gibbs sweep with the stamp withdrawn, which recomputes it. Any
  # difference in the energy changes an accept decision, so beta parts.
  model <- suppressWarnings(
    StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
               alignmentScale = "height", sedModel = "site, partition",
               sedSmooth = TRUE, flexibleKnots = FALSE,
               knotRange = c(-5, 12), sigmaFixed = FALSE)
  )
  modelDir <- withr::local_tempdir()
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = model, nIter = 10, nChains = 2L,
    tempering = TRUE, seed = 1, nThreads = 1L, runParallel = FALSE,
    quiet = TRUE, visualise = FALSE, modelDir = modelDir, modelName = "carry"
  ))
  model <- result[["model"]]
  if (is.null(model[[".logpost_cpp"]])) {
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  mcmc <- readRDS(file.path(modelDir, "carry_mcmc_run_1.rds"))
  expect_gt(mcmc[[c("temper", "temperatures")]][[2]], 1)
  engine <- StratoBayes:::.sb_create_engine(
    data = result[["data"]], model = model, mcmc = mcmc,
    state = mcmc[["recentState"]], tiesCallback = NULL
  )
  probes <- lapply(seq_len(60), function(i) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    StratoBayes:::.sb_sed_smooth_gibbs_probe(engine, 2L, i)
  })
  carried <- vapply(probes, `[[`, logical(1), "carried")
  expect_gt(sum(carried), 0L)
  expect_true(all(vapply(probes, `[[`, numeric(1), "maxBetaDiff") == 0))
})
