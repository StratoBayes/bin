# #2156: the sedBeta proposal adapted on a sliding window forever, and a
# continuation restarted it cold.

SedModel <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  suppressWarnings(StratModel(
    stratData1, priors = AutoPrior(stratData1, "height"),
    alignmentScale = "height", sedModel = "site, partition", sedSmooth = TRUE
  ))
}

SedBetaFixture <- function() {
  data(stratData1, package = "StratoBayes")
  sModel <- SedModel()
  td <- withr::local_tempdir(.local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "sedAdapt"
  ))
  mcmc <- readRDS(file.path(td, "sedAdapt_mcmc_run_1.rds"))
  model <- result[["model"]]
  model[[c("sedSmoothInfo", "boundaryMove")]] <- list(prob = 0)
  list(data = result[["data"]], model = model,
       state = mcmc[["recentState"]][[1]])
}

test_that("sedBeta adaptation stops when told to, and refuses NA", {
  skip_on_cran()
  fx <- SedBetaFixture()
  e <- StratoBayes:::.HMCCreateEngine(fx$data, fx$model, fx$state)
  StratoBayes:::.sb_run_block(e, 400L)
  adapted <- StratoBayes:::.sb_sed_beta_adapt_state(e)
  expect_true(adapted$adapt)
  expect_false(is.null(adapted$chains[[1]][[1]]$cholCov))
  expect_gt(adapted$chains[[1]][[1]]$nProposed, 0L)

  StratoBayes:::.sb_sed_beta_set_adapt(e, FALSE)
  StratoBayes:::.sb_run_block(e, 200L)
  frozen <- StratoBayes:::.sb_sed_beta_adapt_state(e)
  expect_false(frozen$adapt)
  expect_identical(frozen$chains, adapted$chains)
  expect_error(StratoBayes:::.sb_sed_beta_set_adapt(e, NA),
               "adapt must be TRUE or FALSE")
})

test_that("an engine resumed with the adaptation state continues the chain", {
  skip_on_cran()
  fx <- SedBetaFixture()
  a <- StratoBayes:::.HMCCreateEngine(fx$data, fx$model, fx$state)
  StratoBayes:::.sb_run_block(a, 400L)
  state <- StratoBayes:::.sb_extract_state(a)[[1]]
  streams <- StratoBayes:::.sb_get_chain_rng(a)
  adapt <- StratoBayes:::.sb_sed_beta_adapt_state(a)

  Resumed <- function(restoreAdapt) {
    b <- StratoBayes:::.HMCCreateEngine(fx$data, fx$model, state)
    StratoBayes:::.sb_set_chain_rng(b, streams)
    if (restoreAdapt) {
      StratoBayes:::.sb_sed_beta_set_adapt_state(b, adapt$chains)
      expect_identical(StratoBayes:::.sb_sed_beta_adapt_state(b), adapt)
    }
    StratoBayes:::.sb_run_block(b, 100L)
    StratoBayes:::.sb_extract_state(b)[[1]]$gibbs$sedBeta
  }
  StratoBayes:::.sb_run_block(a, 100L)
  whole <- StratoBayes:::.sb_extract_state(a)[[1]]$gibbs$sedBeta
  expect_identical(Resumed(TRUE), whole)
  # A cold proposal draws a different stream.
  expect_false(identical(Resumed(FALSE), whole))
})

test_that(".sb_sed_beta_set_adapt_state() refuses a mismatched state", {
  skip_on_cran()
  fx <- SedBetaFixture()
  e <- StratoBayes:::.HMCCreateEngine(fx$data, fx$model, fx$state)
  chains <- StratoBayes:::.sb_sed_beta_adapt_state(e)$chains
  expect_error(StratoBayes:::.sb_sed_beta_set_adapt_state(e, c(chains, chains)),
               "different number of chains")
  expect_error(
    StratoBayes:::.sb_sed_beta_set_adapt_state(e, list(chains[[1]][-1])),
    "different number of formations"
  )
  bad <- chains
  bad[[1]][[1]]$buffer <- bad[[1]][[1]]$buffer[-1, ]
  expect_error(StratoBayes:::.sb_sed_beta_set_adapt_state(e, bad),
               "malformed")
  bad <- chains
  bad[[1]][[1]]$writePos <- 1e6L
  expect_error(StratoBayes:::.sb_sed_beta_set_adapt_state(e, bad),
               "malformed")
  bad <- chains
  bad[[1]][[1]]$logScale <- NaN
  expect_error(StratoBayes:::.sb_sed_beta_set_adapt_state(e, bad),
               "malformed")
})

test_that("RunStratModel freezes sedBeta adaptation and carries it over", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- SedModel()
  td <- withr::local_tempdir()
  run1 <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 400, endAdapting = 200, convergenceStop = FALSE,
    nChains = 2L, seed = 5, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "sedAdapt"
  ))
  f <- file.path(td, "sedAdapt_mcmc_run_1.rds")
  s1 <- readRDS(f)$sedBetaAdapt
  expect_false(s1$adapt)
  expect_length(s1$chains, 2L)
  expect_false(is.null(s1$chains[[1]][[1]]$cholCov))

  suppressWarnings(RunStratModel(run1, nIter = 100, quiet = TRUE,
                                 visualise = FALSE, nThreads = 1L))
  s2 <- readRDS(f)$sedBetaAdapt
  expect_false(s2$adapt)
  expect_identical(s2$chains, s1$chains)
})

test_that("without adaptProposal the sedBeta proposal never adapts", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- SedModel()
  Run <- function(nIter, modelDir) {
    suppressWarnings(RunStratModel(
      stratObject = stratData1, stratModel = sModel, nIter = nIter,
      nChains = 2L, seed = 7, adaptProposal = FALSE,
      gradientProposals = "off", quiet = TRUE, visualise = FALSE,
      runParallel = FALSE, nThreads = 1L, modelDir = modelDir,
      modelName = "sedFixed"
    ))
  }
  td <- withr::local_tempdir()
  whole <- Run(200, withr::local_tempdir())
  segmented <- suppressWarnings(RunStratModel(
    Run(100, td), nIter = 100, seed = 7, quiet = TRUE, visualise = FALSE,
    nThreads = 1L
  ))
  st <- readRDS(file.path(td, "sedFixed_mcmc_run_1.rds"))$sedBetaAdapt
  expect_false(st$adapt)
  expect_identical(st$chains[[1]][[1]]$nProposed, 0L)
  expect_equal(unname(segmented[["samples"]]), unname(whole[["samples"]]))
})

AdaptRun <- function(modelDir, nIter, endAdapting) {
  data(stratData1, package = "StratoBayes")
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = SedModel(), nIter = nIter,
    endAdapting = endAdapting, convergenceStop = FALSE, nChains = 2L,
    seed = 3, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = modelDir, modelName = "sedAdapt"
  ))
}

AdaptSteps <- function(modelDir) {
  st <- readRDS(file.path(modelDir, "sedAdapt_mcmc_run_1.rds"))$sedBetaAdapt
  vapply(st$chains, function(chain) {
    sum(vapply(chain, `[[`, integer(1), "nProposed"))
  }, integer(1))
}

test_that("sedBeta adapts on exactly iterations 2 to endAdapting", {
  skip_on_cran()
  td <- withr::local_tempdir()
  AdaptRun(td, nIter = 250, endAdapting = 100)
  expect_identical(AdaptSteps(td), c(99L, 99L))
})

test_that("a continuation that reopens adaptation carries the tuning on", {
  skip_on_cran()
  td <- withr::local_tempdir()
  run1 <- AdaptRun(td, nIter = 150, endAdapting = 100)
  suppressWarnings(RunStratModel(
    run1, nIter = 150, endAdapting = 50, convergenceStop = FALSE,
    quiet = TRUE, visualise = FALSE, nThreads = 1L
  ))
  expect_identical(AdaptSteps(td), c(149L, 149L))
})

test_that("a checkpoint without sedBeta state continues on a frozen kernel", {
  skip_on_cran()
  td <- withr::local_tempdir()
  run1 <- AdaptRun(td, nIter = 150, endAdapting = 100)
  f <- file.path(td, "sedAdapt_mcmc_run_1.rds")
  m <- readRDS(f)
  m$sedBetaAdapt <- NULL
  saveRDS(m, f)
  suppressWarnings(RunStratModel(
    run1, nIter = 50, quiet = TRUE, visualise = FALSE, nThreads = 1L
  ))
  expect_identical(AdaptSteps(td), c(0L, 0L))
})
