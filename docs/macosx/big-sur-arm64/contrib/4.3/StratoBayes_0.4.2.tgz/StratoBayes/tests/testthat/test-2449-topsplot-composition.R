# GH #2449, #2307: with `refHeightsSite = k`, every panel is a quantile of the
# per-draw composition site k -> reference -> site j, not of site j conditioned
# on the median reference height.

PosteriorDraws <- function() {
  data("stratPosterior1", package = "StratoBayes", envir = environment())
  selectRows <- ExtractIterations(stratPosterior1, alignment = "all",
                                  burnIn = 0.5, maxSamples = 2500)
  as.matrix(ExtractParameters(stratPosterior1, parameters = "parameters",
                              selectRows = selectRows))
}

# Independent composition: one StratMap() and one Tops() call per draw.
ComposeByDraw <- function(parameters, heights, fromSite, toSite) {
  refRange <- StratoBayes:::.RefSiteHeightRange(stratPosterior1[["data"]], 1)
  vapply(seq_len(nrow(parameters)), function(i) {
    draw <- parameters[i, , drop = FALSE]
    r <- StratMap(stratPosterior1, heights = heights, site = fromSite,
                  parameters = draw, quantiles = "samples")[, 2]
    r <- pmin(pmax(r, refRange[1]), refRange[2])
    tops <- Tops(stratPosterior1, refHeights = r, parameters = draw,
                 quantiles = "samples")
    tops[tops$site == paste0("site_", toSite), 3]
  }, numeric(length(heights)))
}

Site3Width <- function(parameters, heights = c(0.5, 1)) {
  res <- suppressWarnings(
    TopsPlot(stratPosterior1, refHeights = heights, refHeightsSite = 2,
             quantiles = c(0.1, 0.5, 0.9), parameters = parameters,
             display = FALSE)
  )
  top <- res[res$site == "site_3" & res$refId == 1, ]
  unname(diff(top$top[top$quantile %in% c(0.1, 0.9)]))
}

CompositionWidth <- function(parameters, heights = c(0.5, 1)) {
  h3 <- ComposeByDraw(parameters, heights, fromSite = 2, toSite = 3)[1, ]
  unname(diff(quantile(h3, c(0.1, 0.9))))
}

test_that("Tops() output is unchanged by the per-draw refactor", {
  data("stratPosterior1", package = "StratoBayes")
  tops <- Tops(stratPosterior1, refHeights = c(1, 2),
               parameters = PosteriorDraws()[1:40, ],
               quantiles = c(0.1, 0.5, 0.9))
  # values recorded from Tops() before the refactor
  pinned <- c(
    -2.7961094, -0.96487299, -2.2647306, 0.16218637, -2.6756727,
    -0.73930154, -2.1619247, 0.38867996, -2.4789715, -0.60925805,
    -2.0035275, 0.46901585, -2.6621692, -0.76656677, -2.1553756,
    0.35740758, 0.1184149, 0.15660337, 0.098878281, 0.12255709
  )
  expect_equal(
    signif(c(tops[["10%"]], tops[["50%"]], tops[["90%"]], tops$mean,
             tops$sd), 8),
    pinned
  )
})

test_that("noise on the intermediate site widens site 3 (#2449)", {
  data("stratPosterior1", package = "StratoBayes")
  parameters <- PosteriorDraws()[1:120, ]
  set.seed(2449)
  shift <- rnorm(nrow(parameters))

  noisy2 <- parameters
  noisy2[, "alpha_site_2"] <- noisy2[, "alpha_site_2"] + shift
  expected <- CompositionWidth(noisy2)
  expect_equal(Site3Width(noisy2), expected, tolerance = 1e-6)
  # the conditional-on-median answer was an order of magnitude too narrow
  expect_gt(expected, 1)

  noisyBoth <- noisy2
  noisyBoth[, "alpha_site_3"] <- noisyBoth[, "alpha_site_3"] + shift
  expectedBoth <- CompositionWidth(noisyBoth)
  expect_equal(Site3Width(noisyBoth), expectedBoth, tolerance = 1e-6)
  # the shared shift cancels between sites 2 and 3
  expect_lt(expectedBoth, expected / 3)
})

test_that("quantiles do not cross and do not depend on the others (#2307)", {
  data("stratPosterior1", package = "StratoBayes")
  parameters <- PosteriorDraws()[1:60, ]
  Plot <- function(q) {
    suppressWarnings(TopsPlot(stratPosterior1, refHeights = c(1, 2),
                              refHeightsSite = 2, quantiles = q,
                              parameters = parameters, display = FALSE))
  }
  res3 <- Plot(c(0.2, 0.5, 0.8))
  res2 <- Plot(c(0.2, 0.8))

  for (site in levels(res3$site)) {
    for (ref in 1:2) {
      rows <- res3[res3$site == site & res3$refId == ref, ]
      expect_false(is.unsorted(rows$top[order(rows$quantile)]),
                   info = paste(site, ref))
    }
  }
  PickTop <- function(res) {
    res$top[res$site == "site_3" & res$refId == 1 & res$quantile == 0.2]
  }
  expect_equal(PickTop(res2), PickTop(res3))
})

test_that("a draw mapping beyond the reference range is clamped, once warned", {
  data("stratPosterior1", package = "StratoBayes")
  parameters <- PosteriorDraws()[1:60, ]
  expect_warning(
    res <- TopsPlot(stratPosterior1, refHeights = c(1, 2.19),
                    refHeightsSite = 2, quantiles = c(0.1, 0.5, 0.9),
                    parameters = parameters, display = FALSE),
    "draw-by-horizon mappings .* outside the reference site"
  )
  refRange <- StratoBayes:::.RefSiteHeightRange(stratPosterior1[["data"]], 1)
  expect_true(all(res$top[res$site == "site_1"] <= refRange[2]))
})

test_that("clamped draws feed the other panels as the per-draw oracle does", {
  data("stratPosterior1", package = "StratoBayes")
  parameters <- PosteriorDraws()[1:60, ]
  res <- suppressWarnings(
    TopsPlot(stratPosterior1, refHeights = c(1.8, 2.19), refHeightsSite = 2,
             quantiles = c(0.1, 0.5, 0.9), parameters = parameters,
             display = FALSE)
  )
  expected <- ComposeByDraw(parameters, c(1.8, 2.19), fromSite = 2, toSite = 3)
  for (ref in 1:2) {
    top <- res[res$site == "site_3" & res$refId == ref, ]
    expect_equal(unname(top$top[order(top$quantile)]),
                 unname(quantile(expected[ref, ], c(0.1, 0.5, 0.9))),
                 info = paste("horizon", ref))
  }
})
