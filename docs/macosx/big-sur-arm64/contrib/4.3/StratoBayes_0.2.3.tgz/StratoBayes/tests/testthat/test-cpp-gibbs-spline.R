# Tests for the C++ Bayesian-spline Gibbs loop (.sb_gibbs_spline), which powers
# .RunMCMCBspline()/BayesianSpline(). Validated against the retained R reference
# .GibbsSampleBspline().

# Pure-R reference loop (mirrors the pre-C++ .RunMCMCBspline implementation).
.ref_run_bspline <- function(data, model, nIter, nThin = 1) {
  outInd <- seq(1, nIter, nThin); nOut <- length(outInd)
  p <- model[["splineBase"]][["nKnots"]] + 2
  beta <- matrix(NA_real_, nOut, p); sigma <- numeric(nOut); lambda <- numeric(nOut)
  state <- .InitializeGibbsBspline(data, model)
  j <- 0L
  for (i in seq_len(nIter)) {
    state <- .GibbsSampleBspline(data, model, state)
    if (i %in% outInd) {
      j <- j + 1L
      beta[j, ] <- state[["gibbs"]][["beta"]]
      sigma[j]  <- state[["gibbs"]][["sigma"]]
      lambda[j] <- state[["gibbs"]][["lambda"]]
    }
  }
  list(beta = beta, sigma = sigma, lambda = lambda)
}

.make_bspline_model <- function(nKnots = 20, n = 80, lambdaFixed = FALSE) {
  set.seed(303)
  x <- sort(runif(n, 0, 12))
  y <- 0.5 * x + sin(x) + rnorm(n, 0, 0.3)
  d <- data.frame(x = x, y = y)
  d <- d[stats::complete.cases(d), ]
  model <- .ModelBspline(d, nKnots, NULL, 0.01, 0.01, 1, 1000, 0.0001,
                         lambdaFixed, NULL, NULL)
  list(data = d, model = model)
}

.call_cpp_loop <- function(data, model, nIter, nThin = 1) {
  state <- .InitializeGibbsBspline(data, model)
  lf <- isTRUE(model[["lambdaFixed"]])
  .sb_gibbs_spline(
    B = model[["Bspline"]], y = data[["y"]], D = model[[c("splineBase", "D")]],
    sigma0 = state[[c("gibbs", "sigma")]], lambda0 = state[[c("gibbs", "lambda")]],
    aLambda = model[[c("priors", "gibbs", "aLambda")]],
    bLambda = model[[c("priors", "gibbs", "bLambda")]],
    shapeSigma = model[["shapeSigma"]],
    bSigma = model[[c("priors", "gibbs", "bSigma")]],
    numBasis = model[[c("splineBase", "num_basis")]],
    nIter = nIter, outInd = as.integer(seq(1, nIter, nThin)),
    lambdaFixed = lf,
    lambdaFixedValue = if (lf) model[["lambdaFixedValue"]] else 0
  )
}

test_that("single-iteration beta draw matches R reference exactly", {
  bm <- .make_bspline_model()
  state0 <- .InitializeGibbsBspline(bm$data, bm$model)

  # The beta draw happens before any Gamma draw, so the RNG stream is identical
  # and beta should match to numerical (Cholesky) precision.
  set.seed(456)
  ref <- .GibbsSampleBspline(bm$data, bm$model, state0)

  set.seed(456)
  cpp <- .sb_gibbs_spline(
    B = bm$model[["Bspline"]], y = bm$data[["y"]], D = bm$model[[c("splineBase", "D")]],
    sigma0 = state0[[c("gibbs", "sigma")]], lambda0 = state0[[c("gibbs", "lambda")]],
    aLambda = bm$model[[c("priors", "gibbs", "aLambda")]],
    bLambda = bm$model[[c("priors", "gibbs", "bLambda")]],
    shapeSigma = bm$model[["shapeSigma"]],
    bSigma = bm$model[[c("priors", "gibbs", "bSigma")]],
    numBasis = bm$model[[c("splineBase", "num_basis")]],
    nIter = 1L, outInd = 1L, lambdaFixed = FALSE, lambdaFixedValue = 0
  )

  expect_equal(as.numeric(cpp$beta[1, ]), as.numeric(ref[["gibbs"]][["beta"]]),
               tolerance = 1e-6)
})

test_that("C++ loop posterior means match the R reference", {
  bm <- .make_bspline_model()
  nIter <- 3000L; sel <- (nIter / 2 + 1):nIter

  set.seed(99); ref <- .ref_run_bspline(bm$data, bm$model, nIter)
  set.seed(99); cpp <- .call_cpp_loop(bm$data, bm$model, nIter)

  # posterior mean sigma
  expect_equal(mean(cpp$sigma[sel]), mean(ref$sigma[sel]), tolerance = 0.03)

  # posterior mean fitted curve agrees within a small fraction of the noise SD
  ext <- bm$model[["splineBase"]][["ext_knots"]]
  grid <- seq(min(bm$data$x), max(bm$data$x), length.out = 30)
  B <- splines::splineDesign(ext, grid, sparse = FALSE)
  fit_ref <- as.numeric(B %*% colMeans(ref$beta[sel, ]))
  fit_cpp <- as.numeric(B %*% colMeans(cpp$beta[sel, ]))
  expect_lt(max(abs(fit_ref - fit_cpp)), 0.05 * sd(bm$data$y))
})

test_that("thinning yields the expected number of stored iterations", {
  bm <- .make_bspline_model()
  res <- .call_cpp_loop(bm$data, bm$model, nIter = 100L, nThin = 5L)
  expect_equal(length(res$sigma), length(seq(1, 100, 5)))
  expect_equal(nrow(res$beta), length(seq(1, 100, 5)))
  expect_true(all(is.finite(res$sigma)) && all(res$sigma > 0))
  expect_true(all(is.finite(res$lambda)) && all(res$lambda > 0))
})

test_that("fixed lambda is held constant across the chain", {
  set.seed(7)
  x <- sort(runif(80, 0, 12)); y <- 0.5 * x + sin(x) + rnorm(80, 0, 0.3)
  spline <- BayesianSpline(x, y, nKnots = 20, nIter = 200, lambdaFixed = 5)
  expect_true(all(spline$lambda == 5))
})

test_that("BayesianSpline recovers a known smooth signal", {
  set.seed(21)
  x <- seq(0, 8, length.out = 120)
  y <- sin(x) + rnorm(120, 0, 0.15)
  fit <- BayesianSpline(x, y, nKnots = 15, nIter = 1500)
  pred <- PredictSpline(fit, at = x, burnIn = 0.5)
  # fitted posterior mean tracks the true sin(x) closely
  expect_lt(sqrt(mean((pred$mu - sin(x))^2)), 0.1)
})
