# inst/gui/R/data_view_module.R
# Data View module: controls + plot (no run buttons here — those stay in the dialog so IDs remain global)

data_view_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("controls")),
    br(),
    plotOutput(ns("plot"), height = "420px")
  )
}

data_view_server <- function(id, data_api) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    # Controls
    output$controls <- renderUI({
      req(data_api$signalValid())
      sd    <- data_api$stratData()
      req(sd)
      sites <- sd$sites
      sigs  <- data_api$signalCols()

      tagList(
        fluidRow(
          column(3,
                 tags$strong("Sites to display", style = "display:block; margin-bottom:6px;"),
                 div(class = "strat-checklist sb-view-checklist",
                     checkboxGroupInput(ns("viewSiteSelect"), NULL,
                                        choices  = sites,
                                        selected = if (!is.null(input$viewSiteSelect)) input$viewSiteSelect else sites
                     )
                 )
          ),
          column(3,
                 tags$strong("Signals to display", style="display:block; margin-bottom:6px;"),
                 div(class = "strat-checklist sb-view-checklist",
                     checkboxGroupInput(ns("viewSignalSelect"), NULL,
                                        choices  = sigs,
                                        selected = if (!is.null(input$viewSignalSelect)) input$viewSignalSelect else sigs
                     )
                 )
          ),
          column(2,
                 radioButtons(ns("sigPlotType_view"), "Style",
                              c("Pts"="p","Lines"="l","Both"="o"),
                              selected = "l", inline = TRUE
                 )
          ),
          column(4,
                 fluidRow(
                   column(6, sliderInput(ns("viewCex"), "● size", min=0.5, max=5, value=1, step=0.1, width="100%")),
                   column(6, sliderInput(ns("viewLwd"), "— width", min=0.5, max=5, value=2, step=0.5, width="100%"))
                 )
          )
        )
      )
    })

    # Plot
    output$plot <- renderPlot({
      req(data_api$signalValid())
      sd <- data_api$stratData()
      req(sd)

      # Inputs (namespaced)
      req(length(input$viewSiteSelect)   > 0)
      req(length(input$viewSignalSelect) > 0)
      req(!is.null(input$viewCex), !is.null(input$viewLwd))

      sites <- intersect(input$viewSiteSelect, sd$sites)
      sigs  <- input$viewSignalSelect
      nSig  <- length(sigs)
      nSites <- length(sites)

      # Validate mfrow parameters
      if (nSig < 1 || nSites < 1) {
        return(plot.new() + title("Please select at least one site and one signal"))
      }

      oldp <- par(mfrow = c(nSig, nSites)); on.exit(par(oldp), add = TRUE)

      for (i in seq_along(sigs)) {
        sig_idx <- match(sigs[i], sd$signalAttr$signalNames)
        common  <- list(
          cex  = input$viewCex,
          lwd  = input$viewLwd,
          type = if (!is.null(input$sigPlotType_view)) input$sigPlotType_view else "l"
        )
        do.call(plot, c(list(x = sd, signal = sig_idx, sites = sites, overridePar = FALSE), common))
      }
    })
  })
}
