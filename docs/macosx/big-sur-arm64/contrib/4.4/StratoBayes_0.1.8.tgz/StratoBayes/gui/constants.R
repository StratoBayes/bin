# Define constants used in shiny app

# Default debounce period for input sliders etc.
aJiffy <- 42 # ms
typingJiffy <- 2.5 * aJiffy # slightly slower if might be typing
