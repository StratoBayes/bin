## inst/gui/dialog/modelSelectionModal.R
modelSelectionModal <- function() {
  modalDialog(
    title = NULL,
    size = "l",
    fade = FALSE,
    easyClose = FALSE,

    # View 1: Load data screen
    conditionalPanel(
      "output.modalView === 'load'",
      fluidPage(
        fluidRow(
          column(6,
                 # Load options on the left
                 tags$div(
                   style = "margin-bottom: 20px;",
                   # Option 1: Load signal source (always shown)
                   tags$div(
                     style = "margin-bottom: 15px; padding: 10px; background-color: #e8f5e9; border-radius: 5px;",
                     tags$strong("Option 1: Load signal source"),
                     tags$p("Load data from a file or example dataset.", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                     conditionalPanel(
                       "!output.loadedSavedDataset",
                       selectInput("dataSource", "Signal source",
                                  c("Data file" = "file",
                                    "Example dataset 1" = "example-signal-1.csv",
                                    "Example dataset 2" = "00-ohio-3-wells.csv")
                       ),

                       # only show this when the user picks "file"
                       conditionalPanel(
                         "input.dataSource === 'file'",
                         fileInput("dataFile",
                                  "Browse CSV or LAS files",
                                  accept = c(".csv", ".xls", ".xlsx", ".las"),
                                  multiple = TRUE
                         ),

                         # Excel‐options only if it *looks* like Excel
                         conditionalPanel(
                           "input.dataFile && input.dataFile.name.match(/\\.xls[x]?$/)",
                           selectInput("readxl.sheet", "Excel sheet to read:", choices = NULL),
                           numericInput("readxlSkip",     "Skip rows",    min = 0, value = 1),
                           numericInput("readxlSkipCols", "Skip columns", min = 0, value = 1)
                         )
                       )
                     ),
                     conditionalPanel(
                       "output.loadedSavedDataset",
                       tags$div(
                         style = "padding: 10px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;",
                         tags$strong("Saved dataset loaded"),
                         br(),
                         tags$p("Current data is from a saved dataset.", style = "font-size: 0.9em; margin-top: 5px;"),
                         actionButton("loadNewSignalSource", "Load New Signal Source",
                                     class = "btn-sm btn-warning",
                                     style = "margin-top: 5px;",
                                     icon = icon("refresh"))
                       )
                     )
                   ),

                   # Option 2: Load saved dataset (only if available)
                   conditionalPanel(
                     "output.savedDatasetsCount > 0",
                     tags$div(
                       style = "margin-bottom: 15px; padding: 10px; background-color: #e3f2fd; border-radius: 5px;",
                       tags$strong("Option 2: Load saved dataset"),
                       tags$p("Load a previously saved dataset with all settings and partitions.", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                       uiOutput("savedDatasetsSelector"),
                       actionButton("loadDataset", "Load Dataset",
                                   class = "btn-sm btn-success",
                                   style = "margin-top: 5px;")
                     )
                   ),

                   # Option 3: Load data from saved result (only if available)
                   conditionalPanel(
                     "output.savedResultsCount > 0",
                     tags$div(
                       style = "margin-bottom: 15px; padding: 10px; background-color: #f3e5f5; border-radius: 5px;",
                       tags$strong("Option 3: Load data from saved result"),
                       tags$p("Load data from a StratPosterior object (e.g., stratPosterior0$data).", style = "font-size: 0.9em; color: #666; margin-top: 5px;"),
                       uiOutput("savedResultsForDataSelector"),
                       actionButton("loadDataFromResult", "Load Data from Result",
                                   class = "btn-sm btn-info",
                                   style = "margin-top: 5px;")
                     )
                   )
                 )
          ),

          column(6,
                 # Column selection and settings on the right - show when file is selected or data is loaded
                 conditionalPanel(
                   "output.hasDataOrFile",
                   # dynamic siteColumn
                   uiOutput("siteColumn_ui"),

                   # Header on its own line:
                   tags$div(
                     style = "margin-bottom: 0.25em;",
                     tags$strong("Sites to include")
                   ),

                   # Then the checkboxes with natural wrapping:
                   div(
                     class = "strat-checklist",
                     checkboxGroupInput(
                       "loadSiteSelect",
                       label    = NULL,
                       choices  = NULL,
                       selected = NULL
                     )
                   ),

                   # dynamic zColumn
                   uiOutput("zColumn_ui"),
                   # dynamic signalColumns
                   uiOutput("signalColumns_ui"),

                   # Height/Depth scale selection for data loading
                   radioButtons("dataScale", "Scale",
                               c("Height"="height","Depth"="depth"),
                               selected="height", inline=TRUE
                   ),

                   # Partition source selection
                   selectInput("partitionSource", "Partition source",
                              c("No partitions" = "none",
                                "Upload CSV" = "csv",
                                "Auto partitions" = "auto",
                                "Point & Click" = "interactive"),
                              selected = "none"
                   ),

                   # Conditional panel for CSV partition upload
                   conditionalPanel(
                     "input.partitionSource === 'csv'",
                     fileInput("partitionFile",
                              "Browse partition CSV file",
                              accept = c(".csv")
                     ),
                     helpText("CSV should contain columns: site, height/depth, partition")
                   ),

                   # Conditional panel for Auto partitions
                   conditionalPanel(
                     "input.partitionSource === 'auto'",
                     numericInput("nStrata", "Number of strata",
                                 value = 2, min = 1, max = 8, step = 1),
                     selectInput("distributeMethod", "Distribution method",
                                c("Equal points" = "points",
                                  "Equal height" = "height"),
                                selected = "points"),
                     helpText("Automatically creates partitions based on number of strata"),
                     br(),
                     actionButton("addAutoPartitions", "Add Partitions",
                                 class = "btn-success",
                                 style = "width: 100%;")
                   ),

                   # Conditional panel for Point & Click partitions
                   conditionalPanel(
                     "input.partitionSource === 'interactive'",
                     actionButton("createPartitions", "Create Partition Tops",
                                 icon = icon("mouse-pointer"),
                                 class = "btn-info")
                   )
                 )
          )
        ),

        # Preview table below both columns (full width)
        fluidRow(
          column(12,
                 tags$h4("Data Preview"),
                 div(style = "overflow-x: auto; width: 100%;",
                     tableOutput("dataHead")
                 )
          )
        ),

        # Action buttons below preview table (full width)
        conditionalPanel(
          "output.signalValid",
          fluidRow(
            column(12,
              div(
                style = "text-align: center; margin-top: 20px;",
                tags$h4("Choose your next step:"),
                br(),
                actionButton("showSaveData", "Save Data",
                            class = "btn-warning",
                            style = "margin-right: 10px;",
                            icon = icon("save")),
                # Inline save data field (appears when showSaveData is clicked)
                conditionalPanel(
                  "output.showSaveDataField",
                  tags$div(
                    style = "margin-top: 15px; padding: 15px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;",
                    fluidRow(
                      column(8,
                        textInput("saveDataNameInput", "Dataset name:",
                                 value = "",
                                 placeholder = "Enter a name (or leave empty for auto-name)",
                                 width = "100%")
                      ),
                      column(4,
                        actionButton("confirmSaveData", "Save",
                                   class = "btn-primary",
                                   style = "margin-top: 25px; width: 100%;"),
                        actionButton("cancelSaveData", "Cancel",
                                   class = "btn-secondary",
                                   style = "margin-top: 5px; width: 100%;")
                      )
                    )
                  )
                ),
                actionButton("lookAtData", "Look at Data",
                            class = "btn-info",
                            style = "margin-right: 10px;",
                            icon = icon("eye")),
                actionButton("quickRun", "Quick Run",
                            class = "btn-success",
                            style = "margin-right: 10px;",
                            icon = icon("bolt")),
                actionButton("customRun", "Custom Run",
                            class = "btn-primary",
                            icon = icon("cog"))
              )
            )
          )
        )
      )
    ),

    # View 2: Data preview screen (uses data_view_module)
    conditionalPanel(
      "output.modalView === 'view'",
      fluidPage(
        tags$h3("View Data"),
        helpText("Choose what to display, then run or adjust the model."),
        conditionalPanel(
          "output.signalValid",
          # Module UI (controls + plot)
          data_view_ui("dataview"),
          br(),
          # Bottom-right actions: use unique IDs for view panel buttons
          fluidRow(
            column(12,
                   div(
                     style = "display:flex; justify-content:flex-end; gap:10px;",
                     actionButton("quickRun_view", "Quick Run",
                                 class = "btn-success",
                                 icon = icon("bolt")),
                     actionButton("customRun_view", "Custom Run",
                                 class = "btn-info",
                                 icon = icon("cog"))
                   )
            )
          )
        ),
        conditionalPanel(
          "!output.signalValid",
          tags$p("No valid data to display yet.")
        )
      )
    ),


    # View 3: Custom run panel (no tabs, single view)
    conditionalPanel(
      "output.modalView === 'customRun'",
      fluidPage(
        # Saved model settings selector (moved from load view)
        conditionalPanel(
          "output.savedModelSettingsCount > 0",
          tags$div(
            style = "margin-bottom: 15px; padding: 10px; background-color: #e3f2fd; border-radius: 5px;",
            tags$strong("Load saved model settings"),
            uiOutput("savedModelSettingsSelector"),
            actionButton("loadModelSettings", "Load Settings",
                        class = "btn-sm btn-success",
                        style = "margin-top: 5px;")
          )
        ),

        # Model setup tabs
        tabsetPanel(
          id = "modelTabs",
          tabPanel("Model structure", value = "structure",
                   fluidRow(
                     column(6,
                            selectInput("alignmentScale", "Alignment scale",
                                       c("Height" = "height")),
                            selectInput("sedModel", "Sedimentation model",
                                       c("Site" = "site",
                                         "Partition" = "partition",
                                         "Site × Partition" = "site x partition",
                                         "Site, Partition" = "site, partition")),
                            selectInput("alphaPosition", "Alpha position",
                                       c("Top" = "top",
                                         "Middle" = "middle",
                                         "Bottom" = "bottom",
                                         "Custom" = "custom"),
                                       selected = "middle"),
                            # Conditional panel for custom alpha numeric inputs
                            conditionalPanel(
                              "input.alphaPosition === 'custom'",
                              uiOutput("customAlphaInputs"),
                              actionButton("updateAlphaPositions", "Update alphas",
                                          class = "btn-primary",
                                          style = "margin-top: 10px;")
                            )
                     ),
                     column(6,
                            uiOutput("siteModelNote")
                     )
                   ),
                   br(),
                   plotOutput("structureSignal", height = "420px")
          ),
          tabPanel("Priors", value = "prior",
                   uiOutput("priorUI"),
                   br(),
                   plotOutput("priorSignal", height = "420px")
          ),
          tabPanel("Run", value = "run",
                   uiOutput("runUI"),
                   br(),
                   fluidRow(
                     column(6,
                            numericInput("nRun", "Number of runs", value = 1, min = 1, max = 10, step = 1),
                            numericInput("nIter", "Iterations", value = 1000, min = 100, step = 100),
                            numericInput("nThin", "Thinning", value = 1, min = 1, step = 1)
                     ),
                     column(6,
                            numericInput("nChains", "Chains", value = 8, min = 1, max = 100, step = 1),
                            br(),
                            textInput("saveModelSettingsName", "Save settings as (optional):",
                                    placeholder = "Leave empty for auto-name"),
                            br(),
                            actionButton("runModel", "Run Model",
                                       class = "btn-primary btn-lg",
                                       style = "width: 100%;")
                     )
                   ),
                   br(),
                   uiOutput("runIframeUI")
          )
        )
      )
    ),

    footer = tagList(
      # Previous button - only show when NOT in load view
      conditionalPanel(
        "output.modalView !== 'load'",
        actionButton("previousStep", "Back", class = "btn-secondary", style = "float: left;")
      ),
      # Look at Data button - shown when in customRun view
      conditionalPanel(
        "output.modalView === 'customRun'",
        actionButton("lookAtDataFromModal", "Look at Data",
                    class = "btn-info",
                    style = "float: left; margin-left: 10px;",
                    icon = icon("eye"))
      ),
      # Next button - only show when NOT in load view and NOT in view (View Data) view
      conditionalPanel(
        "output.modalView !== 'load' && output.modalView !== 'view'",
        div(style = "float: right; margin-right: 10px;",
            actionButton("nextStep", "Next", class = "btn-primary")
        )
      ),
      # Close button - always visible, always on the right
      div(style = "float: right;",
          actionButton("closeModal", "Close", class = "btn-default")
      )
    )
  )
}
