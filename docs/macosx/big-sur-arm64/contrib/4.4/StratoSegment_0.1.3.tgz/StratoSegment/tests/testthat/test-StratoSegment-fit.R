test_that("StratoSegment returns a StratoSegment object with expected names", {
  sim <- make_test_sim()
  fit <- StratoSegment(
    sim$y,
    depth = sim$depth,
    K = 2L,
    minSegLen = 5L,
    minObsPerCurve = 3L
  )
  expect_s3_class(fit, "StratoSegment")
  expect_named(
    fit,
    c(
      "y", "y_fit", "depth", "n", "p", "K", "requested_K",
      "min_seg_len", "min_seg_depth", "min_seg_frac", "min_obs_per_curve",
      "standardize", "center", "scale", "slope_penalty",
      "changepoints", "changepoint_depths",
      "segment_starts", "segment_ends",
      "objective", "cost_matrix", "dp", "coefficients",
      "fitted", "residuals", "segment_summary"
    )
  )
  expect_equal(fit$n, nrow(sim$y))
  expect_equal(fit$p, ncol(sim$y))
  expect_equal(dim(fit$cost_matrix), c(fit$n, fit$n))
  expect_true(is.finite(fit$objective))
})

test_that("numeric vector y is a single curve", {
  set.seed(1L)
  v <- rnorm(50)
  fit <- StratoSegment(v, depth = NULL, K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_equal(fit$p, 1L)
  expect_equal(ncol(fit$y), 1L)
  expect_equal(nrow(fit$y), 50L)
  expect_equal(fit$depth, seq_len(50L))
  d <- sort(runif(50))
  fit2 <- StratoSegment(v, depth = d, K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_equal(fit2$depth, d)
})

test_that("K = 0 yields no changepoints and finite objective", {
  sim <- make_test_sim(n = 80L, changepoints = integer(0), seed = 1L)
  fit <- StratoSegment(sim$y, depth = sim$depth, K = 0L, minSegLen = 3L, minObsPerCurve = 2L)
  expect_equal(length(fit$changepoints), 0L)
  expect_true(is.finite(fit$objective))
  expect_equal(fit$segment_starts, 1L)
  expect_equal(fit$segment_ends, fit$n)
})

test_that("default depth is seq_len(n) when depth is NULL", {
  sim <- make_test_sim(n = 50L, p = 1L, changepoints = c(20L), seed = 3L)
  fit <- StratoSegment(sim$y, depth = NULL, K = 1L, minSegLen = 4L, minObsPerCurve = 2L)
  expect_equal(fit$depth, seq_len(nrow(sim$y)))
})

test_that("standardize = FALSE still completes", {
  sim <- make_test_sim()
  fit <- StratoSegment(
    sim$y,
    depth = sim$depth,
    K = 1L,
    minSegLen = 5L,
    minObsPerCurve = 3L,
    standardize = FALSE
  )
  expect_s3_class(fit, "StratoSegment")
  expect_false(fit$standardize)
  expect_true(all(fit$center == 0))
  expect_true(all(fit$scale == 1))
})

test_that("residuals match y - fitted on non-NA cells", {
  sim <- make_test_sim()
  fit <- StratoSegment(sim$y, sim$depth, K = 1L, minSegLen = 5L, minObsPerCurve = 3L)
  idx <- !is.na(sim$y)
  expect_equal(fit$residuals[idx], (sim$y - fit$fitted)[idx], tolerance = 1e-10)
})

test_that("internal NA values are handled in y", {
  sim <- make_test_sim(n = 120L, p = 2L, changepoints = c(50L), seed = 7L)
  sim$y[45:55, 1] <- NA_real_
  fit <- expect_no_error(
    StratoSegment(sim$y, sim$depth, K = 1L, minSegLen = 8L, minObsPerCurve = 3L)
  )
  expect_s3_class(fit, "StratoSegment")
})

test_that("infeasibly large K triggers reduction warning", {
  sim <- make_test_sim(n = 15L, p = 1L, changepoints = integer(0), seed = 1L)
  # Assign inside expect_warning(); do not `fit <- expect_warning(StratoSegment(...))`
  # because expect_warning() may not return the evaluated value (then fit is NULL).
  expect_warning(
    fit <- StratoSegment(sim$y, sim$depth, K = 10L, minSegLen = 5L, minObsPerCurve = 2L),
    "reducing K"
  )
  expect_equal(fit$requested_K, 10L)
  expect_equal(fit$K, 2L) # floor(15/5) - 1 changepoints
})

test_that("obvious shared changepoint is found near the true row", {
  set.seed(7L)
  n <- 400L
  true_cp <- 200L
  depth <- seq_len(n)
  y <- matrix(NA_real_, nrow = n, ncol = 2L)
  colnames(y) <- c("a", "b")
  for (j in 1:2) {
    y[seq_len(true_cp), j] <- -10 + rnorm(true_cp, sd = 0.1)
    y[(true_cp + 1L):n, j] <- 10 + rnorm(n - true_cp, sd = 0.1)
  }
  fit <- StratoSegment(
    y,
    depth = depth,
    K = 1L,
    minSegLen = 30L,
    minObsPerCurve = 5L,
    minSegDepth = 0,
    minSegFrac = NULL
  )
  expect_equal(fit$K, 1L)
  expect_true(length(fit$changepoints) == 1L)
  # Changepoint row = last index of first segment; depth is 1:n so same tolerance in depth units.
  expect_true(abs(fit$changepoints[1L] - true_cp) <= 12L)
})
