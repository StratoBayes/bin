test_that("simulate_welllog_trend returns expected structure", {
  out <- simulate_welllog_trend(n = 100L, p = 2L, changepoints = c(30L, 70L), seed = 1L)
  expect_named(out, c("y", "depth", "true_changepoints", "true_coefficients"))
  expect_equal(dim(out$y), c(100L, 2L))
  expect_equal(out$depth, seq_len(100L))
  expect_equal(out$true_changepoints, c(30L, 70L))
  expect_equal(dim(out$true_coefficients)[1], 3L) # 3 segments
})

test_that("StratoSegmentData uses DEPTH column by default", {
  df <- data.frame(
    DEPTH = seq(100, 280, length.out = 40),
    GR = rnorm(40),
    RHOB = rnorm(40)
  )
  fit <- StratoSegmentData(df, K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_s3_class(fit, "StratoSegment")
  expect_equal(fit$depth, df$DEPTH)
  expect_equal(ncol(fit$y), 2L)
})

test_that("StratoSegmentData respects depthCol", {
  df <- data.frame(
    MD = 1:20,
    v1 = rnorm(20),
    v2 = rnorm(20)
  )
  fit <- StratoSegmentData(df, depthCol = "MD", K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_equal(fit$depth, df$MD)
})
