.MakeDuringMCMCFixture <- function(stratPosterior, run = 1, iterationRow = 1) {
  model <- stratPosterior[["model"]]
  data <- stratPosterior[["data"]]
  paramNames <- model[["outputParams"]]
  allNames <- c("iteration", "chain", paramNames)

  lastVals <- stratPosterior[["samples"]][201, , run, 1]

  samples <- array(NA_real_, dim = c(1, length(allNames), 1, 1))
  dimnames(samples) <- list(NULL, allNames, "run1", "chain1")
  samples[iterationRow, "iteration", 1, 1] <- 201
  samples[iterationRow, "chain", 1, 1] <- 1
  samples[iterationRow, paramNames, 1, 1] <- lastVals

  nSect <- data[["S"]]
  sectionCol <- hcl.colors(nSect, "Dark 3", alpha = 1)
  allowedSymbols <- 21:25
  sectionSymbol <- allowedSymbols[(1:nSect - 1) %% length(allowedSymbols) + 1]

  list(data = data, model = model, mcmc = list(nIter = 5000), samples = samples,
       sectionCol = sectionCol, sectionSymbol = sectionSymbol)
}

test_that(".PlotSignal skips plotting instead of crashing for an all-NA signal column", {
  fixture <- .MakeDuringMCMCFixture(stratPosterior1)
  fixture$data[["signal"]][["value"]] <- NA_real_

  png(tempfile())
  result <- expect_no_error(
    suppressWarnings(
      StratoBayes:::.PlotSignal(fixture$data, fixture$model, fixture$mcmc,
                                fixture$samples, run = 1, sig = 1,
                                plotIterRowAll = 1L,
                                fixture$sectionCol, fixture$sectionSymbol, 1)
    )
  )
  dev.off()

  expect_null(result)
})

test_that(".PlotDuringMCMC's non-parallel run selection excludes runs with all-NA samples", {
  # mirrors the filtering logic at the top of .PlotDuringMCMC: in the
  # non-parallel branch, runsForSignalPlot must skip a run whose
  # plotIterRowAll entry is not finite (e.g. an all-NA sample array from an
  # I/O failure), just like the parallel branch already does.
  plotIterRowAll <- c(-Inf, 42)

  run <- 1
  runsForSignalPlot <- if (is.finite(plotIterRowAll[run])) run else integer(0)
  expect_length(runsForSignalPlot, 0L)

  run <- 2
  runsForSignalPlot <- if (is.finite(plotIterRowAll[run])) run else integer(0)
  expect_equal(runsForSignalPlot, 2)
})

test_that("a .PlotDuringMCMC failure does not kill the MCMC run (RT-062)", {
  # RT-062: previously .PlotDuringMCMC was called with no tryCatch, so any
  # plotting error (closed device, all-NA state, etc.) propagated all the way
  # up and terminated the run. It must now be caught and merely warned about.
  callCount <- 0
  testthat::local_mocked_bindings(
    .PlotDuringMCMC = function(...) {
      callCount <<- callCount + 1
      stop("simulated plot failure")
    },
    .package = "StratoBayes"
  )

  warnMessages <- character(0)
  r1 <- withCallingHandlers(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                  nChains = 2, visualise = TRUE, seed = 1),
    warning = function(w) {
      warnMessages <<- c(warnMessages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  expect_s3_class(r1, "StratPosterior")
  expect_gt(callCount, 0)
  expect_true(any(grepl("Plot update failed during MCMC", warnMessages, fixed = TRUE)))
})

test_that("RT-306: a plotting exception between .SavePng and .CloseAndRenamePng does not leak the png() device or its temp file", {
  saveVisualiseDir <- withr::local_tempdir()
  devicesBefore <- length(dev.list())

  for (cycle in 1:5) {
    pngFilenameTemp <- StratoBayes:::.SavePng(
      isParallel = TRUE, saveVisualiseDir = saveVisualiseDir, modelName = "m",
      info1 = "run_1", info2 = paste0("sig_", cycle), info3 = "task_1"
    )
    expect_false(is.null(pngFilenameTemp))

    expect_error(
      StratoBayes:::.PlotWithDeviceCleanup(
        isParallel = TRUE, pngFilenameTemp = pngFilenameTemp,
        plotFn = function() stop("simulated plot failure")
      ),
      "simulated plot failure"
    )

    # the device opened by .SavePng must be closed by the cleanup, so the
    # count of open devices never grows across repeated failing cycles
    expect_equal(length(dev.list()), devicesBefore)
    # and the orphaned _temp.png must not be left behind
    expect_false(file.exists(pngFilenameTemp))
  }

  expect_length(list.files(saveVisualiseDir), 0L)
})

test_that("RT-309: .SanitizeFilenameComponent guards Windows-reserved base names", {
  # reserved names, with and without an extension, in mixed case
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("NUL"), "NUL_")
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("nul"), "nul_")
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("Con"), "Con_")
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("COM3"), "COM3_")
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("lpt9"), "lpt9_")

  # non-reserved names are untouched (beyond the existing character strip)
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("alpha"), "alpha")
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("beta_signal_1"), "beta_signal_1")
  # a reserved name only as a substring is not flagged
  expect_equal(StratoBayes:::.SanitizeFilenameComponent("annulment"), "annulment")
})

test_that("RT-307: an unopenable png() device causes .SavePng to return NULL (call sites skip drawing rather than draw onto the wrong device)", {
  saveVisualiseDir <- withr::local_tempdir()

  # simulate .SavePng's internal open failure by pointing it at a
  # directory that cannot contain the file (forces try()'s error branch)
  badDir <- file.path(saveVisualiseDir, "does_not_exist")
  pngFilenameTemp <- StratoBayes:::.SavePng(
    isParallel = TRUE, saveVisualiseDir = badDir, modelName = "m",
    info1 = "run_1", info2 = "sig_1", info3 = "task_1"
  )
  expect_null(pngFilenameTemp)
})

test_that(".SavePng checks the target directory exists up front, rather than relying on png()'s platform-dependent error behaviour", {
  # grDevices::png() does not fail synchronously on every platform when
  # pointed at a non-existent directory (confirmed: throws a try-error on
  # Windows, but opens without error on the Linux/cairo backend used by
  # check-gha), which made the RT-307 test above pass on Windows and fail
  # on Linux. An explicit dir.exists() check up front is deterministic
  # across platforms and is also cheaper than always attempting the open.
  saveVisualiseDir <- withr::local_tempdir()
  badDir <- file.path(saveVisualiseDir, "does_not_exist")

  expect_no_warning(
    pngFilenameTemp <- StratoBayes:::.SavePng(
      isParallel = TRUE, saveVisualiseDir = badDir, modelName = "m",
      info1 = "run_1", info2 = "sig_1", info3 = "task_1"
    )
  )
  expect_null(pngFilenameTemp)
})

test_that("#504/#505: layout() panel count matches the number of plots .PlotDuringMCMC actually draws, for any nPlotSignal", {
  fixture <- .MakeDuringMCMCFixture(stratPosterior1)

  capturedMatrix <- NULL
  drawCount <- 0
  testthat::local_mocked_bindings(
    layout = function(mat, ...) { capturedMatrix <<- mat; invisible(1) },
    .CompileSamplesDuringMCMC = function(...) fixture$samples,
    .PlotWithDeviceCleanup = function(isParallel, pngFilenameTemp, plotFn) {
      drawCount <<- drawCount + 1
      invisible(NULL)
    },
    .package = "StratoBayes"
  )

  for (nPlotSignal in 1:5) {
    capturedMatrix <- NULL
    drawCount <- 0
    modelDir <- withr::local_tempdir()
    saveVisualiseDir <- withr::local_tempdir()
    StratoBayes:::.PlotDuringMCMC(
      data = fixture$data, model = fixture$model, mcmc = fixture$mcmc,
      modelDir = modelDir, modelName = "m", saveVisualiseDir = saveVisualiseDir,
      nRun = 1, run = 1, isParallel = FALSE,
      visualise = list(signal = rep(1, nPlotSignal), parameter = 1),
      colourScale = "Dark 3", i = 1
    )
    # the layout must cover exactly 1..drawCount with no gaps or repeats --
    # setequal (rather than just comparing max()) catches a matrix that
    # skips or duplicates a panel index while still reporting the right max
    expect_setequal(as.vector(capturedMatrix), seq_len(drawCount))
    expect_equal(drawCount, nPlotSignal + 2, info = paste("nPlotSignal =", nPlotSignal))
    expect_equal(nrow(capturedMatrix), 2, info = paste("nPlotSignal =", nPlotSignal))
    if (nPlotSignal >= 3) {
      # the two parameter plots (posterior, then the truncated parameter)
      # must land in the bottom row, not be transposed with the signal row
      expect_equal(capturedMatrix[2, 1], nPlotSignal + 1L,
                   info = paste("nPlotSignal =", nPlotSignal))
    }
  }
})

test_that("#506: .CloseAndRenamePng warns rather than silently failing when file.rename() returns FALSE", {
  saveVisualiseDir <- withr::local_tempdir()
  pngFilenameTemp <- StratoBayes:::.SavePng(
    isParallel = TRUE, saveVisualiseDir = saveVisualiseDir, modelName = "m",
    info1 = "run_1", info2 = "sig_1", info3 = "task_1"
  )
  expect_false(is.null(pngFilenameTemp))
  # a cairo png() only writes the file once a page is drawn; without this the
  # temp never exists and the rename would fail for the wrong reason
  plot.new()

  testthat::local_mocked_bindings(
    file.rename = function(...) FALSE,
    .package = "base"
  )

  warnMessages <- character(0)
  withCallingHandlers(
    StratoBayes:::.CloseAndRenamePng(
      isParallel = TRUE, pngFilenameTemp = pngFilenameTemp,
      saveVisualiseDir = saveVisualiseDir, modelName = "m", info1 = "run_1", info2 = "sig_1"
    ),
    warning = function(w) {
      warnMessages <<- c(warnMessages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  expect_true(any(grepl("Failed to rename live-plot PNG", warnMessages, fixed = TRUE)))
})

test_that(".CloseAndRenamePng stays silent when file.rename() succeeds", {
  saveVisualiseDir <- withr::local_tempdir()
  pngFilenameTemp <- StratoBayes:::.SavePng(
    isParallel = TRUE, saveVisualiseDir = saveVisualiseDir, modelName = "m",
    info1 = "run_1", info2 = "sig_1", info3 = "task_1"
  )
  expect_false(is.null(pngFilenameTemp))
  plot.new()  # cairo writes no file until a page is drawn

  expect_no_warning(
    StratoBayes:::.CloseAndRenamePng(
      isParallel = TRUE, pngFilenameTemp = pngFilenameTemp,
      saveVisualiseDir = saveVisualiseDir, modelName = "m", info1 = "run_1", info2 = "sig_1"
    )
  )
  expect_true(file.exists(file.path(saveVisualiseDir, "m_plot_run_1_sig_1.png")))
})

test_that(".CloseAndRenamePng stays silent when the plot function drew nothing", {
  # .PlotSignal / .PlotParameter return early on a non-finite range, leaving the
  # device open but empty.  A cairo png() then writes no file at all, so the
  # rename has no source -- that is not a failure worth warning about.
  saveVisualiseDir <- withr::local_tempdir()
  nDevBefore <- length(grDevices::dev.list())
  pngFilenameTemp <- StratoBayes:::.SavePng(
    isParallel = TRUE, saveVisualiseDir = saveVisualiseDir, modelName = "m",
    info1 = "run_1", info2 = "sig_1", info3 = "task_1"
  )
  expect_false(is.null(pngFilenameTemp))

  expect_no_warning(
    StratoBayes:::.CloseAndRenamePng(
      isParallel = TRUE, pngFilenameTemp = pngFilenameTemp,
      saveVisualiseDir = saveVisualiseDir, modelName = "m", info1 = "run_1", info2 = "sig_1"
    )
  )
  # the early return must not skip dev.off()
  expect_equal(length(grDevices::dev.list()), nDevBefore)
})
