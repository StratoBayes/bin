# RT-743 (#1075): GibbsSpline.cpp's post-Cholesky recovery floor on lambda.
#
# The `BayesianSpline()` Gibbs recursion is exactly equivariant under
# y -> c*y once the three absolute prior constants are co-scaled
# (bSigma -> c^2 bSigma, 1/bLambda -> c^2/bLambda, lambda -> lambda/c^2):
# M = B'B/sigma^2 + lambda*D -> M/c^2, so beta -> c*beta on the same RNG
# stream. Any surviving dependence on c is an absolute constant biting.
#
# `lambdaFixed = 0` with numBasis > n makes M singular by construction, so the
# recovery branch fires at every scale -- and that is the branch the floor
# lives in. With the pre-#1075 absolute floor the recovered draw was inert at
# unit scale and penalty-dominated at y-scale 1e4: `beta` disagreed by a factor
# of 125 (1e4) and 1.06e4 (1e6). These cases fail if the floor reverts to an
# absolute constant.

.spline1075 <- function() {
  set.seed(743)
  x <- seq(0, 1, length.out = 12L)
  list(x = x, y = sin(2 * pi * x) + stats::rnorm(12L, 0, 0.05))
}

# A pinned lambda keeps M's conditioning identical across scales, so the fits
# differ only where an absolute constant enters.
.fit1075 <- function(cc, lambdaFixed, nIter = 100L) {
  d <- .spline1075()
  set.seed(1)
  suppressWarnings(
    BayesianSpline(x = d[["x"]], y = d[["y"]] * cc, nKnots = 25L,
                   nIter = nIter, aSigma = 0.01, bSigma = 0.01 * cc^2,
                   aLambda = 1, bLambda = 1000 / cc^2,
                   lambdaInitial = lambdaFixed, lambdaFixed = lambdaFixed))
}

.relDiff1075 <- function(a, b) {
  d <- abs(a - b) / pmax(abs(b), .Machine[["double.xmin"]])
  # An all-non-finite `d` scores Inf, not -Inf: max() over an empty finite
  # subset would otherwise pass expect_lt() vacuously on an all-NaN result --
  # exactly the failure mode a broken near-singular recovery would produce.
  if (!any(is.finite(d))) return(Inf)
  max(d[is.finite(d)])
}

test_that("#1075: the fixture really does reach the recovery branch", {
  d <- .spline1075()
  expect_warning(
    BayesianSpline(x = d[["x"]], y = d[["y"]], nKnots = 25L, nIter = 20L,
                   lambdaInitial = 0, lambdaFixed = 0),
    "indefinite")
})

test_that("#1075: the recovery floor is scale-free, not absolute", {
  base <- .fit1075(1, 0)[["beta"]]

  # Pre-fix: 124.8 at 1e4 and 1.06e4 at 1e6, against ~6e-4 with a relative
  # floor. The tolerance is 100x the observed residual, and still 5 orders
  # below the absolute floor's smallest departure.
  for (cc in c(1e2, 1e4, 1e6)) {
    expect_lt(.relDiff1075(.fit1075(cc, 0)[["beta"]] / cc, base), 0.05)
  }
})

test_that("#1075: the recovery floor stays far below an honest lambda", {
  # The scale-freedom cases above fix the floor's FORM but say nothing about
  # its magnitude: LAMBDA_FLOOR_REL = 1e-4 passes every one of them. This
  # bounds the magnitude instead. The recovered draw is monotonically less
  # penalised as lambda falls, so a floored lambdaFixed = 0 fit that comes back
  # with a LARGER amplitude than an unfloored fit at lambdaFixed = 1e-12 places
  # the floor below 1e-12 -- seven orders under this fixture's honest lambda
  # (.LambdaStar = 3.1e-5, and an estimated-lambda run visits 8e-5 to 3e-2).
  # Measured floor at iteration 1: 5.8e-16. At LAMBDA_FLOOR_REL = 1e-4 it would
  # be 5.8e-10, above 1e-12, and this inequality reverses.
  floored <- max(abs(.fit1075(1, 0)[["beta"]]))
  honest <- max(abs(.fit1075(1, 1e-12)[["beta"]]))
  expect_gt(floored, honest)

  # `floored > honest` alone stays true if the floor is deleted outright --
  # deletion only pushes `floored` further above `honest`. On this fixture the
  # floor holds `floored` at ~6.9e6; LAMBDA_FLOOR_REL = 0 (no floor at all)
  # lets it run to ~4.2e7, a 6.1x jump with no error or warning change. 1.5e7
  # sits between the two, geometric-mean-ish, to absorb LAPACK/platform
  # variation on this rank-deficient (kappa ~ 1e12) solve.
  expect_lt(floored, 1.5e7)
})

test_that("#1075: a fit that never fails the Cholesky is untouched", {
  # lambda pinned just clear of the failure regime: the recovery branch is not
  # entered, so the floor -- of either form -- must be invisible.
  base <- .fit1075(1, 1e-9)
  fit <- .fit1075(1e4, 1e-9 / 1e8)

  expect_lt(.relDiff1075(fit[["beta"]] / 1e4, base[["beta"]]), 1e-6)
  expect_lt(.relDiff1075(fit[["sigma"]] / 1e4, base[["sigma"]]), 1e-6)
})
