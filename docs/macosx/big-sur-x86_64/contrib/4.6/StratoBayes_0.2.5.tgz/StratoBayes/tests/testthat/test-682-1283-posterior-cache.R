# Regression tests for area-10 posterior-cache and accessor hygiene:
# #689, #1281, #682, #683, #687, #1283 (items 1 and 4).
#
# #1283 item 3 (the dead `if (!is.null(cache))` guard in `[[.StratPosterior`)
# is also fixed in this diff but has no test of its own: `cache` is
# unconditionally non-NULL by that point, so the removed branch was
# unreachable and the change has no observable behaviour to pin -- covered
# incidentally by every `#689`/`#1281` test that exercises `[[.StratPosterior`.
#
# #1282 and #1283 (item 2) are Refs-only in this tranche (see PR body) and
# have no tests here: #1282's described shortfall is provably unreachable by
# the current `.maxSampleDeterministicRows()` remainder algorithm (a zero-row
# run always ranks strictly last, and the remainder can never reach that far
# down the list -- verified by proof and by 2M-trial fuzzing), and #1283
# item 2's dead condition sits inside a block PR #1447 already rewrites.
#
# Cache tests need a `StratPosterior` with a *live* `.cache` -- most shipped
# example datasets (including stratPosterior1, used below for the
# cache-independent accessor tests) predate the #264 cache mechanism and have
# none (RT-588), so `#689`/`#1281` build their own small fixture via
# `RunStratModel()` (`.PosteriorFixtureRun()`, from
# helper-posterior-fixtures.R), reused across both tests.

.D2CacheFixtureDir <- .PosteriorFixtureRun(1, 68210)

.D2FreshPosterior <- function() {
  suppressMessages(StratPosterior(readDir = .D2CacheFixtureDir))
}

test_that("#689: the cache stamp no longer carries a full-array checksum", {
  stamp <- .CacheStamp(array(seq_len(8), dim = c(2, 2, 2, 1)), nRun = 1)
  expect_false("checksum" %in% names(stamp))
  expect_setequal(names(stamp), c("dim", "dimnames", "length", "nRun", "probe"))
})

test_that("#689: cache validity still catches a genuine content change", {
  sp <- .D2FreshPosterior()
  expect_false(is.null(.PosteriorCache(sp)))

  # A value change at one of the 32 probed positions (position 1, always
  # probed) must still invalidate the cache without the checksum.
  spChanged <- sp
  spChanged$samples[1, 1, 1, 1] <- spChanged$samples[1, 1, 1, 1] + 1e6
  expect_null(.PosteriorCache(spChanged))

  # Same shape/dimnames/length/nRun, unchanged probe positions: still valid.
  spSame <- sp
  expect_false(is.null(.PosteriorCache(spSame)))
})

test_that("#1281: summary.StratPosterior() writes its result into the cache", {
  sp <- .D2FreshPosterior()
  cache <- .PosteriorCache(sp)
  expect_false(is.null(cache))
  expect_null(cache$summary)

  s1 <- suppressMessages(summary(sp))
  expect_false(is.null(cache$summary))
  expect_identical(cache$summary, s1)
})

test_that("#1281: a cached default summary() is served without recomputation", {
  sp <- .D2FreshPosterior()
  suppressMessages(summary(sp))
  cache <- .PosteriorCache(sp)

  # Sentinel: poke an implausible value into the memoised summary. A second
  # default call that actually recomputes would overwrite it with the real
  # (non-sentinel) figure; a call served from cache returns the sentinel.
  cache$summary[[c("general", "nRun")]] <- -99L
  s2 <- suppressMessages(summary(sp))
  expect_identical(s2[[c("general", "nRun")]], -99L)
})

test_that("#1281: a non-default summary() call does not overwrite the cached default", {
  sp <- .D2FreshPosterior()
  s1 <- suppressMessages(summary(sp))
  cache <- .PosteriorCache(sp)
  expect_identical(cache$summary, s1)

  # runs = 1 is non-default; must not clobber the memoised default summary.
  suppressWarnings(suppressMessages(summary(sp, runs = 1)))
  expect_identical(cache$summary, s1)
})

test_that("#682: .RoundToSigDigits() keeps the full digit count just below a power of ten", {
  df <- data.frame(x = c(9.5, 9.123456789, 99.5, 5, 0.5, 1.5))
  out <- .RoundToSigDigits(df, sigDigits = 6)
  # Pre-fix these overshoot and lose one significant digit: "9.5000" (5 sig
  # figs), "9.1235" (5), "99.500" (5).
  expect_identical(out$x[1], "9.50000")
  expect_identical(out$x[2], "9.12346")
  expect_identical(out$x[3], "99.5000")
  # Unaffected values (already correct pre-fix) stay correct.
  expect_identical(out$x[4], "5.00000")
  expect_identical(out$x[5], "0.50000")
  expect_identical(out$x[6], "1.50000")
})

test_that("#683: $.StratPosterior partial-matches an unambiguous field name", {
  expect_false(is.null(stratPosterior1$savedPar))
  expect_identical(stratPosterior1$savedPar, stratPosterior1$savedParameters)
  expect_identical(stratPosterior1$savedPar, unclass(stratPosterior1)$savedPar)
})

test_that("#683: $.StratPosterior returns NULL for an ambiguous partial match", {
  # "model" is a real, exactly-named element; "mode" ambiguously prefixes
  # both "modelDir" and "modelName", so ordinary list `$` semantics (and
  # unclass(.)$mode) return NULL rather than guessing.
  expect_null(unclass(stratPosterior1)$mode)
  expect_null(stratPosterior1$mode)
})

test_that("#683: $.StratPosterior still exact-matches ordinary fields", {
  expect_identical(stratPosterior1$nRun, stratPosterior1[["nRun"]])
})

test_that("#687: divergence-location colnames guard fires on a mismatched matrix width", {
  m <- matrix(1:12, nrow = 3, ncol = 4)  # 4 cols, but 5 expected for 2 param names
  expect_error(
    .AssembleDivergenceLocations(m, run = 1, divParamNames = c("alpha", "beta")),
    "column"
  )
})

test_that("#687: divergence-location assembly succeeds when the width matches", {
  m <- matrix(as.numeric(1:15), nrow = 3, ncol = 5)
  out <- .AssembleDivergenceLocations(m, run = 2, divParamNames = c("alpha", "beta"))
  expect_identical(colnames(out), c("run", "rung", "treeDepth", "deltaH", "alpha", "beta"))
  expect_identical(nrow(out), 3L)
})

test_that("#1283 (1/4): .AutoBurnInDraws() rejects a per-run row/samples mismatch", {
  # Sibling to "a posterior whose samples and mcmcSummary disagree errors
  # clearly" in test-auto-burnin-posterior.R, which drops a whole RUN (3rd
  # dim) -- the existing guard's own case. This drops a ROW (1st dim)
  # instead, which that guard (run-count only) lets through.
  badSp <- stratPosterior1
  badSp$samples <- badSp$samples[1, , , , drop = FALSE]
  expect_error(.AutoBurnInDraws(badSp), "saved row")
})

test_that("#1283 (4/4): print.StratPosterior() uses plain \\n, matching print.summary.StratPosterior()", {
  printed <- paste(capture.output(print(stratPosterior1)), collapse = "\n")
  expect_false(grepl("\r", printed, fixed = TRUE))
})
