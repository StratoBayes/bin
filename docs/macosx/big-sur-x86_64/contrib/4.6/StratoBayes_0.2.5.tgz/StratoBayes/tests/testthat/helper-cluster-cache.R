# The shipped `stratPosterior*` fixtures predate the #264 object-attached cache
# and carry `.cache = NULL`, so on a fixture `.ClusterInternal()` runs uncached
# and neither lazy branch of `[[.StratPosterior` can fire - unlike real
# `RunStratModel()` output (RT-453). This attaches the missing cache.
#
# `lazy = FALSE` pre-populates `stratCluster` from the stored element, matching
# an object already clustered; `lazy = TRUE` leaves it empty so the deferred
# branches run. `stamp` is required, or RT-454 disowns the cache as inherited.
.WithClusterCache <- function(stratPosterior, lazy = FALSE) {
  ce <- new.env(parent = emptyenv())
  ce$stratCluster <- if (lazy) NULL else .subset2(stratPosterior, "stratCluster")
  ce$summary <- NULL
  ce$clusterCache <- list()
  ce$stamp <- .CacheStamp(.subset2(stratPosterior, "samples"),
                          .subset2(stratPosterior, "nRun"))
  stratPosterior[[".cache"]] <- ce
  stratPosterior
}
