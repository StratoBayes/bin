# Targeted regression tests for RT-414 and RT-415
# (see dev/red-team/findings.md for the full detail/repro of each).
#
# RT-415: `.RhatRankNorm()` split each chain in half and then kept only the
#   *leading* `minLen` draws of each half, so everything past that window was
#   invisible to R-hat while mean/sd/quantiles/ESS used all of it.
# RT-414: `StratPosterior()` dated every run's rows with the *longest* run's
#   row labels, so runs recorded at different `nThin` were truncated (and, in
#   a neighbouring case, left unusable).

# ── RT-415 ───────────────────────────────────────────────────────────────────

# Helper: one-parameter matrix in the shape `.RhatRankNorm()` expects.
.RhatMat <- function(v) matrix(v, ncol = 1, dimnames = list(NULL, "p"))

test_that("RT-415: R-hat no longer reports < 1.00 for grossly non-stationary
          chains whose drift sits outside the leading window", {
  # Deterministic construction (no RNG, so this is portable): every split's
  # *leading* 50 draws are the identical vector `base`, while ~99% of chain B
  # sits 1000 units away. Pre-fix all four visible windows were `base`, so
  # B_over_n was exactly 0 and R-hat collapsed to sqrt((n - 1) / n).
  base <- seq(-1, 1, length.out = 50)
  chainA <- c(base, base)                          # 100 draws; halves 50 / 50
  chainB <- rep(base + 1000, length.out = 10000)   # 10000 draws; halves 5000
  chainB[1:50] <- base                             # leading window of half 1
  chainB[5001:5050] <- base                        # leading window of half 2

  # The chains are grossly non-stationary by any measure that looks at all
  # the draws.
  expect_equal(mean(chainA), 0)
  expect_equal(mean(chainB), 990)

  rhat <- suppressWarnings(
    StratoBayes:::.RhatRankNorm(list(.RhatMat(chainA), .RhatMat(chainB)))
  )

  # Pre-fix this was exactly sqrt(49 / 50) = 0.98995 -- a clean pass.
  expect_gt(unname(rhat), 1.1)
})

test_that("RT-415: draws past the leading window can move R-hat", {
  # Pre-fix, shifting chain B's tail (everything past `half + minLen`) by any
  # amount left R-hat bit-identical: the region provably could not influence
  # the statistic. Post-fix the thinned view spans the whole split, so the
  # shifted tail must register.
  set.seed(1)
  chainA <- rnorm(50)
  chainB <- rnorm(9950)

  Shifted <- function(delta) {
    b <- chainB
    b[5001:9950] <- b[5001:9950] + delta
    suppressWarnings(
      unname(StratoBayes:::.RhatRankNorm(list(.RhatMat(chainA), .RhatMat(b))))
    )
  }

  # Pre-fix every one of these was identical to 12 dp.
  expect_gt(Shifted(1000), Shifted(0) + 0.1)
  expect_gt(Shifted(50), Shifted(0) + 0.1)
})

test_that("RT-415: equal-length chains are unaffected by the fix", {
  # For splits already of length `minLen`, `round(seq(1, n, length.out = n))`
  # is exactly `seq_len(n)`, so balanced inputs must be byte-identical to the
  # pre-fix result. Both an even and an odd chain length are checked (an odd
  # chain drops its final draw at the split step, as before).
  set.seed(7)
  even1 <- rnorm(200)
  even2 <- rnorm(200)
  odd <- rnorm(201)

  # Reference values recorded from the pre-fix implementation.
  expect_equal(
    unname(StratoBayes:::.RhatRankNorm(list(.RhatMat(even1), .RhatMat(even2)))),
    1.000377658173, tolerance = 1e-10
  )
  expect_equal(
    unname(StratoBayes:::.RhatRankNorm(list(.RhatMat(even1), .RhatMat(odd)))),
    0.997354410956, tolerance = 1e-10
  )

  # And no imbalance warning: these are balanced.
  expect_no_warning(
    StratoBayes:::.RhatRankNorm(list(.RhatMat(even1), .RhatMat(even2))),
    message = "thinned"
  )
})

test_that("RT-415: severely unequal runs warn that R-hat is thinned", {
  set.seed(11)
  short <- rnorm(50)
  long <- rnorm(500)
  expect_warning(
    StratoBayes:::.RhatRankNorm(list(.RhatMat(short), .RhatMat(long))),
    "thinned"
  )
  # ... but a merely 2:1 imbalance does not.
  expect_no_warning(
    StratoBayes:::.RhatRankNorm(list(.RhatMat(rnorm(250)), .RhatMat(long))),
    message = "thinned"
  )
  # ... and nor does a layout too degenerate to yield an R-hat at all: saying
  # "the statistic was thinned" about an all-NA result would be misleading.
  expect_no_warning(
    res <- StratoBayes:::.RhatRankNorm(list(.RhatMat(rnorm(3)), .RhatMat(long))),
    message = "thinned"
  )
  expect_true(all(is.na(res)))
})

# ── RT-414 ───────────────────────────────────────────────────────────────────

test_that("RT-414: .CompleteSampleRows dates each run with that run's own
          saveIter, not a single shared label vector", {
  # Two runs sharing one samples array: run 1 saved 3 rows at nThin = 10,
  # run 2 saved 5 rows at nThin = 2. The array is padded to 5 rows and (as
  # built by .SamplesArrayFromRunListAfterMCMC) labelled with the longest
  # run's iterations only.
  samples <- array(NA_real_, dim = c(5, 2, 2, 1))
  samples[1:3, , 1, 1] <- 1
  samples[1:5, , 2, 1] <- 1

  run1Iter <- c(1, 10, 20, 30, 40)   # nThin = 10
  run2Iter <- c(1, 2, 4, 6, 8)       # nThin = 2 (= the array's row labels)

  # Pre-fix the helper took the shared vector and reported run 1's last
  # complete iteration as run2Iter[3] = 4 instead of run1Iter[3] = 20.
  expect_equal(
    StratoBayes:::.CompleteSampleRows(samples, 2, list(run1Iter, run2Iter)),
    c(20, 8)
  )

  # A malformed call must say what is wrong rather than failing later with an
  # opaque `vapply` length error (or, pre-RT-414, an -Inf index downstream).
  expect_error(
    StratoBayes:::.CompleteSampleRows(samples, 2, run2Iter),
    "single shared label vector"
  )
  expect_error(
    StratoBayes:::.CompleteSampleRows(samples, 2, list(run1Iter)),
    "1 label vector\\(s\\) were"
  )
  expect_error(
    StratoBayes:::.CompleteSampleRows(samples, 2, list(numeric(0), run2Iter)),
    "empty iteration-label vector for run\\(s\\) 1"
  )
})

# End-to-end fixtures live in helper-posterior-fixtures.R, shared with
# test-rt416-rt432-posterior-summary.R so the `RunStratModel()` calls -- by far
# the dominant cost of both files -- are paid for once.
.Rt414Combine <- function(thinA, thinB) {
  .PosteriorFixtureCombine(thinA, thinB, envir = parent.frame())
}

test_that("RT-414: mixed nThin = 10 / nThin = 2 keeps every completed row", {
  post <- .Rt414Combine(10, 2)
  mcmcSummary <- post[["mcmcSummary"]]

  # Both runs completed all 1000 iterations; the array's shared row labels
  # come from run 2 alone (1, 2, 4, ..., 1000), whose 101st entry is 200 --
  # pre-fix that 200 was reported as run 1's completedIter.
  expect_equal(as.numeric(dimnames(post[["samples"]])[[1]])[101], 200)
  expect_equal(unname(mcmcSummary[["completedIter"]]), c(1000, 1000))

  # The durable invariant: each run's reported completedIter is a member of
  # that run's own saveIter.
  for (r in 1:2) {
    expect_true(mcmcSummary[["completedIter"]][r] %in%
                  mcmcSummary[["saveIter"]][[r]])
  }

  # nThin = 10 over 1000 iterations saves 101 rows (iteration 1 is always
  # prepended, StratMCMC.R:376-379); nThin = 2 saves 501. Pre-fix run 1 was
  # cut to 21 rows -- 80 of its 101 silently dropped.
  expect_equal(unname(mcmcSummary[["completedIterIndex"]]), c(101, 501))
  expect_equal(lengths(mcmcSummary[["saveIter"]]), c(101, 501))
})

test_that("RT-414: mixed nThin = 10 / nThin = 1 no longer leaves the posterior
          unusable", {
  post <- .Rt414Combine(10, 1)
  mcmcSummary <- post[["mcmcSummary"]]

  # Pre-fix run 1's completedIter was reported as 101, which is not a member
  # of its saveIter {1, 10, 20, ...}; ExtractIterations() then found no
  # completed rows at all and every downstream call hard-errored.
  expect_equal(unname(mcmcSummary[["completedIter"]]), c(1000, 1000))
  expect_true(mcmcSummary[["completedIter"]][1] %in% mcmcSummary[["saveIter"]][[1]])
  expect_equal(lengths(mcmcSummary[["saveIter"]]), c(101, 1000))

  # Pre-fix: "all iterations were discarded as burn-in".
  expect_no_error(suppressWarnings(summary(post)))
})

test_that("RT-414: equal nThin is unchanged", {
  post <- .Rt414Combine(2, 2)
  mcmcSummary <- post[["mcmcSummary"]]
  expect_equal(unname(mcmcSummary[["completedIter"]]), c(1000, 1000))
  expect_equal(unname(mcmcSummary[["completedIterIndex"]]), c(501, 501))
  expect_equal(lengths(mcmcSummary[["saveIter"]]), c(501, 501))
  # Balanced retained lengths, so R-hat is computed without thinning. Scoped
  # to the imbalance warning so an unrelated future warning does not fail
  # this assertion.
  expect_no_warning(summary(post), message = "thinned")
})
