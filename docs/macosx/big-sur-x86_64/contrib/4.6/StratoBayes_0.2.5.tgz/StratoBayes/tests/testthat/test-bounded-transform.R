# #349 item 2: bounded-parameter transform for the C++ NUTS/HMC integrator.
#
# The scalar transform (support -> unconstrained u) and its Jacobian pieces are
# the correctness spine: a wrong dx/du biases the sampler geometry and a wrong
# Jacobian gradient/log-density biases the target. These are deterministic
# finite-difference checks against the C++ helpers via the .sb_transform_probe
# shim — no RNG, no engine, portable — so a wrong bijection or Jacobian in ANY
# transform family is caught in milliseconds (advisor's per-transform guard).
# These cover the transform MATH; the end-to-end integrator property (that the
# Jacobian is applied UN-tempered, so hot PT rungs are not biased) is still owed
# as an engine-level stationarity test (frozen hot beta, RT-302 harness) --
# tracked, not yet written. Transform type codes match the C++ TransformType
# enum: 0 identity, 1 lower [a,Inf), 2 upper (-Inf,b], 3 logit [a,b].

`%||%` <- function(a, b) if (is.null(a)) b else a

.tx_probe <- function(type, lo, hi, u) {
  as.list(StratoBayes:::.sb_transform_probe(as.integer(type), lo, hi, u))
}

# Central finite-difference of a scalar field returned by the probe.
.tx_fd <- function(type, lo, hi, u, field, h = 1e-5) {
  hp <- .tx_probe(type, lo, hi, u + h)[[field]]
  hm <- .tx_probe(type, lo, hi, u - h)[[field]]
  (hp - hm) / (2 * h)
}

test_that("#349 item 2: transform round-trips and Jacobians are FD-consistent", {
  cases <- list(
    list(name = "identity", type = 0L, lo = -Inf, hi = Inf),
    list(name = "lower[0,Inf)", type = 1L, lo = 0,    hi = Inf),
    list(name = "lower[2,Inf)", type = 1L, lo = 2,    hi = Inf),
    list(name = "upper(-Inf,5]", type = 2L, lo = -Inf, hi = 5),
    list(name = "logit[0,1]",   type = 3L, lo = 0,    hi = 1),
    list(name = "logit[-2,3]",  type = 3L, lo = -2,   hi = 3)
  )
  # Keep |u| modest so O(h^2) FD error dominates over sigmoid saturation noise.
  us <- c(-3, -1.3, -0.4, 0, 0.7, 2, 3)

  for (cs in cases) {
    for (u in us) {
      p <- .tx_probe(cs$type, cs$lo, cs$hi, u)

      # x is strictly inside the support
      if (is.finite(cs$lo)) expect_gt(p$x, cs$lo, label = paste(cs$name, "x>lo @u=", u))
      if (is.finite(cs$hi)) expect_lt(p$x, cs$hi, label = paste(cs$name, "x<hi @u=", u))

      # invertibility: u_of_x(x_of_u(u)) == u
      expect_equal(p$u_of_x, u, tolerance = 1e-9,
                   label = paste(cs$name, "round-trip @u=", u))

      # dx/du matches a central difference of x(u)
      expect_equal(p$dxdu, .tx_fd(cs$type, cs$lo, cs$hi, u, "x"),
                   tolerance = 1e-5,
                   label = paste(cs$name, "dxdu vs FD @u=", u))

      # gradjac = d/du log|dx/du| matches a central difference of logjac(u)
      expect_equal(p$gradjac, .tx_fd(cs$type, cs$lo, cs$hi, u, "logjac"),
                   tolerance = 1e-5,
                   label = paste(cs$name, "gradjac vs FD @u=", u))
    }
  }
})

test_that("#349 item 2: identity transform is an exact pass-through", {
  for (u in c(-4, -1, 0, 2.5, 10)) {
    p <- .tx_probe(0L, -Inf, Inf, u)
    expect_identical(p$x, u)
    expect_identical(p$u_of_x, u)
    expect_identical(p$dxdu, 1)
    expect_identical(p$logjac, 0)
    expect_identical(p$gradjac, 0)
  }
})

test_that("#349 item 2: log-lower/upper analytic values are correct", {
  # lower [0,Inf): x=e^u, dx/du=e^u, logjac=u, gradjac=1
  p <- .tx_probe(1L, 0, Inf, 1.5)
  expect_equal(p$x, exp(1.5))
  expect_equal(p$dxdu, exp(1.5))
  expect_equal(p$logjac, 1.5)
  expect_equal(p$gradjac, 1)

  # upper (-Inf,5]: x=5-e^u, dx/du=-e^u, logjac=u, gradjac=1
  p <- .tx_probe(2L, -Inf, 5, 0.7)
  expect_equal(p$x, 5 - exp(0.7))
  expect_equal(p$dxdu, -exp(0.7))
  expect_equal(p$logjac, 0.7)
  expect_equal(p$gradjac, 1)

  # logit at u=0: sigma=0.5, x=midpoint, dx/du=(hi-lo)/4, gradjac=0
  p <- .tx_probe(3L, -2, 3, 0)
  expect_equal(p$x, 0.5)               # -2 + 5*0.5
  expect_equal(p$dxdu, 5 * 0.25)       # (hi-lo)*s*(1-s)
  expect_equal(p$gradjac, 0)           # 1 - 2*0.5
})

test_that("#349 item 2: logjac stays finite for large |u| (numerical stability)", {
  for (u in c(-700, -50, 50, 700)) {
    p <- .tx_probe(3L, 0, 1, u)        # logit
    expect_true(is.finite(p$logjac), label = paste("logit logjac finite @u=", u))
    p <- .tx_probe(1L, 0, Inf, u)      # lower
    expect_true(is.finite(p$logjac), label = paste("lower logjac finite @u=", u))
  }
})

# ── Transform table: support-driven assignment on real models ─────────────────
# Build a C++ engine and read back its per-free-dim transform table. The table
# is derived from each parameter's prior support at setup, so it is populated on
# any engine regardless of proposal config. This is the structural guard behind
# the "unbounded models are bit-identical" guarantee: an all-Normal model MUST
# report anyTransformed = FALSE (fast path = exact pre-item-2 arithmetic), and a
# model with a `gap` (Exponential) MUST map that dim to the log-lower transform.

# Build a C++ engine for a (stratData, StratModel) pair via a short R run, then
# read back the transform table. The table is prior-derived at setup, so it does
# not depend on the proposal config.
.tx_engine <- function(stratData, model) {
  td <- file.path(tempdir(), paste0("txeng_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  RunStratModel(stratData, model, nIter = 20, nChains = 2L, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))
  unlink(td, recursive = TRUE)
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  eng <- StratoBayes:::.sb_create_engine(stratData, model, mcmc, mcmc$recentState)
  freeNames <- model[["parametersNames"]][model[[c("ind", "paramNotFixed")]]]
  list(tx = StratoBayes:::.sb_get_transform(eng), names = freeNames)
}

test_that("#349 item 2: all-Normal model reports anyTransformed=FALSE (identity)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())

  # AutoPrior(stratData1) is all-Normal (no gap, height scale) -> every free dim
  # is identity, so the integrator takes the exact pre-item-2 arithmetic path.
  # This is the structural guard behind the "unbounded models unchanged" claim.
  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = AutoPrior(stratData1),
    alignmentScale = "height", sedModel = "site",
    flexibleKnots = FALSE, knotRange = c(-5, 12))
  s <- .tx_engine(stratData1, model)

  expect_false(s$tx$anyTransformed)
  expect_true(all(s$tx$type == 0L))
})

test_that("#349 item 2: support-driven transforms on a real bounded model", {
  skip_on_cran()
  # stratModel2 (age scale) exercises all three families in one model:
  #   alpha_*   : bounded age priors        -> logit  (type 3, finite lo & hi)
  #   gammaLog_*: Normal (unbounded)        -> identity (type 0)
  #   gap_*     : Exponential [0, Inf)      -> log-lower (type 1, lo = 0)
  data(stratData2, package = "StratoBayes", envir = environment())
  data(stratModel2, package = "StratoBayes", envir = environment())

  s <- .tx_engine(stratData2, stratModel2)
  tx <- s$tx
  expect_true(tx$anyTransformed)

  gapPos   <- which(startsWith(s$names, "gap_"))
  alphaPos <- which(startsWith(s$names, "alpha_"))
  gLogPos  <- which(startsWith(s$names, "gammaLog_"))
  expect_length(gapPos, 1L)
  expect_gt(length(alphaPos), 0L)
  expect_gt(length(gLogPos), 0L)

  # gap -> log-lower at 0, no upper bound
  expect_equal(tx$type[gapPos], 1L)
  expect_equal(tx$lower[gapPos], 0)
  expect_false(is.finite(tx$upper[gapPos]))

  # bounded alpha -> logit with finite lower AND upper
  expect_true(all(tx$type[alphaPos] == 3L))
  expect_true(all(is.finite(tx$lower[alphaPos])))
  expect_true(all(is.finite(tx$upper[alphaPos])))
  expect_true(all(tx$upper[alphaPos] > tx$lower[alphaPos]))

  # unbounded gammaLog -> identity
  expect_true(all(tx$type[gLogPos] == 0L))
})
