# Shared finite-difference gradient comparison for test-cpp-gradient.R and
# test-flexible-knots-gradient.R, which previously each carried their own copy
# of the step ladder and had drifted apart.
#
# Per element, never pooled: testthat::expect_equal() averages the relative
# difference across the vector, so analytic c(1000, 500, 1e-3) matches
# fd c(1000.0001, 500.00005, 5e-3) at tolerance 1e-4 -- the third element is
# wrong by 400% and two neighbours right to 1e-7 dilute it away.
#
# A central difference is an oracle only where logPost is differentiable. The
# overlap penalty weights each observation by an integer count of overlapping
# sections, so logPost steps by ~2 nats when a perturbed age crosses a section
# boundary, and a difference straddling that step returns -jump/(2h) -- order
# 1e5, arbitrary sign, no derivative in it (#989). Shrinking h walks out of the
# straddle, whereas a wrong analytical gradient disagrees at every step. Floor
# at h0/64: below ~1e-7, cancellation in a logPost of order 1e3 dominates.

.FdRelErr <- function(analytic, fd) {
  abs(analytic - fd) / max(abs(analytic), abs(fd), 1e-8)
}

# `refine(i, h)` must re-evaluate element `i` alone at step `h`; recomputing the
# whole gradient vector to keep one element costs 2 * nFree evaluations per
# refinement instead of 2.
# nolint next: object_name_linter. Matches the expect_*() convention.
expect_fd_close <- function(analytic, fd, refine, h0, tol,
                            param_names = NULL, info = NULL) {
  for (i in seq_along(analytic)) {
    steps <- h0
    fds <- fd[[i]]
    rel <- .FdRelErr(analytic[[i]], fds)

    while (rel >= tol && !is.null(refine) && length(steps) < 4) {
      steps <- c(steps, h0 / 4 ^ length(steps))
      fds <- c(fds, refine(i, steps[[length(steps)]]))
      rel <- .FdRelErr(analytic[[i]], fds[[length(fds)]])
    }

    testthat::expect_true(
      rel < tol,
      info = paste(c(sprintf(
        "Param '%s': analytical=%.6e, fd=%s at h=%s, rel_err=%.4e (tol=%.4e)",
        if (is.null(param_names)) i else param_names[[i]], analytic[[i]],
        paste(signif(fds, 6), collapse = ", "),
        paste(signif(steps, 3), collapse = ", "), rel, tol
      ), info), collapse = " | ")
    )
  }
}
