# Area 5/6 fixes: #1256 resumed delta length, #1249 collapsed swap diagnostic,
# #1247 collapsed-posterior warning, #1248 R/C++ ties parity, #1257 factor
# partition column.

# ── #1257: a factor partitionColumn must be coerced ──────────────────────────
# PRE-FIX: uniqueParts is c("2", "1") -- the integer level codes -- and the
# gammaLog parameter names read gammaLog_1/gammaLog_2.
# POST-FIX: uniqueParts holds the real labels and the names follow them.
test_that("StratData() coerces a factor partitionColumn (#1257)", {
  signal <- data.frame(
    site = rep(c("s1", "s2"), each = 20),
    height = rep(seq(0, 19), 2),
    value = rnorm(40)
  )
  parts <- data.frame(
    site = c("s1", "s1", "s2", "s2"),
    height = c(9, 19, 9, 19),
    partition = factor(c("sandstone", "limestone", "sandstone", "limestone"),
                       levels = c("sandstone", "limestone"))
  )
  d <- StratData(signal = signal, parts = parts)

  expect_type(d[[c("partsAttr", "sedRatesDFOri")]], "character")
  expect_setequal(d[[c("partsAttr", "uniqueParts")]],
                  c("sandstone", "limestone"))

  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "partition", nKnots = 5)
  expect_true(any(grepl("sandstone", m[["parametersNames"]])))
  expect_false(any(d[[c("partsAttr", "uniqueParts")]] %in% c("1", "2")))
})

# A gap plus a factor column errored opaquely pre-fix ("missing value where
# TRUE/FALSE needed", raised from .FillGaps' NA sentinel assignment).
test_that("a factor partitionColumn survives a gap (#1257)", {
  signal <- data.frame(
    site = rep(c("s1", "s2"), each = 20),
    height = rep(seq(0, 19), 2),
    value = rnorm(40)
  )
  parts <- data.frame(
    site = rep(c("s1", "s2"), each = 3),
    height = rep(c(6, 13, 19), 2),
    partition = factor(c("sandstone", NA, "limestone",
                         "sandstone", "limestone", "limestone"),
                       levels = c("sandstone", "limestone"))
  )
  expect_silent(d <- StratData(signal = signal, parts = parts))
  expect_setequal(d[[c("partsAttr", "uniqueParts")]],
                  c("sandstone", "limestone"))
})

# ── #1248: a state with both a +Inf and a -Inf tie density ───────────────────
# The C++ accumulator folds every non-finite outcome onto the -1e30 sentinel
# (src/MCMCEngine.cpp, compute_logpost). The R reference summed +Inf + -Inf to
# NaN and hard-errored via .StopTiesNA().
# PRE-FIX: expect_error(..., "returned NA log-likelihood") passes -- i.e. R
# errored where C++ cleanly rejects. POST-FIX: returns -1e30.
# Exercises the .tiesDispatch path directly; a full StratModel is not needed,
# since .LogLikTies() reads only these three fields.
tiesFixture <- function(fns) {
  data <- list(ties = TRUE)
  model <- list(.tiesDispatch = list(
    siteIndices = 1L,
    dispatch = list(lapply(fns, function(f)
      list(active = TRUE, fn = f, args = list())))
  ))
  state <- list(age = list(ties = list(list(0, 0))))
  list(data = data, model = model, state = state)
}

test_that(".LogLikTies folds a +Inf/-Inf pair onto the sentinel (#1248)", {
  posInf <- function(x) Inf
  negInf <- function(x) -Inf

  # Both orders: pre-fix the sum was NaN either way, and C++ is now
  # order-independent too.
  f1 <- tiesFixture(list(posInf, negInf))
  expect_equal(.LogLikTies(f1$data, f1$model, f1$state), -1e30)

  f2 <- tiesFixture(list(negInf, posInf))
  expect_equal(.LogLikTies(f2$data, f2$model, f2$state), -1e30)
})

test_that(".LogLikTies still errors on a genuine NA density (#1248)", {
  naFun <- function(x) NA_real_
  ok <- function(x) -1
  f <- tiesFixture(list(ok, naFun))
  expect_error(.LogLikTies(f$data, f$model, f$state),
               "returned NA log-likelihood")
})

test_that(".LogLikTies folds a lone +Inf onto the sentinel (#1248)", {
  # dbeta(0, 0.5, 2, log = TRUE) is +Inf; C++'s beta_ties_logdensity matches it.
  f <- tiesFixture(list(function(x) Inf))
  expect_equal(.LogLikTies(f$data, f$model, f$state), -1e30)
})

# ── #1247: warn when a run's cold chain finishes stuck out of support ────────
# Unit-tests the checker on synthetic sample matrices. PRE-FIX
# .WarnCollapsedPosterior() did not exist and nothing anywhere warned; the
# discriminator for the surrounding behaviour is that the collapsed matrix now
# warns while the healthy one and the recovered one stay silent.
collapsedChunks <- function(post, chain = 1) {
  list(cbind(iteration = seq_along(post), chain = chain, posterior = post))
}
collapsedNames <- c("iteration", "chain", "posterior")

test_that(".WarnCollapsedPosterior warns on a fully collapsed run (#1247)", {
  expect_warning(
    .WarnCollapsedPosterior(collapsedChunks(rep(-1e30, 20)), collapsedNames, 1),
    "stuck outside the support"
  )
})

test_that(".WarnCollapsedPosterior is silent on a healthy run (#1247)", {
  expect_silent(
    .WarnCollapsedPosterior(collapsedChunks(rnorm(20, -50)), collapsedNames, 1)
  )
})

test_that(".WarnCollapsedPosterior ignores an escaped transient (#1247)", {
  # Sentinel for the first three quarters, finite thereafter: the chain got out.
  post <- c(rep(-1e30, 15), rnorm(5, -50))
  expect_silent(
    .WarnCollapsedPosterior(collapsedChunks(post), collapsedNames, 1)
  )
})

test_that(".WarnCollapsedPosterior judges the cold chain only (#1247)", {
  # A hot chain parked out of support is not a reason to warn.
  chunks <- list(cbind(iteration = rep(1:20, 2), chain = rep(1:2, each = 20),
                       posterior = c(rnorm(20, -50), rep(-1e30, 20))))
  expect_silent(.WarnCollapsedPosterior(chunks, collapsedNames, 1))
})

test_that(".WarnCollapsedPosterior needs the expected columns (#1247)", {
  expect_silent(.WarnCollapsedPosterior(collapsedChunks(rep(-1e30, 20)),
                                        c("iteration", "chain", "other"), 1))
})

# ── #1256: a resumed gibbs$delta must be one value per offset group ──────────
# PRE-FIX: .sb_create_engine() imported the short vector without complaint, and
# the signal/marginal likelihood loops then read delta[obsToGroup[i]] past its
# end (undefined behaviour, invisible on x86-64). Confirmed pre-fix by checking
# out origin/main's src/MCMCEngine.cpp: expect_error() found no condition.
# POST-FIX: the wrapper rejects it by name.
test_that(".sb_create_engine rejects a wrong-length resumed delta (#1256)", {
  skip_on_cran()

  set.seed(101)
  h <- seq(0, 10, length.out = 25)
  sig <- data.frame(
    site   = rep(c("site_1", "site_2"), each = 25),
    height = c(h, h),
    value  = c(sin(h) + rnorm(25, 0, 0.1), sin(h) + 1.5 + rnorm(25, 0, 0.1))
  )
  grp <- data.frame(site = c("site_1", "site_2"), group = c("A", "B"),
                    stringsAsFactors = FALSE)
  d <- StratData(signal = sig, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, knotRange = c(-2, 12),
                  flexibleKnots = FALSE, signalOffsets = TRUE, sigmaFixed = TRUE)

  td <- file.path(tempdir(), "sb1256")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  result <- RunStratModel(stratObject = d, stratModel = m,
                          nIter = 10, nChains = 2L, seed = 1, nThreads = 1L,
                          quiet = TRUE, visualise = FALSE,
                          modelDir = td, modelName = "s1256", engine = "cpp")
  mcmcObj <- readRDS(file.path(td, "s1256_mcmc_run_1.rds"))
  modelObj <- result[["model"]]
  if (is.null(modelObj[[".logpost_cpp"]]))
    modelObj[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(modelObj)

  good <- mcmcObj[["recentState"]]
  expect_equal(length(good[[1]][[c("gibbs", "delta")]][[1]]),
               modelObj[[c("offsetConfig", "nGroups")]])
  expect_no_error(StratoBayes:::.sb_create_engine(
    data = result[["data"]], model = modelObj, mcmc = mcmcObj, state = good))

  # A checkpoint saved under a one-group table, resumed into this two-group one.
  bad <- good
  bad[[1]][[c("gibbs", "delta")]][[1]] <-
    bad[[1]][[c("gibbs", "delta")]][[1]][1]
  expect_error(
    StratoBayes:::.sb_create_engine(
      data = result[["data"]], model = modelObj, mcmc = mcmcObj, state = bad),
    "signal offsets.*expected 2"
  )
})

# ── #1249: a collapsed ladder must not read as perfect swap mixing ───────────
# Both chains of a swap pair clamped to the -1e30 sentinel give L1-L2 == 0
# exactly, so the swap ratio was exp(0) == 1 and every attempt was accepted.
# Measured on this fixture with origin/main's src/MCMCEngine.cpp:
#   177 recorded swap attempts, mean acceptance 1  (a dead ladder reading
#   as ideal mixing). POST-FIX: the same 177 attempts, mean acceptance 0.
# The attempt count is identical because the runif draw is still made and only
# the decision is overridden, so the RNG stream is unchanged.
test_that("a collapsed tempered run records zero swap acceptance (#1249)", {
  skip_on_cran()

  set.seed(9)
  h <- seq(0, 10, length.out = 20)
  sig <- data.frame(
    site = rep(c("s1", "s2"), each = 20), height = c(h, h),
    value = c(sin(h) + rnorm(20, 0, 0.1), sin(h) + rnorm(20, 0, 0.1))
  )
  # A tie on the NON-reference site whose density is -Inf everywhere the
  # sampler can reach: heights are ~0-10, the tie demands 1e6-2e6.
  ties <- data.frame(site = "s2", height = c(0, 10), densityFun = "dunif",
                     arg1 = 1e6, arg2 = 2e6)
  d <- StratData(signal = sig, ties = ties)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, knotRange = c(-2, 12),
                  flexibleKnots = FALSE)

  td <- file.path(tempdir(), "sb1249")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mc <- StratMCMC(m, nIter = 60, nChains = 4L, nThreads = 2L,
                  tempering = TRUE, adaptTemperatures = TRUE,
                  adaptTemperaturesMonitor = TRUE)
  # The run is collapsed by construction, so it warns (#1247) via the
  # .WarnCollapsedPosterior() call site in RunStratModel(); asserting the
  # warning here also pins that call site, not just the helper it calls.
  expect_warning(
    RunStratModel(stratObject = d, stratModel = m, stratMCMC = mc,
                  seed = 1, quiet = TRUE, visualise = FALSE,
                  modelDir = td, modelName = "t1249"),
    "stuck outside the support"
  )
  swaps <- readRDS(file.path(td, "t1249_mcmc_run_1.rds"))[[
    c("temper", "temperingSwaps")]]

  # 4 chains -> choose(4, 2) == 6 columns: ALL pairs, not the ladder.
  expect_equal(ncol(swaps), 6L)
  recorded <- swaps[!is.na(swaps)]
  expect_gt(length(recorded), 100L)   # the diagnostic was actually populated
  expect_lt(mean(recorded), 0.05)     # pre-fix this was exactly 1
})
