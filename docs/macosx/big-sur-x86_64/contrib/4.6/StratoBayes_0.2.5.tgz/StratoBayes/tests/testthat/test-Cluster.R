{ # Initialize test objects
  set.seed(1)
  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- matrix(c(1, 0, 0.7, 0,
                   0, 1, 0.1, 0.1,
                   0.7, 0.1, 1, -0.5,
                   0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- matrix(c(0.7, 0, 0.4, 0,
                   0, 0.6, 0.5, 0.1,
                   0.4, 0.1, 0.75, -0.5,
                   0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4 * matrix(c(0.7, 0, -0.4, 0,
                         0, 0.6, 0.5, 0.1,
                         -0.4, 0.1, 0.75, 0.5,
                         0, 0.1, 0.5, 0.7), nrow = 4)
  data1 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1)
    ))

  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(400, 90, 10)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data2 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1)))
  if (interactive()) {
    plot(data2)
  }


  data3 <- data.frame(
    V1 = c(97.56527, 102.54420, 101.53206, 101.53206, 101.53206, 101.38620, 101.38620,
           100.94047, 100.94047, 99.57210, 100.33106, 100.18833, 99.34119, 99.34119,
           99.43087, 99.33477, 101.38620, 101.38620, 100.94047, 100.94047),
    V2 = c(103.02928, 108.00821, 118.25200, 109.04995, 103.32610, 103.18024, 100.84177,
           106.35769, 100.64825, 104.47125, 107.99137, 105.84992, 101.93326, 89.97386,
           87.70621, 94.24024, 103.18024, 100.84177, 106.35769, 100.64825),
    V3 = c(-0.05652142, -0.05652142, -0.04776534, -0.04776534, -0.04776534, -0.04776534,
           -0.04776534, -0.02732213, -0.02732213, -0.02991628, -0.01460799, -0.02466896,
           -0.01819302, -0.01819302, -0.01644947, -0.01931594, -0.04776534, -0.04776534,
           -0.02732213, -0.02732213),
    V4 = c(0.3448458, 0.3448458, 0.1349495, 0.1349495, 0.1349495, 0.1349495, 0.1349495,
           0.2623913, 0.2623913, 0.4074241, 0.1234816, 0.2380531, 0.4972773, 0.4972773,
           0.5936869, 0.6173871, 0.1349495, 0.1349495, 0.2623913, 0.2623913)
  )


  # Generate 3 cluster centers with different values for a 4-dimensional space
  n <- c(40, 9, 1)
  cov1 <- 0.4*matrix(c(1, 0, 0.7, 0,
                       0, 1, 0.1, 0.1,
                       0.7, 0.1, 1, -0.5,
                       0, 0.1, -0.5, 1), nrow = 4)
  cov2 <- 0.4*matrix(c(0.7, 0, 0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       0.4, 0.1, 0.75, -0.5,
                       0, 0.1, -0.5, 0.7), nrow = 4)
  cov3 <- 0.4*matrix(c(0.7, 0, -0.4, 0,
                       0, 0.6, 0.5, 0.1,
                       -0.4, 0.1, 0.75, 0.5,
                       0, 0.1, 0.5, 0.7), nrow = 4)
  data4 <- as.data.frame(rbind(
    MASS::mvrnorm(n = n[1], mu = c(0, 0, 4, 4), Sigma = cov1, tol = 1),
    MASS::mvrnorm(n = n[2], mu = c(0, 5, 4, 7), Sigma = cov2, tol = 1),
    MASS::mvrnorm(n = n[3], mu = c(4, 0, 2, 7), Sigma = cov3, tol = 1))
  )
}

# RT-144: the skip_on_ci() calls below (added 2025-07-24, "too fragile - may
# fail on CI system", no further detail recorded) leave the entire
# Cluster.default (raw-matrix) dispatch path unexercised in CI. Investigated
# for this fix round: the GHA matrix (.github/workflows) runs Windows,
# macOS-x86_64 and macOS-arm64 across R 4.2-4.6 -- six distinct
# BLAS/LAPACK/RNG environments. These tests assert tight proportions
# (tolerance 0.05-0.25) on kmeans/pam/hdbscan output for points near cluster
# boundaries, which is exactly the kind of assertion that floating-point
# differences across that matrix can flip. The reason still applies, so the
# skips are kept, but the .default dispatch path itself (proto method) is now
# also exercised by a CI-safe smoke test below, using two widely-separated,
# low-variance blobs whose cluster assignment is unambiguous regardless of
# platform.
test_that("Cluster.default dispatches on a raw matrix without CI-fragile precision (RT-144)", {
  set.seed(1)
  wellSeparated <- as.data.frame(rbind(
    MASS::mvrnorm(n = 20, mu = c(0, 0), Sigma = diag(0.01, 2)),
    MASS::mvrnorm(n = 20, mu = c(100, 100), Sigma = diag(0.01, 2))
  ))

  cl <- Cluster(wellSeparated, clusterMethod = "proto")

  expect_length(cl, 40)
  expect_equal(length(unique(cl[1:20])), 1)
  expect_equal(length(unique(cl[21:40])), 1)
  expect_false(identical(cl[1], cl[21]))
})

test_that("Cluster.default data1 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
    cl1 <- Cluster(data1)
    # most of the first 400 should be cluster 1
    testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.1)
    # most of the following 90 should be cluster 2
    testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.1)
})

test_that("Cluster.default data1 - proto, higher outlier", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data1, silOutlierThreshold = 0.3)
  # most of the last 10 should be cluster 0
  testthat::expect_equal(sum(abs(diff(cl1[491:500]) > 0))+10, 10, tolerance = 0.2)
})

test_that("Cluster.default data1 - pam", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "pam")
  # most of the first 400 should be cluster 1
  testthat::expect_equal(sum(cl1[1:400]), 400, tolerance = 0.05)
  # most of the following 90 should be cluster 2
  testthat::expect_equal(sum(cl1[401:490]), 180, tolerance = 0.05)
})

test_that("Cluster.default data1 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data1, clusterMethod = "hdbscan", minPts = 4)
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))>0)+50, 50, tolerance = 0.2)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0)+100, 100, tolerance = 0.25)
})

test_that("Cluster.default data2 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "proto",
                 silOutlierThreshold = 0.1)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[491:500]))>0)+50, 50, tolerance = 0.2)
  testthat::expect_equal(sum(abs(diff(cl1[1:400]))>0)+100, 100, tolerance = 0.25)
})

test_that("Cluster.default data2 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data2, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(cl1Table[length(cl1Table) - c(1, 0)], c(90, 400), tolerance = 0.1)
})

test_that("Cluster.default data3 - hdbscan", {
  skip_on_ci() # too fragile - may fail on CI system

  skip_if_not_installed("dbscan")
  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "hdbscan")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) >  3)
})

test_that("Cluster.default data3 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data3, clusterMethod = "proto", silOutlierThreshold = 0)
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_true(length(cl1Table) <=  3)
})

test_that("Cluster.default data4 - proto", {
  skip_on_ci() # too fragile - may fail on CI system

  set.seed(1)
  cl1 <- Cluster(data4, clusterMethod = "proto")
  cl1Table <- as.numeric(sort(table(cl1), decreasing = F))
  testthat::expect_equal(sum(abs(diff(cl1[41:49]))), 0, tolerance = 3)
  testthat::expect_equal(sum(abs(diff(cl1[1:40]))), 0, tolerance = 4)
  })

test_that("Cluster.StratPosterior - proto default", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1)
  # RT-143: any(cluster > 0) passes with a single non-noise sample out of
  # 300; proto clustering on this seeded input assigns every sample to a
  # cluster, so require coverage well above the trivial floor.
  testthat::expect_true(mean(cl1[["cluster"]] > 0) >= 0.9)
  testthat::expect_equal(cl1[["options"]][["clusterMethod"]], "proto")
})

test_that("Cluster.StratPosterior - hdbscan explicit", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1, clusterMethod = "hdbscan")[["cluster"]]
  # RT-143: hdbscan legitimately leaves a large noise fraction on this
  # seeded input (~36% non-noise), but a coverage-percentage floor well
  # above the trivial 1/300 case still catches a broken clustering that
  # assigns nearly everything to noise.
  testthat::expect_true(mean(cl1 > 0) >= 0.2)
})

test_that("Cluster.StratPosterior falls back to single cluster when all noise", {
  # Use very high burnIn so few samples remain; minPts forces all-noise in hdbscan
  cl <- Cluster(stratPosterior1, burnIn = 0.99,
                clusterMethod = "hdbscan", minPts = 50)
  expect_equal(cl[["nClust"]], 1L)
  expect_false(0L %in% cl[["clustUnique"]])
  expect_true(1L %in% cl[["clustUnique"]])
  # alignment = 1 (default) should now be valid
  expect_silent(.ValidateAlignment(1, clustUnique = cl[["clustUnique"]]))
})

test_that("Cluster.StratPosterior - StratPosterio2", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior2, burnIn = 0.9)[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  # Allow noise (cluster 0) in addition to the two modes
  condition3 <- all(cl1 %in% c(0, 1, 2))

  testthat::expect_true(all(condition1, condition2, condition3))
})

test_that("Cluster.StratPosterior - hdbscan finds multiple modes", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior1, clusterMethod = "hdbscan")[["cluster"]]
  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  testthat::expect_true(all(condition1, condition2))
})

test_that("Cluster.StratPosterior - hdbscan with maxSamples", {
  set.seed(1)
  cl1 <- Cluster(stratPosterior2, maxSamples = 100,
                 clusterMethod = "hdbscan")$cluster

  condition1 <- 1 %in% cl1
  condition2 <- 2 %in% cl1
  # Allow noise (cluster 0) alongside the two modes
  condition3 <- all(cl1 %in% c(0, 1, 2))

  testthat::expect_true(all(condition1, condition2, condition3))
})


test_that("Cluster.StratPosterior can deal with runSelect and selectRows", {
  set.seed(1)
  expect_error(Cluster(stratPosterior1, selectRows = list(102:101, 100:101)),
               "selectRows")
  expect_error(Cluster(stratPosterior1, runs = c(4,2),
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  expect_error(Cluster(stratPosterior1, runs = 3:1,
                       selectRows = list(102:101, 100:101)),
               "runSelect")
  # Fewer than 3 selected samples is one degenerate alignment, not one per
  # sample (RT-713).
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = list(102:101, 100:101, NULL))[["cluster"]],
               c(1, 1))
  expect_equal(Cluster(stratPosterior1, runs = 1,
                       selectRows = 102:101)[["cluster"]],
               c(1, 1))
  # With only 4 data points, should find 2 clusters with pairs grouped together
  cl_small <- Cluster(stratPosterior1, runs = c(3, 1),
                      selectRows = 102:101)[["cluster"]]
  expect_equal(cl_small[1], cl_small[2])
  expect_equal(cl_small[3], cl_small[4])
  expect_false(cl_small[1] == cl_small[3])
  # RT-425: runIndex must line up with the pooled `cluster`/`clusterList`
  # order, which is always ascending run number (selectRows is run-number
  # indexed and pooled via ExtractParameters()'s default "all" runs) -
  # regardless of the order `runs` was supplied in. `runs = c(3, 1)` here
  # formats selectRows to run1 = 100 (1 row), run3 = 102:101 (2 rows), so the
  # pooled order is [run1, run3, run3], not runSelect's [3, 1] order.
  expect_equal(Cluster(stratPosterior1, runs = c(3, 1),
                       selectRows = list(102:101, 100))[["runIndex"]],
               c(1, 3, 3))
  })

test_that("Cluster.StratPosterior's default maxSamples stays on the outlier-capable path (#393)", {
  # .ProtoClusterSubsample() never reports outliers (cluster 0) once
  # nrow(clusterData) > maxClusterSamples - that's documented, deliberate
  # behaviour (RT-127). But a default Cluster.StratPosterior() call used to
  # extract up to maxSamples = 10,000 posterior draws against
  # maxClusterSamples = 2,500, so any typical run silently took the
  # subsample path and outlier detection went dark without the caller
  # touching either argument. Pin maxSamples <= maxClusterSamples so the
  # defaults can't drift apart like that again.
  defaults <- formals(Cluster.StratPosterior)
  expect_lte(eval(defaults[["maxSamples"]]), eval(defaults[["maxClusterSamples"]]))
})

test_that("Cluster.StratPosterior's runIndex tallies match rowIndex regardless of `runs` order (RT-425)", {
  set.seed(1)
  cl <- Cluster(stratPosterior1, runs = c(3, 1),
                selectRows = list(102:101, 100))
  expect_equal(length(cl[["runIndex"]]), length(cl[["cluster"]]))
  # runIndex, in ascending run-number order, must tally exactly against the
  # (also run-number-indexed) rowIndex lengths for the runs actually selected.
  expect_equal(as.vector(table(cl[["runIndex"]])),
               c(length(cl[["rowIndex"]][[1]]), length(cl[["rowIndex"]][[3]])))
  expect_equal(unique(cl[["runIndex"]]), c(1, 3))
  # `runs` is derived from the same `runIndex` (unique(runIndex)), so it also
  # now reports ascending run-number order rather than echoing `runs = c(3,1)`
  # verbatim - this is the same fix, not a second behaviour change.
  expect_equal(cl[["runs"]], c(1, 3))
})

test_that("Cluster.StratPosterior returns Cluster Data", {
  set.seed(1)
  its <- 4950:5000
  selectedSamples <- length(which(its %in% stratPosterior2[[c("mcmcSummary", "saveIter")]][[1]])) * stratPosterior2$nRun
    cluster1 <- Cluster(stratPosterior2, iterations = its, returnClusterData = TRUE)
    expect_equal(dim(cluster1$clusterData), c(selectedSamples, length(unlist(stratPosterior2$model$heightsForClustering))))

    # Value-level check (#394): clusterData must be the *position-space*
    # converted heights (i.e. .AgeConversionBatch() output), not the raw
    # parameter values. A same-width raw-parameter matrix would satisfy the
    # shape check above but fail this one, so this is what actually pins
    # #164's central outcome (cluster on aligned positions, not parameters).
    model <- stratPosterior2[["model"]]
    stratData <- stratPosterior2[["data"]]
    metroPar <- ExtractParameters(stratPosterior2, parameters = "parameters",
                                  selectRows = cluster1[["rowIndex"]])
    expected <- lapply(model[["siteIndices"]], function(site) {
      heights <- model[["heightsForClustering"]][[site]]
      .AgeConversionBatch(metroPar, heights, site, stratData, model[["ind"]])
    })
    expected <- t(do.call(rbind, expected))
    expect_equal(unname(as.matrix(cluster1[["clusterData"]])), unname(expected))
})

test_that("position-space clustering cannot see a parameter site 2 ignores (#394)", {
  # #394: on the four shipped posteriors both spaces agree on nClust, so
  # nothing there distinguishes a real .AgeConversionBatch() call from
  # clustering the raw MCMC parameters. Here the two groups of draws differ
  # only in alpha_site3, which site 2's converted heights ignore.
  set.seed(394)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  ind1 <- .CreateIndices(tmulti, alignmentScale = "age", sedModel = "s",
                         alphaPosition = "bottom")

  n <- 15
  paramsA <- data.frame(
    alpha_site1 = 40.1 + rnorm(n, 0, 0.3),
    alpha_site2 = 34.3 + rnorm(n, 0, 0.3),
    alpha_site3 = 39.3 + rnorm(n, 0, 0.05),
    gammaLog_site1 = 1.25 + rnorm(n, 0, 0.02),
    gammaLog_site2 = 0.914 + rnorm(n, 0, 0.02),
    gammaLog_site3 = 0.409 + rnorm(n, 0, 0.02),
    gap_site2_1 = 1.63 + rnorm(n, 0, 0.05)
  )
  paramsB <- paramsA
  paramsB$alpha_site3 <- paramsA$alpha_site3 + 20 # irrelevant to site 2

  metroPar <- rbind(paramsA, paramsB)[, ind1[["names"]]]
  heights <- range(tmulti[[c("partsAttr", "Bound")]][, 2], na.rm = TRUE)
  heights <- seq(heights[1], heights[2], length.out = 3)
  clusterData <- t(.AgeConversionBatch(as.matrix(metroPar), heights,
                                       site = 2, tmulti, ind1))

  clRaw <- Cluster(as.matrix(metroPar), clusterMethod = "hdbscan", minPts = 5)
  clPos <- Cluster(clusterData, clusterMethod = "hdbscan", minPts = 5)

  # The 20-unit offset dwarfs every other parameter's spread, so raw space
  # splits into exactly the two groups.
  expect_equal(length(unique(clRaw[clRaw != 0])), 2L)
  expect_length(unique(clRaw[seq_len(n)]), 1L)
  expect_length(unique(clRaw[n + seq_len(n)]), 1L)
  expect_false(clRaw[[1]] == clRaw[[n + 1]])

  # Rows i and i + n convert identically, so no clustering of position space
  # can separate them. Pinning the labels rather than nClust keeps the test off
  # hdbscan's platform-sensitive splitting of the remaining noise.
  expect_equal(clusterData[seq_len(n), ], clusterData[n + seq_len(n), ])
  expect_identical(clPos[seq_len(n)], clPos[n + seq_len(n)])
})

test_that("Cluster.StratPosterior - proto finds single cluster for unimodal posterior", {
  # stratPosterior0 and stratPosterior5b are known unimodal cases where
  # hdbscan over-splits; proto should conservatively call them 1 cluster
  cl0 <- Cluster(stratPosterior0)
  expect_equal(cl0[["nClust"]], 1L)

  cl5b <- Cluster(stratPosterior5b)
  expect_equal(cl5b[["nClust"]], 1L)
})

test_that("Cluster.StratPosterior - proto finds two clusters for bimodal posterior", {
  cl2 <- Cluster(stratPosterior2, burnIn = 0.9)
  expect_equal(cl2[["nClust"]], 2L)
  expect_true(all(cl2[["cluster"]] %in% c(0, 1, 2)))
})

test_that("Cluster.StratPosterior - proto finds three clusters for trimodal posterior", {
  cl5a <- Cluster(stratPosterior5a)
  expect_equal(cl5a[["nClust"]], 3L)
})

test_that(".ProtoClusterSubsample agrees with full .ProtoCluster on small data", {
  set.seed(3817)
  # With n < maxClusterSamples, subsample path should produce identical results
  mat <- rbind(
    matrix(rnorm(100 * 4, mean = 0), nrow = 100),
    matrix(rnorm(100 * 4, mean = 5), nrow = 100)
  )
  cl_full <- .ProtoCluster(mat, clustMax = 12)
  cl_sub  <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  expect_identical(cl_full, cl_sub)
})

test_that(".ProtoClusterSubsample handles 1D data with n > maxClusterSamples (RT-057)", {
  set.seed(4711)
  mat <- matrix(c(rnorm(1500, mean = 0), rnorm(1500, mean = 10)), ncol = 1)
  cl <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  expect_length(cl, nrow(mat))
  expect_true(all(cl %in% c(0L, 1L, 2L)))
})

test_that(".ProtoClusterSubsample subsample draw is deterministic across global RNG states (RT-039)", {
  # Simulates a FIFO-cache eviction + revisit: identical clustDat recomputed
  # under a completely different session RNG state must still produce the
  # identical cluster assignment.
  mat <- rbind(
    matrix(rnorm(2000 * 3, mean = 0), ncol = 3),
    matrix(rnorm(1000 * 3, mean = 8), ncol = 3)
  )
  set.seed(10)
  cl1 <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  set.seed(999)
  cl2 <- .ProtoClusterSubsample(mat, maxClusterSamples = 500)
  expect_identical(cl1, cl2)
})

test_that(".ProtoClusterSubsample does not disturb the caller's RNG stream (RT-039)", {
  mat <- rbind(
    matrix(rnorm(2000 * 3, mean = 0), ncol = 3),
    matrix(rnorm(1000 * 3, mean = 8), ncol = 3)
  )
  set.seed(42)
  x <- runif(3)
  set.seed(42)
  invisible(.ProtoClusterSubsample(mat, maxClusterSamples = 500))
  y <- runif(3)
  expect_identical(x, y)
})

test_that(".ProtoClusterFast returns k=1 for degenerate all-identical input (RT-126)", {
  cl <- .ProtoClusterFast(matrix(1, 8, 3), clustMax = 6)
  expect_identical(cl, rep.int(1L, 8))
})

test_that(".ProtoClusterFast can select k=clustMax (RT-125)", {
  # A near-duplicate pair (tiny first merge height) plus an equilateral
  # triangle of well-separated points (near-equal subsequent merge heights).
  # The largest gap in merge heights sits right at the start (h[2]-h[1]),
  # so the natural cut is at k = clustMax = 4 - a case the pre-fix gap
  # window (which excluded heights[n - clustMax]) could never select.
  mat <- matrix(c(0, 0.001, 10, 15, 5,
                  0, 0,     0,  8.66, 8.66), ncol = 2)
  cl <- .ProtoClusterFast(mat, clustMax = 4)
  expect_length(unique(cl), 4L)
})

test_that(".IsPositiveDefinite works", {
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3))))
  expect_false(.IsPositiveDefinite(cov(matrix(c(1,2,NA,2,3,6,7,8,9), nrow = 3))))
  expect_true(.IsPositiveDefinite(cov(matrix(c(1,2,5,2,3,6,7,8,9), nrow = 3)) + diag(3) / 1000))
})
