# #1280 (1): `burnInPercent` could report above 100%.
#
# The other two sub-issues are handled elsewhere: the unsnapped `floorIter`
# candidate in PR #1346 (`R/AutoBurnIn.R`), and the proportion/absolute
# ambiguity not at all (the only confusable value is 0, where both readings
# agree).

test_that("#1280: a fully discarded run reports 100%, not more", {
  sp <- stratPosterior1
  saveIter <- sp[[c("mcmcSummary", "saveIter")]][[1L]]
  # Run 1 stopped early -- the state a `timeLimit` run leaves behind. It is the
  # `completedIter` metadata, not the row count, that `burnInPercent` divides
  # by, so truncating the saved rows alone would not reach the defect.
  stopped <- 600
  sp[["mcmcSummary"]][["completedIter"]][[1L]] <- stopped
  sp[["mcmcSummary"]][["completedIterIndex"]][[1L]] <- sum(saveIter <= stopped)

  # Past run 1's last completed iteration, within every other run's:
  # 700 / 600 * 100 = 116.7% before the fix.
  s <- suppressWarnings(summary(sp, burnIn = 700))
  percent <- unname(s[[c("general", "burnInPercent")]])

  expect_equal(percent[[1L]], 100)
  expect_true(all(percent <= 100))
  # 100 is the true figure and not a cosmetic cap: the run really does
  # contribute nothing.
  expect_equal(unname(s[[c("general", "nSamplesUsedPerRun")]])[[1L]], 0)
  # The runs that did complete are unaffected.
  expect_equal(percent[-1L], rep(700 / 5000 * 100, 2))
})
