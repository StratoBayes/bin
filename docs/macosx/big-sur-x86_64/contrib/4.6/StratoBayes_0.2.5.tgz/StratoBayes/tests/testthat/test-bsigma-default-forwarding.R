# RunStratModel() declares its own `bSigma` formal, so StratModel()'s
# `missing(bSigma)` cannot see that the caller left it unset. Only the NULL
# sentinel in RunStratModel() keeps the data-scaled default (#974) reachable
# through the ordinary entry point.
# stratData1 at native scale cannot discriminate: min(0.01, 0.01 * n * var(y))
# returns 0.01 whether or not the scaling ran.

test_that("the data-scaled bSigma default survives RunStratModel() (GH #974)", {
  sig <- stratData1[["signal"]]
  sig[["value"]] <- sig[["value"]] * 1e-3
  lowVar <- StratData(sig, zColumn = "height", siteColumn = "site",
                      signalColumn = "value")

  direct <- StratModel(lowVar, nKnots = 5, alignmentScale = "height",
                       sedModel = "site")[[c("priors", "gibbs", "bSigma")]]
  viaRun <- RunStratModel(lowVar, nKnots = 5, alignmentScale = "height",
                          sedModel = "site", nIter = 4, nChains = 1,
                          nThreads = 1L, runParallel = FALSE,
                          visualise = FALSE, modelDir = tempdir()
                          )[[c("model", "priors", "gibbs", "bSigma")]]

  expect_identical(viaRun, direct)
  expect_identical(viaRun, .bSigmaScaled(sig[["value"]]))
  # Without this the test still passes if both paths regress to a flat 0.01.
  expect_lt(viaRun, 0.01)
})

test_that("a bSigma the caller does supply reaches StratModel() unscaled", {
  sig <- stratData1[["signal"]]
  sig[["value"]] <- sig[["value"]] * 1e-3
  lowVar <- StratData(sig, zColumn = "height", siteColumn = "site",
                      signalColumn = "value")

  viaRun <- RunStratModel(lowVar, nKnots = 5, alignmentScale = "height",
                          sedModel = "site", bSigma = 5e-3, nIter = 4,
                          nChains = 1, nThreads = 1L, runParallel = FALSE,
                          visualise = FALSE, modelDir = tempdir()
                          )[[c("model", "priors", "gibbs", "bSigma")]]

  expect_identical(viaRun, 5e-3)
})
