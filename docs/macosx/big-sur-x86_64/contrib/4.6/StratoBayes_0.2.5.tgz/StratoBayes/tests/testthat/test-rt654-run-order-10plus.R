# `split()` groups run files by a regex-extracted run number; its factor
# levels sort as strings, so nRun >= 10 orders groups 1,10,11,12,2,3,...
# while callers index the result positionally (`mcmc[[run]]`).

test_that(".ReadMCMC orders 12 checkpoint files numerically, not as strings", {
  readDir <- withr::local_tempdir()
  modelName <- "rt654"
  nRun <- 12L

  for (run in seq_len(nRun)) {
    saveRDS(list(marker = run),
            file.path(readDir, paste0(modelName, "_mcmc_run_", run, ".rds")))
  }

  mcmc <- .ReadMCMC(mcmc = NULL, readDir = readDir, modelName = modelName)

  expect_length(mcmc, nRun)
  for (run in seq_len(nRun)) {
    expect_equal(mcmc[[run]][["marker"]], run)
  }
})

test_that(".CompileSamplesAfterMCMC's TSV fallback orders runs numerically", {
  modelDir <- withr::local_tempdir()
  modelName <- "rt654b"
  nRun <- 11L
  paramNames <- "p1"

  for (run in seq_len(nRun)) {
    df <- data.frame(iteration = 1L, chain = 1L, p1 = run)
    filePath <- file.path(modelDir,
                          paste0(modelName, "_samples_run_", run, ".txt"))
    write.table(df, filePath, sep = "\t", row.names = FALSE)
  }

  model <- list(outputParams = paramNames)
  compiled <- .CompileSamplesAfterMCMC(modelDir, modelName, model)

  for (run in seq_len(nRun)) {
    expect_equal(as.vector(compiled[1, "p1", run, 1]), run)
  }
})
