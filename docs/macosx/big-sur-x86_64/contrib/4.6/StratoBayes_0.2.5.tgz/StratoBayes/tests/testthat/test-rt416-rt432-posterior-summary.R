# Regression tests for the posterior summary / CombineModelRuns review batch:
# RT-416, RT-418, RT-419, RT-422, RT-424, RT-426, RT-427, RT-428, RT-429,
# RT-430, RT-432. See dev/red-team/findings.md for each row's full repro.
#
# RT-431 is documentation-only and has no test.
#
# Several of these interact with RT-414/RT-415 (PR #397). Where a row's repro
# needed re-verifying against post-#397 `main`, the test comment records what
# was actually observed there rather than the row's original wording.

# Helper: one-parameter matrix in the shape `.RhatRankNorm()` expects.
.RhatMat1 <- function(v) matrix(v, ncol = 1, dimnames = list(NULL, "p"))

# ── RT-422: NA / non-finite draws must not fabricate an R-hat ────────────────

test_that("RT-422: contaminated draws yield NA rather than a fabricated R-hat", {
  set.seed(1)
  clean <- rnorm(200)
  withNA <- rnorm(200)
  withNA[1:20] <- NA

  # Pre-fix this returned 3.05899: `rank()`'s default `na.last = TRUE` gave the
  # NAs the largest ranks, which Blom's transform mapped to a large finite z.
  # Meanwhile `.EssFunc()` hard-errors on exactly the same input -- two
  # convergence diagnostics behaving oppositely on identical contaminated data.
  rhat <- suppressWarnings(
    StratoBayes:::.RhatRankNorm(list(.RhatMat1(clean), .RhatMat1(withNA))))
  expect_true(is.na(rhat))
  expect_error(StratoBayes:::.EssFunc(withNA))

  # `is.na()` specifically, not merely "non-finite": `max(NA, NA, na.rm = TRUE)`
  # returns -Inf, so a half-fix would swap a fabricated finite value for a
  # fabricated -Inf.
  expect_false(identical(unname(rhat), -Inf))
})

test_that("RT-422: Inf draws are caught too, via the folded branch", {
  # Screened on `is.finite`, not `is.na`. A non-finite pooled median makes every
  # `abs(allVals - med)` NaN, whose ranks are a deterministic 1, 2, 3, ... ramp
  # -- a tail R-hat computed from pure artefact. Pre-fix this returned 1.0219,
  # a confident-looking "converged" verdict built from nothing.
  set.seed(1)
  clean <- rnorm(200)
  withInf <- rnorm(200)
  withInf[1:20] <- Inf

  rhat <- suppressWarnings(
    StratoBayes:::.RhatRankNorm(list(.RhatMat1(clean), .RhatMat1(withInf))))
  expect_true(is.na(rhat))
})

test_that("RT-422: clean input is unaffected", {
  # The RT-415 reference value, re-asserted here so the NA screen cannot change
  # a result it has no business changing.
  set.seed(7)
  expect_equal(
    unname(StratoBayes:::.RhatRankNorm(
      list(.RhatMat1(rnorm(200)), .RhatMat1(rnorm(200))))),
    1.000377658173, tolerance = 1e-10)
})

# ── RT-429: an absent R-hat must say why ────────────────────────────────────

test_that("RT-429: too-few-draws NA carries a reason, and 8 draws still works", {
  set.seed(2)
  # The chain IS split for n in 4..7 (`half = n %/% 2` >= 2), but `minLen < 4L`
  # then discards the result for every parameter -- printed as a bare `NA`
  # directly beneath a header naming 1.00 as the convergence target.
  for (n in c(4L, 6L, 7L)) {
    rhat <- suppressWarnings(StratoBayes:::.RhatRankNorm(
      list(.RhatMat1(rnorm(n)), .RhatMat1(rnorm(n)))))
    expect_true(all(is.na(rhat)))
    reason <- attr(rhat, "naReason")
    expect_true(!is.null(reason))
    expect_match(reason, "too few retained draws")
    expect_match(reason, as.character(n))  # names the retained draw count
  }

  # ... and 8 draws is computable, so the boundary has not moved.
  rhat8 <- suppressWarnings(StratoBayes:::.RhatRankNorm(
    list(.RhatMat1(rnorm(8)), .RhatMat1(rnorm(8)))))
  expect_true(is.finite(rhat8))
  expect_null(attr(rhat8, "naReason"))
})

test_that("RT-429: the reason survives summary() and reaches print()", {
  # The attribute has to survive `names<-`, storage into the `general` list and
  # the `summary.StratPosterior` class -- assert it end-to-end, not just off
  # `.RhatRankNorm()`'s own return value.
  s <- suppressWarnings(summary(stratPosterior1))
  psrf <- s[[c("general", "psrf")]]
  expect_false(anyNA(psrf))          # this fixture computes fine
  expect_null(attr(psrf, "naReason"))

  # Inject the degenerate state the guard is for and check print() explains it.
  s[[c("general", "psrf")]][] <- NA_real_
  attr(s[[c("general", "psrf")]], "naReason") <- "too few retained draws to test."
  expect_output(print(s), "NA: too few retained draws to test\\.")
})

# ── RT-430: no single-run gate is needed ────────────────────────────────────

test_that("RT-430: .RhatRankNorm gives a valid split-R-hat for a single run", {
  # Characterisation, not a regression: the `length(runSelect) > 1` gates this
  # row asked to remove were already replaced with the vestigial
  # `length(runSelect) >= 1` by RT-140 (a9fdbdba, PR #335), so no test can fail
  # pre-fix. This pins the property that makes the gate unnecessary.
  set.seed(5)
  rhat <- StratoBayes:::.RhatRankNorm(list(.RhatMat1(rnorm(500))))
  expect_true(is.finite(rhat))
  expect_lt(abs(unname(rhat) - 1), 0.05)

  # And summary() reports psrf for a single selected run.
  s <- suppressWarnings(summary(stratPosterior1, runs = 1))
  expect_false(is.null(s[[c("general", "psrf")]]))
})

# ── RT-419: .EssFunc's adaptive lag horizon is value-identical ───────────────

test_that("RT-419: growing lag.max does not change any returned value", {
  # The pre-fix implementation, verbatim, as the oracle. `acf()` normalises by
  # the whole series, so its value at a given lag does not depend on `lag.max`;
  # the Geyer sum reads no lag beyond its truncation point and the monotone
  # clamp depends only on earlier lags. Equality must therefore be exact, not
  # approximate -- a tolerance here would hide precisely the bug it is testing.
  EssRef <- function(x) {
    n <- length(x)
    if (n <= 3L) return(n)
    if (stats::var(x) < .Machine$double.eps) return(1)
    av <- stats::acf(x, lag.max = n - 2L, plot = FALSE)$acf[, 1L, 1L]
    tau <- -1; prevGamma <- Inf; m <- 0L
    while (2L * m + 2L <= length(av)) {
      g <- av[2L * m + 1L] + av[2L * m + 2L]
      if (g <= 0) break
      g <- min(g, prevGamma); prevGamma <- g
      tau <- tau + 2 * g; m <- m + 1L
    }
    min(n, n / max(tau, 1))
  }

  set.seed(42)
  for (n in c(4:12, 50, 200, 1000, 3000)) {
    for (rho in c(0, 0.3, 0.8, 0.95, 0.99, -0.5)) {
      x <- as.numeric(stats::filter(rnorm(n), rho, method = "recursive"))
      expect_identical(StratoBayes:::.EssFunc(x), EssRef(x),
                       info = paste("n =", n, "rho =", rho))
    }
    # Degenerate and near-degenerate chains take the early-return branches.
    expect_identical(StratoBayes:::.EssFunc(rep(1, n)), EssRef(rep(1, n)))
    nearConst <- c(rep(1, n - 1L), 1 + 1e-12)
    expect_identical(StratoBayes:::.EssFunc(nearConst), EssRef(nearConst))
  }
})

test_that("RT-419: the lag horizon actually grows when it needs to", {
  # A strongly autocorrelated chain whose Geyer truncation sits past the
  # initial 64-lag horizon, so the doubling loop must run at least once. If the
  # growth were broken this would silently return a too-small tau -- which the
  # equality test above would catch, but this pins the mechanism directly.
  set.seed(3)
  x <- as.numeric(stats::filter(rnorm(4000), 0.97, method = "recursive"))
  av <- stats::acf(x, lag.max = 3998, plot = FALSE)$acf[, 1L, 1L]
  full <- StratoBayes:::.GeyerTau(av)
  expect_true(full[["truncated"]])

  short <- StratoBayes:::.GeyerTau(av[seq_len(65)])
  expect_false(short[["truncated"]])          # 64 lags is not enough here
  expect_gt(full[["tau"]], short[["tau"]])    # ... and stopping there loses tau
})

# ── RT-416: one damaged sample file must not lose every run ─────────────────

test_that("RT-416: a run with no complete sample rows errors by name", {
  saveIter <- list(c(1, 10, 20), c(1, 2, 4))

  # Pre-fix: `max(which(saveIter[[2]] <= 0))` warned "no non-missing arguments
  # to max; returning -Inf", and the `seq_len(-Inf)` that consumed it failed
  # with "argument must be coercible to non-negative integer" -- naming neither
  # the run nor the file.
  expect_equal(StratoBayes:::.CompletedIterIndex(saveIter, c(20, 4)), c(3L, 3L))

  err <- expect_error(
    StratoBayes:::.CompletedIterIndex(saveIter, c(20, 0), "myModel"))
  expect_match(conditionMessage(err), "run 2")
  expect_match(conditionMessage(err), "myModel_samples_run_2.txt", fixed = TRUE)

  # Both runs damaged: names both, and pluralises.
  err2 <- expect_error(
    StratoBayes:::.CompletedIterIndex(saveIter, c(0, 0), "m"))
  expect_match(conditionMessage(err2), "runs 1, 2")
})

test_that("RT-416: a header-only sample file is caught end-to-end", {
  # The unit test above pins the guard; this pins the *wiring* -- that
  # `StratPosterior()` actually reaches it with `completeIter = 0`. Without
  # this, a later change to what `.CompleteSampleRows()` returns for a
  # zero-row run would leave the guard dead while the unit test still passed.
  #
  # `binary = FALSE` is load-bearing and was found the hard way: with any
  # `_binarysamples_run_*.rds` present, `.CompileSamplesAfterMCMC()` returns
  # from its RDS fast path having silently compiled a *one-run* posterior, so
  # the damaged TSV is never read and nothing fails at all.
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  binary = FALSE, damage = "header-only")
  err <- expect_error(
    suppressMessages(StratPosterior(readDir = dir, modelName = "mC")))
  expect_match(conditionMessage(err), "run 2")
  expect_match(conditionMessage(err), "mC_samples_run_2.txt", fixed = TRUE)

  # Pre-fix this chain was: "no non-missing arguments to max; returning -Inf",
  # then "argument must be coercible to non-negative integer".
  expect_false(grepl("coercible to non-negative integer",
                     conditionMessage(err), fixed = TRUE))
})

test_that("RT-416: a zero-byte sample file is caught end-to-end too", {
  # The second failure limb PR #405 left open: a 0-byte (or otherwise
  # unreadable) file makes `read.table()` itself error, so
  # `.CompileSamplesAfterMCMC()` stores `FALSE` for that run rather than a
  # zero-row data.frame. Pre-fix, `dim(FALSE)` is NULL and the dimension-check
  # `vapply(runData, function(x) dim(x)[2], numeric(1))` at
  # R/RunStratModel.R:2256 died with "values must be length 1, but FUN(X[[2]])
  # result is length 0" -- before `.SamplesArrayFromRunListAfterMCMC()`'s own
  # `runsNotSuccessfullyRead` placeholder-array branch was ever reached.
  #
  # `binary = FALSE` is load-bearing for the same reason as the header-only
  # test above: the RDS fast path would otherwise silently compile a one-run
  # posterior and never touch the damaged TSV.
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  binary = FALSE, damage = "zero-byte")
  err <- expect_error(
    suppressMessages(StratPosterior(readDir = dir, modelName = "mC")))
  expect_match(conditionMessage(err), "run 2")
  expect_match(conditionMessage(err), "mC_samples_run_2.txt", fixed = TRUE)

  # Once the placeholder array is reachable, this run converges on the same
  # named-run/file error as the header-only limb (an all-NA placeholder row
  # has no complete cases, so `.CompletedIterIndex()` catches it) -- not the
  # length-0 `vapply` crash the bug produced.
  expect_false(grepl("result is length 0", conditionMessage(err), fixed = TRUE))
})

test_that("RT-416: every sample file damaged names the model, not a subscript error", {
  # Excluding unreadable runs from the dimension check (the fix above) opens a
  # new edge the vapply crash used to catch first: if *every* run is
  # unreadable, `runsRead` is all-FALSE and
  # `.SamplesArrayFromRunListAfterMCMC()`'s `which.max(numeric(0))` /
  # `runData[integer(0)][[integer(0)]]` would throw "subscript out of bounds",
  # naming neither the model nor the directory. Guard against it explicitly
  # rather than leaving a second obscure crash in the fixed one's place.
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  binary = FALSE, damage = "zero-byte")
  file.create(file.path(dir, "mC_samples_run_1.txt"))  # zero-byte run 1 too

  err <- expect_error(
    suppressMessages(StratPosterior(readDir = dir, modelName = "mC")))
  expect_match(conditionMessage(err), "mC", fixed = TRUE)
  expect_false(grepl("subscript out of bounds", conditionMessage(err), fixed = TRUE))
})

# ── RT-424 / RT-427 / RT-428: CombineModelRuns ──────────────────────────────

# A minimal model directory: enough files for CombineModelRuns' copy loop and
# its comparison steps, without paying for an MCMC run. The comparisons under
# test all happen before `StratPosterior()` is reached.
.FakeModelDir <- function(name, envir, nThin = 2, nChains = 2,
                          sigmaFixed = NULL) {
  dir <- withr::local_tempdir(.local_envir = envir)
  writeLines("iteration\tchain\tvalue",
             file.path(dir, paste0(name, "_samples_run_1.txt")))
  mcmc <- StratMCMC(stratModel1, nIter = 100, nThin = nThin, nChains = nChains)
  saveRDS(mcmc, file.path(dir, paste0(name, "_mcmc_run_1.rds")))
  saveRDS(stratData1, file.path(dir, paste0(name, "_data.rds")))
  model <- stratModel1
  if (!is.null(sigmaFixed)) model[["sigmaFixed"]] <- sigmaFixed
  saveRDS(model, file.path(dir, paste0(name, "_model.rds")))
  writeLines("options", file.path(dir, paste0(name, "_options.txt")))
  dir
}

test_that("#654: combining runs recorded at different nThin warns, not refuses", {
  dA <- .FakeModelDir("mA", environment(), nThin = 2)
  dB <- .FakeModelDir("mB", environment(), nThin = 10)

  # Retired by #654: RT-424's actual fix was threading each run's real
  # `saveIter` labels through, which holds regardless of `nThin`, so a
  # mismatch only warns now.
  expect_warning(
    tryCatch(suppressMessages(
      CombineModelRuns(c(dA, dB), c("mA", "mB"), combinedModelName = "cAB")),
      error = function(e) NULL),   # fake data cannot survive StratPosterior()
    "nThin")
})

test_that("RT-424: differing nChains warns but does not refuse", {
  # The non-fatal half of the check. Without this the warning branch could be
  # deleted, or its condition inverted to fire on every combine, and the suite
  # would still pass.
  dA <- .FakeModelDir("mA", environment(), nThin = 2, nChains = 2)
  dB <- .FakeModelDir("mB", environment(), nThin = 2, nChains = 4)

  expect_warning(
    tryCatch(suppressMessages(
      CombineModelRuns(c(dA, dB), c("mA", "mB"), combinedModelName = "cAB")),
      error = function(e) NULL),   # fake data cannot survive StratPosterior()
    "nChains")

  # ... and identical settings warn about nothing.
  dC <- .FakeModelDir("mC", environment(), nThin = 2, nChains = 2)
  dD <- .FakeModelDir("mD", environment(), nThin = 2, nChains = 2)
  expect_no_warning(
    tryCatch(suppressMessages(
      CombineModelRuns(c(dC, dD), c("mC", "mD"), combinedModelName = "cCD")),
      error = function(e) NULL),
    message = "different MCMC settings")
})

test_that("RT-424: a setting missing from a legacy mcmc file is not a mismatch", {
  # `identical(NULL, 2)` is FALSE, so comparing a legacy object that predates a
  # setting would abort a combine that worked before the check existed -- and
  # render the NULL as an empty string in the message. Absent means unknown.
  modern <- StratMCMC(stratModel1, nIter = 100, nThin = 2, nChains = 2)
  legacy <- modern
  legacy[["nThin"]] <- NULL

  ref <- StratoBayes:::.CheckCombinedMCMCSettings(legacy, NULL, "mA", 1)
  expect_silent(
    StratoBayes:::.CheckCombinedMCMCSettings(modern, ref, "mB", 1))

  # A genuine disagreement between two known values is no longer fatal (#654):
  # it still returns the reference settings, just with a warning.
  other <- StratMCMC(stratModel1, nIter = 100, nThin = 10, nChains = 2)
  ref2 <- StratoBayes:::.CheckCombinedMCMCSettings(modern, NULL, "mA", 1)
  expect_warning(
    result <- StratoBayes:::.CheckCombinedMCMCSettings(other, ref2, "mB", 1),
    "nThin")
  expect_identical(result, ref2)
})

test_that("RT-424: equal nThin is not refused, and nIter is not compared", {
  dA <- .FakeModelDir("mA", environment(), nThin = 2)
  dB <- .FakeModelDir("mB", environment(), nThin = 2)

  # These fake directories cannot survive `StratPosterior()`, so assert only
  # that no MCMC-settings warning fires -- equal nThin/nChains/saveChains must
  # not be flagged, and runs of unequal length are a supported state.
  expect_no_warning(
    tryCatch(suppressMessages(
      CombineModelRuns(c(dA, dB), c("mA", "mB"), combinedModelName = "cAB")),
      error = function(e) NULL),
    message = "different MCMC settings")
})

test_that("#654: combining real nThin=2/nThin=10 runs completes with a warning", {
  # The previously-fatal case, on real StratMCMC() output rather than the fake
  # directories above (which cannot survive StratPosterior()). Confirms the
  # retired guard's own claim -- RT-424's per-run `saveIter` labels hold
  # regardless of `nThin` -- by actually completing the combine.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 40,
                       nThin = 2, nChains = 2, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE)
  r2 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 40,
                       nThin = 10, nChains = 2, visualise = FALSE, seed = 2,
                       runParallel = FALSE, saveMCMC = TRUE)

  combined <- NULL
  expect_warning(
    combined <- CombineModelRuns(
      modelDirs = c(r1[["modelDir"]], r2[["modelDir"]]),
      modelNames = c(r1[["modelName"]], r2[["modelName"]]),
      combinedModelName = paste0(r1[["modelName"]], "_combined654")),
    "nThin")

  expect_s3_class(combined, "StratPosterior")
  expect_equal(dim(combined[["samples"]])[3], 2L)  # both runs present

  # The guard's own justification: each run keeps its own saveIter schedule
  # (not the nThin scalar), so the finer run's 21 rows are not truncated to
  # the coarser run's 5, and neither run's completed iterations are lost.
  mcmcSummary <- combined[["mcmcSummary"]]
  expect_equal(unname(mcmcSummary[["nThin"]]), c(2, 10))
  expect_equal(unname(mcmcSummary[["completedIter"]]), c(40, 40))
  expect_length(mcmcSummary[["saveIter"]][[1]], 21L)
  expect_length(mcmcSummary[["saveIter"]][[2]], 5L)
})

test_that("RT-427: fixed-sigma and estimated-sigma runs no longer compare equal", {
  # The doc promised `sigmaFixed` is excluded from the comparison only when
  # *both* runs' values are numeric; the code dropped it unconditionally. The
  # test discriminates because `sigmaFixed = TRUE` is stored as a numeric while
  # `sigmaFixed = FALSE` stays logical (R/StratModel.R:458-460).
  dA <- .FakeModelDir("mA", environment(), sigmaFixed = 0.128)
  dB <- .FakeModelDir("mB", environment(), sigmaFixed = FALSE)

  err <- tryCatch({
    suppressMessages(CombineModelRuns(c(dA, dB), c("mA", "mB"),
                                      combinedModelName = "cAB"))
    ""
  }, error = function(e) conditionMessage(e))
  expect_match(err, "not identical after adjustments")

  # Control: two *numeric* sigmaFixed values differing from each other are
  # still ignored, exactly as documented -- so the fix honours the contract
  # rather than simply comparing more.
  dC <- .FakeModelDir("mC", environment(), sigmaFixed = 0.1)
  dD <- .FakeModelDir("mD", environment(), sigmaFixed = 0.2)
  err2 <- tryCatch({
    suppressMessages(CombineModelRuns(c(dC, dD), c("mC", "mD"),
                                      combinedModelName = "cCD"))
    ""
  }, error = function(e) conditionMessage(e))
  expect_false(grepl("not identical after adjustments", err2))
})

test_that("RT-427: blanking adjustments[[1]] preserves list length", {
  # R semantics, pinned because the misalignment they cause is silent:
  # `[[1]] <- NULL` removes the element and shifts the rest down, so two
  # `adjustments` lists of different lengths were compared element 2 against
  # element 3.
  shifted <- list(a = 1, b = 2, c = 3)
  shifted[[1]] <- NULL
  expect_length(shifted, 2)

  blanked <- list(a = 1, b = 2, c = 3)
  blanked[1] <- list(NULL)
  expect_length(blanked, 3)
  expect_null(blanked[[1]])
  expect_equal(blanked[[2]], 2)
})

test_that("RT-428: the combined model gets an auto-detectable options file", {
  dA <- .FakeModelDir("mA", environment())
  dB <- .FakeModelDir("mB", environment())
  combinedDir <- dA  # CombineModelRuns uses modelDirs[1]

  suppressWarnings(suppressMessages(tryCatch(
    CombineModelRuns(c(dA, dB), c("mA", "mB"), combinedModelName = "cAB"),
    error = function(e) NULL)))  # fake data cannot survive StratPosterior()

  # Pre-fix every options file was written as `<combined>_options_<i>.txt`,
  # which `StratPosterior()`'s `"_options\\.txt$"` scan never matches -- so the
  # combined model was invisible and the surviving `mA_options.txt` was
  # silently auto-detected and returned in its place.
  expect_true(file.exists(file.path(combinedDir, "cAB_options.txt")))
  expect_true(file.exists(file.path(combinedDir, "cAB_options_2.txt")))

  # With keepOriginals = TRUE the source options file survives beside it, so
  # auto-detection now reports the ambiguity rather than silently picking mA.
  detected <- tryCatch({
    suppressMessages(StratPosterior(readDir = combinedDir))
    "built"
  }, error = function(e) conditionMessage(e))
  expect_false(identical(detected, "built"))
  expect_match(detected, "More than one model found")
})

test_that("RT-428: keepOriginals = FALSE leaves exactly one options file", {
  dA <- .FakeModelDir("mA", environment())
  dB <- .FakeModelDir("mB", environment())
  combinedDir <- dA

  suppressWarnings(suppressMessages(tryCatch(
    CombineModelRuns(c(dA, dB), c("mA", "mB"), combinedModelName = "cAB",
                     keepOriginals = FALSE),
    error = function(e) NULL)))

  # Pre-fix the source options file was deleted only when the directories
  # differed, so `mA_options.txt` survived here and shadowed the combined one.
  expect_false(file.exists(file.path(combinedDir, "mA_options.txt")))
  expect_equal(list.files(combinedDir, pattern = "_options\\.txt$"),
               "cAB_options.txt")
})

# ── RT-432: the detection pattern's unescaped dot ───────────────────────────

test_that("RT-432: `.` in the options pattern is a literal, not a wildcard", {
  dir <- withr::local_tempdir()
  file.create(file.path(dir, "bar_optionsXtxt"))

  # Pre-fix `"_options.txt$"` matched this, so `bar_optionsXtxt` was accepted
  # as a model name -- while the companion `sub("_options\\.txt$", ...)` two
  # lines later, correctly escaped, then failed to strip the suffix.
  expect_error(StratPosterior(readDir = dir), "No model found")
})

# ── RT-418 / RT-426: end-to-end, on the post-#397 mixed-nThin posterior ─────

test_that("RT-418: burnInPercent is reported against each run's own iterations", {
  # Re-verified against post-#397 main: reported `50 10` where both runs in
  # fact discard iterations <= 500 of 1000, i.e. 50% each. (Pre-#397 the same
  # posterior reported `50 2`.) The reporting path indexed run r's `saveIter`
  # by a row index derived from the shortest run; RT-190 had already fixed the
  # *selection* path to use an absolute-iteration threshold.
  post <- .PosteriorFixtureCombine(10, 2, envir = environment())
  expect_equal(unname(post[[c("mcmcSummary", "completedIter")]]), c(1000, 1000))
  expect_equal(unname(lengths(post[[c("mcmcSummary", "saveIter")]])), c(101, 501))

  s <- suppressWarnings(summary(post))
  expect_equal(unname(s[[c("general", "burnInPercent")]]), c(50, 50))

  # The reported figure must match what the selection path actually discarded:
  # each run keeps its own rows past iteration 500.
  saveIter <- post[[c("mcmcSummary", "saveIter")]]
  expect_equal(unname(s[[c("general", "nSamplesUsedPerRun")]]),
               vapply(saveIter, function(si) sum(si > 500), integer(1)))

  # The absolute-`burnIn` branch changed too and needs its own pin: the old
  # reporting path used `saveIter[[r]][burninIndex]` (the last *saved*
  # iteration <= burnIn), the new one uses the threshold itself, so the two
  # differ whenever `burnIn` is not a saved iteration of every run.
  sAbs <- suppressWarnings(summary(post, burnIn = 500))
  expect_equal(unname(sAbs[[c("general", "burnInPercent")]]), c(50, 50))
  sAbs2 <- suppressWarnings(summary(post, burnIn = 250))
  expect_equal(unname(sAbs2[[c("general", "burnInPercent")]]), c(25, 25))
})

test_that("RT-418: equal nThin with unequal run lengths is still correct", {
  # The control that proves the defect is exactly `nThin` heterogeneity: with a
  # shared `saveIter` schedule the old row-index route and the new absolute
  # threshold agree.
  post <- .PosteriorFixtureCombine(2, 2, envir = environment())
  s <- suppressWarnings(summary(post))
  expect_equal(unname(s[[c("general", "burnInPercent")]]), c(50, 50))
})

test_that("RT-426: per-run sample counts are not collapsed to run 1's", {
  # Newly reachable after PR #397: `completedIter` is now correctly 1000/1000
  # while row counts are 101/501, so `evenLength` (keyed on `completedIter`
  # alone) became TRUE and print() emitted "Total samples: 602 (101 per run)"
  # and "300 samples (50 per run)" -- correct numbers underneath, wrong display.
  post <- .PosteriorFixtureCombine(10, 2, envir = environment())
  s <- suppressWarnings(summary(post))
  out <- paste(utils::capture.output(print(s)), collapse = "\n")

  expect_match(out, "101 to 501 per run")
  expect_match(out, "50 to 250 per run")
  expect_false(grepl("(101 per run)", out, fixed = TRUE))
  expect_false(grepl("(50 per run)", out, fixed = TRUE))
})

test_that("RT-426: equal-length runs still print a single collapsed figure", {
  s <- suppressWarnings(summary(stratPosterior1))
  out <- paste(utils::capture.output(print(s)), collapse = "\n")
  expect_false(grepl(" to ", out, fixed = TRUE))
})
