# Issue #129: the draw store the stopping rule reads, and the checkpoint that
# consults it.
#
# The store is where the rule can go quietly wrong: `.EssFunc()` calls `acf()`,
# which reads a series as evenly spaced, and `.ConvergenceDrawSet()` aligns
# runs by intersecting iteration labels. Both hold only while every retained
# draw sits on one stride, so that invariant is asserted directly.

# The saved-sample layout: iteration, chain, then parameters.
CvMat <- function(iters, nChains = 1L, nPar = 3L) {
  grid <- expand.grid(chain = seq_len(nChains), iteration = iters)
  cbind(iteration = grid[["iteration"]], chain = grid[["chain"]],
        matrix(stats::runif(nrow(grid) * nPar), nrow(grid), nPar))
}

CvFill <- function(store, n, seed = 1, offset = 0) {
  set.seed(seed)
  .ConvergenceAppend(
    store,
    cbind(seq_len(n), 1, matrix(stats::rnorm(n * 2) + offset, n, 2)),
    cols = 3:4)
}

# ── which columns are monitored ──────────────────────────────────────────────

test_that("the monitored columns are the diagnostic set, and only it", {
  cols <- c("iteration", "chain", "alpha_site2", "gamma_site2",
            "sigma_d13C", "lambda_d13C", "posterior", "prior_parameters",
            "prior_overlap", "likelihood_spline", "likelihood_ties",
            "proposal_accepted", "proposal_number", "beta_1", "beta_2")
  idx <- .ConvergenceMonitorCols(cols, c("alpha_site2", "gamma_site2"))

  expect_identical(cols[idx],
                   c("alpha_site2", "gamma_site2", "sigma_d13C", "lambda_d13C",
                     "posterior", "prior_parameters", "prior_overlap",
                     "likelihood_spline", "likelihood_ties"))
  # Betas and the proposal bookkeeping are excluded, as in summary()'s psrfPar,
  # and neither index column can be selected by accident.
  expect_false(any(idx %fin% 1:2))
})

# ── the accumulator ──────────────────────────────────────────────────────────

test_that("only the cold chain is accumulated", {
  set.seed(1)
  store <- .ConvergenceCollapse(
    .ConvergenceAppend(.ConvergenceStore(), CvMat(1:10, nChains = 4L),
                       cols = 3:5))

  expect_identical(store[["iters"]], as.numeric(1:10))
  expect_identical(ncol(store[["draws"]]), 3L)
})

test_that("decimation keeps one uniform stride, whatever order rows arrive in", {
  # Rows arrive in uneven blocks, and by the time a block lands the store is
  # already decimated -- so deciding retention from a row's position in the
  # store, rather than in the saved sequence, would leave two strides in one
  # series.
  set.seed(2)
  store <- .ConvergenceStore()
  it <- 0L
  for (block in c(30L, 7L, 51L, 1L, 40L, 120L, 3L)) {
    store <- .ConvergenceAppend(store, CvMat(it + seq_len(block)), cols = 3:5)
    it <- it + block
    store <- .ConvergenceCollapse(store, cap = 64L)
    expect_lte(nrow(store[["draws"]]), 64L)
    expect_identical(nrow(store[["draws"]]), length(store[["iters"]]))
    expect_length(unique(diff(store[["iters"]])), 1L)
  }
  # 252 saved rows against a cap of 64: two doublings, so stride 4 from row 1.
  expect_identical(store[["thin"]], 2L)
  expect_identical(store[["iters"]][[1]], 1)
  expect_identical(unique(diff(store[["iters"]])), 4)
})

test_that("retained iterations stay a subset of a less-thinned store", {
  # Dyadic nesting: two runs that decimated at different points still share
  # every label the coarser one kept, so cross-run R-hat needs no interpolation.
  set.seed(3)
  fine <- .ConvergenceCollapse(
    .ConvergenceAppend(.ConvergenceStore(), CvMat(1:400), cols = 3:5),
    cap = 400L)
  coarse <- .ConvergenceCollapse(
    .ConvergenceAppend(.ConvergenceStore(), CvMat(1:400), cols = 3:5),
    cap = 50L)

  expect_true(all(coarse[["iters"]] %fin% fine[["iters"]]))
})

test_that("an empty or all-hot block leaves the store untouched", {
  store <- .ConvergenceAppend(.ConvergenceStore(), CvMat(integer(0)),
                              cols = 3:5)
  expect_identical(store[["seen"]], 0)
  expect_null(.ConvergenceCollapse(store)[["draws"]])

  # Every row a hot chain: nothing to keep, and `seen` must not advance or the
  # dyadic grid would shift under the next block.
  hot <- CvMat(1:5, nChains = 2L)
  hot <- hot[hot[, 2L] == 2, , drop = FALSE]
  expect_identical(.ConvergenceAppend(store, hot, cols = 3:5)[["seen"]], 0)
})

test_that("the adaptation window is never stored", {
  # A checkpoint is gated on being past adaptation, and the collapse that
  # enforces the cap runs only at a checkpoint -- so a row from the adaptation
  # window is not merely useless (no burn-in below `endAdapting` is admissible)
  # but uncappable. `seen` must not advance for one either, or the dyadic grid
  # would sit at a different phase in a run that adapted for longer.
  set.seed(6)
  store <- .ConvergenceAppend(.ConvergenceStore(), CvMat(1:40), cols = 3:5,
                              floorIter = 25)

  expect_identical(store[["seen"]], 15)
  expect_identical(.ConvergenceCollapse(store)[["iters"]], as.numeric(26:40))

  # Every row inside the window: nothing kept, nothing counted.
  expect_identical(
    .ConvergenceAppend(.ConvergenceStore(), CvMat(1:40), cols = 3:5,
                       floorIter = 1e6),
    .ConvergenceStore())
})

test_that("a single saved iteration is handled as a matrix", {
  # The R engine appends one saved iteration at a time.
  set.seed(4)
  store <- .ConvergenceAppend(.ConvergenceStore(), CvMat(7L), cols = 3:5)
  expect_identical(.ConvergenceCollapse(store)[["iters"]], 7)
})

# ── the checkpoint ───────────────────────────────────────────────────────────

test_that("two consecutive agreeing checkpoints are needed to stop", {
  dir <- withr::local_tempdir()
  Check <- function(store) {
    .ConvergenceCheckpoint(store, list(rHat = 1.5, ess = 10), dir, "m",
                           run = 1, nRun = 1, endAdapting = 0,
                           crossRun = FALSE, useSentinel = FALSE)
  }

  first <- Check(CvFill(.ConvergenceStore(), 300))
  expect_identical(first[["streak"]], 1L)
  expect_false(first[["met"]])

  second <- Check(CvFill(first, 300, seed = 2))
  expect_identical(second[["streak"]], .kConvergenceStreak)
  expect_true(second[["met"]])

  # No sentinel unless it was asked for: in sequential mode one would stop the
  # runs that have yet to start.
  expect_false(.StopSentinelExists(dir, "m"))
})

test_that("a failing checkpoint resets the streak", {
  dir <- withr::local_tempdir()
  store <- .ConvergenceCheckpoint(
    CvFill(.ConvergenceStore(), 300), list(rHat = 1.5), dir, "m", run = 1,
    nRun = 1, endAdapting = 0, crossRun = FALSE, useSentinel = FALSE)
  expect_identical(store[["streak"]], 1L)

  # An unreachable ESS target on the same draws.
  store <- .ConvergenceCheckpoint(
    store, list(ess = 1e9), dir, "m", run = 1, nRun = 1, endAdapting = 0,
    crossRun = FALSE, useSentinel = FALSE)
  expect_identical(store[["streak"]], 0L)
  expect_false(store[["met"]])
})

test_that("too few draws defer without publishing a decision", {
  dir <- withr::local_tempdir()
  store <- .ConvergenceCheckpoint(
    CvFill(.ConvergenceStore(), 4), list(rHat = 1.5), dir, "m", run = 1,
    nRun = 1, endAdapting = 0, crossRun = FALSE, useSentinel = FALSE)

  expect_identical(store[["streak"]], 0L)
  expect_false(file.exists(.ConvergenceDrawsPath(dir, "m", 1)))
})

test_that("a run publishes its decision to its peers, and honours theirs", {
  dir <- withr::local_tempdir()
  Check <- function(store) {
    .ConvergenceCheckpoint(store, list(rHat = 1.5, ess = 10), dir, "m",
                           run = 1, nRun = 1, endAdapting = 0,
                           crossRun = FALSE, useSentinel = TRUE)
  }
  store <- Check(CvFill(.ConvergenceStore(), 300))
  store <- Check(CvFill(store, 300, seed = 2))

  expect_true(store[["met"]])
  expect_true(.StopSentinelExists(dir, "m"))

  # A peer arriving at its first checkpoint stops at once, without needing a
  # streak of its own and without reading anyone's draws.
  peer <- .ConvergenceCheckpoint(
    .ConvergenceStore(), list(rHat = 1.5), dir, "m", run = 2, nRun = 2,
    endAdapting = 0, crossRun = TRUE, useSentinel = TRUE)
  expect_true(peer[["met"]])
  expect_identical(peer[["streak"]], 0L)
})

test_that("no burn-in inside the adaptation window can stop a run (#260)", {
  dir <- withr::local_tempdir()
  Check <- function(store) {
    .ConvergenceCheckpoint(store, list(rHat = 1.5), dir, "m", run = 1,
                           nRun = 1, endAdapting = 1e6, crossRun = FALSE,
                           useSentinel = FALSE)
  }
  store <- Check(CvFill(.ConvergenceStore(), 300))
  expect_false(Check(CvFill(store, 300, seed = 2))[["met"]])
})

test_that("convergenceStop = TRUE means the documented defaults", {
  expect_identical(.ConvergenceCriteria(TRUE), .kConvergenceDefault)
  expect_identical(.kConvergenceDefault, list(rHat = 1.02, ess = 200))

  # The floor has to outlast the first post-adaptation checkpoint even on
  # perfectly independent draws, or the streak requirement is the only thing
  # standing between an easy model and a near-empty result. Under the defaults
  # (`nIter = 1000`, `writeMCMCfile = 0.1`, `endAdapting = 500`) the first is
  # at iteration 600 with 100 retained draws, and `.EssFunc()` caps ESS at the
  # retained draws -- so the earliest checkpoint that can meet it is the third.
  expect_gt(.kConvergenceDefault[["ess"]], 0.1 * 1000)
})

# ── clean-up ─────────────────────────────────────────────────────────────────

test_that("the rule's files are cleared, and nothing else is", {
  dir <- withr::local_tempdir()
  set.seed(5)
  .WriteConvergenceDraws(dir, "m", 1, CvMat(1:20)[, -(1:2), drop = FALSE],
                         1:20, 0)
  .WriteStopSentinel(dir, "m")
  file.create(file.path(dir, "m_convergence_run_2.rds.tmp"))
  keep <- file.path(dir, c("m_mcmc_run_1.rds", "m_samples_run_1.txt",
                           "other_convergence_run_1.rds"))
  file.create(keep)

  .ClearConvergenceFiles(dir, "m")

  expect_false(.StopSentinelExists(dir, "m"))
  expect_false(file.exists(.ConvergenceDrawsPath(dir, "m", 1)))
  expect_false(file.exists(file.path(dir, "m_convergence_run_2.rds.tmp")))
  expect_true(all(file.exists(keep)))
})

test_that("modelName is never spliced into a pattern", {
  # A name holding regex metacharacters must not widen the match (RT-135).
  dir <- withr::local_tempdir()
  file.create(file.path(dir, c("a(b)_convergence_run_1.rds",
                               "axb_convergence_run_1.rds")))

  .ClearConvergenceFiles(dir, "a(b)")

  expect_false(file.exists(file.path(dir, "a(b)_convergence_run_1.rds")))
  expect_true(file.exists(file.path(dir, "axb_convergence_run_1.rds")))
})

# ── the stop condition ───────────────────────────────────────────────────────

test_that("convergence is a stop condition, and the four-argument call works", {
  now <- .sb_steady_seconds()

  expect_false(.StopCondition(5, 10, NULL, now))
  expect_true(.StopCondition(5, 10, NULL, now, convergenceMet = TRUE))
  # The Shiny fork's copy of the loop still calls this with four arguments.
  expect_true(.StopCondition(10, 10, NULL, now))
})

test_that("the time limit reads either clock", {
  # `perRunTimeLimit` is in hours, so a limit of zero is already spent.
  expect_true(.StopCondition(1, 10, 0, .sb_steady_seconds()))
  expect_false(.StopCondition(1, 10, 1, .sb_steady_seconds()))
  # Subtracting monotonic seconds from the fork's POSIXct would error rather
  # than merely mislead, so that call keeps its own branch.
  expect_true(.StopCondition(1, 10, 0, Sys.time()))
  expect_false(.StopCondition(1, 10, 1, Sys.time()))
})
