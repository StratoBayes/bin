# `bLambda` caps lambda's conjugate posterior mean at
# `(aLambda + (numBasis - 2) / 2) * bLambda` -- a bound stated in lambda's own
# units of `span^3 / sd(y)^2`, held at an absolute 1000. #1361 raised it where
# the GH #551 floor had overtaken that cap, which is the corner where lambda
# degenerates to a point mass. Between that corner and a healthy prior lies a
# band where the cap alone fixes lambda, with real variance and nothing to
# notice it by (#1136).

rescaled <- function(hMul = 1, vMul = 1) {
  sig <- stratData1[["signal"]]
  sig[["height"]] <- sig[["height"]] * hMul
  sig[["value"]] <- sig[["value"]] * vMul
  StratData(sig, zColumn = "height", siteColumn = "site",
            signalColumn = "value")
}

# Fixed knots: under the default the knot span is drawn from the priors, so
# tr(D) -- and every quantity keyed to it -- moves run to run. Here it is the
# data range with 25% padding, which makes every number below exact.
# `knotRange` is auto-reported, hence the message suppression.
heightModel <- function(data, nKnots, ...) {
  suppressMessages(
    StratModel(data, alignmentScale = "height", sedModel = "site",
               nKnots = nKnots, flexibleKnots = FALSE, ...)
  )
}

# How far the largest mean lambda the prior permits sits above the scale the
# data support. Below 1 the prior, not the data, is choosing lambda.
capMargin <- function(model, data, sig = 1L) {
  gibbs <- model[[c("priors", "gibbs")]]
  splineBase <- model[["splineBase"]]
  y <- .EnsurePreExtracted(data)[[c("signalAttr", "signalValuesVec")]][[sig]]
  shape <- gibbs[["aLambda"]][[sig]] + (splineBase[["num_basis"]] - 2) / 2
  shape * gibbs[["bLambda"]][[sig]] / .LambdaStar(splineBase, y)
}

# Ordinary unit choices: metres to millimetres, and a signal recorded in
# thousandths of the unit the constant 1000 happened to suit.
rescalings <- list(c(1e3, 1), c(1, 1e-3), c(1e6, 1e-3))

test_that("no unit choice leaves the prior capping lambda below scale (#1136)", {
  for (nKnots in c(10, 25)) {
    for (scale in c(list(c(1, 1)), rescalings)) {
      data <- rescaled(scale[[1]], scale[[2]])
      expect_gt(capMargin(heightModel(data, nKnots), data), 1)
    }
  }
})

test_that("the absolute default does cap it, so the fixture discriminates", {
  # Without this the test above would pass on data that was never in danger.
  # Margins under `bLambda = 1000`, all exact at fixed knots: 8.7e-6 and 2.3e-4
  # for millimetre heights, 8.7e-3 and 0.23 for the rescaled signal, and
  # 8.7e-21 / 2.3e-19 for both together -- up to twenty decades below the scale
  # the data support.
  for (nKnots in c(10, 25)) {
    for (scale in rescalings) {
      data <- rescaled(scale[[1]], scale[[2]])
      capped <- heightModel(data, nKnots, bLambda = 1000)
      expect_lt(capMargin(capped, data), 1)
      # An explicit value is the caller's, and is never rescaled.
      expect_identical(capped[[c("priors", "gibbs", "bLambda")]][[1]], 1000)
    }
  }
})

test_that("native-scale data keeps the absolute default untouched (#1136)", {
  # `sb_lambda.h`'s floor calibration was measured under `bLambda = 1000`, so
  # the change must be inert wherever the cap was not biting. Margins here are
  # 8.7e3 and 2.3e5 -- nowhere near the criterion.
  data <- rescaled()
  for (nKnots in c(10, 25)) {
    model <- heightModel(data, nKnots)
    expect_identical(model[[c("priors", "gibbs", "bLambda")]][[1]], 1000)
    expect_gt(capMargin(model, data), 1e3)
  }
})

test_that("adding knots switches the collision criterion off (#1136)", {
  # Why #1361's criterion is widened rather than left alone. The collision it
  # tests for is the floor overtaking the ceiling; the ceiling grows with
  # numBasis while lambdaStar falls, so on one fixed dataset -- millimetre
  # heights -- the collision stops firing between 10 knots and 25 while the cap
  # goes on sitting three decades under the data's own scale.
  data <- rescaled(1e3, 1)
  collides <- function(nKnots) {
    model <- heightModel(data, nKnots, bLambda = 1000)
    gibbs <- model[[c("priors", "gibbs")]]
    shape <- gibbs[["aLambda"]][[1]] +
      (model[[c("splineBase", "num_basis")]] - 2) / 2
    gibbs[["lambdaMin"]][[1]] >= shape * gibbs[["bLambda"]][[1]]
  }
  expect_true(collides(10))
  expect_false(collides(25))
  # ... and the cap is the same defect at both.
  expect_lt(capMargin(heightModel(data, 25, bLambda = 1000), data), 1e-3)
  expect_gt(capMargin(heightModel(data, 25), data), 1)
})

test_that("a raised bLambda lands a fixed distance above the scale (#1136)", {
  # `.BLambdaRel * lambdaStar`, so the margin is `.BLambdaRel * shape` exactly:
  # free of the unit choice, and of everything but the knot count it is stated
  # in terms of.
  for (nKnots in c(10, 25)) {
    for (scale in rescalings) {
      data <- rescaled(scale[[1]], scale[[2]])
      expect_equal(capMargin(heightModel(data, nKnots), data),
                   .BLambdaRel * (1 + nKnots / 2))
    }
  }
})

test_that("the widened criterion still covers every collision (#1361)", {
  # Subsumption: the floor is `.LambdaFloorRel` (1e-5) times the scale, so a
  # ceiling under the floor is a ceiling under the scale five decades over.
  set.seed(1136)
  y <- rnorm(50)
  tinyD <- list(D = diag(8) * 1e-12, num_basis = 10L)
  floorTiny <- .LambdaFloor(tinyD, list(y))
  expect_gt(floorTiny, (1 + 4) * 1000)
  expect_gt(.BLambdaAboveScale(1000, 1, 10L, floorTiny), 1000)
})

test_that("a signal with no usable scale keeps the absolute default (#1136)", {
  # `.LambdaFloor()` falls back to the absolute `.LambdaMin` when `.LambdaStar`
  # is NA, which is not `.LambdaFloorRel` times anything -- the scale recovered
  # by division is then a fiction, and must not be able to trigger a raise.
  expect_identical(.BLambdaAboveScale(1000, 1, 10L, .LambdaMin), 1000)
  expect_identical(.BLambdaAboveScale(1000, 1, 10L, NA_real_), 1000)
})

test_that("the bundled flexible-knot fixtures stay clear of it (#1136)", {
  # Load-bearing for `test-signal-arg-names.R`, which compares two models'
  # gibbs priors: with flexible knots a raised bLambda is a function of the
  # tr(D) draw, so that comparison holds only while the default stands. The
  # thinnest margin measured over 100 draws is 10.9, on stratData2's second
  # signal; 20 seeded draws here.
  set.seed(1136)
  for (i in 1:20) {
    model <- StratModel(stratData2, stratPrior2, alignmentScale = "age",
                        sedModel = "s", alphaPosition = "b", nKnots = 5,
                        sigmaFixed = c(0.5, 0.5))
    expect_true(all(model[[c("priors", "gibbs", "bLambda")]] == 1000))
  }
})
