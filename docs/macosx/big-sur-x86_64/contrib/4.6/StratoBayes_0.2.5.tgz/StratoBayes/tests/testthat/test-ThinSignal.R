Dense <- function(site = "s1", from = 0, to = 20, n = 500, noise = 0) {
  z <- seq(from, to, length.out = n)
  data.frame(site = site, height = z,
             value = sin(z) + if (noise > 0) rnorm(n, 0, noise) else 0,
             stringsAsFactors = FALSE)
}

test_that("ThinSignal() averages to the requested resolution", {
  d <- Dense(n = 500)
  thin <- ThinSignal(d, blockLength = 1)
  # 20 blocks over heights 0-20, plus the two unaveraged endpoints
  expect_equal(nrow(thin), 22)
  expect_equal(names(thin), names(d))
  expect_false(is.unsorted(thin$height))

  # maxPointsPerSite is an upper bound that the endpoints count against
  expect_lte(nrow(ThinSignal(d, maxPointsPerSite = 50)), 50)
  expect_equal(nrow(ThinSignal(d, maxPointsPerSite = 50)), 50)
})

test_that("ThinSignal() keeps each site's first and last measurement whole", {
  set.seed(3)
  d <- rbind(Dense("s1", 0, 20, 300, noise = 0.5), Dense("s2", 5, 31, 220,
                                                         noise = 0.5))
  thin <- ThinSignal(d, blockLength = 1.7)
  for (s in c("s1", "s2")) {
    ds <- d[d$site == s, ]
    ts <- thin[thin$site == s, ]
    ends <- c(1, nrow(ds))
    # Range preserved exactly, and by carrying the extreme rows through whole:
    # position and value both come across untouched.
    expect_equal(range(ts$height), range(ds$height))
    expect_equal(ts$value[c(1, nrow(ts))], ds$value[ends])
  }

  # Each measurement is used exactly once: the endpoints are held out of the
  # blocks rather than also being averaged into them. Heights 0-10 in blocks of
  # 5 give interior groups 1:4 and 5:9; including the endpoints would instead
  # give means of 2 and 7.5.
  e <- data.frame(site = "s1", height = 0:10, value = as.numeric(0:10))
  expect_equal(ThinSignal(e, blockLength = 5)$value, c(0, 2.5, 7, 10))
})

test_that("ThinSignal() blocks span equal distance, not equal row count", {
  # Sampling density varies 10-fold between the halves, so equal-count blocks
  # would span unequal distances. Equal-length blocks must not.
  dense <- data.frame(site = "s1", height = seq(0, 10, length.out = 400),
                      value = 1)
  sparse <- data.frame(site = "s1", height = seq(10, 20, length.out = 40),
                       value = 2)
  d <- rbind(dense, sparse)
  thin <- ThinSignal(d, blockLength = 1)
  # The retained endpoints sit outside the first and last centroid, roughly half
  # a block from each, so only the interior spacing is expected to be uniform.
  gaps <- diff(thin$height)
  gaps <- gaps[-c(1, length(gaps))]
  # Spacing is near-uniform in distance. It is not exactly so: where a block
  # holds only a few measurements its centroid cannot sit exactly at the block
  # midpoint. Equal-COUNT blocks over the same data span 0.55 to 5.6 -- a ratio
  # near 10 -- so the comparison, not an absolute tolerance, is the real test.
  expect_lt(max(gaps) / min(gaps), 1.6)
  # Half the retained rows fall in each half of the section, despite the 10x
  # density difference; a row-count rule would put ~91% in the dense half.
  expect_equal(sum(thin$height < 10), sum(thin$height > 10), tolerance = 1)
})

test_that("ThinSignal() places every interior value at its block's centroid", {
  d <- rbind(Dense("s1", 0, 20, 300), Dense("s2", 5, 31, 220))
  L <- 1.7
  thin <- ThinSignal(d, blockLength = L)
  for (s in c("s1", "s2")) {
    got <- thin$height[thin$site == s]
    want <- range(d$height[d$site == s])
    # No centroid can lie outside the block it summarizes, so the interior stays
    # clear of the endpoints by up to half a block at either end.
    interior <- got[-c(1, length(got))]
    expect_gt(interior[[1]] - want[[1]], 0)
    expect_lt(interior[[1]] - want[[1]], L)
    expect_lt(want[[2]] - interior[[length(interior)]], L)
  }
  expect_equal(unique(thin$site), c("s1", "s2"))
})

test_that("ThinSignal() suppresses noise rather than discarding measurements", {
  set.seed(1)
  d <- Dense(n = 2000, noise = 0.4)
  thin <- ThinSignal(d, blockLength = 0.5)
  sub <- d[round(seq(1, nrow(d), length.out = nrow(thin))), ]
  # Averaging retains the information of the discarded rows, so its residuals
  # are far smaller than a subsample of the same size. Measured over the
  # averaged rows only: the two retained endpoints are raw measurements, and
  # carry the full noise by design.
  averaged <- thin[-c(1, nrow(thin)), ]
  expect_lt(sd(averaged$value - sin(averaged$height)),
            0.5 * sd(sub$value - sin(sub$height)))
})

test_that("ThinSignal() drops empty blocks and keeps sparse columns usable", {
  # A recovery gap between 8 and 15 leaves interior blocks empty
  d <- rbind(data.frame(site = "s1", height = seq(0, 8, by = 0.1), value = 1),
             data.frame(site = "s1", height = seq(15, 20, by = 0.1), value = 2))
  thin <- ThinSignal(d, maxPointsPerSite = 100)
  expect_lt(nrow(thin), 100)                  # gap blocks vanish
  expect_false(any(is.na(thin$value)))
  expect_true(all(thin$height >= 0 & thin$height <= 20))

  # A block whose signal is wholly NA yields NA for that column alone
  d2 <- data.frame(site = "s1", height = seq(0, 10, by = 0.5),
                   a = c(rep(NA_real_, 8), rep(2, 13)),
                   b = 1)
  thin2 <- ThinSignal(d2, blockLength = 2, signalColumn = c("a", "b"))
  expect_true(any(is.na(thin2$a)))
  expect_false(any(is.na(thin2$b)))
})

test_that("ThinSignal() averages several signal columns independently", {
  d <- data.frame(site = "s1", height = seq(0, 10, length.out = 100),
                  a = 1:100, b = seq(2, 200, length.out = 100))
  thin <- ThinSignal(d, blockLength = 5, signalColumn = c("a", "b"))
  expect_equal(thin$b, thin$a * 2, tolerance = 1e-8)
})

test_that("ThinSignal() warns when a carried column varies within a block", {
  d <- data.frame(site = "s1", height = seq(0, 10, length.out = 100),
                  value = 1, lithology = rep(c("mud", "sand"), 50))
  expect_warning(ThinSignal(d, blockLength = 5), "lithology")
  # Constant within each block, so nothing to warn about
  d$lithology <- rep(c("mud", "sand"), each = 50)
  expect_silent(ThinSignal(d, blockLength = 5))
})

test_that("ThinSignal() honours non-default column names and zScale = depth", {
  d <- data.frame(core = "c1", depth = seq(0, 30, length.out = 200),
                  d13C = seq(0, 1, length.out = 200))
  thin <- ThinSignal(d, blockLength = 3, siteColumn = "core",
                     zColumn = "depth", signalColumn = "d13C")
  expect_equal(nrow(thin), 12)
  expect_equal(names(thin), c("core", "depth", "d13C"))
  expect_true(all(thin$depth >= 0 & thin$depth <= 30))
})

test_that("ThinSignal() warns when the block outruns the knot spacing", {
  d <- Dense(n = 400)                          # heights 0-20
  # 21 knots over [0, 20] -> spacing 1; a block of 3 erases what the spline
  # could have fitted, a block of 0.5 does not.
  expect_warning(ThinSignal(d, blockLength = 3, nKnots = 21),
                 "exceeds the knot spacing")
  expect_silent(ThinSignal(d, blockLength = 0.5, nKnots = 21))

  # An explicit knotRange is wider, so the same block length is admissible
  expect_silent(ThinSignal(d, blockLength = 3, nKnots = 21,
                           knotRange = c(-30, 90)))

  # With maxPointsPerSite the warning names the worst-affected site
  d2 <- rbind(Dense("s1", 0, 20, 200), Dense("wide", 0, 200, 200))
  expect_warning(ThinSignal(d2, maxPointsPerSite = 10, nKnots = 21),
                 "site wide")
})

test_that("ThinSignal() rejects malformed input", {
  d <- Dense(n = 50)
  expect_error(ThinSignal(1:10, blockLength = 1), "must be a data frame")
  expect_error(ThinSignal(d), "exactly one of")
  expect_error(ThinSignal(d, blockLength = 1, maxPointsPerSite = 10),
               "exactly one of")
  expect_error(ThinSignal(d, blockLength = 0), "positive number")
  expect_error(ThinSignal(d, blockLength = c(1, 2)), "positive number")
  expect_error(ThinSignal(d, blockLength = Inf), "positive number")
  expect_error(ThinSignal(d, maxPointsPerSite = 0), "3 or more")
  # Two of the budget are always the endpoints, so 2 leaves nothing to average
  expect_error(ThinSignal(d, maxPointsPerSite = 2), "3 or more")
  expect_error(ThinSignal(d, blockLength = 1, zColumn = "nope"),
               "no column\\(s\\) named: nope")
  expect_error(ThinSignal(d[0, ], blockLength = 1), "no rows")
  expect_error(ThinSignal(transform(d, height = as.character(height)),
                          blockLength = 1), "must be numeric")
  # Averaging a column that cannot be averaged would return NA for every block,
  # so refuse rather than empty it
  expect_error(
    ThinSignal(data.frame(site = "s1", height = 1:6, lith = letters[1:6]),
               blockLength = 2, signalColumn = "lith"),
    "not numeric"
  )
  # A missing or infinite z has no block to belong to
  Spoil <- function(col, value) {
    bad <- d
    bad[[col]][[3]] <- value
    bad
  }
  expect_error(ThinSignal(Spoil("height", NA), blockLength = 1),
               "must be finite")
  expect_error(ThinSignal(Spoil("height", Inf), blockLength = 1),
               "must be finite")
  expect_error(ThinSignal(Spoil("site", NA), blockLength = 1), "no NA")
  expect_error(ThinSignal(d, blockLength = 1, nKnots = 1), "2 or more")
  expect_error(ThinSignal(d, blockLength = 1, nKnots = 21,
                          knotRange = c(10, 1)), "increasing order")
})

test_that("ThinSignal() handles degenerate sites", {
  # A site with no height range, or holding nothing but its own endpoints,
  # cannot be blocked
  d <- rbind(Dense("s1", 0, 20, 100),
             data.frame(site = "s2", height = 3, value = 1),
             data.frame(site = "s3", height = rep(7, 4), value = 1:4),
             data.frame(site = "s4", height = c(0, 9), value = c(1, 2)))
  thin <- ThinSignal(d, blockLength = 2)
  expect_equal(sum(thin$site == "s2"), 1)
  expect_equal(sum(thin$site == "s3"), 4)
  expect_equal(sum(thin$site == "s4"), 2)
  expect_equal(nrow(thin[thin$site == "s1", ]), 12)
})

test_that("ThinSignal() output is accepted by StratData()", {
  d <- rbind(Dense("s1", 0, 20, 600, noise = 0.2),
             Dense("s2", 4, 26, 400, noise = 0.2))
  thin <- ThinSignal(d, blockLength = 0.5)
  sd <- StratData(thin, maxPointsPerSite = Inf)
  expect_s3_class(sd, "StratData")
  expect_equal(nrow(sd$signal), nrow(thin))
})
