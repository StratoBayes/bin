# Tests for R/mcmcFunctions.R

test_that(".UpdateMCMC visits finite-temperature chains hottest-first, by chain index (RT-002/RT-081)", {
  # RT-002 (fixed PR #266): the old expression
  #   order(which(is.finite(temperatures)), decreasing = TRUE)
  # sorts the *ranks* returned by which() (i.e. positions within the
  # which()-vector), not the chain indices themselves, and does so in the
  # wrong direction. For temperatures = c(2, Inf, 1, 0.5), which(is.finite(.))
  # = c(1, 3, 4); the buggy expression evaluates to c(3, 2, 1) -- chain 2
  # (temperature Inf, not finite) is wrongly visited, and chain 4 is skipped
  # entirely. The fix computes `.finiteChains[order(temperatures[.finiteChains],
  # decreasing = TRUE)]`, correctly visiting only the finite chains, hottest
  # first: c(1, 3, 4).
  #
  # .UpdateProposal is mocked (not re-executed) so this test isolates the
  # chain-selection/ordering logic in .UpdateMCMC itself, regardless of
  # proposal-update internals.
  visited <- integer(0)
  testthat::local_mocked_bindings(
    .UpdateProposal = function(data, model, mcmc, chain, inLateAdaptation) {
      visited <<- c(visited, chain)
      mcmc[["metro"]]
    },
    .package = "StratoBayes"
  )

  mcmc <- list(
    metro = list(nextAdapt = 0, adaptProposalInterval = 10,
                adaptProposal = c(TRUE, TRUE, TRUE, TRUE)),
    temper = list(temperatures = c(2, Inf, 1, 0.5))
  )

  StratoBayes:::.UpdateMCMC(data = NULL, model = NULL, mcmc = mcmc,
                            i = 1, inLateAdaptation = FALSE)

  # Non-vacuity: the mock must actually have fired.
  expect_length(visited, 3L)

  expect_equal(visited, c(1L, 3L, 4L))

  # Discriminator: confirm the pre-fix expression gives a different, wrong
  # answer for the same input, so this test would have caught the bug.
  buggyOrder <- order(which(is.finite(mcmc[[c("temper", "temperatures")]])),
                      decreasing = TRUE)
  expect_equal(buggyOrder, c(3L, 2L, 1L))
  expect_false(identical(visited, buggyOrder))
})
