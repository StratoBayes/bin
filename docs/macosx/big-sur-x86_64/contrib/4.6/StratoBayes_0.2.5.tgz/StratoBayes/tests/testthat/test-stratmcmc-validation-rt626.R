# Construction-time guards in StratMCMC(), from red-team round 18.
#
# All tests here assert on the constructed StratMCMC object or on a pure helper,
# never on sampled values: a short MCMC run's numbers are not portable.

data(stratModel1, package = "StratoBayes", envir = environment())

propNames <- function(mcmc) names(mcmc[["propose"]])

# ── RT-626: adaptProposal = FALSE starves the history-free proposals ─────────
#
# .UpdateProposals() is the only writer of columns 2-6 of proposalProbability,
# and it never runs without adaptation, so those types stayed at selection
# probability 0 for the entire run. With gradientProposals = "on" that left
# Prior as the only live proposal, i.e. sampling the prior rather than the
# posterior.

test_that("RT-626: history-free proposals are live under adaptProposal = FALSE", {
  mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                    adaptProposal = FALSE)
  nm <- propNames(mcmc)
  freeOfHistory <- c("Univariate", "ShiftAlphas", "ShiftAlphasRandJoint",
                     "ShiftAlphasRandSeparate")

  expect_true(all(mcmc[[c("metro", "proposalValid")]][, freeOfHistory]))
  expect_true(all(mcmc[[c("metro", "proposalProbability")]][, freeOfHistory] > 0))

  # Univariate proposes with per-parameter SDs; without them it cannot run.
  uvArgs <- mcmc[[c("metro", "proposalArgs")]][[1]][[which(nm == "Univariate")]]
  expect_length(uvArgs, stratModel1[["parametersLength"]])
  expect_true(all(is.finite(uvArgs)))
  expect_true(all(uvArgs > 0))

  # Multivariate has no history-free fallback and must stay unavailable.
  expect_false(mcmc[[c("metro", "proposalValid")]][, "Multivariate"])
  expect_equal(unname(mcmc[[c("metro", "proposalProbability")]][, "Multivariate"]), 0)
})

test_that("RT-626: adaptProposal = FALSE + gradientProposals = 'on' is not prior-only", {
  mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                    adaptProposal = FALSE, gradientProposals = "on")
  # The product formed by both engines when selecting a proposal type.
  selection <- mcmc[[c("metro", "proposalProbabilityWeights")]][1, ] *
    mcmc[[c("metro", "proposalProbability")]][1, ]
  expect_gt(sum(selection > 0), 1L)
})

test_that("RT-626: adaptProposal = TRUE keeps the pre-adaptation proposal set", {
  mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 1)
  live <- names(which(mcmc[[c("metro", "proposalProbability")]][1, ] > 0))
  expect_setequal(live, c("Prior", "SiteBlock", "NeighbourScaled"))
})

# ── RT-628: startAdapting silently clamped onto a defaulted endAdapting ──────

test_that("RT-628: an explicit startAdapting past endAdapting warns", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                      startAdapting = 600),
    "startAdapting"
  )
  expect_equal(mcmc[["startAdapting"]], mcmc[["endAdapting"]])
})

test_that("RT-628: a short run's default window is clamped without warning", {
  expect_no_warning(StratMCMC(stratModel1, nIter = 4, nChains = 1))
})

# ── RT-627: .IntegerSequence dropped the last scheduled checkpoint ───────────

test_that("RT-627: .IntegerSequence appends the final iteration, never overwrites", {
  expect_equal(.IntegerSequence(1, 1000, 0.34), c(340, 680, 1000))
  expect_equal(.IntegerSequence(1, 1000, 0.6), c(600, 1000))
  # Fractions that already land on b are unchanged.
  expect_equal(.IntegerSequence(1, 1000, 0.2), c(200, 400, 600, 800, 1000))
  expect_equal(.IntegerSequence(1, 1000, 1), 1000)
  for (frac in c(0.1, 0.2, 0.25, 0.34, 0.5, 0.6, 0.75, 1)) {
    s <- .IntegerSequence(1, 1000, frac)
    expect_identical(s[[length(s)]], 1000)
    expect_false(anyDuplicated(s) > 0)
  }
})

# ── RT-629: an oversized adaptTemperaturesIntervall disabled adaptation ──────

test_that("RT-629: an unreachable temperature-adaptation schedule warns", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 4, tempering = TRUE,
                      adaptTemperatures = TRUE,
                      adaptTemperaturesIntervall = 100000),
    "adaptTemperatures"
  )
  expect_false(mcmc[[c("temper", "adaptTemperatures")]])
  # The ratio buffer is never written once adaptation is off.
  expect_equal(nrow(mcmc[[c("temper", "temperRatioCapped")]]), 1L)
})

test_that("RT-629: a workable explicit interval is silent and stays enabled", {
  mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 4, tempering = TRUE,
                    adaptTemperatures = TRUE, adaptTemperaturesIntervall = 20)
  expect_true(mcmc[[c("temper", "adaptTemperatures")]])
})

test_that("RT-629: an interval inherited by a continuation does not warn", {
  # `adaptTemperaturesIntervall` is in `.stratMCMCCheckpointFieldMap`, so a
  # continuation forwards the checkpoint's value as a concrete argument even
  # where the caller named nothing -- exactly the RT-133 trap, one argument
  # over. `.adaptTemperaturesExplicit = FALSE` is how `RunStratModel()`
  # reports that, and is what separates this from the case above.
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 4, tempering = TRUE,
              adaptTemperatures = TRUE, adaptTemperaturesIntervall = 100000,
              .adaptTemperaturesExplicit = FALSE)
  )
})

# ── RT-630: startMonitoring could land beyond the last iteration ─────────────

test_that("RT-630: the acceptance-monitoring window lies inside the run", {
  for (n in c(5, 10, 19, 50, 1000)) {
    mcmc <- StratMCMC(stratModel1, nIter = n, nChains = 1)
    accMon <- mcmc[[c("metro", "acceptanceMonitor")]]
    expect_lte(accMon[["startMonitoring"]], accMon[["endMonitoring"]])
    expect_gte(accMon[["startMonitoring"]], mcmc[["startIter"]])
    # `iterationsMonitored` stated this same span until #1340 removed it as
    # dead; `endMonitoring` is the live field the window is bounded by.
    expect_equal(accMon[["endMonitoring"]], mcmc[["endIter"]])
  }
})

# ── RT-631: non-finite proposalProbabilityWeights ───────────────────────────
#
# The C++ engine compares a uniform draw against cumulative weights; a
# non-finite total makes every comparison false and the last proposal type is
# selected on every iteration, silently.

test_that("RT-631: non-finite proposalProbabilityWeights are rejected", {
  for (bad in c(Inf, -Inf, NaN)) {
    expect_error(
      StratMCMC(stratModel1, nIter = 100, nChains = 1,
                proposalProbabilityWeights = replace(rep(1, 8), 2, bad)),
      "proposalProbabilityWeights"
    )
  }
  expect_silent(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                          proposalProbabilityWeights = rep(1, 8)))
})

# ── RT-634: writeMCMCfile = TRUE coerced to 1 despite its own error message ──

test_that("RT-634: a logical writeMCMCfile is rejected", {
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         writeMCMCfile = TRUE),
               "writeMCMCfile")
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         writeMCMCfile = NA),
               "writeMCMCfile")
  # FALSE and a numeric fraction remain valid.
  expect_false(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         writeMCMCfile = FALSE)[["writeMCMCiterations"]])
  expect_equal(StratMCMC(stratModel1, nIter = 100, nChains = 1,
                         writeMCMCfile = 0.5)[["writeMCMCiterations"]],
               c(50, 100))
})

# ── RT-638: completedIter never validated on a fresh object ─────────────────

test_that("RT-638: completedIter must be consistent with a fresh run", {
  expect_error(StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                         completedIter = 500),
               "completedIter")
  expect_error(StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                         completedIter = NA),
               "completedIter")
  expect_error(StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                         completedIter = -1),
               "completedIter")
  expect_s3_class(StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                            completedIter = 0),
                  "StratMCMC")
})

# ── RT-637: clustMinPtsMCMC unbounded relative to the clustered history ──────

test_that("RT-637: clustMinPtsMCMC beyond the history length warns", {
  expect_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 1,
              clustMethodMCMC = "dbscan", clustMinPtsMCMC = 1000),
    "clustMinPtsMCMC"
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 1,
              clustMethodMCMC = "dbscan", clustMinPtsMCMC = 5)
  )
})

test_that("RT-637: the ceiling is the trimmed history, not the whole window", {
  # `.RecentStampRows()` keeps only the most recent `.kRecentHistoryFraction`
  # of the window before clustering, so a `clustMinPtsMCMC` inside
  # `(0.5 * window, window]` is equally impossible and used to go unwarned.
  expect_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 1,
              adaptProposalWindow = 200, clustMethodMCMC = "dbscan",
              clustMinPtsMCMC = 150),
    "clustMinPtsMCMC"
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 1,
              adaptProposalWindow = 200, clustMethodMCMC = "dbscan",
              clustMinPtsMCMC = 100)
  )

  expect_identical(StratoBayes:::.RecentRowCount(200), 100)
})

# ── RT-626 follow-up: all-Fixed alphas leave the ShiftAlphas variants dead ───

test_that("RT-626: ShiftAlphas stays off when every alpha prior is Fixed", {
  data(stratData1, package = "StratoBayes", envir = environment())
  fixedAlphas <- stratModel1[[c("priors", "metro")]]
  fixedAlphas[["alpha_site_2"]] <- Fixed(0)
  fixedAlphas[["alpha_site_3"]] <- Fixed(0)
  class(fixedAlphas) <- c("StratPrior", "list")

  model <- StratModel(stratData1, priors = fixedAlphas,
                      alignmentScale = "height", sedModel = "site")
  expect_length(model[[c("ind", "alphaNotFixed")]], 0L)

  mcmc <- StratMCMC(model, nIter = 1000, nChains = 1, adaptProposal = FALSE)
  shift <- c("ShiftAlphas", "ShiftAlphasRandJoint", "ShiftAlphasRandSeparate")
  prob <- mcmc[[c("metro", "proposalProbability")]]

  # The RT-264 guards make all three permanent no-ops here, so a positive
  # weight would spend a fixed share of the budget on a move that cannot move.
  expect_equal(unname(prob[, shift]), rep(0, length(shift)))
  expect_false(any(mcmc[[c("metro", "proposalValid")]][, shift]))

  # The gate must not take Univariate down with it.
  expect_gt(prob[, "Univariate"], 0)
})
