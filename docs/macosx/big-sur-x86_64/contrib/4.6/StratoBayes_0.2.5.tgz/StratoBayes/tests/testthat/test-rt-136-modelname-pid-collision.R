# RT-136: the auto-generated modelName seed at R/RunStratModel.R is derived
# solely from the current time (millisecond resolution). Two processes
# reaching that line in the same millisecond draw the same seed and so the
# same 12-character modelName, silently colliding on a shared modelDir.
#
# Fix: mix Sys.getpid() into the seed so same-millisecond collisions across
# processes are avoided. These tests exercise the seed arithmetic directly
# (mirroring R/RunStratModel.R) rather than the full auto-naming code path,
# since forcing two real processes to hit the same millisecond is not
# feasible in a unit test.

.rt136_time_seed <- function(timeString) {
  as.numeric(gsub("[^0-9]", "", timeString))
}

test_that("the pre-fix seed formula collides across pids at the same instant", {
  timeString <- format(Sys.time(), "%Y-%m-%d %H:%M:%OS3")
  timeSeed <- .rt136_time_seed(timeString)

  # Pre-fix: seed depended only on the timestamp.
  seedA <- timeSeed %% .Machine$integer.max
  seedB <- timeSeed %% .Machine$integer.max
  expect_equal(seedA, seedB)
})

test_that("mixing in Sys.getpid() avoids the same-instant collision (RT-136 fix)", {
  timeString <- format(Sys.time(), "%Y-%m-%d %H:%M:%OS3")
  timeSeed <- .rt136_time_seed(timeString)

  pidA <- 1234L
  pidB <- 5678L

  seedA <- (timeSeed + pidA) %% .Machine$integer.max
  seedB <- (timeSeed + pidB) %% .Machine$integer.max

  expect_false(seedA == seedB)

  set.seed(seedA)
  nameA <- paste0(paste(sample(letters, 10, replace = TRUE), collapse = ""),
                  paste(sample(0:9, 2, replace = TRUE), collapse = ""))
  set.seed(seedB)
  nameB <- paste0(paste(sample(letters, 10, replace = TRUE), collapse = ""),
                  paste(sample(0:9, 2, replace = TRUE), collapse = ""))

  expect_false(identical(nameA, nameB))
})

test_that("RunStratModel's auto-naming block actually includes Sys.getpid() (RT-136)", {
  # Guards against the fix being silently reverted/removed: the seed
  # construction for the auto-generated modelName must reference
  # Sys.getpid() so same-millisecond seeds from different processes diverge.
  src <- paste(deparse(body(RunStratModel)), collapse = "\n")
  expect_true(grepl("Sys\\.getpid\\(\\)", src))
})
