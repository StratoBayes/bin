test_that("Tops() maps a reordered `parameters` frame by name, not by position (#1292)", {
  p <- ExtractParameters(stratPosterior1, parameters = "parameters",
                         maxSamples = 9)
  canonical <- as.data.frame(p)
  reversed <- canonical[, rev(colnames(canonical)), drop = FALSE]
  # same data, same names, different column order
  expect_identical(canonical, reversed[, colnames(canonical), drop = FALSE])

  fromCanonical <- Tops(stratPosterior1, refHeights = c(1, 2),
                        parameters = canonical, quantiles = 0.5)
  fromReversed <- Tops(stratPosterior1, refHeights = c(1, 2),
                       parameters = reversed, quantiles = 0.5)
  expect_equal(fromReversed, fromCanonical)
})

test_that("StratMap() maps a reordered `parameters` frame by name (#1292)", {
  p <- ExtractParameters(stratPosterior1, parameters = "parameters",
                         maxSamples = 9)
  canonical <- as.data.frame(p)
  reversed <- canonical[, rev(colnames(canonical)), drop = FALSE]

  fromCanonical <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                            parameters = canonical, quantiles = 0.5)
  fromReversed <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                           parameters = reversed, quantiles = 0.5)
  expect_equal(fromReversed, fromCanonical)
})

test_that(".ValidateParams() reorders, stamps or warns as the names warrant (#1292)", {
  nm <- c("alpha", "beta", "gamma")
  df <- data.frame(gamma = 3, alpha = 1, beta = 2)

  reordered <- .ValidateParams(df, len = 3, ifNull = NULL, paramNames = nm)
  expect_identical(colnames(reordered), nm)
  expect_equal(unname(unlist(reordered)), c(1, 2, 3))

  # unnamed input keeps the historic stamping behaviour (RT-466)
  stamped <- .ValidateParams(1:3, len = 3, ifNull = NULL, paramNames = nm)
  expect_identical(colnames(stamped), nm)
  expect_equal(unname(unlist(stamped)), c(1, 2, 3))

  # names present but not a permutation: stamped, but no longer silently
  expect_warning(
    other <- .ValidateParams(data.frame(x = 1, y = 2, z = 3), len = 3,
                             ifNull = NULL, paramNames = nm),
    "do not match the model's parameter names"
  )
  expect_identical(colnames(other), nm)
  expect_equal(unname(unlist(other)), c(1, 2, 3))

  # duplicated supplied names are ambiguous to reorder, so they are stamped
  dup <- data.frame(alpha = 1, alpha = 2, beta = 3, check.names = FALSE)
  expect_warning(
    .ValidateParams(dup, len = 3, ifNull = NULL, paramNames = nm),
    "do not match the model's parameter names"
  )
})

test_that("a 0-row `parameters` is rejected instead of yielding all-NaN output (#1295)", {
  p <- ExtractParameters(stratPosterior1, parameters = "parameters",
                         maxSamples = 9)
  empty <- as.data.frame(p)[0, , drop = FALSE]

  expect_error(.ValidateParams(empty, len = ncol(empty), ifNull = NULL),
               "at least one row")
  expect_error(Tops(stratPosterior1, refHeights = c(1, 2), parameters = empty),
               "at least one row")
  expect_error(StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                        parameters = empty),
               "at least one row")
})
