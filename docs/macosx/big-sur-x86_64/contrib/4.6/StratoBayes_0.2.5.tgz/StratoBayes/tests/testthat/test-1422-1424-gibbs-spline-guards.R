# Arguments for a well-posed .sb_gibbs_spline call on a clamped cubic basis
# with more basis functions (10) than data points (5), so that pinning lambda at
# 0 makes B'B/sigma^2 indefinite enough for the Cholesky ridge ladder to fire.
# Two fewer basis functions and LAPACK factorises it unridged, with no warning.
.SplineGibbsArgs <- function(...) {
  knots <- c(rep(0, 4), seq(0, 1, length.out = 8)[-c(1, 8)], rep(1, 4))
  p <- length(knots) - 4L
  n <- 5L
  utils::modifyList(
    list(B = .sb_spline_design(knots, seq(0, 1, length.out = n), 4L),
         y = seq_len(n) / 10,
         D = crossprod(diff(diag(p), differences = 2)),
         sigma0 = 1, lambda0 = 1e-4, aLambda = 1, bLambda = 1000,
         shapeSigma = 5, bSigma = 1, numBasis = p, nIter = 2L, outInd = 1:2,
         lambdaFixed = FALSE, lambdaFixedValue = 0),
    list(...))
}

test_that(".sb_gibbs_spline rejects sigma hyperparameters it cannot use (#1422)", {
  set.seed(1)
  expect_silent(do.call(.sb_gibbs_spline, .SplineGibbsArgs()))
  for (arg in c("bSigma", "shapeSigma", "sigma0")) {
    for (bad in c(0, -1, NA_real_, Inf)) {
      args <- .SplineGibbsArgs()
      args[[arg]] <- bad
      expect_error(do.call(.sb_gibbs_spline, args), arg,
                   info = paste(arg, "=", bad))
    }
  }
})

test_that(".sb_gibbs_spline rejects lambda hyperparameters it cannot use (#1422)", {
  set.seed(1)
  # 5e-324 is positive and finite, but 1 / 5e-324 is Inf, which zeroes the
  # gamma scale exactly as bLambda = 0 does.
  for (bad in c(0, -1, NA_real_, Inf, 5e-324)) {
    expect_error(do.call(.sb_gibbs_spline, .SplineGibbsArgs(bLambda = bad)),
                 "bLambda", info = paste("bLambda =", bad))
  }
  # aLambda only has to keep the gamma shape aLambda + (numBasis - 2) / 2
  # positive, so a legitimate improper aLambda = 0 must still be accepted.
  expect_silent(do.call(.sb_gibbs_spline, .SplineGibbsArgs(aLambda = 0)))
  for (bad in c(-5, NA_real_, Inf)) {
    expect_error(do.call(.sb_gibbs_spline, .SplineGibbsArgs(aLambda = bad)),
                 "aLambda", info = paste("aLambda =", bad))
  }
  # Both are read only where lambda is sampled, so pinning lambda has to keep
  # nonsense values acceptable rather than newly rejecting a working call.
  expect_silent(do.call(.sb_gibbs_spline,
                        .SplineGibbsArgs(bLambda = 0, aLambda = -Inf,
                                         lambdaFixed = TRUE,
                                         lambdaFixedValue = 1e-4)))
})

test_that("BayesianSpline names the offending hyperparameter (#1422)", {
  set.seed(1)
  x <- seq(0, 8, length.out = 40)
  y <- sin(x) + rnorm(40, 0, 0.2)
  # bLambda = 0 previously ran to completion with lambda pinned at exactly 0.
  expect_error(BayesianSpline(x, y, nKnots = 8, nIter = 50, bLambda = 0),
               "bLambda")
  expect_error(BayesianSpline(x, y, nKnots = 8, nIter = 50, bSigma = 0),
               "bSigma")
  # aSigma reaches C++ only as shapeSigma = aSigma + n / 2, and previously
  # returned a completed fit whose entire sigma chain was Inf. R's own rgamma
  # warns on the way past, which is not the diagnosis the user needs.
  expect_error(
    suppressWarnings(BayesianSpline(x, y, nKnots = 8, nIter = 50,
                                    aSigma = -100)),
    "shapeSigma|sigma0")
})

test_that("sb_spline_design matches splineDesign at every order (#1423)", {
  # find_span()'s right-boundary walk read knots[nknots] and returned a span
  # one past the last valid one at ord == 1, so the row came back all zero.
  Clamped <- function(ord, inner) {
    c(rep(inner[1], ord), inner[-c(1, length(inner))],
      rep(inner[length(inner)], ord))
  }
  Unclamped <- function(ord, inner) {
    seq(inner[1] - ord, inner[length(inner)] + ord,
        length.out = length(inner) + 2 * ord)
  }
  inner <- seq(0, 1, length.out = 6)

  for (ord in 1:4) {
    for (Knots in c(Clamped, Unclamped)) {
      ek <- Knots(ord, inner)
      nbasis <- length(ek) - ord
      # The supported domain, ending exactly on the last valid knot -- the only
      # x that reaches the right-boundary branch.
      x <- c(seq(ek[ord], ek[nbasis + 1], length.out = 7), ek[nbasis + 1])
      B <- .sb_spline_design(ek, x, as.integer(ord))
      expect_equal(B, unclass(splines::splineDesign(ek, x, ord = ord,
                                                    outer.ok = TRUE)),
                   info = paste("ord =", ord))
      expect_equal(rowSums(B), rep(1, length(x)), info = paste("ord =", ord))
    }
  }
})

test_that("sb_spline_design handles degenerate ord-1 knot vectors (#1423)", {
  # Two knots is the shortest vector that reached the out-of-bounds read: a
  # single basis function, worth 1 across the whole span including its top end.
  expect_equal(.sb_spline_design(c(0, 1), c(0, 0.5, 1), 1L),
               matrix(1, nrow = 3, ncol = 1))
  # Repeated knots give the right-boundary walk something to walk over, which
  # at ord == 1 it must not do: the last column stays the answer even where its
  # own span has zero width.
  for (ek in list(c(0, 0.5, 0.5, 1), c(0, 0.5, 1, 1), c(0, 0.5, 1, 1, 1))) {
    expect_equal(.sb_spline_design(ek, 1, 1L),
                 unclass(splines::splineDesign(ek, 1, ord = 1,
                                               outer.ok = TRUE)),
                 info = paste(ek, collapse = ","))
  }
  # length(knots) == 2 * ord - 1 == 1 passes the wrapper's own length check.
  expect_equal(dim(.sb_spline_design(0, 0, 1L)), c(1L, 0L))
})

test_that("the Gibbs failure surfaces its own error under warn = 2 (#1424)", {
  # Iteration 1 recovers through the ridge ladder and records the warning; the
  # recovered |beta| overflows y's scale, sending sigma to Inf, so iteration 2
  # has no positive diagonal left to scale a ridge against.
  set.seed(1)
  Fail <- function() {
    do.call(.sb_gibbs_spline,
            .SplineGibbsArgs(y = 1e200 * c(1, 1.1, 0.9, 1.2, 0.8),
                             lambda0 = 0, lambdaFixed = TRUE,
                             lambdaFixedValue = 0, nIter = 5L, outInd = 1:5))
  }
  expect_error(Fail(), "could not factorise")
  withr::with_options(list(warn = 2), expect_error(Fail(), "could not factorise"))

  # The warning is not merely suppressed: it still reaches a caller whose run
  # recovers rather than failing.
  expect_warning(do.call(.sb_gibbs_spline,
                         .SplineGibbsArgs(lambdaFixed = TRUE,
                                          lambdaFixedValue = 0, nIter = 5L,
                                          outInd = 1:5)),
                 "recovered with a relative ridge")
})
