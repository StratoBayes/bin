# Regression tests for the propose-from-prior Hastings correction (RT-270).
#
# The default "Prior" proposal is an INDEPENDENCE proposal: it redraws the whole
# metro vector from the priors, q(x*|x) = g(x*). Its MH acceptance therefore
# needs the Hastings factor g(x)/g(x*). Omitting it makes the kernel reversible
# w.r.t. prior^2 * L (the prior counted twice), so the posterior shrinks toward
# the prior and comes out under-dispersed.
#
# The existing recovery tests cannot see this: they check medians at true values
# that sit at the prior means, where shrink-to-prior leaves the median unmoved.
# These tests use analytic ground truth (a 1-D conjugate posterior) where the
# bias is unmistakable in both the mean and the sd.


# ── SBC-style ground truth through the real .AcceptProposal ──────────────────
# 1-D conjugate: prior g = N(0, 1), likelihood N(y = 3; theta, 1).
#   True posterior          : N(mean = 1.5,  sd = sqrt(0.5)  = 0.7071)
#   prior^2 * L (no Hastings): N(mean = 1.0,  sd = sqrt(1/3)  = 0.5774)
# Propose from the prior, accept via the package's own .AcceptProposal.

test_that("propose-from-prior recovers the true posterior with the Hastings term (RT-270)", {
  logPost <- function(theta) {
    dnorm(theta, 0, 1, log = TRUE) + dnorm(3, theta, 1, log = TRUE)
  }
  logG <- function(theta) dnorm(theta, 0, 1, log = TRUE)  # proposal density = prior

  run <- function(useHastings, n = 1.2e5) {
    x <- 0; lpx <- logPost(x); keep <- numeric(n)
    for (i in seq_len(n)) {
      xs  <- rnorm(1, 0, 1)                       # independence draw from prior
      lps <- logPost(xs)
      lh  <- if (useHastings) logG(x) - logG(xs) else 0
      if (.AcceptProposal(lpx, lps, 1, logHastings = lh)) { x <- xs; lpx <- lps }
      keep[i] <- x
    }
    keep[-seq_len(n %/% 6)]                        # drop burn-in
  }

  set.seed(20270712)
  corrected <- run(TRUE)
  expect_equal(mean(corrected), 1.5,    tolerance = 0.05)
  expect_equal(sd(corrected),   0.7071, tolerance = 0.03)

  # Omitting the correction (logHastings = 0, the pre-fix behaviour) reproduces
  # the known biased result: mean pulled toward the prior and ~18% too narrow.
  uncorrected <- run(FALSE)
  expect_equal(mean(uncorrected), 1.0,    tolerance = 0.05)
  expect_equal(sd(uncorrected),   0.5774, tolerance = 0.03)

  # The correction must actually widen the posterior (not a no-op).
  expect_gt(sd(corrected), sd(uncorrected) + 0.05)
})


# ── .AcceptProposal API: default keeps symmetric proposals unchanged ─────────

test_that(".AcceptProposal logHastings defaults to the symmetric case", {
  # Equal log-posterior, no Hastings: exp(0) = 1 > runif(1) is always TRUE.
  expect_true(.AcceptProposal(-10, -10, 1))
  # An impossible reverse move (-Inf Hastings) forces rejection.
  expect_false(.AcceptProposal(-10, -10, 1, logHastings = -Inf))
  # A dominant Hastings term flips a move that the posterior ratio alone rejects.
  expect_true(.AcceptProposal(0, log(0.5), 1, logHastings = 10))
})


# ── .MetroProposalLog evaluates g against priorsProposals, not the priors ────

test_that(".MetroProposalLog uses priorsProposals and matches priors by default (RT-270)", {
  mkPrior <- function(mean, sd) {
    list(R = stats::rnorm, D = stats::dnorm, Q = stats::qnorm,
         args = list(mean = mean, sd = sd))
  }
  priorList <- list(a = mkPrior(0, 1), b = mkPrior(2, 0.5))
  x <- c(a = 0.3, b = 1.7)

  # Default: priorsProposals == priors, so proposal and prior densities agree.
  mDefault <- list(priors = list(metro = priorList), priorsProposals = priorList)
  expect_equal(.MetroProposalLog(mDefault, x), .MetroPriorLog(mDefault, x))
  expect_equal(unname(.MetroProposalLog(mDefault, x)),
               c(dnorm(0.3, 0, 1, log = TRUE), dnorm(1.7, 2, 0.5, log = TRUE)))

  # Custom priorsProposals: .MetroProposalLog must follow the *proposal*, so it
  # diverges from the prior density on the parameters that differ.
  propList <- list(a = mkPrior(5, 1), b = mkPrior(2, 0.5))
  mCustom  <- list(priors = list(metro = priorList), priorsProposals = propList)
  expect_false(isTRUE(all.equal(.MetroProposalLog(mCustom, x),
                                .MetroPriorLog(mCustom, x))))
  expect_equal(unname(.MetroProposalLog(mCustom, x)),
               c(dnorm(0.3, 5, 1, log = TRUE), dnorm(1.7, 2, 0.5, log = TRUE)))
})

test_that("the Prior-move Hastings term is zero when unchanged and correctly signed", {
  mkPrior <- function(mean, sd) {
    list(R = stats::rnorm, D = stats::dnorm, Q = stats::qnorm,
         args = list(mean = mean, sd = sd))
  }
  m <- list(priors = list(metro = list(a = mkPrior(0, 1), b = mkPrior(2, 0.5))),
            priorsProposals = list(a = mkPrior(0, 1), b = mkPrior(2, 0.5)))
  hastings <- function(xOld, xNew) {
    sum(.MetroProposalLog(m, xOld)) - sum(.MetroProposalLog(m, xNew))
  }

  x <- c(a = 0.3, b = 1.7)
  expect_equal(hastings(x, x), 0)                 # no move -> no correction

  xHigh <- c(a = 0, b = 2)                         # at the proposal modes: high g
  xLow  <- c(a = 3, b = 0)                         # deep in the tails:   low g
  # Moving to a higher-g state down-weights (g(new) > g(old) => term < 0).
  expect_lt(hastings(xLow, xHigh), 0)
  expect_gt(hastings(xHigh, xLow), 0)
})

# Note: a full simulation-based-calibration sweep across replications on the
# live engines (R and C++) is the recommended heavy-test follow-up (see
# dev/red-team). It is intentionally out of the unit suite: the engines draw
# from R's RNG in different orders, so cross-engine reproducibility is not
# asserted here (cf. test-cpp-engine-integration.R).


# ── RT-381/RT-413/#827: reject-not-redraw, no Prior re-key ──────────────────
# For an MCMC move (`initialState = FALSE`), .GenerateValidProposal() draws
# exactly ONCE from q(.|x) and rejects the whole move on any support
# failure; .UpdateState() never re-selects a different proposal type on a
# rejection either. See the reject-not-redraw comment on that function's
# main loop for why (invariant density pi(x)*Z(x), not pi(x), otherwise).
# `initialState = TRUE` keeps the old retry/fallback behaviour -- see the
# RT-222 tests in test-ModelFunctions.R for that path.

.RT275TestFixture <- function(nChains = 1) {
  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      ties = testDataMulti$ties,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  priorsm <- structure(list(
      "alpha_site1" = UniformPrior(min = 10, max = 60),
      "alpha_site2" = UniformPrior(min = -10, max = 60),
      "alpha_site3" = UniformPrior(min = -10, max = 60),
      "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 0.1)),
    class = c("list", "StratPrior"))
  model <- StratModel(tmulti, priorsm, alignmentScale = "age",
                      sedModel = "site", alphaPosition = "bottom")
  mcmc <- StratMCMC(model, nIter = 10, nChains = nChains)
  list(tmulti = tmulti, model = model, mcmc = mcmc)
}

test_that(".GenerateValidProposal rejects extreme rate (RT-381/#827)", {
  f <- .RT275TestFixture()
  state0 <- .GenerateInitialState(f$tmulti, f$model, f$mcmc, 1)

  # gammaLog_site1 (a rate parameter, index 4) is set far above ratesMax (14).
  # initialState = FALSE, so parametersInitial is not used and ProposeMetro is
  # actually called -- exactly once, whatever it returns.
  extremeParams <- c(30, 30, 30, 100, 1, 1, 5)
  callCount <- 0
  stubPropose <- function(parameters, n, model, ...) {
    callCount <<- callCount + 1
    extremeParams
  }

  expect_no_warning(
    stateNew <- .GenerateValidProposal(
      f$tmulti, f$model, f$mcmc, stateOld = state0, ProposeMetro = stubPropose,
      initialState = FALSE, chain = 1
    )
  )

  expect_null(stateNew)
  expect_equal(callCount, 1)
})

test_that(".GenerateValidProposal rejects knot range (RT-381/#827)", {
  # .RT275TestFixture()'s model defaults to flexibleKnots = TRUE, under which
  # inKnotRange is unconditionally TRUE -- build a fixed-knot variant so the
  # knotRange check is actually live.
  f <- .RT275TestFixture()
  fixedKnotModel <- StratModel(
    f$tmulti,
    structure(
      list(
        "alpha_site1" = UniformPrior(min = 10, max = 60),
        "alpha_site2" = UniformPrior(min = -10, max = 60),
        "alpha_site3" = UniformPrior(min = -10, max = 60),
        "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
        "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
        "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
        "gap_site2_1" = ExponentialPrior(rate = 0.1)
      ),
      class = c("list", "StratPrior")
    ),
    alignmentScale = "age", sedModel = "site", alphaPosition = "bottom",
    flexibleKnots = FALSE, knotRange = c(0, 65)
  )
  fixedKnotMcmc <- StratMCMC(fixedKnotModel, nIter = 10, nChains = 1)
  state0 <- .GenerateInitialState(f$tmulti, fixedKnotModel, fixedKnotMcmc, 1)

  # Not a rate parameter (alpha_site1, in-range), but an age far outside
  # knotRange = c(0, 65) -- fails the knotRange check, not check_rates.
  callCount <- 0
  outOfRangeParams <- state0[[c("metro", "parameters")]]
  outOfRangeParams["alpha_site1"] <- 1e5
  stubPropose <- function(parameters, n, model, ...) {
    callCount <<- callCount + 1
    outOfRangeParams
  }

  stateNew <- .GenerateValidProposal(
    f$tmulti, fixedKnotModel, fixedKnotMcmc, stateOld = state0,
    ProposeMetro = stubPropose, initialState = FALSE, chain = 1
  )

  expect_null(stateNew)
  expect_equal(callCount, 1)
})

test_that(".GenerateValidProposal draws once, no failure (RT-381/#827)", {
  f <- .RT275TestFixture()
  state0 <- .GenerateInitialState(f$tmulti, f$model, f$mcmc, 1)

  callCount <- 0
  stubPropose <- function(parameters, n, model, ...) {
    callCount <<- callCount + 1
    .MetroPriorSample(n = n, model = model, ...)
  }

  stateNew <- .GenerateValidProposal(
    f$tmulti, f$model, f$mcmc, stateOld = state0, ProposeMetro = stubPropose,
    initialState = FALSE, chain = 1
  )

  expect_false(is.null(stateNew))
  expect_equal(callCount, 1)
  expect_false(isTRUE(stateNew$usedPriorFallback))
})

test_that(".UpdateState keeps original proposal (RT-381/RT-413/#827)", {
  f <- .RT275TestFixture()
  tmulti <- f$tmulti
  model <- f$model
  mcmc <- f$mcmc

  state <- .GenerateInitialState(tmulti, model, mcmc, 1)

  # Force proposal selection onto "Univariate" (never "Prior"), then make that
  # proposal deterministically emit an extreme rate every time it is called.
  uniIdx <- which(names(mcmc[["propose"]]) == "Univariate")
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, uniIdx] <- 1
  mcmc[[c("metro", "proposalProbability")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbability")]][1, uniIdx] <- 1
  callCount <- 0
  mcmc[["propose"]][[uniIdx]] <- function(parameters, n, model, ...) {
    callCount <<- callCount + 1
    p <- parameters
    p[model[["indRates"]][1]] <- 100
    p
  }

  set.seed(42)
  stateNew <- .UpdateState(tmulti, model, mcmc, state, 1)

  # Exactly one proposal draw: no redraw, and no re-selection of a different
  # (e.g. Prior) proposal type after the rejection.
  expect_equal(callCount, 1)
  expect_equal(stateNew[[c("metro", "proposalNumber")]], uniIdx)
  expect_false(stateNew[[c("metro", "accept")]])
  expect_equal(stateNew[[c("metro", "logPostNew")]], -10^30)
  # No consumer sets this field for an MCMC move (RT-413,
  # dev/red-team/proofs/RT-412-asymmetric-proposal-qratio.md section 6.2-6.3).
  expect_null(stateNew[["usedPriorFallback"]])
})

test_that(".UpdateState rejects from -1e30 sentinel (RT-387, #827)", {
  # -1e30 isn't literal -Inf, so old == new == -1e30 takes the ordinary
  # exp(0) = 1 branch and .AcceptProposal always accepts (the trap the
  # explicit override in .UpdateState guards against).
  expect_true(.AcceptProposal(-10^30, -10^30, temperature = 1, logHastings = 0))

  f <- .RT275TestFixture()
  tmulti <- f$tmulti
  model <- f$model
  mcmc <- f$mcmc

  state <- .GenerateInitialState(tmulti, model, mcmc, 1)
  state[[c("metro", "logPost")]] <- -10^30

  uniIdx <- which(names(mcmc[["propose"]]) == "Univariate")
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbabilityWeights")]][1, uniIdx] <- 1
  mcmc[[c("metro", "proposalProbability")]][1, ] <- 0
  mcmc[[c("metro", "proposalProbability")]][1, uniIdx] <- 1
  mcmc[["propose"]][[uniIdx]] <- function(parameters, n, model, ...) {
    p <- parameters
    p[model[["indRates"]][1]] <- 100
    p
  }

  set.seed(42)
  stateNew <- .UpdateState(tmulti, model, mcmc, state, 1)

  expect_false(stateNew[[c("metro", "accept")]])
  expect_equal(stateNew[[c("metro", "proposalNumber")]], uniIdx)
  # `state` was retained (never swapped for the NULL stateNew): its
  # parameters are untouched, still the ones .GenerateInitialState drew.
  expect_equal(stateNew[[c("metro", "parameters")]],
               state[[c("metro", "parameters")]])
})
