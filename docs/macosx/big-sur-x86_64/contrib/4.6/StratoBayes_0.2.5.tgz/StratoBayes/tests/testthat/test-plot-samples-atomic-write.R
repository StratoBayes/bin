.PlotSamplePaths <- function(dir, modelName, run) {
  stem <- paste0(modelName, "_plot_samples", "_run_", run)
  list(rds = file.path(dir, sprintf("%s.rds", stem)),
       temp = file.path(dir, sprintf("%s_temp.rds", stem)),
       lock = file.path(dir, sprintf("%s.lock", stem)))
}

test_that(".SafeWriteSamplesForPlotting publishes atomically and leaves no litter (#202)", {
  tmpDir <- tempfile("plotwrite")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  paths <- .PlotSamplePaths(tmpDir, "writetestmodel", 1)

  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, "writetestmodel", 1,
                                             matrix(1:4, 2, 2))
  expect_equal(as.vector(readRDS(paths$rds)), 1:4)
  expect_false(file.exists(paths$temp))
  expect_false(file.exists(paths$lock))

  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, "writetestmodel", 1,
                                             matrix(9:12, 2, 2))
  expect_equal(as.vector(readRDS(paths$rds)), 9:12)
  expect_false(file.exists(paths$temp))
})

test_that("a write that loses the rename race is dropped, never torn (#202)", {
  tmpDir <- tempfile("plotwrite")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  paths <- .PlotSamplePaths(tmpDir, "writetestmodel", 1)
  StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, "writetestmodel", 1,
                                             matrix(1:4, 2, 2))

  # a reader holding the destination open, as .CompileSamplesDuringMCMC does
  con <- file(paths$rds, open = "rb")
  expect_silent(
    StratoBayes:::.SafeWriteSamplesForPlotting(tmpDir, "writetestmodel", 1,
                                               matrix(9:12, 2, 2))
  )
  close(con)

  # the destination is one complete object either way, and the temp is gone
  published <- as.vector(readRDS(paths$rds))
  expect_true(identical(published, 1:4) || identical(published, 9:12))
  expect_false(file.exists(paths$temp))

  if (.Platform$OS.type == "windows") {
    # renaming onto an open file fails there, so the update is dropped
    expect_equal(published, 1:4)
  }
})

test_that(".CompileSamplesDuringMCMC tolerates missing and unreadable run files (#202)", {
  tmpDir <- tempfile("plotread")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  model <- list(outputParams = c("a", "b"))
  good <- file.path(tmpDir, "good.rds")
  saveRDS(cbind(1:3, 1, 10, 20), good)
  corrupt <- file.path(tmpDir, "corrupt.rds")
  writeLines("not an rds", corrupt)
  missing <- file.path(tmpDir, "absent.rds")

  expect_null(StratoBayes:::.CompileSamplesDuringMCMC(
    model, runFiles = list(missing, corrupt)))

  out <- StratoBayes:::.CompileSamplesDuringMCMC(
    model, runFiles = list(good, corrupt))
  expect_equal(dim(out)[[3]], 2)  # runs are the third dimension
  expect_true(all(is.na(out[, , 2, ])))
})

test_that(".CleanUpFiles removes an abandoned plot-samples temp file (#202)", {
  tmpDir <- tempfile("plotclean")
  dir.create(tmpDir)
  on.exit(unlink(tmpDir, recursive = TRUE), add = TRUE)

  paths <- .PlotSamplePaths(tmpDir, "cleantestmodel", 1)
  saveRDS(matrix(1:4, 2, 2), paths$rds)
  saveRDS(matrix(1:4, 2, 2), paths$temp)

  StratoBayes:::.CleanUpFiles(tmpDir, "cleantestmodel", nRun = 1,
                              isParallel = FALSE)
  expect_false(file.exists(paths$rds))
  expect_false(file.exists(paths$temp))
})
