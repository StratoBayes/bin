# Tests for C++ Gibbs sampling (.sb_gibbs) and H/tBy update (.sb_update_htby).
#
# The value-level oracles come from the conjugate full conditionals, not from
# another implementation: .GibbsSample() and .UpdateHtBy() are thin Rcpp
# wrappers on the functions under test, so an "R vs C++" assertion here would
# compare the C++ with itself (#584, r-engine-contract anti-drift rule 5).

# ── Setup: create model with initialized state ──────────────────────────────

setup_gibbs_state <- function(sigmaFixed = TRUE) {
  set.seed(8821)
  testData <- .GenerateTestData(
    "multi", version = "gap-names-3-sites-dates"
  )
  sData <- StratData(
    testData$signal, parts = testData$parts,
    ties = testData$ties,
    signalColumn = c("a", "b"), zColumn = "Hight",
    siteColumn = "SIT"
  )

  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = 10, max = 60),
    "alpha_site2" = UniformPrior(min = -10, max = 60),
    "alpha_site3" = UniformPrior(min = -10, max = 60),
    "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.1)
  ), class = c("list", "StratPrior"))

  model <- StratModel(sData, priors,
    alignmentScale = "age",
    sedModel = "site",
    alphaPosition = "bottom",
    sigmaFixed = sigmaFixed
  )
  mcmc <- StratMCMC(model, nIter = 10, nChains = 2)

  # Generate a valid initial state with Gibbs parameters
  state <- .GenerateValidProposal(
    sData, model, mcmc,
    stateOld = NULL,
    ProposeMetro = .MetroPriorSample,
    initialState = TRUE, chain = 1
  )
  state <- .FlexibleKnotsUpdateDB(sData, model, state)
  state <- .InitializeGibbs(sData, model, state)
  state <- .UpdateHtBy(sData, state)

  list(data = sData, model = model, state = state)
}

# ── Extract C++ inputs from R state/model objects ───────────────────────────

extract_gibbs_args <- function(env) {
  data  <- env$data
  model <- env$model
  state <- env$state

  nSignal <- data[["signalAttr"]][["signalN"]]

  # Determine D (penalty matrix)
  if ("spline" %in% names(state)) {
    D <- state[["spline"]][["D"]]
  } else {
    D <- model[["splineBase"]][["D"]]
  }

  # Convert lambda list to vector
  lambda <- vapply(
    seq_len(nSignal),
    function(m) state[["gibbs"]][["lambda"]][[m]],
    numeric(1)
  )

  sigma_fixed <- !isFALSE(model[["sigmaFixed"]])
  sigma_vals <- if (sigma_fixed) {
    as.numeric(model[["sigmaFixed"]])
  } else {
    numeric(nSignal)
  }

  list(
    H_list            = state[["metro"]][["H"]],
    tBy_list          = state[["metro"]][["tBy"]],
    B_list            = state[["metro"]][["B"]],
    signalValuesVec   = data[["signalAttr"]][["signalValuesVec"]],
    sigma_in          = state[["gibbs"]][["sigma"]],
    lambda_in         = lambda,
    D_mat             = D,
    Q_fallback        = state[["gibbs"]][["Q"]],
    aLambda           = model[["priors"]][["gibbs"]][["aLambda"]],
    bLambda           = model[["priors"]][["gibbs"]][["bLambda"]],
    shapeSigma        = model[["priors"]][["gibbs"]][["shapeSigma"]],
    bSigma_prior      = model[["priors"]][["gibbs"]][["bSigma"]],
    numBasis          = model[["splineBase"]][["num_basis"]],
    sigmaIsFixed      = sigma_fixed,
    sigmaFixedValues  = sigma_vals,
    hasOffsets        = FALSE,
    delta_list        = list(),
    obsToGroup_list   = list()
  )
}

# ── Hand-built inputs for the algebra-derived oracles ───────────────────────
#
# Nothing here may come from a StratoBayes function: an expected value produced
# by the code under test cannot disagree with it.
#
# Two signals with different lengths, sigmas, lambdas and hyperparameters, so a
# per-signal indexing slip shows up as a value mismatch.

hand_built_gibbs_inputs <- function() {
  p <- 5L
  nObs <- c(12L, 9L)
  sigma <- c(0.7, 1.3)

  B <- lapply(nObs, function(n) {
    x <- seq(0, 1, length.out = n)
    outer(x, seq_len(p), function(u, k) cos((k - 1) * pi * u))
  })
  y <- lapply(nObs, function(n) {
    x <- seq(0, 1, length.out = n)
    0.4 + 1.3 * x - 0.8 * x ^ 2
  })

  list(
    p          = p,
    sigma      = sigma,
    lambda     = c(2.5, 0.4),
    B          = B,
    y          = y,
    # Second-difference penalty: rank p - 2, the deficiency the (numBasis - 2)/2
    # term in the lambda full conditional accounts for.
    D          = crossprod(diff(diag(p), differences = 2)),
    H          = Map(function(Bm, s) crossprod(Bm) / s ^ 2, B, sigma),
    tBy        = Map(function(Bm, ym, s) as.numeric(crossprod(Bm, ym)) / s ^ 2,
                     B, y, sigma),
    aLambda    = c(1.2, 0.8),
    bLambda    = c(3, 5),
    shapeSigma = c(2.5, 1.7),
    bSigma     = c(0.9, 1.4)
  )
}

hand_built_gibbs_args <- function(f, sigmaIsFixed = FALSE) {
  list(  # names must be exact: .sb_gibbs has sigma_in/lambda_in/D_mat formals
    H_list           = f$H,
    tBy_list         = f$tBy,
    B_list           = f$B,
    signalValuesVec  = f$y,
    sigma_in         = f$sigma,
    lambda_in        = f$lambda,
    D_mat            = f$D,
    Q_fallback       = lapply(f$H, function(H) diag(nrow(H))),
    aLambda          = f$aLambda,
    bLambda          = f$bLambda,
    shapeSigma       = f$shapeSigma,
    bSigma_prior     = f$bSigma,
    numBasis         = f$p,
    sigmaIsFixed     = sigmaIsFixed,
    sigmaFixedValues = if (sigmaIsFixed) f$sigma else numeric(length(f$sigma))
  )
}

# The draws .sb_gibbs should have made, written out from the full conditionals.
# The two that a transcription would get wrong are the parameterisations:
#
#   lambda ~ Gamma(aLambda + (p - 2)/2, scale = 1 / (1/bLambda + beta'D beta/2))
#   sigma  = 1 / sqrt(Gamma(shapeSigma, rate = bSigma + ||y - B beta||^2 / 2))
#
# shapeSigma arrives already including the n/2 data term; it is the posterior
# shape, not the prior one.
#
# The whole stream is replayed even when a caller asserts only one quantity:
# skipping a draw desynchronises every later signal. `beta` lets a caller feed
# .sb_gibbs's own beta back in, isolating the lambda/sigma conditionals from
# the beta draw.
gibbs_closed_form_draws <- function(f, seed, sigmaIsFixed = FALSE,
                                    beta = NULL) {
  nSignal <- length(f$sigma)
  out <- list(Q = vector("list", nSignal), beta = vector("list", nSignal),
              lambda = numeric(nSignal), sigma = numeric(nSignal))

  set.seed(seed)
  for (m in seq_len(nSignal)) {
    M <- crossprod(f$B[[m]]) / f$sigma[m] ^ 2 + f$lambda[m] * f$D
    Q <- solve(M)
    mu <- as.numeric(Q %*% (crossprod(f$B[[m]], f$y[[m]]) / f$sigma[m] ^ 2))

    # beta = mu + U^-1 z with U'U = M, so var(beta) = M^-1
    betaDrawn <- mu + backsolve(chol(M), rnorm(f$p))
    betaUsed <- if (is.null(beta)) betaDrawn else beta[[m]]

    bDb <- sum(betaUsed * (f$D %*% betaUsed))
    out$lambda[m] <- rgamma(
      1,
      shape = f$aLambda[m] + (f$p - 2) / 2,
      scale = 1 / (1 / f$bLambda[m] + 0.5 * bDb)
    )

    out$sigma[m] <- if (sigmaIsFixed) {
      f$sigma[m]
    } else {
      rate <- f$bSigma[m] +
        0.5 * sum((f$y[[m]] - as.numeric(f$B[[m]] %*% betaUsed)) ^ 2)
      sqrt(1 / rgamma(1, shape = f$shapeSigma[m], scale = 1 / rate))
    }

    out$Q[[m]] <- Q
    out$beta[[m]] <- betaDrawn
  }
  out
}

# ── Test: sb_update_htby equals the definition of H and tBy ─────────────────

test_that(".sb_update_htby returns B'B / sigma^2 and B'y / sigma^2", {
  f <- hand_built_gibbs_inputs()

  res <- .sb_update_htby(
    B_list          = f$B,
    signalValuesVec = f$y,
    sigma           = f$sigma
  )

  for (m in seq_along(f$sigma)) {
    expect_equal(res$H[[m]], crossprod(f$B[[m]]) / f$sigma[m] ^ 2,
      tolerance = 1e-12,
      label = paste("H signal", m))
    expect_equal(as.numeric(res$tBy[[m]]),
      as.numeric(crossprod(f$B[[m]], f$y[[m]])) / f$sigma[m] ^ 2,
      tolerance = 1e-12,
      label = paste("tBy signal", m))
  }
})

# ── Test: sb_gibbs beta full conditional (covariance, mean, draw) ───────────

test_that(".sb_gibbs draws beta from N(M^-1 B'y/sigma^2, M^-1)", {
  f <- hand_built_gibbs_inputs()
  seed <- 5841L

  set.seed(seed)
  res <- do.call(.sb_gibbs, hand_built_gibbs_args(f))
  ref <- gibbs_closed_form_draws(f, seed)

  for (m in seq_along(f$sigma)) {
    expect_equal(res$Q[[m]], ref$Q[[m]],
      tolerance = 1e-10,
      label = paste("Q signal", m))
    # Pins the posterior mean as well: the draw is mu plus a term this replay
    # reproduces exactly, so a wrong mu cannot cancel.
    expect_equal(res$beta[[m]], ref$beta[[m]],
      tolerance = 1e-10,
      label = paste("beta draw signal", m))
  }
})

# ── Test: sb_gibbs lambda full conditional ──────────────────────────────────

test_that(".sb_gibbs draws lambda from its Gamma full conditional", {
  f <- hand_built_gibbs_inputs()
  seed <- 5842L

  set.seed(seed)
  res <- do.call(.sb_gibbs, hand_built_gibbs_args(f))
  ref <- gibbs_closed_form_draws(f, seed, beta = res$beta)

  expect_equal(res$lambda, ref$lambda, tolerance = 1e-9)
})

# ── Test: sb_gibbs sigma full conditional ───────────────────────────────────

test_that(".sb_gibbs draws sigma from its inverse-Gamma full conditional", {
  f <- hand_built_gibbs_inputs()
  seed <- 5843L

  set.seed(seed)
  res <- do.call(.sb_gibbs, hand_built_gibbs_args(f))
  ref <- gibbs_closed_form_draws(f, seed, beta = res$beta)

  expect_equal(res$sigma, ref$sigma, tolerance = 1e-9)
})

# ── Test: fixed sigma consumes no random number ─────────────────────────────

test_that(".sb_gibbs draws no sigma at all when sigmaIsFixed", {
  f <- hand_built_gibbs_inputs()
  seed <- 5844L

  set.seed(seed)
  res <- do.call(.sb_gibbs, hand_built_gibbs_args(f, sigmaIsFixed = TRUE))
  ref <- gibbs_closed_form_draws(f, seed, sigmaIsFixed = TRUE, beta = res$beta)

  expect_equal(res$sigma, f$sigma, tolerance = 1e-14)
  # Signal 2's lambda only lands here if signal 1 skipped its sigma draw
  # rather than drawing and discarding: a discarded draw would shift the
  # stream, which a "sigma is unchanged" assertion cannot see.
  expect_equal(res$lambda, ref$lambda, tolerance = 1e-9)
})

# ── Test: lambda/sigma conditional moments, independent of draw order ───────

test_that(".sb_gibbs lambda and sigma match their conditional Gamma moments", {
  f <- hand_built_gibbs_inputs()
  args <- hand_built_gibbs_args(f)
  nRep <- 400L
  shapeLambda <- f$aLambda + (f$p - 2) / 2

  # Each draw is standardised by the conditional moments implied by the beta
  # returned alongside it, so u has mean 1 and variance 1/shape whatever order
  # the implementation consumes its random numbers in — the one assumption the
  # seed-matched replays above cannot survive.
  uLambda <- matrix(NA_real_, nRep, length(f$sigma))
  uSigma <- matrix(NA_real_, nRep, length(f$sigma))

  set.seed(58401)
  for (i in seq_len(nRep)) {
    res <- do.call(.sb_gibbs, args)
    for (m in seq_along(f$sigma)) {
      beta <- res$beta[[m]]
      scaleLambda <- 1 / (1 / f$bLambda[m] + 0.5 * sum(beta * (f$D %*% beta)))
      uLambda[i, m] <- res$lambda[m] / (shapeLambda[m] * scaleLambda)

      rateSigma <- f$bSigma[m] +
        0.5 * sum((f$y[[m]] - as.numeric(f$B[[m]] %*% beta)) ^ 2)
      uSigma[i, m] <- rateSigma / (res$sigma[m] ^ 2 * f$shapeSigma[m])
    }
  }

  # u is exactly Gamma(shape, 1/shape) whatever beta was, so the reps are iid:
  # mean 1, variance 1/shape, and the sample variance carries the Gamma excess
  # kurtosis 6/shape.
  expect_moments <- function(u, shape) {
    expect_lt(abs(mean(u) - 1) * sqrt(nRep * shape), 4)
    seVar <- sqrt(2 / nRep + 6 / (shape * nRep))
    expect_lt(abs(var(u) * shape - 1) / seVar, 4)
  }

  for (m in seq_along(f$sigma)) {
    expect_moments(uLambda[, m], shapeLambda[m])
    expect_moments(uSigma[, m], f$shapeSigma[m])
  }
})

# ── Test: sb_gibbs returns correct structure ────────────────────────────────

test_that("sb_gibbs returns correct structure", {
  # sigmaFixed = FALSE so the drawn-sigma branch is exercised at production
  # dimensions (p = 27), not only on the hand-built p = 5 inputs above.
  env <- setup_gibbs_state(sigmaFixed = FALSE)
  args <- extract_gibbs_args(env)
  nSignal <- length(args$H_list)
  p <- args$numBasis

  set.seed(4472)
  res <- do.call(.sb_gibbs, args)

  expect_named(res, c("beta", "lambda", "sigma", "Q"))
  expect_length(res$beta, nSignal)
  expect_length(res$lambda, nSignal)
  expect_length(res$sigma, nSignal)
  expect_length(res$Q, nSignal)

  for (m in seq_len(nSignal)) {
    expect_length(res$beta[[m]], p)
    expect_equal(nrow(res$Q[[m]]), p)
    expect_equal(ncol(res$Q[[m]]), p)
    expect_true(is.finite(res$lambda[m]) && res$lambda[m] > 0)
    expect_true(is.finite(res$sigma[m]) && res$sigma[m] > 0)
  }
})

# ── Test: sb_gibbs Q is symmetric and PD ────────────────────────────────────

test_that("sb_gibbs Q is symmetric positive definite", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)

  set.seed(3917)
  res <- do.call(.sb_gibbs, args)

  for (m in seq_along(res$Q)) {
    Q <- res$Q[[m]]
    expect_equal(Q, t(Q), tolerance = 1e-14,
      label = paste("Q symmetry signal", m))
    eig <- eigen(Q, symmetric = TRUE, only.values = TRUE)$values
    expect_true(all(eig > 0),
      label = paste("Q positive definite signal", m))
  }
})

# ── Test: sb_gibbs sigma remains fixed when sigmaIsFixed = TRUE ─────────────

test_that("sb_gibbs preserves fixed sigma", {
  env <- setup_gibbs_state(sigmaFixed = TRUE)
  args <- extract_gibbs_args(env)

  set.seed(9243)
  res <- do.call(.sb_gibbs, args)

  expect_equal(res$sigma, as.numeric(env$model[["sigmaFixed"]]),
    tolerance = 1e-14,
    label = "sigma fixed values preserved")
})

# ── Test: sb_gibbs Q inverts H + lambda D on the full model fixture ─────────

test_that("sb_gibbs Q inverts H + lambda D at production dimensions", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)

  set.seed(1001)
  res <- do.call(.sb_gibbs, args)

  for (m in seq_along(args$H_list)) {
    M <- args$H_list[[m]] + max(args$lambda_in[m], 1e-10) * args$D_mat
    # kappa(M) ~ 7e7 here, so compare the inverses loosely; a tighter bound
    # would ride on the BLAS.
    expect_equal(res$Q[[m]], (solve(M) + t(solve(M))) / 2,
      tolerance = 1e-6,
      label = paste("signal", m, "Q"))
  }
})

# ── Test: sb_gibbs beta draws have correct mean and spread (statistical) ────

test_that("sb_gibbs beta draws centre and spread as N(mu, Q)", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)
  nReps <- 500

  m <- 1  # test first signal
  M <- args$H_list[[m]] + max(args$lambda_in[m], 1e-10) * args$D_mat
  Q_r <- solve(M)
  Q_r <- (Q_r + t(Q_r)) / 2
  mu_r <- as.numeric(Q_r %*% args$tBy_list[[m]])

  beta_draws <- matrix(NA_real_, nrow = nReps, ncol = args$numBasis)
  for (i in seq_len(nReps)) {
    set.seed(2000 + i)
    res <- do.call(.sb_gibbs, args)
    beta_draws[i, ] <- res$beta[[m]]
  }

  # Standardising the mean by the *empirical* sd is blind to any rescaling of
  # the draw covariance, so the spread needs its own assertion.
  se <- apply(beta_draws, 2, sd) / sqrt(nReps)
  expect_lte(sum(abs(colMeans(beta_draws) - mu_r) / se > 3.5), 1)
  expect_equal(apply(beta_draws, 2, var), diag(Q_r), tolerance = 0.25)
})

# ── Test: the Cholesky-failure warning comes from the wrapper (RT-700) ──────

test_that(".sb_gibbs warns once per call, from the wrapper (RT-700)", {
  # A zero H and a zero penalty make M = H + lambda * D singular for every
  # signal, so both signals take the Q_fallback branch. The warning used to be
  # raised from inside the per-signal loop of the no-throw impl frame, giving
  # one warning per failed signal; it is now collected and emitted once by the
  # wrapper, which is the only frame allowed to longjmp (options(warn = 2)
  # turns a warning into exactly that).
  p <- 4L
  gibbsArgs <- list(
    H_list           = list(matrix(0, p, p), matrix(0, p, p)),
    tBy_list         = list(rep(1, p), rep(1, p)),
    B_list           = list(matrix(1, 1, p), matrix(1, 1, p)),
    signalValuesVec  = list(1, 1),
    sigma_in         = c(1, 1),
    lambda_in        = c(0, 0),
    D_mat            = matrix(0, p, p),
    Q_fallback       = list(diag(p), diag(p)),
    aLambda          = c(1, 1), bLambda = c(1, 1),
    shapeSigma       = c(1, 1), bSigma_prior = c(1, 1),
    numBasis         = p,
    sigmaIsFixed     = TRUE,
    sigmaFixedValues = c(1, 1)
  )

  set.seed(717)
  warnings <- character(0)
  res <- withCallingHandlers(
    do.call(.sb_gibbs, gibbsArgs),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  # Pre-fix: two identical warnings, one per failed signal.
  expect_length(warnings, 1L)
  expect_match(warnings, "Cholesky decomposition failed")

  # The fallback draws themselves are unaffected by where the warning is
  # raised: both signals still come back from their identity Q_fallback.
  expect_length(res$beta, 2L)
  for (m in 1:2) {
    expect_true(all(is.finite(res$beta[[m]])))
    expect_equal(res$Q[[m]], diag(p))
  }
})
