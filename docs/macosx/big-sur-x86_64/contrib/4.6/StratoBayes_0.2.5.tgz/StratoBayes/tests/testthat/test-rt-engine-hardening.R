# Regression tests for the RT-3xx/4xx C++ engine hardening batch.
#
# Each block names the finding it pins.  Findings with no reachable trigger from
# R (RT-353 ThreadRNG reseed cache, RT-378 find_reasonable_epsilon, RT-390
# zero-section overlap, RT-392 interrupt unwinding, RT-393 cost-clock
# attribution, RT-394 int overflow, RT-402 at 2^31 elements) have no test here;
# see the PR description for why.
#
# CPU: nThreads = 2L caps the pool at 2 workers (RT-382, fixed in PR #374);
# nChains = 2L throughout, and no test sets runParallel, so peak threads is 2.

# ── Helper: build a C++ engine from a short R-engine run ─────────────────────

make_hardening_engine <- function() {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), paste0("rtharden_", as.integer(runif(1, 1, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  # Single-threaded on purpose: passing nThreads > 1 silently switches the run
  # to the C++ engine, and this helper wants the R engine's mcmc object to build
  # a fresh C++ engine from.
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 2L, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "rtharden", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "rtharden_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj,
    state = state_obj, tiesCallback = NULL
  )

  list(engine_ptr = engine_ptr, model_obj = model_obj,
       mcmc_obj = mcmc_obj, td = td,
       nProposals = length(mcmc_obj[["propose"]]))
}


# ── RT-395: zero-extent matrix products must not reach BLAS XERBLA ───────────

test_that("RT-395: zero-extent matrix-matrix product matches base %*%", {
  # Reference BLAS validates LDA >= MAX(1, M) *before* its zero-extent quick
  # return, so an unguarded m = 0 or k = 0 reached XERBLA -> Rf_error.
  A0 <- matrix(numeric(0), nrow = 0, ncol = 3)
  B0 <- matrix(as.numeric(1:6), nrow = 3, ncol = 2)
  got <- StratoBayes:::.sb_mat_mat_mult(A0, B0)
  expect_equal(dim(got), c(0L, 2L))
  expect_equal(got, A0 %*% B0, ignore_attr = TRUE)

  # k = 0: base R returns a 3x2 matrix of zeros, not an error.
  Ak <- matrix(numeric(0), nrow = 3, ncol = 0)
  Bk <- matrix(numeric(0), nrow = 0, ncol = 2)
  gotK <- StratoBayes:::.sb_mat_mat_mult(Ak, Bk)
  expect_equal(dim(gotK), c(3L, 2L))
  expect_equal(gotK, Ak %*% Bk, ignore_attr = TRUE)
  expect_true(all(gotK == 0))

  # n = 0
  Bn <- matrix(numeric(0), nrow = 3, ncol = 0)
  gotN <- StratoBayes:::.sb_mat_mat_mult(B0 * 0 + 1, Bn)
  expect_equal(dim(gotN), c(3L, 0L))
})

test_that("RT-395: zero-extent matrix-vector product matches base %*%", {
  A0 <- matrix(numeric(0), nrow = 0, ncol = 3)
  expect_equal(length(StratoBayes:::.sb_mat_vec_mult(A0, c(1, 2, 3))), 0L)

  # n = 0: result is a length-3 zero vector (base gives a 3x1 of zeros).
  An <- matrix(numeric(0), nrow = 3, ncol = 0)
  gotN <- StratoBayes:::.sb_mat_vec_mult(An, numeric(0))
  expect_equal(gotN, c(0, 0, 0))
  expect_equal(as.numeric(An %*% numeric(0)), gotN)
})

test_that("RT-395: non-degenerate products are unchanged", {
  set.seed(11)
  A <- matrix(rnorm(12), 4, 3)
  B <- matrix(rnorm(6), 3, 2)
  expect_equal(StratoBayes:::.sb_mat_mat_mult(A, B), A %*% B, ignore_attr = TRUE)
  expect_equal(StratoBayes:::.sb_mat_vec_mult(A, c(1, -2, 3)),
               as.numeric(A %*% c(1, -2, 3)))
})


# ── RT-402: first/last TRUE index ────────────────────────────────────────────

test_that("RT-402: .FirstAndLastCPP returns correct indices", {
  # The 2^31 truncation itself is untestable here (it needs a >2 GB vector);
  # this pins the ordinary behaviour the R_xlen_t rewrite must preserve.
  expect_equal(StratoBayes:::.FirstAndLastCPP(c(FALSE, TRUE, FALSE, TRUE, FALSE)),
               c(2L, 4L))
  expect_equal(StratoBayes:::.FirstAndLastCPP(c(TRUE)), c(1L, 1L))
  expect_equal(StratoBayes:::.FirstAndLastCPP(c(FALSE, FALSE)),
               c(NA_integer_, NA_integer_))
  expect_equal(StratoBayes:::.FirstAndLastCPP(logical(0)),
               c(NA_integer_, NA_integer_))
  # NA entries are not TRUE and must not be selected
  expect_equal(StratoBayes:::.FirstAndLastCPP(c(NA, TRUE, NA)), c(2L, 2L))
  expect_equal(StratoBayes:::.FirstAndLastCPP(c(NA, NA)),
               c(NA_integer_, NA_integer_))
})


# ── RT-386: a duplicated saveIters entry must not stop accumulation ──────────

test_that("RT-386: duplicated saveIters entry does not silently drop later saves", {
  skip_on_cran()
  eng <- make_hardening_engine()

  # saveIters with 3 duplicated. Pre-fix the cursor advanced only on an exact
  # `==` hit, so it parked on the second 3 and iterations 5 and 7 were dropped.
  saveIters <- c(1L, 3L, 3L, 5L, 7L)
  StratoBayes:::.sb_configure_samples(
    eng$engine_ptr, saveIter = saveIters, saveChains = 1L,
    sigmaFixed = eng$model_obj[["sigmaFixed"]][[1]],
    hasOverlapPrior = FALSE, hasTiesLikelihood = FALSE,
    startIter = 1L, binaryOnly = TRUE
  )
  StratoBayes:::.sb_run_block(eng$engine_ptr, 8L)
  flushed <- StratoBayes:::.sb_flush_samples(eng$engine_ptr)

  # Every distinct requested iteration is saved exactly once; the duplicate is
  # consumed rather than poisoning the cursor.
  expect_equal(as.integer(flushed[["iterations"]]), c(1L, 3L, 5L, 7L))
})

test_that("RT-386: a stepped-over saveIters value does not stall the cursor", {
  skip_on_cran()
  eng <- make_hardening_engine()

  # Cursor starts at iteration 1; 2 is requested but the block also asks for 4
  # and 6. Nothing here steps over a value under normal operation, so this pins
  # that ordinary sequences are unaffected by the >= change.
  StratoBayes:::.sb_configure_samples(
    eng$engine_ptr, saveIter = c(2L, 4L, 6L), saveChains = 1L,
    sigmaFixed = eng$model_obj[["sigmaFixed"]][[1]],
    hasOverlapPrior = FALSE, hasTiesLikelihood = FALSE,
    startIter = 1L, binaryOnly = TRUE
  )
  StratoBayes:::.sb_run_block(eng$engine_ptr, 7L)
  flushed <- StratoBayes:::.sb_flush_samples(eng$engine_ptr)
  expect_equal(as.integer(flushed[["iterations"]]), c(2L, 4L, 6L))
})


# ── RT-385: empty saveChains must not read plotRowBuffer out of bounds ───────

test_that("RT-385: empty saveChains gives an empty plotMatrix, not a bad read", {
  skip_on_cran()
  eng <- make_hardening_engine()

  # accumulate_samples pushes a plot row only for saveChains[1], but
  # savedIterBuffer is pushed unconditionally — so with no save chains the flush
  # used to size plotMat from savedIterBuffer and index a zero-length buffer.
  StratoBayes:::.sb_configure_samples(
    eng$engine_ptr, saveIter = c(1L, 2L, 3L), saveChains = integer(0),
    sigmaFixed = eng$model_obj[["sigmaFixed"]][[1]],
    hasOverlapPrior = FALSE, hasTiesLikelihood = FALSE,
    startIter = 1L, binaryOnly = TRUE
  )
  StratoBayes:::.sb_run_block(eng$engine_ptr, 4L)

  flushed <- StratoBayes:::.sb_flush_samples(eng$engine_ptr)
  expect_equal(nrow(flushed[["plotMatrix"]]), 0L)
  expect_equal(nrow(flushed[["sampleMatrix"]]), 0L)
  # `iterations` still reports which iterations were save iterations.
  expect_equal(as.integer(flushed[["iterations"]]), c(1L, 2L, 3L))
})


# ── RT-388: all-zero proposal weights must error, not pick proposal 0 ────────

test_that("RT-388: all-zero proposal selection weights raise the R engine's error", {
  skip_on_cran()
  eng <- make_hardening_engine()

  nCh <- 2L
  nP  <- eng$nProposals
  zeroProb <- matrix(0, nrow = nCh, ncol = nP)
  facts    <- matrix(1, nrow = nCh, ncol = nP)
  args     <- eng$mcmc_obj[["proposeArgs"]]
  if (is.null(args)) args <- vector("list", nCh)

  # Pre-RT-388: runif(0, 0) returned 0, `u <= cumWeights[0]` fired, and a
  # disabled proposal was selected silently. RT-388 made the C++ engine stop,
  # but (until RT-503) only inside .sb_run_block, unwinding select_proposal's
  # std::runtime_error out of sb_run_block_impl's frame. RT-503 hoists the
  # same check into .sb_update_proposals -- a thin, non-impl-split wrapper --
  # so the error now fires here instead, before sb_run_block_impl is ever
  # entered with a state select_proposal() could not handle.
  expect_error(
    StratoBayes:::.sb_update_proposals(eng$engine_ptr, args, facts, zeroProb),
    "no MCMC proposal has positive selection"
  )
})


# ── RT-376 / RT-391: new monitor diagnostics are surfaced ────────────────────

test_that("RT-376/RT-391: monitor reports the split divergence and Gibbs counters", {
  skip_on_cran()
  eng <- make_hardening_engine()

  StratoBayes:::.sb_configure_monitor(eng$engine_ptr, eng$nProposals)
  StratoBayes:::.sb_run_block(eng$engine_ptr, 5L)
  mon <- StratoBayes:::.sb_get_monitor(eng$engine_ptr)

  expect_true("nDomainFailure" %in% names(mon))
  expect_true("nGibbsCholeskyFailures" %in% names(mon))

  # nDomainFailure is a subset of nDivergent by construction.
  expect_true(mon$nDomainFailure >= 0L)
  expect_true(mon$nDomainFailure <= mon$nDivergent)
  # A healthy model should not be hitting the double-Cholesky fallback.
  expect_equal(mon$nGibbsCholeskyFailures, 0L)
})

test_that("RT-376: HMC/NUTS runs surface nDomainFailure in mcmcSummary", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), "rt376_summary")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  post <- RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = model,
    nIter = 200, nChains = 2L, nThreads = 2L, seed = 4817,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "rt376", engine = "cpp"
  )

  expect_true("nDomainFailure" %in% names(post[["mcmcSummary"]]))
  expect_length(post[[c("mcmcSummary", "nDomainFailure")]], post[["nRun"]])
  # Every domain failure is also counted as a divergence.
  expect_true(all(post[[c("mcmcSummary", "nDomainFailure")]] <=
                    post[[c("mcmcSummary", "nDivergent")]]))
  expect_true("nGibbsCholeskyFailures" %in% names(post[["mcmcSummary"]]))
})
