# --- #1367: .ValidateSignal() must coerce a factor `signal`, not silently
# return it unchanged (which SignalLookUp() then indexes by integer code) ---

test_that(".ValidateSignal() resolves a factor by label, not by code (#1367)", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal(factor("value"), data)
  expect_equal(result$signal, "value")
  expect_false(result$allSignals)
})

test_that("SignalLookUp() with a factor `signal` matches the character-`signal` result (#1367)", {
  data <- StratData(signal = signalData1)
  siteName <- names(data[[c("signalAttr", "siteInd")]])[[1]]
  expect_equal(
    SignalLookUp(data, "value", siteName, signal = factor("value")),
    SignalLookUp(data, "value", siteName, signal = "value")
  )
})

# --- #1370: a numeric-looking character `signal` (e.g. "1") must resolve by
# position, the same as the numeric index, instead of returning NULL ---

test_that(".ValidateSignal() resolves a numeric-looking character by position (#1370)", {
  data <- StratData(signal = signalData1)
  byString <- .ValidateSignal("1", data)
  byNumber <- .ValidateSignal(1, data)
  expect_equal(byString$signal, byNumber$signal)
  expect_equal(byString$signal, "value")
})

test_that("SignalLookUp() with signal = \"1\" matches signal = 1, not NULL (#1370)", {
  data <- StratData(signal = signalData1)
  siteName <- names(data[[c("signalAttr", "siteInd")]])[[1]]
  byString <- SignalLookUp(data, "value", siteName, signal = "1")
  byNumber <- SignalLookUp(data, "value", siteName, signal = 1)
  expect_false(is.null(byString))
  expect_equal(byString, byNumber)
})

test_that(".ValidateSignal() prefers a name match over positional resolution when they disagree (#1370)", {
  # A signal genuinely named "1" sitting at position 2: positional
  # resolution of signal = "1" would (wrongly) pick position 1 ("b"); the
  # exact name match must win and return the signal actually named "1".
  multiSignal <- data.frame(
    site = rep(c("site_1", "site_2"), each = 5),
    height = 1:10,
    b = 20:29,
    "1" = 10:1,
    check.names = FALSE
  )
  data <- StratData(multiSignal, signalColumn = c("b", "1"),
                    zColumn = "height", siteColumn = "site")
  expect_equal(
    as.character(data[[c("signalAttr", "signalNames")]]), c("b", "1")
  )

  result <- .ValidateSignal("1", data)
  expect_equal(result$signal, "1")
})

# --- #1372.1: .ValidateColourBy()'s "Invalid 'plotType'" branch must be
# reachable, not dead code that returns an uninformative empty message ---

test_that(".ValidateColourBy() errors clearly on an unmatched plotType (#1372.1)", {
  data <- StratData(signal = signalData1)
  expect_error(
    .ValidateColourBy("site", data, "not_a_plot_type"),
    "Invalid 'plotType'"
  )
})

# --- #1372.2: .CreateColourMaps() must not surface a raw base-R condition
# error for a non-scalar colourScale ---

test_that(".CreateColourMaps() warns (not errors) on a non-scalar colourScale (#1372.2)", {
  nParts <- length(stratData1[[c("partsAttr", "uniqueParts")]])
  expect_warning(
    .CreateColourMaps(stratData1, c("Dark 3", "Dark 2"), nParts, stratData1[["S"]]),
    "colourScale"
  )
  expect_warning(
    .CreateColourMaps(stratData1, character(0), nParts, stratData1[["S"]]),
    "colourScale"
  )
})

# --- #1372.3: .IsNumeric() must reject a factor instead of silently
# accepting its integer level codes ---

test_that(".IsNumeric() rejects a factor (#1372.3)", {
  expect_false(.IsNumeric(factor(c("a", "b"))))
  expect_false(.IsNumeric(factor(c("1", "2"))))
})

# --- #1372.4: .IsColour(NA) must return FALSE, not TRUE ---

test_that(".IsColour() rejects NA (#1372.4)", {
  expect_false(.IsColour(NA))
  expect_false(.IsColour(NA_character_))
})
