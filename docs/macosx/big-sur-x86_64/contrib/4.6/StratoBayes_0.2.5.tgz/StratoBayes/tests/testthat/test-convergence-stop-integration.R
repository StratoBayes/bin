# Issue #129: `convergenceStop` reaching a real run.
#
# The decision logic is pinned in test-convergence-stop.R and
# test-convergence-store.R against hand-written fixtures. What is left to check
# is the wiring, and the assertions here are chosen so that a short run makes
# them deterministic: a trivially satisfiable threshold must always fire, an
# unreachable one must never fire, and neither may stop inside the adaptation
# window. No sampled value is asserted.
#
# `runParallel = TRUE` is deliberately absent: `future` workers load the
# installed package, so a parallel test cannot exercise the branch under
# development. Cross-run comparison and the sentinel are covered directly in
# test-convergence-store.R.

# No `...`: `RunStratModel()` records its own call with `match.call()`, which
# cannot expand a `...` forwarded from a helper frame.
CiRun <- function(convergenceStop, nIter = 120, nRun = 2, engine = "cpp") {
  dir <- tempfile()
  dir.create(dir)
  RunStratModel(stratData1, stratModel1, nIter = nIter, nChains = 4,
                nRun = nRun, seed = seq_len(nRun), quiet = TRUE,
                nThreads = 1L, modelDir = dir, modelName = "ci",
                visualise = FALSE, convergenceStop = convergenceStop,
                engine = engine)
}

CiCompleted <- function(posterior) {
  unlist(posterior[[c("mcmcSummary", "completedIter")]])
}

test_that("a trivially satisfiable rule stops a run, after adaptation", {
  skip_on_cran()
  post <- CiRun(list(rHat = 10, ess = 1))
  completed <- CiCompleted(post)

  expect_true(all(completed < 120))
  # #260: never inside the adaptation window, whatever the chains look like.
  expect_true(all(completed > unlist(post[[c("mcmcSummary", "endAdapting")]])))
  # Two consecutive checkpoints are needed, so the earliest possible stop is
  # the second post-adaptation checkpoint, not the first.
  expect_true(all(completed > 60))

  # The posterior still compiles, and holds no schedule beyond what was run.
  expect_s3_class(post, "StratPosterior")
  saved <- post[[c("mcmcSummary", "saveIter")]]
  for (r in seq_along(saved)) {
    expect_true(all(saved[[r]] <= completed[[r]]))
  }
})

test_that("an unreachable rule never fires", {
  skip_on_cran()
  # R-hat is bounded below by 1, and 120 iterations of this model do not
  # converge; the ESS target is likewise out of reach.
  expect_identical(CiCompleted(CiRun(list(rHat = 1.000001, ess = 1e6))),
                   c(120, 120))
})

test_that("the default leaves a short run untouched", {
  skip_on_cran()
  # Documented behaviour, and the reason turning the rule on by default is not
  # a behaviour change for existing calls: 120 iterations cannot deliver the
  # default ESS floor of 200, so the criteria cannot be met.
  expect_identical(CiCompleted(CiRun(TRUE)), c(120, 120))
  expect_identical(CiCompleted(CiRun(FALSE)), c(120, 120))
})

test_that("the R engine gets the rule working, not stubbed", {
  skip_on_cran()
  expect_true(all(CiCompleted(CiRun(list(rHat = 10, ess = 1),
                                    engine = "R")) < 120))
})

test_that("stopping a single run says what it cannot see", {
  skip_on_cran()
  # Split-R-hat within one run cannot detect disagreement between alignment
  # modes, which is the failure mode that matters here. The caveat is raised
  # when the rule actually stops a run, not on every call: `nRun = 1` is the
  # default, so a standing warning would fire on essentially every run.
  dir <- tempfile()
  dir.create(dir)
  expect_message(
    RunStratModel(stratData1, stratModel1, nIter = 120, nChains = 4, nRun = 1,
                  seed = 1, quiet = FALSE, nThreads = 1L, modelDir = dir,
                  modelName = "ci1", visualise = FALSE,
                  convergenceStop = list(rHat = 10, ess = 1)),
    "single run")
})

test_that("the rule leaves nothing in the model directory", {
  skip_on_cran()
  post <- CiRun(list(rHat = 10, ess = 1))
  left <- list.files(post[["modelDir"]])

  expect_false(any(grepl("_convergence_run_", left)))
  expect_false(any(grepl("_stop$", left)))
})

test_that("a stale sentinel stops neither a fresh run nor a continuation", {
  skip_on_cran()
  # The most likely shipped bug: a `_stop` left by a crashed run would
  # terminate the next one at its first checkpoint. New runs are covered by the
  # stale-file sweep; a continuation never reaches it, so the dispatch clears
  # the sentinel itself.
  #
  # The iteration counts below cannot fail on their own: `nRun = 1` never
  # *reads* a sentinel (only concurrent peers do), so a leftover one could not
  # have stopped these runs however the clean-up behaved. What discriminates is
  # the call count -- the dispatch-time clear and the on-exit clean-up are two
  # calls, and deleting the former leaves one.
  dir <- withr::local_tempdir()
  Sentinel <- function() file.create(file.path(dir, "ci_stop"))

  cleared <- 0L
  realClear <- .ClearConvergenceFiles
  testthat::local_mocked_bindings(
    .ClearConvergenceFiles = function(modelDir, modelName) {
      cleared <<- cleared + 1L
      realClear(modelDir, modelName)
    }
  )

  Sentinel()
  first <- RunStratModel(stratData1, stratModel1, nIter = 100, nChains = 4,
                         nRun = 1, seed = 1, quiet = TRUE, nThreads = 1L,
                         modelDir = dir, modelName = "ci", visualise = FALSE)
  expect_identical(CiCompleted(first), 100)
  expect_identical(cleared, 2L)

  Sentinel()
  cleared <- 0L
  expect_identical(CiCompleted(RunStratModel(first, nIter = 100,
                                             quiet = TRUE)), 200)
  # A continuation skips the new-run stale-file sweep entirely, so this is the
  # only thing standing between it and a crashed predecessor's sentinel.
  expect_identical(cleared, 2L)
})

test_that("a malformed convergenceStop is refused before any sampling", {
  # No `skip_on_cran()`: validation happens before the model is touched, so
  # this costs nothing and is the one guard worth running everywhere.
  expect_error(CiRun(list(rHat = -1)), "greater than 1")
  expect_error(CiRun(list(foo = 1)), "rHat")
  expect_error(CiRun(list()), "at least one")
  expect_error(CiRun(1.02), "named list")
})
