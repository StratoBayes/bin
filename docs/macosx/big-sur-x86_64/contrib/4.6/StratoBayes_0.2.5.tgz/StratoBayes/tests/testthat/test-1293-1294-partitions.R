test_that("Partitions() reads a tie's age from its own density, not from arg1 (#1293)", {
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  # three dunif ties of deliberately different widths: two ties would be
  # affine in arg1 and so could not discriminate lower bound from median
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dunif",
                     arg1 = c(10, 20, 50), arg2 = c(10.2, 40, 50.2))

  got <- Partitions(signal, nStrata = 3, distribute = "height", ties = ties)

  # expected boundaries: interpolate height against the ties' *median* ages
  medianAges <- c(10.1, 30, 50.1)
  ageAt <- stats::approx(c(0, 5, 10), medianAges, xout = range(signal$height),
                         rule = 2)[["y"]]
  wanted <- stats::approx(medianAges, c(0, 5, 10),
                          xout = seq(ageAt[1], ageAt[2],
                                     length.out = 4)[-1], rule = 2)[["y"]]
  expect_equal(got[["height"]], wanted)

  # pre-fix these were the arg1-as-age boundaries; assert we are no longer
  # producing them, so a regression cannot pass this test silently
  argOneAges <- c(10, 20, 50)
  argOneBoundaries <- stats::approx(
    argOneAges, c(0, 5, 10),
    xout = seq(argOneAges[1], argOneAges[3], length.out = 4)[-1],
    rule = 2)[["y"]]
  expect_false(isTRUE(all.equal(got[["height"]], argOneBoundaries)))
})

test_that("Partitions() leaves dnorm ties bit-identical (#1293 control)", {
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dnorm",
                     arg1 = c(10, 20, 50), arg2 = c(0.1, 3, 0.1))
  got <- Partitions(signal, nStrata = 3, distribute = "height", ties = ties)

  # qnorm(0.5, mean, sd) == mean exactly, so the historic arg1-as-age
  # boundaries are still the right answer here
  wanted <- stats::approx(c(10, 20, 50), c(0, 5, 10),
                          xout = seq(10, 50, length.out = 4)[-1],
                          rule = 2)[["y"]]
  expect_identical(got[["height"]], wanted)
})

test_that("Partitions() warns when a tie density has no quantile counterpart (#1293)", {
  dmine <<- function(x, a, b) stats::dnorm(x, a, b)
  on.exit(rm("dmine", envir = globalenv()), add = TRUE)
  signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dmine",
                     arg1 = c(10, 20, 50), arg2 = c(0.1, 3, 0.1))

  expect_warning(Partitions(signal, nStrata = 3, distribute = "height",
                            ties = ties),
                 "No quantile function")
})

test_that("Partitions() accepts a tibble `signal` (#1294)", {
  skip_if_not_installed("tibble")
  rows <- data.frame(site = rep("A", 6), height = c(1, 2, 3, 4, 5, 6))
  tbl <- tibble::as_tibble(rows)

  for (mode in c("points", "height")) {
    expect_equal(
      Partitions(tbl, nStrata = 3, distribute = mode)[["height"]],
      Partitions(rows, nStrata = 3, distribute = mode)[["height"]]
    )
  }
})
