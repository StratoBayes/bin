test_that(".CheckDataFrame() gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  expect_error(.CheckDataFrame(test1),
               "test1 must be a data frame")
  expect_error(.CheckDataFrame(test2, allowNULL = TRUE),
               "test2 must be a data frame or NULL")
  expect_silent(.CheckDataFrame(test3))
  expect_silent(.CheckDataFrame(test3, allowNULL = TRUE))
  expect_silent(.CheckDataFrame(test1, allowNULL = TRUE))
  expect_error(.CheckDataFrame(test4, allowNULL = TRUE),
               "test4 must be a data frame or NULL")
  }
)

test_that(".CheckDataColumns() gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  test5 <- data.frame(signal = 1, site = "site1", height = 2)
  test6 <- data.frame(signal = c(NA,NA), site = c(NA, "site1"), height = 1:2)
  expect_error(.CheckDataColumns(test1),
               "test1 must be a data frame")
  expect_error(.CheckDataColumns(test2, columns = "a", allowNULL = TRUE),
               "test2 must be a data frame or NULL")
  expect_error(.CheckDataColumns(test3, columns = "a", allowNULL = TRUE),
               "test3 is missing the following columns: a")
  expect_silent(.CheckDataColumns(test3, columns = "x"))

  expect_error(.CheckDataColumns(test5, columns = c("signal", "depth", "site"),
                                 allowNULL = TRUE),
               "test5 is missing the following columns: depth")

  expect_silent(.CheckDataColumns(test5, columns = c("height","signal", "site"),
                                  allowNULL = TRUE))
  expect_error(.CheckDataColumns(test6, columns = c("height", "signal", "site"),
                     noNA = c("height", "site")),
               "test6 has NA values in the following columns: site")

  }
)


test_that(".MakeNumeric() does its job and gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  test5 <- data.frame(signal = 1, site = "site1", height = 2)
  test6 <- data.frame(signal = c(NA,1), site = c("site1", 3), height = c(2,"3"),
                      depth = c("site", "depth"))

  expect_error(.MakeNumeric(test1),
               "test1 must be a data frame")
  expect_error(.MakeNumeric(test6, columns =
                              c("signal","site", "depth", "nothing"),
                            allowNULL = TRUE),
               "test6 is missing the following columns: nothing")
  expect_error(.MakeNumeric(test6, columns = c("site", "signal", "depth"),
                            allowNULL = TRUE),
               "The following columns in test6 contain non-NA values that cannot be coerced to numeric: site, depth")
  expect_silent(.MakeNumeric(test6, columns = c("signal")))
  expect_silent(.MakeNumeric(test3, columns = c("x")))
  expect_silent(.MakeNumeric(test6, columns = c("signal"), optionalColumns = "nothing"))
  expect_error(.MakeNumeric(test6, columns = c("signal"), optionalColumns = "depth"),
               "The following columns in test6 contain non-NA values that cannot be coerced to numeric: depth")
}
)

test_that(".CheckTies() does its job and gives errors where necessary", {
  ties1 <- data.frame(height = 1:2,
                              site = 2:3,
                              densityFun = c("dnorm", "dexp"),
                              arg1 = c(0, 1),
                              arg2 = c(1, NA)
  )

  ties2 <- data.frame(height = 1:2,
                                          site = 2:3,
                                          densityFun = c("dnorm", "dexp"),
                                          arg1 = c(0, 1),
                                          arg2 = c(1, NA),
                                          mean = c("N","A")
  )
  ties3 <- data.frame(height = 1:2,
                      site = 2:3,
                      densityFun = c("dnorm", "dexp"),
                      arg1 = c(0, 1),
                      arg2 = c(1, NA),
                      mean = c("N","A"),
                      sd = 1:2
  )
  ties4 <- data.frame(height = c("n","p"),
                      site = 2:3,
                      densityFun = c("dnorm", "dexp"),
                      arg1 = c(0, 1),
                      arg2 = c(1, NA),
                      mean = c("N","A"),
                      sd = 1:2
  )
  ties5 <- data.frame(height = 2:1,
                      site = 2:3,
                      mean = c(1, "3"),
                      sd = 1:2
  )
  ties6 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c(1, "3"),
                      sd = 1:2
  )

  ties7 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", "dnorm"),
                      sd = 1:2,
                      mean = c(NA,1)
  )

  ties8 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", NA),
                      arg1 = 1:2,
                      arg2 = 1:2)

  ties9 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", "dnorm"),
                      arg1 = c(NA,2),
                      arg2 = 1:2)


  ties10 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dexp", "dunif"),
                      arg1 = c(1,2))

  ties11 <- data.frame(height = 2:1,
                       site = 2:3,
                       densityFun = c("dexp", "dunif"),
                       arg1 = c(1,2),
                       arg2 = c(1,NA))

  ties12 <- data.frame(height = 2:1,
                       site = 2:3,
                       densityFun = c("dexp", "dunif"),
                       arg1 = c(1,2),
                       arg3 = c(1,3))

  # dbeta(shape1, shape2) and dgamma(shape, rate) must validate with just
  # arg1/arg2 -- the native C++ tie likelihood never reads a 3rd arg, so
  # dbeta's `ncp` and dgamma's `scale` must not be forced as required (RT-172)
  ties14 <- data.frame(height = 2:1,
                       site = 2:3,
                       densityFun = c("dgamma", "dbeta"),
                       arg1 = c(1, 2),
                       arg2 = c(2, 3))

expect_silent(.CheckTies(ties1, "height", "site"))
expect_silent(.CheckTies(ties2, "height", "site"))
expect_error(.CheckTies(ties3, "height", "site"),
             "The following columns in ties contain non-NA values that cannot be coerced to numeric: mean")
expect_error(.CheckTies(ties4, "height", "site"),
             "The following columns in ties contain non-NA values that cannot be coerced to numeric: height, mean")
expect_silent(.CheckTies(ties5, "height", "site"))
expect_error(.CheckTies(ties6, "height", "site"),
             "ties must have either 'mean' and 'sd' columns or 'densityFun' and 'arg1' columns.")
expect_error(.CheckTies(ties7, "height", "site"),
             "Row 1 in ties is missing")
expect_error(.CheckTies(ties8, "height", "site"),
             "Row 2 in ties is missing")
expect_error(.CheckTies(ties9, "height", "site"),
             "Row 1 in ties is missing")
expect_error(.CheckTies(ties10, "height", "site"),
             "dunif, specified in ties, requires more arguments")
expect_error(.CheckTies(ties11, "height", "site"),
             "for dunif, specified in ties, arg2 cannot be NA")
expect_error(.CheckTies(ties12, "height", "site"),
             "arg2 is missing")
expect_silent(.CheckTies(ties14, "height", "site"))

expect_silent(.CheckTies(NULL, "height", "site"))

ties13 <- data.frame(height = 10,
                     site = "A",
                     mean = 100,
                     sd = 5,
                     densityFun = "dunif",
                     arg1 = 50,
                     arg2 = 150,
                     stringsAsFactors = FALSE
)
expect_error(.CheckTies(ties13, "height", "site"),
             "mutually exclusive")

}
)

test_that(".CheckTies() accepts a per-row mixed mean/sd vs densityFun/arg1 ties table (RT-355)", {

  # Row 1 supplies mean/sd, row 2 supplies densityFun/arg1 -- both are
  # individually complete and valid, so the table as a whole should be
  # accepted even though it mixes both column sets across rows.
  tiesMixed <- data.frame(height = c(10, 20),
                          site = c("A", "B"),
                          mean = c(100, NA),
                          sd = c(5, NA),
                          densityFun = c(NA, "dnorm"),
                          arg1 = c(NA, 50),
                          arg2 = c(NA, 10),
                          stringsAsFactors = FALSE)
  expect_silent(.CheckTies(tiesMixed, "height", "site"))

  # Row 2 now supplies neither mean/sd nor densityFun/arg1 -- should error
  # with a message describing the actual problem (either method missing),
  # not the old table-wide "missing mean or sd" message.
  tiesMixedIncomplete <- tiesMixed
  tiesMixedIncomplete[["densityFun"]][2] <- NA
  tiesMixedIncomplete[["arg1"]][2] <- NA
  expect_error(.CheckTies(tiesMixedIncomplete, "height", "site"),
               "Row 2 in ties must specify either 'mean' and 'sd', or 'densityFun' and 'arg1'.")

  # A row specifying both fully is still rejected as mutually exclusive.
  tiesMixedBoth <- tiesMixed
  tiesMixedBoth[["mean"]][2] <- 50
  tiesMixedBoth[["sd"]][2] <- 10
  expect_error(.CheckTies(tiesMixedBoth, "height", "site"),
               "mutually exclusive")
}
)

test_that(".CheckTies() accepts a mixed table needing only arg1 (#1095)", {

  # No arg2 column, because the only explicit densityFun row uses a
  # one-argument density; the mean/sd row still expands to dnorm + arg1 +
  # arg2, so the arity check must see the post-expansion column list. Against
  # the pre-expansion one it reports "dnorm ... requires more arguments" for a
  # row that named no distribution at all.
  tiesMixed1Arg <- data.frame(height = c(10, 20),
                              site = c("A", "B"),
                              mean = c(100, NA),
                              sd = c(5, NA),
                              densityFun = c(NA, "dexp"),
                              arg1 = c(NA, 0.5),
                              stringsAsFactors = FALSE)
  expect_silent(.CheckTies(tiesMixed1Arg, "height", "site"))

  # The rewrite must still populate both of dnorm's arguments.
  checked <- .CheckTies(tiesMixed1Arg, "height", "site")
  expect_identical(checked[["densityFun"]], c("dnorm", "dexp"))
  expect_identical(checked[["arg1"]], c(100, 0.5))
  expect_identical(checked[["arg2"]], c(5, NA_real_))
})

test_that(".CheckTies() treats dt's ncp as optional (#1094)", {

  # base R's dt() gives `ncp` no default, so the generic "arguments after x,
  # before log" heuristic would force it -- friction for the common central
  # case, and it leaves the engine's own ISNAN(ncp) branch unreachable.
  expect_identical(.GetArgsAfterXBeforeLog(names(formals(dt)), "dt"), "df")

  tiesCentralT <- data.frame(height = 1, site = "A", densityFun = "dt",
                             arg1 = 5)
  expect_silent(.CheckTies(tiesCentralT, "height", "site"))

  # A non-positive df is still rejected.
  tiesBadDf <- data.frame(height = 1, site = "A", densityFun = "dt", arg1 = 0)
  expect_error(.CheckTies(tiesBadDf, "height", "site"),
               "'dt' density's 'df' \\(arg1\\) must be > 0")
})

test_that(".CheckTies() rejects a dbeta tie carrying an ncp (#1094)", {

  # dbeta's arg3 is `ncp`, and both engines evaluate the CENTRAL Beta density,
  # so an accepted ncp would be discarded silently. The densities are
  # genuinely different: dbeta(0.4, 2, 3, log = TRUE) = 0.5469647 versus
  # 0.1593703 with ncp = 5.

  tiesNcp <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                        arg1 = 2, arg2 = 3, arg3 = 5)
  expect_error(.CheckTies(tiesNcp, "height", "site"),
               "non-centrality parameter 'ncp' \\(arg3\\) is not supported")

  # An absent or NA arg3 is the ordinary central case and stays silent.
  tiesNoNcp <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                          arg1 = 2, arg2 = 3)
  expect_silent(.CheckTies(tiesNoNcp, "height", "site"))
  tiesNaNcp <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                          arg1 = 2, arg2 = 3, arg3 = NA_real_)
  expect_silent(.CheckTies(tiesNaNcp, "height", "site"))
  # ncp = 0 IS the central density, so it must stay accepted.
  tiesZeroNcp <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                            arg1 = 2, arg2 = 3, arg3 = 0)
  expect_silent(.CheckTies(tiesZeroNcp, "height", "site"))
})

test_that(".CheckMissingArgs() detects a wholesale-missing arg1 (RT-359)", {
  # Gap-detection must start at 1, not at the observed minimum arg number,
  # so a completely absent arg1 is still flagged rather than treated as the
  # start of a contiguous range.
  expect_error(.CheckMissingArgs(c("arg2", "arg3")), "arg1 is missing")
  expect_error(.CheckMissingArgs(c("arg3")), "arg1, arg2 is missing")
  expect_silent(.CheckMissingArgs(c("arg1", "arg2", "arg3")))
  expect_error(.CheckMissingArgs(c("arg1", "arg3")), "arg2 is missing")
}
)

test_that(".CheckTies() rejects degenerate distribution parameters that would silently drop the tie constraint (RT-169, RT-170, RT-171)", {

  # dlnorm: sdlog = 0 divides by zero in the C++ density -> NaN, silently
  # dropped by the MCMC engine's NaN-skipping aggregator (RT-169)
  tiesLnormBad <- data.frame(height = 1, site = "A",
                              densityFun = "dlnorm", arg1 = 0, arg2 = 0)
  tiesLnormOk <- data.frame(height = 1, site = "A",
                             densityFun = "dlnorm", arg1 = 0, arg2 = 1)
  expect_error(.CheckTies(tiesLnormBad, "height", "site"),
               "'dlnorm' density's 'sdlog' \\(arg2\\) must be > 0")
  expect_silent(.CheckTies(tiesLnormOk, "height", "site"))

  # dnorm via the 'mean'/'sd' interface: sd = 0 -> same degenerate class as
  # RT-169's sdlog=0, but reached through the mean/sd row shape rather than
  # densityFun/arg1, since .CheckTies() rewrites mean/sd to dnorm/arg1/arg2
  # (R/InputChecks.R:162-166) before the domain guard runs
  tiesMeanSdBad <- data.frame(height = 1, site = "A", mean = 0, sd = 0)
  tiesMeanSdOk <- data.frame(height = 1, site = "A", mean = 0, sd = 1)
  expect_error(.CheckTies(tiesMeanSdBad, "height", "site"),
               "'dnorm' density's 'sd' \\(arg2\\) must be > 0")
  expect_silent(.CheckTies(tiesMeanSdOk, "height", "site"))

  # dcauchy: scale = 0 (same class as RT-169's sdlog=0)
  tiesCauchyBad <- data.frame(height = 1, site = "A",
                               densityFun = "dcauchy", arg1 = 0, arg2 = 0)
  expect_error(.CheckTies(tiesCauchyBad, "height", "site"),
               "'dcauchy' density's 'scale' \\(arg2\\) must be > 0")

  # dgamma: shape = 0 -> lgamma(0) = +Inf, both old/new logPost become -Inf
  # so accept_proposal always returns TRUE and the tie is ignored (RT-170)
  tiesGammaBad <- data.frame(height = 1, site = "A", densityFun = "dgamma",
                              arg1 = 0, arg2 = 1, arg3 = 1)
  tiesGammaOk <- data.frame(height = 1, site = "A", densityFun = "dgamma",
                             arg1 = 1, arg2 = 1, arg3 = 1)
  expect_error(.CheckTies(tiesGammaBad, "height", "site"),
               "'dgamma' density's 'shape' \\(arg1\\) must be > 0")
  expect_silent(.CheckTies(tiesGammaOk, "height", "site"))

  # dbeta: shape1 = 0 or shape2 = 0 -> same -Inf/accept-all path (RT-170)
  tiesBetaBadShape1 <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                                   arg1 = 0, arg2 = 1, arg3 = 0)
  tiesBetaBadShape2 <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                                   arg1 = 1, arg2 = 0, arg3 = 0)
  tiesBetaOk <- data.frame(height = 1, site = "A", densityFun = "dbeta",
                            arg1 = 1, arg2 = 1, arg3 = 0)
  expect_error(.CheckTies(tiesBetaBadShape1, "height", "site"),
               "'dbeta' density's 'shape1' \\(arg1\\) must be > 0")
  expect_error(.CheckTies(tiesBetaBadShape2, "height", "site"),
               "'dbeta' density's 'shape2' \\(arg2\\) must be > 0")
  expect_silent(.CheckTies(tiesBetaOk, "height", "site"))

  # dweibull: shape = 0 -> not in the C++ native dispatch, routed to the R
  # callback, returns NaN, silently dropped like RT-169 (RT-171)
  tiesWeibullBad <- data.frame(height = 1, site = "A", densityFun = "dweibull",
                                arg1 = 0, arg2 = 1)
  tiesWeibullOk <- data.frame(height = 1, site = "A", densityFun = "dweibull",
                               arg1 = 1, arg2 = 1)
  expect_error(.CheckTies(tiesWeibullBad, "height", "site"),
               "'dweibull' density's 'shape' \\(arg1\\) must be > 0")
  expect_silent(.CheckTies(tiesWeibullOk, "height", "site"))

  # dt: df = 0 (same degenerate class)
  tiesTBad <- data.frame(height = 1, site = "A", densityFun = "dt",
                          arg1 = 0, arg2 = 0)
  expect_error(.CheckTies(tiesTBad, "height", "site"),
               "'dt' density's 'df' \\(arg1\\) must be > 0")

  # dexp: rate = 0 -> log(0) = -Inf in the native density (MCMCEngine.cpp
  # case 3), so logPostNew and logPostOld are both -Inf and their difference
  # is NaN; rate < 0 -> log(negative) = NaN, dropped outright by sum_narm.
  # Both land in the same class as RT-169/RT-170.
  tiesExpZero <- data.frame(height = 1, site = "A",
                            densityFun = "dexp", arg1 = 0, arg2 = 0)
  tiesExpNeg <- data.frame(height = 1, site = "A",
                           densityFun = "dexp", arg1 = -1, arg2 = 0)
  tiesExpOk <- data.frame(height = 1, site = "A",
                          densityFun = "dexp", arg1 = 1, arg2 = 0)
  expect_error(.CheckTies(tiesExpZero, "height", "site"),
               "'dexp' density's 'rate' \\(arg1\\) must be > 0")
  expect_error(.CheckTies(tiesExpNeg, "height", "site"),
               "'dexp' density's 'rate' \\(arg1\\) must be > 0")
  expect_silent(.CheckTies(tiesExpOk, "height", "site"))

  # dgamma: rate = 0 -> shape * log(0) = -Inf (MCMCEngine.cpp case 4), same
  # class as the dexp case above. Reachable by name only because the native
  # override in .GetArgsAfterXBeforeLog() pins dgamma's arg2 to 'rate'.
  tiesGammaBadRate <- data.frame(height = 1, site = "A", densityFun = "dgamma",
                                 arg1 = 1, arg2 = 0)
  expect_error(.CheckTies(tiesGammaBadRate, "height", "site"),
               "'dgamma' density's 'rate' \\(arg2\\) must be > 0")

})

test_that(".CheckTies() rejects a dunif tie with an empty range", {

  # dunif's failure is a relation between args, not a per-arg domain, so
  # the positive-domain loop cannot catch it (min may legitimately be <= 0).
  # min == max: the native density (MCMCEngine.cpp case 1) leaves a +Inf
  # spike at exactly x == min and -Inf everywhere else, and a continuous age
  # never lands on that point.
  tiesUnifEqual <- data.frame(height = 1, site = "A",
                              densityFun = "dunif", arg1 = 50, arg2 = 50)
  expect_error(.CheckTies(tiesUnifEqual, "height", "site"),
               "'dunif' density's 'max' \\(arg2\\) must be > 'min' \\(arg1\\)")

  # min > max: every x fails the range test, so the density is -Inf
  # everywhere and the tie can never be satisfied.
  tiesUnifInverted <- data.frame(height = 1, site = "A",
                                 densityFun = "dunif", arg1 = 60, arg2 = 50)
  expect_error(.CheckTies(tiesUnifInverted, "height", "site"),
               "'dunif' density's 'max' \\(arg2\\) must be > 'min' \\(arg1\\)")

  # A proper range stays silent, including one spanning zero -- 'min' and
  # 'max' are not positive-domain params and must not be caught by the
  # sd/sdlog/scale/rate/shape/df guard.
  tiesUnifOk <- data.frame(height = 1, site = "A",
                           densityFun = "dunif", arg1 = 50, arg2 = 60)
  tiesUnifNegMin <- data.frame(height = 1, site = "A",
                               densityFun = "dunif", arg1 = -10, arg2 = 10)
  expect_silent(.CheckTies(tiesUnifOk, "height", "site"))
  expect_silent(.CheckTies(tiesUnifNegMin, "height", "site"))

  # The guard must not fire on other densities that happen to have
  # arg2 <= arg1 legitimately (e.g. dnorm with a mean above its sd).
  tiesNormSmallSd <- data.frame(height = 1, site = "A",
                                densityFun = "dnorm", arg1 = 100, arg2 = 5)
  expect_silent(.CheckTies(tiesNormSmallSd, "height", "site"))

})
