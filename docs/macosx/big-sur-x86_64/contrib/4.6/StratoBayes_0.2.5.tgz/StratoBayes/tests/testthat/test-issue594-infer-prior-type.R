# Issue 594 (RT-539/540): a bare Prior() is only inferred as a built-in type
# when prior[["args"]] exactly matches that constructor's named args (in
# order, for LogNormalPrior, whose C++ reader is positional). Otherwise it
# takes the custom-R-function path.

test_that("RT-539: Prior(rnorm, dnorm, qnorm) with no args is not inferred", {
  p <- Prior(rnorm, dnorm, qnorm)
  expect_equal(.InferPriorType(p), "")
})

test_that("RT-539: a partial Normal-shaped Prior() is not inferred", {
  p <- Prior(rnorm, dnorm, qnorm, mean = 5)
  expect_equal(.InferPriorType(p), "")
})

test_that("RT-540: Prior() with sdlog/meanlog reversed is not inferred", {
  p <- Prior(rlnorm, dlnorm, qlnorm, sdlog = 2, meanlog = 1)
  expect_equal(.InferPriorType(p), "")
})

test_that("a correctly-ordered bare LogNormal Prior() is still inferred", {
  p <- Prior(rlnorm, dlnorm, qlnorm, meanlog = 1, sdlog = 2)
  expect_equal(.InferPriorType(p), "LogNormalPrior")
})

test_that("bare Prior() with an unrelated extra arg is not inferred", {
  p <- Prior(rnorm, dnorm, qnorm, mean = 0, sd = 1, extra = 1)
  expect_equal(.InferPriorType(p), "")
})

test_that("every built-in prior constructor is inferred from .InferPriorType", {
  expect_equal(.InferPriorType(unclass(UniformPrior(0, 1))), "UniformPrior")
  expect_equal(.InferPriorType(unclass(NormalPrior(0, 1))), "NormalPrior")
  expect_equal(.InferPriorType(unclass(LogNormalPrior(0, 1))), "LogNormalPrior")
  expect_equal(.InferPriorType(unclass(ExponentialPrior(1))),
               "ExponentialPrior")
  expect_equal(.InferPriorType(unclass(TruncNormalPrior(0, 1, -2, 2))),
               "TruncNormalPrior")
  expect_equal(.InferPriorType(unclass(TruncLogNormalPrior(0, 1, 0.1, 2))),
               "TruncLogNormalPrior")
  expect_equal(.InferPriorType(unclass(Fixed(3))), "Fixed")
})

test_that("bare Prior() missing one built-in arg is not inferred", {
  expect_equal(.InferPriorType(Prior(runif, dunif, qunif, min = 0)), "")
  expect_equal(.InferPriorType(Prior(rexp, dexp, qexp)), "")
  expect_equal(
    .InferPriorType(Prior(.rtnorm, .dtnorm, .qtnorm, mean = 0, sd = 1)),
    ""
  )
  expect_equal(
    .InferPriorType(Prior(.rlnormTrunc, TruncLogNormDensity, .qlnormTrunc,
                          meanlog = 0, sdlog = 1)),
    ""
  )
})

test_that("Fixed-shaped Prior() without its 'value' arg is not inferred", {
  p <- Prior(.fixed_R, .fixed_D, .fixed_Q)
  expect_equal(.InferPriorType(p), "")
})

test_that(".PrepareLogPostArgs() routes RT-539 to the custom-fn path", {
  model <- list(priors = list(metro = list(Prior(rnorm, dnorm, qnorm))))
  res <- .PrepareLogPostArgs(model)
  expect_equal(res$priorTypes, "")
  expect_length(res$rCustomFns, 1)
})

test_that(".PrepareLogPostArgs() routes RT-540 to the custom-fn path", {
  model <- list(priors = list(metro = list(
    Prior(rlnorm, dlnorm, qlnorm, sdlog = 2, meanlog = 1)
  )))
  res <- .PrepareLogPostArgs(model)
  expect_equal(res$priorTypes, "")
  expect_length(res$rCustomFns, 1)
})

# Exercises the actual compiled .sb_logpost(), not just the R-side routing
# above: confirms an empty, unnamed priorArgs[[p]] (RT-539) does not throw,
# and that a reordered LogNormal Prior() (RT-540) evaluates to the correct
# numeric density. Every non-prior .sb_logpost() argument is stubbed to its
# no-signal/no-overlap/no-offset shape so only the prior term is exercised.
.sbLogpostPriorOnlyArgs <- list(
  B_list = list(), beta_list = list(), signalValues = list(),
  sigma = numeric(0), overlapPenalty = FALSE,
  signalSectionOverlap = list(), adjustments = list()
)

test_that("RT-539: bare Prior(rnorm, dnorm, qnorm) reaches .sb_logpost", {
  lp <- .PrepareLogPostArgs(
    list(priors = list(metro = list(Prior(rnorm, dnorm, qnorm))))
  )
  result <- do.call(.sb_logpost, c(
    list(x = 0.5, priorTypes = lp$priorTypes, priorArgs = lp$priorArgs,
         rCustomFns = lp$rCustomFns),
    .sbLogpostPriorOnlyArgs
  ))
  expect_equal(result[1], dnorm(0.5, log = TRUE))
})

test_that("RT-540: reversed-order LogNormal matches LogNormalPrior(1, 2)", {
  lpBug <- .PrepareLogPostArgs(list(priors = list(metro = list(
    Prior(rlnorm, dlnorm, qlnorm, sdlog = 2, meanlog = 1)
  ))))
  lpOk <- .PrepareLogPostArgs(
    list(priors = list(metro = list(LogNormalPrior(1, 2))))
  )

  cppBug <- do.call(.sb_logpost, c(
    list(x = 3, priorTypes = lpBug$priorTypes, priorArgs = lpBug$priorArgs,
         rCustomFns = lpBug$rCustomFns),
    .sbLogpostPriorOnlyArgs
  ))
  cppOk <- do.call(.sb_logpost, c(
    list(x = 3, priorTypes = lpOk$priorTypes, priorArgs = lpOk$priorArgs,
         rCustomFns = lpOk$rCustomFns),
    .sbLogpostPriorOnlyArgs
  ))

  expect_equal(cppBug[1], cppOk[1])
  expect_equal(cppBug[1], dlnorm(3, meanlog = 1, sdlog = 2, log = TRUE))
})

test_that("RT-539: bare Prior(rnorm, dnorm, qnorm) completes on both engines", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  bareP <- Prior(rnorm, dnorm, qnorm)
  stratModel1$priors$metro[[1]]    <- bareP
  stratModel1$priorsProposals[[1]] <- bareP

  mcmc <- StratMCMC(stratModel1, nIter = 6, nChains = 1, nThreads = 1)

  for (eng in c("R", "cpp")) {
    td <- file.path(tempdir(), paste0("rt539_", eng, "_", sample.int(1e6, 1)))
    dir.create(td, showWarnings = FALSE, recursive = TRUE)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)
    expect_no_error(
      RunStratModel(stratData1, stratModel1, mcmc, seed = 1, quiet = TRUE,
                    visualise = FALSE, modelDir = td,
                    modelName = paste0("rt539_", eng), engine = eng)
    )
  }
})
