# Regression tests for RT-533 / RT-534 (issue #588).
#
# Two independent halves of one naming-contract defect:
#
# RT-533 — the per-signal arguments `aSigma`, `aLambda`, `bSigma`, `bLambda` and a
# numeric `sigmaFixed` were stored with the user's names intact but consumed
# positionally, so `aSigma = c(b = 0.2, a = 0.1)` on a model with
# `signalNames = c("a", "b")` gave signal *a* signal *b*'s hyperprior — silently,
# and with the stored object left mislabelled. Per the maintainer's ruling on #588,
# names are now honoured and override position (as in a function call), and a
# partly-named vector errors rather than having its intent guessed.
#
# RT-534 — `disableTies` is consumed via `for (site in names(disableTies))`, so an
# unnamed container made the loop body never execute and the whole argument was
# discarded with no condition of any kind. Because a tie used as the prior for an
# alpha parameter must be disabled to stop it contributing to both prior and
# likelihood, that silence changed the posterior.

set.seed(0)

# `stratData2` has signalNames c("a", "b") and sites site1/site2/site3, of which
# site1 is the only one with a tie at index 1 -- the trap flagged on #588 is that
# `disableTies = list(site2 = 1)` only reaches the "ties that are not provided"
# message branch and so passes without exercising the real path.
.nameArgModel <- function(..., sigmaFixed = c(0.5, 0.5)) {
  StratModel(stratData = stratData2, priors = stratPrior2,
             alignmentScale = "age", sedModel = "s", alphaPosition = "b",
             # numeric `sigmaFixed` and few knots: keeps the fixture off the
             # expensive per-site BayesianSpline path
             nKnots = 5, sigmaFixed = sigmaFixed, ...)
}

# Whole-model `identical()` is not a usable oracle here: `splineBase$D` and
# `splineBase$ageSpan` are drawn from the ambient RNG, so two identically
# parameterised models already differ. Assert on the specific binding instead.
.gibbsOf <- function(model) {
  model[["priors"]][["gibbs"]][c("aSigma", "bSigma", "aLambda", "bLambda",
                                 "shapeSigma")]
}

# ---------------------------------------------------------------------------
# RT-534: `disableTies` container shape
# ---------------------------------------------------------------------------

test_that("`disableTies` positive control flips tiesActive (RT-534 fixture)", {
  # Guards the tests below against passing for the wrong reason: this is the
  # variant that reaches the real code path rather than a message-only branch.
  model <- .nameArgModel(disableTies = list(site1 = 1))
  expect_false(model[["tiesActive"]][1, "site1"])
  expect_true(model[["tiesActive"]][2, "site1"])
})

test_that("an unnamed `disableTies` errors instead of being discarded (RT-534)", {
  # Pre-fix each of these was accepted in complete silence -- no error, no
  # warning -- and left `tiesActive` untouched.
  expect_error(.nameArgModel(disableTies = list(1)), "must be named after")
  expect_error(.nameArgModel(disableTies = list(1, 2)), "must be named after")
  # A bare atomic is the likelier typo, and was equally silent.
  expect_error(.nameArgModel(disableTies = 1), "must be named after")
})

test_that("a partly named `disableTies` errors rather than warning malformed", {
  # Pre-fix this warned "Site  in `disableTies` does not exist in the data." --
  # an empty site name, because `names()` returns "" for the unnamed element.
  expect_error(.nameArgModel(disableTies = list(site1 = 1, 2)),
               "must be named after")
  # `nzchar(NA)` is TRUE by default, so an NA name needs its own guard: this is
  # the same class of NA hole as RT-363 in the index check just below it.
  expect_error(
    .nameArgModel(disableTies = stats::setNames(list(1), NA_character_)),
    "must be named after"
  )
})

test_that("`disableTies` default and empty container stay silent", {
  expect_silent(.nameArgModel(disableTies = NULL))
  expect_silent(.nameArgModel(disableTies = list()))
})

# ---------------------------------------------------------------------------
# RT-533: per-signal Gibbs hyperpriors
# ---------------------------------------------------------------------------

test_that("a fully named out-of-order `aSigma`/`aLambda` is reordered (RT-533)", {
  # Pre-fix: signal "a" received 0.2 and 7 (signal b's values), and the stored
  # vector kept the names `b, a` so the model read back mislabelled too.
  named <- .nameArgModel(aSigma  = c(b = 0.2, a = 0.1),
                         aLambda = c(b = 7,   a = 3))
  expect_equal(named[["priors"]][["gibbs"]][["aSigma"]],  c(a = 0.1, b = 0.2))
  expect_equal(named[["priors"]][["gibbs"]][["aLambda"]], c(a = 3,   b = 7))

  # The reordered model must bind exactly as the equivalent positional call.
  positional <- .nameArgModel(aSigma = c(0.1, 0.2), aLambda = c(3, 7))
  expect_equal(unname(unlist(.gibbsOf(named))),
               unname(unlist(.gibbsOf(positional))))
})

test_that("`bSigma`/`bLambda` honour names on the same terms", {
  # Same choke point, so treating only the `a*` pair would reintroduce the very
  # asymmetry under repair.
  named <- .nameArgModel(bSigma  = c(b = 0.04, a = 0.02),
                         bLambda = c(b = 5,    a = 2))
  expect_equal(named[["priors"]][["gibbs"]][["bSigma"]],  c(a = 0.02, b = 0.04))
  expect_equal(named[["priors"]][["gibbs"]][["bLambda"]], c(a = 2,    b = 5))
})

test_that("`shapeSigma` binds each aSigma to its own signal's n (RT-533)", {
  # shapeSigma = aSigma + nPerSignal / 2 is computed positionally, so a
  # mis-ordered aSigma propagates into the Gibbs update itself, not just the
  # stored label.
  named <- .nameArgModel(aSigma = c(b = 0.2, a = 0.1))
  nPerSignal <- stratData2[[c("signalAttr", "nPerSignal")]]
  expect_equal(unname(named[["priors"]][["gibbs"]][["shapeSigma"]]),
               unname(c(0.1, 0.2) + nPerSignal / 2))
})

test_that("names in canonical order and absent names are both left alone", {
  # No-op paths: bit-identical output for existing (documented, positional)
  # usage, and for a user who names in the order the data already has.
  canonical <- .nameArgModel(aSigma = c(a = 0.1, b = 0.2))
  expect_equal(canonical[["priors"]][["gibbs"]][["aSigma"]], c(a = 0.1, b = 0.2))

  unnamed <- .nameArgModel(aSigma = c(0.1, 0.2))
  expect_null(names(unnamed[["priors"]][["gibbs"]][["aSigma"]]))
  expect_equal(unname(unnamed[["priors"]][["gibbs"]][["aSigma"]]), c(0.1, 0.2))
})

test_that("a partly named per-signal vector errors rather than guessing", {
  # The maintainer's ruling on #588: be strict at the edge rather than infer
  # which unnamed element belongs to which signal.
  expect_error(.nameArgModel(aSigma  = c(a = 0.1, 0.2)), "partly named")
  expect_error(.nameArgModel(aLambda = c(3, b = 7)),     "partly named")
})

test_that("unknown or duplicated signal names error", {
  # Silently ignoring a name that matches no signal is the defect class under
  # repair, so it must not be tolerated either.
  expect_error(.nameArgModel(aSigma = c(a = 0.1, z = 0.2)),
               "do not match the signal names")
  expect_error(.nameArgModel(aSigma = c(a = 0.1, a = 0.2)),
               "do not match the signal names")
})

test_that("an unnamed length-1 value still recycles to every signal", {
  # The documented scalar form, unaffected by the name checks.
  scalar <- .nameArgModel(aSigma = 0.02)
  expect_equal(scalar[["priors"]][["gibbs"]][["aSigma"]], c(0.02, 0.02))
  expect_null(names(scalar[["priors"]][["gibbs"]][["aSigma"]]))
})

test_that("a length-1 value named after one of several signals errors", {
  # The scalar form means "this value for every signal", so a single name
  # cannot select one of them -- there is no reading to honour, and silently
  # dropping the name is the defect class under repair.
  expect_error(.nameArgModel(aSigma = c(a = 0.02)),
               "do not match the signal names")
  expect_error(.nameArgModel(aSigma = c(z = 0.02)),
               "do not match the signal names")
})

test_that("a single-signal model still checks the one name it has", {
  # The only route by which a *named* length-1 `sigmaFixed` survives
  # `.NumericNotNA(sigmaFixed, nSignal)`, so the only place its name can be
  # wrong without the length check catching it first.
  sig1 <- stratData1[[c("signalAttr", "signalNames")]]
  expect_length(sig1, 1)

  m1 <- function(...) {
    StratModel(stratData = stratData1, priors = stratPrior1,
               alignmentScale = "height", sedModel = "site", nKnots = 5, ...)
  }
  expect_error(m1(sigmaFixed = c(zzz = 0.5)), "do not match the signal names")
  # ...and accepts the signal's actual name
  right <- m1(sigmaFixed = stats::setNames(0.5, sig1))
  expect_equal(unname(right[["sigmaFixed"]]), 0.5)
})

# ---------------------------------------------------------------------------
# RT-533: numeric `sigmaFixed`
# ---------------------------------------------------------------------------

test_that("a fully named numeric `sigmaFixed` is reordered (RT-533)", {
  # `sigmaFixed` is consumed positionally when filling `sdSpline`, and stored on
  # the model verbatim, so it had both halves of the same defect.
  named <- .nameArgModel(sigmaFixed = c(b = 0.7, a = 0.3))
  expect_equal(named[["sigmaFixed"]], c(a = 0.3, b = 0.7))
})

test_that("`sigmaFixed` treats unnamed and partly named as aSigma does", {
  unnamed <- .nameArgModel(sigmaFixed = c(0.3, 0.7))
  expect_equal(unname(unnamed[["sigmaFixed"]]), c(0.3, 0.7))

  expect_error(.nameArgModel(sigmaFixed = c(a = 0.3, 0.7)), "sigmaFixed")
  expect_error(.nameArgModel(sigmaFixed = c(a = 0.3, z = 0.7)), "sigmaFixed")

  # The logical form must be untouched by the numeric-vector name check
  # (`individualSplineIter` kept at its floor: this path fits a spline per site).
  logical <- .nameArgModel(sigmaFixed = FALSE, individualSplineIter = 4)
  expect_false(logical[["sigmaFixed"]])
})

# ---------------------------------------------------------------------------
# the helper itself
# ---------------------------------------------------------------------------

test_that(".CanonicaliseSignalOrder covers every container shape", {
  sig <- c("a", "b")

  # unnamed: documented positional behaviour, returned untouched
  expect_identical(.CanonicaliseSignalOrder(c(1, 2), sig, "aSigma"), c(1, 2))
  # canonical: untouched, so bundled models stay bit-identical
  expect_identical(.CanonicaliseSignalOrder(c(a = 1, b = 2), sig, "aSigma"),
                   c(a = 1, b = 2))
  # permuted: reordered
  expect_identical(.CanonicaliseSignalOrder(c(b = 2, a = 1), sig, "aSigma"),
                   c(a = 1, b = 2))
  # unnamed scalar: the recycling form, untouched
  expect_identical(.CanonicaliseSignalOrder(1, sig, "aSigma"), 1)
  # partly named, NA-named, empty-named all error
  expect_error(.CanonicaliseSignalOrder(c(a = 1, 2), sig, "aSigma"),
               "partly named")
  expect_error(.CanonicaliseSignalOrder(
    stats::setNames(c(1, 2), c("a", NA)), sig, "aSigma"), "partly named")
  expect_error(.CanonicaliseSignalOrder(
    stats::setNames(c(1, 2), c("a", "")), sig, "aSigma"), "partly named")
  # unknown, duplicated, and a name that covers only some signals all error
  expect_error(.CanonicaliseSignalOrder(c(a = 1, z = 2), sig, "aSigma"),
               "signal names")
  expect_error(.CanonicaliseSignalOrder(c(a = 1, a = 2), sig, "aSigma"),
               "signal names")
  expect_error(.CanonicaliseSignalOrder(c(z = 1), sig, "aSigma"), "signal names")
  expect_error(.CanonicaliseSignalOrder(c(a = 1), sig, "aSigma"), "signal names")
  # absent signalNames is a no-op rather than an error
  expect_identical(.CanonicaliseSignalOrder(c(b = 2, a = 1), NULL, "aSigma"),
                   c(b = 2, a = 1))
})

test_that(".CanonicaliseSignalOrder handles the real signalNames object", {
  # `StratData()` leaves a `.match.hash` attribute on `signalNames`, which makes
  # `identical(names(x), signalNames)` FALSE for even a canonically named
  # vector -- so the no-op fast path is dead unless the attribute is stripped.
  sig <- stratData2[[c("signalAttr", "signalNames")]]
  expect_false(identical(as.character(sig), sig))

  expect_identical(.CanonicaliseSignalOrder(c(a = 1, b = 2), sig, "aSigma"),
                   c(a = 1, b = 2))
  expect_identical(.CanonicaliseSignalOrder(c(b = 2, a = 1), sig, "aSigma"),
                   c(a = 1, b = 2))
  expect_error(.CanonicaliseSignalOrder(c(a = 1, z = 2), sig, "aSigma"),
               "signal names")
})
