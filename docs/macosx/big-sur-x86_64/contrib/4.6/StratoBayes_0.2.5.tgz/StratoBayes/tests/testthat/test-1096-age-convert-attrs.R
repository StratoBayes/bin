# The R and C++ age converters must agree on attributes as well as values, so a
# parity assertion need not be written `ignore_attr = TRUE` -- a names-blind
# comparison cannot notice a site reordering in one engine only (#1096).

test_that(".sb_age_convert carries the same site names as its R twin (#1096)", {
  sawNames <- FALSE
  sawTies <- FALSE

  for (dn in c("stratData1", "stratData2", "stratData3")) {
    data <- .EnsurePreExtracted(get(dn))
    indices <- .CreateIndices(data, "height", "site", "middle")
    set.seed(4211)
    params <- rnorm(length(indices[["names"]]), sd = 0.5)

    rOut <- .AgeConversionStratData(data, indices, params)
    cppOut <- .sb_age_convert(data, indices, params)

    sawNames <- sawNames || !is.null(names(rOut[["signal"]]))
    expect_identical(names(cppOut[["signal"]]), names(rOut[["signal"]]),
                     label = paste(dn, "signal names"))
    if ("ties" %in% names(rOut)) {
      sawTies <- TRUE
      expect_identical(names(cppOut[["ties"]]), names(rOut[["ties"]]),
                       label = paste(dn, "ties names"))
    }

    # Attributes are live here, so names and values cannot drift apart; asserted
    # separately they can.
    expect_equal(cppOut, rOut, label = paste(dn, "whole output"))
  }

  # Only stratData2 is site-named and tied; the other fixtures satisfy the loop
  # on NULL == NULL and never enter the ties branch.
  expect_true(sawNames)
  expect_true(sawTies)
})

# Four R-side intermediates reach C++ through an implicit REALSXP->INTSXP
# coercion. That is well defined for whole numbers and NA_real_ only; a
# fractional or NaN value, or a dropped `dim`, would fail silently or throw from
# an impl frame. Nothing else pins their storage mode.
# Characterisation coverage: nothing in AgeConvert.cpp's name handling can make
# these fail.

test_that("age-conversion intermediates stay integer-coercible (#1096)", {
  gapDf <- matrix(c(TRUE, FALSE, NA, TRUE), nrow = 2)
  gapInd <- .GapIndices(gapDf, "age")
  expect_type(gapInd, "double")
  expect_true(all(is.na(gapInd) | gapInd == trunc(gapInd)))
  expect_false(any(is.nan(gapInd)))
  expect_identical(dim(gapInd), dim(gapDf))

  lithDf <- matrix(c("a", "b", "a", "c"), nrow = 2)
  lithInd <- .LithologyIndices(lithDf, "age")
  expect_true(all(is.na(lithInd) | lithInd == trunc(lithInd)))
  expect_false(any(is.nan(lithInd)))
  expect_identical(dim(lithInd), dim(lithDf))

  for (dn in c("stratData1", "stratData3")) {
    data <- .EnsurePreExtracted(get(dn))
    n <- data[[c("signalAttr", "N")]]
    expect_true(all(n == trunc(n)) && !any(is.nan(n)), label = paste(dn, "N"))

    sedRates <- data[[c("partsAttr", "sedRatesDF")]]
    if (!is.null(sedRates)) {
      expect_true(all(is.na(sedRates) | sedRates == trunc(sedRates)),
                  label = paste(dn, "sedRatesDF"))
      expect_false(any(is.nan(sedRates)), label = paste(dn, "sedRatesDF NaN"))
    }
  }
})
