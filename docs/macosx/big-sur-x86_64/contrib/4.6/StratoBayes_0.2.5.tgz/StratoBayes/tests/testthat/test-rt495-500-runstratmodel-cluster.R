# Targeted regression tests for #538 (RT-500), #537 (RT-499), #536 (RT-498),
# #533 (RT-495) -- all in R/RunStratModel.R. #566/#534/#574 (same file, same
# red-team round) are covered by test-zzy-RunStratModel.R, merged separately
# via PR #599.

test_that("#538 (RT-500): .RunIterations's dead `b == 1` disjunct is removed",
          {
  runIterations <- StratoBayes:::.RunIterations

  # Every real caller passes a = max(2, startIter) >= 2, so a == b == 1 was
  # never reachable in practice.
  expect_equal(runIterations(1, 1), 1)
  expect_equal(runIterations(3, 1), numeric(0))
  expect_equal(runIterations(2, 5), 2:5)
})

test_that("#537 (RT-499): .ReadMCMC errors when a supplied stratMCMC list's
          length disagrees with nRun", {
  readMCMC <- StratoBayes:::.ReadMCMC
  tmpDir <- withr::local_tempdir()

  expect_error(
    readMCMC(list(stratMCMC1, stratMCMC1), readDir = tmpDir, modelName = "x",
             nRun = 3),
    "but has length 2"
  )

  # A length that does match nRun is unaffected.
  result <- readMCMC(list(stratMCMC1, stratMCMC1), readDir = tmpDir,
                     modelName = "x", nRun = 2)
  expect_length(result, 2)
})

test_that("#536 (RT-498): a fresh `newRun` sweep also clears stale
          _error_run_N.txt and _errorMessages.rds files", {
  dir <- withr::local_tempdir()
  modelName <- "rt498test"
  writeLines("boom", file.path(dir, paste0(modelName, "_error_run_1.txt")))
  saveRDS(list("boom"), file.path(dir, paste0(modelName, "_errorMessages.rds")))

  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
               nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
               runParallel = FALSE, quiet = TRUE,
               modelDir = dir, modelName = modelName)

  expect_false(file.exists(file.path(dir, paste0(modelName, "_error_run_1.txt"))))
  expect_false(file.exists(file.path(dir, paste0(modelName, "_errorMessages.rds"))))
})

test_that("#533 (RT-495): a clean sequential run doesn't leave a spurious
          _errorMessages.rds behind", {
  dir <- withr::local_tempdir()
  modelName <- "rt495test"

  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
               nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
               runParallel = FALSE, quiet = TRUE,
               modelDir = dir, modelName = modelName)

  expect_false(file.exists(file.path(dir, paste0(modelName, "_errorMessages.rds"))))
})
