# Regression test for RT-694 (#880): `.MetroPriorLog()`/`.MetroProposalLog()`
# build their density call as `do.call(D, c(x = x[[pr]], args, log = TRUE))`.
# A custom prior whose own `args` legitimately contains a `x` or `log` name
# collides with this internal construction: the R engine hard-errors
# ("formal argument matched by multiple actual arguments"), while the C++
# custom path (`callArgs["x"] = ...`) silently overwrites the user's value
# and computes a different density instead.
#
# `.PriorsValidity()`'s own smoke test masked this at construction time,
# because it merges via `modifyList(list(x = rValue), prior[["args"]])`,
# which overwrites rather than duplicates.
#
# Fix: `Prior()` now rejects `args` names that collide with the internal
# call-construction names (`n` for R(), `x`/`log` for D(), `p` for Q()), so
# the collision can never be constructed in the first place.

test_that("Prior() rejects args named 'x' or 'log' (RT-694, #880)", {
  expect_error(Prior(rnorm, dnorm, qnorm, x = 1), "reserved")
  expect_error(Prior(rnorm, dnorm, qnorm, log = TRUE), "reserved")
})

test_that("Prior() rejects args named 'n' or 'p' (RT-694, #880)", {
  expect_error(Prior(rnorm, dnorm, qnorm, n = 1), "reserved")
  expect_error(Prior(rnorm, dnorm, qnorm, p = 1), "reserved")
})

test_that("Prior() still accepts ordinary argument names", {
  expect_s3_class(Prior(rnorm, dnorm, qnorm, mean = 0, sd = 1), "Prior")
})

test_that("built-in prior constructors never trip the reserved-name check", {
  expect_s3_class(UniformPrior(0, 1), "Prior")
  expect_s3_class(NormalPrior(0, 1), "Prior")
  expect_s3_class(LogNormalPrior(0, 1), "Prior")
  expect_s3_class(ExponentialPrior(1), "Prior")
  expect_s3_class(TruncNormalPrior(0, 1, -2, 2), "Prior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 0.1, 2), "Prior")
  expect_s3_class(Fixed(3), "Prior")
})

test_that("a custom prior legitimately named 'x' can no longer silently collide (RT-694, #880)", {
  # Before the fix this constructed successfully and only failed (R engine)
  # or silently miscomputed (C++ engine) when the density was evaluated.
  custom <- function(val, x, log = FALSE) dnorm(val, mean = x, log = log)
  expect_error(Prior(rnorm, custom, qnorm, x = 3), "reserved")
})
