test_that("boxplot works", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("boxplot 1", function() {
    boxplot(stratPosterior1)
  })})

test_that("boxplot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("boxplot 2", function() {

    boxplot(stratPosterior2, parameters = c(2:3, "lambda"),
                alignment = 2, pch = 21, bg = "red", col = "blue",
            iterations = 4000:5000, xlab = c("a1", "a2", "l1", "l2"),
            ylab = c(expression(alpha), expression(lambda)))
  })})

test_that("boxplot works with different xlab and ylab settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("boxplot 3", function() {

    boxplot(stratPosterior3, parameters = 1,
           xlab = c("alpha[1]"), ylab = "value")
  })})

test_that("boxplot works with different xlab and ylab settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("boxplot 4", function() {

    boxplot(stratPosterior3, parameters = c(1,3),
            xlab = c("alpha[1]", "gamma[1]"), ylab = "value", srt = 0,
            adj = 0.5)
  })})

test_that("boxplot works with fixed parameters", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("boxplot 5", function() {

    boxplot(stratPosterior3, parameters = c(1:3))
  })})


test_that("boxplot works with new cluster object and
          iterations before burnIn", {
            skip_if_not_snapshot_os()
            clustNew <- Cluster(stratPosterior1, iterations = 100:250)

            vdiffr::expect_doppelganger("boxplot 6", function() {
              boxplot(stratPosterior1, alignment = 1,
                          stratCluster = clustNew, type = "o")
            })})


test_that("boxplot.StratPosterior produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({boxplot(stratPosterior1)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("boxplot.StratPosterior validates runs= like its sibling plots (RT-475)", {
  # unlike TracePlot()/ScatterPlot()/BeanPlot()/hist.StratPosterior(), which
  # all call .ValidateRunSelect() immediately after `runSelect <- runs`,
  # boxplot.StratPosterior() used runSelect unvalidated, so runs = NULL
  # surfaced base R's "argument is of length zero" instead of a package message
  expect_error(boxplot(stratPosterior1, runs = NULL, display = FALSE),
               "`runSelect` cannot be NULL")
  expect_error(boxplot(stratPosterior1, runs = 99, display = FALSE),
               "whole numbers between 1")
})

test_that("boxplot.StratPosterior validates `alignment` before dereferencing it (RT-604)", {
  expect_error(boxplot(stratPosterior1, alignment = NULL, display = FALSE),
               "`alignment` cannot be NULL")
  expect_error(boxplot(stratPosterior1, alignment = character(0), display = FALSE),
               "`alignment` cannot be an empty vector")
  expect_error(boxplot(stratPosterior1, alignment = NA, display = FALSE),
               "`alignment` must not contain missing values")
})

test_that("boxplot.StratPosterior validates maxSamples instead of crashing inside .maxSampleDeterministicRows (RT-606)", {
  expect_error(boxplot(stratPosterior1, maxSamples = NA, display = FALSE),
               "`maxSamples`")
  expect_error(boxplot(stratPosterior1, maxSamples = -5, display = FALSE),
               "`maxSamples`")
})
