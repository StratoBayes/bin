test_that("Create indices works with multi gap-names-3-sites", {
  skip_if_not_snapshot_os()
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")

  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "p", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s x p", alphaPosition = "bottom"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "height",
                                 sedModel = "s, p", alphaPosition = "bottom"))

  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "p", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s x p", alphaPosition = "b"))
  expect_snapshot(.CreateIndices(tmulti, alignmentScale = "age",
                                 sedModel = "s, p", alphaPosition = "b"))

  # to hit zetaNames <- NULL
  testData2 <- .GenerateTestData("single", version = "1")
  t2 <- StratData(testData2$signal)

  expect_equal(.CreateIndices(t2, alignmentScale = "height", sedModel = "s x p",
                              alphaPosition = "bottom")$names,
               c("alpha_2", "gammaLog_1"))

})

test_that(".GapIndices() numbers gaps consecutively across sites (#586)", {
  # column 2 is all-gap and has no NA padding, so there is nothing for a
  # `- 1` correction to discount; column 3's gap must still get index 3
  gaps <- matrix(c(FALSE, FALSE,
                   TRUE, TRUE,
                   TRUE, FALSE), nrow = 2)

  expect_identical(.GapIndices(gaps, "height"),
                   matrix(c(NA, NA,
                            1, 2,
                            3, NA), nrow = 2))

  # on the age scale the first column is counted too
  expect_identical(.GapIndices(gaps[, -1], "age"),
                   matrix(c(1, 2,
                            3, NA), nrow = 2))
})

test_that(".CreateIndices() gives each gap its own parameter (#586)", {
  sig <- data.frame(
    site = rep(c("A", "B", "C"), each = 6),
    height = c(seq(0, 10, length.out = 6),
               seq(1, 10, length.out = 6),
               seq(0, 10, length.out = 6)),
    value = rep(c(1, 3, 2, 5, 4, 6), 3)
  )
  # site B is entirely gap and has as many boundaries as any other site
  parts <- data.frame(
    site = c("A", "A", "B", "B", "C", "C"),
    height = c(5, 10, 5, 10, 5, 10),
    partition = c("a1", "a2", "b1", "b2", "c1", "c2"),
    sedRates = c("a1", "a2", NA, NA, NA, "c2")
  )
  stratData <- StratData(signal = sig, parts = parts)
  expect_identical(stratData[[c("partsAttr", "nGaps")]], 3L)

  ind <- .CreateIndices(stratData, "height", "site", "middle")

  expect_identical(ind$names[grep("^gap_", ind$names)],
                   c("gap_B_1", "gap_B_2", "gap_C_1"))
  expect_identical(ind$gapInd,
                   matrix(c(NA, NA,
                            1, 2,
                            3, NA), nrow = 2))

  # the gap block is sized seq_len(nGapsTwo) on the height scale, so the
  # boundaries must use each of those indices exactly once
  for (sedModel in c("site", "partition", "site x partition",
                     "site, partition")) {
    gapInd <- .CreateIndices(stratData, "height", sedModel, "middle")$gapInd
    expect_identical(sort(gapInd[!is.na(gapInd)]),
                     as.numeric(seq_len(stratData[[c("partsAttr",
                                                     "nGapsTwo")]])))
  }
})
