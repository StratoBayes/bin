test_that(".BuildMassBlocks returns all 1x1 for minimal model", {
  model <- list(parametersLengthNotFixed = 3L)
  blocks <- StratoBayes:::.BuildMassBlocks(model)
  expect_length(blocks, 3)
  for (b in blocks) {
    expect_equal(b$k, 1L)
    expect_equal(b$cholMat, 1)
    expect_equal(b$invMat, 1)
  }
  # All free params covered exactly once
  all_idx <- unlist(lapply(blocks, `[[`, "idx"))
  expect_equal(sort(all_idx), 1:3)
})


test_that(".BuildMassBlocks creates 2x2 blocks for site model", {
  skip_on_cran()
  # 3-site height-scale "site" model: alpha at 1,2 gamma at 3,4
  # All 4 are free, no gaps
  model <- list(
    parametersLengthNotFixed = 4L,
    parametersLength = 4L,
    ind = list(
      paramNotFixed = 1:4,
      alpha = c(1L, 2L),
      gamma = c(3L, 4L),
      sedModel = "site"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  # Should have 2 blocks of size 2: (alpha1,gamma1) and (alpha2,gamma2)
  expect_length(blocks, 2)
  expect_equal(blocks[[1]]$k, 2L)
  expect_equal(blocks[[2]]$k, 2L)
  # First block: alpha idx 1 → free 1, gamma idx 3 → free 3
  expect_equal(blocks[[1]]$idx, c(1L, 3L))
  # Second block: alpha idx 2 → free 2, gamma idx 4 → free 4
  expect_equal(blocks[[2]]$idx, c(2L, 4L))
  # All indices covered
  all_idx <- sort(unlist(lapply(blocks, `[[`, "idx")))
  expect_equal(all_idx, 1:4)
})


test_that(".BuildMassBlocks handles fixed parameters", {
  skip_on_cran()
  # 3-site model, but gamma_1 is fixed (param 3 missing from paramNotFixed)
  model <- list(
    parametersLengthNotFixed = 3L,
    parametersLength = 4L,
    ind = list(
      paramNotFixed = c(1L, 2L, 4L),  # alpha1, alpha2, gamma2
      alpha = c(1L, 2L),
      gamma = c(3L, 4L),
      sedModel = "site"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  # alpha1 has no free gamma partner → 1x1 block

  # alpha2 + gamma2 → 2x2 block
  sizes <- vapply(blocks, `[[`, 0L, "k")
  expect_true(2L %in% sizes)
  expect_true(1L %in% sizes)
  # All 3 free params covered
  all_idx <- sort(unlist(lapply(blocks, `[[`, "idx")))
  expect_equal(all_idx, 1:3)
})


test_that(".BuildMassBlocks stays diagonal for partition model", {
  skip_on_cran()
  model <- list(
    parametersLengthNotFixed = 5L,
    parametersLength = 5L,
    ind = list(
      paramNotFixed = 1:5,
      alpha = c(1L, 2L),
      gamma = c(3L, 4L, 5L),
      sedModel = "partition"  # alpha/gamma lengths differ
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)
  # All 1x1 because "partition" model doesn't have 1:1 alpha-gamma pairing
  for (b in blocks) {
    expect_equal(b$k, 1L)
  }
  expect_length(blocks, 5)
})


# ── RT-344: per-site pairing under sedModel = "site x partition" ─────────────
# Under "site x partition", gamma is indexed by unique *partition* and is shared
# across sites, while the per-site sedimentation factor is `zeta`.  The pre-fix
# gate paired alpha with gamma for this model too, admitted purely on
# `length(alphaIdx) == length(gammaIdx)`.  Two consequences, both tested below:
# the optimisation was inert whenever the counts differed (the normal case), and
# it built *wrong* blocks on the occasions they coincided.
#
# Correspondence (verified against real models in both scales):
#   age scale     alpha = sites 1..S, zeta = sites 2..S
#   height scale  alpha = sites 2..S, zeta = sites 3..S
# i.e. alpha[-1] <-> zeta elementwise, since zeta omits alpha[1]'s site.

test_that(".BuildMassBlocks pairs alpha with zeta for site x partition (RT-344)", {
  skip_on_cran()
  # Age-scale S=3, L=2 unique partitions:
  #   alpha 1:3 (sites 1-3), gamma 4:5 (partitions), zeta 6:7 (sites 2-3), gap 8
  model <- list(
    parametersLengthNotFixed = 8L,
    parametersLength = 8L,
    ind = list(
      paramNotFixed = 1:8,
      alpha = 1:3,
      gamma = 4:5,
      zeta = 6:7,
      sedModel = "site x partition"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  twoByTwo <- Filter(function(b) b$k == 2L, blocks)
  # alpha_site2 + zeta_site2, alpha_site3 + zeta_site3 -- NOT alpha + gamma.
  expect_length(twoByTwo, 2L)
  expect_equal(twoByTwo[[1]]$idx, c(2L, 6L))
  expect_equal(twoByTwo[[2]]$idx, c(3L, 7L))

  # alpha_site1 has no zeta partner, so it stays 1x1; gammas are never paired.
  oneIdx <- unlist(lapply(Filter(function(b) b$k == 1L, blocks), `[[`, "idx"))
  expect_setequal(oneIdx, c(1L, 4L, 5L, 8L))

  # Welford accumulators must be sized to the block, or .WelfordUpdateBlocks /
  # .AdaptMassBlocks (R/mcmcFunctions.R) corrupt them silently rather than error.
  for (b in twoByTwo) {
    expect_length(b$wMean, 2L)
    expect_length(b$wM2, 4L)
    expect_equal(b$wN, 0L)
    expect_length(b$cholMat, 4L)
    expect_length(b$invMat, 4L)
  }

  # Blocks must still cover every free parameter exactly once.
  expect_equal(sort(unlist(lapply(blocks, `[[`, "idx"))), 1:8)
})


test_that(".BuildMassBlocks does not pair alpha with gamma when L == S (RT-344)", {
  skip_on_cran()
  # The sharpest red case.  Age-scale S=3 with L=3 unique partitions makes
  # length(alpha) == length(gamma) == 3, so the pre-fix length-equality gate
  # FIRED and produced 2x2 blocks pairing alpha_site<k> with an unrelated
  # *partition's* gamma: (1,4), (2,5), (3,6).  A wrong block is worse than a
  # missing one -- it tells HMC/NUTS two uncorrelated coordinates are coupled.
  model <- list(
    parametersLengthNotFixed = 8L,
    parametersLength = 8L,
    ind = list(
      paramNotFixed = 1:8,
      alpha = 1:3,
      gamma = 4:6,
      zeta = 7:8,
      sedModel = "site x partition"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  twoByTwo <- Filter(function(b) b$k == 2L, blocks)
  expect_length(twoByTwo, 2L)
  expect_equal(twoByTwo[[1]]$idx, c(2L, 7L))
  expect_equal(twoByTwo[[2]]$idx, c(3L, 8L))

  # No gamma index may appear in any multi-parameter block.
  pairedIdx <- unlist(lapply(twoByTwo, `[[`, "idx"))
  expect_false(any(4:6 %in% pairedIdx))
  expect_equal(sort(unlist(lapply(blocks, `[[`, "idx"))), 1:8)
})


test_that(".BuildMassBlocks leaves the plain site model unchanged (RT-344)", {
  skip_on_cran()
  # Comparison case: "site" has a genuine per-site gamma and no zeta, so it keeps
  # the alpha<->gamma pairing.  Identical index layout to the L == S case above,
  # minus zeta -- so this pins that the fix discriminates on sedModel, not shape.
  model <- list(
    parametersLengthNotFixed = 6L,
    parametersLength = 6L,
    ind = list(
      paramNotFixed = 1:6,
      alpha = 1:3,
      gamma = 4:6,
      sedModel = "site"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)

  twoByTwo <- Filter(function(b) b$k == 2L, blocks)
  expect_length(twoByTwo, 3L)
  expect_equal(twoByTwo[[1]]$idx, c(1L, 4L))
  expect_equal(twoByTwo[[2]]$idx, c(2L, 5L))
  expect_equal(twoByTwo[[3]]$idx, c(3L, 6L))
  expect_equal(sort(unlist(lapply(blocks, `[[`, "idx"))), 1:6)
})


test_that(".BuildMassBlocks handles site x partition with no free zeta (RT-344)", {
  skip_on_cran()
  # Height-scale S=2 degenerate case: alpha = site 2 only, zeta is empty.
  # length(alpha) == length(zeta) + 1 still holds, and the pairing loop is a
  # no-op, so every parameter must fall through to a 1x1 block.
  model <- list(
    parametersLengthNotFixed = 3L,
    parametersLength = 3L,
    ind = list(
      paramNotFixed = 1:3,
      alpha = 1L,
      gamma = 2:3,
      zeta = integer(0),
      sedModel = "site x partition"
    )
  )
  blocks <- StratoBayes:::.BuildMassBlocks(model)
  expect_true(all(vapply(blocks, `[[`, 0L, "k") == 1L))
  expect_equal(sort(unlist(lapply(blocks, `[[`, "idx"))), 1:3)
})


test_that(".BuildMassBlocks pairs by site name on a real site x partition model (RT-344)", {
  skip_on_cran()
  # End-to-end check that the synthetic index layouts above match a real model,
  # asserted on parameter NAMES so it cannot pass by coincidence of numbering.
  # This model has S = 3 and L = 4, so length(alpha) != length(gamma) and the
  # pre-fix gate never fired: every block came back 1x1.
  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  ties <- data.frame(
    SIT = c("site1", "site1", "site3"), Hight = c(0, 80, 20),
    arg1 = c(10, 20, 5), arg2 = c(60, 1, 0),
    densityFun = c("dunif", "dcauchy", "dt")
  )
  sData <- StratData(testData$signal, parts = testData$parts, ties = ties,
                     signalColumn = c("a", "b"), zColumn = "Hight",
                     siteColumn = "SIT")
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = 35, max = 45),
    "alpha_site2" = UniformPrior(min = 30, max = 40),
    "alpha_site3" = UniformPrior(min = 30, max = 40),
    "gammaLog_part 1.1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_part 2.1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_part 2.2" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_part 3.1" = NormalPrior(mean = 1, sd = 1),
    "zetaLog_site2" = NormalPrior(mean = 0, sd = 1),
    "zetaLog_site3" = NormalPrior(mean = 0, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.5)),
    class = c("StratPrior", "list"))
  sModel <- StratModel(sData, priors, alignmentScale = "age",
                       sedModel = "site x partition", alphaPosition = "bottom",
                       flexibleKnots = FALSE, knotRange = c(0, 100))

  ind <- sModel[["ind"]]
  blocks <- StratoBayes:::.BuildMassBlocks(sModel)
  freeNames <- ind[["names"]][ind[["paramNotFixed"]]]

  paired <- lapply(Filter(function(b) b$k == 2L, blocks),
                   function(b) freeNames[b$idx])
  expect_equal(paired, list(c("alpha_site2", "zetaLog_site2"),
                            c("alpha_site3", "zetaLog_site3")))
  expect_equal(sort(unlist(lapply(blocks, `[[`, "idx"))),
               seq_len(sModel[["parametersLengthNotFixed"]]))
})


test_that(".MassSampleMomentum produces correct distribution for 1x1 blocks", {
  skip_on_cran()
  set.seed(8172)
  nFree <- 3
  # Mass matrix: diag(4, 9, 1) → chol = diag(2, 3, 1)
  blocks <- list(
    list(idx = 1L, cholMat = 2, invMat = 0.25, k = 1L),
    list(idx = 2L, cholMat = 3, invMat = 1/9, k = 1L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L)
  )
  # Sample many times and check variance
  samples <- replicate(5000, .MassSampleMomentum(blocks, nFree))
  # p ~ N(0, M), so var(p_i) = M_ii
  expect_equal(var(samples[1, ]), 4, tolerance = 0.5)
  expect_equal(var(samples[2, ]), 9, tolerance = 1.0)
  expect_equal(var(samples[3, ]), 1, tolerance = 0.3)
})


test_that(".MassSampleMomentum produces correlated samples for 2x2 blocks", {
  skip_on_cran()
  set.seed(3947)
  nFree <- 2
  # M = [[4, 2], [2, 3]], L = lower cholesky
  M <- matrix(c(4, 2, 2, 3), 2, 2)
  L <- t(chol(M))
  Minv <- solve(M)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(L),
         invMat = as.vector(Minv), k = 2L)
  )
  samples <- replicate(10000, .MassSampleMomentum(blocks, nFree))
  # Check covariance ≈ M
  emp_cov <- cov(t(samples))
  expect_equal(emp_cov[1, 1], 4, tolerance = 0.5)
  expect_equal(emp_cov[2, 2], 3, tolerance = 0.5)
  expect_equal(emp_cov[1, 2], 2, tolerance = 0.5)
})


test_that(".MassKineticEnergy is correct for diagonal blocks", {
  skip_on_cran()
  p <- c(2, 3, 1)
  # M^{-1} = diag(0.5, 0.25, 1)
  blocks <- list(
    list(idx = 1L, cholMat = sqrt(2), invMat = 0.5, k = 1L),
    list(idx = 2L, cholMat = 2, invMat = 0.25, k = 1L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L)
  )
  K <- .MassKineticEnergy(p, blocks)
  expected <- 0.5 * (4 * 0.5 + 9 * 0.25 + 1 * 1)
  expect_equal(K, expected)
})


test_that(".MassKineticEnergy is correct for 2x2 block", {
  skip_on_cran()
  p <- c(1, 2)
  M <- matrix(c(4, 1, 1, 2), 2, 2)
  Minv <- solve(M)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M))),
         invMat = as.vector(Minv), k = 2L)
  )
  K <- .MassKineticEnergy(p, blocks)
  expected <- 0.5 * drop(p %*% Minv %*% p)
  expect_equal(K, expected, tolerance = 1e-10)
})


test_that(".MassInvMultiply is correct for mixed blocks", {
  skip_on_cran()
  p <- c(1, 2, 3)
  M2 <- matrix(c(4, 1, 1, 2), 2, 2)
  M2inv <- solve(M2)

  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M2))),
         invMat = as.vector(M2inv), k = 2L),
    list(idx = 3L, cholMat = sqrt(5), invMat = 0.2, k = 1L)
  )
  result <- .MassInvMultiply(p, blocks, 3L)
  expected <- c(drop(M2inv %*% c(1, 2)), 3 * 0.2)
  expect_equal(result, expected, tolerance = 1e-10)
})


test_that(".MassBlocksToDiag extracts diagonal correctly", {
  skip_on_cran()
  M2 <- matrix(c(4, 1, 1, 2), 2, 2)
  M2inv <- solve(M2)
  blocks <- list(
    list(idx = c(1L, 2L), cholMat = as.vector(t(chol(M2))),
         invMat = as.vector(M2inv), k = 2L),
    list(idx = 3L, cholMat = 1, invMat = 0.5, k = 1L)
  )
  diag_vec <- .MassBlocksToDiag(blocks, 3)
  expect_equal(diag_vec[1], M2inv[1, 1], tolerance = 1e-10)
  expect_equal(diag_vec[2], M2inv[2, 2], tolerance = 1e-10)
  expect_equal(diag_vec[3], 0.5)
})


test_that(".AdaptMassBlocks produces correct block covariance", {
  skip_on_cran()
  set.seed(4519)
  n <- 1000
  # Generate correlated data for a 2x2 block
  Sigma <- matrix(c(4, 2, 2, 3), 2, 2)
  L <- t(chol(Sigma))
  samples <- matrix(rnorm(n * 2), ncol = 2) %*% t(L)
  # Add a third independent column
  freeHistory <- cbind(samples, rnorm(n, sd = 2))

  blocks <- list(
    list(idx = c(1L, 2L), cholMat = c(1, 0, 0, 1),
         invMat = c(1, 0, 0, 1), k = 2L,
         wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L),
    list(idx = 3L, cholMat = 1, invMat = 1, k = 1L,
         wMean = 0, wM2 = 0, wN = 0L)
  )

  # Welford: accumulate then adapt
  blocks <- .WelfordUpdateBlocks(blocks, freeHistory)
  adapted <- .AdaptMassBlocks(blocks)

  # RT-162: the inverse mass matrix M^{-1} (= invMat) equals the empirical
  # covariance Sigma, and the mass matrix M (= cholMat %*% t(cholMat)) equals
  # Sigma^{-1}. (An earlier version of this test asserted M ≈ Sigma, which
  # encoded the sign-inverted metric and is exactly why the bug survived.)
  Minv_adapted <- matrix(adapted[[1]]$invMat, 2, 2)
  expect_equal(Minv_adapted[1, 1], 4, tolerance = 0.5)
  expect_equal(Minv_adapted[2, 2], 3, tolerance = 0.5)
  expect_equal(Minv_adapted[1, 2], 2, tolerance = 0.5)

  # cholMat factors M = Sigma^{-1}, so M %*% M^{-1} = I
  L_adapted <- matrix(adapted[[1]]$cholMat, 2, 2)
  M_adapted <- L_adapted %*% t(L_adapted)
  expect_equal(M_adapted %*% Minv_adapted, diag(2), tolerance = 1e-6)

  # Block 2: M^{-1} recovers variance ≈ 4; cholMat^2 = M = 1/variance
  expect_equal(adapted[[2]]$invMat, 4, tolerance = 1.0)
  expect_equal(adapted[[2]]$cholMat^2, 1 / adapted[[2]]$invMat, tolerance = 1e-8)
})


test_that("Block-diagonal leapfrog matches diagonal for 1x1 blocks", {
  skip_on_cran()
  set.seed(6201)
  nFree <- 3
  massMatInv <- c(0.5, 0.25, 1.0)
  massMat <- 1.0 / massMatInv
  blocks1x1 <- list(
    list(idx = 1L, cholMat = sqrt(massMat[1]), invMat = massMatInv[1], k = 1L),
    list(idx = 2L, cholMat = sqrt(massMat[2]), invMat = massMatInv[2], k = 1L),
    list(idx = 3L, cholMat = sqrt(massMat[3]), invMat = massMatInv[3], k = 1L)
  )
  q <- rnorm(3)
  p <- rnorm(3)
  grad <- rnorm(3)
  # A simple gradient function (quadratic potential)
  gradFn <- function(params) {
    freeP <- params[1:3]
    list(logPost = -0.5 * sum(freeP^2), grad = -freeP, ok = TRUE)
  }
  fullParams <- q  # trivial case: freeIdx = 1:3

  res_diag <- .HMCLeapfrog(q, p, grad, 0.1, 5L, massMatInv,
                             gradFn, 1:3, fullParams, 1.0)
  res_block <- .HMCLeapfrog(q, p, grad, 0.1, 5L, NULL,
                              gradFn, 1:3, fullParams, 1.0,
                              massBlocks = blocks1x1)
  expect_equal(res_diag$q, res_block$q, tolerance = 1e-10)
  expect_equal(res_diag$p, res_block$p, tolerance = 1e-10)
  expect_equal(res_diag$logPost, res_block$logPost, tolerance = 1e-10)
})
