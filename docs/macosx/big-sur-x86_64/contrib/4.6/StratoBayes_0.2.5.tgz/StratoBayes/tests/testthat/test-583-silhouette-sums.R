# The silhouette widths that drive cluster-count selection in the proto and pam
# backends are derived from a table of distance sums, not from cluster's own
# silhouette routine. That routine is the oracle throughout: it is a genuinely
# independent implementation, in C, in another package, so these are not parity
# tests over a single implementation.

library("cluster")
library("protoclust")

RefWidths <- function(cluster, d, keep = NULL) {
  if (!is.null(keep)) {
    cluster <- cluster[keep]
    # base R, not `.SubsetDist()`: the oracle must not share package code with
    # what it is checking.
    d <- stats::as.dist(as.matrix(d)[keep, keep])
  }
  sil <- silhouette(cluster, d)
  if (length(sil) == 1 && is.na(sil)) NULL else unname(sil[, "sil_width"])
}

# ---------------------------------------------------------------------------
# .ClusterDistSumsCpp
# ---------------------------------------------------------------------------

test_that(".ClusterDistSumsCpp sums distances to each group", {
  set.seed(1)
  x <- matrix(rnorm(40), 20)
  d <- dist(x)
  group <- rep(1:4, each = 5)
  expect_equal(.ClusterDistSumsCpp(unclass(d), group, 4L),
               t(rowsum(as.matrix(d), group)),
               ignore_attr = TRUE)
})

test_that(".ClusterDistSumsCpp treats group 0 as excluded", {
  set.seed(2)
  x <- matrix(rnorm(30), 15)
  d <- dist(x)
  group <- c(rep(1:3, each = 5))
  drop <- c(2L, 7L, 11L)
  masked <- group
  masked[drop] <- 0L
  expect_equal(.ClusterDistSumsCpp(unclass(d), masked, 3L),
               t(rowsum(as.matrix(d)[-drop, ], group[-drop])),
               ignore_attr = TRUE)
})

test_that(".ClusterDistSumsCpp validates its arguments", {
  d <- unclass(dist(matrix(rnorm(20), 10)))
  expect_error(.ClusterDistSumsCpp(d, 1L, 1L), "at least two entries")
  expect_error(.ClusterDistSumsCpp(d, rep(1L, 10), 0L), "at least 1")
  expect_error(.ClusterDistSumsCpp(d, rep(1L, 9), 1L), "packed lower triangle")
  expect_error(.ClusterDistSumsCpp(d, c(NA_integer_, rep(1L, 9)), 1L),
               "must not contain NA")
  expect_error(.ClusterDistSumsCpp(d, c(3L, rep(1L, 9)), 2L),
               "out-of-range value 3")
  expect_error(.ClusterDistSumsCpp(d, c(-1L, rep(1L, 9)), 2L),
               "out-of-range value -1")
})

# ---------------------------------------------------------------------------
# .SilhouetteWidths against cluster::silhouette()
# ---------------------------------------------------------------------------

test_that(".SilhouetteWidths matches silhouette() on random partitions", {
  set.seed(3)
  for (trial in seq_len(30)) {
    n <- sample(6:50, 1)
    x <- matrix(rnorm(n * sample(1:3, 1)), n)
    k <- sample(2:5, 1)
    cluster <- sample.int(k, n, replace = TRUE)
    cluster[seq_len(k)] <- seq_len(k)
    d <- dist(x)
    expect_equal(.SilhouetteWidths(unclass(d), cluster, k),
                 RefWidths(cluster, d))
  }
})

test_that(".SilhouetteWidths matches silhouette() under a keep mask", {
  set.seed(4)
  for (trial in seq_len(30)) {
    n <- sample(10:50, 1)
    x <- matrix(rnorm(n * 2), n)
    k <- sample(2:4, 1)
    cluster <- sample.int(k, n, replace = TRUE)
    cluster[seq_len(k)] <- seq_len(k)
    keep <- runif(n) > 0.3
    keep[seq_len(k)] <- TRUE
    d <- dist(x)
    expect_equal(.SilhouetteWidths(unclass(d), cluster, k, keep = keep),
                 RefWidths(cluster, d, keep))
  }
})

test_that(".SilhouetteWidths scores a lone cluster member 0", {
  x <- matrix(c(0, 0, 1, 1, 1, 1.1, 5, 5), ncol = 2, byrow = TRUE)
  d <- dist(x)
  cluster <- c(1L, 2L, 2L, 3L)
  widths <- .SilhouetteWidths(unclass(d), cluster, 3L)
  expect_equal(widths[c(1, 4)], c(0, 0))
  expect_equal(widths, RefWidths(cluster, d))
})

test_that(".SilhouetteWidths scores coincident observations 0", {
  # Every distance is zero, so `a` and `b` are both 0 and there is nothing to
  # divide by; silhouette() reports 0 rather than NaN.
  d <- dist(matrix(0, 9, 2))
  cluster <- rep(1:3, each = 3)
  expect_equal(.SilhouetteWidths(unclass(d), cluster, 3L), rep(0, 9))
  expect_equal(.SilhouetteWidths(unclass(d), cluster, 3L),
               RefWidths(cluster, d))
})

test_that(".SilhouetteWidths ignores a cluster the keep mask empties", {
  set.seed(5)
  x <- rbind(matrix(rnorm(6), 3), matrix(rnorm(4) + 20, 2),
             matrix(rnorm(6) - 20, 3))
  d <- dist(x)
  cluster <- c(1L, 1L, 1L, 2L, 2L, 3L, 3L, 3L)
  keep <- c(rep(TRUE, 3), FALSE, FALSE, rep(TRUE, 3))
  # Kept labels are {1, 3}: not contiguous, and cluster 2 must not be offered
  # as anyone's nearest neighbour.
  expect_equal(.SilhouetteWidths(unclass(d), cluster, 3L, keep = keep),
               RefWidths(cluster, d, keep))
})

test_that(".SilhouetteWidths returns NULL where silhouette() returns NA", {
  set.seed(6)
  x <- matrix(rnorm(20), 10)
  d <- dist(x)
  # One cluster left after masking: silhouette() gives a bare NA.
  cluster <- c(rep(1L, 5), rep(2L, 5))
  keep <- c(rep(TRUE, 5), rep(FALSE, 5))
  expect_null(.SilhouetteWidths(unclass(d), cluster, 2L, keep = keep))
  expect_null(RefWidths(cluster, d, keep))

  # As many clusters as observations: likewise NA.
  keep2 <- c(TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE)
  expect_null(.SilhouetteWidths(unclass(d), cluster, 2L, keep = keep2))
  expect_null(RefWidths(cluster, d, keep2))
})

# ---------------------------------------------------------------------------
# End-to-end: the cluster assignments the two branches return are unchanged
# ---------------------------------------------------------------------------

# Independent restatement of `.ProtoCluster()`, scoring each cut with
# `cluster::silhouette()` directly, as an oracle for the whole function.
RefProtoCluster <- function(clustDat, clustMax, silCutOff = 0.5,
                            silOutlierThreshold = TRUE,
                            silOutlierSDFromMean = 3) {
  d <- dist(clustDat, method = "euclidian")
  tree <- protoclust(d)
  cuts <- lapply(2:clustMax, function(k) cutree(tree, k = k))
  sils <- lapply(cuts, function(cut) silhouette(cut, d)[, "sil_width"])
  if (!isFALSE(silOutlierThreshold)) {
    for (i in seq_along(cuts)) {
      sil <- sils[[i]]
      thresh <- if (is.numeric(silOutlierThreshold)) {
        silOutlierThreshold
      } else {
        max(0, mean(sil) - (silOutlierSDFromMean * sd(sil)))
      }
      if (is.na(thresh)) next
      isOutlier <- !is.na(sil) & sil < thresh
      if (any(isOutlier)) {
        kept <- stats::as.dist(as.matrix(d)[!isOutlier, !isOutlier])
        tmp <- silhouette(cuts[[i]][!isOutlier], kept)
        if (!(length(tmp) == 1 && is.na(tmp))) {
          cuts[[i]][isOutlier] <- 0
          sils[[i]] <- tmp[, "sil_width"]
        }
      }
    }
  }
  meanSils <- vapply(sils, mean, double(1))
  best <- which.max(meanSils)
  if (meanSils[[best]] >= silCutOff) {
    cuts[[best]]
  } else {
    1 + double(nrow(clustDat))
  }
}

test_that(".ProtoCluster is unchanged by the shared distance-sum table", {
  set.seed(7)
  for (trial in seq_len(20)) {
    n <- sample(20:120, 1)
    nMode <- sample(1:4, 1)
    dims <- sample(1:4, 1)
    centres <- matrix(rnorm(nMode * dims, sd = sample(c(1, 8), 1)), nMode)
    x <- centres[sample.int(nMode, n, TRUE), , drop = FALSE] +
      matrix(rnorm(n * dims), n)
    clustMax <- sample(2:12, 1)
    silCutOff <- sample(c(0, 0.5, 0.9), 1)
    threshold <- sample(list(TRUE, FALSE, 0.3), 1)[[1]]
    got <- suppressWarnings(.ProtoCluster(x, clustMax, silCutOff, threshold))
    want <- suppressWarnings(
      RefProtoCluster(x, clustMax, silCutOff, threshold)
    )
    expect_identical(as.vector(got), as.vector(want))
  }
})

test_that(".ProtoCluster still retains outliers when the recompute is NA", {
  # All but one of the survivors share a label, so the recomputed silhouette
  # is a bare NA and the outlier labels must be rolled back.
  set.seed(8)
  x <- rbind(matrix(rnorm(20, sd = 0.01), 10), c(50, 50), c(-50, -50))
  warnings <- capture_warnings(
    result <- .ProtoCluster(x, clustMax = 3, silOutlierThreshold = 0.99)
  )
  expect_match(warnings, "retaining outliers", all = TRUE)
  expect_false(any(result == 0))
})

# Independent restatement of `.PamCluster()`, scoring each k with
# `cluster::pam()` and `cluster::silhouette()` directly, as an oracle for the
# whole function.
RefPamCluster <- function(clustDat, clustMax, silCutOff = 0.5,
                          silOutlierThreshold = TRUE,
                          silOutlierSDFromMean = 3) {
  nrowCD <- nrow(clustDat)
  clustMax <- min(nrowCD - 1, clustMax)
  if (clustMax < 2L) return(rep.int(1L, nrowCD))

  d <- dist(clustDat, method = "euclidian")
  fits <- lapply(2:clustMax, function(k) pam(d, k = k)[["clustering"]])
  sils <- lapply(fits, function(cl) silhouette(cl, d)[, "sil_width"])
  if (!isFALSE(silOutlierThreshold)) {
    for (i in seq_along(fits)) {
      sil <- sils[[i]]
      thresh <- if (is.numeric(silOutlierThreshold)) {
        silOutlierThreshold
      } else {
        max(0, mean(sil) - (silOutlierSDFromMean * sd(sil)))
      }
      if (is.na(thresh)) next
      isOutlier <- !is.na(sil) & sil < thresh
      if (!any(isOutlier)) next
      if (all(isOutlier)) {
        # `.PamCluster()` gives this k an avg.width of -1, ineligible for
        # selection; #692 tracks its (undertested) behaviour here.
        fits[[i]][isOutlier] <- 0
        sils[[i]] <- rep(-1, length(sil))
        next
      }
      kept <- stats::as.dist(as.matrix(d)[!isOutlier, !isOutlier])
      tmp <- silhouette(fits[[i]][!isOutlier], kept)
      if (!(length(tmp) == 1 && is.na(tmp))) {
        fits[[i]][isOutlier] <- 0
        sils[[i]] <- tmp[, "sil_width"]
      }
    }
  }
  meanSils <- vapply(sils, mean, double(1))
  best <- which.max(meanSils)
  if (meanSils[[best]] >= silCutOff) {
    fits[[best]]
  } else {
    1 + double(nrowCD)
  }
}

test_that(".PamCluster is unchanged by the shared distance-sum table", {
  set.seed(9)
  for (trial in seq_len(20)) {
    n <- sample(20:120, 1)
    nMode <- sample(1:4, 1)
    dims <- sample(1:4, 1)
    # A wide spread (25) is included, not just 1 and 8, so some trials leave
    # a clearly separated cluster for the outlier recompute to prune and
    # rescore -- a narrower range left that path untested.
    centres <- matrix(rnorm(nMode * dims, sd = sample(c(1, 8, 25), 1)), nMode)
    x <- centres[sample.int(nMode, n, TRUE), , drop = FALSE] +
      matrix(rnorm(n * dims), n)
    clustMax <- sample(2:12, 1)
    silCutOff <- sample(c(0, 0.5, 0.9), 1)
    threshold <- sample(list(TRUE, FALSE, 0.3), 1)[[1]]
    got <- suppressWarnings(.PamCluster(x, clustMax, silCutOff, threshold))
    want <- suppressWarnings(RefPamCluster(x, clustMax, silCutOff, threshold))
    expect_identical(as.vector(got), as.vector(want))
  }
})
