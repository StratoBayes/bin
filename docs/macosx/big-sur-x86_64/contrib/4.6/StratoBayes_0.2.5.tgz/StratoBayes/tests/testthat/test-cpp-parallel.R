# Tests for intra-run parallel chain execution (std::thread)
#
# Verifies that the parallel chain path (nThreads > 1) produces valid output
# and that the thread-safety fixes (precomputed prior constants, native C++
# proposal args) work correctly.

# ── Helper ────────────────────────────────────────────────────────────────────

run_parallel_test <- function(data_name, model_name,
                              nIter = 50, nChains = 4, nThreads = 2,
                              prior_overrides = NULL) {
  data(list = data_name, package = "StratoBayes", envir = environment())
  data(list = model_name, package = "StratoBayes", envir = environment())

  sData <- get(data_name)
  sModel <- get(model_name)

  # Override priors in both metro and proposals fields
  if (!is.null(prior_overrides)) {
    for (i in seq_along(prior_overrides)) {
      if (!is.null(prior_overrides[[i]]) && i <= length(sModel$priors$metro)) {
        sModel$priors$metro[[i]] <- prior_overrides[[i]]
        sModel$priorsProposals[[i]] <- prior_overrides[[i]]
      }
    }
  }

  td <- file.path(tempdir(), paste0("par_test_", data_name, "_", nThreads,
                                     "_", sample.int(1e6, 1)))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mcmc <- StratMCMC(sModel, nIter = nIter, nChains = nChains,
                    nThreads = nThreads)

  set.seed(4729)
  result <- RunStratModel(
    stratObject = sData,
    stratModel = sModel,
    stratMCMC = mcmc,
    seed = 1,
    quiet = TRUE,
    visualise = FALSE,
    modelDir = td,
    modelName = "par_test",
    engine = "cpp"
  )

  result
}


# ── Basic parallel execution ────────────────────────────────────────────────

test_that("C++ engine runs with nThreads > 1", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 50, nChains = 4, nThreads = 2)
  expect_equal(dim(r$samples)[1], 50)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})

test_that("Parallel and sequential produce valid output on same data", {
  r_seq <- run_parallel_test("stratData1", "stratModel1",
                             nIter = 50, nChains = 4, nThreads = 0)
  r_par <- run_parallel_test("stratData1", "stratModel1",
                             nIter = 50, nChains = 4, nThreads = 2)

  expect_equal(dim(r_seq$samples)[1], dim(r_par$samples)[1])

  expect_true(all(is.finite(r_seq$samples[, "posterior", , ])))
  expect_true(all(is.finite(r_par$samples[, "posterior", , ])))
})


# ── Truncated prior thread safety ───────────────────────────────────────────

test_that("Parallel path works with TruncNormalPrior", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 50, nChains = 4, nThreads = 2,
                         prior_overrides = list(
                           TruncNormalPrior(0, 10, -20, 20)
                         ))
  expect_equal(dim(r$samples)[1], 50)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})

test_that("Parallel path works with TruncLogNormalPrior", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 50, nChains = 4, nThreads = 2,
                         prior_overrides = list(
                           NULL,
                           NULL,
                           TruncLogNormalPrior(0, 1, 0.01, 10)
                         ))
  expect_equal(dim(r$samples)[1], 50)
})


# ── Multiple datasets ──────────────────────────────────────────────────────

test_that("Parallel execution works on stratData2 (ties with native densities)", {
  # stratData2 has ties (dnorm, dexp) — all natively supported in C++.
  # With T-107 fix, canParallelize is true so chains run in parallel.
  r <- run_parallel_test("stratData2", "stratModel2",
                         nIter = 30, nChains = 4, nThreads = 2)
  expect_equal(dim(r$samples)[1], 30)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})

test_that("Parallel execution works on stratData4", {
  r <- run_parallel_test("stratData4", "stratModel4",
                         nIter = 30, nChains = 4, nThreads = 2)
  expect_equal(dim(r$samples)[1], 30)
})


# ── nThreads edge cases ─────────────────────────────────────────────────────

test_that("nThreads = 0 runs sequentially", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 30, nChains = 4, nThreads = 0)
  expect_equal(dim(r$samples)[1], 30)
})

test_that("nThreads = 1 runs sequentially", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 30, nChains = 4, nThreads = 1)
  expect_equal(dim(r$samples)[1], 30)
})

test_that("nThreads > nChains does not crash", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 30, nChains = 1, nThreads = 2)
  expect_equal(dim(r$samples)[1], 30)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})

test_that("nChains = 1 with nThreads > 1 does not crash", {
  # Single chain — parallel with 1 chain is legal but trivial
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 30, nChains = 1, nThreads = 2)
  expect_equal(dim(r$samples)[1], 30)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})


# ── Stress: longer runs to catch intermittent issues ────────────────────────

test_that("Parallel path survives 200 iterations without NaN/crash", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 200, nChains = 4, nThreads = 2)
  expect_equal(dim(r$samples)[1], 200)
  posts <- r$samples[, "posterior", , ]
  expect_true(all(is.finite(posts)))
  # Posterior should not be stuck at a single value
  expect_gt(sd(posts), 0)
})

test_that("Parallel path with many chains (8) produces valid output", {
  r <- run_parallel_test("stratData1", "stratModel1",
                         nIter = 50, nChains = 8, nThreads = 2)
  expect_equal(dim(r$samples)[1], 50)
  expect_true(all(is.finite(r$samples[, "posterior", , ])))
})


# ── Posterior quality: not degenerate ────────────────────────────────────────

test_that("Parallel posterior has non-trivial acceptance (not stuck)", {
  r <- run_parallel_test("stratData4", "stratModel4",
                         nIter = 100, nChains = 4, nThreads = 2)
  # samples array: [iteration, parameter, run, chain]
  posts <- r$samples[, "posterior", 1, 1]
  post_diffs <- diff(posts)
  pct_moved <- mean(post_diffs != 0)
  expect_gt(pct_moved, 0.05,
            label = "At least 5% of iterations should show posterior movement")
})


# ── StratMCMC nThreads defaults ─────────────────────────────────────────────

test_that("StratMCMC defaults nThreads from mc.cores option", {
  data(stratModel1, package = "StratoBayes", envir = environment())

  # Without mc.cores set, defaults to 1L
  old <- options(mc.cores = NULL)
  on.exit(options(old), add = TRUE)
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 6)
  expect_equal(mcmc$nThreads, 1L)

  # With mc.cores set, uses that value
  options(mc.cores = 4)
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 6)
  expect_equal(mcmc$nThreads, 4L)
})

test_that("StratMCMC respects explicit nThreads", {
  data(stratModel1, package = "StratoBayes", envir = environment())
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 8, nThreads = 2)
  expect_equal(mcmc$nThreads, 2L)
})
