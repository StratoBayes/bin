# tests/testthat/test-rt162-mass-matrix.R
#
# Deliberately NOT skip_on_cran(): seeded, pure-R linear algebra in 0.2s.
# NOT_CRAN is true only on the nightly cron (#1026), so gating this would keep
# it out of the PR merge gate for no gain.
#
# Regression tests for RT-162: the adapted HMC/NUTS metric must store the
# *inverse* mass matrix as M^{-1} = Sigma (empirical parameter covariance),
# giving M = Sigma^{-1}. The bug set M^{-1} = Sigma^{-1} (i.e. M = Sigma),
# the worst-conditioned metric: leapfrog steps become tiny in wide dimensions
# and large in narrow ones. The stationary distribution stays correct, so the
# only way to catch this is to assert the sign of the adaptation directly.

test_that("RT-162: diagonal .AdaptMassMatrix scales M^{-1} WITH the variance", {
  set.seed(162)
  n <- 4000L
  # Highly anisotropic posterior: a wide parameter (var ~ 100) and a narrow
  # one (var ~ 0.01) — a variance ratio of ~1e4.
  freeHistory <- cbind(rnorm(n, sd = 10), rnorm(n, sd = 0.1))
  empVar <- apply(freeHistory, 2, var)

  # Minimal args/mcmc that clear all three early-return guards in
  # .AdaptMassMatrix (freeze window, doubling schedule, unique-rows), so the
  # adaptation actually runs rather than returning the input unchanged.
  hmcArgs <- list(massMatInv = c(1, 1))          # identity metric on input
  mcmc <- list(currentIter = 10L, startAdapting = 0L, endAdapting = 1000L)
  restartFn <- function(args) invisible(NULL)

  adapted <- .AdaptMassMatrix(
    hmcArgs, freeHistory, historySize = n, mcmc = mcmc, restartFn = restartFn)
  mmi <- adapted[["massMatInv"]]

  # Guard against a silent no-op: the metric must have moved off identity.
  expect_false(isTRUE(all.equal(mmi, c(1, 1))))

  # M^{-1} = Sigma: the inverse mass matrix equals the empirical variance, so
  # it is LARGE in the wide dimension and SMALL in the narrow one.
  expect_equal(mmi, empVar, tolerance = 1e-6)
  expect_gt(mmi[1], mmi[2])

  # The ratio tracks the variance ratio (~1e4), NOT its reciprocal (~1e-4) as
  # the pre-fix `massMatInv <- 1/vars` would have produced.
  expect_equal(mmi[1] / mmi[2], empVar[1] / empVar[2], tolerance = 1e-6)
})


test_that("RT-162: adapted block metric draws momentum with covariance M = Sigma^{-1}", {
  set.seed(1620)
  n <- 5000L
  # Anisotropic + correlated target covariance. Generating with chol(Sigma)
  # (upper) so that cov(freeHistory) ~ Sigma.
  Sigma <- matrix(c(9, 3, 3, 4), 2, 2)
  freeHistory <- matrix(rnorm(n * 2), ncol = 2) %*% chol(Sigma)
  empCov <- cov(freeHistory)

  blocks <- list(list(idx = c(1L, 2L), k = 2L,
                      cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                      wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L))
  blocks <- .WelfordUpdateBlocks(blocks, freeHistory)
  blocks <- .AdaptMassBlocks(blocks)

  # invMat = M^{-1} = empirical covariance (plus the ridge), which is ~Sigma.
  Minv <- matrix(blocks[[1]]$invMat, 2, 2)
  expect_equal(Minv, empCov + diag(1e-10, 2), tolerance = 1e-6)
  expect_equal(Minv, Sigma, tolerance = 0.1)   # scales WITH the target covariance

  # Momentum is drawn p ~ N(0, M) with M = (empirical cov)^{-1}. The empirical
  # covariance of many sampled momenta must therefore match M = cholMat cholMat^T,
  # NOT the covariance itself — the end-to-end consequence of the correct sign.
  L <- matrix(blocks[[1]]$cholMat, 2, 2)
  M <- L %*% t(L)
  P <- replicate(20000L, .MassSampleMomentum(blocks, 2L))
  expect_equal(cov(t(P)), M, tolerance = 0.05)
})


test_that("RT-162: k>1 diagonal fallback (chol failure) also stores M^{-1} = vars", {
  # The k>1 Cholesky-failure fallback is unreachable from real Welford data
  # (a PSD covariance plus the 1e-10 ridge is always PD), so exercise it with a
  # directly-constructed indefinite covariance: covMat = wM2/(wN-1) =
  # [[2, 5], [5, 0.5]] has a negative eigenvalue, so chol() fails even after the
  # ridge and .AdaptMassBlocks takes the diagonal fallback. Distinct diagonal
  # entries (2 and 0.5) make this a sign check too: the pre-fix fallback stored
  # 1/vars.
  blocks <- list(list(idx = c(1L, 2L), k = 2L,
                      cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                      wMean = c(0, 0), wM2 = c(4, 10, 10, 1), wN = 3L))
  adapted <- .AdaptMassBlocks(blocks)

  vars <- c(2, 0.5)   # diag(covMat)
  # M^{-1} (= invMat) = diag(vars); M (= cholMat cholMat^T) = diag(1/vars).
  expect_equal(adapted[[1]]$invMat, c(vars[1], 0, 0, vars[2]), tolerance = 1e-8)
  expect_equal(adapted[[1]]$cholMat, c(1/sqrt(vars[1]), 0, 0, 1/sqrt(vars[2])),
               tolerance = 1e-8)
})
