# #489: an MH iteration in which no proposal survives validation must still run
# the (beta, sigma, lambda) Gibbs sweep, refresh
# `logPost`/`logPostOld`/`logPostNew`, and set `proposalNumber`.  Before the fix
# it set only `accept`, so the iteration skipped the Gibbs block and
# `monitor.record()` billed it to the previous iteration's proposal slot.
#
# Same class as RT-380 (#420) and RT-380b (#454), which route through
# `no_proposal_self_transition()`.
#
# ARCHITECTURE NOTE (RT-381, PR #382).  #489 was originally about the
# `MAX_OUTER_RETRIES` bail-out, reached after 500 x 20 failed trials.  RT-381
# converted the three validity checks from redraw-on-failure to
# reject-on-failure, which deletes the retry loop and with it the bail-out: a
# single failed check is now one clean rejection that flows through the ordinary
# accept/reject branch.  #489's DEFECT IS THEREFORE STRUCTURALLY IMPOSSIBLE
# rather than fixed in place — but its invariants still need guarding, because
# the replacement path is the one every out-of-support proposal now takes.  Every
# assertion below is unchanged in intent; only the guard-fired discriminator had
# to move (see below).  If RT-381 is ever reverted, restore
# `no_proposal_self_transition()` on the bail-out and flip the two sentinel
# assertions back to `-Inf`.
#
# Trigger: bounded (uniform) metro priors plus a Univariate proposal whose SDs
# have been blown up to 1e12, so every draw lands outside the support and
# `check_prior_bounds()` rejects it.  All four coordinates move together under a
# Bactrian kernel, so the chance of a valid draw is ~1e-40; if one ever did
# survive the assertions below fail loudly rather than passing vacuously.
#
# Guard-fired discriminator: a proposal that passes validation is evaluated, so
# it leaves a finite `logPostNew` at its real log posterior.  One that fails
# validation is never evaluated and carries the `-1e30` out-of-support sentinel
# instead, so `logPostNew == RT381_SENTINEL` means the reject-not-redraw path
# ran.  (Pre-RT-381 the same role was played by `-Inf`, set by
# `no_proposal_self_transition()`.)  The control arm holds everything fixed but
# the SDs and records a finite, non-sentinel value.
RT381_SENTINEL <- -1e30

# ── Fixture ──────────────────────────────────────────────────────────────────

# Uniform metro priors (`stratModel1`'s are Normal, i.e. unbounded, so
# `check_prior_bounds()` can never reject); a short R chain then supplies an
# initialised `mcmc` and a valid state.  The same `model` drives the warm-up and
# the engine, so `.sb_eval_logpost()` is a valid oracle for the whole
# log posterior, not just its signal term.
.rt489_setup <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  bounds <- list(alpha_site_2 = c(-10, 10), alpha_site_3 = c(-10, 10),
                 gammaLog_site_2 = c(-3, 3), gammaLog_site_3 = c(-3, 3))
  priors <- stratModel1$priors$metro
  for (nm in names(priors))
    priors[[nm]] <- UniformPrior(bounds[[nm]][[1]], bounds[[nm]][[2]])

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = priors,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12),
    sigmaFixed = stratModel1$sigmaFixed)
  expect_identical(model$parametersLengthNotFixed, 4L)

  td <- file.path(tempdir(), paste0("rt489_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4200)
  RunStratModel(stratData1, model, nIter = 30, nChains = 1, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  list(data = stratData1, model = model, mcmc = mcmc,
       uni = which(names(mcmc$propose) == "Univariate"),
       mvn = which(names(mcmc$propose) == "Multivariate"))
}

# Put all proposal mass on one slot.
.rt489_pin <- function(mcmc, slot) {
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, slot] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  mcmc
}

# One iteration on the pinned slot.  `univSD` overrides the Univariate SDs:
# 1e12 puts every draw outside the support, 1e-3 keeps every draw inside it.
#
# RT-381 note: the control arm has to pin a SMALL SD rather than keep the
# adapted ones.  The adapted SDs (~4 on each alpha against bounds of [-10, 10],
# with all four coordinates jumping together) also leave the support at this
# seed — harmless pre-RT-381, when an invalid draw was retried until one was
# valid, but under reject-not-redraw that is itself a sentinel-carrying
# rejection, which would make the control indistinguishable from the test arm.
.rt489_one_iter <- function(s, slot, univSD = NULL, seed = 99L) {
  mcmc <- .rt489_pin(s$mcmc, slot)
  if (!is.null(univSD))
    mcmc[[c("metro", "proposalArgs")]][[1]]$Univariate <-
      rep(univSD, s$model$parametersLength)

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, mcmc$recentState)
  StratoBayes:::.sb_configure_monitor(
    eng, ncol(mcmc[[c("metro", "proposalProbability")]]))
  before <- StratoBayes:::.sb_extract_state(eng)[[1]]
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, 1L)
  after <- StratoBayes:::.sb_extract_state(eng)[[1]]

  # Independent oracle: rebuilds B/H/tBy from scratch through a full forward
  # pass, versus the engine's cached BtB/Bty.
  list(before = before, after = after,
       mon = StratoBayes:::.sb_get_monitor(eng),
       oracle = StratoBayes:::.sb_eval_logpost(
         eng, 1L, after$metro$parameters, marginal = TRUE))
}

# ── The no-valid-proposal iteration is a full self-transition ───────────────

test_that("#489: an all-invalid MH iteration runs the Gibbs sweep", {
  skip_on_cran()

  s <- .rt489_setup()
  r <- .rt489_one_iter(s, s$uni, univSD = 1e12)

  # Reject-not-redraw path fired: the proposal was never evaluated.
  expect_identical(r$after$metro$logPostNew, RT381_SENTINEL)

  # Recorded as a rejection; alignment untouched.
  expect_false(r$after$metro$accept)
  expect_equal(r$after$metro$parameters, r$before$metro$parameters)

  # (a) Gibbs block ran — pre-#489-fix these were bit-identical to `before`.
  expect_false(isTRUE(all.equal(r$before$gibbs$beta, r$after$gibbs$beta)))
  expect_false(isTRUE(all.equal(r$before$gibbs$lambda, r$after$gibbs$lambda)))

  # (b) log posteriors refreshed, and to the right value rather than merely a
  # changed one.  Pre-fix `logPost` was unchanged and logPostOld sat at 0.
  expect_false(isTRUE(all.equal(r$before$metro$logPost, r$after$metro$logPost)))
  expect_equal(r$after$metro$logPostOld, r$after$metro$logPost)
  expect_equal(r$after$metro$logPost, r$oracle, tolerance = 1e-10)

  # (c) the iteration claims the slot that was selected.  Pre-fix: 0.
  expect_identical(r$after$metro$proposalNumber, s$uni)

  # Control: the same slot, same seed, an SD small enough that the draw cannot
  # leave the support — a real MH transition, which evaluates the proposal and so
  # records its actual log posterior.  Without this the sentinel assertion above
  # would not distinguish a never-evaluated proposal from an ordinary rejection.
  # `is.finite` alone is NOT enough: the sentinel is finite too.
  ctrl <- .rt489_one_iter(s, s$uni, univSD = 1e-3)
  expect_true(is.finite(ctrl$after$metro$logPostNew))
  expect_false(identical(ctrl$after$metro$logPostNew, RT381_SENTINEL))
  expect_identical(ctrl$after$metro$proposalNumber, s$uni)
})

# ── proposalNumber: the wrinkle the HMC/NUTS sites did not have ──────────────

test_that("#489: an all-invalid MH iteration does not bill the previous slot", {
  skip_on_cran()

  s <- .rt489_setup()

  # Iteration 1 on Multivariate (unaffected by univariateSDs) completes a real
  # transition; iteration 2 switches to the broken Univariate slot and rejects
  # without evaluating.  Pre-fix the second iteration inherited `proposalNumber`
  # from the first, so the monitor scored Multivariate twice and Univariate
  # never.
  mcmc <- .rt489_pin(s$mcmc, s$mvn)
  mcmc[[c("metro", "proposalArgs")]][[1]]$Univariate <-
    rep(1e12, s$model$parametersLength)
  nProp <- ncol(mcmc[[c("metro", "proposalProbability")]])

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, mcmc$recentState)
  StratoBayes:::.sb_configure_monitor(eng, nProp)
  set.seed(99L)
  StratoBayes:::.sb_run_block(eng, 1L)
  expect_identical(StratoBayes:::.sb_extract_state(eng)[[1]]$metro$proposalNumber,
                   s$mvn)

  StratoBayes:::.sb_update_proposals(
    eng,
    mcmc[[c("metro", "proposalArgs")]],
    mcmc[[c("metro", "proposalFactor")]],
    .rt489_pin(mcmc, s$uni)[[c("metro", "proposalProbability")]])
  StratoBayes:::.sb_run_block(eng, 1L)

  after <- StratoBayes:::.sb_extract_state(eng)[[1]]
  expect_identical(after$metro$logPostNew, RT381_SENTINEL)  # invalid-draw path
  expect_identical(after$metro$proposalNumber, s$uni)

  counts <- StratoBayes:::.sb_get_monitor(eng)$proposalCount  # 1 chain x nProp
  expected <- matrix(0L, nrow = 1, ncol = nProp)
  expected[[1, s$mvn]] <- 1L
  expected[[1, s$uni]] <- 1L
  expect_equal(unname(counts), expected)
})
