
test_that("plot.StratPosterior throws errors", {
  expect_error(plot(stratPosterior1, alignment = 2),
               "`alignment`.* must consist of whole numbers between 1 and 1")

  expect_error(plot(stratPosterior1, iterations = 15000),
               "No iterations")

  expect_error(plot(stratPosterior1, sites = 4),
               "`sites` may contain")
})

test_that("plot.StratPosterior works with display = FALSE", {
  expect_error(plot(stratPosterior1, display = FALSE), NA)
})

test_that("plot.StratPosterior works - 1", {
  skip_if_not_snapshot_os()

  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 1", function() {
    parOri <- par()
    par(col = "darkgreen", bg = rgb(0.9, 0.8, 0.8, 1), cex = 0.8, lwd = 3,
        mfrow = c(2, 2))
    plot(stratPosterior1, overridePar = FALSE)
    plot(stratPosterior1, separateSites = FALSE, overridePar = FALSE)
    par(parOri[c("col", "bg", "cex", "lwd", "mfrow")])
  })})

test_that("plot.StratPosterior works - 3", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 3", function() {
    plot(stratPosterior2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 4", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 4", function() {
    plot(stratPosterior2, signal = 1:2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 5", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 5", function() {
    plot(stratPosterior2, signal = 2,
         colourBy =  "partition", col = 1:4)
  })})


test_that("plot.StratPosterior works - 6", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 6", function() {
    plot(stratPosterior2, iterations = 25:125, signal = 1:2)
  })
})

test_that("plot.StratPosterior works with depth data - 7", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior depth", function() {
    plot(stratPosterior3, type = "l", colourBy = "p")
  })
})

test_that("plot.StratPosterior works with custom parameters - 8", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 8", function() {
    plot(stratPosterior3, type = "l", colourBy = "p",
         parameters = c(-1, 2, -1, 0))
  })
})

test_that("plot.StratPosterior works with multi alignments in one plot - 9", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior multi", function() {
    plot(stratPosterior2, type = "l", colourBy = "s", alignment = 1:2)
  })
})

test_that("plot.StratPosterior works with overridePar = FALSE", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("plot posterior override", function() {
    set.seed(1)
    par(mfrow = c(3, 1))
    plot(stratPosterior1, overridePar = FALSE)
  })
})

test_that(
  "plot.StratPosterior works with new cluster object and iterations before burnIn",
  {
    skip_if_not_snapshot_os()
    set.seed(0)
    clustNew <- Cluster(stratPosterior1, iterations = 100:200)
    vdiffr::expect_doppelganger("plot posterior clustNew", function() {
      plot(stratPosterior1, colourBy = "site",
           stratCluster = clustNew, type = "o")
    })
  }
)

test_that("plot.stratPosterior produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  expect_error({plot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
  unlink(tmpFile)
})

test_that("plot.StratPosterior does not crash for explicit NULL dots args (RT-298/RT-299)", {
  tmpFile <- tempfile()
  png(filename = tmpFile)
  expect_no_error(plot(stratPosterior1, type = NULL))
  expect_no_error(plot(stratPosterior1, pch = NULL))
  dev.off()
  unlink(tmpFile)
})

test_that("plot.StratPosterior gives its own message for an NA embedded in `alignment` (RT-468)", {
  expect_error(plot(stratPosterior1, alignment = c(1, NA), display = FALSE),
               "`alignment` must not contain missing values")
})

test_that("plot.StratPosterior gives its own message for an NA embedded in `parameters` (RT-469)", {
  expect_error(
    plot(stratPosterior1, parameters = c(0.5, NA, 0.5, 0.5), display = FALSE),
    "`parameters` must not contain missing values"
  )
})

test_that("plot.StratPosterior rejects a non-finite xlim/ylim instead of a base R error (RT-470)", {
  expect_error(plot(stratPosterior1, xlim = c(0, NA), display = FALSE),
               "`xlim` must contain only finite values")
  expect_error(plot(stratPosterior1, ylim = c(0, Inf), display = FALSE),
               "`ylim` must contain only finite values")
})

test_that("plot.StratPosterior fixed knots: spline uses model ext_knots (not tight range(ages))", {
  skip_on_cran()
  set.seed(1)

  data(stratData1, stratModel1, package = "StratoBayes")

  model_fix <- StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-14, 32),
    nKnots = 8L
  )

  mc <- StratMCMC(
    stratModel = model_fix,
    nIter = 45L,
    nChains = 2L,
    nThreads = 2L,
    nThin = 5L,
    tempering = FALSE,
    adapt = FALSE
  )

  td <- tempfile("strat_plot_")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  post <- suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = model_fix,
      stratMCMC = mc,
      nRun = 1L,
      quiet = TRUE,
      visualise = FALSE,
      engine = "R",
      modelDir = td,
      modelName = "plot_fix_knot"
    )
  )
  expect_s3_class(post, "StratPosterior")

  pnames <- post$savedParameters
  metro1 <- as.numeric(post$samples[1, pnames, 1, 1])
  names(metro1) <- pnames

  ages <- StratoBayes:::.sb_age_convert(post$data, post$model$ind, metro1)[["signal"]]
  r_ages <- range(vapply(ages, range, numeric(2)))
  kr <- post$model$splineBase$knotRange
  expect_true(diff(kr) > diff(r_ages) * 1.05)

  sig <- 1L
  sn <- post$data$signalAttr$signalNames[sig]
  nb <- post$model$splineBase$num_basis
  betas <- paste0("beta_", sn, "_", seq_len(nb))
  expect_true(all(betas %in% pnames))
  b1 <- as.numeric(post$samples[1, betas, 1, 1])

  yPlot <- seq(r_ages[1], r_ages[2], length.out = 55)
  ext <- post$model$splineBase$ext_knots
  B_ok <- splines::splineDesign(ext, yPlot, sparse = FALSE)
  pred_ok <- as.numeric(StratoBayes:::.MatrixVectorMult(B_ok, b1))

  wrong <- StratoBayes:::.CreateSplineBaseBspline(
    post$data,
    post$model$splineBase$nKnots,
    r_ages[1],
    r_ages[2],
    NULL
  )
  B_bad <- splines::splineDesign(wrong$ext_knots, yPlot, sparse = FALSE)
  pred_bad <- as.numeric(StratoBayes:::.MatrixVectorMult(B_bad, b1))

  expect_gt(max(abs(pred_ok - pred_bad)), 1e-4)

  pl <- suppressMessages(
    suppressWarnings(
      plot(
        post,
        display = FALSE,
        burnIn = 0,
        maxSamples = 30L,
        alignment = 1L,
        signal = sig,
        separateSites = FALSE,
        overridePar = FALSE
      )
    )
  )
  expect_length(pl$spline$x, 300L)
  expect_length(pl$spline$y, 300L)
})

test_that("plot.StratPosterior flexibleKnots rebuild passes correct shape to .CreateSplineBaseBspline (RT-300)", {
  # Regression for RT-300: the flexibleKnots rebuild branch passed the whole
  # StratData object (result$data) as the first argument to
  # .CreateSplineBaseBspline(), which expects list(x=..., y=...) and does
  # range(data[["x"]], na.rm = TRUE). StratData has no top-level $x, so this
  # silently evaluated range(NULL, na.rm = TRUE) and emitted two spurious
  # "no non-missing arguments to min/max; returning Inf/-Inf" warnings on
  # every default plot(stratPosterior1) call (stratPosterior1's model has
  # flexibleKnots == TRUE, so this fires on the package's own first example).
  set.seed(1)
  expect_no_warning(plot(stratPosterior1, display = FALSE))
})

test_that("plot.StratPosterior does not crash for a valid but unmatched plot type", {
  png(filename = tempfile())
  set.seed(1)
  expect_no_error(plot(stratPosterior1, type = "h"))
  dev.off()
})

test_that("plot.StratPosterior passes each signal's own Gibbs hyperprior to BayesianSpline when `parameters` is supplied", {
  # Regression: with `parameters` supplied, plot.StratPosterior() re-fits a
  # BayesianSpline() per signal, but previously passed the *whole*
  # length-nSignal aSigma/bSigma/aLambda/bLambda vectors instead of the
  # current signal's own entry (StratModel.R subscripts these with
  # aLambda[sig] etc. at the equivalent call site). Give the two signals of
  # stratData2 distinguishable hyperpriors so a positional/vector mix-up
  # is observable.
  post <- stratPosterior2
  post[[c("model", "priors", "gibbs", "aSigma")]]  <- c(a = 0.01, b = 5)
  post[[c("model", "priors", "gibbs", "bSigma")]]  <- c(a = 0.01, b = 7)
  post[[c("model", "priors", "gibbs", "aLambda")]] <- c(a = 1,    b = 9)
  post[[c("model", "priors", "gibbs", "bLambda")]] <- c(a = 1000, b = 13)

  pars <- as.numeric(
    ExtractParameters(post, parameters = "all")[1, seq_len(post[[c("model", "parametersLength")]])]
  )

  realBayesianSpline <- BayesianSpline
  captured <- list()
  testthat::local_mocked_bindings(
    BayesianSpline = function(..., aSigma, bSigma, aLambda, bLambda) {
      captured[[length(captured) + 1]] <<- list(
        aSigma = aSigma, bSigma = bSigma, aLambda = aLambda, bLambda = bLambda
      )
      realBayesianSpline(..., aSigma = aSigma, bSigma = bSigma,
                          aLambda = aLambda, bLambda = bLambda)
    },
    .package = "StratoBayes"
  )

  set.seed(1)
  plot(post, signal = c("a", "b"), parameters = pars, display = FALSE)

  expect_length(captured, 2)
  expect_equal(captured[[1]][c("aSigma", "bSigma", "aLambda", "bLambda")],
               list(aSigma = 0.01, bSigma = 0.01, aLambda = 1, bLambda = 1000))
  expect_equal(captured[[2]][c("aSigma", "bSigma", "aLambda", "bLambda")],
               list(aSigma = 5, bSigma = 7, aLambda = 9, bLambda = 13))
})

test_that("plot.StratPosterior tolerates length>1 'type' (RT-507/#728)", {
  # a length-2 `type` made several `args[["type"]] == ...` comparisons
  # length-2 too, which errors under R >= 4.3's stricter `&&`/`||`
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  expect_no_error(plot(stratPosterior1, type = c("p", "l")))
})

test_that("plot.StratPosterior validates 'quantile' (RT-502/RT-503/#724)", {
  expect_error(plot(stratPosterior1, quantile = 1.5, display = FALSE),
               "'quantile' must be a single numeric value between 0 and 1")
  expect_error(plot(stratPosterior1, quantile = "0.5", display = FALSE),
               "'quantile' must be a single numeric value between 0 and 1")
  expect_error(plot(stratPosterior1, quantile = NA_real_, display = FALSE),
               "'quantile' must be a single numeric value between 0 and 1")
})

test_that("plot.StratPosterior no blank legend col, separateSites=F (#723)", {
  # a single panel (one signal, one alignment) draws its legend in the
  # panel's own margin (the singlePlotCell case), not a dedicated column
  captured <- NULL
  testthat::local_mocked_bindings(
    layout = function(mat, ...) {
      captured <<- mat
      invisible(1)
    }
  )
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  plot(stratPosterior1, separateSites = FALSE)
  expect_equal(ncol(captured), 1)
})
