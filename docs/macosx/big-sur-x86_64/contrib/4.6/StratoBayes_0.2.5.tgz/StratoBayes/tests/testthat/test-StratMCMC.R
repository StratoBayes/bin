test_that("stratModel must be a StratModel object (#82)", {
  expect_error(StratMCMC(stratModel = list(a = 1)), "StratModel")
  expect_error(StratMCMC(stratModel = stratData1), "StratModel")
})

test_that("bactrianM validation", {
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = -0.1),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = 1),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = "a"),
               "bactrianM")
  expect_error(StratMCMC(stratModel = stratModel1, bactrianM = c(0.5, 0.5)),
               "bactrianM")
  # Valid values should not error
  m0 <- StratMCMC(stratModel = stratModel1, bactrianM = 0)
  expect_equal(m0$metro$bactrianM, 0)
  m95 <- StratMCMC(stratModel = stratModel1, bactrianM = 0.95)
  expect_equal(m95$metro$bactrianM, 0.95)
})

test_that("StratMCMC parameter validation", {
  # writeMCMCfile: FALSE/0 (off) and values in (0, 1] are OK; outside that range errors
  m_off <- StratMCMC(stratModel = stratModel1, writeMCMCfile = FALSE)
  expect_identical(m_off$writeMCMCiterations, FALSE)
  m_off0 <- StratMCMC(stratModel = stratModel1, writeMCMCfile = 0)
  expect_identical(m_off0$writeMCMCiterations, FALSE)
  m_one <- StratMCMC(stratModel = stratModel1, writeMCMCfile = 1)
  expect_true(is.numeric(m_one$writeMCMCiterations))
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = 1.5),
               "writeMCMCfile")
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = -1),
               "writeMCMCfile")
  expect_error(StratMCMC(stratModel = stratModel1, writeMCMCfile = 2),
               "writeMCMCfile")

  # acceptanceHistoryLength: must be a positive integer
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 0),
               "acceptanceHistoryLength")
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = -1),
               "acceptanceHistoryLength")
  expect_error(StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 1.5),
               "acceptanceHistoryLength")
  m_ahl <- StratMCMC(stratModel = stratModel1, acceptanceHistoryLength = 10)
  expect_equal(m_ahl$metro$acceptanceLength, 10)

  # adaptTemperaturesIntervall: must be NULL or a positive integer
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 0),
               "adaptTemperaturesIntervall")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = -1),
               "adaptTemperaturesIntervall")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 10.5),
               "adaptTemperaturesIntervall")
  m_ati <- StratMCMC(stratModel = stratModel1, adaptTemperaturesIntervall = 10)
  expect_equal(m_ati$temper$adaptTemperaturesIntervall, 10)

  # startAdapting / endAdapting: must be NULL or positive integers (integer-ness only, RT-205)
  expect_error(StratMCMC(stratModel = stratModel1, startAdapting = 1.5),
               "startAdapting")
  expect_error(StratMCMC(stratModel = stratModel1, endAdapting = 1.5),
               "endAdapting")

  # RT-311: adaptProposalInterval must be NULL or a positive integer
  expect_error(StratMCMC(stratModel = stratModel1, adaptProposalInterval = 0),
               "adaptProposalInterval")
  expect_error(StratMCMC(stratModel = stratModel1, adaptProposalInterval = -1),
               "adaptProposalInterval")
  expect_error(StratMCMC(stratModel = stratModel1, adaptProposalInterval = NA),
               "adaptProposalInterval")
  expect_error(StratMCMC(stratModel = stratModel1, adaptProposalInterval = 10.5),
               "adaptProposalInterval")
  m_api <- StratMCMC(stratModel = stratModel1, adaptProposalInterval = 5)
  expect_equal(m_api$metro$adaptProposalInterval, 5)

  # RT-316: adaptTemperaturesDecay must be NULL or a non-negative finite numeric
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesDecay = -1),
               "adaptTemperaturesDecay")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesDecay = NA),
               "adaptTemperaturesDecay")
  expect_error(StratMCMC(stratModel = stratModel1, adaptTemperaturesDecay = Inf),
               "adaptTemperaturesDecay")
  m_atd <- StratMCMC(stratModel = stratModel1, adaptTemperaturesDecay = 2.5)
  expect_equal(m_atd$temper$adaptTemperaturesDecay, 2.5)

  # RT-312: clustWithParametersMCMC / onlyMultivariateProposalsAfterAdapt must be strict TRUE/FALSE
  expect_error(StratMCMC(stratModel = stratModel1, clustWithParametersMCMC = NA),
               "clustWithParametersMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, clustWithParametersMCMC = 1),
               "clustWithParametersMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, onlyMultivariateProposalsAfterAdapt = NA),
               "onlyMultivariateProposalsAfterAdapt")
  expect_error(StratMCMC(stratModel = stratModel1, onlyMultivariateProposalsAfterAdapt = 0),
               "onlyMultivariateProposalsAfterAdapt")

  # RT-314: nThreads must be a single non-negative integer
  expect_error(StratMCMC(stratModel = stratModel1, nThreads = c(2, 3)),
               "nThreads")
  m_nt <- StratMCMC(stratModel = stratModel1, nThreads = 2L)
  expect_equal(m_nt$nThreads, 2L)

  # RT-315: adapt must be NULL, TRUE, or FALSE
  expect_error(StratMCMC(stratModel = stratModel1, adapt = 1),
               "adapt")
  expect_error(StratMCMC(stratModel = stratModel1, adapt = "FALSE"),
               "adapt")
  expect_error(StratMCMC(stratModel = stratModel1, adapt = NA),
               "adapt")
  m_adapt <- StratMCMC(stratModel = stratModel1, adapt = FALSE)
  expect_false(m_adapt$temper$adaptTemperatures)
  expect_true(all(!m_adapt$metro$adaptProposal))

  # RT-317: alphaShift must be NULL or a single positive, finite numeric value
  expect_error(StratMCMC(stratModel = stratModel1, alphaShift = -1),
               "alphaShift")
  expect_error(StratMCMC(stratModel = stratModel1, alphaShift = 0),
               "alphaShift")
  expect_error(StratMCMC(stratModel = stratModel1, alphaShift = NA),
               "alphaShift")
  expect_error(StratMCMC(stratModel = stratModel1, alphaShift = "a"),
               "alphaShift")
  m_as <- StratMCMC(stratModel = stratModel1, alphaShift = 0.5)
  expect_equal(m_as$metro$alphaShift, 0.5)

  # RT-318: parametersInitial must be typed numeric, not a numeric-looking character vector
  nParam <- length(stratModel1[["parametersNames"]])
  expect_error(StratMCMC(stratModel = stratModel1,
                          parametersInitial = as.character(seq_len(nParam))),
               "parametersInitial")

  # RT-320: clustMaxMCMC / clustMinPtsMCMC / silCutOffMCMC / silOutlierThresholdMCMC
  expect_error(StratMCMC(stratModel = stratModel1, clustMaxMCMC = NA),
               "clustMaxMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, clustMaxMCMC = 1),
               "clustMaxMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, clustMaxMCMC = 2.5),
               "clustMaxMCMC")
  m_cmax <- StratMCMC(stratModel = stratModel1, clustMaxMCMC = 5)
  expect_equal(m_cmax$metro$clustMaxMCMC, 5)

  expect_error(StratMCMC(stratModel = stratModel1, clustMinPtsMCMC = NA),
               "clustMinPtsMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, clustMinPtsMCMC = 2),
               "clustMinPtsMCMC")
  m_cmin <- StratMCMC(stratModel = stratModel1, clustMinPtsMCMC = 4)
  expect_equal(m_cmin$metro$clustMinPtsMCMC, 4)

  expect_error(StratMCMC(stratModel = stratModel1, silCutOffMCMC = NA),
               "silCutOffMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, silCutOffMCMC = 1.5),
               "silCutOffMCMC")
  m_sco <- StratMCMC(stratModel = stratModel1, silCutOffMCMC = 0.7)
  expect_equal(m_sco$metro$silCutOff, 0.7)

  expect_error(StratMCMC(stratModel = stratModel1, silOutlierThresholdMCMC = NA),
               "silOutlierThresholdMCMC")
  expect_error(StratMCMC(stratModel = stratModel1, silOutlierThresholdMCMC = "a"),
               "silOutlierThresholdMCMC")
  m_sot <- StratMCMC(stratModel = stratModel1, silOutlierThresholdMCMC = 0.2)
  expect_equal(m_sot$metro$silOutlierThreshold, 0.2)
})

test_that("StratMCMC methods work", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratMCMC1))

  expect_equal(.PrettyNumber(NULL), numeric(0))
  expect_equal(.PrettyNumber(1 / 3), 0.333)
  expect_snapshot(summary(stratMCMC1))

  # print mcmc from run with completed iterations
  stratMCMC1$completedIter <- 100
  expect_snapshot(print(stratMCMC1))

  # check that summary.StratMCMC produces valid output
  output <- utils::capture.output(summary.StratMCMC(stratMCMC1))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Probability", output[[4]])))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Multivariate", output[[6]])))
  expect_true(any(grepl("4", output[[6]])))

})

test_that("RT-206: endAdapting is capped at nIter so kept samples are post-adaptation", {
  # Regression for RT-206. A user-supplied `endAdapting > nIter` used to be
  # stored uncapped, leaving the adaptation condition `i <= endAdapting` TRUE
  # for the entire run: proposal + temperature adaptation kept firing to the
  # last iteration and every "post-adaptation" sample was actually drawn under
  # a still-adapting (non-Markov) kernel. `StratMCMC()` now caps the stored
  # value at `endIter` (equivalent to capping user `endAdapting` at `nIter`)
  # and warns.
  #
  # Review findings (verified against source): the cap arithmetic is exact for
  # both new and continued runs -- the `startIter - 1` offset makes `endIter`
  # the correct bound and `completedIter` cancels; the strict `>` preserves the
  # legal `endAdapting == nIter` boundary; and this is the only path that can
  # produce `endAdapting > endIter`. Reader caveat: capping `nIter+1 -> nIter`
  # does NOT turn kept samples into post-adaptation draws -- both are pure
  # warm-ups with zero post-adapt samples; the cap's value is the warning plus
  # keeping stored `endAdapting` inside `[startIter, endIter]`. Cases (d)/(e)
  # add continued-run coverage -- exactly where the offset could hide an
  # off-by-one.

  # Records whether the specific RT-206 warning is emitted while forcing `expr`.
  rt206WarningFired <- function(expr) {
    fired <- FALSE
    withCallingHandlers(
      force(expr),
      warning = function(w) {
        if (grepl("endAdapting", conditionMessage(w)) &&
            grepl("exceeds", conditionMessage(w))) {
          fired <<- TRUE
        }
        invokeRestart("muffleWarning")
      }
    )
    fired
  }

  # (a) Bug case: endAdapting one past the end. Warning fires and the stored
  #     value is pulled back to exactly endIter (not endIter + 1).
  expect_warning(
    mBug <- StratMCMC(stratModel = stratModel1, nIter = 100,
                      endAdapting = 101, nThreads = 2L),
    "endAdapting.*exceeds"
  )
  expect_equal(mBug[["endAdapting"]], mBug[["endIter"]])
  expect_equal(mBug[["endAdapting"]], 100)  # new run: endIter == nIter

  # (b) Boundary case: endAdapting == nIter is a legal request (adapt right up
  #     to the final iteration, zero post-adaptation samples). It must NOT be
  #     warned or altered, and adaptation must end exactly at the last
  #     iteration (endIter) -- not one-before, not one-past.
  mBoundary <- NULL
  expect_false(rt206WarningFired(
    mBoundary <- StratMCMC(stratModel = stratModel1, nIter = 100,
                           endAdapting = 100, nThreads = 2L)
  ))
  expect_equal(mBoundary[["endAdapting"]], mBoundary[["endIter"]])
  expect_equal(mBoundary[["endAdapting"]], 100)

  # (c) Normal in-range usage is completely unaffected: no warning, stored value
  #     equals the user request offset by (startIter - 1), which is 0 for a new
  #     run.
  mInRange <- NULL
  expect_false(rt206WarningFired(
    mInRange <- StratMCMC(stratModel = stratModel1, nIter = 100,
                          endAdapting = 40, nThreads = 2L)
  ))
  expect_equal(mInRange[["endAdapting"]], 40)  # 40 + startIter(1) - 1
  expect_true(mInRange[["endAdapting"]] < mInRange[["endIter"]])

  # (d) Continued run: the cap must respect the `startIter - 1` offset, so the
  #     bound is `endIter` (= completedIter + nIter), NOT a naive `nIter`.
  #     Continue a 100-iteration run for another 100 (completedIter = 100,
  #     startIter = 101, endIter = 200). `endAdapting` one past THIS run's
  #     length (101) must warn and be pulled to endIter == 200 -- a naive `nIter`
  #     cap would wrongly store 100. This is the case an off-by-one would break.
  mPrior <- StratMCMC(stratModel = stratModel1, nIter = 100, nThreads = 2L)
  expect_warning(
    mBugCont <- StratMCMC(stratModel = stratModel1, stratMCMC = mPrior,
                          completedIter = 100, nIter = 100, endAdapting = 101,
                          nThreads = 2L),
    "endAdapting.*exceeds"
  )
  expect_equal(mBugCont[["endIter"]], 200)  # completedIter(100) + nIter(100)
  expect_equal(mBugCont[["endAdapting"]], mBugCont[["endIter"]])
  expect_equal(mBugCont[["endAdapting"]], 200)  # capped to endIter, not nIter

  # (e) Continued-run boundary: endAdapting == nIter (100) is legal for a
  #     continued run too -- stored as endIter (200) and left un-warned.
  mBoundaryCont <- NULL
  expect_false(rt206WarningFired(
    mBoundaryCont <- StratMCMC(stratModel = stratModel1, stratMCMC = mPrior,
                               completedIter = 100, nIter = 100,
                               endAdapting = 100, nThreads = 2L)
  ))
  expect_equal(mBoundaryCont[["endAdapting"]], mBoundaryCont[["endIter"]])
  expect_equal(mBoundaryCont[["endAdapting"]], 200)
})

test_that("saveChains must contain the cold chain (RT-759)", {
  # Convergence stopping and the adaptation timer both pick the cold chain out
  # of the flushed samples by value, so a set without chain 1 disables both
  # with no message at all. The direct argument is already refused; a
  # continuation takes `saveChains` from the template instead, overriding that
  # check.
  expect_error(StratMCMC(stratModel1, nIter = 100, nChains = 3, saveChains = 2),
               "must be an integer containing at least the number")

  template <- StratMCMC(stratModel1, nIter = 100, nChains = 3,
                        saveChains = c(1, 2), nThreads = 2L)
  template[["saveChains"]] <- 2
  expect_error(StratMCMC(stratModel1, stratMCMC = template,
                         completedIter = 100, nIter = 100, nThreads = 2L),
               "must contain the number")
})

test_that("timeLimit is not a StratMCMC argument (RT-319)", {
  # StratMCMC() previously accepted a `timeLimit` argument that had no effect
  # whatsoever. It has been removed; time limiting is applied only by
  # RunStratModel().
  expect_error(
    StratMCMC(stratModel = stratModel1, timeLimit = 0.5),
    "unused argument"
  )
})
