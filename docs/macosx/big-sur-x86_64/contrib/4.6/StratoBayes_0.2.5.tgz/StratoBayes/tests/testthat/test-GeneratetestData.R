test_that(".GenerateTestData generates valid data", {
testData <- .GenerateTestData("multi", "gap-3-sites-dates-longer")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("a", "b"))
expect_s3_class(stratD, "StratData")
expect_equal(stratD[["S"]], 3)
expect_true(nrow(testData$signal) > 0)

testData <- .GenerateTestData("single", "1c")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")
expect_true(nrow(testData$signal) > 0)

testData <- .GenerateTestData("single", "2")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")
expect_true(nrow(testData$signal) > 0)

testData <- .GenerateTestData("single", "4")
stratD <- StratData(testData$signal, testData$ties, testData$parts,
                    signalColumn = c("value"))
expect_s3_class(stratD, "StratData")
expect_true(nrow(testData$signal) > 0)
expect_true(nrow(testData$parts) > 0)

})
