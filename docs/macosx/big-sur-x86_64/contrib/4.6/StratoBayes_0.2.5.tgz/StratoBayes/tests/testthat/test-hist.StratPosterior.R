test_that("hist.StratPosterior works", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("hist 1", function() {
    hist(stratPosterior1)
  })})

test_that("hist.StratPosterior works with colour for prior", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("hist 2", function() {
    hist(stratPosterior1, prior = rgb(0,.5,.8,.3), alignment = 1,
         iterations = 4000:5000)
  })})

test_that("hist.StratPosterior works colourBy = 'none'", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("hist 3", function() {
    hist(stratPosterior1, colourBy = "none")
  })})

test_that("hist.StratPosterior works colourBy = 'run'", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("hist 4", function() {
    hist(stratPosterior1, colourBy = "run")
  })})

test_that("hist.StratPosterior works with three parameters", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("hist 5", function() {
    hist(stratPosterior1, parameters = "parameters")
  })})


  test_that("hist.StratPosterior works without Prior", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 6", function() {
      hist(stratPosterior1, prior = F, parameters = c("posterior", 2), colourBy = "run",
           colourScale = "Plasma", burnIn = .9)
    })})

  test_that("hist.StratPosterior works without Prior 2", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 7", function() {
      hist(stratPosterior2, prior = F, freq = T,
           parameters = c(3, "prior"), colourBy = "none",
           ylab = "something else", col = "dodgerblue")
    })})

  test_that("hist.StratPosterior works with three parameters", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 8", function() {
      hist(stratPosterior2, colourBy = "alignment")
    })})

  test_that("hist.StratPosterior works with fixed parameter - run", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 9", function() {
      hist(stratPosterior3, colourBy = "run", parameters = 2:1)
    })})

  test_that("hist.StratPosterior works with fixed parameter - alignment", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 10", function() {
      hist(stratPosterior3, colourBy = "alignment", parameters = 2)
    })})

  test_that("hist.StratPosterior works with fixed parameter - none", {
    skip_if_not_snapshot_os()
    vdiffr::expect_doppelganger("hist 11", function() {
      hist(stratPosterior3, colourBy = "none", parameters = 1:3)
    })})

  test_that("hist.StratPosterior works with new cluster object and
          iterations before burnIn", {
            skip_if_not_snapshot_os()
            set.seed(12)
            clustNew <- Cluster(stratPosterior1, iterations = 100:200)

            vdiffr::expect_doppelganger("hist 12", function() {
              hist(stratPosterior1, colourBy = "alignment",
                          stratCluster = clustNew, type = "o")
            })})


  test_that("hist.StratPosterior produces margin error message", {
    png(filename = tempfile(), width = 50, height = 50)
    expect_error({hist(stratPosterior2, colourBy = "al")},
                 regexp = "The plot window is too small for the specified margins")
    dev.off()
  })

  test_that("hist.StratPosterior rejects NA `breaks` instead of passing it to hist() unvalidated (RT-479)", {
    # is.numeric(NA) is FALSE, so a bare NA fell through to the `else` branch
    # of `myBreaks <- if (is.numeric(breaks) ...)` and reached base hist()
    # with no package-authored message
    expect_error(hist(stratPosterior1, breaks = NA, display = FALSE),
                 "`breaks` must not contain missing values")
    expect_error(hist(stratPosterior1, breaks = NA_real_, display = FALSE),
                 "`breaks` must not contain missing values")
  })

  test_that("hist.StratPosterior accepts a function `breaks` and rejects breaks = 0 with a clear message (RT-607)", {
    # anyNA(breaks) errored on a closure input before this fix; breaks = 0
    # reached seq(length.out = 0) and base hist()'s opaque "character(0)"
    expect_no_error(hist(stratPosterior1, breaks = nclass.Sturges, display = FALSE))
    expect_error(hist(stratPosterior1, breaks = 0, display = FALSE),
                 "`breaks` must be at least 2")
  })

  test_that("hist.StratPosterior validates `colourBy` before branching on it (RT-611)", {
    # colourBy = "align" (a legal pmatch-able partial) was compared against
    # the literal "alignment" *before* .ValidateColourBy() ran, so it took
    # the ExtractIterations() path even when a pre-built `stratCluster` (with
    # its own rowIndex) was supplied - unlike the fully-spelled "alignment".
    # Confirm both spellings now take the same (stratCluster-reuse) path.
    sc <- Cluster(stratPosterior2)
    origExtractIterations <- StratoBayes::ExtractIterations
    calls <- 0
    testthat::local_mocked_bindings(
      ExtractIterations = function(...) {
        calls <<- calls + 1
        origExtractIterations(...)
      },
      .package = "StratoBayes"
    )
    invisible(hist(stratPosterior2, colourBy = "align", stratCluster = sc,
                   display = FALSE))
    expect_equal(calls, 0)
  })

  test_that("hist.StratPosterior returns the computed histogram (not just x/args/breaks) when display = TRUE, with a correct per-parameter xname (RT-610)", {
    pdf(NULL)
    on.exit(dev.off(), add = TRUE)

    out <- hist(stratPosterior1, colourBy = "none", parameters = 1:2, display = TRUE)
    expect_true(all(c("counts", "density", "mids") %fin% names(out[[1]])))
    expect_true(all(c("counts", "density", "mids") %fin% names(out[[2]])))
    expect_equal(out[[1]][["xname"]], names(hist(stratPosterior1, colourBy = "none",
                                                  parameters = 1, display = FALSE)[[1]][["x"]]))
    expect_false(identical(out[[1]][["xname"]], out[[2]][["xname"]]))
  })

  test_that("hist.StratPosterior's `border` argument actually reaches the plot() call for every colourBy branch (#708)", {
    # display = FALSE never reaches the plot() call at all, so testing only
    # that path (as an earlier version of this test did) can't catch
    # .ExtractRelevantArgs(argsTemp, "plot.default") silently stripping
    # `border` back out again before the do.call(plot, ...) below it - it
    # isn't a plot.default/plot.window/title/par() formal.
    pdf(NULL)
    on.exit(dev.off(), add = TRUE)

    capturedBorder <- character()
    originalPlotHistogramObject <- StratoBayes:::.PlotHistogramObject
    testthat::local_mocked_bindings(
      .PlotHistogramObject = function(x, args) {
        border <- args[["border"]]
        if (!is.null(border)) capturedBorder <<- c(capturedBorder, border)
        originalPlotHistogramObject(x, args)
      },
      .package = "StratoBayes"
    )

    for (cb in c("none", "run", "alignment")) {
      capturedBorder <- character()
      invisible(hist(stratPosterior1, colourBy = cb, border = "red",
                     display = TRUE))
      expect_true("red" %fin% capturedBorder)
    }

    # an unsupplied border still falls back to the smart NA/colourPrior
    # default rather than leaking a stale "red" from a prior call
    capturedBorder <- character()
    invisible(hist(stratPosterior1, colourBy = "none", display = TRUE))
    expect_false("red" %fin% capturedBorder)
  })

  test_that("hist.StratPosterior's `border` does not leak into the legend's own border (#708)", {
    # `border` is a formal of legend() (unlike plot.default), so folding it
    # into the shared `args` list for the plot call also handed it to
    # .ExtractRelevantArgs(args, "legend") unless explicitly scrubbed
    pdf(NULL)
    on.exit(dev.off(), add = TRUE)

    capturedLegendBorder <- "unset"
    testthat::local_mocked_bindings(
      legend = function(...) {
        capturedLegendBorder <<- list(...)[["border"]]
        invisible(NULL)
      },
      .package = "StratoBayes"
    )

    invisible(hist(stratPosterior1, colourBy = "run", border = "red",
                   display = TRUE))
    expect_null(capturedLegendBorder)
  })

  test_that("hist.StratPosterior reserves legend margin using cex.lab, matching what the legend is drawn with (RT-608)", {
    capturedCex <- NULL
    testthat::local_mocked_bindings(
      .EstimateLegendWidth = function(labels, cex = 1) {
        capturedCex <<- cex
        6
      },
      .package = "StratoBayes"
    )
    pdf(NULL)
    on.exit(dev.off(), add = TRUE)
    invisible(hist(stratPosterior1, colourBy = "run", cex.lab = 3))
    expect_equal(capturedCex, 3)
  })

  test_that("hist.StratPosterior validates maxSamples instead of crashing inside .maxSampleDeterministicRows (RT-606)", {
    expect_error(hist(stratPosterior1, maxSamples = NA, display = FALSE),
                 "`maxSamples`")
    expect_error(hist(stratPosterior1, maxSamples = -5, display = FALSE),
                 "`maxSamples`")
  })

  test_that("hist.StratPosterior validates `alignment` before dereferencing it (RT-604)", {
    expect_error(hist(stratPosterior1, alignment = NULL, display = FALSE),
                 "`alignment` cannot be NULL")
    expect_error(hist(stratPosterior1, alignment = character(0), display = FALSE),
                 "`alignment` cannot be an empty vector")
    expect_error(hist(stratPosterior1, alignment = NA, display = FALSE),
                 "`alignment` must not contain missing values")
  })

  test_that("hist.StratPosterior attributes samples to the correct alignment
          cluster for non-ascending runs (RT-303)", {
            # Before the fix, `alignmentsSelected` was built in runSelect
            # (user-input) order c(3, 1) while `metroPar` (from
            # ExtractParameters(), called without `runs`) is always laid out
            # in ascending run-number order (run 1's rows, then run 3's) --
            # silently swapping cluster labels between the two runs. Capture
            # the per-cluster sample vectors reaching the internal `hist()`
            # call (the last step before the plot) rather than tracing
            # hist.StratPosterior directly, since trace()-ing that S3 method
            # stops firing once any earlier hist() call in the test run has
            # already gone through generic dispatch (same inline-caching
            # pitfall documented in test-StratMapPlot.R for plot()).
            sc <- Cluster(stratPosterior2, runs = c(3, 1))

            capturedX <- list()
            originalHist <- graphics::hist
            testthat::local_mocked_bindings(
              hist = function(x, ...) {
                capturedX[[length(capturedX) + 1]] <<- x
                originalHist(x, ...)
              },
              .package = "StratoBayes"
            )

            invisible(hist(stratPosterior2, runs = c(3, 1), colourBy = "alignment",
                           parameters = 1, stratCluster = sc, display = FALSE))

            # drop the top-level dispatch call to hist.StratPosterior itself
            # (x = the StratPosterior object), keeping only the per-cluster
            # numeric-vector calls
            perClusterX <- Filter(is.numeric, capturedX)

            truthForClust <- function(cl) {
              rows1 <- sc[["rowIndex"]][[1]][sc[["clusterList"]][[1]] == cl]
              rows3 <- sc[["rowIndex"]][[3]][sc[["clusterList"]][[3]] == cl]
              v1 <- if (length(rows1)) {
                ExtractParameters(stratPosterior2, parameters = 1, runs = 1,
                                   selectRows = list(rows1))[, 1]
              } else numeric(0)
              v3 <- if (length(rows3)) {
                ExtractParameters(stratPosterior2, parameters = 1, runs = 3,
                                   selectRows = list(rows3))[, 1]
              } else numeric(0)
              sort(c(v1, v3))
            }

            # ascending cluster order 0, 1, 2 (a cluster-0/outlier sample is
            # present in run 3 of this fixture)
            expect_equal(length(perClusterX), 3)
            expect_equal(sort(perClusterX[[1]]), truthForClust(0))
            expect_equal(sort(perClusterX[[2]]), truthForClust(1))
            expect_equal(sort(perClusterX[[3]]), truthForClust(2))
          })

test_that("hist.StratPosterior does not crash for explicit NULL dots args (RT-299)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_no_error(hist(stratPosterior1, pch = NULL))
})
