test_that("Traceplots works", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("traceplot 1", function() {
    TracePlot(stratPosterior1)
  })})

test_that("Traceplots works with alignment", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 2", function() {
    set.seed(2)
    cluster <- Cluster(stratPosterior1, clusterMethod = "hdbscan")
    TracePlot(stratPosterior1, stratCluster = cluster, colourBy = "alignment",
              type = "o", alpha = 1, colourScale = "Warm", pch = 1:25,
              alignment = seq_len(min(c(3,cluster$nClust))))
  })
})

test_that("Traceplots works with different parameter", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 3", function() {
    TracePlot(stratPosterior2, parameters = c("lambda", 3),
              alignment = 1:2, iterations = 4000:5000,
              type = "o")
  })
})

test_that("Traceplots works with likelihood parameter", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 4", function() {
    TracePlot(stratPosterior2, parameters = c("likelihood"),
              iterations = 3000:4000, colourBy = "none",
              runs = 3, type = "o")
  })
})

test_that("Traceplots works with selecting iter and run", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("traceplot 4b", function() {
    TracePlot(stratPosterior2, parameters = c("likelihood"),
             iterations = list(NULL, NULL, 3000:4000, NULL),
              colourBy = "run", type = "o")
  })
})

test_that(".PlotSegmentedLines fails when given different lengths", {
 expect_error(.PlotSegmentedLines(1:2, 2:3, 3:5, c("black"), NULL),
              "The length")
})

test_that("TracePlot produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  on.exit(unlink(tmpFile))
  expect_error(TracePlot(stratPosterior1),
               "The plot window is too small for the specified margins")
  dev.off()
})

test_that("TracePlot works with new cluster object and iterations before burnIn", {
  skip_if_not_snapshot_os()
  set.seed(5)
  clustNew <- Cluster(stratPosterior1, iterations = 100:200)

  vdiffr::expect_doppelganger("traceplot 5", function() {
    TracePlot(stratPosterior1, colourBy = "alignment",
              stratCluster = clustNew, type = "o")
  })
})

test_that("TracePlot errors clearly when a custom stratCluster yields all-empty rows (RT-139)", {
  # When a custom stratCluster bypasses ExtractIterations and every run has
  # zero rows, `runSelect` used to become integer(0), and downstream code
  # accessed `plotIter[[runSelect[1]]]` (`runSelect[1]` == NA) -> subscript
  # error, instead of a readable message.
  nRun <- stratPosterior1[["nRun"]]
  emptyCluster <- list(rowIndex = replicate(nRun, integer(0), simplify = FALSE))

  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(
    TracePlot(stratPosterior1, stratCluster = emptyCluster, colourBy = "alignment"),
    "No iterations available to plot"
  )
})

test_that("TracePlot does not crash for explicit NULL dots args (RT-297/298/299)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_no_error(TracePlot(stratPosterior1, type = NULL))
  expect_no_error(TracePlot(stratPosterior1, pch = NULL))
})

test_that("TracePlot accepts every documented `type` value and rejects unrecognised ones (RT-603)", {
  # the legend switch() had no default arm, so type = "b"/"s"/"h"/"n" crashed
  # with "argument is missing, with no default" even though these are
  # documented (matching base plot()/lines()) values
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  for (ty in c("p", "l", "o", "b", "c", "s", "S", "h", "n")) {
    expect_no_error(TracePlot(stratPosterior1, type = ty))
  }
  expect_error(TracePlot(stratPosterior1, type = "zz"), "Invalid `type`")
})

test_that("TracePlot validates `type` even when no legend is drawn (RT-603)", {
  # the stop() for an invalid type used to live inside the
  # `if (addLegend && ...)` block, nested inside `if (isTRUE(display))` -
  # so colourBy = "none" (no legend) or display = FALSE let a bad type
  # through silently instead of erroring
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(TracePlot(stratPosterior1, type = "zz", colourBy = "none"),
               "Invalid `type`")
  expect_error(TracePlot(stratPosterior1, type = "zz", display = FALSE),
               "Invalid `type`")
  expect_error(TracePlot(stratPosterior1, type = c("p", "l")),
               "Invalid `type`")
})

test_that("TracePlot's legend correctly shows both line and point for type = 'b' (RT-603)", {
  # the point-drawing block overwrites tempArgs[["type"]] to "p" for "o"/"b"
  # before the legend switch reads it, so it always fell into the "p" arm
  # (points only) - dropping the line entry from the legend for "b"/"o"
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  capturedLwd <- "unset"
  testthat::local_mocked_bindings(
    legend = function(...) {
      capturedLwd <<- list(...)[["lwd"]]
      invisible(NULL)
    },
    .package = "StratoBayes"
  )
  invisible(TracePlot(stratPosterior1, type = "b", colourBy = "run"))
  expect_false(identical(capturedLwd, "unset"))
  expect_false(anyNA(capturedLwd))
})

test_that("TracePlot validates `alignment` before dereferencing it (RT-604)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(TracePlot(stratPosterior1, alignment = NULL),
               "`alignment` cannot be NULL")
  expect_error(TracePlot(stratPosterior1, alignment = character(0)),
               "`alignment` cannot be an empty vector")
  expect_error(TracePlot(stratPosterior1, alignment = NA),
               "`alignment` must not contain missing values")
})

test_that("TracePlot validates maxSamples instead of crashing inside .maxSampleDeterministicRows (RT-606)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(TracePlot(stratPosterior1, maxSamples = NA), "`maxSamples`")
  expect_error(TracePlot(stratPosterior1, maxSamples = -5), "`maxSamples`")
})
