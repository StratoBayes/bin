# The monotonic clock behind every interval the package measures for itself.

test_that(".sb_steady_seconds is monotone and reads in seconds", {
  first <- .sb_steady_seconds()
  expect_type(first, "double")
  expect_length(first, 1L)

  ticks <- replicate(1000, .sb_steady_seconds())
  # Monotone by contract, which is the whole reason for preferring it to
  # `Sys.time()`: a clock correction cannot make an interval negative.
  expect_true(all(diff(ticks) >= 0))
  # And finer than its own call cost, which `proc.time()` is not.
  expect_gt(length(unique(ticks)), 500)

  before <- .sb_steady_seconds()
  Sys.sleep(0.2)
  elapsed <- .sb_steady_seconds() - before
  expect_gt(elapsed, 0.1)
  expect_lt(elapsed, 5)
})
