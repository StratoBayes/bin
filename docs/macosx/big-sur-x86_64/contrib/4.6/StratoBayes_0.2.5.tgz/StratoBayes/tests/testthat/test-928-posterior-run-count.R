# Regression tests for #928 (RT-734): a model directory whose sample files and
# `_mcmc_run_*.rds` checkpoints cover different runs must be refused, not
# compiled into a posterior whose `nRun` exceeds the runs its `samples` array
# holds.
#
# Fixtures come from helper-posterior-fixtures.R; structural assertions only.

test_that("#928: metadata for a run with no samples is refused", {
  # Run 2 keeps `mC_mcmc_run_2.rds` but loses `mC_binarysamples_run_2.rds`, so
  # `.CompileSamplesAfterMCMC()`'s RDS fast path compiles a one-run array while
  # `.ReadMCMC()` reports two runs. Pre-fix that gave `nRun = 2` over a
  # one-slice array: `print()` reported per-run sample counts that did not
  # multiply out, and `summary()` died on "subscript out of bounds".
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(),
                                  damage = "drop-binary-run2")

  err <- expect_error(suppressMessages(StratPosterior(dir, modelName = "mC")))
  msg <- conditionMessage(err)

  expect_match(msg, "metadata for 2 run\\(s\\) but samples for 1")
  # The run numbers each file family covers, so the absent file is nameable
  # from the message alone. Matched up to the line break, so "1" cannot pass
  # against a listed "1, 2".
  expect_match(msg, "_mcmc_run_*.rds: 1, 2\n", fixed = TRUE)
  expect_match(msg, "_binarysamples_run_*.rds: 1\n", fixed = TRUE)
  expect_false(grepl("subscript out of bounds", msg, fixed = TRUE))
})

test_that("#928: the run-count guard also covers the TSV branch", {
  # `binary = FALSE` drops the `_binarysamples_*.rds` fast path for both runs,
  # so `.CompileSamplesAfterMCMC()` reads `_samples_run_*.txt`. Without this
  # case the guard was pinned only where the RDS files exist.
  dir <- .PosteriorFixtureCombine(2, 2, envir = environment(), binary = FALSE,
                                  damage = "drop-samples-run2")
  expect_length(list.files(dir, pattern = "binarysamples"), 0)

  err <- expect_error(suppressMessages(StratPosterior(dir, modelName = "mC")))
  msg <- conditionMessage(err)

  expect_match(msg, "metadata for 2 run\\(s\\) but samples for 1")
  expect_match(msg, "_mcmc_run_*.rds: 1, 2\n", fixed = TRUE)
  # The TSV family is the short one here, and the RDS family is reported
  # absent rather than silently omitted.
  expect_match(msg, "_samples_run_*.txt: 1\n", fixed = TRUE)
  expect_match(msg, "_binarysamples_run_*.rds: none\n", fixed = TRUE)
})

test_that("#928: an intact directory compiles, with a self-consistent nRun", {
  post <- .PosteriorFixtureCombine(2, 2, envir = environment())

  expect_equal(post[["nRun"]], 2)
  expect_equal(post[["nRun"]], dim(post[["samples"]])[[3]])
  # Both per-run field families: `saveIter` is built against the samples
  # array, `nIter` against the checkpoints.
  expect_equal(length(post[[c("mcmcSummary", "saveIter")]]), 2)
  expect_equal(length(post[[c("mcmcSummary", "nIter")]]), 2)
  expect_equal(length(post[[c("mcmcSummary", "completedIter")]]), 2)

  smry <- suppressMessages(suppressWarnings(summary(post, runs = 1:2)))
  expect_equal(smry[[c("general", "nRun")]], 2)
})
