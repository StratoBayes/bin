# Shared by test-mv-temp-scaling.R and test-rt132-cluster-covariance-guard.R.
#
# `.UpdateProposal` is this package's own internal, so a build where it is
# missing is a rename, not an unavailable resource -- these tests must fail,
# not skip. `inherits = FALSE` matters: with the default the lookup escapes the
# namespace and can resolve to an attached `package:StratoBayes` copy that
# `get()` would not have returned.
.GetUpdateProposal <- function() {
  ns <- loadNamespace("StratoBayes")
  testthat::expect_true(
    exists(".UpdateProposal", envir = ns, mode = "function", inherits = FALSE),
    info = ".UpdateProposal missing from the StratoBayes namespace")
  get(".UpdateProposal", envir = ns, mode = "function", inherits = FALSE)
}
