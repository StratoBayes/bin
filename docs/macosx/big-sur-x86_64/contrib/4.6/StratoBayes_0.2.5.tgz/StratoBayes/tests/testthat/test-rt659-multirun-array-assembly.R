# Regression tests for RT-659 (#840): two array-assembly hazards in the
# multi-run compilation path.

test_that(".CompileSamplesAfterMCMC's binary RDS fast path does not mislabel
          runs after a run number gap (RT-659 defect 1)", {
  modelDir <- withr::local_tempdir()
  modelName <- "rt659a"
  paramNames <- "p1"

  # Simulate a parallel crash-then-salvage scenario: run 1's worker died
  # before checkpointing a binarysamples RDS, while runs 2 and 3 succeeded.
  # `saveChainsList` reflects all 3 planned runs, as it does when built from
  # `mcmc` (one element per run regardless of whether it completed).
  saveChainsList <- list(1L, 1L, 1L)

  for (run in c(2L, 3L)) {
    mat <- cbind(iteration = 1, chain = 1, p1 = run)
    colnames(mat) <- c("iteration", "chain", paramNames)
    saveRDS(mat, file.path(modelDir,
                           paste0(modelName, "_binarysamples_run_", run, ".rds")))
  }

  model <- list(outputParams = paramNames)
  compiled <- StratoBayes:::.CompileSamplesAfterMCMC(
    modelDir, modelName, model, saveChainsList = saveChainsList
  )

  # Only 2 of the 3 planned runs actually have data -- deliberately not
  # padded to a 3-run array (RT-734/#928 refuses that mismatch elsewhere).
  # Before the fix, runData was filled by list *position* after sorting, so
  # run 3's data (the second file found) was stored at position 2 and
  # labelled "run2" -- silently relabelling every run after the gap.
  expect_equal(dimnames(compiled)[["runs"]], c("run2", "run3"))
  expect_equal(as.vector(compiled[1, "p1", "run2", 1]), 2)
  expect_equal(as.vector(compiled[1, "p1", "run3", 1]), 3)
})

test_that(".CompileSamplesAfterMCMC's TSV fallback does not mislabel runs
          after a run number gap (RT-659 defect 1, TSV path)", {
  modelDir <- withr::local_tempdir()
  modelName <- "rt659b"
  paramNames <- "p1"
  saveChainsList <- list(1L, 1L, 1L)

  for (run in c(2L, 3L)) {
    df <- data.frame(iteration = 1L, chain = 1L, p1 = run)
    write.table(df, file.path(modelDir,
                              paste0(modelName, "_samples_run_", run, ".txt")),
               sep = "\t", row.names = FALSE)
  }

  model <- list(outputParams = paramNames)
  compiled <- StratoBayes:::.CompileSamplesAfterMCMC(
    modelDir, modelName, model, saveChainsList = saveChainsList
  )

  expect_equal(dimnames(compiled)[["runs"]], c("run2", "run3"))
  expect_equal(as.vector(compiled[1, "p1", "run2", 1]), 2)
  expect_equal(as.vector(compiled[1, "p1", "run3", 1]), 3)
})

test_that(".PadArray pads dim4 (chains) up to maxDim4 so abind() along dim 3
          does not fail when runs have differing chain counts (RT-659
          defect 2)", {
  # Exact reproduction from the issue: dims c(2,2,1,4) and c(2,2,1,2).
  arrMany <- array(1, dim = c(2, 2, 1, 4))
  arrFew  <- array(2, dim = c(2, 2, 1, 2))

  padded <- lapply(list(arrMany, arrFew), StratoBayes:::.PadArray,
                    maxDim1 = 2, maxDim4 = 4)

  expect_equal(dim(padded[[2]]), c(2, 2, 1, 4))

  combined <- NULL
  expect_no_error(
    combined <- do.call(abind::abind, c(padded, along = 3))
  )
  expect_equal(dim(combined), c(2, 2, 2, 4))
  # the padded-in chains for the short run must be NA, not fabricated data
  expect_true(all(is.na(combined[, , 2, 3:4])))
})
