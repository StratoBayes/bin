# #1298: one Inf in a signal column produced a completely dead, all-NaN chain
# that RunStratModel() returned with no error, no warning, and a
# nGibbsCholeskyFailures of 0 — a run indistinguishable from a healthy one by
# any of the package's own health diagnostics.
#
# Layer 1 (StratData) closes the data route; layers 2/3 (the C++ Gibbs sweep)
# make the same poisoning report itself when it reaches the engine some other
# way — a hand-built state, or a signal value mutated after construction.

.sig1298 <- function() {
  d <- as.data.frame(stratData1[["signal"]])
  d[["site"]] <- as.character(d[["site"]])
  d
}

test_that("StratData rejects an infinite signal value (#1298)", {
  bad <- .sig1298()
  bad[["value"]][5] <- Inf
  expect_error(
    StratData(signal = bad, siteColumn = "site", zColumn = "height",
              signalColumn = "value"),
    "infinite values \\(row 5\\)"
  )

  bad[["value"]][9] <- -Inf
  expect_error(
    StratData(signal = bad, siteColumn = "site", zColumn = "height",
              signalColumn = "value"),
    "rows 5, 9"
  )
})

test_that("StratData still accepts NA and a clean signal (#1298)", {
  ok <- .sig1298()
  ok[["value"]][5] <- NA_real_
  expect_s3_class(
    StratData(signal = ok, siteColumn = "site", zColumn = "height",
              signalColumn = "value"),
    "StratData"
  )
  ok[["value"]][6] <- NaN
  expect_s3_class(
    StratData(signal = ok, siteColumn = "site", zColumn = "height",
              signalColumn = "value"),
    "StratData"
  )
})

# The end-to-end guard. The Inf is injected AFTER construction, so it reaches
# the C++ engine exactly as it did before layer 1 existed. Pre-fix this run
# finished silently with NaN samples and nGibbsCholeskyFailures == 0; the
# assertion that goes red if the engine guards are deleted is the warning.
test_that("an Inf that reaches the engine is reported, not silent (#1298)", {
  clean <- StratData(signal = .sig1298(), siteColumn = "site",
                     zColumn = "height", signalColumn = "value")
  # `signalAttr$signalValuesVec` is the cached copy the engine actually reads
  # (sb_create_engine); poisoning it is how the Inf reaches the sweep now that
  # StratData() rejects it at the door.
  poisoned <- clean
  poisoned[["signalAttr"]][["signalValuesVec"]][[1]][5] <- Inf

  model <- StratModel(clean, alignmentScale = "height", sedModel = "site",
                      sigmaFixed = 0.1, nKnots = 10, flexibleKnots = FALSE,
                      knotRange = c(-2.5, 12.5))

  dir <- withr::local_tempdir()
  warnings <- character(0)
  post <- withCallingHandlers(
    RunStratModel(poisoned, model, nRun = 1L, nChains = 2L, nIter = 20L,
                  modelDir = dir, modelName = "m1298", visualise = FALSE,
                  quiet = TRUE, runParallel = FALSE, nThreads = 1L, seed = 1L),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  # The health diagnostic must see it ...
  expect_gt(sum(post[["mcmcSummary"]][["nGibbsCholeskyFailures"]]), 0L)
  # ... and the user must be told, once, in plain language.
  expect_true(any(grepl("Cholesky decomposition failed", warnings, fixed = TRUE)))
  # Pins the beta rollback specifically: without it the first sweep's non-finite
  # draw reaches the saved samples even though the later sweeps get counted.
  # (`posterior` is legitimately -Inf here, so this tests NaN, not finiteness.)
  expect_false(any(is.nan(post[["samples"]])))
})
