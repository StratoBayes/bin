# #842: the C++ engine accumulates acceptance-monitor counts one batch at a
# time and tested `i >= startMonitoring` at the batch's leading edge only, so a
# batch straddling the start of the monitoring window contributed nothing.
#
# The oracle is exact and path-independent: every iteration proposes exactly
# once per chain, so the totals over the window must be
# `nChains * (endMonitoring - startMonitoring + 1)` whatever is accepted. The
# `engine = "R"` arm tests the same claim against a loop that has always been
# per-iteration, so a wrong oracle would fail there too rather than silently
# excusing the C++ arm.

data(stratData1, package = "StratoBayes", envir = environment())
data(stratModel1, package = "StratoBayes", envir = environment())

# `startMonitoring` is derived from `adaptProposalInterval` and the run length;
# batch boundaries come from the checkpoint schedule. Nothing ties the two
# together, and these arguments pick a run where they disagree.
#
# `do.call()` rather than `...`: `.CompileArgsToFile()` reconstructs the caller's
# call with `match.call()`, which errors on a `...` it cannot see.
.MonitoredTotals <- function(engine, extra) {
  dir <- withr::local_tempdir(.local_envir = parent.frame())
  do.call(RunStratModel, c(
    list(stratData1, stratModel1, nRun = 1, nChains = 2, nThreads = 1L,
         seed = 1, quiet = TRUE, visualise = FALSE, convergenceStop = FALSE,
         modelDir = dir, modelName = "m842", engine = engine,
         adaptProposalInterval = 7),
    extra))
  mcmc <- readRDS(file.path(dir, "m842_mcmc_run_1.rds"))
  accMon <- mcmc[[c("metro", "acceptanceMonitor")]]
  list(observed = sum(accMon[["proposalTotal"]]),
       expected = mcmc[["nChains"]] *
         (accMon[["endMonitoring"]] - accMon[["startMonitoring"]] + 1))
}

test_that("the monitor counts every iteration of its window (#842)", {
  for (engine in c("cpp", "R")) {
    # No adaptation, so every batch is a post-adaptation one.
    totals <- .MonitoredTotals(engine, list(nIter = 40, adaptProposal = FALSE))
    expect_equal(totals[["observed"]], totals[["expected"]])
  }
})

test_that("monitoring after a real adaptation window loses nothing (#842)", {
  for (engine in c("cpp", "R")) {
    # A collapsed adaptation window is the reachable case where the monitor
    # starts well after `endAdapting` rather than at `endAdapting + 1`, which
    # is a batch boundary already and so cannot discriminate.
    totals <- .MonitoredTotals(engine, list(nIter = 60, startAdapting = 20,
                                            endAdapting = 20))
    expect_equal(totals[["observed"]], totals[["expected"]])
  }
})
