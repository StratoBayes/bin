# RT-649 (#829): the R engine's NUTS diagnostic fields must be cleared at
# proposal dispatch.
#
# `nutsDivergent` / `nutsTreeDepth` are written only by `.UpdateStateNUTS()` and
# `.UpdateStateHMC()`, and read only by the counting block in
# `RunStratModel()`, which gates on `!is.null(nutsDivergent)` -- so a value
# surviving into an MH iteration is counted as a gradient transition, and a
# surviving TRUE as a divergence.
#
# Only a REJECTED MH move can expose that: it returns `state` untouched,
# whereas an accepted one wipes `metro` wholesale inside
# `.GenerateValidProposal()`. Both arms therefore assert a rejection occurred.
# Unclear-flags inflation measured at 2.1x (100 reported, 47 actual).

test_that("#829: a rejected MH move clears the NUTS diagnostic fields", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  set.seed(829)
  mcmc <- StratMCMC(stratModel1, nIter = 40, nChains = 1)
  state <- .GenerateInitialState(stratData1, stratModel1, mcmc, 1)

  nIter <- 30L
  accepts <- logical(nIter)
  staleDivergent <- logical(nIter)
  staleTreeDepth <- logical(nIter)
  for (i in seq_len(nIter)) {
    mcmc[["currentIter"]] <- i
    # Re-planted every iteration: an accepted move wipes `metro` on its own, so
    # a single plant would be consumed by the first acceptance.
    state[[c("metro", "nutsDivergent")]] <- TRUE
    state[[c("metro", "nutsTreeDepth")]] <- 7L
    state <- .UpdateState(stratData1, stratModel1, mcmc, state, 1)
    accepts[[i]] <- isTRUE(state[[c("metro", "accept")]])
    staleDivergent[[i]] <- !is.null(state[[c("metro", "nutsDivergent")]])
    staleTreeDepth[[i]] <- !is.null(state[[c("metro", "nutsTreeDepth")]])
  }

  # No gradient proposal is installed here, so every dispatch is MH. Absent,
  # not FALSE: the counting block gates on `!is.null()`.
  expect_false(any(staleDivergent))
  expect_false(any(staleTreeDepth))

  # Discriminator: with no rejection the two assertions above are vacuous.
  expect_true(any(!accepts))
})

test_that("#829: nGradientTransitions counts exactly the gradient dispatches", {
  # Not skip_on_cran(): this is the only arm that reaches the runtime counter
  # the issue was about, and a skipped arm runs zero assertions on a PR. The
  # whole file costs ~2 s, so it gates the merge lane instead.
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  # ORACLE: a non-RNG-consuming counter around the real `.UpdateStateNUTS`.
  # `nGradientTransitions` is derived from `state`, not from this call, so the
  # two are independent.
  nutsCalls <- 0L
  realNUTS <- StratoBayes:::.UpdateStateNUTS
  testthat::local_mocked_bindings(
    .UpdateStateNUTS = function(...) {
      nutsCalls <<- nutsCalls + 1L
      realNUTS(...)
    },
    .package = "StratoBayes"
  )

  # `flexibleKnots = FALSE`: gradient proposals under the R engine require it.
  model <- StratModel(
    stratData1, priors = stratModel1[[c("priors", "metro")]],
    alignmentScale = stratModel1[["alignmentScale"]],
    sedModel = stratModel1[["sedModel"]],
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), paste0("rt649_", as.integer(runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(6491)
  RunStratModel(stratData1, model, nIter = 200L, nChains = 1L, seed = 7L,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "g", engine = "R", gradientProposals = "on",
                nThreads = 1L)
  mcmc <- readRDS(file.path(td, "g_mcmc_run_1.rds"))

  # `<=` not `==`: the gradient-failure early return in `.UpdateStateNUTS()`
  # sets neither field, so that dispatch is legitimately uncounted. Unclear
  # flags gave 133 against 48 actual calls.
  expect_lte(mcmc[["nGradientTransitions"]], nutsCalls)

  # Discriminators: NUTS really ran, and the MH rejections that can inflate the
  # count really outnumbered it.
  expect_gt(nutsCalls, 0L)
  expect_gt(200L - nutsCalls, nutsCalls)
})
