# ── The β-marginal must not believe a Cholesky with no significant digits ────
#
# GH #953. `signal_logmarginal_one` forms M = BᵀB/σ² + λD and factors it.
# dpotrf and dpbtrf reject a pivot only when it is ≤ 0, so an M that is singular
# to working precision still factors with `info == 0`, and the solve then returns
# arithmetic noise. On real data that noise was a log-posterior of +1e10 .. +1e23
# against an honest fit near −5000, which the chain accepted and could never
# leave (24/24 tempered runs on `cambrian-6site-noparts`).
#
# The state that produces it is NOT exotic: the flexible-knot law rescales D by
# (span/ageSpan)³, so an alignment that stretches the age span drives λD twenty
# decades below BᵀB/σ² while λ itself sits obediently on its #551/#603 floor.
# The floor cannot fix this — it bounds λ, not λD.
#
# The guard is an exact bound, not a tuned threshold: M ⪰ BtB/σ² for any λ ≥ 0,
# so quad = ½·Btyᵀ M⁻¹ Bty/σ⁴ ≤ ½·y'y/σ² at EVERY state, and a larger value is
# certainly miscomputed. #551 rightly refused a threshold part-way up a rising
# density (the chain samples the wall instead of avoiding it); this is different,
# because the density is not rising — recomputed by a cancellation-free QR the
# honest marginal at those states is 6,000–8,800 nats WORSE than an ordinary
# alignment, so correct arithmetic rejects them anyway. (That figure is from the
# real states and does NOT describe the fixtures below, whose QR references are
# +175.9 and +215.0 against a healthy design's −11.4: they scale D directly
# while the normalising ½(p−2)·log λ tracks only λ, so their effective prior is
# near-improper and the marginal genuinely diverges. #1381.)
#
# WHICH CONDITIONING TESTS WORK. Two were refuted before #1381 and stay refuted:
#   * the equilibrated PIVOT min_j L[j,j]²/M[j,j] against p·eps. A real state
#     reporting +1.1e8 scored 2.8e-14 there and a red/green let 2 of 6 seeds
#     through; #1155 later measured why, the pivot surrogate under-reports κ by
#     up to 1.29e6x because a Kahan matrix has every pivot O(1) at κ₂ ≈ 7e15.
#   * rcond of M as it stands. The "no data under two basis functions" case
#     below scores 1.1e-23 there while being finite and CORRECT — raw, it is
#     indistinguishable from a collapsed sliver.
# What does work is LAPACK's estimator on the EQUILIBRATED matrix D_s·M·D_s,
# D_s = diag(M)^-½, run unconditionally (#1381). Rounding in forming BtB is
# componentwise, |ΔM_ij| ≲ n·eps·√(M_ii·M_jj) — ~n·eps in SCALED units — so a
# scaled matrix whose rcond is below eps does not determine its own smallest
# eigenvalue, whatever its diagonal looks like. Equilibrated, the empty-column
# case scores 2.0e-3 (its ill-conditioning was pure scaling: those columns
# decouple and their assembly error is exactly zero) against 1.4e-18..2.5e-16
# for the #953 slivers, and 479,573 marginal evaluations of a real tempered
# `cambrian-6site-noparts` run never went below 8.9e-5.
#
# The "no data under two basis functions" case below therefore pins BOTH halves:
# it must stay finite, which rules out a raw pivot or a raw rcond, and it is the
# equilibration that lets it through.

pen <- function(p, scale = 1) {
  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  scale * crossprod(Delta)
}

bspline_design <- function(x, p, ord = 4L) {
  k <- seq(0, 1, length.out = p - ord + 2)
  splines::splineDesign(c(rep(k[1], ord - 1), k, rep(k[length(k)], ord - 1)),
                        x, ord = ord, outer.ok = TRUE)
}

marginal_of <- function(B, D, y, lambda = 1, sigma = 1) {
  StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(B), beta_list = list(numeric(ncol(B))),
    signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list(),
    marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)[2]
}

# Independent reference: the same marginal from a QR of the augmented system
# [B/σ ; √λ·Δ], which never forms the normal equations and so does not square
# the condition number. Written from the model, not translated from the C++.
marginal_reference <- function(B, D, y, lambda = 1, sigma = 1) {
  p <- ncol(B)
  eD <- eigen(D, symmetric = TRUE)
  keep <- eD$values > max(eD$values) * 1e-14
  Delta <- diag(sqrt(eD$values[keep]), sum(keep)) %*%
    t(eD$vectors[, keep, drop = FALSE])
  qrA <- qr(rbind(B / sigma, sqrt(lambda) * Delta), LAPACK = TRUE)
  R <- qr.R(qrA)
  z <- backsolve(R, (as.numeric(crossprod(B, y)) / sigma^2)[qrA$pivot],
                 transpose = TRUE)
  -nrow(B) * log(sigma) - 0.5 * sum(y^2) / sigma^2 +
    0.5 * (p - 2) * log(lambda) + 0.5 * sum(z^2) - sum(log(abs(diag(R))))
}

p <- 12L
n <- 60L
set.seed(1)
y <- sin(6 * seq(0, 1, length.out = n)) + stats::rnorm(n, sd = 0.1)
spread <- bspline_design(seq(0, 1, length.out = n), p)

test_that("a well-conditioned design is unaffected, however small lambda*D is", {
  # Full-strength ridge: the ordinary case.
  expect_equal(marginal_of(spread, pen(p), y),
               marginal_reference(spread, pen(p), y))

  # Ridge annihilated by a 1e-20 rescale, design still well spread. The guard
  # keys on conditioning, not on the size of lambda*D, so this must be untouched.
  expect_equal(marginal_of(spread, pen(p, 1e-20), y),
               marginal_reference(spread, pen(p, 1e-20), y))
})

test_that("basis functions with no data under them are not rejected (#953 equilibration)", {
  # Data occupy only the upper half of the knot range, so the leading basis
  # columns are empty and their diagonals are ~1e-20 of the rest. Those columns
  # are decoupled: the factorisation is exact and the marginal is correct, so it
  # must come back finite. This is the case that rules out a raw pivot ratio AND
  # a raw rcond -- 1.06e-23 unscaled, 2.0e-3 equilibrated, which is why #1381's
  # gate measures the equilibrated matrix.
  edge <- bspline_design(seq(0.55, 1, length.out = n), p)
  got <- marginal_of(edge, pen(p, 1e-20), y)
  expect_true(is.finite(got))
  expect_equal(got, marginal_reference(edge, pen(p, 1e-20), y))
})

test_that("a design collapsed onto a sliver of the knot range is rejected", {
  # The #953 alignment shape: every observation in a 1e-4 sliver, ridge
  # annihilated. M is singular to working precision and the marginal cannot be
  # evaluated, so the state must be rejected rather than scored.
  for (width in c(1.2e-4, 1e-5)) {
    collapsed <- bspline_design(seq(0.5, 0.5 + width, length.out = n), p)
    expect_identical(marginal_of(collapsed, pen(p, 1e-20), y), -Inf)
  }
})

# ── #1145: an exactly-fitting design sits ON the bound, so it must not trip ──
#
# 2*quad = y'y/sigma^2 - min_b f(b) for f(b) = ||y - Bb||^2/sigma^2 + lambda*b'Db.
# A constant y is interpolated by b = 1 under a partition-of-unity basis, and
# D %*% 1 = 0 for a difference penalty, so min f is EXACTLY 0 and quad EXACTLY
# equals the bound. Whether the computed quad lands above or below is then pure
# rounding, at the scale of the solve's forward error 3*p*eps*kappa(M) -- five
# to six decades past the p*eps slack #995 allowed. 63 of 576 such configurations
# returned -Inf pre-fix, at n/p from 0.25 to 7.5.
exact_fit <- list(
  list(p = 40L, n = 10L, ord = 3L, sigma = 10, lambda = 1e3, warp = 3),
  list(p = 40L, n = 10L, ord = 4L, sigma = 10, lambda = 1e3, warp = 1),
  list(p =  8L, n = 60L, ord = 4L, sigma = 10, lambda = 1e3, warp = 3))

test_that("a design that fits exactly is scored, not rejected (#1145)", {
  for (cfg in exact_fit) {
    B <- bspline_design(seq(0, 1, length.out = cfg$n)^cfg$warp, cfg$p, cfg$ord)
    y <- rep(1, cfg$n)
    got <- marginal_of(B, pen(cfg$p), y, cfg$lambda, cfg$sigma)
    expect_true(is.finite(got))
    expect_equal(got, marginal_reference(B, pen(cfg$p), y, cfg$lambda, cfg$sigma),
                 tolerance = 1e-6)
  }
})

test_that("the exact-fit case is scored on the dense Cholesky path too (#1145)", {
  # Every naturally-arising exact fit is banded, so permute one symmetrically to
  # reach sb_cholesky's branch of the re-test: P preserves both Bb = y (P%*%1 = 1)
  # and D%*%1 = 0, so the fit stays exact, but the band does not survive and
  # sb_band_detect declines to -1.
  cfg <- exact_fit[[1]]
  set.seed(3)
  perm <- sample.int(cfg$p)
  B <- bspline_design(seq(0, 1, length.out = cfg$n)^cfg$warp, cfg$p, cfg$ord)[, perm]
  D <- pen(cfg$p)[perm, perm]
  y <- rep(1, cfg$n)
  got <- marginal_of(B, D, y, cfg$lambda, cfg$sigma)
  expect_true(is.finite(got))
  expect_equal(got, marginal_reference(B, D, y, cfg$lambda, cfg$sigma),
               tolerance = 1e-6)
})

test_that("the marginal never exceeds the honest value, on either Cholesky path", {
  # The invariant the guard actually enforces, stated directly: whatever the
  # conditioning, the returned value is either -Inf or is not ABOVE the
  # cancellation-free QR value. Only overshoot is dangerous -- that is what the
  # chain accepts and cannot leave. Undershoot by rounding is harmless and does
  # occur (a near-collinear p = 4 design lands ~0.5 nats low).
  #
  # p = 4 declines the banded fast path (sb_band_detect caps at p - 2), so the
  # dense rows exercise sb_cholesky and the p = 12 rows exercise dpbtrf.
  #
  # `collinear` is the one design in this file whose verdict #1381 CHANGED: it
  # scored -3.359 before and is -Inf now, its kappa(M) being ~1e16. Both stay
  # tolerated here on purpose. Its equilibrated rcond is 1.3e-16 against a gate
  # at 12*eps = 2.7e-15 -- 20x, an order of magnitude thinner than anything else
  # the guard decides, and #1377 is what a margin argument at that scale buys.
  set.seed(2)
  nd <- 20L
  dense <- matrix(stats::rnorm(nd * 4L), nd, 4L)
  collinear <- dense
  collinear[, 4] <- collinear[, 3] + 1e-8 * stats::rnorm(nd)
  yd <- stats::rnorm(nd)

  designs <- list(
    list(B = dense, D = pen(4L, 1e-20), y = yd),
    list(B = collinear, D = pen(4L, 1e-20), y = yd),
    list(B = spread, D = pen(p), y = y),
    list(B = spread, D = pen(p, 1e-20), y = y),
    list(B = bspline_design(seq(0.55, 1, length.out = n), p),
         D = pen(p, 1e-20), y = y),
    list(B = bspline_design(seq(0.5, 0.5 + 1.2e-4, length.out = n), p),
         D = pen(p, 1e-20), y = y),
    list(B = bspline_design(seq(0.5, 0.5 + 1e-5, length.out = n), p),
         D = pen(p, 1e-20), y = y))

  for (d in designs) {
    got <- marginal_of(d$B, d$D, d$y)
    if (is.finite(got)) {
      expect_lte(got, marginal_reference(d$B, d$D, d$y) + 1e-6)
    } else {
      expect_identical(got, -Inf)
    }
  }

  # #1145 clamps quad to the bound rather than carrying the excess, so the
  # exact-fit designs must respect the same invariant.
  for (cfg in exact_fit) {
    B <- bspline_design(seq(0, 1, length.out = cfg$n)^cfg$warp, cfg$p, cfg$ord)
    y <- rep(1, cfg$n)
    expect_lte(marginal_of(B, pen(cfg$p), y, cfg$lambda, cfg$sigma),
               marginal_reference(B, pen(cfg$p), y, cfg$lambda, cfg$sigma) + 1e-6)
  }
})

# ── #1155: the trip branch needs a real condition estimate, not a lower bound ─
#
# kappa was first estimated as max_j M[j,j] / min_j L[j,j]^2, on the argument
# that under-estimating kappa only tightens the slack. That is true of the slack
# and FALSE of the clamp: an under-report keeps the state on the ACCEPT side,
# where quad is then replaced by the bound -- a value the solve never earned.
# Measured over 4,646 dense Kahan constructions the surrogate under-reported by
# up to 1.29e6x, admitting a clamp 6.1% of the bound above the truth (~1.2e3 nats
# at #953's scale). dpbcon/dpocon on the computed factor has no such failure
# mode, and runs only inside the branch that used to return -Inf outright.

kahan <- function(p, s, tail = 1) {
  cc <- sqrt(1 - s^2)
  K <- matrix(0, p, p)
  for (i in 1:p) {
    K[i, i] <- s^(i - 1)
    if (i < p) K[i, (i + 1):p] <- -cc * s^(i - 1)
  }
  K[, p] <- K[, p] * tail
  K
}

test_that("a solve the pivot surrogate calls healthy is still rejected (#1155)", {
  # A Kahan matrix is the textbook case the surrogate cannot see: every Cholesky
  # pivot is O(1) while kappa_2 is ~7e15. B = [K; 0] makes BtB = K'K exactly, and
  # y = (K^-T v, e) realises any bound above quad_true, so the fixture is a state
  # some real design and signal produce -- not a hand-poked triple.
  pk <- 40L
  K <- kahan(pk, 0.9, 10^-4.5)
  set.seed(3)
  v <- stats::rnorm(pk)
  yfit <- as.numeric(solve(t(K), v))
  quadTrue <- 0.5 * sum(yfit^2)          # = ½·v'(K'K)⁻¹v exactly
  # Bound placed 3% above the truth, inside the solve's actual 6.5% error, so
  # the computed quad overshoots it by ~3.4% -- far under the 2x cap, and under
  # the 10.3% slack the surrogate's kappa granted. Both margins are ~3x.
  B <- rbind(K, 0)
  yk <- c(yfit, sqrt(2 * quadTrue * 0.03))
  D <- pen(pk, 1e-30)

  # The discriminator: the surrogate estimate leaves relErr well below 1, so the
  # old code accepted and clamped here. If a future edit makes this fixture
  # rejectable on conditioning alone, this assertion fails and says so.
  Lc <- t(chol(crossprod(B) + D))
  relErrSurrogate <- 3 * pk * .Machine$double.eps *
    max(diag(crossprod(B) + D)) / min(diag(Lc))^2
  expect_lt(relErrSurrogate, 1)

  expect_identical(marginal_of(B, D, yk), -Inf)
})

test_that("the relErr gate, not the 2x cap, rejects the #953 population (#1155)", {
  # Scanning the collapsed-sliver family finely in width, most factorable states
  # that trip the guard overshoot the bound by LESS than 2x, so the `1 + relErr
  # < 2` cap does not reject the broken population -- the relErr >= 1 gate does.
  # This fixture sits in that sub-2x band: quad/bound = 1.0028 against relErr
  # 1.5e9, so it is rejected by the gate and by nothing else. Weaken, invert or
  # delete the gate and it comes back finite (measured: 215.34).
  # The pre-existing sliver fixtures cannot stand in: both widths (1.2e-4 and
  # 1e-5) fail the Cholesky outright, so neither ever reaches this branch.
  #
  # ONE fixture, not the two this started with. #1377: the other (scale 1e-16,
  # width 10^-3.375) was rejected on x86-64 and ACCEPTED on aarch64, returning
  # +176.8. Reaching this branch at all requires quad > bound, which the bound's
  # proof forbids in exact arithmetic -- so EVERY fixture here trips only on
  # rounding, and by how much is arithmetic-dependent. That one sat too close to
  # the edge to survive a change of architecture: across four arithmetic variants
  # on x86-64 alone its value spanned 7 nats (175.9 QR / 180.97 dense / 182.85
  # clamped / 182.93 raw band) and its quad/bound straddled 1 (0.892 dense, >1
  # band). This fixture spans 0.4 nats over the same four (214.99 / 215.38 /
  # 215.34 / 215.36) and is confirmed rejected on BOTH architectures. If it ever
  # needs replacing, trust that spread and a two-architecture check -- not a
  # margin argument, which is what selected the fixture that broke.
  cfg <- list(scale = 1e-20, width = 10^-3.06)
  B <- bspline_design(seq(0.5, 0.5 + cfg$width, length.out = n), p)
  expect_identical(marginal_of(B, pen(p, cfg$scale), y), -Inf)
})

# -- #1381: the trust gate runs unconditionally, on the equilibrated matrix ---
#
# Before #1381 the condition estimate ran only inside the `quad > bound` branch.
# That branch is unreachable in exact arithmetic (M >= BtB/sigma^2 is a theorem),
# so it fires only once rounding has corrupted quad -- which made the verdict
# arithmetic-dependent (#1377: the same sliver was -Inf on x86-64 and +176.8 on
# aarch64) and left states whose quad happens to stay under the bound unchecked.

test_that("a solve with no significant digits is rejected even under the bound (#1381)", {
  # The same Kahan construction as above, with an ordinary y instead of one
  # placed to overshoot: quad/bound = 0.9685, so the bound branch never trips and
  # the pre-#1381 code scored this state at +91.83 -- a POSITIVE log-marginal on
  # a design whose kappa_2 is ~7e15, the exact shape of #953. rcond of the
  # equilibrated M is 9.1e-18 against a gate at 3p*eps = 2.7e-14, so the gate
  # rejects it with 2,900x to spare. Delete the gate and this comes back +91.83.
  pk <- 40L
  K <- kahan(pk, 0.9, 10^-4.5)
  set.seed(7)
  yk <- stats::rnorm(pk + 1L)
  B <- rbind(K, 0)
  D <- pen(pk, 1e-30)

  M <- crossprod(B) + D
  sc <- 1 / sqrt(diag(M))
  quadOverBound <- 0.5 * sum(backsolve(chol(M), crossprod(B, yk),
                                       transpose = TRUE)^2) / (0.5 * sum(yk^2))
  expect_lt(quadOverBound, 1)                       # the bound branch is not it
  expect_lt(rcond(M * outer(sc, sc), norm = "1"),
            3 * pk * .Machine$double.eps / 100)     # the gate is, with margin

  expect_identical(marginal_of(B, D, yk), -Inf)
})

test_that("the sliver that flipped across architectures is rejected (#1377)", {
  # Restored from #1380, which dropped it because its quad/bound straddled 1 and
  # so its verdict turned on rounding. It is no longer selected by a margin on
  # quad/bound: the gate keys on the equilibrated conditioning, which sits 4,600x
  # under the threshold here, and does not care whether dpbtrf's pivot on a
  # matrix singular to working precision comes out positive on this machine.
  cfg <- list(scale = 1e-16, width = 10^-3.375)
  B <- bspline_design(seq(0.5, 0.5 + cfg$width, length.out = n), p)
  D <- pen(p, cfg$scale)

  M <- crossprod(B) + D
  sc <- 1 / sqrt(diag(M))
  expect_lt(rcond(M * outer(sc, sc), norm = "1"),
            3 * p * .Machine$double.eps / 100)

  expect_identical(marginal_of(B, D, y), -Inf)
})

test_that("well-conditioned designs keep a wide margin over the gate (#1381)", {
  # The gate's cost is false rejection, so pin the accept side too: healthy
  # B-spline Grams must sit decades above 3p*eps, not just above it. Measured
  # over 479,573 marginal evaluations of a real tempered `cambrian-6site-noparts`
  # run (p = 27), the smallest equilibrated rcond seen was 8.9e-5 -- 4.9e9x the
  # gate. These fixtures stand in for that run; the floor here is ~1e-5.
  designs <- list(
    bspline_design(seq(0, 1, length.out = n), p),
    bspline_design(seq(0, 1, length.out = n)^3, p),
    bspline_design(sort(c(seq(0, .2, length.out = n - 10L),
                          seq(.9, 1, length.out = 10L))), p),
    bspline_design(seq(0, 1, length.out = 200L), 60L))
  for (B in designs) {
    q <- ncol(B)
    M <- crossprod(B) + pen(q, 1e-20)
    sc <- 1 / sqrt(diag(M))
    expect_gt(rcond(M * outer(sc, sc), norm = "1"),
              1e6 * 3 * q * .Machine$double.eps)
  }
})
