# A custom `Prior(R = , D = )` hands two arbitrary R functions to the C++
# engine, which calls them from inside implementation frames: the density from
# `compute_logpost()` and the gradient's finite-difference fallback, the
# generator from `sample_all_from_prior()`, and the density again from
# `sb_logpost_impl()`. An R error raised there used to longjmp straight out of
# those frames (#1144), extending #1134's hazard to the custom-prior half.
#
# WHAT THESE TESTS CAN AND CANNOT SHOW. On x86-64 the run ends in an R error
# both before and after the fix, so the discriminator is *where the error comes
# from*: pre-fix the user's own message thrown through the C++ stack, post-fix
# the C++ frames returning normally and a thin exported wrapper naming the
# callback. Green here is evidence the plumbing works, never evidence about the
# aarch64 abort -- only aarch64 CI can show that.

test_that(".SafeCallback labels the callback it wrapped", {
  out <- .SafeCallback(function(x) stop("nope"), "custom prior density")(1)
  expect_identical(as.double(out), -Inf)
  expect_identical(attr(out, "sbCallbackWhat", exact = TRUE),
                   "custom prior density")
  expect_identical(attr(out, "sbCallbackError", exact = TRUE), "nope")
})

test_that(".SafeCallback's default label survives an unlabelled call", {
  out <- .SafeCallback(function(x) stop("nope"))(1)
  expect_identical(attr(out, "sbCallbackWhat", exact = TRUE), "R callback")
})


# Deciding "is C++ on the stack?" rather than counting calls: a density that
# always throws is caught in pure R by `.GenerateInitialState()` and never
# reaches C++, proving nothing, while a call counter has to be tuned against
# however many times the R-side setup happens to evaluate the prior. The C++
# frames do not pop R's context stack, so `.sb_run_block()` below this one means
# the callback was invoked from inside the sampler's implementation frames.
# `.sb_run_block()` specifically, not any `.sb_*`: `.GenerateInitialState()`
# reaches `.sb_logpost()` before the engine exists, and failing there would
# leave the engine-side density and gradient sites untested.
.Custom1144InEngine <- function() {
  callers <- vapply(sys.calls(), function(cl) {
    fn <- cl[[1L]]
    if (is.name(fn)) as.character(fn) else ""
  }, character(1))
  ".sb_run_block" %in% callers
}

.Custom1144 <- new.env(parent = emptyenv())

.Custom1144Prior <- function() {
  Prior(
    R = function(n, mean, sd) {
      if (isTRUE(.Custom1144$failR) && .Custom1144InEngine())
        stop("the generator gave up")
      stats::rnorm(n, mean, sd)
    },
    D = function(x, mean, sd, log = TRUE) {
      if (isTRUE(.Custom1144$failD) && .Custom1144InEngine())
        stop("the density gave up")
      stats::dnorm(x, mean, sd, log = log)
    },
    Q = function(p, mean, sd) stats::qnorm(p, mean, sd),
    mean = 0, sd = 2
  )
}

.Custom1144Reset <- function(failD = FALSE, failR = FALSE) {
  .Custom1144$failD <- failD
  .Custom1144$failR <- failR
}
.Custom1144Reset()

.Custom1144Fixture <- function() {
  set.seed(1)
  n1 <- 60L
  n2 <- 40L
  h1 <- seq(0, 10, length.out = n1)
  h2 <- seq(0, 6, length.out = n2)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(n1, 0, .1)),
    data.frame(site = "s2", height = h2, value = sin(h2 + 1) + rnorm(n2, 0, .1))
  )
  stratData <- StratData(signal = signal, siteColumn = "site",
                         zColumn = "height", signalColumn = "value")
  priors <- structure(
    list(alpha_s2 = .Custom1144Prior(),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list")
  )
  stratModel <- StratModel(stratData, priors, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "middle",
                           nKnots = 6, sigmaFixed = 1, flexibleKnots = FALSE,
                           knotRange = c(-15, 25))
  list(data = stratData, model = stratModel)
}

test_that(".SafeModelCallbacks wraps only the custom prior's callbacks", {
  model <- .Custom1144Fixture()[["model"]]
  model[[".logpost_cpp"]] <- .PrepareLogPostArgs(model)
  expect_identical(model[[".logpost_cpp"]][["priorTypes"]],
                   c("", "NormalPrior"))

  # Each replacement must behave like `.SafeCallback()` output and carry the
  # label for its own callback, which is what names it in the raised error; a
  # wrapper returning a constant must not satisfy this.
  safe <- .SafeModelCallbacks(model)
  failedD <- safe[[".logpost_cpp"]][["rCustomFns"]][[1L]]("x")
  expect_identical(as.double(failedD), -Inf)
  expect_identical(attr(failedD, "sbCallbackWhat", exact = TRUE),
                   "custom prior density")
  failedR <- safe[["priorsProposals"]][[1L]][["R"]]()
  expect_identical(as.double(failedR), -Inf)
  expect_identical(attr(failedR, "sbCallbackWhat", exact = TRUE),
                   "custom prior sampler")
  # The built-in prior on parameter 2 is read entirely in C++.
  expect_identical(safe[["priorsProposals"]][[2L]][["R"]],
                   model[["priorsProposals"]][[2L]][["R"]])

  # The wrapped closures must never be written back: `model` is serialised to
  # parallel workers, saved with the posterior, and read by the R engine.
  expect_identical(model[[".logpost_cpp"]][["rCustomFns"]][[1L]],
                   model[["priors"]][["metro"]][[1L]][["D"]])
})

test_that(".SafeModelCallbacks is a no-op for a model with no custom prior", {
  model <- list(.logpost_cpp = list(priorTypes = c("NormalPrior", "Fixed")))
  expect_identical(.SafeModelCallbacks(model), model)
  expect_identical(.SafeModelCallbacks(list()), list())
})

test_that(".SafeModelCallbacks keeps an absent generator absent, not deleted", {
  # `.SafeCallback(NULL)` is NULL, and `[[<-` with NULL removes the name.
  model <- list(
    .logpost_cpp = list(priorTypes = "",
                        rCustomFns = list(function(x, log = TRUE) 0)),
    priorsProposals = list(list(R = NULL, args = list()))
  )
  safe <- .SafeModelCallbacks(model)
  expect_true("R" %in% names(safe[["priorsProposals"]][[1L]]))
  expect_null(safe[["priorsProposals"]][[1L]][["R"]])
})

test_that(".SafeCallbacks reuses wrappers but never a stale one", {
  # `.LogPost()` wraps per call, so the memo is a hot-path saving; a memo that
  # missed an invalidation would silently call the PREVIOUS user's density.
  fns <- list(function(x, log = TRUE) stop("first"))
  expect_identical(.SafeCallbacks(fns, "custom prior density"),
                   .SafeCallbacks(fns, "custom prior density"))

  relabelled <- .SafeCallbacks(fns, "custom prior sampler")[[1L]](1)
  expect_identical(attr(relabelled, "sbCallbackWhat", exact = TRUE),
                   "custom prior sampler")

  fns2 <- list(function(x, log = TRUE) stop("second"))
  refreshed <- .SafeCallbacks(fns2, "custom prior density")[[1L]](1)
  expect_identical(attr(refreshed, "sbCallbackError", exact = TRUE), "second")
})

test_that("both .sb_create_engine call sites wrap the model's callbacks", {
  for (fn in list(StratoBayes:::.HMCCreateEngine, StratoBayes:::.InnerRunMCMC)) {
    src <- gsub("[[:space:]]", "",
                paste(deparse(body(fn), width.cutoff = 500L), collapse = ""))
    expect_true(grepl(".SafeModelCallbacks(model)", src, fixed = TRUE))
  }
})

test_that("a throwing custom prior density errors from the wrapper (#1144)", {
  fx <- .Custom1144Fixture()
  for (grad in c("off", "on")) {
    .Custom1144Reset(failD = TRUE)
    expect_error(
      RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                    nIter = 30, nChains = 2L, seed = 1, quiet = TRUE,
                    visualise = FALSE, nThreads = 1L,
                    gradientProposals = grad, engine = "cpp",
                    modelDir = tempdir(), modelName = paste0("t1144d", grad)),
      "A custom prior density raised an error: the density gave up"
    )
  }
})

test_that("a throwing custom prior generator errors from the wrapper (#1144)", {
  fx <- .Custom1144Fixture()
  .Custom1144Reset(failR = TRUE)
  expect_error(
    RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                  nIter = 200, nChains = 2L, seed = 1, quiet = TRUE,
                  visualise = FALSE, nThreads = 1L,
                  gradientProposals = "off", engine = "cpp",
                  modelDir = tempdir(), modelName = "t1144r"),
    "A custom prior sampler raised an error: the generator gave up",
    fixed = TRUE
  )
})

test_that("a well-behaved custom prior still runs (#1144)", {
  fx <- .Custom1144Fixture()
  .Custom1144Reset()
  expect_s3_class(
    RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                  nIter = 20, nChains = 2L, seed = 1, quiet = TRUE,
                  visualise = FALSE, nThreads = 1L,
                  gradientProposals = "off", engine = "cpp",
                  modelDir = tempdir(), modelName = "t1144ok"),
    "StratPosterior"
  )
})

test_that("sb_logpost_impl reports a failed callback through its wrapper", {
  # `sb_logpost_impl()` has no engine to record the message on; it carries a
  # `std::string&` that only `.sb_logpost()` raises.
  boom <- .SafeCallback(function(x, log = TRUE) stop("the density gave up"),
                        "custom prior density")
  args <- list(
    x = 0.5, priorTypes = "", priorArgs = list(list()),
    rCustomFns = list(boom), B_list = list(), beta_list = list(),
    signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list()
  )
  expect_error(do.call(.sb_logpost, args),
               "A custom prior density raised an error: the density gave up")

  args[["rCustomFns"]] <- list(function(x, log = TRUE) dnorm(x, log = log))
  expect_identical(do.call(.sb_logpost, args)[[1]], dnorm(0.5, log = TRUE))
})

test_that(".sb_logpost rejects an unusable rCustomFns in its wrapper", {
  args <- list(
    x = 0.5, priorTypes = "", priorArgs = list(list()),
    rCustomFns = list(), B_list = list(), beta_list = list(),
    signalValues = list(), sigma = numeric(0), overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list()
  )
  expect_error(do.call(.sb_logpost, args), "rCustomFns has 0 entries")

  args[["rCustomFns"]] <- list("not a function")
  expect_error(do.call(.sb_logpost, args), "is not a function")
})
