# Targeted regression test for RT-655
# (see https://github.com/StratoBayes/StratoBayes-R-package/issues/836).
#
# `nCores` is a local inside RunStratModel()'s body, not something returned
# to the caller, so both cases below observe its derived value indirectly
# via the oversubscription warning at RunStratModel.R:924-932 (also
# exercised by RT-352 in test-rt347-348-351-352-runstratmodel-guards.R).
# With `detectCores()` mocked to 4, `nThreads = nChains = 4` (so 4 OS
# threads/run), and `runParallel = 1`: a numeric `runParallel` caps
# `nCores` at `min(nRun, runParallel) = 1`, giving 1 x 4 = 4 threads --
# not > 4 available, so no warning. An explicit `nCores = 3L` overrides
# that cap, giving 3 x 4 = 12 threads -- warns.
.MuffleParallellyWarning <- function(expr) {
  withCallingHandlers(expr, warning = function(w) {
    if (grepl("localhost parallel workers", conditionMessage(w),
              fixed = TRUE)) {
      invokeRestart("muffleWarning")
    }
  })
}

test_that("RT-655: numeric runParallel caps nCores", {
  skip_if_not_installed("future.apply")
  testthat::local_mocked_bindings(
    detectCores = function(...) 4L, .package = "parallel"
  )

  .MuffleParallellyWarning(
    expect_no_warning(
      RunStratModel(
        stratData1, stratModel = stratModel1, nRun = 4, nIter = 2,
        nChains = 4, nThreads = 4, visualise = FALSE, seed = 1:4,
        runParallel = 1, quiet = TRUE
      )
    )
  )
})

test_that("RT-655: explicit nCores overrides numeric runParallel", {
  skip_if_not_installed("future.apply")
  testthat::local_mocked_bindings(
    detectCores = function(...) 4L, .package = "parallel"
  )

  .MuffleParallellyWarning(
    expect_warning(
      RunStratModel(
        stratData1, stratModel = stratModel1, nRun = 4, nIter = 2,
        nChains = 4, nThreads = 4, visualise = FALSE, seed = 1:4,
        runParallel = 1, nCores = 3L, quiet = TRUE
      ),
      "oversubscribe available CPU cores"
    )
  )
})
