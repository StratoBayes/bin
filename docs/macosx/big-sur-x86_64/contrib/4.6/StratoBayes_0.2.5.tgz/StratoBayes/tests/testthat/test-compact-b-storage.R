# ── Compact row-band storage of B (issue #622) ───────────────────────────────
#
# The engine stores each signal's design matrix as n x order row windows plus
# BcolStart (SBCompactB, src/sb_linalg.h); dense n x p matrices exist only at
# the R boundary (.sb_create_engine import, .sb_extract_state export). Storage
# is invisible to results — every consumer already read B through BcolStart
# windows — so these tests pin the three genuinely new pieces: the compact
# writer, the import window-copy, and the dense materialisation at export.

test_that("compact B round-trips the R boundary and matches a dense oracle", {
  data(stratData1, envir = environment())
  data(stratModel1, envir = environment())
  td <- withr::local_tempdir()

  warm <- suppressMessages(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10L, nChains = 2L, nCores = 1L, nThreads = 1L, seed = 4L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "cbstore",
    engine = "R"))
  data_obj <- warm[["data"]]
  model_obj <- warm[["model"]]
  if (is.null(model_obj[[".logpost_cpp"]]))
    model_obj[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  mcmc_obj <- readRDS(file.path(td, "cbstore_mcmc_run_1.rds"))

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj[["ind"]], parameters, FALSE)
      tmpState <- list(age = list(ties = ageResult[["ties"]]))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }
  make_engine <- function(state) {
    StratoBayes:::.sb_create_engine(
      data = data_obj, model = model_obj, mcmc = mcmc_obj, state = state,
      tiesCallback = tiesCallback)
  }
  # Extraction returns unnamed per-signal lists; the R schema names them.
  dense_b <- function(state_chain) {
    unname(lapply(state_chain[[c("metro", "B")]], unname))
  }

  # Import -> extract must reproduce the R-built (splines::splineDesign) dense
  # B exactly: a genuine basis matrix has all nonzeros inside the
  # [colStart, colStart + order) window the compact form keeps.
  eng <- make_engine(mcmc_obj[["recentState"]])
  S0 <- StratoBayes:::.sb_extract_state(eng)
  for (chain in seq_along(S0)) {
    expect_identical(dense_b(S0[[chain]]),
                     dense_b(mcmc_obj[["recentState"]][[chain]]))
  }

  # Advance the engine so B is rebuilt by the compact writer at new ages, then
  # pin the materialised dense B against the package's standalone dense
  # constructor (.sb_spline_design, src/SplineDesign.cpp: same basis
  # recursion, independent *column placement* — which is the dimension this
  # patch changes) at the extracted state's own ages.
  StratoBayes:::.sb_configure_monitor(
    eng, ncol(mcmc_obj[[c("metro", "proposalProbability")]]))
  set.seed(31L)
  StratoBayes:::.sb_run_block(eng, 200L)
  S1 <- StratoBayes:::.sb_extract_state(eng)
  # At least one accepted age/alignment move in 200 sweeps (Gibbs draws never
  # touch B), or the writer was never exercised and the oracle check below is
  # vacuous.
  expect_false(identical(dense_b(S1[[1]]), dense_b(S0[[1]])))

  ord <- model_obj[[c("splineBase", "splineOrder")]]
  sigs <- data_obj[[c("signalAttr", "sigs")]]
  for (chain in seq_along(S1)) {
    st <- S1[[chain]]
    ek <- st[["spline"]][["ext_knots"]]
    if (is.null(ek)) ek <- model_obj[[c("splineBase", "ext_knots")]]
    for (m in seq_along(sigs)) {
      ages <- st[[c("age", "signalFlat")]][sigs[[m]][["signalInd"]]]
      oracle <- StratoBayes:::.sb_spline_design(ek, ages, ord)
      expect_equal(unname(st[[c("metro", "B")]][[m]]), unname(oracle),
                   tolerance = 1e-13)
      # Consumer pin: H comes from the sparse window accumulation
      # (sparse_BtB via compute_htby); crossprod of the SAME dense B is the
      # independent dense route. The only PR-gate assertion touching the
      # compact consumers — the equivalence suites are skip_on_cran.
      sig2 <- st[[c("gibbs", "sigma")]][[m]]^2
      expect_equal(unname(st[[c("metro", "H")]][[m]]),
                   unname(crossprod(st[[c("metro", "B")]][[m]])) / sig2,
                   tolerance = 1e-12)
    }
  }

  # Extract -> import -> extract is the identity on the dense schema: pins the
  # import window-copy and the export materialisation as exact inverses.
  eng2 <- make_engine(S1)
  S2 <- StratoBayes:::.sb_extract_state(eng2)
  for (chain in seq_along(S2)) {
    expect_identical(dense_b(S2[[chain]]), dense_b(S1[[chain]]))
  }
})
