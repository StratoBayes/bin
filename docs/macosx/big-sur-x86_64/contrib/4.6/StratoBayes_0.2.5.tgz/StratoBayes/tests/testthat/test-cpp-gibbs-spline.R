# Tests for the C++ Bayesian-spline Gibbs loop (.sb_gibbs_spline), which powers
# .RunMCMCBspline()/BayesianSpline(). Validated against the retained R reference
# .GibbsSampleBspline().

# Pure-R reference loop (mirrors the pre-C++ .RunMCMCBspline implementation).
.ref_run_bspline <- function(data, model, nIter, nThin = 1) {
  outInd <- seq(1, nIter, nThin); nOut <- length(outInd)
  p <- model[["splineBase"]][["nKnots"]] + 2
  beta <- matrix(NA_real_, nOut, p); sigma <- numeric(nOut); lambda <- numeric(nOut)
  state <- .InitializeGibbsBspline(data, model)
  j <- 0L
  for (i in seq_len(nIter)) {
    state <- .GibbsSampleBspline(data, model, state)
    if (i %in% outInd) {
      j <- j + 1L
      beta[j, ] <- state[["gibbs"]][["beta"]]
      sigma[j]  <- state[["gibbs"]][["sigma"]]
      lambda[j] <- state[["gibbs"]][["lambda"]]
    }
  }
  list(beta = beta, sigma = sigma, lambda = lambda)
}

.make_bspline_model <- function(nKnots = 20, n = 80, lambdaFixed = FALSE) {
  set.seed(303)
  x <- sort(runif(n, 0, 12))
  y <- 0.5 * x + sin(x) + rnorm(n, 0, 0.3)
  d <- data.frame(x = x, y = y)
  d <- d[stats::complete.cases(d), ]
  model <- .ModelBspline(d, nKnots, NULL, 0.01, 0.01, 1, 1000, 0.0001,
                         lambdaFixed, NULL, NULL)
  list(data = d, model = model)
}

.call_cpp_loop <- function(data, model, nIter, nThin = 1) {
  state <- .InitializeGibbsBspline(data, model)
  lf <- isTRUE(model[["lambdaFixed"]])
  .sb_gibbs_spline(
    B = model[["Bspline"]], y = data[["y"]], D = model[[c("splineBase", "D")]],
    sigma0 = state[[c("gibbs", "sigma")]], lambda0 = state[[c("gibbs", "lambda")]],
    aLambda = model[[c("priors", "gibbs", "aLambda")]],
    bLambda = model[[c("priors", "gibbs", "bLambda")]],
    shapeSigma = model[["shapeSigma"]],
    bSigma = model[[c("priors", "gibbs", "bSigma")]],
    numBasis = model[[c("splineBase", "num_basis")]],
    nIter = nIter, outInd = as.integer(seq(1, nIter, nThin)),
    lambdaFixed = lf,
    lambdaFixedValue = if (lf) model[["lambdaFixedValue"]] else 0
  )
}

test_that("single-iteration beta draw matches R reference exactly", {
  bm <- .make_bspline_model()
  state0 <- .InitializeGibbsBspline(bm$data, bm$model)

  # The beta draw happens before any Gamma draw, so the RNG stream is identical
  # and beta should match to numerical (Cholesky) precision.
  set.seed(456)
  ref <- .GibbsSampleBspline(bm$data, bm$model, state0)

  set.seed(456)
  cpp <- .sb_gibbs_spline(
    B = bm$model[["Bspline"]], y = bm$data[["y"]], D = bm$model[[c("splineBase", "D")]],
    sigma0 = state0[[c("gibbs", "sigma")]], lambda0 = state0[[c("gibbs", "lambda")]],
    aLambda = bm$model[[c("priors", "gibbs", "aLambda")]],
    bLambda = bm$model[[c("priors", "gibbs", "bLambda")]],
    shapeSigma = bm$model[["shapeSigma"]],
    bSigma = bm$model[[c("priors", "gibbs", "bSigma")]],
    numBasis = bm$model[[c("splineBase", "num_basis")]],
    nIter = 1L, outInd = 1L, lambdaFixed = FALSE, lambdaFixedValue = 0
  )

  expect_equal(as.numeric(cpp$beta[1, ]), as.numeric(ref[["gibbs"]][["beta"]]),
               tolerance = 1e-6)
})

test_that("C++ loop posterior means match the R reference", {
  bm <- .make_bspline_model()
  nIter <- 3000L; sel <- (nIter / 2 + 1):nIter

  set.seed(99); ref <- .ref_run_bspline(bm$data, bm$model, nIter)
  set.seed(99); cpp <- .call_cpp_loop(bm$data, bm$model, nIter)

  # posterior mean sigma
  expect_equal(mean(cpp$sigma[sel]), mean(ref$sigma[sel]), tolerance = 0.03)

  # posterior mean fitted curve agrees within a small fraction of the noise SD
  ext <- bm$model[["splineBase"]][["ext_knots"]]
  grid <- seq(min(bm$data$x), max(bm$data$x), length.out = 30)
  B <- splines::splineDesign(ext, grid, sparse = FALSE)
  fit_ref <- as.numeric(B %*% colMeans(ref$beta[sel, ]))
  fit_cpp <- as.numeric(B %*% colMeans(cpp$beta[sel, ]))
  expect_lt(max(abs(fit_ref - fit_cpp)), 0.05 * sd(bm$data$y))
})

test_that("thinning yields the expected number of stored iterations", {
  bm <- .make_bspline_model()
  res <- .call_cpp_loop(bm$data, bm$model, nIter = 100L, nThin = 5L)
  expect_equal(length(res$sigma), length(seq(1, 100, 5)))
  expect_equal(nrow(res$beta), length(seq(1, 100, 5)))
  expect_true(all(is.finite(res$sigma)) && all(res$sigma > 0))
  expect_true(all(is.finite(res$lambda)) && all(res$lambda > 0))
})

test_that("fixed lambda is held constant across the chain", {
  set.seed(7)
  x <- sort(runif(80, 0, 12)); y <- 0.5 * x + sin(x) + rnorm(80, 0, 0.3)
  spline <- BayesianSpline(x, y, nKnots = 20, nIter = 200, lambdaFixed = 5)
  expect_true(all(spline$lambda == 5))
})

# ── RT-187: the beta precision matrix must never be left unfactorised ────────
# `beta` is a zero-initialised workspace reused across iterations, so a
# Cholesky failure used to store a beta that had not been resampled — all-zero
# on iteration 1 — and then feed it to beta'D beta (the lambda draw) and the
# residual sum of squares (the sigma draw), contaminating the rest of the
# chain. The recovery ridge is now scaled to the magnitude of the precision
# matrix itself, is reported the first time it is needed, and the sampler stops
# rather than carrying an unresampled beta forward.

test_that("a ridge-recovered beta draw is reported, not silent (RT-187)", {
  # Reachable via the public API: lambdaFixed = 0 removes the penalty entirely,
  # so with fewer data points (2) than basis functions (nKnots + 2 = 27),
  # B'B/sigma^2 is exactly singular and the first factorisation fails.
  x <- c(0, 10)
  y <- c(1, 2)
  expect_warning(
    fit <- BayesianSpline(x, y, nKnots = 25, nIter = 5L, lambdaFixed = 0),
    "numerically indefinite"
  )
  expect_true(all(is.finite(fit[["beta"]])))
  expect_true(all(fit[["lambda"]] == 0))
})

test_that("the recovery ridge is scaled to the precision matrix (RT-187)", {
  # The ridge used to be an absolute 1e-8, escalating to an absolute 1e13.
  # Both are invisible against a precision matrix of magnitude ~1e30
  # (cancellation in the factorisation is O(eps * ||M||)), so the pre-fix code
  # fell through to storing the all-zero iteration-1 beta. A ridge measured
  # relative to mean(diag(M)) rescues it at any scale.
  p <- 8L
  set.seed(11)
  # B'B has rank 2 out of 8, with magnitude ~1e30 and no axis-aligned null
  # space, so the ridge has to survive cancellation to do anything.
  B <- 1e15 * t(qr.Q(qr(matrix(rnorm(p * 2), nrow = p)))[, 1:2, drop = FALSE])
  D <- matrix(0, p, p)   # no penalty, so M = B'B/sigma^2 alone is singular
  y <- c(0, 0)

  expect_warning(
    res <- .sb_gibbs_spline(
      B = B, y = y, D = D,
      sigma0 = 1, lambda0 = 0,
      aLambda = 1, bLambda = 1000,
      shapeSigma = 1, bSigma = 0.01,
      numBasis = p, nIter = 1L, outInd = 1L,
      lambdaFixed = TRUE, lambdaFixedValue = 0
    ),
    "numerically indefinite"
  )
  expect_true(all(is.finite(res[["beta"]])))
  # The pre-fix code stored the untouched zero workspace here.
  expect_false(all(res[["beta"]] == 0))
})

test_that("an unfactorisable precision matrix stops instead of storing stale beta (RT-187)", {
  # A negative-definite penalty is a caller error, not ill-conditioning: no
  # ridge can rescue it, so the sampler must stop rather than store a beta it
  # never resampled. (Unreachable through BayesianSpline(), whose penalty comes
  # from .bsplinepen() and is a PSD Gram matrix; this guards the kernel.)
  p <- 4L
  expect_error(
    .sb_gibbs_spline(
      B = matrix(0, nrow = 5, ncol = p), y = rep(0, 5), D = -diag(p),
      sigma0 = 1, lambda0 = 1,
      aLambda = 1, bLambda = 1000,
      shapeSigma = 1, bSigma = 0.01,
      numBasis = p, nIter = 1L, outInd = 1L,
      lambdaFixed = FALSE, lambdaFixedValue = 0
    ),
    "could not factorise"
  )
})

test_that("the ridge ladder escalates past its first rung when needed (RT-187)", {
  # Only the first rung had coverage, so a bug in the escalation (or in the
  # rung reported by the warning) would have gone unnoticed. B'B = diag(1,1,1,0)
  # and lambda * D = -1e-8 in the last coordinate give M = diag(1,1,1,-1e-8),
  # whose mean diagonal is ~0.75; recovery therefore needs a relative ridge
  # above 1e-8/0.75 = 1.33e-8, so rungs 1e-10, 1e-9 and 1e-8 must all fail and
  # 1e-7 must succeed. (Kernel-level construction: .bsplinepen() is PSD, so a
  # negative penalty entry is not reachable through BayesianSpline().)
  p <- 4L
  expect_warning(
    res <- .sb_gibbs_spline(
      B = diag(c(1, 1, 1, 0)), y = rep(0, 4), D = -diag(c(0, 0, 0, 1)) * 1e-8,
      sigma0 = 1, lambda0 = 1,
      aLambda = 1, bLambda = 1000,
      shapeSigma = 1, bSigma = 0.01,
      numBasis = p, nIter = 1L, outInd = 1L,
      lambdaFixed = TRUE, lambdaFixedValue = 1
    ),
    "relative ridge of 1e-07"
  )
  expect_true(all(is.finite(res[["beta"]])))

  # Contrast: the reachable trigger recovers on the very first rung, so the
  # perturbation there is 1e-10 of the matrix scale.
  expect_warning(
    BayesianSpline(c(0, 10), c(1, 2), nKnots = 25, nIter = 1L, lambdaFixed = 0),
    "relative ridge of 1e-10"
  )
})

test_that("a ridge-recovered iteration is reported only once per run (RT-187)", {
  # Every iteration of this fit needs the ridge, but the warning is suppressed
  # after the first so a long chain cannot bury the rest of its output (or hit
  # R's 50-warning cap) with one repeated message.
  nWarn <- 0L
  withCallingHandlers(
    BayesianSpline(c(0, 10), c(1, 2), nKnots = 25, nIter = 20L,
                   lambdaFixed = 0),
    warning = function(w) {
      nWarn <<- nWarn + 1L
      invokeRestart("muffleWarning")
    }
  )
  expect_equal(nWarn, 1L)
})

test_that("BayesianSpline recovers a known smooth signal", {
  set.seed(21)
  x <- seq(0, 8, length.out = 120)
  y <- sin(x) + rnorm(120, 0, 0.15)
  fit <- BayesianSpline(x, y, nKnots = 15, nIter = 1500)
  pred <- PredictSpline(fit, at = x, burnIn = 0.5)
  # fitted posterior mean tracks the true sin(x) closely
  expect_lt(sqrt(mean((pred$mu - sin(x))^2)), 0.1)
})


# ── Input guards on the .sb_gibbs_spline wrapper (#1176) ─────────────────────
# The implementation reaches B, y and D through raw pointers with no bounds
# check, so a shape mismatch is an out-of-bounds read, not an R-level error.
# Pre-fix, every call below returned normally with garbage or all-zero output.
# `.RunMCMCBspline()` always supplies conforming arguments, so this is a
# `:::`-level hardening guard rather than a user-facing bug fix.

.gibbs_spline_args <- function(...) {
  fit <- .make_bspline_model(nKnots = 4, n = 40)
  state <- .InitializeGibbsBspline(fit$data, fit$model)
  args <- list(
    B = fit$model[["Bspline"]], y = fit$data[["y"]],
    D = fit$model[[c("splineBase", "D")]],
    sigma0 = state[[c("gibbs", "sigma")]],
    lambda0 = state[[c("gibbs", "lambda")]],
    aLambda = fit$model[[c("priors", "gibbs", "aLambda")]],
    bLambda = fit$model[[c("priors", "gibbs", "bLambda")]],
    shapeSigma = fit$model[["shapeSigma"]],
    bSigma = fit$model[[c("priors", "gibbs", "bSigma")]],
    numBasis = fit$model[[c("splineBase", "num_basis")]],
    nIter = 10L, outInd = c(2L, 4L, 6L),
    lambdaFixed = FALSE, lambdaFixedValue = 0
  )
  utils::modifyList(args, list(...))
}

# One shape per test_that: an unexpected C++ error aborts the whole block, so
# bundling them would leave the later ones unrun on any build that throws early.
test_that("#1176: .sb_gibbs_spline rejects a y that does not match B's rows", {
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(y = c(1, 2, 3))),
               "one element per row")
})

test_that("#1176: .sb_gibbs_spline rejects a D that is not numBasis square", {
  expect_error(do.call(.sb_gibbs_spline,
                       .gibbs_spline_args(D = matrix(1, 2, 2))),
               "numBasis x numBasis")
})

test_that("#1176: .sb_gibbs_spline rejects a numBasis that disagrees with B", {
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(numBasis = 3L)),
               "must have `numBasis` columns")
})

test_that("#1176: .sb_gibbs_spline rejects an outInd it cannot honour", {
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(outInd = c(0L, 4L))),
               "1:nIter")
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(outInd = c(4L, 99L))),
               "1:nIter")
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(outInd = c(5L, 3L))),
               "strictly increasing")
  expect_error(do.call(.sb_gibbs_spline, .gibbs_spline_args(outInd = c(2L, 2L))),
               "strictly increasing")
})

test_that("#1176: a valid thinned outInd still stores every requested draw", {
  set.seed(11)
  out <- do.call(.sb_gibbs_spline, .gibbs_spline_args(outInd = c(2L, 4L, 6L)))
  # The pre-fix exact-match cursor produced these same values for an ascending
  # in-range outInd, so this pins the drain rewrite as behaviour-preserving on
  # the only input the package itself ever supplies.
  expect_equal(dim(out$beta), c(3L, 6L))
  expect_true(all(is.finite(out$beta)))
  expect_true(all(out$sigma > 0))
  expect_true(all(out$lambda > 0))
  expect_false(any(apply(out$beta, 1, function(r) all(r == 0))))
})
