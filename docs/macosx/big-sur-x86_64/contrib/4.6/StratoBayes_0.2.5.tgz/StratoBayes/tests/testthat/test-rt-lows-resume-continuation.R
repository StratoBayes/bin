# Tests for a batch of low-severity red-team findings around resume/
# continuation bookkeeping and the sequential profiling path:
#   RT-003 temperingSwaps history wiped on continued runs
#   RT-005 adaptTemperaturesMonitor=TRUE + adaptTemperatures=FALSE silently no-ops
#   RT-098 NUTS/HMC divergence counters reset on continued runs
#   RT-099 adaptTemperaturesCount not transferred on resume
#   RT-100 acceptanceMonitor totals not transferred on resume
#   RT-164 completedIter underreports on cpp-engine time-limit early termination
#   RT-165 Rprof not stopped on error in the sequential profiling path

# ── RT-098/099/100/003 (transfer half): .UpdateMCMCforContinuedRun ──────────
# Direct unit test of the transfer function with minimal mock mcmc objects,
# isolating these fixes from the (heavier) chainHistory/acceptance ring-buffer
# transfer logic in the same function (adaptProposal = FALSE skips that branch
# entirely).

test_that(".UpdateMCMCforContinuedRun transfers divergence/adaptation/monitor accumulators (RT-098/099/100/003)", {
  oldTemperingSwaps <- matrix(c(TRUE, FALSE, NA, TRUE), nrow = 2)

  mcmcOld <- list(
    nDivergent = 5L,
    nGradientTransitions = 20L,
    maxTreeDepth = 7L,
    temper = list(
      adaptTemperaturesCount = 4L,
      temperingSwaps = oldTemperingSwaps
    ),
    metro = list(
      acceptanceMonitor = list(
        acceptanceTotal = matrix(c(3, 4), nrow = 1),
        proposalTotal   = matrix(c(10, 10), nrow = 1)
      ),
      proposalProbability = matrix(0.5, 1, 2),
      proposalFactor = matrix(1, 1, 2),
      proposalValid = matrix(TRUE, 1, 2),
      proposalArgs = list(list(NULL, NULL)),
      adaptProposal = FALSE
    ),
    recentState = list(dummy = TRUE)
  )

  mcmcNew <- list(
    nDivergent = 0L,
    nGradientTransitions = 0L,
    maxTreeDepth = 0L,
    temper = list(
      temperatures = c(1, Inf),
      adaptTemperaturesCount = 0L,
      temperingSwaps = NULL
    ),
    metro = list(
      acceptanceMonitor = list(
        acceptanceTotal = matrix(0, 1, 2),
        proposalTotal = matrix(0, 1, 2)
      ),
      proposalProbability = matrix(0, 1, 2),
      proposalFactor = matrix(0, 1, 2),
      proposalValid = matrix(FALSE, 1, 2),
      proposalArgs = list(),
      adaptProposal = FALSE
    ),
    nChains = 1,
    recentState = NULL
  )

  result <- .UpdateMCMCforContinuedRun(mcmc = mcmcOld, mcmcNew = mcmcNew, newRun = FALSE)

  # RT-098
  expect_equal(result[["nDivergent"]], 5L)
  expect_equal(result[["nGradientTransitions"]], 20L)
  expect_equal(result[["maxTreeDepth"]], 7L)

  # RT-099
  expect_equal(result[[c("temper", "adaptTemperaturesCount")]], 4L)

  # RT-100
  expect_equal(result[[c("metro", "acceptanceMonitor", "acceptanceTotal")]],
               mcmcOld[[c("metro", "acceptanceMonitor", "acceptanceTotal")]])
  expect_equal(result[[c("metro", "acceptanceMonitor", "proposalTotal")]],
               mcmcOld[[c("metro", "acceptanceMonitor", "proposalTotal")]])

  # RT-003 (transfer half)
  expect_equal(result[[c("temper", "temperingSwaps")]], oldTemperingSwaps)
})

test_that(".UpdateMCMCforContinuedRun leaves fresh values untouched for a new run", {
  mcmcOld <- list(nDivergent = 5L)
  mcmcNew <- list(
    nDivergent = 0L,
    metro = list(adaptProposal = FALSE),
    nChains = 1
  )
  result <- .UpdateMCMCforContinuedRun(mcmc = mcmcOld, mcmcNew = mcmcNew, newRun = TRUE)
  expect_equal(result[["nDivergent"]], 0L)
})


# ── RT-325: continuation arguments left unspecified must inherit the ──────
# ── checkpoint, not the StratMCMC()/RunStratModel() function default ──────
#
# Originally: `.UpdateMCMCforContinuedRun` carried over the prior run's
# temperature ladder unconditionally, so continuing a tempered run with
# `tempering = FALSE` left every non-cold chain mis-tempered in the base MH
# acceptance ratio (`.AcceptProposal` / `accept_proposal` divide by
# temperatures[chain] unconditionally, with no tempering-flag guard).
#
# Follow-up: the same "silently resets to the function default instead of the
# checkpoint" problem exists for every other StratMCMC continuation argument
# -- e.g. continuing a `tempering = FALSE` run *without* re-specifying
# `tempering` at all silently flipped it back to `TRUE` (the signature
# default) and generated a brand-new random ladder. Fixed via
# `.ResolveContinuationDefaults()` (mcmcFunctions.R), called from
# `RunStratModel()` before building `mcmcNew`, for every argument in
# `.stratMCMCCheckpointFieldMap`; `tempering`/`temperatures` and the
# `adaptProposal`/`startAdapting`/`endAdapting` trio get bespoke handling at
# the same call site (see the doc comment on the field map for why).

test_that(".ResolveContinuationDefaults leaves args untouched for a new run (oldMcmc = NULL)", {
  args <- list(nThin = 1, bactrianM = 0.95)
  result <- .ResolveContinuationDefaults(args, oldMcmc = NULL, providedArgs = character(0))
  expect_equal(result, args)
})

test_that(".ResolveContinuationDefaults substitutes only the un-provided arguments", {
  oldMcmc <- list(
    nThin = 5,
    metro = list(bactrianM = 0.5, alphaShift = 0.2)
  )
  args <- list(nThin = 1, bactrianM = 0.95, alphaShift = NULL)

  # User explicitly supplied `bactrianM` this call -- must NOT be overwritten.
  result <- .ResolveContinuationDefaults(args, oldMcmc, providedArgs = "bactrianM")

  expect_equal(result[["nThin"]], 5)          # not provided -> checkpoint
  expect_equal(result[["bactrianM"]], 0.95)   # provided -> kept as given
  expect_equal(result[["alphaShift"]], 0.2)   # not provided -> checkpoint
})

test_that(".ResolveContinuationDefaults tolerates a checkpoint missing an entire intermediate key", {
  # Legacy checkpoint saved before `metro$bactrianM` existed -- no `metro` key
  # at all. Must not error ("no such index at level 1") and must leave the
  # default in place, not crash.
  oldMcmc <- list(nThin = 5)
  args <- list(nThin = 1, bactrianM = 0.95)

  result <- .ResolveContinuationDefaults(args, oldMcmc, providedArgs = character(0))

  expect_equal(result[["nThin"]], 5)
  expect_equal(result[["bactrianM"]], 0.95)
})

test_that(".ResolveContinuationDefaults leaves a field-map name absent from `args` untouched, even if the checkpoint has it (RT-325 DRY refactor)", {
  # A caller with no concept of a given setting at all -- e.g.
  # RunStratModelShiny() has no `bactrianM` argument -- must not have it
  # silently introduced from the checkpoint. `StratMCMC()` then applies its
  # own default, matching that caller's pre-existing (unfixed) behaviour
  # exactly rather than a surprise new inheritance path.
  oldMcmc <- list(metro = list(bactrianM = 0.3))
  args <- list(nThin = 1)

  result <- .ResolveContinuationDefaults(args, oldMcmc, providedArgs = character(0))

  expect_false("bactrianM" %in% names(result))
})

test_that(".BuildContinuationMCMC errors clearly when mcmcArgs is missing a required argument (RT-325 DRY refactor)", {
  expect_error(
    .BuildContinuationMCMC(
      model = NULL, mcmcRun = NULL, newRun = TRUE, providedArgs = character(0),
      completedIter = 0,
      mcmcArgs = list(nIter = 100)
    ),
    "missing required entries"
  )
})

# Build a complete `mcmcArgs` from StratMCMC()'s own defaults, so this stays
# valid as arguments are added rather than needing a hand-maintained literal.
.TestMcmcArgs <- function(...) {
  required <- c(
    "nIter", "nChains", "nThin", "saveChains", "tempering",
    "temperatures", "adapt", "adaptTemperatures", "adaptTemperaturesIntervall",
    "adaptTemperaturesDecay", "adaptTemperaturesMonitor", "adaptProposal",
    "startAdapting", "endAdapting", "adaptProposalWindow",
    "adaptProposalInterval", "acceptanceHistoryLength", "alphaShift",
    "proposalProbabilityWeights", "scaleMultivariateProposals",
    "onlyMultivariateProposalsAfterAdapt", "clustWithParametersMCMC",
    "clustMethodMCMC", "clustMaxMCMC", "silCutOffMCMC",
    "silOutlierThresholdMCMC", "clustMinPtsMCMC", "parametersInitial",
    "saveMCMC", "writeMCMCfile"
  )
  fm <- formals(StratMCMC)
  args <- lapply(required, function(nm) {
    default <- fm[[nm]]
    if (identical(default, quote(expr = ))) NULL else eval(default)
  })
  names(args) <- required
  utils::modifyList(args, list(...))
}

test_that(".BuildContinuationMCMC derives adaptTemperatures explicitness from providedArgs when not forwarded (RT-133)", {
  # The NULL-`.adaptTemperaturesExplicit` branch. RunStratModel() always forwards
  # a concrete value, so this path belongs solely to RunStratModelShiny(), whose
  # only in-repo caller is `inst/gui/` -- untestable end-to-end from here, hence
  # this direct unit test. nChains = 2 makes the ladder c(1, Inf), so RT-133's
  # no-op condition is live and the warning is the observable.
  args <- .TestMcmcArgs(nIter = 200, nChains = 2, tempering = TRUE,
                        adaptTemperatures = TRUE)

  expect_warning(
    .BuildContinuationMCMC(
      model = stratModel1, mcmcRun = NULL, newRun = TRUE,
      providedArgs = "adaptTemperatures", completedIter = 0, mcmcArgs = args
    ),
    "has no effect"
  )

  expect_no_warning(
    .BuildContinuationMCMC(
      model = stratModel1, mcmcRun = NULL, newRun = TRUE,
      providedArgs = character(0), completedIter = 0, mcmcArgs = args
    )
  )
})


# ── RT-325/RT-310 full-pipeline: continuation-argument inheritance ────────
# Small real RunStratModel() runs exercising the mechanism end-to-end,
# including the parts `.ResolveContinuationDefaults()` unit tests can't
# reach: the `tempering`/`temperatures` honour-vs-inherit-vs-warn logic and
# the RT-310 adaptation-window freeze, both resolved directly in
# `RunStratModel()` rather than the generic field map.

test_that("continuing without `tempering=` inherits the checkpoint's flag, not the function default (RT-325)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = FALSE)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  expect_false(mcmc1[[c("temper", "tempering")]])

  # No `tempering=` argument at all this call.
  r2 <- RunStratModel(r1, nIter = 10, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  expect_false(mcmc2[[c("temper", "tempering")]])
  expect_true(all(mcmc2[[c("temper", "temperatures")]] == 1))
})

# NOTE on the two tests below: their core "ladder ends up flat/inherited"
# assertions alone do NOT discriminate the current comprehensive mechanism
# (`.ResolveContinuationDefaults`, inheriting ~22 settings generically) from
# the narrower, superseded intermediate fix that only ever special-cased
# `temperatures` in `.UpdateMCMCforContinuedRun` -- in both scenarios below,
# the narrow fix's guard and the comprehensive mechanism happen to resolve
# `tempering` to the same value (explicit argument in the first test;
# checkpoint-was-TRUE coincidentally equalling the function default in the
# second), so the ladder outcome doesn't depend on which implementation is
# present. Each test therefore also asserts a *non-tempering* setting
# (`bactrianM`, `clustMaxMCMC`) is inherited from the checkpoint in the same
# call -- something the narrow, temperatures-only fix could never produce,
# since it had no generic inheritance mechanism at all. This is the same
# check `.ResolveContinuationDefaults`'s own unit tests exercise directly;
# here it confirms the generic mechanism is actually wired into the
# `tempering`/`temperatures` code paths' scenarios, not just reachable in
# isolation.

test_that("explicit `tempering = FALSE` at continuation drops the old ladder, other settings still inherit (RT-325)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = TRUE, bactrianM = 0.5)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  expect_false(all(mcmc1[[c("temper", "temperatures")]] == 1))

  r2 <- RunStratModel(r1, nIter = 10, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L, tempering = FALSE)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  expect_false(mcmc2[[c("temper", "tempering")]])
  expect_true(all(mcmc2[[c("temper", "temperatures")]] == 1))
  # Discriminates against the superseded temperatures-only fix: unrelated
  # settings left unspecified this call still inherit from the checkpoint
  # (0.5, not StratMCMC()'s 0.95 default) in the very same continuation.
  expect_equal(mcmc2[[c("metro", "bactrianM")]], 0.5)
})

test_that("continuing a tempered run without `temperatures=` keeps the adapted ladder, other settings still inherit (RT-325)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = TRUE, clustMaxMCMC = 7)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  oldLadder <- mcmc1[[c("temper", "temperatures")]]

  r2 <- RunStratModel(r1, nIter = 10, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  expect_equal(mcmc2[[c("temper", "temperatures")]], oldLadder)
  # Discriminates against the superseded temperatures-only fix: an unrelated
  # setting left unspecified this call still inherits from the checkpoint
  # (7, not StratMCMC()'s 12 default) in the very same continuation.
  expect_equal(mcmc2[[c("metro", "clustMaxMCMC")]], 7)
})

test_that("an explicit differing `temperatures=` at continuation is honoured, with a warning (RT-325)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = TRUE)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  newLadder <- c(1, 2, 5, Inf)
  # Sanity: genuinely different from whatever the adaptive ladder converged to.
  expect_false(isTRUE(all.equal(mcmc1[[c("temper", "temperatures")]], newLadder)))

  expect_warning(
    r2 <- RunStratModel(r1, nIter = 10, runParallel = FALSE, visualise = FALSE,
                        nThreads = 1L, temperatures = newLadder),
    "differs from the previous run's adapted ladder"
  )
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # The explicitly-supplied ladder wins, not the checkpoint's.
  expect_equal(mcmc2[[c("temper", "temperatures")]], newLadder)
})

test_that("continuing without adaptation args freezes the kernel instead of reopening a window (RT-310)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  # Sanity: the first run's adaptation window closed well before it finished,
  # otherwise this test can't discriminate "frozen" from "still adapting".
  expect_true(mcmc1[["endAdapting"]] < mcmc1[["completedIter"]])

  r2 <- RunStratModel(r1, nIter = 50, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # No fresh window reopened relative to the new segment's own iterations --
  # the inherited window is already fully in the past.
  expect_true(mcmc2[["endAdapting"]] <= mcmc1[["completedIter"]])
  expect_false(any(mcmc2[[c("metro", "adaptProposal")]]))
})

test_that("explicit `adaptProposal = TRUE` at continuation still opens a fresh window (RT-310)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))

  r2 <- RunStratModel(r1, nIter = 50, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L, adaptProposal = TRUE)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # A fresh window relative to the new segment -- starts after completedIter.
  expect_true(mcmc2[["endAdapting"]] > mcmc1[["completedIter"]])
})

test_that("adaptTemperatures resumes on a roomy continuation instead of staying stuck at a mechanically-forced FALSE (RT-325)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # nIter = 5 is short enough that StratMCMC() mechanically coerces
  # `adaptTemperatures` to FALSE (no room to adapt: startAdapting >=
  # endAdapting), even though the user asked for the TRUE default.
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 5,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = TRUE)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  # Sanity: the coercion actually fired, otherwise this test can't discriminate.
  expect_false(mcmc1[[c("temper", "adaptTemperatures")]])
  expect_true(mcmc1[[c("temper", "adaptTemperaturesRequested")]])

  # A long, roomy continuation with an explicit `adaptProposal = TRUE` (so
  # RT-310's freeze-by-default doesn't itself mask this check by reusing the
  # tiny already-elapsed window) but no `adaptTemperatures=` argument.
  r2 <- RunStratModel(r1, nIter = 5000, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L, adaptProposal = TRUE)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # Inherits the *requested* TRUE, not the checkpoint's coerced FALSE -- with
  # ample room this time, temperature adaptation actually resumes.
  expect_true(mcmc2[[c("temper", "adaptTemperatures")]])
})

test_that("explicit `adaptTemperatures = TRUE` at continuation is honoured, not silently discarded (code review follow-up)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # A frozen (RT-310) continuation reuses the checkpoint's already-past
  # startAdapting/endAdapting window. Without the explicit-request unlock,
  # StratMCMC()'s own temperature-schedule computation against that
  # already-past window is degenerate (adaptTemperItEnd <= adaptTemperItStart)
  # and silently forces `adaptTemperatures` back to FALSE -- contradicting
  # the caller's explicit TRUE here and the "explicit always overrides"
  # documented contract. Deliberately does NOT pass `adaptProposal = TRUE`,
  # so this isolates the `adaptTemperatures`-only unlock path.
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                       nChains = 4, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE, nThreads = 1L,
                       tempering = TRUE)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  # Sanity: the first run's window already closed, otherwise this test can't
  # discriminate "frozen against a past window" from "still adapting anyway".
  expect_true(mcmc1[["endAdapting"]] < mcmc1[["completedIter"]])

  r2 <- RunStratModel(r1, nIter = 5000, runParallel = FALSE, visualise = FALSE,
                       nThreads = 1L, adaptTemperatures = TRUE)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  expect_true(mcmc2[[c("temper", "adaptTemperatures")]])
  # Known coupling (documented, not independent control): unlocking the
  # shared window for temperature adaptation also reopens proposal
  # adaptation, since StratMCMC() has only one startAdapting/endAdapting pair
  # for both subsystems.
  expect_true(any(mcmc2[[c("metro", "adaptProposal")]]))
})


# ── RT-003 (pre-fill half): .InnerRunMCMC temperingSwaps allocation ─────────
# Full-pipeline check that a continued run's temperingSwaps rows for the
# already-completed segment are byte-identical afterwards, not reset. (NA
# entries within a row are expected by design -- only nChains-1 of the
# nSwapCombinations columns are attempted per iteration -- so the correct
# check is exact preservation of the pre-continuation matrix, not "no NA".)

test_that("continued runs preserve prior temperingSwaps rows (RT-003)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 60,
                       nChains = 3, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE,
                       adaptTemperaturesMonitor = TRUE, adaptTemperaturesIntervall = 5)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  expect_true(mcmc1[["completedIter"]] >= 1)
  # Sanity: the checkpoint itself actually recorded some swap attempts (not
  # an all-NA array), otherwise this test wouldn't discriminate the bug.
  expect_false(all(is.na(mcmc1[[c("temper", "temperingSwaps")]][
    seq_len(mcmc1[["completedIter"]]), ])))

  r2 <- RunStratModel(r1, nIter = 10, runParallel = FALSE, visualise = FALSE)
  mcmc2 <- readRDS(file.path(r2[["modelDir"]],
                             paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # The first run's completed rows must be preserved exactly, not reallocated
  # to a fresh all-NA array.
  expect_equal(
    mcmc2[[c("temper", "temperingSwaps")]][seq_len(mcmc1[["completedIter"]]), ],
    mcmc1[[c("temper", "temperingSwaps")]][seq_len(mcmc1[["completedIter"]]), ]
  )
})


# ── RT-005: StratMCMC() warns on a no-op adaptTemperaturesMonitor combo ─────

test_that("StratMCMC warns when adaptTemperaturesMonitor=TRUE but adaptTemperatures=FALSE (RT-005)", {
  data(stratModel1, package = "StratoBayes")

  expect_warning(
    StratMCMC(stratModel1, nIter = 10, nChains = 3,
              adaptTemperatures = FALSE, adaptTemperaturesMonitor = TRUE),
    "no effect"
  )
})

test_that("StratMCMC does not warn when adaptTemperaturesMonitor combo is consistent (RT-005)", {
  data(stratModel1, package = "StratoBayes")

  expect_no_warning(
    StratMCMC(stratModel1, nIter = 10, nChains = 3,
              adaptTemperatures = TRUE, adaptTemperaturesMonitor = TRUE)
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 10, nChains = 3,
              adaptTemperatures = FALSE, adaptTemperaturesMonitor = FALSE)
  )
})


# ── RT-164: completedIter must reflect the whole cpp-engine batch ───────────
# Force a time-limit stop mid-batch (.maxBatchSize caps the batch, timeLimit
# is set impossibly small) and compare the recorded completedIter against the
# ground truth: the number of rows actually flushed to the binary samples
# file, which is independent of the buggy bookkeeping variable.

test_that("completedIter reflects the full processed batch on cpp time-limit stop (RT-164)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                       nChains = 3, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE,
                       timeLimit = 1e-9, .maxBatchSize = 5L)
  mcmc1 <- readRDS(file.path(r1[["modelDir"]],
                             paste0(r1[["modelName"]], "_mcmc_run_1.rds")))

  # Anchor to this run's own modelName: modelDir defaults to the shared
  # session tempdir(), so an unanchored pattern can match a stale
  # _binarysamples_run_1.rds left behind by an unrelated earlier test.
  binFile <- list.files(r1[["modelDir"]],
                        pattern = paste0("^", .EscapeRegex(r1[["modelName"]]),
                                          "_binarysamples_run_1\\.rds$"),
                        full.names = TRUE)
  skip_if(length(binFile) == 0L, "cpp engine not used / no binary samples file")
  nSamplesWritten <- nrow(readRDS(binFile[1]))

  expect_equal(mcmc1[["completedIter"]], nSamplesWritten)
})


# ── RT-165: Rprof is stopped even when the sequential path errors ──────────
# Mocks .InnerRunMCMC to always throw and utils::Rprof to record calls, so the
# test observes whether the real sequential-profiling code path in
# RunStratModel() calls Rprof(NULL) (the "stop" call) despite the error.

test_that("Rprof is stopped when .InnerRunMCMC errors in the sequential profiling path (RT-165)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  rprofCalls <- character(0)
  fakeRprof <- function(filename = NULL, ...) {
    rprofCalls <<- c(rprofCalls, if (is.null(filename)) "stop" else "start")
  }

  testthat::local_mocked_bindings(
    .InnerRunMCMC = function(...) stop("forced RT-165 test error"),
    .package = "StratoBayes"
  )
  testthat::local_mocked_bindings(Rprof = fakeRprof, .package = "utils")

  expect_error(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                  nChains = 2, visualise = FALSE, seed = 1,
                  runParallel = FALSE, profile = TRUE),
    "forced RT-165 test error"
  )

  expect_equal(rprofCalls, c("start", "stop"))
})
