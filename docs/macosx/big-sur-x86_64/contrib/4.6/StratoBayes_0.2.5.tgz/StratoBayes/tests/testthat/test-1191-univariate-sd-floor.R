# #1191: an exactly-zero adapted Univariate SD is an absorbing state. The
# ">= 3 distinct rows" gate counts whole rows, so a single constant column
# reaches `apply(sdDat, 2, sd)` and yields 0; `.rbactrian(sd = 0)` then draws
# exactly 0, so that coordinate contributes no new history and every later
# recomputation reads the same constant column.

# 3 free parameters on a [0, 10] prior. Column 2 is constant; columns 1 and 3
# vary, so the joint distinct-row gate passes on their variation alone.
.uniFixture <- function(constantCol = 2L, nRow = 12L,
                        priors = rep(list(list(args = list(min = 0,
                                                           max = 10))), 3L)) {
  nParam <- 3L
  hist <- cbind(seq(1, 2, length.out = nRow),
                seq(3, 4, length.out = nRow),
                seq(5, 6, length.out = nRow))
  hist[, constantCol] <- 3.5
  full <- cbind(hist, 0)                      # trailing logPost column

  model <- list(
    parametersLength = nParam,
    parametersLengthNotFixed = nParam,
    ind = list(paramNotFixed = seq_len(nParam), alpha = integer(0),
               gamma = integer(0)),
    priors = list(metro = priors)
  )
  mcmc <- list(
    nChains = 1L, currentIter = 10L, endAdapting = 100L, startAdapting = 1L,
    propose = setNames(vector("list", 1L), "Univariate"),
    temper = list(temperatures = 1, tempering = FALSE),
    metro = list(
      historySize = nRow, historyLength = nRow, historyRingPos = 1L,
      enableRingBuffer = FALSE, clustWithParametersMCMC = TRUE,
      nProposals = 1L,
      proposalValid = matrix(FALSE, 1L, 1L,
                             dimnames = list(NULL, "Univariate")),
      proposalProbability = matrix(1, 1L, 1L,
                                   dimnames = list(NULL, "Univariate")),
      proposalArgs = list(chain1 = list(Univariate = NULL)),
      adaptProposal = TRUE,
      chainHistory = list(full),
      historyStamp = list(seq_len(nRow)),
      historyStampNext = nRow + 1L
    )
  )
  list(model = model, mcmc = mcmc, hist = hist, nRow = nRow)
}

.adaptedSDs <- function(f) {
  metro <- .UpdateProposal(data = list(), model = f[["model"]],
                           mcmc = f[["mcmc"]], chain = 1L,
                           inLateAdaptation = FALSE)
  metro[["proposalArgs"]][["chain1"]][["Univariate"]]
}

test_that("a constant column still clears the distinct-row gate", {
  f <- .uniFixture()
  # The premise of the whole finding: the gate is joint over rows, so the
  # constant column is never what stops the empirical SD being computed.
  expect_gte(nrow(unique(f[["hist"]])), 3L)
  expect_identical(stats::sd(f[["hist"]][, 2]), 0)
})

test_that("a degenerate Univariate SD is floored, not left at zero (#1191)", {
  f <- .uniFixture()
  sds <- .adaptedSDs(f)

  # PRE-FIX this was exactly 0.
  expect_gt(sds[2], 0)
  # Derived, not plucked: 1% of the prior-range fallback (0.01 * (max - min)),
  # chosen inside the derived admissible band by analogy with -- not the same
  # basis as -- the 1% relative guard `.NeighbourScaledSDs` applies to its own
  # adapted SD field.
  expect_equal(sds[2], 0.01 * 0.01 * (10 - 0))
  # The two informative columns keep their empirical SDs untouched: the floor
  # must not inflate an SD adaptation set legitimately, because Univariate is
  # one joint accept/reject over every free coordinate.
  expect_equal(sds[c(1, 3)], apply(f[["hist"]][, c(1, 3)], 2, stats::sd))
})

test_that("a zero SD is absorbing, and the floor escapes it (#1191)", {
  f <- .uniFixture()
  model <- f[["model"]]
  sds <- .adaptedSDs(f)

  # One adaptation round: propose from the adapted SDs, accept everything, and
  # feed the resulting states back in as the next history.
  advance <- function(sdVec, nStep) {
    set.seed(1191)
    x <- c(1.5, 3.5, 5.5)
    out <- matrix(NA_real_, nStep, 3L)
    for (i in seq_len(nStep)) {
      x <- .ProposeUnivariate(1L, x, sdVec, proposalFactor = 1,
                              dimFactor = 1, model = model)
      out[i, ] <- x
    }
    out
  }

  # (a) With the pre-fix value the coordinate cannot move at all: this is the
  #     absorbing state, demonstrated rather than asserted.
  stuck <- advance(c(sds[1], 0, sds[3]), f[["nRow"]])
  expect_identical(stats::sd(stuck[, 2]), 0)

  # (b) ... and it does not restart: the next recomputation off that history
  #     sees the same constant column, so the pre-fix SD stays 0 for ever.
  f2 <- f
  f2[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(stuck, 0))
  # PRE-FIX this returned 0 -- the same zero, off the history that zero
  # produced. POST-FIX the column is still constant, so the floor fires again
  # and the coordinate gets another chance to move.
  expect_equal(.adaptedSDs(f2)[2], 0.01 * 0.01 * 10)

  # (c) With the floor the coordinate moves, and the empirical SD recomputed
  #     from that history is genuinely adapted -- recovery, not a pinned floor.
  moved <- advance(sds, f[["nRow"]])
  expect_gt(stats::sd(moved[, 2]), 0)
  f3 <- f
  f3[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(moved, 0))
  recovered <- .adaptedSDs(f3)
  expect_gt(recovered[2], sds[2])
})

test_that("a sub-ULP SD is floored too: the step would round away (#1191)", {
  f <- .uniFixture()
  # sd 0 is the zero-magnitude case of "the proposed step cannot change the
  # stored value". Around 3.5 the spacing of doubles is ~4.4e-16, so an SD
  # below that is absorbing for the same reason.
  subUlp <- f[["hist"]]
  subUlp[, 2] <- rep(c(3.5, 3.5 + 2^-51), length.out = f[["nRow"]])
  f[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(subUlp, 0))

  expect_gt(stats::sd(subUlp[, 2]), 0)               # not the sd == 0 case
  expect_lt(stats::sd(subUlp[, 2]), .Machine[["double.eps"]] * 3.5)
  expect_equal(.adaptedSDs(f)[2], 0.01 * 0.01 * 10)
})

# A one-sidedly truncated prior names both bounds, so the name-based match
# finds them and returns Inf. An infinite SD is absorbing in the same way a
# zero one is -- worse, in fact: `.rbactrian()` draws NaN from it, so every
# proposal is rejected rather than merely being a no-op.
.halfBoundedPriors <- function() {
  rep(list(TruncNormalPrior(0, 1, 0, Inf)), 3L)
}

test_that("an unbounded prior gives a finite scale (#1191)", {
  ranges <- .PriorRanges(.uniFixture(priors = .halfBoundedPriors())[["model"]])

  # PRE-FIX every entry was Inf.
  expect_true(all(is.finite(ranges)))
  expect_true(all(ranges > 0))
  # The substitute is the prior's own central 99% interval, not a constant.
  expect_equal(ranges,
               rep(diff(.qtnorm(c(0.005, 0.995), 0, 1, 0, Inf)), 3L))

  # ... and it still reduces to the exact range where that range is finite.
  bounded <- .PriorRanges(.uniFixture()[["model"]])
  expect_equal(bounded, rep(10, 3L))
})

test_that("the degenerate floor stays finite on an unbounded prior (#1191)", {
  f <- .uniFixture(priors = .halfBoundedPriors())
  sds <- .adaptedSDs(f)

  # PRE-FIX sds[2] was Inf, and `.rbactrian(sd = Inf)` draws NaN: the coordinate
  # that could not move became one whose every proposal is rejected.
  expect_true(all(is.finite(sds)))
  expect_gt(sds[2], 0)
  set.seed(1191)
  expect_true(all(is.finite(
    .ProposeUnivariate(1L, c(1.5, 3.5, 5.5), sds, proposalFactor = 1,
                       dimFactor = 1, model = f[["model"]])
  )))
  # The pre-fix consequence, stated rather than assumed.
  expect_true(is.nan(suppressWarnings(.rbactrian(1L, sd = Inf))))
})

test_that("the NeighbourScaled fallback is finite too (#1191)", {
  f <- .uniFixture(priors = .halfBoundedPriors())
  names(f[["mcmc"]][["propose"]]) <- "NeighbourScaled"
  dimnames(f[["mcmc"]][[c("metro", "proposalValid")]]) <-
    list(NULL, "NeighbourScaled")
  f[["mcmc"]][["metro"]][["proposalArgs"]] <-
    list(chain1 = list(NeighbourScaled = NULL))

  metro <- .UpdateProposal(data = list(), model = f[["model"]],
                           mcmc = f[["mcmc"]], chain = 1L,
                           inLateAdaptation = FALSE)
  # PRE-FIX this branch carried its own copy of the same name-based match.
  expect_true(all(is.finite(
    metro[["proposalArgs"]][["chain1"]][["NeighbourScaled"]]
  )))
  # Unchanged where the range is finite: the shared helper reproduces the
  # old /8 fallback exactly, including its 0.125 no-bounds case.
  expect_equal(
    .PriorRanges(.uniFixture()[["model"]]) / 8, rep(10 / 8, 3L)
  )
})

test_that("the floor is not reached when the column carries information", {
  f <- .uniFixture(constantCol = 2L)
  # Give column 2 a spread far below the floor's own scale but non-zero: the
  # floor must not fire, because there is real adaptation information there.
  tiny <- f[["hist"]]
  tiny[, 2] <- 3.5 + seq_len(f[["nRow"]]) * 1e-9
  f[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(tiny, 0))

  sds <- .adaptedSDs(f)
  expect_equal(sds[2], stats::sd(tiny[, 2]))
  expect_lt(sds[2], 0.01 * 0.01 * 10)
})

test_that("a non-finite empirical SD is floored, not left NA (#1191)", {
  f <- .uniFixture()
  # An NA/NaN in the retained history makes stats::sd() return NA. Deliberate
  # choice: flooring it keeps the proposal SD finite rather than propagating
  # NA into sdVec, at the cost of masking the corrupt-history signal (see the
  # comment at the degenerate-entry check in .UpdateProposal).
  corrupt <- f[["hist"]]
  corrupt[1, 2] <- NA_real_
  f[["mcmc"]][["metro"]][["chainHistory"]] <- list(cbind(corrupt, 0))

  sds <- .adaptedSDs(f)
  expect_true(is.finite(sds[2]))
  expect_equal(sds[2], 0.01 * 0.01 * (10 - 0))
})
