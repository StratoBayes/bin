# #1382: `RunStratModel()` records its arguments by handing `.CompileArgsToFile()`
# its own `match.call()`. Only that frame can expand a `...` the caller forwarded
# in, so reconstructing the call from inside the helper aborted the run outright
# whenever `RunStratModel()` was wrapped.

test_that("RunStratModel() records a wrapped call's arguments (#1382)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  dir <- withr::local_tempdir()

  WrappedRun <- function(...) RunStratModel(stratData1, stratModel1, ...)
  posterior <- WrappedRun(nRun = 1, nChains = 2, nThreads = 1L, seed = 1,
                          nIter = 20, quiet = TRUE, visualise = FALSE,
                          convergenceStop = FALSE, modelDir = dir,
                          modelName = "m1382")

  expect_s3_class(posterior, "StratPosterior")
  options <- readLines(file.path(dir, "m1382_options.txt"))
  # `nIter` reaches the recorded call only through the `...`, while `stratObject`
  # is named only inside the wrapper: both present means what was recorded is
  # `RunStratModel()`'s own call, with the dots expanded into it.
  expect_true("nIter = 20" %in% options)
  expect_true("stratObject = stratData1" %in% options)
})
