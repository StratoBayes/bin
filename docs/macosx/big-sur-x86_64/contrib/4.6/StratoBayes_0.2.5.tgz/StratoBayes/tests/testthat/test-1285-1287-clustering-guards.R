# Area 11 tranche C: #1285 (hdbscan NA guard), #1286 (Cluster.default all-zero
# rescue) and #1287 (dbscan proposal-efficiency mechanisms, comment-only).

# ---------------------------------------------------------------------------
# #1285: .HdbscanCluster() must reject NA input with a clear R-level error,
# matching the guard the other three backends already have -- not the raw
# upstream "cannot contain NAs for kNN" string.
# ---------------------------------------------------------------------------

test_that(".HdbscanCluster errors clearly on a single NA cell (#1285)", {
  m <- matrix(c(1, 2, 3, 4, 5, NA, 7, 8, 9), nrow = 3)
  # "Remove or impute" is specific to this package's own message -- the raw
  # upstream error ("...cannot contain NAs for kNN (with kd-tree)!") also
  # contains the substring "NA", so a bare "NA" pattern would pass pre-fix.
  expect_error(.HdbscanCluster(m, minPts = 3), "Remove or impute")
})

test_that(".HdbscanCluster errors clearly on an all-NA row (#1285)", {
  m <- matrix(c(1, 2, NA, 4, 5, NA), nrow = 3)
  expect_error(.HdbscanCluster(m, minPts = 3), "entirely NA")
})

# ---------------------------------------------------------------------------
# #1286: Cluster.default()'s hdbscan arm must rescue an all-zero label vector
# the same way Cluster.StratPosterior() already does, on exactly-coincident
# input.
# ---------------------------------------------------------------------------

test_that("Cluster.default(hdbscan) rescues all-zero labels on coincident rows (#1286)", {
  m <- matrix(rep(c(1, 2), each = 50), nrow = 50)
  cl <- Cluster(m, clusterMethod = "hdbscan", minPts = 3)
  expect_false(all(cl == 0L))
  expect_true(all(cl == 1L))
})

test_that("Cluster.default(hdbscan) leaves genuine outliers (label 0) alone (#1286)", {
  # A handful of tight points plus one far outlier: hdbscan should assign the
  # outlier its own noise label, and the rescue must not fire when only some
  # (not all) labels are 0.
  set.seed(1)
  tight <- matrix(rnorm(30 * 2, sd = 0.01), ncol = 2)
  outlier <- matrix(c(1000, 1000), ncol = 2)
  m <- rbind(tight, outlier)
  cl <- Cluster(m, clusterMethod = "hdbscan", minPts = 3)
  expect_true(any(cl == 0L))
  expect_true(any(cl != 0L))
})

# ---------------------------------------------------------------------------
# #1287: both mechanisms (small-cluster covariance discard in .ClustInfo(),
# and .ClusterCovariancesAreDegenerate()'s condition-number branch) were
# investigated in the issue thread and are intentional proposal-efficiency
# properties of a Hastings-corrected proposal (both run on the default
# clustMethodMCMC = "proto" path too, not only the opt-in dbscan path), not
# correctness bugs. No functional change was made (mirrors RT-715: a
# comment-only fix needs no regression test); see the comments at
# R/Cluster.R's .ClustInfo() exclude-0s block and
# .ClusterCovariancesAreDegenerate() for the recorded reasoning.
# ---------------------------------------------------------------------------
