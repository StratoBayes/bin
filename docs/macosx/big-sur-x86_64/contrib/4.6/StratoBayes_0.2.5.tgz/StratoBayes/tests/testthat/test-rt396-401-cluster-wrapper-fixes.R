# Regression tests for three independent red-team findings:
#
#   RT-396  `.MatrixMult` destroyed the shape of a zero-row matrix
#           (`matrix(as.double(A), nrow = 0)` is 0 x 0, not 0 x p).
#   RT-400  `.PamCluster`'s silhouette-outlier removal was a silent no-op
#           whenever the input carried row names.
#   RT-401  `.ProtoCluster` lacked the pam branch's `is.na(thresh)` guard.

# ---------------------------------------------------------------------------
# RT-396: .MatrixMult must preserve matrix shape
# ---------------------------------------------------------------------------

test_that(".MatrixMult preserves ncol when coercing a zero-row matrix (RT-396)", {
  # Pre-fix, `matrix(as.double(A), nrow = 0)` collapsed this 0 x 3 integer
  # matrix to 0 x 0, so the conformability check compared 0 against 3 and
  # raised a misleading "number of columns in `A`" error.
  A <- matrix(1L, nrow = 0, ncol = 3)
  B <- matrix(1, nrow = 3, ncol = 2)

  expect_equal(dim(.MatrixMult(A, B)), dim(A %*% B))
  expect_equal(.MatrixMult(A, B), A %*% B)
})

test_that(".MatrixMult matches base `%*%` for every zero-extent case (RT-396)", {
  # Reference BLAS validates LDA/LDB before its zero-extent quick return, so
  # all three degenerate shapes reach XERBLA unless short-circuited.
  cases <- list(
    list(A = matrix(1, 0, 3), B = matrix(1, 3, 2)),  # m = 0
    list(A = matrix(1, 3, 0), B = matrix(1, 0, 2)),  # k = 0
    list(A = matrix(1, 3, 2), B = matrix(1, 2, 0)),  # n = 0
    list(A = matrix(1, 0, 0), B = matrix(1, 0, 0))
  )
  for (case in cases) {
    expect_equal(.MatrixMult(case[["A"]], case[["B"]]),
                 case[["A"]] %*% case[["B"]])
  }
})

test_that(".MatrixMult still rejects genuinely non-conformable inputs (RT-396)", {
  # The short-circuit must not swallow a real dimension mismatch.
  expect_error(.MatrixMult(matrix(1, 0, 3), matrix(1, 2, 4)),
               "number of columns in `A`")
  expect_error(.MatrixMult(matrix(1, 3, 2), matrix(1, 0, 4)),
               "number of columns in `A`")
})

# ---------------------------------------------------------------------------
# RT-400: .PamCluster must not depend on whether observations are labelled
# ---------------------------------------------------------------------------

# Two tight clusters plus four diffuse points that pam flags as silhouette
# outliers.  Pre-fix, the labelled and unlabelled runs disagreed on both the
# cluster assignments and the selected k.
.rt400Data <- function(seed = 1) {
  set.seed(seed)
  rbind(matrix(rnorm(8 * 3, 0, 0.4), 8, 3),
        matrix(rnorm(8 * 3, 5, 0.4), 8, 3),
        matrix(rnorm(4 * 3, 0, 6), 4, 3))
}

test_that(".PamCluster gives the same clustering labelled or unlabelled (RT-400)", {
  x <- .rt400Data()
  xLabelled <- x
  rownames(xLabelled) <- paste0("obs", seq_len(nrow(x)))

  expect_equal(unname(.PamCluster(x, clustMax = 5)),
               unname(.PamCluster(xLabelled, clustMax = 5)))
})

test_that(".PamCluster's outlier removal still fires with labelled input (RT-400)", {
  # The tell: with labels, `sum(isOutlier)` was 0 while outliers existed, so
  # no observation was ever assigned to the outlier cluster 0.
  xLabelled <- .rt400Data()
  rownames(xLabelled) <- paste0("obs", seq_len(nrow(xLabelled)))

  expect_true(any(.PamCluster(xLabelled, clustMax = 5) == 0))
})

test_that(".PamCluster respects a numeric silOutlierThreshold when labelled (RT-400)", {
  # A threshold high enough to catch the diffuse points must have an effect
  # regardless of labelling; pre-fix the argument was silently ignored.
  x <- .rt400Data()
  xLabelled <- x
  rownames(xLabelled) <- paste0("obs", seq_len(nrow(x)))

  unlabelled <- .PamCluster(x, clustMax = 5, silOutlierThreshold = 0.4)
  labelled <- .PamCluster(xLabelled, clustMax = 5, silOutlierThreshold = 0.4)

  expect_equal(unname(unlabelled), unname(labelled))
  expect_true(any(labelled == 0))
})

# ---------------------------------------------------------------------------
# RT-401: .ProtoCluster's NA-threshold handling
# ---------------------------------------------------------------------------

test_that("an NA threshold skips outlier removal rather than erroring (RT-401)", {
  # `silOutlierThreshold = FALSE` is the live route to `thresh <- NA` on the pam
  # branch, and what `if (!is.na(thresh))` guards. An NA `silOutlierSDFromMean`
  # is now a hard error instead (RT-442).
  x <- .rt400Data()

  expect_no_error(result <- .PamCluster(x, clustMax = 4,
                                        silOutlierThreshold = FALSE))
  expect_false(any(result == 0))
  expect_false(anyNA(result))
})

test_that("an NA silOutlierThreshold is a clear usage error (RT-401)", {
  x <- .rt400Data()

  expect_error(.ProtoCluster(x, clustMax = 4, silOutlierThreshold = NA_real_),
               "must be TRUE, FALSE or a number")
  expect_error(.PamCluster(x, clustMax = 4, silOutlierThreshold = NA_real_),
               "must be TRUE, FALSE or a number")
  expect_error(.ProtoCluster(x, clustMax = 4,
                             silOutlierThreshold = c(0.1, 0.2)),
               "must be a single value")
})
