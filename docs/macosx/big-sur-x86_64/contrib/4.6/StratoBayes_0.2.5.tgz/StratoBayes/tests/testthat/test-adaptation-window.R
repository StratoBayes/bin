# Issue #129 stage 4: the adaptation window's defaults, extracted from
# `StratMCMC()` so that the one which cannot survive an unbounded `nIter` is
# visible.
#
# `nIter = Inf` is not yet reachable through `StratMCMC()`, whose validation
# still requires a finite value. The unbounded branch is tested here as a pure
# function, and arms when that validation is relaxed.

test_that("the defaults are unchanged for a new run", {
  # A pin, not a derivation: these are the values the package has always used,
  # and the extraction must not move them.
  expect_identical(.DefaultStartAdapting(1000, 1), 50)
  expect_identical(.DefaultEndAdapting(1000, 1), 500)

  expect_identical(.DefaultStartAdapting(20, 1), 10)
  expect_identical(.DefaultEndAdapting(20, 1), 10)

  # Long runs keep the fixed lead-in rather than scaling it.
  expect_identical(.DefaultStartAdapting(100000, 1), 50)
  expect_identical(.DefaultEndAdapting(100000, 1), 50000)
})

test_that("a continuation adapts relative to its own start", {
  # Both are counted from the start of the segment, so a continuation beginning
  # at iteration 501 adapts over 501..750 rather than 1..250.
  expect_identical(.DefaultEndAdapting(500, 501), 750)
  # Past iteration 51 the lead-in has no room left and adaptation starts at
  # once, which is why the `max(..., 1)` floor is there.
  expect_identical(.DefaultStartAdapting(500, 501), 501)
})

test_that("an unbounded run gets an adaptation phase of its own", {
  # Half of Inf is Inf: adaptation would never end, so every retained draw
  # would come from a still-adapting (non-Markov) kernel.
  expect_identical(.DefaultEndAdapting(Inf, 1), .kDefaultAdaptIter + 0)
  expect_identical(.DefaultEndAdapting(Inf, 101), .kDefaultAdaptIter + 100)
  expect_true(is.finite(.DefaultEndAdapting(Inf, 1)))

  # `startAdapting` needs no such branch: the three-way minimum already falls
  # back to the fixed lead-in.
  expect_identical(.DefaultStartAdapting(Inf, 1), .DefaultStartAdapting(1e6, 1))
})

test_that("StratMCMC() still produces the historical window", {
  mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 2)

  expect_identical(mcmc[["startAdapting"]], 50)
  expect_identical(mcmc[["endAdapting"]], 500)
  # The default proposal-adaptation window is 5% of the range, floored at 100.
  expect_identical(mcmc[[c("metro", "historyLength")]], 100)
})
