# Issue #209: settings that are incompatible with a continued run must be
# caught, rather than silently corrupting that run's output.

ResolveThin <- StratoBayes:::.ResolveContinuationThin

test_that("an explicitly supplied differing nThin is overridden with a warning", {
  expect_warning(
    res <- ResolveThin(nThin = 3, mcmc = list(list(nThin = 1)), completedIter = 8,
                       providedArgs = c("nIter", "nThin")),
    "supplied for this continued run \\(3\\).*stored run's `nThin` \\(1\\)"
  )
  expect_equal(res[["nThin"]], 1)
  expect_true("nThin" %in% res[["providedArgs"]])
})

test_that("an explicitly supplied matching nThin is silent", {
  expect_no_warning(
    res <- ResolveThin(nThin = 2, mcmc = list(list(nThin = 2), list(nThin = 2)),
                completedIter = c(8, 8), providedArgs = c("nIter", "nThin"))
  )
  expect_equal(res[["nThin"]], 2)
})

test_that("an unsupplied nThin is left to silent per-run inheritance", {
  expect_no_warning(
    res <- ResolveThin(nThin = 1, mcmc = list(list(nThin = 5), list(nThin = 5)),
                completedIter = c(8, 8), providedArgs = "nIter")
  )
  # Untouched here; `.ResolveContinuationDefaults()` reads 5 off the checkpoint.
  expect_equal(res[["nThin"]], 1)
  expect_false("nThin" %in% res[["providedArgs"]])
})

test_that("checkpoints that disagree on nThin are forced to run 1's value", {
  expect_warning(
    res <- ResolveThin(nThin = 1, mcmc = list(list(nThin = 2), list(nThin = 5)),
                completedIter = c(8, 8), providedArgs = "nIter"),
    "disagree on `nThin` \\(2, 5\\)"
  )
  expect_equal(res[["nThin"]], 2)
  expect_true("nThin" %in% res[["providedArgs"]])
})

test_that("the diverged-runs path still reports itself, and warns only once", {
  warnings <- capture_warnings(
    res <- ResolveThin(nThin = 3, mcmc = list(list(nThin = 1), list(nThin = 1)),
                       completedIter = c(8, 4),
                       providedArgs = c("nIter", "nThin"))
  )
  expect_length(warnings, 1)
  expect_match(warnings, "diverged in completed iterations")
  expect_equal(res[["nThin"]], 1)
})

test_that("a checkpoint carrying no nThin at all is left alone", {
  expect_no_warning(
    res <- ResolveThin(nThin = 3, mcmc = list(list()), completedIter = 8,
                providedArgs = c("nIter", "nThin"))
  )
  expect_equal(res[["nThin"]], 3)
})

test_that(".ReadMCMC(requireState = TRUE) rejects a checkpoint with no state", {
  fresh <- StratMCMC(stratModel = stratModel1, nIter = 4, nChains = 2)
  expect_null(fresh[["recentState"]])

  expect_error(
    StratoBayes:::.ReadMCMC(fresh, tempdir(), "aModel", nRun = 1,
                            requireState = TRUE),
    "run 1 cannot be continued from.*`recentState`"
  )
  expect_error(
    StratoBayes:::.ReadMCMC(fresh, tempdir(), "aModel", nRun = 1,
                            requireState = TRUE),
    "pass `nIter` on its own"
  )

  # StratPosterior() reads settings only, so its call leaves the check off.
  expect_identical(
    StratoBayes:::.ReadMCMC(fresh, tempdir(), "aModel", nRun = 1),
    list(fresh)
  )
})

test_that(".ReadMCMC(requireState = TRUE) accepts a state-carrying checkpoint", {
  fresh <- StratMCMC(stratModel = stratModel1, nIter = 4, nChains = 2)
  fresh[["recentState"]] <- list(alpha = 0)
  fresh[["completedIter"]] <- 4

  expect_length(
    StratoBayes:::.ReadMCMC(fresh, tempdir(), "aModel", nRun = 1,
                            requireState = TRUE),
    1
  )
})

# The warning these two tests trigger is about the samples FILE, so the file is
# what has to be read. `saveIter` and `nThin` are both derived metadata
# (`R/RunStratModel.R:2071`), and `samples` prefers the `_binarysamples_*.rds`
# fast path, so neither would notice a writer that appended rows on the wrong
# schedule while the checkpoint still recorded the right one.
.SamplesFileIterations <- function(run) {
  file <- file.path(run[["modelDir"]],
                    paste0(run[["modelName"]], "_samples_run_1.txt"))
  expect_true(file.exists(file))
  read.table(file, header = TRUE)[["iteration"]]
}

test_that("a continuation with a differing nThin keeps one saved schedule", {
  modelDir <- withr::local_tempdir()
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 8, nChains = 2, nThin = 2, nThreads = 1L,
                      modelDir = modelDir, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)
  expect_equal(r1[["mcmcSummary"]][["saveIter"]][[1]], c(1, 2, 4, 6, 8))

  expect_warning(
    r2 <- RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                        nIter = 4, nThin = 3, nThreads = 1L, visualise = FALSE,
                        quiet = TRUE),
    "would leave that file on two different schedules"
  )

  expect_equal(unname(r2[["mcmcSummary"]][["nThin"]])[[1]], 2)
  saveIter <- r2[["mcmcSummary"]][["saveIter"]][[1]]
  # Iteration 1 is always saved, so only the schedule after it is regular.
  expect_true(all(diff(saveIter[-1]) == 2))

  # The rows actually on disk: 8 iterations at nThin 2, then 4 more on the
  # inherited nThin 2 -- not the requested 3, which would have written 11.
  expect_equal(.SamplesFileIterations(r2), c(1, 2, 4, 6, 8, 10, 12))
})

test_that("a continuation that does not supply nThin inherits it silently", {
  modelDir <- withr::local_tempdir()
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 8, nChains = 2, nThin = 2, nThreads = 1L,
                      modelDir = modelDir, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)

  expect_no_warning(
    r2 <- RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                        nIter = 4, nThreads = 1L, visualise = FALSE,
                        quiet = TRUE)
  )

  expect_equal(unname(r2[["mcmcSummary"]][["nThin"]])[[1]], 2)
  saveIter <- r2[["mcmcSummary"]][["saveIter"]][[1]]
  expect_true(all(diff(saveIter[-1]) == 2))
  expect_gt(length(saveIter), 5)
  expect_equal(.SamplesFileIterations(r2), c(1, 2, 4, 6, 8, 10, 12))
})

test_that("a continuation with a matching nThin is silent", {
  modelDir <- withr::local_tempdir()
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 8, nChains = 2, nThin = 2, nThreads = 1L,
                      modelDir = modelDir, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)

  expect_no_warning(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                  nIter = 4, nThin = 2, nThreads = 1L, visualise = FALSE,
                  quiet = TRUE)
  )
})

test_that("a freshly built StratMCMC cannot be passed to a continuation", {
  modelDir <- withr::local_tempdir()
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                      nIter = 4, nChains = 2, nThreads = 1L,
                      modelDir = modelDir, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE, saveMCMC = TRUE)

  expect_error(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                  nIter = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  stratMCMC = StratMCMC(stratModel = stratModel1, nIter = 2,
                                        nChains = 2)),
    "run 1 cannot be continued from"
  )

  # The run's own stored checkpoint continues cleanly.
  r2 <- RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                      nIter = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                      stratMCMC = r1[["mcmc"]][[1]])
  expect_s3_class(r2, "StratPosterior")
  expect_gt(max(r2[["mcmcSummary"]][["saveIter"]][[1]]), 4)
})
