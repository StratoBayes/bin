# #1421: the R engine's five post-Gibbs `.UpdateHtBy()` refreshes were called
# without `model`, so the delta-subtraction branch was skipped and `metro$tBy`
# was left as B'y/sigma^2 instead of B'(y - delta)/sigma^2. `.GibbsSample()`
# hands `tBy` straight to `.sb_gibbs`, which uses it verbatim as beta's
# conditional mean (mu = M^-1 tBy), so beta was drawn against the un-offset
# data while sigma and delta were drawn against offset-corrected residuals --
# the sweep no longer targeted its own joint posterior. Only the alignment
# accept path re-derived tBy correctly, so the bias fired on every rejected
# iteration.
#
# Tier-1 maintained-parity core (Gibbs state) per docs/r-engine-contract.md;
# the C++ engine has always been correct here (`refresh_htby_after_gibbs`,
# src/MCMCEngine.cpp).
#
# ORACLE: base-R `crossprod()` on the state's own B, delta and sigma.
# `.UpdateHtBy()` is a thin wrapper over the C++ `.sb_update_htby()`, so
# checking it against that would exercise one implementation twice and could
# not fail.

# The alignment priors are deliberately tight: with the two sites pinned onto
# a common height axis a single spline cannot absorb a between-group shift, so
# delta carries the simulated offset instead of collapsing to zero and the
# dropped B'delta term is large.
.offsetFixture <- function(sigmaFixed = FALSE, gradientProposals = "off") {
  set.seed(11)
  n <- 30
  h <- seq(0, 10, length.out = n)
  signal <- data.frame(
    site   = c(rep("s1", n), rep("s2", n)),
    height = c(h, h),
    value  = c(sin(h) + rnorm(n, 0, 0.1), sin(h) + 3 + rnorm(n, 0, 0.1))
  )
  group <- data.frame(site = c("s1", "s2"), group = c("A", "B"),
                      stringsAsFactors = FALSE)
  data <- StratData(signal = signal, group = group)
  priors <- structure(list(
    "alpha_s2"    = NormalPrior(mean = 0, sd = 0.05),
    "gammaLog_s2" = NormalPrior(mean = 0, sd = 0.05)),
    class = c("list", "StratPrior"))
  model <- StratModel(data, priors = priors, alignmentScale = "height",
                      sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                      sigmaFixed = sigmaFixed)
  list(data = data, model = model,
       mcmc = StratMCMC(model, nIter = 50, nChains = 1,
                        gradientProposals = gradientProposals))
}

# H_m == B_m'B_m / sigma_m^2 and tBy_m == B_m'(y_m - delta_m[group]) / sigma_m^2,
# at the sigma and delta the state itself carries. H is delta-free, so a
# failure confined to tBy is this bug and a failure in both is #508's.
#
# The oracle reuses `offsetConfig$obsToGroup`, so it pins that the delta branch
# ran, not that the obs-to-group mapping is itself right; that mapping is
# pinned separately by test-signal-offsets.R.
.expectOffsetCorrectedHtBy <- function(state, data, model, label) {
  obsToGroup <- model[[c("offsetConfig", "obsToGroup")]]
  values <- data[[c("signalAttr", "signalValuesVec")]]
  for (m in seq_along(state[[c("metro", "B")]])) {
    bMat <- state[[c("metro", "B")]][[m]]
    sigma2 <- state[[c("gibbs", "sigma")]][[m]] ^ 2
    adjusted <- values[[m]] -
      state[[c("gibbs", "delta")]][[m]][obsToGroup[[m]]]
    testthat::expect_equal(
      unname(state[[c("metro", "H")]][[m]] * sigma2), unname(crossprod(bMat)),
      tolerance = 1e-8, info = paste0(label, ", H, signal ", m))
    testthat::expect_equal(
      unname(state[[c("metro", "tBy")]][[m]] * sigma2),
      unname(drop(crossprod(bMat, adjusted))),
      tolerance = 1e-8, info = paste0(label, ", tBy, signal ", m))
  }
}

# Without this the oracle above collapses onto the raw-y one it is meant to
# discriminate from, and the test passes whatever `.UpdateHtBy()` does.
.expectDeltaBites <- function(state, label) {
  testthat::expect_gt(
    max(abs(unlist(state[[c("gibbs", "delta")]]))), 0.1)
  invisible(label)
}

test_that("#1421: the R engine's tBy carries delta across every iteration", {
  fix <- .offsetFixture()

  set.seed(1421)
  state <- .GenerateInitialState(fix$data, fix$model, fix$mcmc, 1)
  .expectOffsetCorrectedHtBy(state, fix$data, fix$model, "initial state")

  accepts <- logical(30)
  for (i in seq_along(accepts)) {
    fix$mcmc[["currentIter"]] <- i
    state <- .UpdateState(fix$data, fix$model, fix$mcmc, state, 1)
    accepts[[i]] <- isTRUE(state[[c("metro", "accept")]])
    .expectOffsetCorrectedHtBy(state, fix$data, fix$model,
                               paste("iteration", i))
    .expectDeltaBites(state, paste("iteration", i))
  }

  # Step 8 runs on both branches, so this is a mixing check, not a branch
  # discriminator: a frozen chain would assert the same state 30 times.
  expect_true(any(accepts))
  expect_true(any(!accepts))
})

test_that("#1421: fixed sigma still needs the delta refresh", {
  # Offsets are redrawn every sweep whatever sigma does, so this arm isolates
  # the dropped delta from #508's stale sigma: H cannot go stale here.
  fix <- .offsetFixture(sigmaFixed = 0.15)

  set.seed(1421)
  state <- .GenerateInitialState(fix$data, fix$model, fix$mcmc, 1)
  for (i in 1:15) {
    fix$mcmc[["currentIter"]] <- i
    state <- .UpdateState(fix$data, fix$model, fix$mcmc, state, 1)
    .expectOffsetCorrectedHtBy(state, fix$data, fix$model,
                               paste("fixed sigma, iteration", i))
    .expectDeltaBites(state, paste("fixed sigma, iteration", i))
    expect_identical(state[[c("gibbs", "sigma")]], 0.15,
                     label = paste("fixed sigma, iteration", i))
  }
})

test_that("#1421: the gradient transitions refresh tBy with delta too", {
  # `.UpdateStateHMC()` and `.UpdateStateNUTS()` carry two post-Gibbs refreshes
  # each (accept and reject), reached only through a gradient proposal.
  fix <- .offsetFixture(gradientProposals = "on")
  gradSlots <- which(names(fix$mcmc[["propose"]]) %in% c("HMC", "NUTS"))
  expect_length(gradSlots, 1L)
  propIdx <- gradSlots[[1]]

  set.seed(1421)
  state <- .GenerateInitialState(fix$data, fix$model, fix$mcmc, 1)

  args <- .HMCDefaultArgs(fix$model)
  args[["adaptStepSize"]] <- FALSE
  args[["divergenceMax"]] <- 1000
  args[["nSteps"]] <- 2L

  Drive <- function(Update, stepSize) {
    mcmc <- fix$mcmc
    stepArgs <- args
    stepArgs[["stepSize"]] <- stepSize
    mcmc[[c("metro", "proposalArgs")]][[1]][[propIdx]] <- stepArgs
    mcmc[["currentIter"]] <- 1L
    set.seed(1421)
    Update(fix$data, fix$model, mcmc, state, chain = 1L,
           proposalNumber = propIdx)
  }

  # A tiny step barely moves the Hamiltonian and is accepted; an oversized one
  # diverges and is rejected, so both refresh sites in each function run.
  Updates <- list(HMC = .UpdateStateHMC, NUTS = .UpdateStateNUTS)
  for (nm in names(Updates)) {
    accepted <- logical(0)
    for (stepSize in c(1e-4, 1e3)) {
      updated <- Drive(Updates[[nm]], stepSize)
      label <- paste(nm, "gradient step", stepSize)
      .expectOffsetCorrectedHtBy(updated, fix$data, fix$model, label)
      .expectDeltaBites(updated, label)
      accepted <- c(accepted, isTRUE(updated[[c("metro", "accept")]]))
    }
    # Both branches must actually have fired; otherwise the pair above pins one
    # of this function's two refresh sites twice and leaves the other dark.
    expect_true(any(accepted), label = paste(nm, "accept branch fired"))
    expect_false(all(accepted), label = paste(nm, "reject branch fired"))
  }
})
