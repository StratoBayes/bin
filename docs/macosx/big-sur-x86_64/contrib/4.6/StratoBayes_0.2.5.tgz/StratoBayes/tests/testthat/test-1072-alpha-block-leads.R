# `ind$alphaNotFixed` is built in `StratModel()` as a position within
# `ind$alpha`, but the `.ProposeShiftAlphas*` proposers compare it against
# `ind$alpha` itself (a parameter-vector index) and write their shift into the
# leading positions of the parameter vector. Both readings agree only while the
# alpha block occupies positions `seq_along(ind$alpha)`. That invariant is
# established solely by `.CreateIndices()`; these tests pin it for every
# alignmentScale x sedModel combination, so a future reordering of the
# parameter vector fails here instead of silently freeing a pinned alpha or
# freezing a free one (#1072).

set.seed(0)
.alphaLeadData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
.alphaLeadStrat <- StratData(.alphaLeadData$signal, parts = .alphaLeadData$parts,
                             ties = .alphaLeadData$ties,
                             signalColumn = c("a", "b"), zColumn = "Hight",
                             siteColumn = "SIT")

test_that("the alpha block leads the parameter vector in every configuration", {
  sedModels <- c("site", "partition", "site x partition", "site, partition")
  for (scale in c("height", "age")) {
    for (sedModel in sedModels) {
      ind <- .CreateIndices(.alphaLeadStrat, alignmentScale = scale,
                            sedModel = sedModel, alphaPosition = "bottom")
      label <- paste(scale, sedModel, sep = " / ")
      expect_identical(ind[["alpha"]], seq_along(ind[["alpha"]]),
                       info = label)
      # names() is what the priors are canonicalised against, so the alphas
      # must lead there too, not merely carry leading indices.
      expect_true(all(startsWith(
        ind[["names"]][seq_along(ind[["alpha"]])], "alpha_")),
        info = label)
      expect_false(any(startsWith(
        ind[["names"]][-seq_along(ind[["alpha"]])], "alpha_")),
        info = label)
    }
  }
})

test_that("the C++ alpha-shift proposers respect a Fixed alpha", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  priors <- stratModel1[["priors"]][["metro"]]
  priors[["alpha_site_3"]] <- Fixed(2)
  model <- StratModel(stratData = stratData1, priors = priors,
                      alignmentScale = stratModel1[["alignmentScale"]],
                      sedModel = stratModel1[["sedModel"]],
                      flexibleKnots = FALSE, knotRange = c(-5, 12))

  # `alpha_site_3` is the *second* alpha, so a mask read at the wrong offset
  # would either move it or freeze `alpha_site_2` in its place.
  expect_identical(model[[c("ind", "alphaNotFixed")]], 1L)

  td <- file.path(tempdir(), "sb1072")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  res <- RunStratModel(stratData1, model, nIter = 200, nChains = 1L, seed = 1,
                       quiet = TRUE, visualise = FALSE, modelDir = td,
                       modelName = "s", engine = "cpp", nThreads = 1L)
  params <- ExtractParameters(res)

  expect_true(all(params[, "alpha_site_3"] == 2))
  # guard against a vacuous pass: the free alpha must actually have moved
  expect_gt(length(unique(params[, "alpha_site_2"])), 1L)
})
