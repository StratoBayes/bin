test_that(".SectionOverlap() works", {
  testSection <- list(c(1, 2, 4, 5, 10.1),
                   c(1, 5),
                   c(5, 6, 7),
                   c(25),
                   30,
                   c(-8, 12),
                   c(2, -2),
                   c(19, -20, 28))
  expectedResult <- list(c(5L, 5L, 4L, 5L, 3L),
                         c(5L, 5L),
                         c(5L, 4L, 4L),
                         2L,
                         1L,
                         c(2L, 2L),
                         c(5L, 3L),
                         c(1L, 1L, 1L))

  expect_error(.SectionOverlap(testSection, countGaps = FALSE),
               "`gapSegments` must be specified")
  overlapOutput <- .SectionOverlap(testSection)
  expect_equal(overlapOutput,expectedResult)
})

test_that(".SectionOverlap works with and without counting gaps", {
  testSection <- list(c(1,2,3), c(1, 4, 5), c(1, 7))

  expectedResult1 <- list(c(3L, 3L, 3L),
                         c(3L, 2L, 2L),
                         c(3L, 1L))

  overlapOutput1 <- .SectionOverlap(testSection)
  expect_equal(overlapOutput1,expectedResult1)


  expectedResult2 <- list(c(3L, 1L, 1L),
                          c(3L, 1L, 1L),
                          c(3L, 1L))

  g1 <- list(matrix(c(1,3)), matrix(c(1,1,2,3), nrow = 2), matrix(c(1,1,2,2), nrow = 2))
  overlapOutput2 <- .SectionOverlap(testSection, FALSE, g1)
  expect_equal(overlapOutput2,expectedResult2)

})

test_that(".SectionOverlapCpp handles all-empty sections without crashing (RT-250)", {
  expect_equal(StratoBayes:::.SectionOverlapCpp(list(numeric(0))),
               list(integer(0)))
  expect_equal(StratoBayes:::.SectionOverlapCpp(list(numeric(0), numeric(0))),
               list(integer(0), integer(0)))
  # mixed case (one empty, one non-empty) still works (RT-028)
  expect_equal(StratoBayes:::.SectionOverlapCpp(list(numeric(0), c(1, 2, 3))),
               list(integer(0), c(1L, 1L, 1L)))
})

test_that(".SectionOverlap(countGaps = FALSE) skips a site with no segments (RT-403)", {
  # A site with no non-NA values for a signal contributes zero gap segments.
  # The re-split arithmetic used to build a DESCENDING index range for it,
  # handing that site its neighbours' segments instead of nothing.
  #
  # Expectations are derived from the definition of the quantity, NOT from
  # either implementation: the overlap count of a datum is the number of
  # sections whose [min age, max age] range contains it.  With the two
  # populated sections spanning [1, 3] and [2, 4]:
  #   age 1 -> in [1,3] only            -> 1
  #   ages 2, 3 -> in both              -> 2
  #   age 4 -> in [2,4] only            -> 1
  # so the populated sites read 1 2 2 and 2 2 1, and the empty site reads
  # nothing at all.
  full <- c(1, 2, 3)
  late <- c(2, 3, 4)
  oneSeg <- matrix(c(1, 3), nrow = 2)          # a single gapless segment
  noSeg <- matrix(numeric(0), nrow = 2, ncol = 0)  # site absent for this signal

  cases <- list(
    first  = list(ages = list(numeric(0), full, late),
                  gaps = list(noSeg, oneSeg, oneSeg),
                  want = list(integer(0), c(1L, 2L, 2L), c(2L, 2L, 1L))),
    middle = list(ages = list(full, numeric(0), late),
                  gaps = list(oneSeg, noSeg, oneSeg),
                  want = list(c(1L, 2L, 2L), integer(0), c(2L, 2L, 1L))),
    last   = list(ages = list(full, late, numeric(0)),
                  gaps = list(oneSeg, oneSeg, noSeg),
                  want = list(c(1L, 2L, 2L), c(2L, 2L, 1L), integer(0)))
  )

  for (pos in names(cases)) {
    case <- cases[[pos]]
    expect_equal(
      .SectionOverlap(case$ages, countGaps = FALSE, gapSegments = case$gaps),
      case$want,
      info = sprintf("empty site in %s position, countGaps = FALSE", pos)
    )
    # The countGaps = TRUE branch treats sites as sections directly; with no
    # gaps in the fixture it must reach the same hand-derived answer.
    expect_equal(
      .SectionOverlap(case$ages, countGaps = TRUE),
      case$want,
      info = sprintf("empty site in %s position, countGaps = TRUE", pos)
    )
  }
})

test_that("
.FindOverlappingSections throws errors when given wrong input and is able to work with non-doubles", {
  expect_equal(.FindOverlappingSections(list(1:4,3:5), c(1,3,4,5), 1:7),
               list(c(1,1,2,3),c(2,3,3)))
  expect_error(.FindOverlappingSections(list("char"), 1, list(1,2)))
  expect_error(.FindOverlappingSections(list("char"), 1, 2))
})
