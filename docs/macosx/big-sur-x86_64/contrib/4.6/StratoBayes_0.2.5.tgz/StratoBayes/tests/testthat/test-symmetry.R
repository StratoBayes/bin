test_that("Matrix symmetric", {
  mat <- matrix(c(0.00, 1.01, 2.01, 3.01,
                  1.00, 0.00, 4.01, 5.01,
                  2.00, 4.00, 0.00, 6.01,
                  3.00, 5.00, 6.00, 0.00), 4, 4)
  orderInd <- which(lower.tri(matrix(0, 4, 4)), arr.ind = TRUE)
  mat <- .MakeSymmetric(mat,orderInd)
  expect_equal(t(mat)[lower.tri(mat)], mat[lower.tri(mat)])

  # RT-086: the above only proves symmetry, which an all-zeros matrix would
  # also satisfy. Pin the actual triangle that was copied: .MakeSymmetric is
  # called with the lower.tri index, so the lower-triangle values (the
  # "+0.01" series) must be the ones propagated into the upper triangle, not
  # the original upper-triangle ("+0.00") values.
  expect_equal(mat[upper.tri(mat)], c(1.01, 2.01, 4.01, 3.01, 5.01, 6.01))
  expect_equal(mat[lower.tri(mat)], c(1.01, 2.01, 3.01, 4.01, 5.01, 6.01))
})
