# Tests for fixed knots (flexibleKnots = FALSE) and NUTS integration
#
# Covers:
#   1. knotRange incompatibility -> clear error (not hang)
#   2. NUTS auto-registration with fixed knots
#   3. NUTS + ties with valid knotRange

# -- Helpers -------------------------------------------------------------------

make_fixed_knot_model <- function(sData, sModel, knotRange) {
  StratoBayes::StratModel(
    stratData = sData,
    priors = sModel$priors$metro,
    alignmentScale = sModel$alignmentScale,
    sedModel = sModel$sedModel,
    flexibleKnots = FALSE,
    knotRange = knotRange
  )
}


# -- knotRange too narrow -> informative error ---------------------------------

test_that("incompatible knotRange errors quickly instead of hanging", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # Use an absurdly narrow knotRange that no prior sample can satisfy
  model <- make_fixed_knot_model(stratData1, stratModel1, c(0, 0.001))

  expect_error(
    RunStratModel(stratData1, model,
                  nIter = 5, nChains = 1, nCores = 1L, engine = "R"),
    "Could not generate a valid initial state"
  )
})

test_that("knotRange error message mentions knotRange and flexibleKnots", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- make_fixed_knot_model(stratData1, stratModel1, c(0, 0.001))

  err <- tryCatch(
    RunStratModel(stratData1, model,
                  nIter = 5, nChains = 1, nCores = 1L, engine = "R",
                  visualise = FALSE),
    error = conditionMessage
  )
  expect_match(err, "knotRange")
  expect_match(err, "flexibleKnots")
})


# -- NUTS registration --------------------------------------------------------
#
# `"auto"` registers NUTS under NEITHER knot setting: benchmarked 14-24x worse
# on ESS/sec with fixed knots and 20-50x worse with flexible knots, on 18/18
# paired seeds each. The fixed-knot arm is the behaviour change (#522); the
# flexible-knot arm was already the default. Both directions are pinned so a
# future default change cannot pass silently.

test_that("gradientProposals = 'auto' registers NUTS under neither knot setting", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  fixed <- make_fixed_knot_model(stratData1, stratModel1, c(-5, 12))
  expect_false(isTRUE(fixed$flexibleKnots))
  mcmcFixed <- StratMCMC(fixed, nIter = 10, nChains = 1)
  expect_false("NUTS" %in% names(mcmcFixed$propose))
  # The two MH-only proposals NUTS used to displace are present instead.
  expect_true(all(c("SiteBlock", "NeighbourScaled") %in% names(mcmcFixed$propose)))

  expect_true(isTRUE(stratModel1$flexibleKnots))
  mcmcFlex <- StratMCMC(stratModel1, nIter = 10, nChains = 1)
  expect_false("NUTS" %in% names(mcmcFlex$propose))
})

test_that("gradientProposals = 'on' registers NUTS with fixed knots", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- make_fixed_knot_model(stratData1, stratModel1, c(-5, 12))
  mcmc <- StratMCMC(model, nIter = 10, nChains = 1, gradientProposals = "on")

  expect_true("NUTS" %in% names(mcmc$propose))
  # Registering NUTS displaces the two MH-only proposals.
  expect_false(any(c("SiteBlock", "NeighbourScaled") %in% names(mcmc$propose)))
})


# -- NUTS + ties ---------------------------------------------------------------

test_that("NUTS works with ties data when knotRange is wide enough", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  # Wide knotRange that encompasses the prior's age range
  model <- make_fixed_knot_model(stratData2, stratModel2, c(-40, 80))

  result <- RunStratModel(stratData2, model,
                          nIter = 50, nChains = 1, nCores = 1L,
                          engine = "cpp")
  expect_s3_class(result, "StratPosterior")
  expect_false(result$model$flexibleKnots)
})

test_that("NUTS + ties with narrow knotRange errors, not hangs", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  model <- make_fixed_knot_model(stratData2, stratModel2, c(-5, 12))

  expect_error(
    RunStratModel(stratData2, model,
                  nIter = 10, nChains = 1, nCores = 1L, engine = "R"),
    "Could not generate a valid initial state"
  )
})
