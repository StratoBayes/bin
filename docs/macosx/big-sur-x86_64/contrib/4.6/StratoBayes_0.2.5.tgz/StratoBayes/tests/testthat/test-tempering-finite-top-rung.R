# The ladder update `dS[j] = A[j - 1] - A[j]` reads the swap link above rung j,
# so the hottest rung -- with no link above it -- cannot be adapted: A holds
# only nChains - 1 links, and `A[nChains]` returns NA. An NA temperature is in
# turn a divisor in its neighbours' swap ratios, so a single non-finite rung
# reaches the whole ladder within a few adaptation rounds, leaving every chain
# but the coldest frozen at a NaN temperature. These tests pin the top rung's
# exemption for a finite ladder as well as a user-supplied `Inf` one.

Ladder <- function(temperatures, ratios, nRows = 4L) {
  nChains <- length(temperatures)
  list(
    nChains = nChains,
    temper = list(
      temperatures = temperatures,
      temperRatioCapped = matrix(rep(ratios, each = nRows), nrow = nRows),
      adaptTemperaturesDecay = FALSE,
      adaptTemperaturesCount = 0,
      temperAdaptIndex = nRows + 1L
    )
  )
}

# Acceptances that are healthy in the middle and poor at both ends, so every
# interior rung has a non-zero dS and genuinely wants to move.
kAccept <- c(0.05, 0.30, 0.40, 0.45, 0.45, 0.40, 0.20)
kFiniteTop <- 80 ^ ((0:7) / 7)

test_that(".UpdateTemperatures keeps a finite top rung finite", {
  result <- .UpdateTemperatures(Ladder(kFiniteTop, kAccept))
  expect_true(all(is.finite(result[["temperatures"]])))
})

test_that(".UpdateTemperatures holds a finite top rung fixed", {
  result <- .UpdateTemperatures(Ladder(kFiniteTop, kAccept))
  expect_identical(result[["temperatures"]][[8]], 80)
})

test_that(".UpdateTemperatures still adapts the interior under a finite top", {
  # Pinning the top rung must not freeze the whole ladder: the point of the fix
  # is that the interior keeps adapting, so a no-op here would be its own bug.
  result <- .UpdateTemperatures(Ladder(kFiniteTop, kAccept))
  interior <- 2:7
  expect_false(isTRUE(all.equal(result[["temperatures"]][interior],
                                kFiniteTop[interior])))
})

test_that("a finite top rung survives repeated adaptation rounds", {
  # The closed feedback loop is what spreads a single bad rung: temperatures[j +
  # 1] divides the link-j swap ratio, so a non-finite rung makes A[j] NaN and
  # sends rung j non-finite at the next round.
  RatiosFor <- function(temperatures) {
    energy <- -c(0, 40, 80, 120, 160, 200, 240, 280)
    Link <- function(j) {
      min(exp((energy[j] - energy[j + 1]) / temperatures[j + 1] +
                (energy[j + 1] - energy[j]) / temperatures[j]), 1)
    }
    vapply(seq_len(length(temperatures) - 1L), Link, numeric(1))
  }

  temperatures <- kFiniteTop
  for (round in seq_len(9L)) {
    ladder <- Ladder(temperatures, RatiosFor(temperatures))
    temperatures <- .UpdateTemperatures(ladder)[["temperatures"]]
  }

  expect_true(all(is.finite(temperatures)))
  expect_false(is.unsorted(temperatures, strictly = TRUE))
})

test_that(".UpdateTemperatures keeps the interior below a pinned finite top", {
  # Nothing in the update rule itself bounds the hottest adapted rung against a
  # pinned top, and an inverted ladder violates the cold -> hot ordering the
  # rule assumes. Acceptances rising towards the top drive rung 7 upwards.
  climbing <- c(0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.01)
  temperatures <- kFiniteTop
  for (round in seq_len(20L)) {
    temperatures <-
      .UpdateTemperatures(Ladder(temperatures, climbing))[["temperatures"]]
  }
  expect_true(all(temperatures[1:7] < 80))
  expect_false(is.unsorted(temperatures, strictly = TRUE))
})

test_that(".UpdateTemperatures leaves a rung alone when its dS is not finite", {
  # An all-NA ratio column gives colMeans(na.rm = TRUE) = NaN. Whatever the
  # cause, a non-finite step must not be written into the ladder.
  mcmc <- Ladder(c(1, 4, 16, Inf), c(0.4, 0.3, 0.2))
  mcmc[[c("temper", "temperRatioCapped")]][, 2] <- NA_real_
  result <- .UpdateTemperatures(mcmc)
  expect_true(all(is.finite(result[["temperatures"]][1:3])))
  expect_identical(result[["temperatures"]][[3]], 16)
})

test_that("a real run keeps a supplied finite-topped ladder usable", {
  # The unit tests above drive .UpdateTemperatures directly, so only this one
  # covers the call site and the C++ push (.sb_update_temperatures). Structural
  # assertions only: the adapted values are not portable across platforms, but
  # "finite, ordered, top pinned" is.
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  nChains <- 6L
  ladder <- 80 ^ ((0:(nChains - 1L)) / (nChains - 1L))
  run <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1L,
                       nIter = 400L, nChains = nChains, tempering = TRUE,
                       temperatures = ladder, adaptTemperatures = TRUE,
                       visualise = FALSE, seed = 1L, runParallel = FALSE,
                       saveMCMC = TRUE, nThreads = 1L)
  mcmc <- readRDS(file.path(run[["modelDir"]],
                            paste0(run[["modelName"]], "_mcmc_run_1.rds")))
  temperatures <- mcmc[[c("temper", "temperatures")]]

  expect_true(all(is.finite(temperatures)))
  expect_false(is.unsorted(temperatures, strictly = TRUE))
  expect_identical(temperatures[[nChains]], 80)
  # ...and adaptation actually happened, rather than the ladder being frozen.
  expect_false(isTRUE(all.equal(temperatures, ladder)))
})

test_that("an Inf-topped ladder adapts to pinned values", {
  # `Inf` is valid user input, though not the default ladder; its top rung is
  # exempt for the same reason a finite one is.
  infLadder <- c(1, 10 ^ (seq_len(6) / 2), Inf)
  result <- .UpdateTemperatures(Ladder(infLadder, kAccept))
  expect_identical(result[["temperatures"]][[1]], 1)
  expect_identical(result[["temperatures"]][[8]], Inf)
  expect_equal(result[["temperatures"]][2:7],
               c(2.68383, 8.87055, 29.43873, 97.81627, 325.12988, 1160.29073),
               tolerance = 1e-5)
})

test_that("StratMCMC warns when only the top rung is above 1", {
  # With two chains an explicit finite ladder has no adaptable rung at all --
  # rung 2 is the top rung -- so half the run's chains buy nothing.
  warnings <- testthat::capture_warnings(
    StratMCMC(stratModel = stratModel1, nIter = 200, nChains = 2,
              temperatures = c(1, 5), adaptTemperatures = TRUE)
  )
  expect_length(warnings, 1)
  expect_match(warnings, "no effect")
})
