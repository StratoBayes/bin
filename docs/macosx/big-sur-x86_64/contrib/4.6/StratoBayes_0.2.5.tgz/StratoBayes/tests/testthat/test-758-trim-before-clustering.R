# The recency trim is scoped to the whole history buffer, not to one cluster:
# a per-cluster trim cannot stop burn-in-era draws choosing the boundaries.

test_that(".RecentStampRows keeps the latest-stamped rows in row order", {
  stamps <- c(3L, 8L, 1L, 6L, 2L, 7L, 4L, 5L)

  keep <- .RecentStampRows(stamps, 8L)

  expect_identical(keep, c(2L, 4L, 6L, 8L))
  expect_identical(sort(stamps[keep]), 5:8)
})

test_that(".RecentStampRows retains the per-cluster trim's row count", {
  for (n in c(4L, 7L, 8L, 33L, 400L)) {
    # deterministic scramble, so no RNG is consumed
    keep <- .RecentStampRows(rev(seq_len(n)), n)
    # `.ClustInfo()` computes the same count, then abandons the trim if it
    # leaves fewer than 3 rows; `.RecentStampRows()` must abandon it too.
    nRecent <- as.integer(n - ceiling(n * 0.5))
    expect_identical(length(keep), if (nRecent >= 3L) nRecent else n)
  }
})

test_that(".RecentStampRows keeps every row when stamps are unusable", {
  n <- 8L
  all <- seq_len(n)

  expect_identical(.RecentStampRows(NULL, n), all)
  expect_identical(.RecentStampRows(1:4, n), all)                # wrong length
  expect_identical(.RecentStampRows(c(NA_integer_, 2:8), n), all) # any NA
})

test_that(".RecentStampRows keeps every row when a trim would be degenerate", {
  expect_identical(.RecentStampRows(1:3, 3L), 1:3)
  expect_identical(.RecentStampRows(1:8, 8L, 1), seq_len(8))
  # 0.3 of 5 rows leaves 1, below the 3 a covariance needs
  expect_identical(.RecentStampRows(1:5, 5L, 0.3), seq_len(5))
})

# With one cut available, clustering the whole buffer spends it on the
# burn-in/recent split, leaving both recent modes in a single cluster
# whose covariance spans the gap between them.
.eraFixture <- function() {
  # 9 burn-in rows far away, 9 recent rows split between two nearby modes.
  burnIn <- cbind(seq(-104, -96, length.out = 9), seq(-4, 4, length.out = 9))
  modeA  <- cbind(c(0, 0.4, 0.8, 0.2, 0.6), rep(0, 5))
  modeB  <- cbind(c(20, 20.4, 20.8, 20.2), rep(0, 4))
  recent <- rbind(modeA[1, ], modeB[1, ], modeA[2, ], modeB[2, ], modeA[3, ],
                  modeB[3, ], modeA[4, ], modeB[4, ], modeA[5, ])

  # Eras interleave by ROW so a positional trim cannot stand in for a
  # stamp one, and the modes alternate by STAMP so the newest half of a
  # merged cluster spans both -- otherwise a per-cluster trim would
  # tighten the covariance by luck.
  rows <- vector("list", 18)
  rows[seq(1, 17, by = 2)] <- split(burnIn, row(burnIn))
  rows[seq(2, 18, by = 2)] <- split(recent, row(recent))
  list(dat = do.call(rbind, rows),
       stamps = as.integer(c(rbind(1:9, 10:18))),
       recent = recent)
}

test_that("a global trim tightens the cluster covariance", {
  d <- .eraFixture()
  n <- nrow(d[["dat"]])
  clustMax <- 2L

  # cluster the whole buffer, then trim inside each cluster
  clustersAll <- .ProtoClusterFast(d[["dat"]], clustMax = clustMax)
  before <- .ClustInfo(d[["dat"]], clustersAll, stamps = d[["stamps"]])

  # trim to the recent window, then cluster only that
  keep <- .RecentStampRows(d[["stamps"]], n)
  clustersRecent <- .ProtoClusterFast(d[["dat"]][keep, , drop = FALSE],
                                      clustMax = clustMax)
  after <- .ClustInfo(d[["dat"]][keep, , drop = FALSE], clustersRecent,
                      recentFraction = 1, stamps = d[["stamps"]][keep])

  # the trim must actually select the recent era, or the rest is vacuous
  expect_setequal(d[["dat"]][keep, 1], d[["recent"]][, 1])

  widest <- function(ci) {
    max(vapply(ci, function(cl) sqrt(cl[[2]][1, 1]), numeric(1)))
  }
  expect_gt(widest(before), 5)      # spans the gap between the two modes
  expect_lt(widest(after), 1)       # within-mode spread only
})

# `clustWithParametersMCMC = FALSE` clusters on the height columns instead of the
# parameter columns, and is the one branch of the trim that no other test drives.
.heightClusterMcmc <- function() {
  nFree <- 2L
  n <- 20L
  set.seed(758)
  # Parameters carry no cluster structure; heights carry two clear groups. A
  # covariance built from the wrong columns therefore yields one cluster, not two.
  params <- matrix(rnorm(n * nFree), n, nFree)
  heights <- cbind(c(rep(0, n / 2), rep(100, n / 2)) + rnorm(n, sd = 0.01),
                   c(rep(0, n / 2), rep(100, n / 2)) + rnorm(n, sd = 0.01))
  hist <- cbind(params, heights, rnorm(n))
  full <- matrix(0, 50L, ncol(hist))
  full[seq_len(n), ] <- hist
  stamps <- as.integer(c(11:15, 1:5, 16:20, 6:10))

  list(
    nChains = 2L, currentIter = 10L, endAdapting = 100L, startAdapting = 1L,
    propose = setNames(vector("list", 1L), "Multivariate"),
    temper = list(temperatures = c(1, 4, NA_real_), tempering = TRUE),
    metro = list(
      historySize = c(n, n), historyLength = 50L, historyRingPos = c(1L, 1L),
      enableRingBuffer = FALSE,
      clustWithParametersMCMC = FALSE,
      clusterHeightIndices = 3:4,
      clustMethodMCMC = "proto", clustMaxMCMC = 5L, clustMinPtsMCMC = 5L,
      nProposals = c(1L, 1L),
      proposalValid = matrix(c(FALSE, FALSE), nrow = 2L, ncol = 1L,
                             dimnames = list(NULL, "Multivariate")),
      proposalProbability = matrix(c(0, 0.5), nrow = 2L, ncol = 1L,
                                   dimnames = list(NULL, "Multivariate")),
      proposalArgs = list(chain1 = list(Multivariate = NULL),
                          chain2 = list(Multivariate = NULL)),
      adaptProposal = c(TRUE, TRUE),
      chainHistory = list(full, full),
      # Newest 10 stamps are rows 1-5 and 11-15, so the retained window spans
      # both height groups; a positional trim would keep rows 11-20 and see only
      # one. Stamp order therefore decides whether two clusters are found.
      historyStamp = list(c(stamps, rep(NA_integer_, 50L - n)),
                          c(stamps, rep(NA_integer_, 50L - n))),
      historyStampNext = c(n + 1L, n + 1L)
    )
  )
}

test_that("the trim reaches the clustWithParametersMCMC = FALSE branch", {
  mcmc <- .heightClusterMcmc()
  model <- list(parametersLength = 2L, parametersLengthNotFixed = 2L,
                ind = list(paramNotFixed = 1:2))

  metro <- .UpdateProposal(data = list(), model = model, mcmc = mcmc,
                           chain = 1L, inLateAdaptation = FALSE)
  args <- metro[["proposalArgs"]][["chain1"]][["Multivariate"]]

  expect_true(metro[["proposalValid"]][1L, "Multivariate"])
  # two clusters means the height columns drove the clustering; the parameter
  # columns alone would have given one
  expect_length(args, 2L)
  # covariance is still over the free PARAMETERS, not the height columns
  expect_identical(dim(args[[1]][[2]]), c(2L, 2L))
})

test_that("trimming twice would discard half the sample again (#758)", {
  # Guards the `mvFraction` branch in `.UpdateProposal()`. The cluster
  # must be big enough that a second trim still leaves 3 rows, or
  # `.ClustInfo()` abandons it and the comparison is vacuous.
  n <- 40L
  dat <- cbind(seq_len(n), 0)
  clusters <- rep(1L, n)
  stamps <- seq_len(n)

  full <- .ClustInfo(dat, clusters, recentFraction = 1, stamps = stamps)
  halved <- .ClustInfo(dat, clusters, stamps = stamps)

  expect_equal(sqrt(full[[1]][[2]][1, 1]), sd(seq_len(n)), tolerance = 1e-3)
  expect_equal(sqrt(halved[[1]][[2]][1, 1]), sd(seq_len(n / 2)),
               tolerance = 1e-3)
})
