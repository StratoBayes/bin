
test_that("TopsPlot works", {
  skip_if_not_snapshot_os()
  expect_error(TopsPlot(1, 2, 2), "'stratPosterior' must be")

  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 1", function() {
    TopsPlot(stratPosterior1)
  })})

test_that("TopsPlot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 2", function() {

    TopsPlot(stratPosterior1, alignment = 1, sites = 3:1,
                 burnIn = 0.95, topsColourScale = "Viridis",
                 colourScale = "Dark 2", topsAlpha = 1,
                 lwd = 2)
  })})

test_that("TopsPlot works with custom settings", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 3", function() {

    TopsPlot(stratPosterior0, alignment = 1, sites = 2:1,
             burnIn = 0.95, topsColourScale = "Viridis",
             colourScale = "Dark 2", topsAlpha = 1, refHeights = c(8, 11),
             topsLwd = 3, topsLty = c(2,3,1,4,5), quantiles = c(0.1, 0.2, 0.3, 0.4, 0.9),
             ylim = c(5, 15), xlim = c(0, 2), ylab = "height (m) ", pch = 1:2)
  })})



test_that("TopsPlot works on depth scale", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("TopsPlot 4", function() {

    TopsPlot(stratPosterior3, xlab = "depth (m)", alignment = 1, refHeights = c(-3, -1, 0))
  })})

# priors TopsPlot not yet implemented
#
# test_that("TopsPlot can plot prior", {
  skip_if_not_snapshot_os()
#   vdiffr::expect_doppelganger("StratMapPlot 4", function() {
#     set.seed(1)
#     StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 100)
#   })})

# test_that("TopsPlot can plot posterior and prior", {
  skip_if_not_snapshot_os()
#   vdiffr::expect_doppelganger("StratMapPlot 5", function() {
#
#     set.seed(1)
#     StratMapPlot(stratPosterior2, prior = TRUE, col = 2:3, tiesColour = 4,
#                  sites = 1:2, pch = 2, cex = 2, lwd = 2)
#   })})


test_that("TopsPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({TopsPlot(stratPosterior1)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("TopsPlot works with refHeightsSite (pseudo-ref site)", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 5 - refHeightsSite site 2", function() {
    TopsPlot(stratPosterior1,
             refHeights = c(0.1, 1, 1.5),
             refHeightsSite = 2,
             alignment = 1,
             quantiles = c(0.1, 0.5, 0.9))
  })
})

test_that("TopsPlot works with refHeightsSite and multiple sites", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("TopsPlot 6 - refHeightsSite with all sites", function() {
    TopsPlot(stratPosterior1,
             refHeights = c(0.1, 3, 4),
             refHeightsSite = 3,
             sites = c(1,3),
             alignment = 1,
             quantiles = c(0.1, 0.5, 0.9),
             topsLwd = 2)
  })
})

test_that("TopsPlot refHeightsSite returns correct data structure", {
  set.seed(1)
  result <- TopsPlot(stratPosterior1,
                      refHeights = c(1, 2),
                      refHeightsSite = 2,
                      alignment = 1,
                      quantiles = c(0.1, 0.5, 0.9),
                      display = FALSE)

  # Check that result is a data frame
  expect_s3_class(result, "data.frame")

  # Check required columns
  expect_true(all(c("refHeight", "site", "quantile", "top") %in% names(result)))

  # Get site names from the data
  sites <- unique(result$site)
  expect_true(length(sites) >= 2)  # Should have at least 2 sites

  # Find input site (site 2) - should be the site that's not "site_1"
  inputSiteName <- sites[sites != "site_1"][1]
  refSiteName <- "site_1"

  # Check that input site (site 2) has same top value for all quantiles per refHeight
  # (all quantiles should equal the input refHeights)
  if (!is.na(inputSiteName)) {
    inputSiteData <- result[result$site == inputSiteName, ]
    if (nrow(inputSiteData) > 0) {
      # Group by refHeight and check that all quantiles have same value
      for (rh in unique(inputSiteData$refHeight)) {
        rhData <- inputSiteData[inputSiteData$refHeight == rh, ]
        if (nrow(rhData) > 1) {
          # All quantiles should have the same top value (the input refHeight)
          uniqueTops <- unique(round(rhData$top, 10))
          expect_equal(length(uniqueTops), 1,
                       info = paste("Input site should have same top value for all quantiles at refHeight", rh))
        }
      }
    }
  }

  # Check that reference site has quantiles (different values from StratMap)
  refSiteData <- result[result$site == refSiteName, ]
  if (nrow(refSiteData) > 0 && length(unique(refSiteData$quantile)) > 1) {
    # For same refHeight, different quantiles should have different top values
    # (these come from StratMap quantiles)
    refHeightGroups <- split(refSiteData$top, refSiteData$refHeight)
    for (rh in names(refHeightGroups)) {
      group <- refHeightGroups[[rh]]
      if (length(group) > 1) {
        # Should have variation across quantiles (StratMap quantiles)
        uniqueVals <- unique(round(group, 8))
        expect_true(length(uniqueVals) > 1,
                    info = paste("Reference site should have different top values across quantiles for refHeight", rh))
      }
    }
  }

  # Verify that reference site quantiles match StratMap output
  set.seed(1)
  stratMapResult <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                              alignment = 1, quantiles = c(0.1, 0.5, 0.9))
  stratMapQuantiles <- as.matrix(stratMapResult[, c("10%", "50%", "90%")])

  # Check that reference site top values match StratMap quantiles
  for (rhIdx in seq_along(c(1, 2))) {
    refHeight <- c(1, 2)[rhIdx]
    refSiteRhData <- refSiteData[refSiteData$refHeight == refHeight, ]
    if (nrow(refSiteRhData) > 0) {
      # Get quantile values from result
      resultQuantiles <- refSiteRhData$top[order(refSiteRhData$quantile)]
      stratMapQuantilesForRh <- as.numeric(stratMapQuantiles[rhIdx, ])

      # Values should match (within rounding)
      expect_equal(round(resultQuantiles, 6), round(stratMapQuantilesForRh, 6),
                   info = paste("Reference site quantiles should match StratMap output for refHeight", refHeight))
    }
  }
})

test_that("TopsPlot refHeightsSite validates input correctly", {
  # Test invalid site
  expect_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 4),
               "must be NULL, a valid site name, or a valid site index")

  # Test invalid site name
  expect_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = "invalid_site"),
               "must be NULL, a valid site name, or a valid site index")

  # Test that refHeightsSite = NULL works (original behavior)
  set.seed(1)
  expect_no_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = NULL, display = FALSE))

  # Test that refHeightsSite = 1 works (reference site)
  set.seed(1)
  expect_no_error(TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 1, display = FALSE))
})

test_that("TopsPlot() rejects a multi-element refHeightsSite with a clear message (RT-721, #913)", {
  # before the fix, a length-2 numeric/character refHeightsSite reached the
  # `||` in the length-1-assuming if/else chain and errored with an opaque
  # "'length = 2' in coercion to 'logical(1)'" instead of a clear message
  expect_error(
    TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = c(2, 3),
             display = FALSE),
    "must identify exactly one site"
  )
  expect_error(
    TopsPlot(stratPosterior1, refHeights = c(1, 2),
             refHeightsSite = c("site_2", "site_3"), display = FALSE),
    "must identify exactly one site"
  )
})

test_that("TopsPlot() resolves a fractional refHeightsSite the same way in both the internal truncation and the StratMap() call (RT-721, #913)", {
  # before the fix, TopsPlot() truncated refHeightsSite = 2.9 to site 2
  # internally, but passed the raw (unresolved) 2.9 to StratMap()'s own
  # `.ValidateSites()`, which rejected it -- two paths disagreeing about the
  # same argument value
  set.seed(1)
  # the truncation is announced since #1296, but must still land on site 2
  expect_warning(
    fractional <- TopsPlot(stratPosterior1, refHeights = c(1, 2),
                           refHeightsSite = 2.9, alignment = 1,
                           display = FALSE),
    "not a whole number")
  set.seed(1)
  truncated <- TopsPlot(stratPosterior1, refHeights = c(1, 2),
                         refHeightsSite = 2, alignment = 1,
                         display = FALSE)
  expect_equal(fractional, truncated)
})

test_that("TopsPlot(quantiles = numeric(0)) errors clearly instead of crashing (RT-197)", {
  expect_error(
    TopsPlot(stratPosterior1, quantiles = numeric(0), display = FALSE),
    "must be a non-empty numeric vector"
  )
})

test_that(".DefaultRefHeightsSite2() survives trailing NA from unequal partition counts (RT-194)", {
  # Regression for RT-194: with a 2-site model, site 2's Bound/BoundLow
  # columns can have trailing NA when site 1 has more partitions than site 2
  # (unequal partition counts). range() without na.rm = TRUE returned
  # c(NA, NA), which propagated into StratMap(heights = c(NA,NA,NA)) and
  # crashed before the later fallback guard.
  dataObj <- list(
    partsAttr = list(
      Bound    = cbind(site1 = c(10, 20, 30), site2 = c(5, 15, NA)),
      BoundLow = cbind(site1 = c(0, 10, 20),  site2 = c(0, 5, NA))
    )
  )

  result <- .DefaultRefHeightsSite2(dataObj)

  expect_true(all(is.finite(result)))
  expect_length(result, 3)
  expect_equal(sort(result)[2], mean(range(c(5, 15, 0, 5))))
})

test_that(".ApplyMarginFrac() insets panel x-bounds by marginFrac of panel width (RT-213)", {
  pltX <- c(0.2, 0.8)
  noMargin <- .ApplyMarginFrac(pltX, 0)
  expect_equal(noMargin, pltX)

  withMargin <- .ApplyMarginFrac(pltX, 0.1)
  expect_false(isTRUE(all.equal(withMargin, pltX)))
  expect_equal(withMargin, pltX + c(1, -1) * 0.1 * diff(pltX))
  expect_true(withMargin[1] > pltX[1])
  expect_true(withMargin[2] < pltX[2])

  # larger marginFrac -> larger inset (measurable effect, RT-213)
  widerMargin <- .ApplyMarginFrac(pltX, 0.2)
  expect_true(diff(widerMargin) < diff(withMargin))
})

test_that("TopsPlot() does not shadow medianIdx when using refHeightsSite (RT-290)", {
  # Regression for RT-290: the medianIdx computed for line-style rendering
  # (from topsLty/nQ) was silently overwritten inside the refHeightsSite
  # branch by an unrelated later assignment. Confirm the two are now
  # distinct variables and the call still runs without error, and that the
  # rendering-related medianIdx still reflects an odd-quantile-count default.
  set.seed(1)
  out <- TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 2,
                  quantiles = c(0.1, 0.5, 0.9), display = FALSE)
  expect_s3_class(out, "data.frame")
})

test_that("TopsPlot() forwards sample-selection args to the default 2-site refHeights StratMap() call (RT-291)", {
  # Regression for RT-291: the default refHeights for a 2-site model were
  # computed via StratMap() called positionally with only
  # (stratObject, heights, site), so alignment/burnIn/etc. supplied by the
  # caller were silently ignored. Mock StratMap() to capture the args it's
  # actually called with, from within TopsPlot()'s default-refHeights branch.
  capturedArgs <- list()
  originalStratMap <- StratoBayes:::StratMap
  testthat::local_mocked_bindings(
    StratMap = function(stratObject, heights, site, ...) {
      capturedArgs[[length(capturedArgs) + 1]] <<- list(...)
      originalStratMap(stratObject, heights, site, ...)
    },
    .package = "StratoBayes"
  )

  set.seed(1)
  TopsPlot(stratPosterior3, alignment = 1, burnIn = 0.25, maxSamples = 50,
           display = FALSE)

  expect_true(length(capturedArgs) >= 1)
  callArgs <- capturedArgs[[1]]
  expect_equal(callArgs[["alignment"]], 1)
  expect_equal(callArgs[["burnIn"]], 0.25)
  expect_equal(callArgs[["maxSamples"]], 50)
})

test_that("TopsPlot() warns and ignores wrong-length topsLty (RT-292)", {
  expect_warning(
    TopsPlot(stratPosterior1, topsLty = c(1, 2), quantiles = c(0.1, 0.5, 0.9),
             display = FALSE),
    "topsLty"
  )
})

test_that("TopsPlot() quantiles error message matches the inclusive check (RT-293)", {
  # The check itself permits exactly 0/1; the message must not claim
  # "strictly between 0 and 1" (which would be false), and quantiles of
  # exactly 0/1 must not error.
  expect_error(
    TopsPlot(stratPosterior1, quantiles = c(-0.1, 0.5), display = FALSE),
    "between 0 and 1"
  )
  expect_no_error(
    TopsPlot(stratPosterior1, quantiles = c(0, 0.5, 1), display = FALSE)
  )
})

test_that("TopsPlot(refHeights = numeric(0)) errors instead of silently falling back (RT-294)", {
  expect_error(
    TopsPlot(stratPosterior1, refHeights = numeric(0), display = FALSE),
    "empty vector"
  )
  # omitting refHeights entirely must still work (uses the computed default)
  set.seed(1)
  expect_no_error(TopsPlot(stratPosterior1, display = FALSE))
})

test_that("TopsPlot(alignment = NA) errors clearly instead of crashing (RT-461)", {
  expect_error(
    TopsPlot(stratPosterior1, alignment = NA, display = FALSE),
    "`alignment` must not contain NA"
  )
})

test_that("TopsPlot(quantiles containing NA) errors clearly instead of crashing on the range check (RT-458)", {
  expect_error(
    TopsPlot(stratPosterior1, quantiles = c(0.5, NA), display = FALSE),
    "must not contain NA"
  )
})

test_that("TopsPlot() drops non-finite refHeights elements with a warning instead of discarding the whole vector (RT-459)", {
  # c(1, 2) are members of the c(0, 1, 2) fallback, so a naive repro with
  # those values would be confounded; use values outside that set.
  expect_warning(
    out <- TopsPlot(stratPosterior1, refHeights = c(5, NA, 7), display = FALSE),
    "non-finite"
  )
  expect_setequal(unique(out[["refHeight"]]), c(5, 7))

  expect_warning(
    outInf <- TopsPlot(stratPosterior1, refHeights = c(5, Inf, 7), display = FALSE),
    "non-finite"
  )
  expect_setequal(unique(outInf[["refHeight"]]), c(5, 7))

  # control: no non-finite elements, no warning, values preserved exactly
  outControl <- expect_no_warning(
    TopsPlot(stratPosterior1, refHeights = c(5, 7), display = FALSE)
  )
  expect_setequal(unique(outControl[["refHeight"]]), c(5, 7))

  # all non-finite: falls back to c(0, 1, 2), with a warning
  expect_warning(
    outAllBad <- TopsPlot(stratPosterior1, refHeights = c(NA, Inf), display = FALSE),
    "non-finite"
  )
  expect_setequal(unique(outAllBad[["refHeight"]]), c(0, 1, 2))
})

test_that("TopsPlot()'s returned refId is a horizon index, not a topsWide row number, at non-reference sites (RT-722, #914)", {
  # Tops()'s output is ordered refHeight-outer x site-inner, so with
  # refHeights = c(1, 2) and sites site_2/site_3, topsWide's rows are
  # (ref1,site2), (ref1,site3), (ref2,site2), (ref2,site3) -- row numbers
  # 1,2,3,4. Before the fix, reshape()'s row-number `id` leaked through as
  # `refId` for this (no-refHeightsSite) branch, giving site_2 refId {1,3}
  # and site_3 refId {2,4} instead of the true horizon index {1,2} at both.
  set.seed(1)
  out <- TopsPlot(stratPosterior1, refHeights = c(1, 2), display = FALSE)

  site2Ids <- sort(unique(out$refId[out$site == "site_2"]))
  site3Ids <- sort(unique(out$refId[out$site == "site_3"]))

  expect_equal(site2Ids, c(1, 2))
  expect_equal(site3Ids, c(1, 2))

  # the horizon index must line up with the actual refHeight value at every
  # site, including the reference site
  expect_true(all(out$refHeight[out$refId == 1] == 1))
  expect_true(all(out$refHeight[out$refId == 2] == 2))
})

test_that("TopsPlot(display = FALSE) does not open a graphics device or write Rplots.pdf (RT-600, #702)", {
  wd <- withr::local_tempdir()
  withr::local_dir(wd)
  # par()/grconvertY() reuse an already-open device instead of opening one,
  # so this must start from no device or the check below is a no-op.
  grDevices::graphics.off()
  expect_null(dev.list())

  out <- TopsPlot(stratPosterior1, display = FALSE)

  expect_null(dev.list())
  expect_false(file.exists(file.path(wd, "Rplots.pdf")))
  expect_s3_class(out, "data.frame")
})
