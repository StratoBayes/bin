# RT-380 (#420): gradient failure at the current state must still perform the
# unconditional Gibbs sweep and refresh the log posteriors.
#
# `update_state_hmc()` / `update_state_nuts()` both begin by evaluating the
# gradient at the CURRENT state.  When that fails — `hmc_eval_gradient()` sets
# ok = FALSE on an age-conversion failure or a non-finite log posterior — there
# is no proposal to accept, so the iteration is a self-transition.  Before the
# fix that self-transition was a bare `return` which set only `accept` and
# `proposalNumber`, skipping:
#
#   (a) the unconditional (beta, sigma, lambda) Gibbs refresh that every other
#       reject path runs — making the composite kernel
#       d(x)·delta_x + (1 - d(x))·K_G, a state-dependent omission of K_G; and
#   (b) the `logPost` / `logPostOld` / `logPostNew` refresh, so those fields
#       described a state the chain had already left (they were left at their
#       initial 0 on the first such iteration).
#
# Reachability in a real run is low (it needs the gradient to fail at a state
# that was itself accepted), so this is driven at the engine level instead: a
# chain whose current `alpha_site_2` sits outside its Uniform(-6, 12) prior has
# log posterior -Inf, hence gradOk = FALSE, deterministically and on every
# iteration.  The un-poisoned arm of each test is the comparator — an ordinary
# NUTS/HMC rejection, which has always run the sweep.

# ── Helpers ──────────────────────────────────────────────────────────────────

# Build a gradient-proposal-only engine setup.  A short R chain supplies fully
# initialised state (including the NUTS mass matrix and dual-averaging state);
# the proposal probabilities are then forced onto the gradient slot alone
# (0 * anyweight = 0, so nothing else is ever selected).  HMC is not in the
# default proposal set — `StratMCMC()` only installs NUTS — so the HMC arm
# renames that slot, which is enough for the engine to dispatch to
# `update_state_hmc()` (`proposal_type_from_string()` keys off the name, and
# the HMC hyperparameters it needs are the ones NUTS already carries).
.rt380_setup <- function(gradProposal = c("NUTS", "HMC"), sigmaFixed = TRUE) {
  gradProposal <- match.arg(gradProposal)

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12), sigmaFixed = sigmaFixed
  )
  td <- file.path(tempdir(), paste0("rt380_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4200)
  RunStratModel(gradientProposals = "on", stratData1, model, nIter = 30, nChains = 1, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  if (gradProposal == "HMC") {
    names(mcmc$propose)[names(mcmc$propose) == "NUTS"] <- "HMC"
    pp <- mcmc[[c("metro", "proposalProbability")]]
    colnames(pp)[colnames(pp) == "NUTS"] <- "HMC"
    mcmc[[c("metro", "proposalProbability")]] <- pp
    pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
    if (!is.null(colnames(pw)))
      colnames(pw)[colnames(pw) == "NUTS"] <- "HMC"
    mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw
  }

  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, which(colnames(pp) == gradProposal)] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  list(data = stratData1, model = model, mcmc = mcmc)
}

# Run a single gradient-proposal iteration and return the chain-1 Gibbs and
# metro state either side of it.  `poison` puts `alpha_site_2` outside its
# prior support, which is what forces gradOk = FALSE.
.rt380_one_iter <- function(s, poison, seed = 99L) {
  state <- s$mcmc$recentState
  if (poison) state[[1]]$metro$parameters[["alpha_site_2"]] <- 20

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc, state)
  before <- StratoBayes:::.sb_extract_state(eng)[[1]]
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, 1L)
  after <- StratoBayes:::.sb_extract_state(eng)[[1]]
  list(before = before, after = after)
}

# ── Tests ────────────────────────────────────────────────────────────────────

for (.prop in c("NUTS", "HMC")) local({
  prop <- .prop

  test_that(paste0("RT-380: ", prop,
                   " gradient failure still runs the Gibbs sweep"), {
    skip_on_cran()

    s <- .rt380_setup(prop)
    ctrl <- .rt380_one_iter(s, poison = FALSE)
    fail <- .rt380_one_iter(s, poison = TRUE)

    # Comparator: an ordinary rejection moves the Gibbs block.  If this ever
    # stops holding the test below is vacuous, so assert it explicitly.
    expect_false(ctrl$after$metro$accept)
    expect_false(isTRUE(all.equal(ctrl$before$gibbs$lambda,
                                  ctrl$after$gibbs$lambda)))

    # The gradient really did fail: no proposal was evaluated, so the parameters
    # are untouched and the iteration is recorded as a rejection.
    expect_false(fail$after$metro$accept)
    expect_equal(fail$after$metro$parameters, fail$before$metro$parameters)
    expect_identical(fail$after$metro$proposalNumber,
                     ctrl$after$metro$proposalNumber)

    # (a) the (beta, sigma, lambda) block was refreshed.  Pre-fix these were
    # bit-identical to `before`, because gibbs_sample_all() never ran.
    expect_false(isTRUE(all.equal(fail$before$gibbs$lambda,
                                  fail$after$gibbs$lambda)))
    expect_false(isTRUE(all.equal(fail$before$gibbs$beta,
                                  fail$after$gibbs$beta)))
  })

  test_that(paste0("RT-380: ", prop,
                   " gradient failure refreshes logPostOld/logPostNew"), {
    skip_on_cran()

    s <- .rt380_setup(prop)
    fail <- .rt380_one_iter(s, poison = TRUE)
    m <- fail$after$metro

    # (b) logPostOld tracks the state actually carried forward — the post-Gibbs
    # one — and logPostNew records that nothing was proposed.  Pre-fix both were
    # left at their initial 0, i.e. neither stale-but-plausible nor -Inf.
    #
    # Only the signal term (`logPostSep[[2]]`) is re-marginalised here, exactly
    # as on an ordinary rejection: the parameters did not move, so the remaining
    # components are as valid as they were on entry.
    expect_equal(m$logPostOld, m$logPost)
    expect_identical(m$logPostNew, -Inf)

    # ...and logPost is the post-Gibbs value, not the pre-call one.
    expect_false(isTRUE(all.equal(fail$before$metro$logPost, m$logPost)))
  })
})

# `stratModel1` fixes sigma, so the `if (!sigmaFixed)` H/tBy rescale inside the
# helper is skipped in every arm above — the tests there prove the fix bundle
# minus that limb.  One free-sigma arm exercises it: sigma must move in the
# re-Gibbs, which is precisely the condition that makes the rescale load-bearing.
test_that("RT-380: gradient failure rescales H/tBy when sigma is free", {
  skip_on_cran()

  s <- .rt380_setup("NUTS", sigmaFixed = FALSE)
  fail <- .rt380_one_iter(s, poison = TRUE)

  expect_false(fail$after$metro$accept)
  expect_false(isTRUE(all.equal(fail$before$gibbs$sigma, fail$after$gibbs$sigma)))
  expect_false(isTRUE(all.equal(fail$before$metro$H, fail$after$metro$H)))
  expect_false(isTRUE(all.equal(fail$before$metro$tBy, fail$after$metro$tBy)))
  expect_equal(fail$after$metro$logPostOld, fail$after$metro$logPost)
})
