# Issue #602: `burnIn = "auto"` reaching the user.
#
# The contract is narrow and worth stating: `"auto"` must be *exactly* a
# numeric burn-in. Every consumer is therefore checked against the same call
# with the resolved number substituted -- if any of them resolved differently,
# late, or not at all, the two results would diverge.

AbResolved <- function(sp) .AutoBurnIn(sp)[["iteration"]]

# `stratPosterior1` does not converge, so every `"auto"` call below warns by
# design; the warning itself is pinned in test-auto-burnin-posterior.R, and
# what is under test here is that the resolved number is used unchanged.
Auto <- function(expr) suppressWarnings(expr)

test_that("every consumer treats \"auto\" as exactly the resolved number", {
  sp <- stratPosterior1
  resolved <- AbResolved(sp)

  # Value-returning consumers, compared directly.
  expect_identical(Auto(ExtractIterations(sp, burnIn = "auto")),
                   ExtractIterations(sp, burnIn = resolved))
  expect_identical(Auto(ExtractParameters(sp, burnIn = "auto")),
                   ExtractParameters(sp, burnIn = resolved))

  # `options` records the call's arguments, and `runSelect` inside it picks up
  # a fastmatch `.match.hash` attribute that makes `identical()` fail on
  # otherwise equal objects; compare the clustering itself.
  autoClust <- Auto(Cluster(sp, burnIn = "auto"))
  fixedClust <- Cluster(sp, burnIn = resolved)
  expect_identical(autoClust[setdiff(names(autoClust), "options")],
                   fixedClust[setdiff(names(fixedClust), "options")])
  expect_identical(autoClust[[c("options", "burnIn")]],
                   fixedClust[[c("options", "burnIn")]])

  # summary() carries an extra `autoBurnIn` element by design; everything the
  # statistics are computed from must still match.
  auto <- Auto(summary(sp, burnIn = "auto"))
  fixed <- summary(sp, burnIn = resolved)
  expect_identical(auto[["alignmentAll"]], fixed[["alignmentAll"]])
  expect_identical(auto[[c("general", "psrf")]], fixed[[c("general", "psrf")]])
  expect_identical(auto[[c("general", "burnInPercent")]],
                   fixed[[c("general", "burnInPercent")]])
})

test_that("plotting consumers treat \"auto\" as exactly the resolved number", {
  sp <- stratPosterior1
  resolved <- AbResolved(sp)

  # Two things stop `identical()` being the oracle here, neither to do with
  # `burnIn`: `plot.StratPosterior()` subsamples points with the RNG, so the
  # calls are seeded; and the returned argument lists carry a fastmatch
  # `.match.hash` attribute whose external pointer differs between two
  # otherwise equal objects.
  Compare <- function(fun, target = resolved) {
    grDevices::pdf(NULL)
    on.exit(grDevices::dev.off(), add = TRUE)
    set.seed(1)
    a <- Auto(fun(sp, burnIn = "auto", display = FALSE))
    set.seed(1)
    b <- fun(sp, burnIn = target, display = FALSE)
    expect_true(isTRUE(all.equal(a, b)))
  }

  for (fun in list(ScatterPlot, BeanPlot, hist, boxplot, plot)) {
    Compare(fun)
  }

  # TracePlot alone falls back to 0, not to the shared fallback: it is read to
  # judge how far the chains have got, and the tail is the wrong end for that.
  # `stratPosterior1` does not converge, so this is the fallback path.
  expect_true(.AutoBurnInFellBack(.AutoBurnIn(sp)[["status"]]))
  Compare(TracePlot, target = 0)
  expect_false(isTRUE(all.equal(
    suppressWarnings(TracePlot(sp, burnIn = "auto", display = FALSE)),
    TracePlot(sp, burnIn = resolved, display = FALSE))))
})

test_that("Tops and StratMap treat \"auto\" as exactly the resolved number", {
  sp <- stratPosterior1
  resolved <- AbResolved(sp)

  expect_identical(Auto(Tops(sp, burnIn = "auto")), Tops(sp, burnIn = resolved))
  # Site 1 is the reference, and site 2 spans 0 to ~2.19; extrapolation errors.
  expect_identical(Auto(StratMap(sp, heights = c(0, 1), site = 2, burnIn = "auto")),
                   StratMap(sp, heights = c(0, 1), site = 2, burnIn = resolved))
})

test_that("only the exact string \"auto\" resolves", {
  sp <- stratPosterior1

  # No partial matching, no case folding: these must reach each consumer's own
  # numeric validation and be rejected there.
  expect_error(ExtractIterations(sp, burnIn = "AUTO"))
  expect_error(ExtractIterations(sp, burnIn = "a"))
  expect_error(ExtractParameters(sp, burnIn = "Auto"))
})

test_that("\"auto\" is refused when there are no posterior draws to choose from", {
  # StratMap and friends also accept a StratModel, which has no samples.
  expect_error(StratMap(stratModel1, stratData = stratData1, burnIn = "auto"),
               "StratPosterior")
})

test_that("summary() reports the automatic burn-in, and only then", {
  sp <- stratPosterior1

  expect_output(print(Auto(summary(sp, burnIn = "auto"))), "[Aa]utomatic burn-in")
  # A numeric burn-in must not gain the extra line.
  expect_false(any(grepl(
    "[Aa]utomatic burn-in",
    utils::capture.output(print(summary(sp, burnIn = 0.5))))))

  expect_null(summary(sp, burnIn = 0.5)[[c("general", "autoBurnIn")]])
  expect_false(is.null(Auto(summary(sp, burnIn = "auto"))[[c("general", "autoBurnIn")]]))
})

test_that("the resolvers behave when called directly", {
  # Called directly as well as through the consumers above: reaching them only
  # via the package namespace leaves these branches untested.
  expect_identical(.ResolveBurnIn(stratPosterior1, 0.3), 0.3)
  expect_error(.ResolveBurnIn(stratModel1, "auto"), "StratPosterior")
  expect_error(.ResolveBurnIn(stratData1, "auto"), "StratPosterior")

  set.seed(2)
  x <- seq(0, 1, length.out = 30)
  spline <- BayesianSpline(x = x, y = x^2 + stats::rnorm(30, 0, 0.05), nIter = 120)
  expect_identical(.ResolveBurnInSpline(spline, 0.25), 0.25)
  expect_true(is.numeric(.ResolveBurnInSpline(spline, "auto")))
})

test_that("a spline missing a stored hyperparameter is still evaluable", {
  # `lambda`/`sigma` shorter than `beta` (a truncated write) become all-NA
  # columns, which the finiteness screen drops rather than erroring on.
  set.seed(3)
  stub <- list(beta = matrix(stats::rnorm(200), 100, 2),
               lambda = numeric(0),
               sigma = rep(1, 100),
               nIter = 100, nThin = 1)

  res <- .AutoBurnInSpline(stub)
  expect_true(res[["status"]] %fin%
                c("ok", "rHatNotReached", "essNotReached", "insufficientDraws"))
  expect_true(is.numeric(res[["iteration"]]))
})

test_that("PredictSpline accepts \"auto\" via the spline resolver", {
  set.seed(1)
  x <- seq(0, 1, length.out = 40)
  spline <- BayesianSpline(x = x, y = sin(2 * pi * x) + stats::rnorm(40, 0, 0.1),
                           nIter = 200)

  # 200 Gibbs iterations of one chain do not converge either, so the spline
  # resolver warns on the same path the posterior one does.
  resolved <- .AutoBurnInSpline(spline)[["iteration"]]
  expect_identical(Auto(PredictSpline(spline, burnIn = "auto")),
                   PredictSpline(spline, burnIn = resolved))

  # The spline sampler has no adaptation phase, so unlike a StratPosterior it
  # may select any stored iteration.
  expect_gte(resolved, 0)
})
