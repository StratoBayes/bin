# Regression tests for issue #209: continued runs must be checked for
# file/object compatibility before anything reads or appends to them.

.FakeStratModel209 <- function(outputParams = c("a", "b"),
                               sigmaFixed = TRUE,
                               flexibleKnots = TRUE,
                               alphaPosition = "middle",
                               sedModel = "site",
                               nKnots = 10,
                               overlapPenalty = TRUE,
                               countGaps = FALSE) {
  structure(
    list(
      outputParams = outputParams,
      sigmaFixed = sigmaFixed,
      flexibleKnots = flexibleKnots,
      alphaPosition = alphaPosition,
      sedModel = sedModel,
      splineBase = list(nKnots = nKnots),
      overlapPenalty = list(overlapPenalty = overlapPenalty, countGaps = countGaps)
    ),
    class = c("StratModel", "list")
  )
}

.FakeStratData209 <- function(signalNames = "value",
                              sites = c("s1", "s2"),
                              N = c(10, 10)) {
  structure(
    list(
      sites = sites,
      signalAttr = list(signalNames = signalNames, N = setNames(N, sites))
    ),
    class = c("StratData", "list")
  )
}

# .CheckSamplesFileHeader --------------------------------------------------

test_that(".CheckSamplesFileHeader passes silently when the header matches the model", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b"))
  writeLines(paste(c("iteration", "chain", "a", "b"), collapse = "\t"),
             file.path(dir, "m_samples_run_1.txt"))

  expect_silent(StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 1))
})

test_that(".CheckSamplesFileHeader errors on a wrong column count", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b", "c"))
  writeLines(paste(c("iteration", "chain", "a", "b"), collapse = "\t"),
             file.path(dir, "m_samples_run_1.txt"))

  expect_error(
    StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 1),
    "m_samples_run_1\\.txt' has 4 column\\(s\\) but the current model expects 5"
  )
})

test_that(".CheckSamplesFileHeader errors on a renamed column at equal column count", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b"))
  writeLines(paste(c("iteration", "chain", "a", "X"), collapse = "\t"),
             file.path(dir, "m_samples_run_1.txt"))

  expect_error(
    StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 1),
    "column 4 is named 'X' but the current model expects 'b'"
  )
})

test_that(".CheckSamplesFileHeader skips a missing samples file", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b"))

  expect_silent(StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 1))
})

test_that(".CheckSamplesFileHeader skips a completely empty samples file", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b"))
  file.create(file.path(dir, "m_samples_run_1.txt"))

  expect_silent(StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 1))
})

test_that(".CheckSamplesFileHeader checks every run up to nRun", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209(outputParams = c("a", "b"))
  writeLines(paste(c("iteration", "chain", "a", "b"), collapse = "\t"),
             file.path(dir, "m_samples_run_1.txt"))
  writeLines(paste(c("iteration", "chain", "a", "Y"), collapse = "\t"),
             file.path(dir, "m_samples_run_2.txt"))

  expect_error(
    StratoBayes:::.CheckSamplesFileHeader(dir, "m", model, 2),
    "m_samples_run_2\\.txt"
  )
})

# .CheckModelAgainstStored --------------------------------------------------

test_that(".CheckModelAgainstStored passes silently for an identical model", {
  dir <- withr::local_tempdir()
  model <- .FakeStratModel209()
  saveRDS(model, file.path(dir, "m_model.rds"))

  expect_silent(StratoBayes:::.CheckModelAgainstStored(model, dir, "m"))
})

test_that(".CheckModelAgainstStored skips when no stored model.rds exists", {
  dir <- withr::local_tempdir()

  expect_silent(StratoBayes:::.CheckModelAgainstStored(.FakeStratModel209(), dir, "m"))
})

test_that(".CheckModelAgainstStored skips when the stored .rds is not a StratModel", {
  dir <- withr::local_tempdir()
  saveRDS(list(foo = 1), file.path(dir, "m_model.rds"))

  expect_silent(StratoBayes:::.CheckModelAgainstStored(.FakeStratModel209(), dir, "m"))
})

test_that(".CheckModelAgainstStored errors when outputParams length differs", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratModel209(outputParams = c("a", "b", "c")),
          file.path(dir, "m_model.rds"))
  supplied <- .FakeStratModel209(outputParams = c("a", "b"))

  expect_error(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    "has 2 output parameter\\(s\\); the model stored in 'm_model\\.rds' has 3"
  )
})

test_that(".CheckModelAgainstStored errors when outputParams names differ at equal length", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratModel209(outputParams = c("a", "b")),
          file.path(dir, "m_model.rds"))
  supplied <- .FakeStratModel209(outputParams = c("a", "x"))

  expect_error(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    "output parameter 2 is 'x'; the model stored in 'm_model\\.rds' has 'b'"
  )
})

test_that(".CheckModelAgainstStored warns (not errors) when only a consequential setting differs", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratModel209(sigmaFixed = TRUE), file.path(dir, "m_model.rds"))
  supplied <- .FakeStratModel209(sigmaFixed = FALSE)

  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
    "sigmaFixed"
  )
})

test_that(".CheckModelAgainstStored warns on each consequential setting in turn", {
  # `.FakeStratModel209()` takes a parameter per key of `keys`
  # (`R/RunStratModel.R:3155`), but only `sigmaFixed` was ever varied, so
  # dropping any of the other six from `keys` went unnoticed. One case each.
  altered <- list(
    sigmaFixed = FALSE, flexibleKnots = FALSE, alphaPosition = "base",
    sedModel = "section", nKnots = 12, overlapPenalty = FALSE, countGaps = TRUE
  )

  for (key in names(altered)) {
    dir <- withr::local_tempdir()
    saveRDS(.FakeStratModel209(), file.path(dir, "m_model.rds"))
    supplied <- do.call(.FakeStratModel209, altered[key])

    expect_warning(
      StratoBayes:::.CheckModelAgainstStored(supplied, dir, "m"),
      key,
      label = paste("altering", key)
    )
  }

  # Discriminator: the stored and supplied defaults are otherwise identical, so
  # nothing warns when nothing is altered.
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratModel209(), file.path(dir, "m_model.rds"))
  expect_silent(
    StratoBayes:::.CheckModelAgainstStored(.FakeStratModel209(), dir, "m")
  )
})

test_that(".CheckModelAgainstStored ignores a field absent from the stored object", {
  dir <- withr::local_tempdir()
  stored <- .FakeStratModel209()
  stored[["sedModel"]] <- NULL  # simulate an older stored model missing a field
  saveRDS(stored, file.path(dir, "m_model.rds"))

  expect_silent(StratoBayes:::.CheckModelAgainstStored(.FakeStratModel209(), dir, "m"))
})

# .CheckDataAgainstStored ----------------------------------------------------

test_that(".CheckDataAgainstStored passes silently for identical data", {
  dir <- withr::local_tempdir()
  data <- .FakeStratData209()
  saveRDS(data, file.path(dir, "m_data.rds"))

  expect_silent(StratoBayes:::.CheckDataAgainstStored(data, dir, "m"))
})

test_that(".CheckDataAgainstStored skips when no stored data.rds exists", {
  dir <- withr::local_tempdir()

  expect_silent(StratoBayes:::.CheckDataAgainstStored(.FakeStratData209(), dir, "m"))
})

test_that(".CheckDataAgainstStored skips when the stored .rds is not a StratData", {
  dir <- withr::local_tempdir()
  saveRDS(list(foo = 1), file.path(dir, "m_data.rds"))

  expect_silent(StratoBayes:::.CheckDataAgainstStored(.FakeStratData209(), dir, "m"))
})

test_that(".CheckDataAgainstStored errors when signal names differ", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratData209(signalNames = "value"), file.path(dir, "m_data.rds"))
  supplied <- .FakeStratData209(signalNames = "other")

  expect_error(
    StratoBayes:::.CheckDataAgainstStored(supplied, dir, "m"),
    "has signals \\(other\\); the data stored in 'm_data\\.rds' has \\(value\\)"
  )
})

test_that(".CheckDataAgainstStored errors when sites are reordered", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratData209(sites = c("s1", "s2"), N = c(10, 20)),
          file.path(dir, "m_data.rds"))
  supplied <- .FakeStratData209(sites = c("s2", "s1"), N = c(20, 10))

  expect_error(
    StratoBayes:::.CheckDataAgainstStored(supplied, dir, "m"),
    "has sites \\(s2, s1\\); the data stored in 'm_data\\.rds' has \\(s1, s2\\)"
  )
})

test_that(".CheckDataAgainstStored errors when per-site observation counts differ", {
  dir <- withr::local_tempdir()
  saveRDS(.FakeStratData209(sites = c("s1", "s2"), N = c(10, 10)),
          file.path(dir, "m_data.rds"))
  supplied <- .FakeStratData209(sites = c("s1", "s2"), N = c(10, 20))

  expect_error(
    StratoBayes:::.CheckDataAgainstStored(supplied, dir, "m"),
    "different number of observations per site"
  )
})

# Defect 1: modelDir/data.rds call-site bug -------------------------------

test_that("RunStratModel gives a clear error when `_data.rds` is missing", {
  dir <- withr::local_tempdir()
  name <- "nodatarun"
  file.create(file.path(dir, paste0(name, "_model.rds")))
  writeLines("nRun = 1", file.path(dir, paste0(name, "_options.txt")))
  file.create(file.path(dir, paste0(name, "_samples_run_1.txt")))
  file.create(file.path(dir, paste0(name, "_mcmc_run_1.rds")))

  expect_error(
    RunStratModel(modelDir = dir, modelName = name, quiet = TRUE),
    paste0(name, "_data\\.rds")
  )
})

# End-to-end wiring: the checks fire from RunStratModel() itself ------------

test_that("RunStratModel continuation succeeds cleanly when nothing has changed", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                      nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)

  expect_error(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                 nIter = 2, visualise = FALSE, quiet = TRUE),
    NA
  )

  # Continuing from the in-memory StratPosterior object itself exercises the
  # StratPosterior branch's model/data checks, not just the modelDir branch.
  expect_error(
    RunStratModel(r1, nIter = 2, visualise = FALSE, quiet = TRUE),
    NA
  )
})

test_that("RunStratModel errors when continuing with a stratModel of a different parameter layout", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                      nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)

  brokenModel <- StratModel(stratData = stratData1, priors = stratPrior1,
                            alignmentScale = "height", sedModel = "site",
                            alphaPosition = "bottom", nKnots = 15,
                            overlapPenalty = TRUE, sigmaFixed = FALSE)

  expect_error(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                 stratModel = brokenModel, nIter = 2, visualise = FALSE, quiet = TRUE),
    "output parameter"
  )
})

test_that("RunStratModel errors when the stored samples header no longer matches the model", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                      nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)

  samplesFile <- file.path(r1[["modelDir"]],
                           paste0(r1[["modelName"]], "_samples_run_1.txt"))
  lines <- readLines(samplesFile)
  header <- strsplit(lines[[1]], "\t", fixed = TRUE)[[1]]
  header[[3]] <- "corrupted_column"
  lines[[1]] <- paste(header, collapse = "\t")
  writeLines(lines, samplesFile)

  expect_error(
    RunStratModel(modelDir = r1[["modelDir"]], modelName = r1[["modelName"]],
                 nIter = 2, visualise = FALSE, quiet = TRUE),
    "corrupted_column"
  )
})
