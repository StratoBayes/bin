# RT-433 blast-radius sweep: regression tests for the validation now living in
# thin wrappers (AGENTS.md, "C++ error paths -- wrapper validates,
# implementation never throws"). Each of these throws was moved out of a large
# `*_impl` frame; these tests exist so the arm64-only CI run actually exercises
# every throw path added or relocated by the sweep, not just that the package
# builds. See test-cpp-engine-guards.R for the pre-existing splineOrder guard
# tests this file complements.
#
# make_guard_test_engine() is duplicated (not sourced) from
# test-cpp-engine-guards.R: top-level helpers defined in a `test-*.R` file are
# not shared across files under `R CMD check`/`devtools::test()` (only
# `helper-*.R` files are), so each test file that needs it carries its own copy
# -- the same reason memcheck/SplineOrderGuardTest.R duplicates it rather than
# sourcing a testthat file.

make_guard_test_engine <- function(sData, sModel, seed = 7261, knotRange = NULL) {
  if (isTRUE(sModel$flexibleKnots) && !is.null(knotRange)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      sigmaFixed = sModel$sigmaFixed,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }

  td <- file.path(tempdir(), paste0("errwrap_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = sData,
    stratModel  = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gtest",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gtest_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  list(
    data_obj = data_obj, model_obj = model_obj,
    mcmc_obj = mcmc_obj, state_obj = state_obj,
    tiesCallback = tiesCallback, td = td
  )
}

test_that("sb_create_engine rejects an unknown alignmentScale", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_model <- setup$model_obj
  bad_model$ind$alignmentScale <- "not-a-real-scale"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = bad_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown alignment scale"
  )
})

test_that("sb_create_engine rejects an unknown sedModel", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_model <- setup$model_obj
  bad_model$ind$sedModel <- "not-a-real-sedModel"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = bad_model,
      mcmc = setup$mcmc_obj, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown sedModel"
  )
})

test_that("sb_create_engine rejects an unknown proposal type", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_mcmc <- setup$mcmc_obj
  names(bad_mcmc$propose)[1] <- "NotARealProposalType"

  expect_error(
    StratoBayes:::.sb_create_engine(
      data = setup$data_obj, model = setup$model_obj,
      mcmc = bad_mcmc, state = setup$state_obj,
      tiesCallback = setup$tiesCallback
    ),
    "Unknown proposal type"
  )
})

# RT-325's construction-time refusal of flexibleKnots + a gradient proposal is
# gone: compute_logpost_gradient (Gradient_impl.h) carries the
# params -> ageRange -> knots -> B chain rule. Coverage of the surviving
# behaviour is test-flexible-knots-gradient.R's end-to-end NUTS run, which
# reaches .sb_create_engine through a legitimately NUTS-registered mcmc object.

test_that("sb_eval_logpost rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_eval_logpost(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_eval_logpost(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_compute_gradient rejects an out-of-range chain", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )

  expect_error(
    StratoBayes:::.sb_compute_gradient(engine_ptr, 99L),
    "chain must be between"
  )
})

test_that("sb_gradient_at rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_gradient_at(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_gradient_at(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_hmc_eval_logpost rejects an out-of-range chain and a mismatched params length", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nParam <- setup$model_obj$parametersLength

  expect_error(
    StratoBayes:::.sb_hmc_eval_logpost(engine_ptr, 0L, rep(0, nParam)),
    "chain must be between"
  )
  expect_error(
    StratoBayes:::.sb_hmc_eval_logpost(engine_ptr, 1L, rep(0, nParam + 1L)),
    "params must have length"
  )
})

test_that("sb_sync_gibbs rejects an out-of-range chain", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nSig <- setup$model_obj$nSignals %||% length(setup$model_obj$sedModel)

  expect_error(
    StratoBayes:::.sb_sync_gibbs(engine_ptr, 99L, list(0), 1, 1),
    "chain must be between"
  )
})

test_that("sb_compute_gradient returns a finite gradient under flexibleKnots (both paths)", {
  # RT-307 made debug = TRUE call the production compute_logpost_gradient, so
  # both paths inherit the flexible-knot chain rule and neither refuses.
  # Value-level agreement with finite differences is
  # test-flexible-knots-gradient.R's job; this only pins that the wrappers do
  # not reject the combination.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)  # flexibleKnots = TRUE
  on.exit(unlink(setup$td, recursive = TRUE))
  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  nFree <- setup$model_obj$parametersLengthNotFixed

  plain <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L, debug = FALSE)
  expect_length(plain$grad, nFree)
  expect_true(all(is.finite(plain$grad)))

  dbg <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L, debug = TRUE)
  expect_equal(dbg$grad, plain$grad)
  expect_length(dbg$grad_prior, setup$model_obj$parametersLength)
})

test_that(".sb_logpost(marginal = TRUE) requires lambda and Dmat", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))
  model_obj <- setup$model_obj
  data_obj  <- setup$data_obj

  x <- model_obj$metroParams %||% rep(0.1, model_obj$parametersLength)
  priorTypes <- vapply(model_obj$priors$metro, function(p) p$prior %||% "", character(1))

  expect_error(
    StratoBayes:::.sb_logpost(
      x = x, priorTypes = priorTypes, priorArgs = list(), rCustomFns = list(),
      B_list = list(), beta_list = list(), signalValues = list(),
      sigma = rep(1, data_obj$S), overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = TRUE, lambda = NULL, Dmat = NULL
    ),
    "requires lambda and Dmat"
  )
})

test_that(".sb_logpost validates the joint-at-beta lambda/Dmat conformability", {
  # The flexible-knot joint branch indexes lambda per signal and Dmat up to each
  # signal's basis dimension. Those three checks live in the wrapper, not in the
  # ~140-line impl frame they guard (RT-433).
  # No parameters: the prior loop is a no-op, so the call exercises the joint
  # signal branch alone.
  nBas <- 4L
  B <- matrix(1, nrow = 3L, ncol = nBas)

  callJoint <- function(lambda, Dmat) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0),
      priorArgs = list(), rCustomFns = list(),
      B_list = list(B), beta_list = list(rep(0, nBas)),
      signalValues = list(rep(0, 3L)),
      sigma = 1, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      marginal = FALSE, lambda = lambda, Dmat = Dmat
    )
  }

  expect_error(callJoint(numeric(0), diag(nBas)),
               "lambda is shorter than the number of signals")
  expect_error(callJoint(1, matrix(1, nBas, nBas - 1L)), "Dmat must be square")
  expect_error(callJoint(1, diag(nBas - 1L)),
               "does not match the spline basis")
  expect_silent(callJoint(1, diag(nBas)))
})

test_that("sb_age_convert rejects an unknown alignmentScale and sedModel", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- make_guard_test_engine(stratData1, stratModel1)
  on.exit(unlink(setup$td, recursive = TRUE))

  bad_ind_scale <- setup$model_obj$ind
  bad_ind_scale$alignmentScale <- "not-a-real-scale"
  expect_error(
    StratoBayes:::.sb_age_convert(setup$data_obj, bad_ind_scale, rep(0, setup$model_obj$parametersLength)),
    "Alignment must be on height or age scale"
  )

  bad_ind_sed <- setup$model_obj$ind
  bad_ind_sed$sedModel <- "not-a-real-sedModel"
  expect_error(
    StratoBayes:::.sb_age_convert(setup$data_obj, bad_ind_sed, rep(0, setup$model_obj$parametersLength)),
    "Unknown sedModel"
  )
})
