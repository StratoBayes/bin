# #711: `.ClustInfo`'s `recentFraction` trim must follow insertion order, not row
# position. Under the default `enableRingBuffer = FALSE` the chain history is a
# random-replacement reservoir, so a positional trim keeps a random half and
# leaves burn-in dispersion in the Multivariate proposal's covariance.

# Rows interleave early (far, wide) and late (near, tight) states, so the
# positional "recent half" still contains early rows.
.stampFixture <- function() {
  early <- cbind(c(100, 101, 102, 103), c(100, 101, 102, 103))
  late <- cbind(c(0, 1, 2, 3), c(0, -1, -2, -3))
  list(
    dat = rbind(early[1, ], late[1, ], early[2, ], late[2, ],
                early[3, ], late[3, ], early[4, ], late[4, ]),
    stamps = c(1L, 5L, 2L, 6L, 3L, 7L, 4L, 8L),
    late = late
  )
}

.haarioRidge <- function(x) {
  covMat <- cov(x)
  covMat + 0.001 * mean(diag(covMat)) * diag(nrow(covMat))
}

test_that(".ClustInfo trims to the latest-stamped rows (#711)", {
  d <- .stampFixture()
  clusters <- rep(1L, 8)

  result <- .ClustInfo(d[["dat"]], clusters, stamps = d[["stamps"]])

  expect_length(result, 1)
  expect_equal(result[[1]][[1]], colMeans(d[["late"]]))
  expect_equal(result[[1]][[2]], .haarioRidge(d[["late"]]))

  # Without stamps the positional trim keeps rows 5:8, half of them early: the
  # mean is dragged to ~52 and the covariance inflated by ~3 orders of magnitude.
  positional <- .ClustInfo(d[["dat"]], clusters)
  expect_gt(positional[[1]][[1]][1], 50)
  expect_gt(max(diag(positional[[1]][[2]])), 1000)
})

test_that(".ClustInfo stamps are subset per cluster, not globally (#711)", {
  d <- .stampFixture()
  # Two clusters, each interleaving its own early/late rows.
  dat <- rbind(d[["dat"]], d[["dat"]] + 1000)
  clusters <- rep(1:2, each = 8)
  stamps <- c(d[["stamps"]], d[["stamps"]] + 8L)

  result <- .ClustInfo(dat, clusters, stamps = stamps)

  expect_length(result, 2)
  expect_equal(result[[1]][[1]], colMeans(d[["late"]]))
  expect_equal(result[[2]][[1]], colMeans(d[["late"]] + 1000))
})

test_that(".ClustInfo stamping is a no-op on chronologically ordered rows (#711)", {
  d <- .stampFixture()
  clusters <- rep(1L, 8)

  expect_identical(.ClustInfo(d[["dat"]], clusters, stamps = seq_len(8)),
                   .ClustInfo(d[["dat"]], clusters))
})

test_that(".ClustInfo ignores unusable stamps (#711)", {
  d <- .stampFixture()
  clusters <- rep(1L, 8)
  positional <- .ClustInfo(d[["dat"]], clusters)

  naStamps <- d[["stamps"]]
  naStamps[3] <- NA_integer_
  expect_identical(.ClustInfo(d[["dat"]], clusters, stamps = naStamps),
                   positional)
  expect_identical(.ClustInfo(d[["dat"]], clusters, stamps = 1:4),
                   positional)
})

test_that(".ClustInfo leaves the RNG stream untouched with stamps (#711)", {
  d <- .stampFixture()
  set.seed(1)
  before <- .Random.seed
  .ClustInfo(d[["dat"]], rep(1L, 8), stamps = d[["stamps"]])
  expect_identical(.Random.seed, before)
})


# ---- history writers ---------------------------------------------------------

.stampModel <- list(heightsForClustering = list(), siteIndices = integer(0),
                    parametersLength = 2L)

# `withStamp = FALSE` reproduces a `metro` saved before #711.
.stampMetro <- function(historyLength, withStamp = TRUE,
                        enableRingBuffer = FALSE) {
  metro <- list(
    historyLength = historyLength,
    acceptanceLength = 10L,
    clustWithParametersMCMC = TRUE,
    enableRingBuffer = enableRingBuffer,
    historySize = 0L,
    historyRingPos = 1L,
    chainHistory = list(matrix(0, nrow = historyLength, ncol = 3L)),
    acceptance = array(NA_real_, dim = c(1L, 10L, 1L)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
  )
  if (withStamp) {
    metro[["historyStamp"]] <- list(rep(NA_integer_, historyLength))
    metro[["historyStampNext"]] <- 1L
  }
  metro
}

.stampSaveStates <- function(metro, params, inLateAdaptation = FALSE) {
  mcmc <- list(temper = list(temperatures = 1), metro = metro)
  for (k in seq_len(nrow(params))) {
    state <- list(list(metro = list(
      parameters = params[k, ], logPost = -k, accept = TRUE,
      proposalNumber = 1L
    )))
    mcmc[["metro"]] <- .SaveMCMChistory(
      data = NULL, model = .stampModel, mcmc = mcmc, state = state,
      inLateAdaptation = inLateAdaptation
    )
  }
  mcmc[["metro"]]
}

test_that(".SaveMCMChistory stamps reservoir writes in insertion order (#711)", {
  params <- cbind(1:4, 1:4)
  metro <- .stampSaveStates(.stampMetro(4L), params)
  expect_identical(metro[["historyStamp"]][[1]], 1:4)
  expect_identical(metro[["historyStampNext"]], 5L)

  # Buffer full: the fifth state overwrites a random row, whose stamp must
  # become the newest wherever it lands.
  set.seed(711)
  metro <- .stampSaveStates(metro, cbind(9, 9), inLateAdaptation = TRUE)
  stamps <- metro[["historyStamp"]][[1]]
  expect_identical(sum(stamps == 5L), 1L)
  expect_equal(metro[["chainHistory"]][[1]][which(stamps == 5L), ],
               c(9, 9, -1))
})

test_that("history writers tolerate a metro saved before stamps existed (#711)", {
  params <- cbind(1:3, 1:3)
  metro <- .stampSaveStates(.stampMetro(4L, withStamp = FALSE), params)
  expect_identical(metro[["historySize"]], 3L)
  expect_null(metro[["historyStamp"]])

  mcmc <- list(temper = list(temperatures = 1),
               metro = .stampMetro(4L, withStamp = FALSE))
  historyData <- list(list(count = 3L, parameters = params, logPost = -(1:3),
                           accept = rep(TRUE, 3), proposalNumber = rep(1L, 3)))
  bulk <- .BulkSaveMCMChistory(model = .stampModel, mcmc = mcmc,
                               historyData = historyData,
                               inLateAdaptation = FALSE)
  expect_identical(bulk[["historySize"]], 3L)
  expect_null(bulk[["historyStamp"]])
})

test_that(".BulkSaveMCMChistory stamps identically to .SaveMCMChistory (#711)", {
  params <- cbind(1:3, 1:3)
  perIter <- .stampSaveStates(.stampMetro(4L), params)

  mcmc <- list(temper = list(temperatures = 1), metro = .stampMetro(4L))
  historyData <- list(list(count = 3L, parameters = params, logPost = -(1:3),
                           accept = rep(TRUE, 3), proposalNumber = rep(1L, 3)))
  bulk <- .BulkSaveMCMChistory(model = .stampModel, mcmc = mcmc,
                               historyData = historyData,
                               inLateAdaptation = FALSE)

  expect_identical(bulk[["historyStamp"]], perIter[["historyStamp"]])
  expect_identical(bulk[["historyStampNext"]], perIter[["historyStampNext"]])
})


# ---- continued runs ----------------------------------------------------------

.stampContinuation <- function(oldStamp) {
  histLen <- 5L
  oldMetro <- list(
    historyLength = histLen,
    acceptanceLength = 10L,
    historySize = 3L,
    historyRingPos = 1L,
    chainHistory = list(cbind(1:5, 1:5, -(1:5))),
    acceptance = array(NA_real_, dim = c(1L, 10L, 1L)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
  )
  if (!is.null(oldStamp)) {
    oldMetro[["historyStamp"]] <- list(oldStamp)
    oldMetro[["historyStampNext"]] <- max(oldStamp, na.rm = TRUE) + 1L
  }
  list(
    mcmc = list(temper = list(temperatures = 1), nChains = 1L,
                metro = oldMetro),
    mcmcNew = list(temper = list(temperatures = 1), nChains = 1L,
                   metro = .stampMetro(histLen), recentState = NULL)
  )
}

test_that("a continued run carries insertion order forward (#711)", {
  # Reservoir stamps are not monotone in row position; the transfer must copy
  # them, not renumber by row.
  f <- .stampContinuation(c(7L, 3L, 5L, NA_integer_, NA_integer_))
  out <- .UpdateMCMCforContinuedRun(f[["mcmc"]], f[["mcmcNew"]],
                                    newRun = FALSE)

  expect_identical(out[[c("metro", "historySize")]], 3L)
  expect_identical(out[[c("metro", "historyStamp")]][[1]][1:3], c(7L, 3L, 5L))
  expect_identical(out[[c("metro", "historyStampNext")]], 8L)
})

test_that("a continued run into a shorter buffer keeps the newest rows (#711)", {
  oldStamp <- c(11L, 12L, 13L, 14L, 15L, 16L, 17L, 18L)
  mcmc <- list(
    temper = list(temperatures = 1), nChains = 1L,
    metro = list(
      historyLength = 8L, acceptanceLength = 10L, historySize = 8L,
      historyRingPos = 1L, historyStamp = list(oldStamp),
      historyStampNext = 19L,
      chainHistory = list(cbind(1:8, 1:8, -(1:8))),
      acceptance = array(NA_real_, dim = c(1L, 10L, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    )
  )
  mcmcNew <- list(temper = list(temperatures = 1), nChains = 1L,
                  metro = .stampMetro(5L), recentState = NULL)

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  expect_identical(out[[c("metro", "historySize")]], 5L)
  expect_equal(out[[c("metro", "chainHistory")]][[1]], cbind(4:8, 4:8, -(4:8)))
  expect_identical(out[[c("metro", "historyStamp")]][[1]], oldStamp[4:8])
  expect_identical(out[[c("metro", "historyStampNext")]], 19L)
  # Buffer is now exactly full; next write wraps to row 1.
  expect_identical(out[[c("metro", "historyRingPos")]], 1L)
})

test_that("a continued run from a pre-stamp save neither errors nor leaves NAs (#711)", {
  f <- .stampContinuation(NULL)
  out <- .UpdateMCMCforContinuedRun(f[["mcmc"]], f[["mcmcNew"]],
                                    newRun = FALSE)

  expect_identical(out[[c("metro", "historySize")]], 3L)
  expect_identical(out[[c("metro", "historyStamp")]][[1]][1:3], 1:3)
  expect_identical(out[[c("metro", "historyStampNext")]], 4L)
  # Transferred rows are unchanged by the fabricated stamps.
  expect_equal(out[[c("metro", "chainHistory")]][[1]][1:3, ],
               cbind(1:3, 1:3, -(1:3)))
})


# ---- run wiring --------------------------------------------------------------

# Every test above builds `metro` by hand, so all of them stay green if a real
# run stops producing stamps: `.SaveMCMChistory()` skips stamping when the slot
# is absent, `.RecentStampRows()` then keeps every row and `.ClustInfo()` falls
# back to its positional trim, silently undoing #711 and #758.
#
# The two cases below split that into production (a run leaves usable stamps in
# `metro`) and consumption (`.UpdateProposal()` hands those stamps to
# `.RecentStampRows()`). Production alone is not enough: the consumption test
# calls `.RecentStampRows()` itself, so deleting the two lines that supply the
# stamps at `R/mcmcFunctions.R:356`/`:377` leaves it green.

test_that("StratMCMC() creates a stamp slot per chain (#711)", {
  mcmc <- StratMCMC(stratModel = stratModel1, nIter = 4, nChains = 2)

  expect_identical(lengths(mcmc[[c("metro", "historyStamp")]]),
                   rep(as.integer(mcmc[[c("metro", "historyLength")]]), 2))
  expect_identical(mcmc[[c("metro", "historyStampNext")]], rep(1L, 2))
})

test_that("a completed run leaves stamps the trim can use (#711)", {
  modelDir <- withr::local_tempdir()
  run <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                       nIter = 60, nChains = 3, nThreads = 1L,
                       modelDir = modelDir, visualise = FALSE, seed = 1,
                       runParallel = FALSE, quiet = TRUE)
  mcmc <- .ReadMCMC(NULL, run[["modelDir"]], run[["modelName"]], nRun = 1)[[1]]
  metro <- mcmc[["metro"]]

  # History is accumulated for finite-temperature chains only, and the default
  # ladder is finite throughout, so that is every chain.
  chains <- which(is.finite(mcmc[[c("temper", "temperatures")]]))
  expect_length(chains, 3)

  for (chain in chains) {
    at <- paste("chain", chain)
    nFilled <- metro[["historySize"]][chain]
    stamps <- metro[["historyStamp"]][[chain]][seq_len(nFilled)]

    # Enough rows for a trim to keep 3 after halving, but too few to fill the
    # buffer -- so no reservoir replacement has happened yet and the stamps are
    # exactly the insertion order.
    expect_gt(nFilled, 5, label = paste(at, "historySize"))
    expect_lt(nFilled, metro[["historyLength"]],
              label = paste(at, "historySize"))
    expect_identical(sort(stamps), seq_len(nFilled),
                     label = paste(at, "stamps"))
    expect_true(all(stamps < metro[["historyStampNext"]][chain]),
                label = paste(at, "stamps below historyStampNext"))

    # `.UpdateProposal()` reads these; unusable stamps trim nothing at all.
    expect_lt(length(.RecentStampRows(stamps, nFilled)), nFilled,
              label = paste(at, "trimmed row count"))
  }

  # Consumption: nothing above would notice if `.UpdateProposal()` stopped
  # passing the stamps on, since every call to `.RecentStampRows()` so far has
  # been this file's own.
  seen <- list()
  real <- .RecentStampRows
  local_mocked_bindings(
    .RecentStampRows = function(stamps, n, ...) {
      seen[[length(seen) + 1L]] <<- list(stamps = stamps, n = n)
      real(stamps, n, ...)
    },
    .package = "StratoBayes"
  )
  .UpdateProposal(run[["data"]], run[["model"]], mcmc, 1, FALSE)

  # One call per chain update: only the Multivariate proposal clusters.
  expect_length(seen, 1)
  nFilled <- metro[["historySize"]][1]
  expect_equal(seen[[1]][["n"]], nFilled)
  expect_identical(seen[[1]][["stamps"]],
                   metro[["historyStamp"]][[1]][seq_len(nFilled)])
})
