test_that("print.StratData can print a stratData1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratData1))
})

test_that("print.StratData can print a stratData2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratData2))
})

test_that("print.StratModel can print stratModel1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratModel1))
})

test_that("print.StratModel can print stratModel2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratModel2))
})

test_that("print.StratPosterior can print stratPosterior1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratPosterior1))
})

test_that("print.StratPosterior can print stratPosterior2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratPosterior2))
})

test_that("print.StratPosterior reports true totals when runs differ", {
  x <- stratPosterior1
  x[[c("mcmcSummary", "saveIter")]][[1]] <-
    x[[c("mcmcSummary", "saveIter")]][[1]][1:50]
  x[[c("mcmcSummary", "completedIter")]][1] <- 1250

  out <- capture.output(print(x))
  expect_match(out[1], "after 1250 to 5000 iterations:", fixed = TRUE)
  expect_match(out[2], "Samples: 452 (50 to 201 per run)", fixed = TRUE)
})
