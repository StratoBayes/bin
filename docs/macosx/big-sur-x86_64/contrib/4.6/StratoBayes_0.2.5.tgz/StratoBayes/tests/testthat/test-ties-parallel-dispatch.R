# Regression tests for #511: a user-supplied tie `densityFun` broke
# `runParallel = TRUE`.
#
# `.BuildTiesDispatch()` resolves each tie's `densityFun` *name* with
# `match.fun()`. That resolution used to happen inside the `future`
# multisession worker, and a function that only ever appears as a character
# value in `data$tiesAttr` is invisible to future's globals detection, so it was
# never exported: every worker died with
# "object '<name>' of mode 'function' was not found". `RunStratModel()` now
# resolves the dispatch in the parent process and ships the closures to the
# workers with the model.

{ # Initialize -- two sites, one tie whose density is user-supplied.

  # The name has to be resolvable by `match.fun()` from inside the package
  # namespace (both `.CheckTies()` and `.BuildTiesDispatch()` do that), so the
  # function goes in globalenv() under a distinctive name. Evaluating the
  # `function` expression *in* globalenv() also makes `environment(fn)` the
  # global environment, which is what `.AnyTiesDensityFromGlobalEnv()` looks
  # for. The body deliberately references nothing but `stats::dnorm`: a free
  # variable looked up in the caller's globalenv would not travel to a worker.
  assign(".sb511TieDensity",
         eval(quote(function(x, mean, sd, log = TRUE)
           stats::dnorm(x, mean = mean, sd = sd, log = log)),
           envir = globalenv()),
         envir = globalenv())
  withr::defer(suppressWarnings(rm(".sb511TieDensity", envir = globalenv())),
               testthat::teardown_env())

  sb511Signal <- signalData1[signalData1[["site"]] %in% c("site_1", "site_2"), ]
  sb511Priors <- structure(
    list(alpha_site_2 = stratPrior1[["alpha_site_2"]],
         gammaLog_site_2 = stratPrior1[["gammaLog_site_2"]]),
    class = c("list", "StratPrior"))

  # `alignmentScale = "height"` drops site 1 from the dispatch
  # (`seq_len(S)[-1]`), so the tie has to sit on site 2 to be exercised at all.
  sb511TiesCustom <- data.frame(site = "site_2", height = 4,
                                densityFun = ".sb511TieDensity",
                                arg1 = 5, arg2 = 5)
  sb511TiesDnorm <- data.frame(site = "site_2", height = 4,
                               densityFun = "dnorm", arg1 = 5, arg2 = 5)

  sb511Data <- StratData(sb511Signal, ties = sb511TiesCustom)
  sb511Model <- StratModel(sb511Data, sb511Priors, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "bottom",
                           nKnots = 8)

  # Collect warnings without letting them abort or surface, so a test can assert
  # on their absence as well as their presence.
  sb511WithWarnings <- function(expr) {
    warnings <- character()
    value <- withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      })
    list(value = value, warnings = warnings)
  }
}

test_that(".AnyTiesDensityFromGlobalEnv identifies a global-environment density", {
  dispatchCustom <- .BuildTiesDispatch(sb511Data, sb511Model)
  dispatchDnorm <- .BuildTiesDispatch(StratData(sb511Signal, ties = sb511TiesDnorm),
                                      sb511Model)

  # Guard against both checks going vacuous if the fixture's tie ever stopped
  # reaching the dispatch table.
  expect_length(dispatchCustom[["dispatch"]][[2]], 1)
  expect_length(dispatchDnorm[["dispatch"]][[2]], 1)

  expect_true(.AnyTiesDensityFromGlobalEnv(dispatchCustom))
  # `stats::dnorm` lives in a namespace environment, never globalenv().
  expect_false(.AnyTiesDensityFromGlobalEnv(dispatchDnorm))
  # No ties at all -> `.BuildTiesDispatch()` returns NULL.
  expect_false(.AnyTiesDensityFromGlobalEnv(NULL))
})

test_that("RunStratModel() hoists the ties dispatch into the parent process (#511)", {
  # The hoist is what makes a custom density survive the trip to a worker, so
  # pin it directly: intercept `.InnerRunMCMC()` and inspect the model it is
  # handed. Cheap enough to run on the sequential path -- the hoist happens
  # before the parallel/sequential split.
  captured <- new.env(parent = emptyenv())
  modelDir <- withr::local_tempdir()

  testthat::local_mocked_bindings(
    .InnerRunMCMC = function(...) {
      captured[["args"]] <- list(...)
      NULL
    },
    .package = "StratoBayes")

  # The mock writes no samples, so the compile step downstream fails; the
  # captured arguments are all this test needs.
  try(suppressMessages(suppressWarnings(
    RunStratModel(sb511Data, stratModel = sb511Model, nRun = 1, nIter = 10,
                  nChains = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  seed = 1, runParallel = FALSE,
                  modelDir = modelDir, modelName = "sb511hoist")
  )), silent = TRUE)

  expect_false(is.null(captured[["args"]]))
  dispatch <- captured[["args"]][["model"]][[".tiesDispatch"]]
  expect_false(is.null(dispatch))
  expect_true(is.function(dispatch[["dispatch"]][[2]][[1]][["fn"]]))

  # The dispatch goes on a copy of the model, never on the one that is
  # persisted or returned.
  persisted <- readRDS(file.path(modelDir, "sb511hoist_model.rds"))
  expect_null(persisted[[".tiesDispatch"]])
})

test_that(".InnerRunMCMC() uses a supplied dispatch instead of re-resolving it (#511)", {
  # A worker cannot see the user's `densityFun` binding. Reproduce that
  # in-process: capture the arguments `RunStratModel()` sends, remove the
  # binding, and call `.InnerRunMCMC()` for real. With the parent-built
  # dispatch it runs; drop the dispatch and it fails exactly as every parallel
  # worker used to.
  realInnerRunMCMC <- .InnerRunMCMC
  captured <- new.env(parent = emptyenv())
  captureDir <- withr::local_tempdir()

  testthat::local_mocked_bindings(
    .InnerRunMCMC = function(...) {
      captured[["args"]] <- list(...)
      NULL
    },
    .package = "StratoBayes")

  try(suppressMessages(suppressWarnings(
    RunStratModel(sb511Data, stratModel = sb511Model, nRun = 1, nIter = 10,
                  nChains = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  seed = 1, runParallel = FALSE,
                  modelDir = captureDir, modelName = "sb511inner")
  )), silent = TRUE)
  expect_false(is.null(captured[["args"]]))

  tieDensity <- get(".sb511TieDensity", envir = globalenv())
  rm(".sb511TieDensity", envir = globalenv())
  on.exit(assign(".sb511TieDensity", tieDensity, envir = globalenv()),
          add = TRUE)

  # The pre-fix failure mode, in the environment a worker actually has.
  expect_error(.BuildTiesDispatch(sb511Data, sb511Model),
               "of mode 'function' was not found")

  withDispatch <- captured[["args"]]
  withDispatch[["modelDir"]] <- withr::local_tempdir()
  expect_no_error(do.call(realInnerRunMCMC, withDispatch))

  withoutDispatch <- captured[["args"]]
  withoutDispatch[["model"]][[".tiesDispatch"]] <- NULL
  withoutDispatch[["modelDir"]] <- withr::local_tempdir()
  expect_error(do.call(realInnerRunMCMC, withoutDispatch),
               "of mode 'function' was not found")
})

test_that("a custom tie densityFun runs sequentially without warning (#511)", {
  modelDir <- withr::local_tempdir()

  run <- sb511WithWarnings(
    RunStratModel(sb511Data, stratModel = sb511Model, nRun = 1, nIter = 20,
                  nChains = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  seed = 1, runParallel = FALSE,
                  modelDir = modelDir, modelName = "sb511seq"))

  expect_s3_class(run[["value"]], "StratPosterior")
  # The global-environment advisory is specific to parallel workers.
  expect_false(any(grepl("global environment", run[["warnings"]], fixed = TRUE)))
  # No resolved closures on the returned or persisted model.
  expect_null(run[[c("value", "model")]][[".tiesDispatch"]])
  expect_null(readRDS(file.path(modelDir, "sb511seq_model.rds"))[[".tiesDispatch"]])
})

test_that("the global-environment advisory is gated on workers actually spawning", {
  # `runParallel = TRUE` with `nRun = 1` never reaches `future_lapply()`, so the
  # closure never leaves this process and there is nothing to advise about.
  modelDir <- withr::local_tempdir()

  run <- sb511WithWarnings(
    RunStratModel(sb511Data, stratModel = sb511Model, nRun = 1, nIter = 20,
                  nChains = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  seed = 1, runParallel = TRUE, nCores = 2L,
                  modelDir = modelDir, modelName = "sb511single"))

  expect_s3_class(run[["value"]], "StratPosterior")
  expect_false(any(grepl("global environment", run[["warnings"]], fixed = TRUE)))
})

test_that("a custom tie densityFun survives runParallel = TRUE (#511)", {
  skip_on_cran()  # spawns worker processes
  skip_if_not_installed("future.apply")
  # `future` workers `library(StratoBayes)`, i.e. they load the *installed*
  # build, not the one `devtools::load_all()` put in this session. In a dev
  # session this test would therefore report on whatever is installed; run it
  # only against an installed build (`R CMD check`, or a tarball install).
  skip_if(!file.exists(file.path(find.package("StratoBayes"), "R",
                                 "StratoBayes.rdb")),
          "dev session: parallel workers would load the installed build")

  modelDir <- withr::local_tempdir()

  # nCores = 2L, nThreads = 1L: two worker processes, one thread each.
  run <- sb511WithWarnings(
    RunStratModel(sb511Data, stratModel = sb511Model, nRun = 2, nIter = 20,
                  nChains = 2, nThreads = 1L, visualise = FALSE, quiet = TRUE,
                  seed = 1:2, runParallel = TRUE, nCores = 2L,
                  modelDir = modelDir, modelName = "sb511par"))

  # Before the fix both workers died in `match.fun()`.
  expect_s3_class(run[["value"]], "StratPosterior")
  expect_equal(run[[c("value", "nRun")]], 2)

  # The density is defined in globalenv(), so the advisory warning fires.
  expect_true(any(grepl("defined in your global environment",
                        run[["warnings"]], fixed = TRUE)))

  expect_null(run[[c("value", "model")]][[".tiesDispatch"]])
  expect_null(readRDS(file.path(modelDir, "sb511par_model.rds"))[[".tiesDispatch"]])
})
