# RT-133: with no intermediate chain temperature (always the case with
# nChains = 2, where rung 2 is the unadaptable top rung), `adaptTemperatures =
# TRUE` silently does nothing -- tIndices is empty and .UpdateTemperatures's
# update loop never runs. The user should be told, exactly once, and only if
# they actually asked for temperature adaptation.
#
# The warning itself has moved from `.UpdateTemperatures()` (called once per
# adaptation window, so it used to fire dozens of times per run) to
# `StratMCMC()` setup time, where the resolved temperature ladder is already
# known and the condition is static for the whole run.

test_that(".UpdateTemperatures leaves temperatures unchanged with no intermediate chain (RT-133)", {
  mcmc <- list(
    nChains = 2,
    temper = list(
      temperatures = c(1, Inf),
      temperRatioCapped = matrix(NA_real_, 1, 1),
      adaptTemperaturesDecay = 5,
      adaptTemperaturesCount = 0,
      temperAdaptIndex = 1
    )
  )

  expect_no_warning(result <- .UpdateTemperatures(mcmc))
  expect_equal(result[["temperatures"]], c(1, Inf))
  # temperAdaptIndex should not be reset by the (skipped) update logic
  expect_equal(result[["temperAdaptIndex"]], 1)
})

test_that(".UpdateTemperatures updates temperatures normally with nChains > 2 (RT-133 regression guard)", {
  mcmc <- list(
    nChains = 3,
    temper = list(
      temperatures = c(1, 2, Inf),
      temperRatioCapped = matrix(c(0.2, 0.8), 1, 2),
      adaptTemperaturesDecay = 5,
      adaptTemperaturesCount = 0,
      temperAdaptIndex = 1
    )
  )

  expect_no_warning(result <- .UpdateTemperatures(mcmc))
  expect_false(isTRUE(all.equal(result[["temperatures"]], c(1, 2, Inf))))
  expect_equal(result[["temperAdaptIndex"]], 1)
})

test_that("StratMCMC emits no warning with default adaptTemperatures and nChains = 2 (RT-133)", {
  expect_no_warning(
    StratMCMC(stratModel = stratModel1, nIter = 10, nChains = 2)
  )
})

test_that("StratMCMC warns exactly once when adaptTemperatures is explicitly TRUE with nChains = 2 (RT-133)", {
  warnings <- testthat::capture_warnings(
    mcmc <- StratMCMC(stratModel = stratModel1, nIter = 200, nChains = 2,
                       adaptTemperatures = TRUE)
  )
  expect_length(warnings, 1)
  expect_match(warnings, "no effect")
  # sampler setup must be unaffected by the warning
  expect_equal(mcmc[[c("temper", "temperatures")]], c(1, 1.9))
})

test_that("StratMCMC warns exactly once when `adapt = TRUE` with nChains = 2 (RT-133)", {
  warnings <- testthat::capture_warnings(
    StratMCMC(stratModel = stratModel1, nIter = 200, nChains = 2, adapt = TRUE)
  )
  expect_length(warnings, 1)
  expect_match(warnings, "no effect")
})

# An adaptable rung needs a swap link on both sides, so the smallest finite
# ladder that warrants silence has three chains: with two, rung 2 is the top
# rung, which adaptation cannot move (test-tempering-finite-top-rung.R).
test_that("a finite ladder with an adaptable rung is silent (RT-133)", {
  expect_no_warning(
    StratMCMC(stratModel = stratModel1, nIter = 200, nChains = 3,
              temperatures = c(1, 5, 25), adaptTemperatures = TRUE)
  )
})

test_that("StratMCMC does not warn when nChains > 2 and adaptTemperatures is explicit (RT-133 regression guard)", {
  expect_no_warning(
    StratMCMC(stratModel = stratModel1, nIter = 200, nChains = 3,
              adaptTemperatures = TRUE)
  )
})

# The RunStratModel() path, not just StratMCMC() direct. `.BuildContinuationMCMC()`
# reaches StratMCMC() through `do.call()`, which names every argument, so without
# the forwarded `.adaptTemperaturesExplicit` the forwarded default reads as a user
# request and RT-133's noise returns on every default nChains = 2 run. This is the
# one test here that discriminates the forwarding; the two continuation tests
# below would pass without it.
test_that("a fresh RunStratModel run does not warn with default adaptTemperatures and nChains = 2 (RT-133)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  warnings0 <- character(0)
  withCallingHandlers(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                  nChains = 2, visualise = FALSE, seed = 1, runParallel = FALSE,
                  saveMCMC = TRUE, nThreads = 1L),
    warning = function(w) {
      warnings0 <<- c(warnings0, conditionMessage(w))
      invokeRestart("muffleWarning")
    })

  expect_false(any(grepl("has no effect", warnings0)))
})

# RT-133 x RT-310 contract: freezing the shared adaptation window by default
# (RT-310) makes StratMCMC() coerce `adaptTemperatures` to FALSE, so the warning
# must stay silent; an explicit request unlocks the window, so it must speak.
test_that("a frozen continuation does not warn about no-op adaptTemperatures (RT-133 x RT-310)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                      nChains = 2, visualise = FALSE, seed = 1, runParallel = FALSE,
                      saveMCMC = TRUE, nThreads = 1L)
  m1 <- readRDS(file.path(r1[["modelDir"]],
                          paste0(r1[["modelName"]], "_mcmc_run_1.rds")))
  # Sanity: no intermediate temperature, so RT-133's condition is live at all.
  expect_identical(m1[[c("temper", "temperatures")]], c(1, 1.9))

  warnings1 <- character(0)
  r2 <- withCallingHandlers(
    RunStratModel(r1, nIter = 50, runParallel = FALSE, visualise = FALSE,
                  nThreads = 1L),
    warning = function(w) {
      warnings1 <<- c(warnings1, conditionMessage(w))
      invokeRestart("muffleWarning")
    })
  m2 <- readRDS(file.path(r2[["modelDir"]],
                          paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  expect_false(any(m2[[c("metro", "adaptProposal")]]))
  expect_false(m2[[c("temper", "adaptTemperatures")]])
  expect_false(any(grepl("has no effect", warnings1)))
})

test_that("an explicitly unlocked continuation does warn about no-op adaptTemperatures (RT-133 x RT-310)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                      nChains = 2, visualise = FALSE, seed = 1, runParallel = FALSE,
                      saveMCMC = TRUE, nThreads = 1L)

  warnings2 <- character(0)
  r2 <- withCallingHandlers(
    RunStratModel(r1, nIter = 200, runParallel = FALSE, visualise = FALSE,
                  nThreads = 1L, adaptTemperatures = TRUE),
    warning = function(w) {
      warnings2 <<- c(warnings2, conditionMessage(w))
      invokeRestart("muffleWarning")
    })
  m2 <- readRDS(file.path(r2[["modelDir"]],
                          paste0(r2[["modelName"]], "_mcmc_run_1.rds")))

  # Explicit request unlocks the shared window -- proposal adaptation reopens
  # too (a documented coupling, not independent control).
  expect_true(any(m2[[c("metro", "adaptProposal")]]))
  expect_true(m2[[c("temper", "adaptTemperatures")]])
  expect_true(any(grepl("has no effect", warnings2)))
})
