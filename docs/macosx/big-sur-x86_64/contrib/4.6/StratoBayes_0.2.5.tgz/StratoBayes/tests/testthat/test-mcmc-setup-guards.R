# Guards for silent MCMC-setup misconfigurations.
#
# RT-273: .UpdateState() selects a proposal type with
#   sample.int(prob = proposalProbabilityWeights[chain, ] * proposalProbability[chain, ]).
# StratMCMC() guarantees the Prior weight (column 1) is positive, so the weights
# alone can never be all-zero -- but the *product* with the adapted proposal
# probabilities can be, e.g. when onlyMultivariateProposalsAfterAdapt zeros every
# proposalProbability but Multivariate and the user also set the Multivariate
# weight to 0. sample.int() then aborts with the opaque base-R error
# "too few positive probabilities". The guard turns that into an actionable stop().
#
# RT-272: on the C++ engine, a model that needs R callbacks (custom prior
# densities or tie densities not natively supported in C++) has
# canParallelize = FALSE, so chains run sequentially even when nThreads > 1.
# .sb_set_threads() now emits a message so the requested speed-up is not silently
# dropped.
#
# RT-690: the C++ engine's "Prior" proposal for a custom prior must sample via
# priorsProposals[[p]]'s own R function AND its own args, not the prior's args.

# ── RT-273: proposal-selection guard ─────────────────────────────────────────

test_that("RT-273: .UpdateState errors clearly when no proposal has positive probability", {
  nProp <- 3L
  # weights x probability = c(1,0,1) * c(0,1,0) = c(0,0,0)
  mcmc <- list(metro = list(
    nProposals                 = list(nProp),
    proposalProbabilityWeights = matrix(c(1, 0, 1), nrow = 1),
    proposalProbability        = matrix(c(0, 1, 0), nrow = 1)
  ))
  expect_error(
    .UpdateState(NULL, NULL, mcmc, NULL, 1L),
    "no MCMC proposal has positive selection probability"
  )
})

test_that("RT-273: guard does not fire when at least one proposal has positive probability", {
  nProp <- 3L
  # product = c(1,2,0) * c(0.5,0.5,0) = c(0.5,1,0): positive, must pass the guard.
  mcmc <- list(metro = list(
    nProposals                 = list(nProp),
    proposalProbabilityWeights = matrix(c(1, 2, 0), nrow = 1),
    proposalProbability        = matrix(c(0.5, 0.5, 0), nrow = 1)
  ))
  # The call continues past the guard and fails downstream (no propose/model),
  # so the only thing asserted is that it is NOT the RT-273 guard error.
  msg <- tryCatch({
    .UpdateState(NULL, NULL, mcmc, NULL, 1L)
    NA_character_
  }, error = function(e) conditionMessage(e))
  expect_false(isTRUE(grepl("no MCMC proposal has positive selection", msg)))
})

# ── RT-272: silent-sequential warning on the C++ engine ──────────────────────

test_that("RT-272: cpp engine warns when R callbacks force sequential execution despite nThreads > 1", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  # A custom D closure (not a built-in density) makes .InferPriorType() return
  # "" -> PT_CUSTOM -> the engine needs an R callback -> canParallelize = FALSE.
  customD <- function(x, mean, sd, log = TRUE) dnorm(x, mean = mean, sd = sd, log = log)
  cp <- Prior(R = function(n, mean, sd) rnorm(n, mean = mean, sd = sd),
              D = customD, Q = qnorm, mean = 0, sd = 10)
  stratModel1$priors$metro[[1]]  <- cp
  stratModel1$priorsProposals[[1]] <- cp

  td <- file.path(tempdir(), paste0("rt272_", sample.int(1e6, 1)))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mcmc <- StratMCMC(stratModel1, nIter = 6, nChains = 2, nThreads = 2)

  expect_message(
    RunStratModel(stratData1, stratModel1, mcmc, seed = 1, quiet = TRUE,
                  visualise = FALSE, modelDir = td, modelName = "rt272",
                  engine = "cpp"),
    "running chains sequentially despite"
  )
})

# ── T-124 / T-163: R-engine Tier-3 boundary is CI-enforced ───────────────────
#
# The R MCMC engine is a frozen reference (docs/r-engine-contract.md): Tier-3
# features (multithreading, partial tempering, any post-2026-07-17 sampler
# feature) are C++-only. The contract's enforcement clause requires the Tier-3
# boundary to be pinned by CI, not memory. The one Tier-3 feature reachable
# today is threading: `RunStratModel` auto-switches `engine = "R"` -> "cpp" when
# nThreads > 1 (T-124, RunStratModel.R). This test pins that behaviour. The
# error-path guard for a *new* Tier-3 config (e.g. partial tempering, PR #347)
# is added when that feature lands and its config params exist to reject.

test_that("T-124: R engine auto-switches to C++ when nThreads > 1 (Tier-3 boundary)", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  td <- file.path(tempdir(), paste0("t124_", sample.int(1e6, 1)))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mcmc <- StratMCMC(stratModel1, nIter = 6, nChains = 1, nThreads = 2)

  # engine = "R" + nThreads > 1 must inform the user of the switch, not silently
  # honour a threading request the R engine cannot serve.
  expect_message(
    post <- RunStratModel(stratData1, stratModel1, mcmc, seed = 1, quiet = TRUE,
                          visualise = FALSE, modelDir = td, modelName = "t124",
                          engine = "R"),
    "Threading requires the C"
  )
  # The run completes on the C++ engine (a valid posterior is produced).
  expect_s3_class(post, "StratPosterior")
})

# ── RT-690: custom-prior "Prior" proposal samples with its OWN args ──────────
#
# For a PT_CUSTOM parameter, the C++ engine's "Prior" proposal draws from
# priorsProposals[[p]]$R called with priorsProposals[[p]]$args -- not with
# the prior's own args (priors$metro[[p]]$args). When the two arg lists use
# different names, pairing the proposal's sampler with the prior's argument
# list throws R's "unused argument" error from inside the no-throw C++ impl
# frame, exactly as it would on the main thread (custom priors force
# sequential execution, RT-272).

test_that("RT-690: cpp Prior proposal uses the proposal's own args", {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  # Prior: custom D wrapper (-> PT_CUSTOM) with args mean/sd.
  customD <- function(x, mean, sd, log = TRUE) {
    dnorm(x, mean = mean, sd = sd, log = log)
  }
  stratModel1$priors$metro[[1]] <- Prior(
    R = function(n, mean, sd) rnorm(n, mean = mean, sd = sd),
    D = customD, Q = qnorm, mean = 0, sd = 10
  )
  # Proposal: same shape of object but a disjoint set of argument names
  # (shape/rate rather than mean/sd). Calling this R function with the
  # prior's args throws "unused arguments (mean = ..., sd = ...)".
  customGammaD <- function(x, shape, rate, log = TRUE) {
    dgamma(x, shape = shape, rate = rate, log = log)
  }
  stratModel1$priorsProposals[[1]] <- Prior(
    R = function(n, shape, rate) rgamma(n, shape = shape, rate = rate),
    D = customGammaD, Q = qgamma, shape = 2, rate = 1
  )

  # Force every chain to always select the "Prior" proposal, so
  # sample_all_from_prior() is guaranteed to run on every iteration.
  probe <- StratMCMC(stratModel1, nIter = 1, nChains = 1)
  nProp <- length(names(probe[["propose"]]))
  weights <- c(1, rep(0, nProp - 1))

  mcmc <- StratMCMC(stratModel1, nIter = 3, nChains = 1,
                    proposalProbabilityWeights = weights)

  td <- file.path(tempdir(), paste0("rt690_", sample.int(1e6, 1)))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  expect_no_error(
    RunStratModel(stratData1, stratModel1, mcmc, seed = 1, quiet = TRUE,
                  visualise = FALSE, modelDir = td, modelName = "rt690",
                  engine = "cpp")
  )
})
