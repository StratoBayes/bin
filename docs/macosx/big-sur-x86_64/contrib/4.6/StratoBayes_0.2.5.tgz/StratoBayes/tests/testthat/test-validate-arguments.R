test_that(".ValidateAlignment() works", {
  expect_equal(.ValidateAlignment("all", 1:2), 1:2)
  expect_equal(.ValidateAlignment("ALL",0:2), 0:2)
  expect_equal(.ValidateAlignment("none",2:4), 2:4)
  expect_equal(.ValidateAlignment(1:2,0:3), 1:2)
  expect_equal(.ValidateAlignment(2,0:3), 2)
  expect_equal(.ValidateAlignment(1,1), 1)

  expect_error(.ValidateAlignment(NULL, 1), "cannot be NULL")
  expect_error(.ValidateAlignment("fail",1), "`alignment` must be")
  expect_error(.ValidateAlignment(1), "clustUnique")
  expect_error(.ValidateAlignment(1:2,2:4), "must consist of whole")
  expect_error(.ValidateAlignment(character(0), 1:2), "empty")
  # non-integer doubles must not be silently truncated (as.integer(1.9) -> 1L)
  expect_error(.ValidateAlignment(c(1.9, 3.0), 0:3), "`alignment` must be")
  expect_equal(.ValidateAlignment(c(1, 3), 0:3), c(1L, 3L))
})

test_that(".ValidateAlignment gives its own message for a numeric vector with an embedded NA (RT-468)", {
  # is.numeric(x) && any(x != floor(x)) NA-poisons to `if (NA)` for c(1, NA),
  # surfacing base R's opaque "missing value where TRUE/FALSE needed" instead
  expect_error(.ValidateAlignment(c(1, NA), 0:3),
               "`alignment` must not contain missing values")
  expect_error(.ValidateAlignment(c(1, 2, NA), 0:3),
               "`alignment` must not contain missing values")
  # a bare NA (logical, not numeric) is unaffected: is.numeric(NA) is FALSE
  expect_error(.ValidateAlignment(NA, 0:3), "must consist of whole numbers")
})

test_that(".ValidateAlignmentPresence() catches NULL/empty/NA before a `clustUnique`-dependent full validation is possible (RT-604)", {
  expect_error(.ValidateAlignmentPresence(NULL), "cannot be NULL")
  expect_error(.ValidateAlignmentPresence(character(0)), "empty vector")
  expect_error(.ValidateAlignmentPresence(NA), "must not contain missing values")
  expect_no_error(.ValidateAlignmentPresence("all"))
  expect_no_error(.ValidateAlignmentPresence(1:3))
})

test_that(".ValidateMaxSamples() rejects non-scalar/non-numeric/non-positive input (RT-606)", {
  expect_error(.ValidateMaxSamples(NA), "single number")
  expect_error(.ValidateMaxSamples(-5), "single number")
  expect_error(.ValidateMaxSamples(0), "single number")
  expect_error(.ValidateMaxSamples(c(1, 2)), "single number")
  expect_error(.ValidateMaxSamples("2000"), "single number")
  expect_equal(.ValidateMaxSamples(2000), 2000)
})

test_that(".ValidateMaxSamples() accepts Inf, matching ExtractParameters()'s own 'no cap' default (RT-606)", {
  expect_equal(.ValidateMaxSamples(Inf), Inf)
})

test_that(".ValidateParams() succeeds", {
  expect <- as.data.frame(matrix(1:2, nrow = 1), optional = TRUE)
  expect_equal(.ValidateParams(NULL, 1, "NULL"), "NULL")
  expect_equal(.ValidateParams(1:2, 2), expect)
  expect_error(.ValidateParams(1:2, 3), "vector of length 3")
  mat6 <- matrix(1:6, 3, 2)
  expect6 <- as.data.frame(mat6, optional = TRUE)
  expect_equal(.ValidateParams(mat6, 2), expect6)
  expect_error(.ValidateParams(mat6, 3), "vector of length 3")
  expect_equal(.ValidateParams(expect6, 2), expect6)
  expect_error(.ValidateParams(expect6, 3), "vector of length 3")
})

test_that(".ValidateParams() names the coerced data frame's columns when paramNames is supplied (RT-466)", {
  out <- .ValidateParams(1:2, 2, ifNull = NULL, paramNames = c("alpha", "gammaLog"))
  expect_equal(colnames(out), c("alpha", "gammaLog"))
  expect_equal(unname(unlist(out)), 1:2)

  # a length mismatch (e.g. a stale paramNames) leaves the data frame name-less
  # rather than assigning the wrong names
  outMismatch <- .ValidateParams(1:2, 2, ifNull = NULL, paramNames = c("alpha"))
  expect_equal(colnames(outMismatch),
               colnames(as.data.frame(matrix(1:2, ncol = 2), optional = TRUE)))
})
  
test_that(".ValidateParams rejects an NA inside `parameters` instead of letting it propagate downstream (RT-469)", {
  expect_error(.ValidateParams(c(0.5, NA, 0.5, 0.5), 4),
               "`parameters` must not contain missing values")
  mat <- matrix(c(1, NA, 3, 4), nrow = 1)
  expect_error(.ValidateParams(mat, 4),
               "`parameters` must not contain missing values")
})

test_that(".ValidateModelParams rejects NA instead of crashing with an opaque error (RT-478)", {
  # lapply(as.character(parameters), ...) turns NA into NA_character_;
  # as.numeric(NA_character_) is NA without a warning, so `n` stays NA and
  # `p == ""` NA-poisons to `if (NA)` -- "missing value where TRUE/FALSE needed"
  expect_error(.ValidateModelParams(stratPosterior1, NA),
               "`parameters` must not contain missing values")
  expect_error(.ValidateModelParams(stratPosterior1, c("posterior", NA)),
               "`parameters` must not contain missing values")
  expect_error(.ValidateModelParams(stratPosterior1, NA_integer_),
               "`parameters` must not contain missing values")
})

test_that(".ValidateModelParams rejects an out-of-range numeric index on both sides (RT-605)", {
  # only the upper bound (`n > length(metroParamNames)`) was ever checked;
  # `n <= 0` fell through to get1index's own opaque subscript errors
  expect_error(.ValidateModelParams(stratPosterior1, 0),
               "Invalid number '0' specified for `parameters`")
  expect_error(.ValidateModelParams(stratPosterior1, -1),
               "Invalid number '-1' specified for `parameters`")
})

test_that(".ValidateModelParams rejects a zero-length `parameters` instead of silently returning NULL (RT-605)", {
  expect_error(.ValidateModelParams(stratPosterior1, character(0)),
               "`parameters` cannot be an empty vector")
  expect_error(.ValidateModelParams(stratPosterior1, integer(0)),
               "`parameters` cannot be an empty vector")
})

test_that(".ValidateModelParams gates the prior/likelihood whitelist on StratPosterior objects (RT-605)", {
  # a StratPrior has no "prior"/"likelihood" component to resolve to, so
  # allowing them through the whitelist just deferred the error to an
  # opaque `priors[[c("prior", "D")]]` NULL lookup downstream
  expect_error(.ValidateModelParams(stratPrior1, "prior"),
               "Invalid names specified for parameters")
  expect_error(.ValidateModelParams(stratPrior1, "likelihood"),
               "Invalid names specified for parameters")
  expect_equal(.ValidateModelParams(stratPosterior1, "log prior"), "prior")
})

test_that(".ValidateModelParams rejects lambda/sigma/beta on a StratPrior with a clear message instead of an unbound-variable leak (RT-605)", {
  # sigNames/eachSplineBasis were only ever bound in the !onlyMetro branch,
  # so these arms crashed with "object 'sigNames' not found" for a StratPrior
  expect_error(.ValidateModelParams(stratPrior1, "lambda"),
               "not a valid `parameters` selection")
  expect_error(.ValidateModelParams(stratPrior1, "sigma"),
               "not a valid `parameters` selection")
  expect_error(.ValidateModelParams(stratPrior1, "beta"),
               "not a valid `parameters` selection")
})

test_that(".ValidateModelParams works", {

  expect_error(.ValidateModelParams("", stratPosterior1),
               "parameters must be atomic")

  expect_error(.ValidateModelParams(stratModel1, 1),
               "object must be of class")

  expect_error(.ValidateModelParams(stratPosterior1, ""),
               "`parameters` may not be empty")

  expect_error(.ValidateModelParams(stratPosterior1, "sigma"),
               "Invalid names specified for parameters")

  expect_error(.ValidateModelParams(stratPosterior1, 5),
               "Invalid number '5' specified for `parameters`")

  expect_equal(.ValidateModelParams(stratPosterior1, "probability"),
               c("posterior", "prior_parameters", "prior_overlap",
                 "likelihood_spline"))

  expect_equal(.ValidateModelParams(stratPosterior1, "log posterior"),
               "posterior")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_parameters"),
               "prior_parameters")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_overlap"),
               "prior_overlap")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood_spline"),
               "likelihood_spline")

  expect_equal(.ValidateModelParams(stratPosterior2, "log likelihood_ties"),
               "likelihood_ties")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood"),
               "likelihood")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior"),
               "prior")

  expect_equal(.ValidateModelParams(stratPosterior1, "beta")[5:6],
               c("beta_value_5", "beta_value_6"))

  expect_equal(.ValidateModelParams(stratPosterior2, "beta_b")[1:3],
               c("beta_b_1", "beta_b_2", "beta_b_3"))

})

# --- .ValidateRunSelect ---

test_that(".ValidateRunSelect accepts valid inputs", {
  expect_equal(.ValidateRunSelect("all", 3), 1:3)
  expect_equal(.ValidateRunSelect("ALL", 5), 1:5)
  expect_equal(.ValidateRunSelect(1, 3), 1L)
  expect_equal(.ValidateRunSelect(c(1, 3), 3), c(1L, 3L))
})

test_that(".ValidateRunSelect rejects invalid inputs", {
  expect_error(.ValidateRunSelect(NULL, 3), "cannot be NULL")
  expect_error(.ValidateRunSelect(0, 3), "whole numbers between 1")
  expect_error(.ValidateRunSelect(4, 3), "whole numbers between 1 and 3")
  expect_error(.ValidateRunSelect(-1, 3), "whole numbers between 1")
  expect_error(.ValidateRunSelect(character(0), 3), "empty")
})

test_that(".ValidateRunSelect rejects NA instead of crashing with an opaque error (RT-462)", {
  expect_error(.ValidateRunSelect(NA, 3), "cannot contain NA")
  expect_error(.ValidateRunSelect(NA_integer_, 3), "cannot contain NA")
  expect_error(.ValidateRunSelect(c(1, NA), 3), "cannot contain NA")
})

# --- %safein% ---

test_that("%safein% matches same-type values", {
  expect_equal(1:3 %safein% c(2, 3, 4), c(FALSE, TRUE, TRUE))
  expect_equal(c("a", "b") %safein% c("b", "c"), c(FALSE, TRUE))
})

test_that("%safein% treats integer and double as compatible", {
  expect_equal(1L %safein% c(1, 2), TRUE)
  expect_equal(1.0 %safein% 1L, TRUE)
})

test_that("%safein% returns FALSE when types differ (char vs numeric)", {
  expect_equal("1" %safein% 1, FALSE)
  expect_equal(1 %safein% "1", FALSE)
  expect_equal(c("1", "2") %safein% 1:2, c(FALSE, FALSE))
})

# --- .ValidateSites ---

test_that(".ValidateSites accepts site names", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites("site_1", data), 1L)
  result <- .ValidateSites(c("site_1", "site_3"), data)
  expect_equal(result, c(1L, 3L))
})

test_that(".ValidateSites resolves a factor by label, not by code (RT-519)", {
  # A factor's typeof() is "integer", which used to slip past %safein%'s
  # type-matching branch and match against seq_len(S) by code rather than
  # against data[["sites"]] by label -- returning site 1 regardless of which
  # site was named, whenever a single-level factor happened to code as 1.
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites(factor("site_2"), data), 2L)
  expect_equal(.ValidateSites(factor("site_3"), data), 3L)
  expect_equal(
    .ValidateSites(factor("site_2", levels = c("site_1", "site_2", "site_3")),
                   data),
    2L
  )
})

test_that(".ValidateSites accepts 'all'", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites("all", data), 1:3)
})

test_that(".ValidateSites accepts integer indices", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateSites(c(1, 2), data), c(1, 2))
})

test_that(".ValidateSites rejects out-of-range", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSites(5, data), "integers from 1 to")
})

test_that(".ValidateSites rejects NULL or empty input instead of silently selecting nothing", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSites(NULL, data), "cannot be NULL or an empty vector")
  expect_error(.ValidateSites(character(0), data), "cannot be NULL or an empty vector")
})

test_that(".ValidateSites rejects NA instead of NA-poisoning into a raw base-R error (RT-514)", {
  # NA (logical) fails %safein% against a character `data[["sites"]]` (type
  # mismatch), falling through to `sites[[1]] == "all"`, i.e. `if (NA)` --
  # "missing value where TRUE/FALSE needed" instead of a package message
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSites(NA, data), "`sites` must not contain missing values")
  expect_error(.ValidateSites(NA_character_, data), "`sites` must not contain missing values")
  expect_error(.ValidateSites(NA_integer_, data), "`sites` must not contain missing values")
  expect_error(.ValidateSites(c("site_1", NA), data), "`sites` must not contain missing values")
})

# --- .ValidateSignal ---

test_that(".ValidateSignal accepts signal names", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal("value", data)
  expect_equal(result$signal, "value")
  expect_false(result$allSignals)
})

test_that(".ValidateSignal accepts 'all'", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal("all", data)
  expect_true(result$allSignals)
})

test_that(".ValidateSignal accepts integer index", {
  data <- StratData(signal = signalData1)
  result <- .ValidateSignal(1L, data)
  expect_equal(result$signal, "value")
})

test_that(".ValidateSignal rejects invalid names", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSignal("nonexistent", data), "signal must be")
})

test_that(".ValidateSignal rejects empty input", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSignal(character(0), data), "empty")
})

test_that(".ValidateSignal rejects NA instead of NA-poisoning into a raw base-R error (RT-514)", {
  # `signal[[1]] == "all"` NA-poisons to `if (NA)` for a bare NA
  data <- StratData(signal = signalData1)
  expect_error(.ValidateSignal(NA, data), "`signal` must not contain missing values")
  expect_error(.ValidateSignal(NA_character_, data), "`signal` must not contain missing values")
  expect_error(.ValidateSignal(NA_integer_, data), "`signal` must not contain missing values")
})

test_that("SignalLookUp() rejects NA `signal` with a package message, not a raw base-R error (RT-514)", {
  data <- StratData(signal = signalData1)
  siteName <- names(data[[c("signalAttr", "siteInd")]])[[1]]
  expect_error(SignalLookUp(data, "height", siteName, signal = NA),
               "`signal` must not contain missing values")
})

# --- .ValidateShow ---

test_that(".ValidateShow works for valid inputs", {
  expect_equal(.ValidateShow("signal"), "signal")
  expect_equal(.ValidateShow("partition"), "partition")
  # partial matching
  expect_equal(.ValidateShow("sig"), "signal")
  expect_equal(.ValidateShow("par"), "partition")
})

test_that(".ValidateShow rejects invalid inputs", {
  expect_error(.ValidateShow("invalid"), "must be.*signal.*or.*partition")
})

test_that(".ValidateShow rejects empty input", {
  expect_error(.ValidateShow(character(0)), "empty")
})

# --- .ValidateColourBy ---

test_that(".ValidateColourBy works for alignment plot type", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateColourBy("site", data, "alignment"), "site")
  expect_equal(.ValidateColourBy("partition", data, "alignment"), "partition")
})

test_that(".ValidateColourBy works for hist plot type", {
  data <- StratData(signal = signalData1)
  expect_equal(.ValidateColourBy("alignment", data, "hist"), "alignment")
  expect_equal(.ValidateColourBy("run", data, "hist"), "run")
  expect_equal(.ValidateColourBy("none", data, "hist"), "none")
})

test_that(".ValidateColourBy rejects cross-type mismatches", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateColourBy("alignment", data, "data"), "must be one of")
  expect_error(.ValidateColourBy("site", data, "hist"), "must be one of")
})

test_that(".ValidateColourBy defaults to partition when multiple partitions", {
  data <- StratData(signal = signalData1)
  result <- .ValidateColourBy(NULL, data, "data")
  # With 1 unique partition, should default to "site"
  expect_true(result %in% c("site", "partition"))
})

test_that(".ValidateColourBy rejects empty input", {
  data <- StratData(signal = signalData1)
  expect_error(.ValidateColourBy(character(0), data, "data"), "empty")
})

# --- .CreateColourMaps ---

test_that(".CreateColourMaps rejects empty `col` instead of silently producing all-NA colours", {
  expect_error(
    .CreateColourMaps(
      data = list(), colourScale = "Dark 3", nParts = 3, nSect = 2,
      args = list(col = character(0))
    ),
    "empty"
  )
})

# --- .ValidateQuantiles ---

test_that(".ValidateQuantiles accepts valid quantiles", {
  expect_equal(.ValidateQuantiles(c(0.025, 0.5, 0.975)), c(0.025, 0.5, 0.975))
  expect_equal(.ValidateQuantiles(c(0, 0.5, 1)), c(0, 0.5, 1))
})

test_that(".ValidateQuantiles rejects out-of-range", {
  expect_error(.ValidateQuantiles(c(-0.1, 0.5, 0.9)), "between 0 and 1")
  expect_error(.ValidateQuantiles(c(0.1, 0.5, 1.1)), "between 0 and 1")
})

test_that(".ValidateQuantiles rejects non-numeric", {
  expect_error(.ValidateQuantiles(NULL), "must be a numeric")
  expect_error(.ValidateQuantiles(NA), "must be a numeric")
  expect_error(.ValidateQuantiles("a"), "must be a numeric")
})

test_that(".ValidateQuantiles requires length 3 ascending", {
  expect_equal(.ValidateQuantiles(c(0.05, 0.5, 0.95)),
               c(0.05, 0.5, 0.95))
  expect_error(.ValidateQuantiles(c(0.5, 0.95)),
               "length 3")
  expect_error(.ValidateQuantiles(c(0.95, 0.5, 0.05)),
               "ascending order")
})

# --- .IsNumeric ---

test_that(".IsNumeric correctly identifies numeric-coercible values", {
  expect_true(.IsNumeric(1))
  expect_true(.IsNumeric("1.5"))
  expect_true(.IsNumeric(c("1", "2", "3")))
  expect_false(.IsNumeric("abc"))
  expect_false(.IsNumeric(c("1", "abc")))
})

test_that(".IsNumeric rejects NULL and empty vectors instead of a false TRUE", {
  expect_false(.IsNumeric(NULL))
  expect_false(.IsNumeric(character(0)))
  expect_false(.IsNumeric(numeric(0)))
})

# --- .IsColour ---

test_that(".IsColour recognises valid R colours", {
  expect_true(.IsColour("red"))
  expect_true(.IsColour("#FF0000"))
  expect_true(.IsColour("blue"))
  expect_false(.IsColour("notacolour"))
  expect_false(.IsColour("definitely_not_a_colour_xyz"))
})

# --- .AddLogPrefix ---

test_that(".AddLogPrefix adds log to probability terms", {
  expect_equal(.AddLogPrefix("posterior"), "log posterior")
  expect_equal(.AddLogPrefix("likelihood"), "log likelihood")
  expect_equal(.AddLogPrefix("alpha_site_1"), "alpha_site_1")
  expect_equal(
    .AddLogPrefix(c("posterior", "alpha_site_1")),
    c("log posterior", "alpha_site_1")
  )
})

# --- .ValidateFiniteLimits ---

test_that(".ValidateFiniteLimits accepts NULL and finite ranges", {
  expect_no_error(.ValidateFiniteLimits(NULL, "xlim"))
  expect_no_error(.ValidateFiniteLimits(c(0, 10), "xlim"))
})

test_that(".ValidateFiniteLimits rejects non-finite content (RT-470)", {
  expect_error(.ValidateFiniteLimits(c(0, NA), "xlim"),
               "`xlim` must contain only finite values")
  expect_error(.ValidateFiniteLimits(c(0, Inf), "ylim"),
               "`ylim` must contain only finite values")
})

test_that(".CreateColourMaps falls back to default symbols for empty pch (RT-299)", {
  # a NULL or length-zero `pch` gave nOK == 0, a `%% 0` NaN index and then
  # "attempt to set an attribute on NULL" from setNames()
  nParts <- length(stratData1[[c("partsAttr", "uniqueParts")]])
  reference <- .CreateColourMaps(stratData1, "Dark 3", nParts, stratData1[["S"]])

  for (emptyPch in list(NULL, integer(0), character(0))) {
    maps <- .CreateColourMaps(stratData1, "Dark 3", nParts, stratData1[["S"]],
                              args = list(pch = emptyPch))
    expect_equal(maps[["symbolMap"]], reference[["symbolMap"]])
    expect_equal(maps[["sectionSymbol"]], reference[["sectionSymbol"]])
  }
})
