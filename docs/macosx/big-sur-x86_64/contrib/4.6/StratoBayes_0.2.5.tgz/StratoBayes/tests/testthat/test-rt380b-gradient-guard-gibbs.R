# RT-380b (#454): the `!hmc.initialized || nFree == 0` guard in
# `update_state_hmc()` / `update_state_nuts()` must still run the (beta, sigma,
# lambda) Gibbs sweep and refresh `logPost`/`logPostOld`/`logPostNew`.  Before
# the fix it returned having set only `accept` and `proposalNumber`.
#
# Two triggers, exercised separately: `nFree == 0` (all priors `Fixed()`) and
# `!hmc.initialized` (gradient slot's `proposalArgs` not built — reproduced by
# nulling the slot, which is what `extract_hmc_args()` sees pre-adaptation).
# Driven at the engine level; the guard is upstream of proposal selection.
#
# Guard-fired discriminator: `recordGradient()` runs at the *bottom* of both
# update functions, so a guarded iteration gives `proposalCount == 1` with
# `nGradientTransitions == 0`; a real transition gives 1.

# ── Helpers ──────────────────────────────────────────────────────────────────

# Gradient-proposal-only engine setup: a short R chain supplies initialised
# state (mass matrix, dual averaging), then all proposal mass goes to one slot.
# `allFixed` makes every Metropolis prior `Fixed()`, giving nFree == 0.
#
# `StratMCMC()` installs only NUTS, so the HMC arm renames that slot —
# `proposal_type_from_string()` keys off the name, which is enough to dispatch
# to `update_state_hmc()`.  NUTS args carry no `nSteps`, so `HMCState`'s
# value-initialised `nSteps = 0` stands and the HMC control arm integrates zero
# leapfrog steps: these arms test dispatch, not HMC dynamics.  Same construction
# as `test-rt380-gradient-failure-gibbs.R`.
.rt380b_setup <- function(gradProposal = c("NUTS", "HMC"), allFixed = FALSE,
                          sigmaFixed = TRUE) {
  gradProposal <- match.arg(gradProposal)

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  priors <- stratModel1$priors$metro
  if (allFixed) {
    # Only `inherits(prior, "Fixed")` matters (R/StratModel.R:422); values just
    # need to sit inside the priors' support so the initial state is valid.
    fixedAt <- c(alpha_site_2 = 5, alpha_site_3 = 5,
                 gammaLog_site_2 = 0, gammaLog_site_3 = 0)
    for (nm in names(priors)) priors[[nm]] <- Fixed(unname(fixedAt[[nm]]))
  }

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = priors,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12), sigmaFixed = sigmaFixed
  )
  expect_identical(model$parametersLengthNotFixed, if (allFixed) 0L else 4L)

  td <- file.path(tempdir(), paste0("rt380b_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4200)
  RunStratModel(gradientProposals = "on", stratData1, model, nIter = 30, nChains = 1, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  if (gradProposal == "HMC") {
    names(mcmc$propose)[names(mcmc$propose) == "NUTS"] <- "HMC"
    for (fld in c("proposalProbability", "proposalProbabilityWeights",
                  "proposalFactor", "proposalValid")) {
      mm <- mcmc[[c("metro", fld)]]
      if (!is.null(colnames(mm)))
        colnames(mm)[colnames(mm) == "NUTS"] <- "HMC"
      mcmc[[c("metro", fld)]] <- mm
    }
  }

  pp <- mcmc[[c("metro", "proposalProbability")]]
  slot <- which(colnames(pp) == gradProposal)
  pp[, ] <- 0
  pp[, slot] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  list(data = stratData1, model = model, mcmc = mcmc, slot = slot)
}

# One gradient-proposal iteration; returns chain-1 state either side plus the
# monitor counters.  `killArgs` empties the slot's proposalArgs, forcing
# !hmc.initialized.
.rt380b_one_iter <- function(s, killArgs = FALSE, seed = 99L) {
  mcmc <- s$mcmc
  if (killArgs) mcmc[[c("metro", "proposalArgs")]][[1]][s$slot] <- list(NULL)

  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, mcmc$recentState)
  StratoBayes:::.sb_configure_monitor(
    eng, ncol(mcmc[[c("metro", "proposalProbability")]]))
  before <- StratoBayes:::.sb_extract_state(eng)[[1]]
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, 1L)
  mon <- StratoBayes:::.sb_get_monitor(eng)
  after <- StratoBayes:::.sb_extract_state(eng)[[1]]

  # Independent oracle: recomputes the beta-marginal logPost over the post-Gibbs
  # state through a full forward pass that rebuilds B/H/tBy from scratch, versus
  # the helper's cached BtB/Bty.
  oracle <- StratoBayes:::.sb_eval_logpost(
    eng, 1L, after$metro$parameters, marginal = TRUE)

  list(before = before, after = after, mon = mon, oracle = oracle,
       argsNull = is.null(mcmc[[c("metro", "proposalArgs")]][[1]][[s$slot]]))
}

# Shared assertions for a guarded self-transition.
.rt380b_expect_self_transition <- function(r) {
  # Guard fired: slot selected, no transition completed.
  expect_identical(sum(r$mon$proposalCount), 1L)
  expect_identical(r$mon$nGradientTransitions, 0L)

  # Recorded as a rejection; position untouched.
  expect_false(r$after$metro$accept)
  expect_equal(r$after$metro$parameters, r$before$metro$parameters)

  # (a) Gibbs block refreshed — pre-fix these were bit-identical to `before`.
  expect_false(isTRUE(all.equal(r$before$gibbs$lambda, r$after$gibbs$lambda)))
  expect_false(isTRUE(all.equal(r$before$gibbs$beta, r$after$gibbs$beta)))

  # (b) log posteriors refreshed.  Pre-fix `logPost` was unchanged and
  # logPostOld/logPostNew sat at 0 (`sb_create_engine()` imports `logPost` but
  # not those two, so they enter the block value-initialised).
  expect_false(isTRUE(all.equal(r$before$metro$logPost, r$after$metro$logPost)))
  expect_equal(r$after$metro$logPostOld, r$after$metro$logPost)
  expect_identical(r$after$metro$logPostNew, -Inf)

  # ...and it is the right value, not merely a changed one.
  expect_equal(r$after$metro$logPost, r$oracle, tolerance = 1e-10)
}

# ── Trigger 1: nFree == 0 ────────────────────────────────────────────────────

for (.prop in c("NUTS", "HMC")) local({
  prop <- .prop

  test_that(paste0("RT-380b: ", prop,
                   " with nFree == 0 still runs the Gibbs sweep"), {
    skip_on_cran()

    s <- .rt380b_setup(prop, allFixed = TRUE)
    r <- .rt380b_one_iter(s)

    # Isolates the `nFree == 0` disjunct: setup ran adaptation, so the args
    # exist and hmc.initialized is TRUE.
    expect_false(r$argsNull)

    .rt380b_expect_self_transition(r)
  })
})

# `stratModel1` fixes sigma, so the arms above skip the `if (!sigmaFixed)`
# H/tBy rescale inside `no_proposal_self_transition()`.  This arm exercises it.
#
# The oracle was disabled here until #490 was fixed: the engine used to import
# the R warm-up's `metro$H` and back-derive `BtB = H * sigma^2`, which is not
# B'B once the R engine's own Gibbs sweep has moved sigma.
test_that("RT-380b: nFree == 0 rescales H/tBy when sigma is free", {
  skip_on_cran()

  s <- .rt380b_setup("NUTS", allFixed = TRUE, sigmaFixed = FALSE)
  r <- .rt380b_one_iter(s)

  .rt380b_expect_self_transition(r)
  expect_false(isTRUE(all.equal(r$before$gibbs$sigma, r$after$gibbs$sigma)))
  expect_false(isTRUE(all.equal(r$before$metro$H, r$after$metro$H)))
  expect_false(isTRUE(all.equal(r$before$metro$tBy, r$after$metro$tBy)))
})

# ── Trigger 2: !hmc.initialized ──────────────────────────────────────────────

for (.prop in c("NUTS", "HMC")) local({
  prop <- .prop

  test_that(paste0("RT-380b: uninitialised ", prop,
                   " still runs the Gibbs sweep"), {
    skip_on_cran()

    s <- .rt380b_setup(prop)

    # Control: with the args in place the same setup completes a real gradient
    # transition.  Without it the nGradientTransitions == 0 assertion below
    # would be vacuous.
    ctrl <- .rt380b_one_iter(s)
    expect_false(ctrl$argsNull)
    expect_identical(ctrl$mon$nGradientTransitions, 1L)

    r <- .rt380b_one_iter(s, killArgs = TRUE)
    expect_true(r$argsNull)

    .rt380b_expect_self_transition(r)

    # Same slot reported either way — the guard is not a skipped proposal.
    expect_identical(r$after$metro$proposalNumber,
                     ctrl$after$metro$proposalNumber)
  })
})
