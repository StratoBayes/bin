test_that("#1289: .ValidateAlignment() leaves the caller's clustUnique alone", {
  # `%fin%` stamps its *table* argument with a `.match.hash` attribute in
  # place, which reaches the caller's stored `stratCluster` and makes the
  # object compare unequal to its own earlier self.
  stored <- list(clustUnique = c(1L, 2L, 0L))
  expect_null(attributes(stored[["clustUnique"]]))

  invisible(.ValidateAlignment(1, clustUnique = stored[["clustUnique"]]))
  expect_null(attributes(stored[["clustUnique"]]))

  # The "all"/"none" branch returns clustUnique, and that return value is then
  # used as a `%fin%` table by .ExtractAlignmentIterations(), so returning the
  # stored vector itself mutates it one step later.
  allOut <- .ValidateAlignment("all", clustUnique = stored[["clustUnique"]])
  expect_equal(allOut, c(1L, 2L, 0L))
  invisible(c(1L, 1L, 2L) %fin% allOut)
  expect_null(attributes(stored[["clustUnique"]]))

  noneOut <- .ValidateAlignment("none", clustUnique = stored[["clustUnique"]])
  invisible(c(1L, 1L, 2L) %fin% noneOut)
  expect_null(attributes(stored[["clustUnique"]]))
})

test_that("#1288: .ValidateMinPts() rejects malformed minPts", {
  expect_equal(.ValidateMinPts(2), 2)
  expect_equal(.ValidateMinPts(5L), 5L)

  expect_error(.ValidateMinPts(0), "at least 2")
  expect_error(.ValidateMinPts(-3), "at least 2")
  expect_error(.ValidateMinPts(1), "at least 2")
  expect_error(.ValidateMinPts(NA), "single whole number")
  expect_error(.ValidateMinPts(NA_integer_), "single whole number")
  expect_error(.ValidateMinPts("x"), "single whole number")
  expect_error(.ValidateMinPts(3.5), "single whole number")
  expect_error(.ValidateMinPts(Inf), "single whole number")
  expect_error(.ValidateMinPts(c(3, 5)), "single whole number")
  expect_error(.ValidateMinPts(NULL), "single whole number")
})

test_that("#1288: Cluster() validates minPts on the hdbscan branch only", {
  set.seed(1)
  dat <- matrix(rnorm(40), nrow = 20)

  expect_error(Cluster(dat, clusterMethod = "hdbscan", minPts = 0),
               "at least 2")
  expect_error(Cluster(dat, clusterMethod = "hdbscan", minPts = NA),
               "single whole number")
  # silently reduced to min(c(3, 5)) = 3 before this fix
  expect_error(Cluster(dat, clusterMethod = "hdbscan", minPts = c(3, 5)),
               "single whole number")

  # proto ignores minPts, and always has: junk there must stay harmless
  expect_silent(Cluster(dat, clusterMethod = "proto", minPts = 0))
  expect_equal(Cluster(dat, clusterMethod = "hdbscan", minPts = 3),
               .HdbscanCluster(dat, minPts = 3))
})

test_that("#1288: .ClampMinPts() bounds minPts by the rows clustered", {
  expect_equal(.ClampMinPts(3, 20), 3)
  expect_equal(.ClampMinPts(50, 6), 5)
})

test_that("#1288: options$minPts records the value actually clustered with", {
  cl <- Cluster(stratPosterior1, burnIn = 0.5, maxSamples = 6,
                clusterMethod = "hdbscan", minPts = 50)
  nRows <- length(unlist(cl[["rowIndex"]]))
  skip_if_not(nRows >= 3, "fixture gave too few rows to cluster")
  expect_lt(cl[[c("options", "minPts")]], 50)
  expect_equal(cl[[c("options", "minPts")]], nRows - 1)

  # an unclamped request is recorded unchanged
  cl2 <- Cluster(stratPosterior1, burnIn = 0.5, clusterMethod = "hdbscan",
                 minPts = 5)
  expect_equal(cl2[[c("options", "minPts")]], 5)
  expect_null(Cluster(stratPosterior1, burnIn = 0.5)[[c("options", "minPts")]])
})

test_that("#1290: a completedIter off a save point no longer empties the run", {
  saveIter <- list(c(10, 20, 30), c(10, 20, 30))

  # exact matches are unchanged: an exact hit is the largest index satisfying <=
  expect_equal(.CompletedRowIndex(saveIter, c(30, 20), c(1L, 2L)), c(3, 2))

  # the case that used to yield index 0, and so an empty completed-iteration
  # vector and a "burn-in discarded everything" error further downstream
  expect_equal(.CompletedRowIndex(saveIter, c(25, 30), c(1L, 2L)), c(2, 3))

  # genuinely below every saved iteration: named, not blamed on burnIn
  expect_error(.CompletedRowIndex(saveIter, c(30, 5), c(1L, 2L)),
               "run 2 reports a last completed iteration \\(5\\) below every")
  expect_error(.CompletedRowIndex(saveIter, c(1, 5), c(3L, 5L)),
               "runs 3, 5 report")

  # end to end: a run whose metadata falls between two save points keeps its
  # completed rows instead of losing them all
  offPoint <- stratPosterior1
  labels <- offPoint[[c("mcmcSummary", "saveIter")]][[1]]
  offPoint[["mcmcSummary"]][["completedIter"]][[1]] <-
    labels[[length(labels)]] - 1
  offRows <- ExtractIterations(offPoint, "all", burnIn = 0.5)[[1]]
  expect_gt(length(offRows), 0)
  expect_lt(max(offRows), length(labels))
  expect_silent(Cluster(offPoint, burnIn = 0.5))

  broken <- stratPosterior1
  broken[["mcmcSummary"]][["completedIter"]][[1]] <- 0
  expect_error(ExtractIterations(broken, "all", burnIn = 0.5),
               "below every iteration saved")
  expect_error(Cluster(broken, burnIn = 0.5), "below every iteration saved")
})
