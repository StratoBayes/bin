# #1156, #1157, #1280: AutoBurnIn cache staleness and reporting-accuracy gaps.
#
# #1280 has three sub-issues; only the floorIter-snapping one is in scope
# here (the other two touch R/StratPosterior.R, out of scope for this file).

# 3 runs, a shared transient over the first 200 rows, stationary thereafter --
# same synthetic fixture shape as test-auto-burnin.R.
Rt1280Drift <- function(n = 1000, seed = 1, nCol = 3, burn = 200) {
  set.seed(seed)
  m <- matrix(stats::rnorm(n * nCol), n, nCol)
  m[seq_len(burn), ] <- m[seq_len(burn), ] + seq(10, 0, length.out = burn)
  colnames(m) <- paste0("p", seq_len(nCol))
  m
}

Rt1280Converged <- function(n = 1000) {
  list(draws = lapply(1:3, function(s) Rt1280Drift(n, seed = s)),
       iters = replicate(3, seq_len(n), simplify = FALSE))
}

test_that("#1156: the cache is invalidated when getOption(\"StratoBayes.rHatMax\") changes", {
  sp <- stratPosterior1
  cache <- new.env(parent = emptyenv())
  cache$stamp <- .CacheStamp(.subset2(sp, "samples"), .subset2(sp, "nRun"))
  sp[[".cache"]] <- cache

  withr::local_options(StratoBayes.rHatMax = 1.02)
  first <- .AutoBurnIn(sp)
  expect_identical(first[["rHatMax"]], 1.02)
  expect_identical(.PosteriorCache(sp)$autoBurnIn, first)

  # Changing the option must be visible on the next default-criteria call --
  # before the fix, the cache was keyed only on "were arguments passed
  # explicitly", so this returned the stale rHatMax = 1.02 answer unchanged.
  withr::local_options(StratoBayes.rHatMax = 1.5)
  second <- .AutoBurnIn(sp)
  expect_identical(second[["rHatMax"]], 1.5)
  expect_false(identical(second, first))
})

test_that("#1157: the stale \"longest run\" comments have been corrected", {
  path <- testthat::test_path("..", "..", "R", "AutoBurnIn.R")
  skip_if_not(file.exists(path), "source tree not available (installed package)")
  text <- paste(readLines(path), collapse = "\n")

  expect_false(grepl("against the LONGEST run", text, fixed = TRUE))
  # Both sites (the inline comment and .AutoBurnInCandidates()'s roxygen) must
  # be corrected -- a single match would let either one stay stale.
  expect_identical(lengths(regmatches(text, gregexpr(
    "highest completed iteration label", text, fixed = TRUE))), 2L)
})

test_that("#1280 (2): floorIter is snapped onto the run's saved iterations", {
  fx <- Rt1280Converged()
  # A sparse lattice (every 10th iteration), so a floor inside a gap can be
  # told apart from one that lands on a saved iteration.
  fx$iters <- lapply(fx$iters, function(it) it[it %% 10 == 0])
  # A floor that sits strictly inside a lattice gap: no run saves iteration
  # 137, so a caller quoting this candidate as an iteration that exists would
  # be wrong unless it is snapped.
  floorIter <- 137
  candidates <- .AutoBurnInCandidates(fx$iters, floorIter, seq(0, 0.9, 0.05))

  reference <- sort(unique(unlist(fx$iters)))
  expect_true(all(candidates %in% c(reference, floorIter)))
  # The smallest candidate at/above the floor must be an iteration that was
  # actually saved, not the raw unsnapped floorIter value.
  smallestAdmissible <- min(candidates[candidates >= floorIter])
  expect_true(smallestAdmissible %in% reference)
  expect_equal(smallestAdmissible, min(reference[reference >= floorIter]))
})
