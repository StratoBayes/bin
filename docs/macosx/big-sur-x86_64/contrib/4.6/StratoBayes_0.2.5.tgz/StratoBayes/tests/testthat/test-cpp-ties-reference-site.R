# The ties likelihood must cover the same sites in both engines (#1093).
#
# On the height scale site 1 is the alignment reference: its "tie ages" are the
# raw tie heights, unchanged by any parameter, so `.BuildTiesDispatch` drops it
# from the ties term and the C++ native ties loop must drop it too. Scoring it
# adds a parameter-independent constant, which cancels in the accept ratio and
# so leaves every reported log-posterior wrong with nothing failing; and a
# reference-site density of -Inf at its own raw height short-circuits the whole
# accumulator to the -1e30 sentinel, discarding every later site's ties as well.
# On the age scale there is no reference site and every site's ties count.
#
# Deliberately NOT `skip_on_cran()`: the engine-parity harness
# test-cpp-logpost-equivalence.R is CRAN-gated and runs nightly only, which is
# the gate class a silent log-posterior offset slips through. The fixture is
# small (100 data points, a 10-iteration setup run) so it is affordable on PRs.

# Prepared data/model/state plus a C++ engine at a matched state, the same way
# RunStratModel does internally. The setup run must use engine = "R": a
# C++-engine `recentState` is stored in a form `.LogLikTies` does not consume.
RefTieSetup <- function(ties, scale = "height") {
  set.seed(1)
  n1 <- 60L
  n2 <- 40L
  h1 <- seq(0, 10, length.out = n1)
  h2 <- seq(0, 6, length.out = n2)
  d <- rbind(
    data.frame(site = "s1", height = h1,
               value = sin(h1) + rnorm(n1, 0, 0.1)),
    data.frame(site = "s2", height = h2,
               value = sin(h2 + 1) + rnorm(n2, 0, 0.1))
  )
  sData <- StratData(signal = d, ties = ties, siteColumn = "site",
                     zColumn = "height", signalColumn = "value")
  # Derived rather than hard-coded, so the two scales' fixtures differ in
  # `alignmentScale` alone: on the age scale site 1 has its own alpha/gammaLog.
  prepared <- StratoBayes:::.EnsurePreExtracted(sData)
  pNames <- StratoBayes:::.CreateIndices(prepared, scale, "site",
                                         "middle")[["names"]]
  priors <- lapply(pNames, function(nm) {
    if (startsWith(nm, "alpha")) UniformPrior(min = -10, max = 20)
    else NormalPrior(mean = 0, sd = 0.5)
  })
  names(priors) <- pNames
  class(priors) <- c("StratPrior", "list")
  sModel <- StratModel(sData, priors, alignmentScale = scale,
                       sedModel = "site", alphaPosition = "middle", nKnots = 6,
                       sigmaFixed = 1, flexibleKnots = FALSE,
                       knotRange = c(-15, 25))

  td <- file.path(tempdir(),
                  paste0("reftie_", paste(sample(c(letters, 0:9), 10L, TRUE),
                                          collapse = "")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  set.seed(7261)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel, nIter = 10, nChains = 2L,
    seed = 1, quiet = TRUE, visualise = FALSE, nThreads = 1L,
    gradientProposals = "on", modelDir = td, modelName = "reftie",
    engine = "R"
  )
  dataObj <- result$data
  modelObj <- result$model
  mcmcObj <- readRDS(file.path(td, "reftie_mcmc_run_1.rds"))
  stateObj <- mcmcObj$recentState

  if (is.null(modelObj$.logpost_cpp))
    modelObj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(modelObj)
  if (is.null(modelObj$.tiesDispatch))
    modelObj$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(dataObj,
                                                               modelObj)

  tiesCallback <- function(parameters) {
    ageResult <- StratoBayes:::.sb_age_convert(dataObj, modelObj$ind,
                                              parameters, FALSE)
    StratoBayes:::.LogLikTies(dataObj, modelObj,
                              list(age = list(ties = ageResult$ties)))
  }
  engine <- StratoBayes:::.sb_create_engine(
    data = dataObj, model = modelObj, mcmc = mcmcObj, state = stateObj,
    tiesCallback = tiesCallback)

  list(data = dataObj, model = modelObj, state = stateObj,
       engine = engine, td = td)
}

# R- and C++-engine ties components at every chain's sampled parameters.
RefTieComponents <- function(setup) {
  lapply(seq_along(setup$state), function(ch) {
    params <- setup$state[[ch]]$metro$parameters
    r <- StratoBayes:::.LogPost(setup$data, setup$model, setup$state[[ch]])
    cpp <- StratoBayes:::.sb_eval_logpost(setup$engine, ch, params,
                                          debug = TRUE)
    list(r = r[3], cpp = cpp$logPostSep[3], ok = isTRUE(cpp$ok))
  })
}

NormalTies <- function() {
  data.frame(height = c(3, 2), site = c("s1", "s2"),
             mean = c(3, 4), sd = c(1, 2))
}

test_that("the R reference excludes the reference site from the ties term", {
  setup <- RefTieSetup(NormalTies())
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  # The semantics the C++ loop must match: site 1 is absent from the dispatch.
  expect_identical(setup$model$.tiesDispatch$siteIndices, 2L)
  # ...and its tie age is the raw height, so its density is a constant.
  params <- setup$state[[1]]$metro$parameters
  ages <- StratoBayes:::.sb_age_convert(setup$data, setup$model$ind,
                                        params, FALSE)$ties
  expect_equal(unname(unlist(ages[[1]])), 3)
})

test_that("a finite reference-site tie offsets no C++ ties term (#1093)", {
  setup <- RefTieSetup(NormalTies())
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  # The offset this detects is state-independent, so the comparison only
  # discriminates if the two chains sit at different parameters.
  expect_false(identical(setup$state[[1]]$metro$parameters,
                         setup$state[[2]]$metro$parameters))

  for (comp in RefTieComponents(setup)) {
    expect_true(comp$ok)
    # The offending offset is dnorm(3, 3, 1, log = TRUE) = -0.9189385, the
    # same at every parameter value, so the tolerance must stay far below it.
    expect_equal(comp$cpp, comp$r, tolerance = 1e-10)
  }
})

test_that("a -Inf reference-site tie collapses no C++ ties term (#1093)", {
  # dunif(100, 200) has zero density at the tie's own raw height of 3, and
  # site 2's tie is evaluated after it, so a short-circuit here discards both.
  ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                     densityFun = c("dunif", "dnorm"),
                     arg1 = c(100, 4), arg2 = c(200, 2))
  setup <- RefTieSetup(ties)
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  for (comp in RefTieComponents(setup)) {
    expect_true(comp$ok)
    expect_true(is.finite(comp$r))
    # The sentinel is itself finite, so test for it explicitly.
    expect_gt(comp$cpp, -1e29)
    expect_equal(comp$cpp, comp$r, tolerance = 1e-10)
  }
})

test_that("the age scale scores site 1's ties in the C++ engine (#1093)", {
  # The wrong-direction variant — an unconditional skip, or an inverted
  # AC_HEIGHT test — drops site 1's ties here, and the only other harness
  # covering that is test-cpp-logpost-equivalence.R, which is skip_on_cran().
  setup <- RefTieSetup(NormalTies(), scale = "age")
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  # No reference site on the age scale: every site's ties count.
  expect_identical(setup$model$.tiesDispatch$siteIndices, 1:2)

  for (comp in RefTieComponents(setup)) {
    expect_true(comp$ok)
    expect_equal(comp$cpp, comp$r, tolerance = 1e-10)
  }
})
