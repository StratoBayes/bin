test_that("CombineModelRuns aborts and preserves originals when a copy fails (RT-123)", {
  # file.copy(overwrite = FALSE)'s return value was previously discarded, and
  # originals were deleted unconditionally when keepOriginals = FALSE - so a
  # failed copy (e.g. destination already populated from a prior partial run)
  # silently lost the only copy of the sample data.
  dir <- withr::local_tempdir()
  oldFile <- file.path(dir, "modelA_samples_run_1.txt")
  writeLines("dummy sample content", oldFile)

  # Pre-create the destination so file.copy(overwrite = FALSE) fails.
  destFile <- file.path(dir, "combined_samples_run_1.txt")
  writeLines("pre-existing content", destFile)

  expect_error(
    CombineModelRuns(modelDirs = dir, modelNames = "modelA",
                      combinedModelName = "combined", keepOriginals = FALSE),
    "Failed to copy"
  )

  # the original must not be deleted despite the failed copy
  expect_true(file.exists(oldFile))
  # the destination must retain its pre-existing content, not be left stale
  expect_equal(readLines(destFile), "pre-existing content")
})

test_that("CombineModelRuns preserves the full sample history of a fresh binaryOnly run (RT-436)", {
  # A fresh C++ run writes its full sample history to
  # `<model>_binarysamples_run_N.rds` and leaves the sibling
  # `<model>_samples_run_N.txt` as a one-row stub (T-158). CombineModelRuns
  # previously copied only the TSV/idx/mcmc files, so `.CompileSamplesAfterMCMC`
  # fell back to the stub and the combined posterior silently retained only
  # iteration 1.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                       nThin = 10, nChains = 2, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE)

  binFile <- list.files(r1[["modelDir"]],
                        pattern = paste0("^", .EscapeRegex(r1[["modelName"]]),
                                          "_binarysamples_run_1\\.rds$"),
                        full.names = TRUE)
  skip_if(length(binFile) == 0L, "cpp engine not used / no binary samples file")

  nRowsOriginal <- nrow(readRDS(binFile[1]))
  completedIterOriginal <- r1[["mcmcSummary"]][["completedIter"]][1]
  # The bug only bites when there is real history beyond iteration 1 to lose.
  expect_gt(nRowsOriginal, 1L)

  combinedModelName <- paste0(r1[["modelName"]], "_combinedRT436")
  combined <- CombineModelRuns(modelDirs = r1[["modelDir"]],
                                modelNames = r1[["modelName"]],
                                combinedModelName = combinedModelName)

  # The fix materializes the RDS straight into the combined TSV rather than
  # copying it, so the combined directory holds no binary RDS at all - this
  # keeps a mixed-provenance combine (see the next test) from ever landing on
  # `.CompileSamplesAfterMCMC`'s binary-RDS fast path with a partial RDS set.
  combinedBinFile <- file.path(r1[["modelDir"]],
                                paste0(combinedModelName, "_binarysamples_run_1.rds"))
  expect_false(file.exists(combinedBinFile))

  combinedSampleFile <- file.path(r1[["modelDir"]],
                                   paste0(combinedModelName, "_samples_run_1.txt"))
  expect_equal(nrow(utils::read.delim(combinedSampleFile)), nRowsOriginal)

  expect_equal(dim(combined[["samples"]])[1], nRowsOriginal)
  expect_equal(combined[["mcmcSummary"]][["completedIter"]][1], completedIterOriginal)
})

test_that("CombineModelRuns keeps both runs' full history when mixing a fresh run with an already-materialized one (RT-436)", {
  # A combined set routinely mixes a fresh C++ run (has a binarysamples RDS)
  # with a run that was already materialized to TSV - either by a
  # continuation call (T-158) or by the R engine, which never writes a
  # binarysamples RDS at all. `.CompileSamplesAfterMCMC`'s binary-RDS fast
  # path has no concept of "this run has no RDS, fall back for it alone": if
  # CombineModelRuns copied the RDS verbatim, a combined directory holding
  # one run's RDS but not the other's would silently drop the other run
  # entirely (worse than the single-run RT-436 bug). Simulate the
  # already-materialized run by hand rather than running MCMC twice.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                       nThin = 10, nChains = 2, visualise = FALSE, seed = 1,
                       runParallel = FALSE, saveMCMC = TRUE)

  binFile <- list.files(r1[["modelDir"]],
                        pattern = paste0("^", .EscapeRegex(r1[["modelName"]]),
                                          "_binarysamples_run_1\\.rds$"),
                        full.names = TRUE)
  skip_if(length(binFile) == 0L, "cpp engine not used / no binary samples file")
  fullHistory <- as.data.frame(readRDS(binFile[1]))

  modelBName <- paste0(r1[["modelName"]], "_modelB")
  file.copy(file.path(r1[["modelDir"]], paste0(r1[["modelName"]], "_data.rds")),
            file.path(r1[["modelDir"]], paste0(modelBName, "_data.rds")))
  file.copy(file.path(r1[["modelDir"]], paste0(r1[["modelName"]], "_model.rds")),
            file.path(r1[["modelDir"]], paste0(modelBName, "_model.rds")))
  file.copy(file.path(r1[["modelDir"]], paste0(r1[["modelName"]], "_mcmc_run_1.rds")),
            file.path(r1[["modelDir"]], paste0(modelBName, "_mcmc_run_1.rds")))
  write.table(fullHistory,
              file = file.path(r1[["modelDir"]], paste0(modelBName, "_samples_run_1.txt")),
              row.names = FALSE, col.names = TRUE, sep = "\t", quote = FALSE)
  # deliberately no `<modelBName>_binarysamples_run_1.rds`

  combinedModelName <- paste0(r1[["modelName"]], "_combinedMixed")
  combined <- CombineModelRuns(
    modelDirs = r1[["modelDir"]],
    modelNames = c(r1[["modelName"]], modelBName),
    combinedModelName = combinedModelName
  )

  expect_equal(dim(combined[["samples"]])[3], 2L)
  expect_equal(dim(combined[["samples"]])[1], nrow(fullHistory))

  # dim()[3]/dim()[1] alone don't discriminate a regression where modelA's
  # own materialized content silently reverts to fewer real rows while
  # modelB (unaffected) still sets the padding ceiling - .PadArray pads every
  # run up to the longest, so a shrunk-but-still-present run wouldn't move
  # either dim(). Assert directly that modelA's own slice has no NA rows.
  expect_false(anyNA(combined[["samples"]][, , 1, ]))
  expect_equal(combined[["mcmcSummary"]][["completedIter"]],
               rep(r1[["mcmcSummary"]][["completedIter"]][1], 2))

  # No binary RDS should exist anywhere in the combined directory.
  expect_length(
    list.files(r1[["modelDir"]],
               pattern = paste0("^", .EscapeRegex(combinedModelName), "_binarysamples_run_\\d+\\.rds$")),
    0L
  )
})
