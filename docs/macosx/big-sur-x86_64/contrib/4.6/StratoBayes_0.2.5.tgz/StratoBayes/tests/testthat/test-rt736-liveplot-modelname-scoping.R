# Regression tests for RT-736 (#930): live-plot artefacts written during
# RunStratModel() were not modelName-scoped, unlike every other artefact in
# the model directory. `.SetModelDir()` explicitly supports several models
# sharing one `modelDir`, so two models running there at once (or a second
# job's on.exit sweep) could clobber each other's `results.html` and PNGs.

test_that(".SavePng/.CloseAndRenamePng scope PNG filenames by modelName, so
          two models writing to the same saveVisualiseDir don't collide", {
  saveVisualiseDir <- withr::local_tempdir()

  pngA <- StratoBayes:::.SavePng(isParallel = TRUE, saveVisualiseDir = saveVisualiseDir,
                                 modelName = "modelA",
                                 info1 = "run_1", info2 = "sig_1", info3 = "task_1")
  plot.new()
  StratoBayes:::.CloseAndRenamePng(isParallel = TRUE, pngFilenameTemp = pngA,
                                   saveVisualiseDir = saveVisualiseDir, modelName = "modelA",
                                   info1 = "run_1", info2 = "sig_1")

  pngB <- StratoBayes:::.SavePng(isParallel = TRUE, saveVisualiseDir = saveVisualiseDir,
                                 modelName = "modelB",
                                 info1 = "run_1", info2 = "sig_1", info3 = "task_1")
  plot.new()
  StratoBayes:::.CloseAndRenamePng(isParallel = TRUE, pngFilenameTemp = pngB,
                                   saveVisualiseDir = saveVisualiseDir, modelName = "modelB",
                                   info1 = "run_1", info2 = "sig_1")

  # Before the fix both would resolve to the identical unscoped
  # "plot_run_1_sig_1.png", so modelB's write would clobber modelA's.
  expect_true(file.exists(file.path(saveVisualiseDir, "modelA_plot_run_1_sig_1.png")))
  expect_true(file.exists(file.path(saveVisualiseDir, "modelB_plot_run_1_sig_1.png")))
})

test_that(".CreateHtmlCode embeds modelName-scoped image filenames", {
  html <- StratoBayes:::.CreateHtmlCode(nRun = 1, saveDir = tempdir(),
                                        parametersToPlot = "posterior",
                                        allRuns = 1, allSigs = 1,
                                        modelName = "modelA")
  expect_true(grepl("modelA_plot_run_1_sig_1.png", html, fixed = TRUE))
  expect_true(grepl("modelA_plot_parameter_posterior.png", html, fixed = TRUE))
  # never the unscoped legacy name
  expect_false(grepl("\"plot_run_1_sig_1.png\"", html, fixed = TRUE))
})

test_that(".RemoveResidualPlotFiles only removes the requesting model's own
          PNGs, not another model's sharing the same directory", {
  testDir <- withr::local_tempdir()

  pathA <- file.path(testDir, "modelA_plot_run_1_sig_1.png")
  pathB <- file.path(testDir, "modelB_plot_run_1_sig_1.png")
  png(pathA); plot.new(); dev.off()
  png(pathB); plot.new(); dev.off()
  expect_true(file.exists(pathA))
  expect_true(file.exists(pathB))

  StratoBayes:::.RemoveResidualPlotFiles(
    saveVisualiseDir = testDir, modelDir = testDir, modelName = "modelA",
    nRun = 1, sigIndices = 1, parameters = character(0)
  )

  expect_false(file.exists(pathA))
  # modelB's PNG, sharing the same modelDir, must survive modelA's sweep.
  expect_true(file.exists(pathB))
})
