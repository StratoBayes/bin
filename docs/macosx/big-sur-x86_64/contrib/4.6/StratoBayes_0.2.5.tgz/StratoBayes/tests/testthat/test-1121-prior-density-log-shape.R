# GH #1121: `.PriorsValidity()` must smoke-test `D` in the shape every run-time
# caller uses -- `do.call(D, c(x = ..., args, log = TRUE))`.

MakePriors <- function(D) {
  structure(
    list(alpha_site_2 = UniformPrior(min = -6, max = 12),
         alpha_site_3 = UniformPrior(min = -6, max = 12),
         gammaLog_site_2 = Prior(function(n, ...) rnorm(n, 0, 0.7), D,
                                 function(p, ...) qnorm(p, 0, 0.7)),
         gammaLog_site_3 = NormalPrior(mean = 0, sd = 0.7)),
    class = c("list", "StratPrior"))
}

test_that("GH #1121: a `D` that swallows `log` is rejected", {
  swallows <- MakePriors(function(x, ...) dnorm(x, 0, 0.7))
  expect_error(.PriorsValidity(swallows), "gammaLog_site_2", fixed = TRUE)
  expect_error(.PriorsValidity(swallows), "ignores its `log` argument",
               fixed = TRUE)
})

test_that("GH #1121: a `D` that honours `log` passes", {
  expect_true(.PriorsValidity(
    MakePriors(function(x, log = FALSE, ...) dnorm(x, 0, 0.7, log = log))))
})

test_that("GH #1121: a `D` with no way to accept `log` is rejected", {
  # previously passed validation, then threw at the first sampler evaluation
  expect_error(.PriorsValidity(MakePriors(function(x) dnorm(x, 0, 0.7, TRUE))),
               "unused argument")
})

test_that("GH #1121: a `D` that errors only on `log = FALSE` is accepted", {
  # the sampler never uses that shape, so it must not be grounds for rejection
  logOnly <- function(x, log = FALSE, ...) {
    if (!isTRUE(log)) stop("log-scale only")
    dnorm(x, 0, 0.7, log = TRUE)
  }
  expect_true(.PriorsValidity(MakePriors(logOnly)))
})

test_that("GH #1121: a non-scalar or non-numeric `D` return is rejected", {
  expect_error(.PriorsValidity(MakePriors(function(x, ...) "dense")),
               "single non-NA numeric")
  expect_error(.PriorsValidity(MakePriors(function(x, ...) c(1, 2))),
               "single non-NA numeric")
  expect_error(.PriorsValidity(MakePriors(function(x, ...) NA_real_)),
               "single non-NA numeric")
})

test_that("GH #1121: bundled priors, including `Fixed()`, still validate", {
  expect_true(.PriorsValidity(stratPrior1))
  expect_true(.PriorsValidity(structure(
    list(alpha_site_2 = Fixed(3),
         alpha_site_3 = UniformPrior(min = -6, max = 12),
         gammaLog_site_2 = LogNormalPrior(meanlog = 0, sdlog = 0.7),
         gammaLog_site_3 = TruncNormalPrior(mean = 0, sd = 0.7,
                                            lower = -2, upper = 2)),
    class = c("list", "StratPrior"))))
})

test_that("GH #1121: `.fixed_D()` gives a density of 1 off the log scale", {
  expect_identical(.fixed_D(1, value = 1, log = TRUE), 0)
  expect_identical(.fixed_D(1, value = 1, log = FALSE), 1)
  expect_identical(.fixed_D(1, value = 1), 1)
})
