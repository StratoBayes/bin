# Issue #602: automatic burn-in selection, and the evaluator behind #129's
# convergence stopping rule.
#
# Everything here is a pure function over synthetic matrices, so it runs on
# every PR (no `skip_on_cran()`) and pins the fires/doesn't-fire logic that the
# integration tests cannot assert reproducibly.

# 3 runs, a shared transient over the first 200 rows, stationary thereafter.
AbDrift <- function(n = 1000, seed = 1, nCol = 3, burn = 200) {
  set.seed(seed)
  m <- matrix(stats::rnorm(n * nCol), n, nCol)
  m[seq_len(burn), ] <- m[seq_len(burn), ] + seq(10, 0, length.out = burn)
  colnames(m) <- paste0("p", seq_len(nCol))
  m
}

AbConverged <- function(n = 1000) {
  list(draws = lapply(1:3, function(s) AbDrift(n, seed = s)),
       iters = replicate(3, seq_len(n), simplify = FALSE))
}

test_that("a shared transient is detected and discarded", {
  fx <- AbConverged()
  res <- .AutoBurnInCore(fx$draws, fx$iters)

  expect_identical(res[["status"]], "ok")
  expect_false(.AutoBurnInFellBack(res[["status"]]))
  # The true transient ends at row 200; the 0.05 grid cannot resolve finer.
  expect_gte(res[["iteration"]], 200)
  expect_lte(res[["iteration"]], 320)
  expect_lte(res[["rHat"]], getOption("StratoBayes.rHatMax", 1.02))
})

test_that("runs stuck in different modes fall back rather than pick a burn-in", {
  set.seed(9)
  n <- 1000
  stuck <- list(
    matrix(stats::rnorm(n), n, 1, dimnames = list(NULL, "p1")),
    matrix(stats::rnorm(n) + 20, n, 1, dimnames = list(NULL, "p1"))
  )
  res <- .AutoBurnInCore(stuck, replicate(2, seq_len(n), simplify = FALSE))

  expect_identical(res[["status"]], "rHatNotReached")
  expect_true(.AutoBurnInFellBack(res[["status"]]))
  # No draw is certified, so the fallback keeps only a diagnostic tail.
  expect_identical(res[["iteration"]], .kAutoBurnInFallback)
  expect_gt(.kAutoBurnInFallback, 0.9)
  # The best R-hat reached is reported, for diagnosis.
  expect_gt(res[["rHat"]], getOption("StratoBayes.rHatMax", 1.02))
})

test_that("no candidate is chosen below the adaptation floor (#260)", {
  fx <- AbConverged()
  res <- .AutoBurnInCore(fx$draws, fx$iters, floorIter = 800)

  expect_identical(res[["status"]], "ok")
  expect_gte(res[["iteration"]], 800)
})

test_that("a constant column cannot change the answer", {
  # .EssFunc() returns 1 below eps variance, so an unscreened constant column
  # would pin min-ESS at 1 for every candidate and hand the decision to the
  # tie-break.
  fx <- AbConverged()
  withConstant <- lapply(fx$draws, function(m) cbind(m, fixed = 1))

  expect_identical(.AutoBurnInCore(withConstant, fx$iters),
                   .AutoBurnInCore(fx$draws, fx$iters))
})

test_that("a non-finite column is dropped, not fatal", {
  fx <- AbConverged()
  withNA <- lapply(fx$draws, function(m) {
    m[5L, 2L] <- NA_real_
    m
  })
  res <- .AutoBurnInCore(withNA, fx$iters)

  expect_identical(res[["status"]], "ok")
})

test_that("all-constant draws are unevaluable rather than silently accepted", {
  fx <- AbConverged()
  flat <- lapply(fx$draws, function(m) {
    matrix(1, nrow(m), 2L, dimnames = list(NULL, c("a", "b")))
  })
  res <- .AutoBurnInCore(flat, fx$iters)

  expect_identical(res[["status"]], "unevaluable")
  expect_identical(res[["iteration"]], .kAutoBurnInFallback)
})

test_that("too few retained draws is reported, not guessed at", {
  n <- 12L
  short <- replicate(2, {
    matrix(stats::rnorm(n), n, 1, dimnames = list(NULL, "p1"))
  }, simplify = FALSE)
  iters <- replicate(2, seq_len(n), simplify = FALSE)
  res <- .AutoBurnInCore(short, iters, floorIter = n - 2L)

  expect_identical(res[["status"]], "insufficientDraws")
})

test_that("an unreachable ESS target reports the best reached", {
  fx <- AbConverged()
  res <- .AutoBurnInCore(fx$draws, fx$iters, essTarget = 1e9)

  expect_identical(res[["status"]], "essNotReached")
  expect_true(is.finite(res[["ess"]]))
  expect_lt(res[["ess"]], 1e9)
})

test_that("ragged runs do not emit one R-hat warning per candidate", {
  # `.RhatRankNorm()` warns on very unequal runs; the grid search calls it ~19
  # times, so an unsuppressed warning becomes a storm.
  ragged <- list(AbDrift(1000, seed = 1), AbDrift(300, seed = 2))
  iters <- list(seq_len(1000), seq_len(300))

  expect_silent(.AutoBurnInCore(ragged, iters))
})

test_that("the search is deterministic", {
  fx <- AbConverged()
  expect_identical(.AutoBurnInCore(fx$draws, fx$iters),
                   .AutoBurnInCore(fx$draws, fx$iters))
})

test_that("candidates land on the iteration lattice and respect the floor", {
  iters <- replicate(3, seq(25L, 5000L, by = 25L), simplify = FALSE)
  cand <- .AutoBurnInCandidates(iters, floorIter = 1337, grid = seq(0, 0.9, 0.05))

  expect_true(all(cand >= 1337))
  expect_true(all(cand %in% c(1337, iters[[1]])))
  expect_false(is.unsorted(cand))
  expect_identical(anyDuplicated(cand), 0L)
})

test_that("candidates span the longest run, not the shortest", {
  iters <- list(seq_len(300L), seq_len(5000L), seq_len(5000L))
  cand <- .AutoBurnInCandidates(iters, floorIter = 0, grid = seq(0, 0.9, 0.05))

  expect_gt(max(cand), 300)
  expect_lte(max(cand), 4500)
})

# 3 runs, a transient over the first 2000 of 5000 iterations, and one run that
# stopped at 300 -- wholly inside it. The shape #129 produces once a run ends on
# its own convergence rather than at a shared `nIter`.
AbRagged <- function() {
  list(draws = list(AbDrift(300, seed = 1, burn = 300),
                    AbDrift(5000, seed = 2, burn = 2000),
                    AbDrift(5000, seed = 3, burn = 2000)),
       iters = list(seq_len(300L), seq_len(5000L), seq_len(5000L)))
}

test_that("a run ending inside the burn-in is dropped, not allowed to cap it", {
  fx <- AbRagged()
  res <- .AutoBurnInCore(fx$draws, fx$iters)

  expect_identical(res[["status"]], "ok")
  # The transient the two long runs carry ends at 2000; capping candidates at the
  # 300-iteration run made it unreachable and the search fell back to 0.5.
  expect_gt(res[["iteration"]], 300)
  expect_identical(res[["nRunUsed"]], 2L)
  expect_identical(res[["nRunDropped"]], 1L)
})

test_that("an excluded run is named in the report, not passed over", {
  res <- .AutoBurnInCore(AbRagged()$draws, AbRagged()$iters)

  expect_match(.AutoBurnInMessage(res), "1 run ends before that iteration",
               fixed = TRUE)
})

test_that("two runs stay capped by the shorter, because R-hat compares runs", {
  # Deliberate: dropping one of two leaves nothing to compare, so a two-run
  # posterior cannot reach a burn-in past its shorter run.
  fx <- AbRagged()
  res <- .AutoBurnInCore(fx$draws[1:2], fx$iters[1:2])

  expect_true(.AutoBurnInFellBack(res[["status"]]))
})

test_that("degenerate input falls back instead of erroring", {
  expect_identical(.AutoBurnInCore(list(), list())[["status"]], "unevaluable")
  empty <- list(matrix(numeric(0), 0L, 1L, dimnames = list(NULL, "p1")))
  expect_identical(.AutoBurnInCore(empty, list(integer(0)))[["status"]],
                   "insufficientDraws")

  # Draws and iteration labels that do not line up describe no run at all.
  fx <- AbConverged()
  expect_identical(.AutoBurnInCore(fx$draws, fx$iters[1:2])[["status"]],
                   "unevaluable")
})

test_that("misaligned draws are refused rather than silently recycled", {
  fx <- AbConverged()

  # A logical row index shorter than its matrix is recycled by `[`, which would
  # select draws that do not correspond to the thresholded iterations at all.
  shortLabels <- fx$iters
  shortLabels[[2]] <- shortLabels[[2]][seq_len(500)]
  expect_identical(.AutoBurnInCore(fx$draws, shortLabels)[["status"]],
                   "unevaluable")

  # `.RhatRankNorm()` names parameters from the first run only, so a differently
  # ordered run would be compared parameter-against-parameter incorrectly.
  reordered <- fx$draws
  reordered[[2]] <- reordered[[2]][, c(2L, 1L, 3L), drop = FALSE]
  expect_identical(.AutoBurnInCore(reordered, fx$iters)[["status"]],
                   "unevaluable")
})

test_that("an NA iteration label costs one row, not its run", {
  # A logical NA index selects an all-NA row, so the label is dropped by
  # `which()` and not counted -- but it is one uncomparable row, and treating it
  # as grounds to veto every candidate cost the whole search.
  fx <- AbConverged()
  withNA <- fx$iters
  withNA[[1]][500L] <- NA_integer_

  res <- .AutoBurnInCore(fx$draws, withNA)
  expect_false(is.na(res[["iteration"]]))
  expect_true(is.numeric(res[["iteration"]]))
  expect_identical(res[["status"]], "ok")
  expect_identical(res[["nRunDropped"]], 0L)
})

test_that("rHatMax is applied, and is what gets reported", {
  fx <- AbConverged()

  strict <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.0001)
  expect_identical(strict[["status"]], "rHatNotReached")
  # The result carries the criteria it was judged against, so a report cannot
  # quote a threshold that was never applied -- and echoes it exactly, where
  # signif(1.0001, 4) would have printed "1".
  expect_identical(strict[["rHatMax"]], 1.0001)
  expect_message(.AutoBurnInReport(strict), "1.0001", fixed = TRUE)

  lenient <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.5)
  expect_identical(lenient[["status"]], "ok")
  expect_identical(lenient[["rHatMax"]], 1.5)
})

test_that("an R-hat that is Inf everywhere is reported as no R-hat at all", {
  # Runs each constant at a *different* value pass the pooled-variance screen
  # but have no within-run variance, so `.RhatBasic()` returns Inf. No candidate
  # is then finite, and there is no "best reached" value to quote.
  n <- 40L
  flatApart <- list(
    matrix(0, n, 1L, dimnames = list(NULL, "p1")),
    matrix(20, n, 1L, dimnames = list(NULL, "p1"))
  )
  res <- .AutoBurnInCore(flatApart, replicate(2, seq_len(n), simplify = FALSE))

  expect_identical(res[["status"]], "rHatNotReached")
  expect_identical(res[["iteration"]], .kAutoBurnInFallback)
  expect_true(is.na(res[["rHat"]]))
})

test_that(".AutoBurnInReport explains every outcome", {
  Result <- function(status, ...) {
    modifyList(list(iteration = .kAutoBurnInFallback, rHat = 1.5, ess = 12,
                    rHatMax = 1.02, essTarget = 400,
                    status = status), list(...))
  }

  expect_message(
    .AutoBurnInReport(Result("ok", iteration = 400, rHat = 1.004, ess = 900)),
    "discarding iterations up to 400")
  expect_message(.AutoBurnInReport(Result("rHatNotReached")), "R-hat 1.5 > 1.02")
  # An unevaluable R-hat is named, not printed as "R-hat NA > 1.02".
  expect_message(.AutoBurnInReport(Result("rHatNotReached", rHat = NA_real_)),
                 "not computable")
  expect_message(.AutoBurnInReport(Result("essNotReached")), "ESS 12 < 400")
  expect_message(.AutoBurnInReport(Result("insufficientDraws")), "too few draws")
  # Any future status still says something rather than printing NULL.
  expect_message(.AutoBurnInReport(Result("unevaluable")), "unassessable")

  # What was kept, and that it is not a posterior, are in every fallback.
  expect_message(.AutoBurnInReport(Result("unevaluable")),
                 "keeping the last 5%, not a posterior sample")

  expect_null(suppressMessages(.AutoBurnInReport(Result("ok", iteration = 1))))
})

test_that("the search caps the rows it reads", {
  # Long runs are decimated before the candidate loop. The same rows underlie
  # every candidate, so the ranking is unaffected -- but the candidate lattice
  # is the decimated one, so the chosen threshold is resolved only to the
  # decimation stride (here 1000/100 = 10 iterations).
  fx <- AbConverged()
  full <- .AutoBurnInCore(fx$draws, fx$iters)
  capped <- .AutoBurnInCore(fx$draws, fx$iters, searchMaxDraws = 100L)

  expect_identical(capped[["status"]], "ok")
  expect_lt(abs(capped[["iteration"]] - full[["iteration"]]), 30)
  # Fewer rows read means a smaller absolute ESS; it is search-internal and
  # never reported as the run's ESS.
  expect_lt(capped[["ess"]], full[["ess"]])
})

test_that("the short-circuit search agrees on whether a burn-in exists", {
  # `stopAtFirst` is what the stopping rule (#129) calls at every checkpoint:
  # it wants the yes/no, not the argmax. The two searches walk the same
  # candidate list, so they must never disagree about existence -- only about
  # which admissible candidate they return.
  Exists <- function(res) identical(res[["status"]], "ok")

  fx <- AbConverged()
  for (rHatMax in c(1.001, 1.02, 1.5)) {
    for (essTarget in c(0, 400, 1e9)) {
      full <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = rHatMax,
                              essTarget = essTarget)
      first <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = rHatMax,
                               essTarget = essTarget, stopAtFirst = TRUE)
      expect_identical(Exists(first), Exists(full))
      if (Exists(first)) {
        # Earliest admissible, so never later than the ESS-maximising one and
        # still meeting both criteria.
        expect_lte(first[["iteration"]], full[["iteration"]])
        expect_lte(first[["rHat"]], rHatMax)
        expect_gte(first[["ess"]], essTarget)
      }
    }
  }

  set.seed(11)
  n <- 800
  stuck <- list(
    matrix(stats::rnorm(n), n, 1, dimnames = list(NULL, "p1")),
    matrix(stats::rnorm(n) + 30, n, 1, dimnames = list(NULL, "p1"))
  )
  stuckIters <- replicate(2, seq_len(n), simplify = FALSE)
  expect_false(Exists(.AutoBurnInCore(stuck, stuckIters, stopAtFirst = TRUE)))
  expect_identical(
    .AutoBurnInCore(stuck, stuckIters, stopAtFirst = TRUE)[["iteration"]],
    .kAutoBurnInFallback)
})

# ---- The short-circuit search ----------------------------------------------
#
# `stopAtFirst` refutes a candidate as cheaply as it can: it abandons the max
# over parameters at the first parameter above the R-hat ceiling and the min at
# the first below the ESS floor, retries that parameter first at the next
# candidate, evaluates whichever criterion refuted last time first, and skips
# candidates that cannot hold enough draws to reach the target at all. Every one
# of those is meant to be exact, so what follows is an equivalence check against
# a brute-force scan plus a check that the shortcuts really fire -- a shortcut
# that never fires would pass the equivalence check on its own.

# The search as the documentation describes it: every candidate, every
# parameter, whole-matrix R-hat, a plain minimum over ESS. No decimation and no
# column screening, so fixtures must stay under `searchMaxDraws` and keep every
# column usable.
AbBruteForce <- function(drawList, iterList, floorIter = 0,
                         rHatMax = 1.02, essTarget = 0) {
  candidates <- .AutoBurnInCandidates(iterList, floorIter,
                                      seq(0, 0.9, by = 0.05))
  enough <- vapply(candidates, function(cand) {
    all(vapply(iterList, function(it) sum(it > cand), integer(1)) >=
          .kAutoBurnInMinRows)
  }, logical(1))

  for (cand in candidates[enough]) {
    subsets <- Map(function(m, it) m[it > cand, , drop = FALSE],
                   drawList, iterList)
    rHat <- suppressWarnings(max(.RhatRankNorm(subsets), na.rm = TRUE))
    if (!is.finite(rHat) || rHat > rHatMax) next
    ess <- min(vapply(seq_len(ncol(subsets[[1]])), function(p) {
      sum(vapply(subsets, function(m) .EssFunc(m[, p]), numeric(1)))
    }, numeric(1)))
    if (ess >= essTarget) {
      return(list(iteration = cand, rHat = rHat, ess = ess,
                  rows = sum(vapply(subsets, nrow, integer(1))), status = "ok"))
    }
  }
  list(iteration = .kAutoBurnInFallback, rHat = NA_real_, ess = NA_real_,
       rows = NA_integer_, status = "fallback")
}

# Different parameters bind under different criteria: p1 carries the transient,
# so it is the R-hat culprit early and unremarkable later; p2 is strongly
# autocorrelated throughout, so it is the ESS culprit at every threshold. The
# hint therefore has to move between criteria mid-search.
AbShiftingCulprit <- function(n = 600, nRun = 2) {
  set.seed(4)
  Run <- function() {
    Ar1 <- function(rho) {
      as.numeric(stats::filter(stats::rnorm(n), rho, method = "recursive"))
    }
    m <- cbind(p1 = Ar1(0.2), p2 = Ar1(0.95), p3 = Ar1(0.5))
    m[seq_len(150), "p1"] <- m[seq_len(150), "p1"] + seq(15, 0, length.out = 150)
    m
  }
  list(draws = replicate(nRun, Run(), simplify = FALSE),
       iters = replicate(nRun, seq_len(n), simplify = FALSE))
}

test_that("the short-circuit search agrees with a brute-force scan", {
  fixtures <- list(converged = AbConverged(400),
                   shifting = AbShiftingCulprit(),
                   single = AbShiftingCulprit(nRun = 1L))
  # Spans every route through the search: R-hat refuting everywhere (1.001),
  # neither criterion binding (Inf and 0), ESS refuting while R-hat passes
  # (Inf and 1e9), and both live at once.
  for (fx in fixtures) {
    for (rHatMax in c(1.001, 1.02, 1.5, Inf)) {
      for (essTarget in c(0, 50, 300, 1e9)) {
        want <- AbBruteForce(fx$draws, fx$iters, rHatMax = rHatMax,
                             essTarget = essTarget)
        got <- .AutoBurnInCore(fx$draws, fx$iters, rHatMax = rHatMax,
                               essTarget = essTarget, stopAtFirst = TRUE)
        info <- paste("rHatMax", rHatMax, "essTarget", essTarget)
        expect_identical(identical(got[["status"]], "ok"),
                         identical(want[["status"]], "ok"), info = info)
        expect_identical(got[["iteration"]], want[["iteration"]], info = info)
        if (identical(want[["status"]], "ok")) {
          # The aggregates are reported, not merely tested against a threshold,
          # so on the success path they must be the true max and true min.
          expect_identical(got[["rHat"]], want[["rHat"]], info = info)
          expect_identical(got[["ess"]], want[["ess"]], info = info)
        }
      }
    }
  }
})

test_that("a refuted candidate is abandoned at the parameter that refuted it", {
  fx <- AbShiftingCulprit()
  Counted <- function(...) {
    realEss <- .EssFunc
    realRHat <- .RhatRankNorm
    n <- c(ess = 0L, rHat = 0L)
    testthat::local_mocked_bindings(
      .EssFunc = function(x) {
        n[["ess"]] <<- n[["ess"]] + 1L
        realEss(x)
      },
      .RhatRankNorm = function(runSamples) {
        n[["rHat"]] <<- n[["rHat"]] + ncol(runSamples[[1]])
        realRHat(runSamples)
      }
    )
    .AutoBurnInCore(fx$draws, fx$iters, ...)
    n
  }

  # Nothing is admissible, so every candidate has to be refuted -- the search's
  # expensive case, and the one the shortcuts exist for. Three parameters, two
  # runs, 19 candidates: refuting each on every parameter costs 57 R-hat
  # parameters and 114 `.EssFunc()` calls, which is what the full search pays.
  cheap <- Counted(rHatMax = 1.0000001, essTarget = 1e5, stopAtFirst = TRUE)
  full <- Counted(rHatMax = 1.0000001, essTarget = 1e5, stopAtFirst = FALSE)
  expect_lt(cheap[["rHat"]], full[["rHat"]])
  expect_lt(cheap[["rHat"]] + cheap[["ess"]], 57L)

  # R-hat cannot refute, so ESS does, at p2 every time. Once that is the
  # standing hint each candidate costs one parameter's ESS and no R-hat at all:
  # the steady state of a run that has converged and is waiting for draws.
  essOnly <- Counted(rHatMax = Inf, essTarget = 1e5, stopAtFirst = TRUE)
  expect_lt(essOnly[["rHat"]], 3L * 19L)
  expect_lt(essOnly[["ess"]], 2L * 3L * 19L)
})

test_that("no candidate is evaluated when none could hold enough draws", {
  # `.EssFunc()` is capped at the length of its input, so a target above the
  # retained rows is unreachable by arithmetic rather than by measurement -- and
  # the rows only shrink as the threshold rises. This is what makes a run's
  # first checkpoints free.
  fx <- AbConverged(200)
  evaluated <- FALSE
  testthat::local_mocked_bindings(
    .EssFunc = function(x) {
      evaluated <<- TRUE
      length(x)
    },
    .RhatRankNorm = function(runSamples) {
      evaluated <<- TRUE
      stats::setNames(rep(1, ncol(runSamples[[1]])), colnames(runSamples[[1]]))
    }
  )

  # 3 runs x 200 draws leaves 600 retained rows at the loosest threshold.
  res <- .AutoBurnInCore(fx$draws, fx$iters, essTarget = 601, stopAtFirst = TRUE)
  expect_false(evaluated)
  expect_identical(res[["status"]], "essNotReached")
  expect_identical(res[["iteration"]], .kAutoBurnInFallback)

  # One row inside the bound, and the search runs as usual.
  .AutoBurnInCore(fx$draws, fx$iters, essTarget = 600, stopAtFirst = TRUE)
  expect_true(evaluated)
})

test_that("an unevaluable parameter is dropped from R-hat, not read as failing", {
  # `max(..., na.rm = TRUE)` over the whole matrix ignored an NA parameter and
  # left `-Inf` when every parameter was NA. Taking the maximum one parameter at
  # a time has to reproduce both, and the finiteness screen upstream makes
  # neither reachable with real draws -- hence the mock.
  fx <- AbConverged(400)
  Rhat <- function(na) {
    real <- .RhatRankNorm
    testthat::local_mocked_bindings(
      .RhatRankNorm = function(runSamples) {
        out <- real(runSamples)
        out[names(out) %in% na] <- NA_real_
        out
      }
    )
    .AutoBurnInCore(fx$draws, fx$iters, rHatMax = 1.5, stopAtFirst = TRUE)
  }

  # p1 is unevaluable; p2 and p3 still decide the candidate.
  expect_identical(Rhat("p1")[["status"]], "ok")
  # Nothing is evaluable, so nothing may be certified.
  allNa <- Rhat(c("p1", "p2", "p3"))
  expect_identical(allNa[["status"]], "rHatNotReached")
  expect_identical(allNa[["iteration"]], .kAutoBurnInFallback)
})
