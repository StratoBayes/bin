# A tie whose `densityFun` is not natively supported is evaluated by calling
# back into R from inside `compute_logpost()` and from the gradient's
# finite-difference fallback -- both large C++ implementation frames. An R
# error raised there used to longjmp straight out of those frames: a catchable
# condition on x86-64, abort-class on aarch64-Linux (#1134).
#
# NOTE ON WHAT THESE TESTS CAN AND CANNOT SHOW. On x86-64 the run ends in an R
# error both before and after the fix, so the discriminator is *where the error
# comes from*: pre-fix it is the user's own message thrown through the C++
# stack; post-fix the C++ frames return normally and the engine's thin exported
# wrapper raises a prefixed message. A green run here is evidence the plumbing
# works, never evidence about the aarch64 abort -- only aarch64 CI can show
# that.

test_that(".SafeCallback turns an R error into a sentinel, not a condition", {
  boom <- function(x) stop("age must be positive")
  safe <- .SafeCallback(boom)

  out <- expect_no_error(safe(1))
  expect_identical(as.double(out), -Inf)
  expect_identical(attr(out, "sbCallbackError", exact = TRUE),
                   "age must be positive")
})

test_that(".SafeCallback passes a well-behaved callback straight through", {
  safe <- .SafeCallback(function(x, y) dnorm(x, y, log = TRUE))
  expect_identical(safe(1.5, 2), dnorm(1.5, 2, log = TRUE))
  expect_null(attr(safe(1.5, 2), "sbCallbackError", exact = TRUE))
})

test_that(".SafeCallback rejects a return value that is not a single number", {
  # `as<double>()` on any of these would throw from the implementation frame --
  # the same hazard by a different door.
  for (bad in list("nonsense", numeric(0), c(1, 2), NULL, list(1))) {
    out <- .SafeCallback(function() bad)()
    expect_identical(as.double(out), -Inf)
    expect_match(attr(out, "sbCallbackError", exact = TRUE),
                 "a single number is required")
  }
})

test_that(".SafeCallback(NULL) stays NULL", {
  # `.sb_create_engine()` reads a NULL tiesCallback as "this model has no ties".
  expect_null(.SafeCallback(NULL))
})

test_that("both .sb_create_engine call sites wrap their callback", {
  for (fn in list(StratoBayes:::.HMCCreateEngine, StratoBayes:::.InnerRunMCMC)) {
    src <- gsub("[[:space:]]", "",
                paste(deparse(body(fn), width.cutoff = 500L), collapse = ""))
    expect_true(grepl(".SafeCallback(tiesCallback,\"tiesdensityFun\")", src,
                      fixed = TRUE))
  }
})

.Ties1134Fixture <- function() {
  set.seed(1)
  n1 <- 60L
  n2 <- 40L
  h1 <- seq(0, 10, length.out = n1)
  h2 <- seq(0, 6, length.out = n2)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(n1, 0, .1)),
    data.frame(site = "s2", height = h2, value = sin(h2 + 1) + rnorm(n2, 0, .1))
  )
  ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                     densityFun = c("throwingDensity1134", "throwingDensity1134"),
                     arg1 = c(2, 2), arg2 = c(3, 3))
  stratData <- StratData(signal = signal, ties = ties, siteColumn = "site",
                         zColumn = "height", signalColumn = "value")
  priors <- structure(
    list(alpha_s2 = UniformPrior(min = -5, max = 5),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list")
  )
  stratModel <- StratModel(stratData, priors, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "middle",
                           nKnots = 6, sigmaFixed = 1, flexibleKnots = FALSE,
                           knotRange = c(-15, 25))
  list(data = stratData, model = stratModel)
}

# The density must survive the R-side initial-state evaluation and only then
# fail, or the throw never reaches C++ at all: a density that always throws is
# caught by `.GenerateInitialState()` in pure R and proves nothing about #1134.
# `densityFun` is resolved by name, so this has to be visible from the global
# environment.
.throwCounter1134 <- new.env(parent = emptyenv())
assign("throwingDensity1134", function(x, arg1, arg2, log = TRUE) {
  .throwCounter1134$n <- .throwCounter1134$n + 1L
  if (.throwCounter1134$n > .throwCounter1134$limit) stop("age must be positive")
  dnorm(x, arg1, arg2, log = log)
}, envir = globalenv())
# Every later test file in this process shares that environment, so the binding
# is given back when this file finishes.
withr::defer(rm("throwingDensity1134", envir = globalenv()),
             envir = testthat::teardown_env())

test_that("a throwing ties densityFun errors from the wrapper, not the impl frame (#1134)", {
  fx <- .Ties1134Fixture()

  for (grad in c("off", "on")) {
    .throwCounter1134$n <- 0L
    .throwCounter1134$limit <- 5L
    expect_error(
      RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                    nIter = 20, nChains = 2L, seed = 1, quiet = TRUE,
                    visualise = FALSE, nThreads = 1L,
                    gradientProposals = grad, engine = "cpp",
                    modelDir = tempdir(), modelName = paste0("t1134", grad)),
      "A ties densityFun raised an error: age must be positive"
    )
  }
})

test_that("a well-behaved non-native ties densityFun still runs (#1134)", {
  fx <- .Ties1134Fixture()
  .throwCounter1134$n <- 0L
  .throwCounter1134$limit <- Inf
  expect_s3_class(
    RunStratModel(stratObject = fx[["data"]], stratModel = fx[["model"]],
                  nIter = 20, nChains = 2L, seed = 1, quiet = TRUE,
                  visualise = FALSE, nThreads = 1L,
                  gradientProposals = "off", engine = "cpp",
                  modelDir = tempdir(), modelName = "t1134ok"),
    "StratPosterior"
  )
})

# `.sb_create_engine()` takes whatever closure it is handed, so wrapping is a
# caller's obligation. The test above pins today's two callers by name; this one
# holds for any caller, named or not.
test_that("no R caller of .sb_create_engine hands over a raw callback", {
  ns <- asNamespace("StratoBayes")
  callers <- character(0)

  for (nm in ls(ns, all.names = TRUE)) {
    obj <- get(nm, envir = ns)
    if (!is.function(obj) || is.primitive(obj)) next
    src <- gsub("[[:space:]]", "",
                paste(deparse(body(obj), width.cutoff = 500L), collapse = ""))
    # A caller that hands over no callback at all needs no wrapper; passing one
    # positionally would evade this, but no call site in this package does.
    if (!grepl(".sb_create_engine(", src, fixed = TRUE) ||
          !grepl("tiesCallback=", src, fixed = TRUE)) next
    callers <- c(callers, nm)
    expect_true(grepl("tiesCallback=.SafeCallback(", src, fixed = TRUE),
                info = nm)
  }

  # Test helpers pass a raw callback and are deliberately out of scope: their
  # fixtures use natively-supported densities, so no callback is ever invoked.
  expect_true(length(callers) >= 2L)
})

# The mirror of the call-site scan in test-cpp-no-throw-in-impl-frames.R: a
# recorded message is only useful if something raises it. Every exported entry
# point that can reach a ties callback drains the engine, and the count check
# means a sixth cannot be added without editing this list -- a new entry point
# that reached `compute_logpost()` and forgot the drain would otherwise swallow
# the failure, or surface it on an unrelated later call.
test_that("every exported entry point that can reach the callback drains it", {
  srcDir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(srcDir),
              "src/ not found (not running against a source tree)")

  drainers <- c("sb_run_block", "sb_eval_logpost", "sb_compute_gradient",
                "sb_gradient_at", "sb_hmc_eval_logpost")
  lines <- readLines(file.path(srcDir, "MCMCEngine.cpp"), warn = FALSE)

  for (fn in drainers) {
    # Exported wrappers are the only definitions at column 0; `_impl` is a
    # different name, and calls to it are indented.
    start <- grep(sprintf("^[A-Za-z_][A-Za-z0-9_:<>*& ]*\\b%s\\s*\\(", fn),
                  lines)
    expect_length(start, 1L)
    end <- start + which(grepl("^\\}", lines[-seq_len(start)]))[[1]]
    expect_true(any(grepl("take_callback_error\\s*\\(", lines[start:end])),
                info = fn)
  }

  srcFiles <- list.files(srcDir, pattern = "\\.(cpp|h)$", full.names = TRUE)
  sites <- unlist(lapply(srcFiles, function(f) {
    fLines <- readLines(f, warn = FALSE)
    hits <- grep("\\btake_callback_error\\s*\\(", fLines)
    fLines[hits][!grepl("^\\s*static\\b", fLines[hits])]  # not the definition
  }))
  expect_length(sites, length(drainers))
})
