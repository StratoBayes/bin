# Regression test for RT-735 (#929): CombineModelRuns() spliced `modelName`
# unescaped into two regexes (the sample-file glob and its matching run-number
# gsub), unlike every other construction in the same function, which uses
# `.EscapeRegex()` -- see test-rt-135-modelname-regex-escape.R for the
# established pattern this mirrors.

test_that("CombineModelRuns does not pick up a decoy sample file that only
          matches via an unescaped '.' in modelName (RT-735)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  modelName <- "my.model"
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                      nChains = 2, nThreads = 0L, visualise = FALSE,
                      seed = 1, runParallel = FALSE, modelName = modelName,
                      quiet = TRUE)

  # A decoy sample file for an unrelated model whose name only matches
  # "my.model_samples_run_\\d+\\.txt$" because an unescaped "." matches any
  # character -- "myXmodel" is not "my.model" and must never be picked up.
  realSampleFile <- file.path(r1[["modelDir"]], paste0(modelName, "_samples_run_1.txt"))
  decoySampleFile <- file.path(r1[["modelDir"]], "myXmodel_samples_run_1.txt")
  file.copy(realSampleFile, decoySampleFile)

  combinedModelName <- paste0(modelName, "_combinedRT735")
  combined <- CombineModelRuns(modelDirs = r1[["modelDir"]],
                                modelNames = modelName,
                                combinedModelName = combinedModelName)

  # Before the fix, the unescaped pattern also matched the decoy, so
  # `runNumbers` held two entries both labelled run 1 -- the decoy's content
  # was spliced in as a fabricated second run, paired with the real run's own
  # MCMC metadata (borrowed via the same unescaped modelName, so it existed
  # regardless of the decoy).
  expect_equal(dim(combined[["samples"]])[3], 1L)
})
