# RT-097: crash recovery for interrupted binaryOnly C++ runs.
#
# Before the fix, the C++ engine (binaryOnly mode) accumulated every sample in
# memory and wrote them to `<name>_binarysamples_run_<run>.rds` only AFTER the
# sampling loop finished.  An interrupt raised inside the engine
# (`R_CheckUserInterrupt()`) unwound the loop and skipped that write, so:
#   * all accumulated samples were lost, and
#   * on resume `completedIter` was recomputed from the TSV (which holds only
#     iteration 1), yielding completedIter = 1 while `recentState` still pointed
#     at the last checkpoint — silently mislabeling the resumed trace.
#
# The fix writes the binary RDS at every checkpoint (beside the mcmc RDS that
# stores recentState/completedIter).  These tests drive an interrupt via the
# `StratoBayes.testInterruptAtIter` hook (optionally scoped to one run with
# `StratoBayes.testInterruptAtRun`) and assert the checkpointed samples survive
# and the resume recomputes a completedIter consistent with the checkpoint
# (never reset to 1) — for a single run, for an end-to-end resume, and for the
# ragged multi-run case where one run completes and another is cut short.

test_that("RT-097: interrupted binaryOnly run persists checkpointed samples", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "rt097_persist")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  modelName <- "rt097a"
  nIter <- 60L

  # Interrupt at iteration 55: several writeMCMCfile checkpoints (~6, 12, ...,
  # 54 at writeMCMCfile = 0.1) fire first, so the checkpoint write is exercised.
  old <- options(StratoBayes.testInterruptAtIter = 55L)
  on.exit(options(old), add = TRUE)

  set.seed(1)
  expect_error(
    RunStratModel(
      stratObject = stratData1, stratModel = stratModel1,
      nIter = nIter, nChains = 2L, seed = 1, quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = modelName, engine = "cpp"
    ),
    "simulated interrupt"
  )
  options(old)  # disable the hook before any resume

  binPath <- file.path(td, paste0(modelName, "_binarysamples_run_1.rds"))

  # Core fix: the checkpoint RDS exists even though the post-loop write was
  # skipped, and it holds more than just iteration 1.
  expect_true(file.exists(binPath))
  checkpointed <- readRDS(binPath)
  M <- max(checkpointed[, "iteration"])
  expect_gt(M, 1L)      # would be absent / iteration-1-only under the bug
  expect_lt(M, nIter)   # run did not complete

  # The atomic writer must not leave its scratch file behind.  A stray
  # `<...>.rds.tmp` matches none of the package's list.files() patterns (all
  # anchored on `\\.rds$`), so it would accumulate invisibly across interrupts.
  expect_length(list.files(td, pattern = "\\.tmp$"), 0L)

  # The resume path recomputes completedIter from these samples exactly as
  # RunStratModel does (R/RunStratModel.R:518-531).  It must equal the
  # checkpointed iteration M, NOT 1.  RT-414 made `iter` a per-run list.
  model <- readRDS(file.path(td, paste0(modelName, "_model.rds")))
  mcmc1 <- readRDS(file.path(td, paste0(modelName, "_mcmc_run_1.rds")))
  samples <- .CompileSamplesAfterMCMC(
    td, modelName, model, saveChainsList = list(mcmc1[["saveChains"]])
  )
  completedIter <- .CompleteSampleRows(samples, 1L, list(mcmc1[["saveIter"]]))
  expect_equal(completedIter, M)
  expect_gt(completedIter, 1L)
})


test_that("RT-097: an interrupted run checkpoints without disturbing completed runs", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "rt097_multirun")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  modelName <- "rt097c"
  nIter <- 60L

  # Interrupt run 2 only: run 1 completes and takes the ordinary post-loop
  # write, run 2 unwinds mid-flight and must be recovered from its checkpoint.
  # This is the ragged case — the runs end at different iterations, so the
  # per-run completedIter must not be flattened to a single shared value.
  old <- options(StratoBayes.testInterruptAtIter = 55L,
                 StratoBayes.testInterruptAtRun = 2L)
  on.exit(options(old), add = TRUE)

  set.seed(1)
  expect_error(
    RunStratModel(
      stratObject = stratData1, stratModel = stratModel1,
      nIter = nIter, nChains = 2L, seed = c(1, 2), quiet = TRUE,
      visualise = FALSE, modelDir = td, modelName = modelName, engine = "cpp"
    ),
    "simulated interrupt at iteration 55 of run 2"
  )
  options(old)

  bin1 <- file.path(td, paste0(modelName, "_binarysamples_run_1.rds"))
  bin2 <- file.path(td, paste0(modelName, "_binarysamples_run_2.rds"))
  expect_true(file.exists(bin1))
  expect_true(file.exists(bin2))  # absent entirely under the bug

  mcmcList <- lapply(1:2, function(r)
    readRDS(file.path(td, paste0(modelName, "_mcmc_run_", r, ".rds"))))

  # Run 1 reached its last scheduled save; run 2 stopped at a checkpoint.
  lastScheduled <- max(mcmcList[[1]][["saveIter"]])
  expect_equal(max(readRDS(bin1)[, "iteration"]), lastScheduled)
  M2 <- max(readRDS(bin2)[, "iteration"])
  expect_gt(M2, 1L)
  expect_lt(M2, lastScheduled)

  # Ragged recovery: the shorter run is NA-padded into the samples array, so
  # completedIter must report run 2's own checkpoint — not 1 (the bug), and not
  # run 1's length (padding counted as real).
  model <- readRDS(file.path(td, paste0(modelName, "_model.rds")))
  samples <- .CompileSamplesAfterMCMC(
    td, modelName, model,
    saveChainsList = lapply(mcmcList, function(x) x[["saveChains"]])
  )
  completedIter <- .CompleteSampleRows(
    samples, 2L, lapply(mcmcList, function(x) x[["saveIter"]]))
  expect_equal(completedIter, c(lastScheduled, M2))

  expect_length(list.files(td, pattern = "\\.tmp$"), 0L)
})


test_that("RT-097: resume continues from the checkpoint, not from iteration 1", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), "rt097_resume")
  unlink(td, recursive = TRUE)
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  modelName <- "rt097b"
  nIter <- 60L
  resumeNIter <- 20L

  old <- options(StratoBayes.testInterruptAtIter = 55L)
  on.exit(options(old), add = TRUE)  # never leak the hook into other tests
  set.seed(1)
  expect_error(
    RunStratModel(
      stratObject = stratData1, stratModel = stratModel1,
      nIter = nIter, nChains = 2L, seed = 1, quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = modelName, engine = "cpp"
    ),
    "simulated interrupt"
  )
  options(old)  # disable the hook so the resume runs to completion

  binPath <- file.path(td, paste0(modelName, "_binarysamples_run_1.rds"))
  expect_true(file.exists(binPath))
  M <- max(readRDS(binPath)[, "iteration"])
  expect_gt(M, 1L)

  # Resume from the directory.  Continuation adds resumeNIter iterations, so it
  # should run from M+1 to M+resumeNIter.
  set.seed(1)
  resumed <- RunStratModel(
    stratObject = NULL, modelDir = td, modelName = modelName,
    nIter = resumeNIter, seed = 1, quiet = TRUE, visualise = FALSE,
    engine = "cpp"
  )
  expect_s3_class(resumed, "StratPosterior")

  # The resume materializes the checkpointed samples into the TSV and appends
  # the new ones.  Inspect the iteration labels directly.
  tsvPath <- file.path(td, paste0(modelName, "_samples_run_1.txt"))
  iters <- read.table(tsvPath, header = TRUE, sep = "\t",
                      check.names = FALSE)[["iteration"]]

  # Pre-interrupt checkpoint iteration is preserved (not lost, not relabeled).
  expect_true(M %in% iters)
  # The chain continued PAST the checkpoint — max reaches M + resumeNIter.
  # Under the bug this would have been ~1 + resumeNIter, well below M.
  expect_equal(max(iters), M + resumeNIter)
  # No wholesale data loss: at least the M pre-interrupt iterations survive.
  expect_gte(length(unique(iters)), M)

  # A completed resume must leave no scratch file behind either.
  expect_length(list.files(td, pattern = "\\.tmp$"), 0L)
})
