# RT-370 / RT-371: `.CreateSplineS()`'s auto-`knotRange` (used when
# `flexibleKnots = FALSE` and `knotRange` is left NULL).
#
# RT-370: the range was read from the hardcoded canonical columns
#   `data$signal$height` / `data$signal$site`. `StratData()` keeps the user's
#   own `zColumn` / `siteColumn` names, so with non-default names both are
#   NULL, `range(NULL, na.rm = TRUE)` is `c(Inf, -Inf)`, and the resulting
#   `knotRange = c(-Inf, Inf)` crashed `seq()` with "'from' must be a finite
#   number".
# RT-371: the range was always computed from raw heights, but `knotRange`
#   lives on the alignment scale -- under `alignmentScale = "age"` it must be
#   computed from converted ages.

makeNonDefaultData <- function() {
  set.seed(0)
  td <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  StratData(td$signal, parts = td$parts, ties = td$ties,
            signalColumn = c("a", "b"), zColumn = "Hight", siteColumn = "SIT")
}

agePriors <- function() {
  structure(list(
    "alpha_site1" = UniformPrior(min = 10, max = 60),
    "alpha_site2" = UniformPrior(min = -10, max = 60),
    "alpha_site3" = UniformPrior(min = -10, max = 60),
    "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.1)),
    class = c("list", "StratPrior"))
}

padded <- function(rng) {
  pad <- 0.25 * diff(rng)
  c(rng[[1]] - pad, rng[[2]] + pad)
}

test_that("auto knotRange uses the configured column names (RT-370)", {
  data <- makeNonDefaultData()

  # precondition: the canonical column literals really are absent
  expect_null(data[["signal"]][["height"]])
  expect_null(data[["signal"]][["site"]])
  expect_equal(data[["zColumn"]], "Hight")
  expect_equal(data[["siteColumn"]], "SIT")

  # height scale: priors are generated automatically
  expect_message(
    model <- StratModel(data, priors = NULL, alignmentScale = "height",
                        sedModel = "site", alphaPosition = "bottom",
                        flexibleKnots = FALSE),
    "knotRange not specified"
  )
  knotRange <- model[[c("splineBase", "knotRange")]]

  # pre-fix this was c(-Inf, Inf) and StratModel() died inside seq()
  expect_true(all(is.finite(knotRange)))
  expect_equal(knotRange,
               padded(range(data[[c("signalAttr", "siteHeights")]][[1L]])))
})

test_that("auto knotRange is on the alignment scale (RT-371)", {
  data <- makeNonDefaultData()
  priors <- agePriors()

  expect_message(
    model <- StratModel(data, priors, alignmentScale = "age",
                        sedModel = "site", alphaPosition = "bottom",
                        flexibleKnots = FALSE),
    "knotRange not specified"
  )
  knotRange <- model[[c("splineBase", "knotRange")]]

  # the expected value, recomputed independently: every site's signal ages,
  # converted at the prior medians, padded by 25%.
  medianPars <- vapply(priors, function(pr) {
    do.call(pr[["Q"]], c(p = 0.5, pr[["args"]]))
  }, numeric(1))
  ages <- unlist(.sb_age_convert(data, model[["ind"]], medianPars)[["signal"]],
                 use.names = FALSE)
  expect_equal(knotRange, padded(range(ages)))

  # ... and it is NOT the raw-height range the pre-fix code produced. The two
  # differ by more than rounding: heights run 1-80, ages roughly 0-34.
  rawHeightRange <- padded(range(unlist(
    data[[c("signalAttr", "siteHeights")]], use.names = FALSE)))
  expect_false(isTRUE(all.equal(knotRange, rawHeightRange)))

  # the whole point of the range: `.GenerateInitialState()` must be able to
  # find a draw whose converted ages all lie inside it. This is what RT-371's
  # traced symptom ("Could not generate a valid initial state after 500
  # attempts") is about, so assert it end-to-end rather than re-checking the
  # vector the range was derived from.
  mcmc <- StratMCMC(model, nIter = 10, nChains = 2)
  for (seed in 1:3) {
    set.seed(seed)
    state <- .GenerateInitialState(data, model, mcmc, chain = 1)
    stateAges <- state[[c("age", "signalFlat")]]
    expect_true(min(stateAges) >= knotRange[[1]])
    expect_true(max(stateAges) <= knotRange[[2]])
  }
})

test_that("auto knotRange is unchanged on the height scale with default columns", {
  # Value-identity guard: the RT-370/371 rewrite must leave the canonical
  # height-scale case byte-identical. `siteHeights[[1]]` is the same set of
  # values the old `data$signal$height[data$signal$site == sites[1]]`
  # expression selected.
  set.seed(0)
  td <- .GenerateTestData("multi")
  data <- StratData(td$signal, parts = td$parts, signalColumn = c("a", "b"))

  oldRefHeights <- data[["signal"]][["height"]][
    data[["signal"]][["site"]] == data[["sites"]][1L]
  ]
  expect_gt(length(oldRefHeights), 0)

  expect_message(
    model <- StratModel(data, priors = NULL, alignmentScale = "height",
                        sedModel = "site", alphaPosition = "bottom",
                        flexibleKnots = FALSE),
    "knotRange not specified"
  )
  expect_equal(model[[c("splineBase", "knotRange")]],
               padded(range(oldRefHeights, na.rm = TRUE)))
})
