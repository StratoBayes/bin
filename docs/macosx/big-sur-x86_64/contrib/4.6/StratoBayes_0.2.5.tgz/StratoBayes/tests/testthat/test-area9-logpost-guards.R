# Regression tests for area-9 log-posterior guard findings.
#
#   #896 (RT-707) — .OverlapCheck indexed out of bounds for a single-site model
#   #895 (RT-706) — .sb_logpost's joint-at-beta branch had no NaN screen

test_that(".OverlapCheck returns TRUE for a single section (#896)", {
  # `1:(lx - 1)` counts DOWN when lx == 1, so the old loop reached
  # overlap_mat[2, 1] on a 1 x 1 matrix.
  expect_true(.OverlapCheck(list(seq(0, 10, length.out = 30)), ovMin = 15))
  expect_true(.OverlapCheck(list(1), ovMin = 15))
})

test_that(".OverlapCheck still discriminates connected from disjoint sections", {
  connected <- list(seq(0, 10, length.out = 30), seq(2, 12, length.out = 30))
  disjoint  <- list(seq(0, 10, length.out = 30), seq(90, 100, length.out = 30))

  expect_true(.OverlapCheck(connected, ovMin = 5))
  expect_false(.OverlapCheck(disjoint, ovMin = 5))
})

# `.sb_logpost(marginal = FALSE)` is the R engine's joint-at-beta path and the
# Tier-1 parity partner of compute_logpost(), which folds a NaN signal term onto
# the -1e30 sentinel. Without the same fold here the caller's
# sum(..., na.rm = TRUE) DROPS the signal term and scores the state on prior
# alone.
test_that(".sb_logpost folds a NaN joint signal likelihood onto -1e30 (#895)", {
  lp <- .PrepareLogPostArgs(list(priors = list(metro = list(NormalPrior(0, 1)))))

  callLogpost <- function(beta) {
    .sb_logpost(
      x = 0.5, priorTypes = lp$priorTypes, priorArgs = lp$priorArgs,
      rCustomFns = lp$rCustomFns,
      B_list = list(matrix(1, nrow = 3L, ncol = 2L)),
      beta_list = list(beta),
      signalValues = list(c(1, 2, 3)),
      sigma = 1, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list()
    )
  }

  expect_false(is.nan(callLogpost(c(NaN, 0))[2]))
  expect_equal(callLogpost(c(NaN, 0))[2], -1e30)

  # A finite beta is untouched by the fold.
  expect_true(is.finite(callLogpost(c(0.5, 0.5))[2]))
})
