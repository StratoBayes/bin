# Smoke test for the curve-alignment wiring of RunStratModel().
#
# This test deliberately makes NO assertion about *which* posterior value the
# short MCMC lands on. Absolute posterior summaries from a short chain are not a
# portable oracle: the mode a finite chain settles in depends on the platform's
# RNG/BLAS stream, so an `expect_equal(alpha_b "50%", 3/4*pi)`-style check passes
# on one platform and reddens on another (observed on PR #343: same commit,
# green on GHA attempt 1, red on attempt 2, errors locally under thread
# nondeterminism). See the project note "MCMC value tests not portable".
#
# CI contract here = does-it-run + well-formed output:
#   * RunStratModel() + summary() complete without error,
#   * summary carries the expected parameter rows and >=1 alignment,
#   * every reported estimate is finite (no NA/NaN).
#
# The actual value-recovery oracle (matching case -> alpha_b ~ 3/4*pi;
# non-matching case -> boundary ~ 3/2*pi) lives in
# dev/red-team/heavy-tests/smooth-curve-alignment-recovery.R as a relative,
# multi-seed median check, where cross-platform variance is handled by the
# median over seeds rather than pretended away.

test_that("smooth curves: RunStratModel wiring runs and returns well-formed output", {

  skip_on_cran() # slow

  # Don't use parallel evaluation unless future.apply is installed
  canRunParallel <- requireNamespace("future.apply", quietly = TRUE)

  # Assert only structural, platform-independent facts about a summary().
  expect_wellformed_summary <- function(estimates,
                                        params = c("alpha_b", "gammaLog_b")) {
    expect_s3_class(estimates, "summary.StratPosterior")
    nAl <- estimates$general$overallAlignments
    expect_true(is.numeric(nAl) && nAl >= 1)
    for (a in seq_len(nAl)) {
      s <- estimates[[a]][["summary"]]
      expect_true(all(params %in% rownames(s)))
      expect_true(all(c("mean", "50%") %in% colnames(s)))
      # No NA/NaN in the estimates we key inference off. `$summary` is a
      # data.frame, so coerce the block to a numeric matrix before is.finite().
      expect_true(all(is.finite(as.matrix(s[params, c("mean", "50%")]))))
    }
  }

  # Two matching sine curves offset by 3/4*pi on the common (height) scale.
  set.seed(0)
  n1 <- 500
  x1 <- seq(0, pi, length.out = n1)
  y1 <- sin(x1)
  n2 <- 250
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2)
  x2 <- x2 - 1/2 * pi
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)

  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = 3/2 * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))

  # Path 1: sigma fixed.
  modelFixed <- StratModel(stratData = stratD,
                           priors = priors,
                           alignmentScale = "height",
                           sedModel = "site",
                           alphaPosition = "middle",
                           nKnots = 10,
                           overlapPenalty = TRUE,
                           sigmaFixed = TRUE)

  rFixed <- RunStratModel(stratObject = stratD,
                          stratModel = modelFixed,
                          nRun = 2,
                          nIter = 200,
                          nThreads = 2L, # AGENTS.md CPU cap
                          runParallel = canRunParallel,
                          visualise = FALSE,
                          seed = 1:2)

  expect_wellformed_summary(summary(rFixed))

  # Path 2: sigma estimated (the only genuinely different code path for a smoke
  # test -- matching/non-matching and n=500/30 are just data through the same
  # engine, so they are not re-exercised here; the heavy-test covers them).
  set.seed(0)
  modelEst <- StratModel(stratData = stratD,
                         priors = priors,
                         alignmentScale = "height",
                         sedModel = "site",
                         alphaPosition = "middle",
                         nKnots = 10,
                         overlapPenalty = TRUE,
                         sigmaFixed = FALSE)

  rEst <- RunStratModel(stratObject = stratD,
                        stratModel = modelEst,
                        nRun = 2,
                        nIter = 200,
                        nThreads = 2L, # AGENTS.md CPU cap
                        runParallel = canRunParallel,
                        visualise = FALSE,
                        seed = 1:2)

  expect_wellformed_summary(summary(rEst))
})
