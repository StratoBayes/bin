# Under `flexibleKnots = TRUE`, `.CreateSplineS()` stores the penalty matrix `D`
# at a reference span and the engine rescales it to each alignment as
# D_a = (ageSpan / span(a))^3 * D_base. Equally spaced knots make that law
# exact, so the reference span cancels: `D * ageSpan^3` is the same matrix
# whatever range is chosen.
#
# It was chosen by drawing the alignment from the priors (GH #1400). That is
# free for the sampler, but `.LambdaStar()` reads `tr(D)` without undoing the
# rescale, so the GH #551 floor inherited the draw -- 58.8x between builds of
# one model on stratData2, from a 3.9x spread in the span, cubed. Two
# identically parameterised models therefore carried different priors.
#
# The reference is now the prior medians, matching the fixed-knot branch
# (RT-371). `.PriorsValidity()` has already called every `Q` at p = 0.5 by
# then, so a broken quantile function still surfaces there, not here -- the
# last block pins that ordering.

test_that("the reference span cancels out of the penalty law", {
  # Why the median is free to differ from any draw: for equally spaced knots
  # tr(D) * span^3 is invariant to both the scale and the origin of the range.
  base <- .bsplinepen(seq(0, 10, length.out = 6), norder = 4)
  scaled <- .bsplinepen(seq(0, 70, length.out = 6), norder = 4)
  shifted <- .bsplinepen(seq(-33, -23, length.out = 6), norder = 4)

  expect_equal(sum(diag(scaled)) * 70^3, sum(diag(base)) * 10^3)
  expect_equal(sum(diag(shifted)) * 10^3, sum(diag(base)) * 10^3)
  # the whole matrix, not just its trace
  expect_equal(scaled * 70^3, base * 10^3)
})

test_that("a flexible-knot spline base is identical between builds (#1400)", {
  mk <- function() {
    suppressMessages(StratModel(stratData2, stratPrior2,
                                alignmentScale = "age", sedModel = "s",
                                alphaPosition = "b", nKnots = 5,
                                sigmaFixed = c(0.5, 0.5)))
  }
  set.seed(1)
  first <- mk()
  # an intervening draw is what used to move the reference span
  invisible(runif(7))
  second <- mk()

  expect_identical(first[["splineBase"]], second[["splineBase"]])
  expect_identical(first[[c("priors", "gibbs")]], second[[c("priors", "gibbs")]])
})

test_that("the #551 floor no longer moves between builds (#1400)", {
  mk <- function() {
    suppressMessages(StratModel(stratData2, stratPrior2,
                                alignmentScale = "age", sedModel = "s",
                                alphaPosition = "b", nKnots = 5,
                                sigmaFixed = c(0.5, 0.5)))
  }
  set.seed(1)
  floors <- vapply(seq_len(8), function(i) {
    invisible(runif(i))
    mk()[[c("priors", "gibbs", "lambdaMin")]][[1]]
  }, numeric(1))
  expect_length(unique(floors), 1L)

  # and it is still the scale-relative floor, not a constant that happens to
  # be stable: it tracks `.LambdaStar()` of the base actually stored.
  m <- mk()
  y <- .EnsurePreExtracted(stratData2)[[
    c("signalAttr", "signalValuesVec")]][[1]]
  expect_equal(m[[c("priors", "gibbs", "lambdaMin")]][[1]],
               .LambdaFloorRel * .LambdaStar(m[["splineBase"]], y))
})

test_that("model setup does not consume the ambient stream (#1400)", {
  # `sigmaFixed` supplied so the per-site BayesianSpline() sigma estimate --
  # a genuine MCMC, and legitimately random -- does not run.
  for (flexible in c(TRUE, FALSE)) {
    set.seed(1)
    before <- .Random.seed
    invisible(suppressMessages(
      StratModel(stratData1, alignmentScale = "height", sedModel = "site",
                 nKnots = 10, sigmaFixed = 0.5, flexibleKnots = flexible)))
    expect_identical(.Random.seed, before)
  }
})

test_that(".MetroPriorMedians reads each prior's median", {
  priors <- list(a = Prior(runif, dunif, qunif, min = 2, max = 6),
                 b = Prior(rnorm, dnorm, qnorm, mean = -3, sd = 10))
  expect_equal(.MetroPriorMedians(priors), c(a = 4, b = -3))

  set.seed(1)
  before <- .Random.seed
  invisible(.MetroPriorMedians(priors))
  expect_identical(.Random.seed, before)
})

test_that(".WithPreservedSeed restores the stream, including on error", {
  set.seed(42)
  before <- .Random.seed
  expect_equal(.WithPreservedSeed(runif(3)), {
    set.seed(42); runif(3)
  })
  set.seed(42)
  invisible(.WithPreservedSeed(runif(3)))
  expect_identical(.Random.seed, before)

  set.seed(42)
  expect_error(.WithPreservedSeed(stop("boom")), "boom")
  expect_identical(.Random.seed, before)

  # an unseeded session must stay unseeded: a restored `.Random.seed` that was
  # never there would silently fix the stream for everything after it.
  if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
    rm(".Random.seed", envir = globalenv())
  }
  invisible(.WithPreservedSeed(runif(1)))
  expect_false(exists(".Random.seed", envir = globalenv(), inherits = FALSE))
})

test_that("prior validation draws nothing but still checks R and Q", {
  set.seed(1)
  before <- .Random.seed
  expect_true(.PriorsValidity(stratPrior2))
  expect_identical(.Random.seed, before)

  # `.CreateSplineS()` now calls Q(0.5) on the default path, so this ordering
  # is what keeps a broken quantile function reported against its own prior.
  broken <- stratPrior2
  broken[["alpha_site1"]] <- Prior(runif, dunif,
                                   function(p, ...) stop("no quantile"),
                                   min = 0, max = 1)
  expect_error(.PriorsValidity(broken), "alpha_site1")
  expect_error(.PriorsValidity(broken), "Q function")
})
