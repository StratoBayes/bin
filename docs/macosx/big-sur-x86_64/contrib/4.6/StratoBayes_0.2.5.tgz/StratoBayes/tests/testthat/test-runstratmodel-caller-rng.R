# `RunStratModel` invents a model name from a time+PID seed when `modelName` is
# NULL. That draw runs in the global RNG stream, and the restore afterwards is
# conditional on a numeric `seed` -- which defaults to FALSE. So without the
# restore, `set.seed(k)` before an unseeded run buys nothing: the sampler starts
# from a stream keyed on the wall clock. Measured drift, pre-fix, on this
# fixture: max |a - b| = 473.9 across two runs of the same seeded call.

test_that("a caller's set.seed survives the model-name draw (unseeded run)", {
  skip_on_cran()

  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 8, sigmaFixed = TRUE)
  mc <- StratMCMC(sm, nIter = 40L, nChains = 2L, nThin = 1L, nThreads = 1L)

  # modelName unset and seed left at its FALSE default: the only configuration
  # in which the restore is reachable.
  Run <- function() {
    set.seed(99)
    suppressWarnings(RunStratModel(stratData1, sm, mc, nRun = 1L,
                                   runParallel = FALSE, visualise = FALSE,
                                   quiet = TRUE))$samples[, , 1, 1]
  }

  expect_identical(as.numeric(Run()), as.numeric(Run()))
})
