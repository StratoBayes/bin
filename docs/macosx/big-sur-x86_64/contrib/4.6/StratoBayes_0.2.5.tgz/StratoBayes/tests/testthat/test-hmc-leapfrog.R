# Tests for HMC leapfrog proposal (Phase B)
#
# Verifies:
#   1. Leapfrog integrator's energy error is second order in the step size
#   2. .sb_gradient_at() matches .sb_compute_gradient() at current params
#   3. .sb_sync_gibbs() correctly updates engine chain state
#   4. Full HMC proposal runs within MCMC without error
#   5. HMC proposals produce non-degenerate acceptance across datasets

# ── Helper: set up engine + state for HMC testing ───────────────────────────

setup_hmc_engine <- function(sData, sModel, knotRange, sigmaFixed = TRUE) {
  if (sModel$flexibleKnots || !isTRUE(sigmaFixed)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      flexibleKnots = FALSE,
      knotRange = knotRange,
      sigmaFixed = sigmaFixed
    )
  }
  td <- file.path(tempdir(), paste0("hmc_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(6418)
  result <- RunStratModel(gradientProposals = "on", 
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "htest", engine = "R"
  )

  data_obj <- result$data
  model_obj <- result$model
  mcmc_obj <- readRDS(file.path(td, "htest_mcmc_run_1.rds"))
  state <- mcmc_obj$recentState[[1]]

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine <- StratoBayes:::.HMCCreateEngine(data_obj, model_obj, state)

  list(
    engine = engine,
    data_obj = data_obj,
    model_obj = model_obj,
    mcmc_obj = mcmc_obj,
    state = state,
    td = td
  )
}


# ── Test: .sb_gradient_at matches .sb_compute_gradient at current params ─────

test_that(".sb_gradient_at returns same gradient as .sb_compute_gradient", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  params <- setup$state$metro$parameters

  # .sb_gradient_at (the new export)
  result_at <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)
  expect_true(result_at$ok)

  # .sb_compute_gradient (the existing test export)
  tiesCallback <- if ("ties" %in% names(setup$data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        setup$data_obj, setup$model_obj$ind, parameters, FALSE)
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(setup$data_obj, setup$model_obj, tmpState)
    }
  }
  test_engine <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$mcmc_obj$recentState,
    tiesCallback = tiesCallback
  )
  result_cg <- StratoBayes:::.sb_compute_gradient(test_engine, 1L)

  expect_equal(result_at$grad, result_cg$grad, tolerance = 1e-10)
  expect_equal(result_at$logPost, result_cg$logPost, tolerance = 1e-10)
})


# ── Test: leapfrog energy conservation ──────────────────────────────────────

test_that("leapfrog conserves the Hamiltonian to second order in the step", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # Energy conservation is a property of the SYMPLECTIC integrator on a SMOOTH
  # potential.  The default overlap penalty is piecewise-constant in the ages
  # (an integer section-overlap count), hence discontinuous: leapfrog cannot
  # conserve energy across a step that crosses a section boundary (ΔH jumps by
  # one adjustment value, ~15 nats here).  Before RT-101 this test passed only
  # because hmc_eval_gradient/sb_gradient_at froze the overlap term for the
  # whole trajectory; the fix correctly recomputes it, exposing the jump.  We
  # therefore test the integrator on a smooth potential (overlapPenalty = FALSE)
  # — the property this test actually asserts.  HMC/NUTS remain valid samplers on
  # the discontinuous potential (the MH correction uses the true H values); they
  # are just less efficient near boundaries.
  sModel <- StratoBayes::StratModel(
    stratData      = stratData1,
    priors         = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel       = stratModel1$sedModel,
    flexibleKnots  = FALSE,
    knotRange      = c(-5, 12),
    overlapPenalty = FALSE
  )
  setup <- setup_hmc_engine(stratData1, sModel, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  freeIdx <- setup$model_obj$ind$paramNotFixed
  nFree <- setup$model_obj$parametersLengthNotFixed
  params <- setup$state$metro$parameters

  gradResult <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)
  expect_true(gradResult$ok)

  massMatInv <- rep(1.0, nFree)
  set.seed(3847)
  p <- rnorm(nFree)
  hOld <- -gradResult$logPost + 0.5 * sum(p^2 * massMatInv)

  gradFn <- function(full_params)
    StratoBayes:::.sb_gradient_at(setup$engine, 1L, full_params)

  trajectory <- 0.02
  DeltaH <- function(stepSize) {
    result <- StratoBayes:::.HMCLeapfrog(
      q = params[freeIdx], p = p, grad = gradResult$grad,
      stepSize = stepSize, nSteps = as.integer(round(trajectory / stepSize)),
      massMatInv = massMatInv, gradFn = gradFn,
      freeIdx = freeIdx, fullParams = params,
      temperature = 1.0
    )
    expect_false(result$divergent)
    abs(-result$logPost + 0.5 * sum(result$p^2 * massMatInv) - hOld)
  }

  deltaH <- vapply(c(1e-3, 5e-4, 2.5e-4), DeltaH, numeric(1))
  ratio <- deltaH[-length(deltaH)] / deltaH[-1]

  # A symplectic integrator on a smooth potential has |delta_H| = O(stepSize^2),
  # so halving the step at a fixed trajectory length quarters it. A ratio of 2
  # means a first-order error -- a gradient inconsistent with the log-posterior
  # it differentiates -- and ~1 a discontinuity in the potential. The ratio is
  # the testable quantity rather than |delta_H| itself, whose magnitude tracks
  # the curvature wherever the seeded run above lands and so varies by an order
  # of magnitude across the package's state (#986).
  expect_true(
    all(ratio > 3.5 & ratio < 4.5),
    info = sprintf("delta_H = %s; ratios = %s",
                   paste(signif(deltaH, 4), collapse = ", "),
                   paste(signif(ratio, 4), collapse = ", "))
  )
})


# ── Test: .sb_sync_gibbs updates engine state ───────────────────────────────

test_that(".sb_sync_gibbs correctly updates Gibbs state", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  params <- setup$state$metro$parameters

  # Gradient at original Gibbs state
  grad_before <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)

  # Modify Gibbs state: double all betas
  new_beta <- lapply(setup$state$gibbs$beta, function(b) b * 2)
  new_sigma <- setup$state$gibbs$sigma * 1.5
  new_lambda <- vapply(
    seq_along(setup$state$gibbs$lambda),
    function(m) setup$state$gibbs$lambda[[m]] * 0.5,
    numeric(1)
  )

  StratoBayes:::.sb_sync_gibbs(
    setup$engine, 1L, new_beta, new_sigma, new_lambda)

  # Gradient at modified Gibbs state (same params)
  grad_after <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)

  # Gradient should change because the likelihood depends on beta/sigma
  expect_true(grad_after$ok)
  expect_false(isTRUE(all.equal(grad_before$grad, grad_after$grad)),
    info = "Gradient should differ after Gibbs state change")
})


# ── Test: full MCMC with HMC runs without error ────────────────────────────

test_that("RunStratModel with HMC proposal runs without error", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), "hmc_mcmc_test")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(9241)
  result <- expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 100, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_full",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  # Check HMC was registered
  mcmc <- readRDS(file.path(td, "hmc_full_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))
  gradProp <- intersect(c("HMC", "NUTS"), colnames(mcmc$metro$proposalValid))
  expect_true(mcmc$metro$proposalValid[1, gradProp])
})


# ── Test: .UpdateStateHMC records divergences on the divergent path ───────────
# RT-221 follow-up. A divergent HMC proposal (hard integrator failure or a
# blow-up to non-finite logPost) must still populate nutsDivergent -- matching
# how .UpdateStateNUTS reports divergences regardless of acceptance -- rather
# than leaving the field at its stale/NULL value. Also exercises the
# .UpdateStateHMC divergence wiring (H0 construction + nutsDivergent), which the
# .HMCLeapfrog unit tests do not reach.
# (RT-343 removed the dedicated early return this once described; a hard
# divergence now falls through to the ordinary reject path, which sets the same
# fields. The assertions are unchanged and still pass.)
test_that(".UpdateStateHMC records nutsDivergent on a divergent proposal", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  model_obj <- setup$model_obj
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  gradIdx <- which(names(setup$mcmc_obj$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- StratoBayes:::.HMCDefaultArgs(model_obj)
  hmcArgs$adaptStepSize <- FALSE
  hmcArgs$stepSize <- 50        # deliberately oversized -> guaranteed divergence
  hmcArgs$nSteps <- 10L
  hmcArgs$divergenceMax <- 1000
  mcmc <- setup$mcmc_obj
  for (ch in seq_along(mcmc$metro$proposalArgs)) {
    mcmc$metro$proposalArgs[[ch]][[gradIdx]] <- hmcArgs
  }

  # Seed a known non-divergent value so the assertion can only pass if
  # .UpdateStateHMC actively writes the flag on the divergent-reject path.
  state <- setup$state
  state[[c("metro", "nutsDivergent")]] <- FALSE

  set.seed(11)
  updated <- StratoBayes:::.UpdateStateHMC(
    setup$data_obj, model_obj, mcmc, state, chain = 1L, proposalNumber = gradIdx)

  # Oversized step diverges and is rejected, but the divergence is now recorded.
  expect_false(isTRUE(updated[[c("metro", "accept")]]))
  expect_true(isTRUE(updated[[c("metro", "nutsDivergent")]]))
})


# ── Test: a hard HMC divergence still runs the Gibbs sweep (RT-343, #415) ─────
# Every sampler iteration updates the HMC/NUTS block and then refreshes
# (beta, sigma, lambda) with an exact Gibbs draw, regardless of accept/reject.
# `.UpdateStateHMC` used to early-return the untouched state when the leapfrog
# trajectory came back with a non-finite log-posterior, skipping that sweep --
# unlike its own ordinary reject path, NUTS, and plain MH, which all sweep
# unconditionally. Gibbs state is Tier-1 maintained-parity core
# (docs/r-engine-contract.md), so this is a real R-engine bug, not an expected
# Tier-2 divergence.
#
# The skip was a stationarity defect, not untidiness: it made the per-iteration
# kernel differ from the intended one by d(x)[delta_x - G], and d (the
# hard-divergence probability) rises as sigma falls via the 1/sigma^2 curvature
# coupling, so the skip landed unevenly across parameter space and made
# small-sigma states sticky. Full derivation:
# dev/red-team/proofs/RT-343-hmc-divergence-gibbs-skip.md.
#
# Pre-fix this test fails on the gibbs assertions: the early return left beta,
# sigma and lambda bit-identical to their pre-call values.
test_that(".UpdateStateHMC Gibbs-sweeps on a hard divergence (RT-343)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  # sigmaFixed = FALSE: the pi-invariance argument for this fix turns on sigma
  # dependence (1/sigma^2 curvature coupling), so sigma must actually be free
  # for the sigma assertion below to exercise it.
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12), sigmaFixed = FALSE)
  on.exit(unlink(setup$td, recursive = TRUE))

  model_obj <- setup$model_obj
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  gradIdx <- which(names(setup$mcmc_obj$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- StratoBayes:::.HMCDefaultArgs(model_obj)
  hmcArgs$adaptStepSize <- FALSE
  hmcArgs$stepSize <- 50        # deliberately oversized -> guaranteed divergence
  hmcArgs$nSteps <- 10L
  hmcArgs$divergenceMax <- 1000
  mcmc <- setup$mcmc_obj
  for (ch in seq_along(mcmc$metro$proposalArgs)) {
    mcmc$metro$proposalArgs[[ch]][[gradIdx]] <- hmcArgs
  }

  state <- setup$state
  set.seed(11)
  updated <- StratoBayes:::.UpdateStateHMC(
    setup$data_obj, model_obj, mcmc, state, chain = 1L, proposalNumber = gradIdx)

  # Confirm the fixture really does take the hard-divergence branch, so the
  # assertions below cannot pass vacuously via the ordinary reject path.
  # nutsDivergent alone would also be TRUE for a Hamiltonian blow-up with a
  # finite logPost, which the pre-fix code did NOT early-return on -- logPostNew
  # is the exact discriminator, since .HMCLeapfrog only sets `divergent` (and
  # hence takes the deleted early-return branch) when it also returns -Inf.
  expect_false(isTRUE(updated[[c("metro", "accept")]]))
  expect_true(isTRUE(updated[[c("metro", "nutsDivergent")]]))
  expect_false(is.finite(updated[[c("metro", "logPostNew")]]))

  # The position must not move -- a divergent trajectory is a rejection ...
  expect_equal(updated[[c("metro", "parameters")]],
               state[[c("metro", "parameters")]])

  # ... but the nuisance block must have been resampled, not left stale.
  expect_false(identical(updated[[c("gibbs", "beta")]],
                         state[[c("gibbs", "beta")]]))
  expect_false(identical(updated[[c("gibbs", "lambda")]],
                         state[[c("gibbs", "lambda")]]))
  expect_false(identical(updated[[c("gibbs", "sigma")]],
                         state[[c("gibbs", "sigma")]]))

  # The stored log-posterior must be recomputed at the post-sweep (sigma,
  # lambda), as the ordinary reject path does -- not carried over stale.
  expect_true(is.finite(updated[[c("metro", "logPost")]]))
  expect_equal(updated[[c("metro", "logPost")]],
               sum(updated[[c("metro", "logPostSep")]], na.rm = TRUE))
})


# ── Test: .UpdateState clears acceptProb before dispatching (RT-346, #417) ────
# Guards the staleness hazard the new field introduces. `state` persists across
# iterations and only NUTS writes `acceptProb`, so without an explicit clear a
# probability left by a NUTS iteration would still be attached when a plain MH
# proposal runs, and .SaveMCMChistory would record it against the wrong proposal
# slot -- corrupting that slot's adaptation instead of NUTS's.
test_that(".UpdateState clears a stale acceptProb before dispatch (RT-346)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  model_obj <- setup$model_obj
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  mcmc <- setup$mcmc_obj
  # Force selection onto a non-gradient proposal slot. The slot must also carry
  # a positive adapted probability: selection weight is the product of the two
  # factors, and late adaptation hands the cold chain's Prior budget to
  # Multivariate, so weighting Prior alone leaves the product all-zero and
  # .UpdateState stops on its own guard before it can dispatch.
  propNames <- names(mcmc$propose)
  mhIdx <- which(!propNames %in% c("HMC", "NUTS") &
                   mcmc$metro$proposalProbability[1, ] > 0)[[1]]
  weights <- mcmc$metro$proposalProbabilityWeights
  weights[] <- 0
  weights[, mhIdx] <- 1
  mcmc$metro$proposalProbabilityWeights <- weights

  # Plant a value as though the previous iteration had been NUTS.
  state <- setup$state
  state[[c("metro", "acceptProb")]] <- 0.99

  set.seed(23)
  updated <- StratoBayes:::.UpdateState(setup$data_obj, model_obj, mcmc,
                                        state, chain = 1L)

  expect_equal(updated[[c("metro", "proposalNumber")]], mhIdx)
  # Must not still be 0.99: either cleared to NA or dropped entirely. Written out
  # rather than via `%||%` so a length-0 value fails loudly instead of making
  # expect_true() error on logical(0).
  staleProb <- updated[[c("metro", "acceptProb")]]
  expect_true(is.null(staleProb) || (length(staleProb) == 1L && is.na(staleProb)))
})


# ── Test: HMC on age-scale model with ties ──────────────────────────────────

test_that("HMC runs on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- file.path(tempdir(), "hmc_data2")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(3072)
  expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData2, stratModel = sModel,
    nIter = 100, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_d2",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ══════════════════════════════════════════════════════════════════════════════
# Phase C: C++ engine HMC tests
# ══════════════════════════════════════════════════════════════════════════════

# ── Test: C++ engine HMC runs without error (stratData1) ─────────────────────

test_that("C++ engine HMC runs without error (stratData1)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d1"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(5183)
  result <- expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp1",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  # Verify HMC was registered
  mcmc <- readRDS(file.path(td, "hmc_cpp1_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))

  # Verify result has reasonable logPost trajectory (not stuck at one value)
  rds_file <- file.path(td, "hmc_cpp1_binarysamples_run_1.rds")
  tsv_file <- file.path(td, "hmc_cpp1_samples_run_1.txt")
  if (file.exists(rds_file)) {
    samples <- as.data.frame(readRDS(rds_file))
  } else {
    samples <- read.delim(tsv_file, sep = "\t")
  }
  logPost <- samples$posterior
  expect_true(sd(logPost) > 0,
    info = "logPost should vary across samples (not stuck)")
})


# ── Test: C++ engine HMC runs on age-scale model with ties (stratData2) ──────

test_that("C++ engine HMC runs on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d2"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(7642)
  expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData2, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ── Test: C++ engine HMC runs on partition model (stratData3) ─────────────────

test_that("C++ engine HMC runs on partition model (stratData3)", {
  skip_on_cran()

  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData3,
    priors = stratModel3$priors$metro,
    alignmentScale = stratModel3$alignmentScale,
    sedModel = stratModel3$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 20)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d3"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(2917)
  expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData3, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp3",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ── Test: C++ HMC produces HMC-specific acceptances (not all-accept no-op) ───

test_that("C++ engine HMC produces genuine HMC proposals", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_genuine"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4619)
  result <- RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_gen",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Check that HMC proposals appear in the sample data
  rds_file <- file.path(td, "hmc_gen_binarysamples_run_1.rds")
  tsv_file <- file.path(td, "hmc_gen_samples_run_1.txt")
  if (file.exists(rds_file)) {
    samples <- as.data.frame(readRDS(rds_file))
  } else {
    samples <- read.delim(tsv_file, sep = "\t")
  }
  mcmc <- readRDS(file.path(td, "hmc_gen_mcmc_run_1.rds"))

  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  expect_length(hmcIdx, 1)

  # Gradient-based proposals should be present
  hmc_proposals <- samples$proposal_number == hmcIdx
  expect_true(sum(hmc_proposals) > 0,
    info = "At least some HMC proposals should appear in the sample")

  # Not all HMC proposals should be accepted (that would indicate the
  # Phase B no-op bug where proposed == current)
  if (sum(hmc_proposals) >= 5) {
    hmc_accepts <- samples$proposal_accepted[hmc_proposals]
    expect_true(any(hmc_accepts == 0) && any(hmc_accepts == 1),
      info = "HMC should have both accepted and rejected proposals")
  }
})


# ══════════════════════════════════════════════════════════════════════════════
# Phase D: Dual averaging step size adaptation tests
# ══════════════════════════════════════════════════════════════════════════════

# ── Test: dual averaging leaves an adapted step size in the persisted mcmc ────
# `.sb_hmc_get_adapted()` needs a live engine pointer, which RunStratModel()
# does not hand back; what is observable after a run is the state it wrote to
# the mcmc RDS, so that is what the name promises.

test_that("dual averaging writes an adapted step size to the persisted mcmc object", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_state"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(6731)
  result <- RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Verify HMC was registered and final step size was adapted

  mcmc <- readRDS(file.path(td, "hmc_da_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))

  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- mcmc$metro$proposalArgs[[1]][[hmcIdx]]

  # After adaptation ends, adaptStepSize should be FALSE
  expect_false(hmcArgs[["adaptStepSize"]])

  # stepSize should have changed from the initial default.  Ask production for
  # the heuristic rather than re-deriving it: a duplicated formula that drifts
  # makes this expect_false() easier to satisfy, so it would weaken silently
  # instead of catching the change.
  initialEps <- .HMCDefaultArgs(sModel)[["stepSize"]]
  expect_false(
    isTRUE(all.equal(hmcArgs[["stepSize"]], initialEps, tolerance = 0.01)),
    info = "Step size should differ from initial heuristic after DA"
  )
})


# ── Test: Dual averaging adapts step size toward target acceptance ─────────────

test_that("Dual averaging produces adapted step size (C++ engine)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_adapt"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  # Run with enough iterations for DA to converge
  set.seed(8294)
  result <- RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 500, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Check adapted step size is finite and positive (finite-temperature chains only)
  mcmc <- readRDS(file.path(td, "hmc_da2_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  finiteChains <- which(is.finite(mcmc$temper$temperatures))
  for (ch in finiteChains) {
    eps <- mcmc$metro$proposalArgs[[ch]][[hmcIdx]][["stepSize"]]
    expect_true(is.finite(eps) && eps > 0,
      info = sprintf("Chain %d: adapted step size should be finite and positive", ch))
  }
})


# ── Test: R-engine dual averaging ───────────────────────────────────────────

test_that("R-engine HMC with dual averaging runs without error", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), "hmc_da_r")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4518)
  result <- expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da_r",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  mcmc <- readRDS(file.path(td, "hmc_da_r_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- mcmc$metro$proposalArgs[[1]][[hmcIdx]]

  # Step size should be finite and positive after adaptation
  expect_true(is.finite(hmcArgs[["stepSize"]]) && hmcArgs[["stepSize"]] > 0)
  # Adaptation should be turned off after warmup
  expect_false(hmcArgs[["adaptStepSize"]])
})


# ── Test: DA with age-scale model + ties ──────────────────────────────────────

test_that("Dual averaging works on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_d2"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(3159)
  expect_no_error(RunStratModel(gradientProposals = "on", 
    stratObject = stratData2, stratModel = sModel,
    nIter = 300, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da_d2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  mcmc <- readRDS(file.path(td, "hmc_da_d2_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  eps <- mcmc$metro$proposalArgs[[1]][[hmcIdx]][["stepSize"]]
  expect_true(is.finite(eps) && eps > 0)
})
