# Regression tests for two correctness bugs found reviewing the
# feature/signal-offsets x beta-marginal-MH merge (PR #249):
#
#  1. The beta-marginal branch of .sb_logpost()/signal_logmarginal() silently
#     ignored signal offsets (R-engine and C++-engine disagreed with each
#     other AND with the correct offset-adjusted marginal). Fixed by
#     offset-adjusting yy/Bty (and adding the delta log-prior) in both the
#     R-callable reference (src/LogPost.cpp) and the production engine
#     (signal_logmarginal(), src/MCMCEngine.cpp).
#  2. HMC/NUTS accept paths (and the gradient-failure self-transition) never
#     refreshed the cached Bty for the delta the same Gibbs sweep just drew,
#     so beta's next conditional and the stored logPost were one sweep stale
#     whenever offsets + a gradient proposal were both active. Fixed by
#     routing every post-Gibbs H/tBy refresh through one shared
#     refresh_htby_after_gibbs() helper.
#  3. .sb_logpost()/.sb_gibbs() performed no validation of the offset
#     arguments, so a NULL/mismatched-length delta_list or nGroups = 0 with
#     hasOffsets = TRUE reached raw, unchecked Rcpp::List/NumericVector
#     indexing inside the RT-433 impl frame (reproduced as a segfault during
#     review). Fixed with wrapper-level stop() checks.

# ══════════════════════════════════════════════════════════════════════════════
# Helper: minimal 2-site, 2-group offsets dataset + fixed-knots model
# (fixed knots so gradientProposals = "on" reliably registers NUTS)
# ══════════════════════════════════════════════════════════════════════════════

.offset_fixture <- function(n = 25, offset = 1.5, noise_sd = 0.1, seed = 101) {
  set.seed(seed)
  h <- seq(0, 10, length.out = n)
  sig <- data.frame(
    site   = c(rep("site_1", n), rep("site_2", n)),
    height = c(h, h),
    value  = c(sin(h) + rnorm(n, 0, noise_sd),
               sin(h) + offset + rnorm(n, 0, noise_sd))
  )
  grp <- data.frame(site = c("site_1", "site_2"), group = c("A", "B"),
                     stringsAsFactors = FALSE)
  d <- StratData(signal = sig, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, knotRange = c(-2, 12),
                  flexibleKnots = FALSE, signalOffsets = TRUE,
                  sigmaFixed = TRUE)
  list(data = d, model = m)
}

# ══════════════════════════════════════════════════════════════════════════════
# 1. .sb_logpost(marginal = TRUE) must actually depend on the offsets
# ══════════════════════════════════════════════════════════════════════════════

test_that(".sb_logpost(marginal = TRUE, hasOffsets = TRUE) is sensitive to delta", {
  p <- 4L; n <- 6L; sigma <- 1; lambda <- 1

  Delta <- matrix(0, p - 2, p)
  for (i in seq_len(p - 2)) Delta[i, i:(i + 2)] <- c(1, -2, 1)
  D <- crossprod(Delta)

  set.seed(11)
  B <- matrix(stats::rnorm(n * p), n, p)
  y <- as.numeric(seq_len(n))
  otg <- rep(1:2, length.out = n)  # 2 groups

  call_marginal <- function(delta) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(B), beta_list = list(numeric(p)),
      signalValues = list(y), sigma = sigma, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      hasOffsets = TRUE, delta_list = list(delta), obsToGroup_list = list(otg),
      tau = 1,
      marginal = TRUE, lambda = lambda, Dmat = D, flexTerm = 0)
  }

  res0 <- call_marginal(c(0, 0))
  res1 <- call_marginal(c(3, -3))

  # Before the fix these were IDENTICAL (the marginal branch ignored delta
  # entirely) regardless of how large the offset was.
  expect_false(isTRUE(all.equal(res0[2], res1[2])),
    info = "marginal signal log-likelihood must change when delta changes")
  expect_true(all(is.finite(res0)))
  expect_true(all(is.finite(res1)))
})

# ══════════════════════════════════════════════════════════════════════════════
# 2. The R-callable reference and the production engine must agree on the
# beta-marginal WITH offsets active
# (mirrors expect_logpost_marginal_equiv in test-cpp-logpost-equivalence.R,
# but exercises hasOffsets = TRUE, which that file's fixtures never do)
#
# `.LogPost()` marshals into the Rcpp export `.sb_logpost()`, so the two sides
# are LogPost.cpp against MCMCEngine.cpp -- independent implementations, but
# not R engine against C++ engine (docs/r-engine-contract.md:63).
# ══════════════════════════════════════════════════════════════════════════════

test_that("reference and engine BETA-MARGINAL log-posteriors agree with offsets active", {
  skip_on_cran()

  fx <- .offset_fixture(seed = 202)
  d <- fx$data; m <- fx$model

  td <- file.path(tempdir(), paste0("offmarg_",
                   paste(sample(c(letters, 0:9), 10L, TRUE), collapse = "")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(11)
  result <- RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 15, nChains = 2L, seed = 1,
    quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "offmarg", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "offmarg_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj, state = state_obj
  )

  for (ch in seq_along(state_obj)) {
    params <- state_obj[[ch]]$metro$parameters
    r_comp <- StratoBayes:::.LogPost(data_obj, model_obj, state_obj[[ch]],
                                     marginal = TRUE)
    cpp <- StratoBayes:::.sb_eval_logpost(engine_ptr, ch, params,
                                          debug = TRUE, marginal = TRUE)

    expect_true(isTRUE(cpp$ok),
      info = sprintf("chain %d: engine reached compute_logpost (marginal)", ch))

    r_total <- sum(r_comp, na.rm = TRUE)
    expect_equal(cpp$logPost, r_total, tolerance = 1e-8,
      info = sprintf("chain %d total (marginal, offsets): R=%.12g cpp=%.12g",
                     ch, r_total, cpp$logPost))
  }
})

# ══════════════════════════════════════════════════════════════════════════════
# 3. HMC/NUTS accept path must not leave Bty stale w.r.t. the redrawn delta
# ══════════════════════════════════════════════════════════════════════════════
#
# sigmaFixed = TRUE + offsets is the combination that, pre-fix, left the
# accept-path H/tBy refresh a complete no-op (guarded only by `!sigmaFixed`,
# never by hasOffsets). gradientProposals = "on" with fixed knots reliably
# registers NUTS (see test-flexible-knots-gradient.R). After enough
# iterations, the chain's OWN stored logPost (sb_extract_metro) must match a
# from-scratch recompute at the same parameters (.sb_eval_logpost, which
# always rebuilds B/H/tBy/Bty fresh via update_spline_state) -- pre-fix, an
# HMC/NUTS accept could leave these silently diverged.

test_that("chain logPost stays consistent with a fresh recompute under offsets + gradient proposals + sigmaFixed", {
  skip_on_cran()

  fx <- .offset_fixture(seed = 303)
  d <- fx$data; m <- fx$model

  td <- file.path(tempdir(), paste0("offhtby_",
                   paste(sample(c(letters, 0:9), 10L, TRUE), collapse = "")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(22)
  result <- RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 200, nChains = 2L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "offhtby", engine = "cpp",
    gradientProposals = "on"
  )

  mcmc_obj  <- readRDS(file.path(td, "offhtby_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState
  data_obj  <- result$data
  model_obj <- result$model
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj, state = state_obj
  )

  # Run further iterations on the LIVE engine (no extract/import round-trip,
  # which would itself refresh the caches and mask the bug) so HMC/NUTS accepts
  # happen under offsets + sigmaFixed. This engine did not come from
  # RunStratModel, so its monitor counts nothing until configured; and the
  # per-chain RNGs are seeded off R's stream on the first block call only,
  # which is what set.seed() here pins.
  StratoBayes:::.sb_configure_monitor(
    engine_ptr, mcmc_obj[[c("metro", "nProposals")]][[1L]])
  set.seed(99)
  invisible(StratoBayes:::.sb_run_block(engine_ptr, nIter = 300L))

  # If the gradient path were silently disabled for this fixture the recompute
  # check below would hold trivially. The warm-up above is 200 rather than 40
  # iterations because the step size has to be adapted for this to fire at all:
  # measured 30-39 NUTS accepts here, so 5 is a floor, not a measurement.
  mon <- StratoBayes:::.sb_get_monitor(engine_ptr)
  nuts <- which(names(mcmc_obj[["propose"]]) == "NUTS")
  expect_length(nuts, 1L)
  expect_gte(sum(mon[["acceptCount"]][, nuts]), 5L)

  metro <- StratoBayes:::.sb_extract_metro(engine_ptr)
  for (ch in seq_along(metro)) {
    stored_logpost <- metro[[ch]][["metro"]][["logPost"]]
    params <- metro[[ch]][["metro"]][["parameters"]]
    fresh <- StratoBayes:::.sb_eval_logpost(engine_ptr, ch, params, marginal = TRUE)

    expect_equal(stored_logpost, fresh, tolerance = 1e-8,
      info = sprintf(
        "chain %d: stored cs.logPost=%.10g vs fresh recompute=%.10g (offsets + sigmaFixed + gradient proposals)",
        ch, stored_logpost, fresh))
  }
})

# ══════════════════════════════════════════════════════════════════════════════
# 4. .sb_logpost()/.sb_gibbs() reject malformed offset arguments cleanly
# (previously reached unchecked Rcpp indexing inside the RT-433 impl frame)
# ══════════════════════════════════════════════════════════════════════════════

test_that(".sb_logpost(hasOffsets = TRUE) errors cleanly on missing delta_list", {
  expect_error(
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(matrix(0, 1, 1)),
      beta_list = list(0), signalValues = list(0), sigma = 1,
      overlapPenalty = FALSE, signalSectionOverlap = list(), adjustments = list(),
      hasOffsets = TRUE, delta_list = NULL, obsToGroup_list = NULL, tau = 1
    ),
    "requires delta_list"
  )
})

test_that(".sb_gibbs(hasOffsets = TRUE) errors cleanly on nGroups = 0", {
  p <- 4L
  expect_error(
    StratoBayes:::.sb_gibbs(
      H_list = list(diag(p)), tBy_list = list(rep(1, p)),
      B_list = list(matrix(1, 1, p)), signalValuesVec = list(1),
      sigma_in = 1, lambda_in = 0.01, D_mat = diag(p),
      Q_fallback = list(diag(p)), aLambda = 1, bLambda = 1,
      shapeSigma = 1, bSigma_prior = 1, numBasis = p, sigmaIsFixed = TRUE,
      sigmaFixedValues = 1,
      hasOffsets = TRUE, delta_list = list(numeric(0)), tau_in = 1,
      obsToGroup_list = list(1L), nGroups = 0L
    ),
    "requires nGroups > 0"
  )
})

test_that(".sb_gibbs(hasOffsets = TRUE) errors cleanly on a short delta vector", {
  p <- 4L
  expect_error(
    StratoBayes:::.sb_gibbs(
      H_list = list(diag(p)), tBy_list = list(rep(1, p)),
      B_list = list(matrix(1, 1, p)), signalValuesVec = list(1),
      sigma_in = 1, lambda_in = 0.01, D_mat = diag(p),
      Q_fallback = list(diag(p)), aLambda = 1, bLambda = 1,
      shapeSigma = 1, bSigma_prior = 1, numBasis = p, sigmaIsFixed = TRUE,
      sigmaFixedValues = 1,
      hasOffsets = TRUE, delta_list = list(c(0, 0)), tau_in = 1,
      obsToGroup_list = list(1L), nGroups = 3L
    ),
    "length nGroups"
  )
})

# ══════════════════════════════════════════════════════════════════════════════
# 5. signalOffsets accepts only TRUE, not truthy-but-not-TRUE values
# ══════════════════════════════════════════════════════════════════════════════

test_that("StratModel treats signalOffsets = 0 as disabled, not enabled", {
  d <- StratData(signal = signalData0)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = 0)
  expect_null(m[["offsetConfig"]])
})

test_that("StratModel treats signalOffsets = NA as disabled, not enabled", {
  d <- StratData(signal = signalData0)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = NA)
  expect_null(m[["offsetConfig"]])
})
