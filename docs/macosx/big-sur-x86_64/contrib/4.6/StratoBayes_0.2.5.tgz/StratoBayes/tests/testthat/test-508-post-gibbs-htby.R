# #508: the Gibbs sweep draws a new sigma, but `.UpdateHtBy()` ran *before* it,
# so the R engine left `state$metro$H` scaled to the pre-sweep sigma. The next
# iteration's reject path hands that same H back to `.GibbsSample()`, which
# forms M = H + lambda*D and draws beta ~ N(M^-1 tBy, M^-1) -- i.e. beta came
# from its full conditional at the wrong sigma, by a factor (sigma_new /
# sigma_old)^2 that never self-heals. The C++ engine rescales after every sweep
# (`rescale_htby()`, src/MCMCEngine.cpp); the R engine now does too.
#
# Tier-1 maintained-parity core (Gibbs state) per docs/r-engine-contract.md.
#
# ORACLE: base-R `crossprod()` on the state's own B. `.UpdateHtBy()` is a thin
# wrapper over the C++ `.sb_update_htby()`, so checking H against it would
# exercise one implementation twice and could not fail.

# H_m == B_m'B_m / sigma_m^2 and tBy_m == B_m'y_m / sigma_m^2, at the sigma the
# state itself carries. This is the invariant the sweep breaks.
#
# The raw-y form assumes every fixture below leaves signalOffsets at its FALSE
# default; with offsets active tBy is B'(y - delta) instead (#1421).
expectHtByAtOwnSigma <- function(state, values, label) {
  for (m in seq_along(state[[c("metro", "B")]])) {
    bMat <- state[[c("metro", "B")]][[m]]
    sigma2 <- state[[c("gibbs", "sigma")]][[m]] ^ 2
    testthat::expect_equal(
      unname(state[[c("metro", "H")]][[m]] * sigma2), unname(crossprod(bMat)),
      tolerance = 1e-8, info = paste0(label, ", H, signal ", m))
    testthat::expect_equal(
      unname(state[[c("metro", "tBy")]][[m]] * sigma2),
      unname(drop(crossprod(bMat, values[[m]]))),
      tolerance = 1e-8, info = paste0(label, ", tBy, signal ", m))
  }
}

.htbyFixture <- function(sigmaFixed) {
  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  data <- StratData(testData$signal, parts = testData$parts,
                    ties = testData$ties, signalColumn = c("a", "b"),
                    zColumn = "Hight", siteColumn = "SIT")
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = 10, max = 60),
    "alpha_site2" = UniformPrior(min = -10, max = 60),
    "alpha_site3" = UniformPrior(min = -10, max = 60),
    "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.1)),
    class = c("list", "StratPrior"))
  model <- StratModel(data, priors, alignmentScale = "age", sedModel = "site",
                      alphaPosition = "bottom", sigmaFixed = sigmaFixed)
  list(data = data, model = model,
       mcmc = StratMCMC(model, nIter = 50, nChains = 1))
}

test_that("#508: the R engine's H tracks sigma across every iteration", {
  fix <- .htbyFixture(sigmaFixed = FALSE)
  values <- fix$data[[c("signalAttr", "signalValuesVec")]]

  set.seed(508)
  state <- .GenerateInitialState(fix$data, fix$model, fix$mcmc, 1)
  expectHtByAtOwnSigma(state, values, "initial state")

  accepts <- logical(40)
  sigmas <- numeric(40)
  for (i in seq_along(accepts)) {
    fix$mcmc[["currentIter"]] <- i
    state <- .UpdateState(fix$data, fix$model, fix$mcmc, state, 1)
    accepts[[i]] <- isTRUE(state[[c("metro", "accept")]])
    sigmas[[i]] <- state[[c("gibbs", "sigma")]][[1]]
    expectHtByAtOwnSigma(state, values, paste("iteration", i))
  }

  # Without both branches the assertion above is half a test: pre-fix, the
  # accept path was stale only from the sweep onward, the reject path from the
  # previous iteration's sweep onward.
  expect_true(any(accepts))
  expect_true(any(!accepts))
  # ...and a moving sigma is what makes the invariant bite at all.
  expect_gt(length(unique(sigmas)), 1)
})

test_that("#508: fixed sigma keeps the invariant (negative control)", {
  # sigma cannot move, so H was never stale here -- this arm passed before the
  # fix and must keep passing.
  fix <- .htbyFixture(sigmaFixed = c(0.5, 0.7))
  values <- fix$data[[c("signalAttr", "signalValuesVec")]]

  set.seed(508)
  state <- .GenerateInitialState(fix$data, fix$model, fix$mcmc, 1)
  for (i in 1:10) {
    fix$mcmc[["currentIter"]] <- i
    state <- .UpdateState(fix$data, fix$model, fix$mcmc, state, 1)
    expectHtByAtOwnSigma(state, values, paste("fixed sigma, iteration", i))
    # Discriminator: without this, an unhonoured `sigmaFixed` would silently
    # turn the control into a second copy of the positive arm above.
    expect_identical(state[[c("gibbs", "sigma")]], c(0.5, 0.7),
                     label = paste("fixed sigma, iteration", i))
  }
})

test_that("#508: both engines export an H at their own sigma", {
  skip_on_cran()

  # The parity statement, with the two engines' full run loops as the two
  # implementations and `crossprod()` as the oracle neither of them uses. The
  # C++ arm has always held (it is what #490's import fix relies on); the R arm
  # is what this issue moved.
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  model <- StratModel(stratData = stratData1, priors = stratModel1$priors$metro,
                      alignmentScale = stratModel1$alignmentScale,
                      sedModel = stratModel1$sedModel, flexibleKnots = FALSE,
                      knotRange = c(-5, 12), sigmaFixed = FALSE)
  values <- stratData1[[c("signalAttr", "signalValuesVec")]]

  for (engine in c("R", "cpp")) {
    td <- file.path(tempdir(), paste0("sb508_", engine))
    dir.create(td, showWarnings = FALSE, recursive = TRUE)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)

    set.seed(4200)
    RunStratModel(stratData1, model, nIter = 30, nChains = 1, seed = 1,
                  quiet = TRUE, visualise = FALSE, modelDir = td,
                  modelName = "s", engine = engine, nThreads = 1L)
    recent <- readRDS(file.path(td, "s_mcmc_run_1.rds"))[["recentState"]][[1]]
    expectHtByAtOwnSigma(recent, values, paste("engine", engine))
  }
})
