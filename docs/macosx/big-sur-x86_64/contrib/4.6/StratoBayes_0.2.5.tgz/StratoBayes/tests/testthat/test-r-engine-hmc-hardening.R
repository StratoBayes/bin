# R-engine HMC/NUTS hardening: RT-729 (#922), RT-730 (#923), RT-731 (#924),
# RT-732 (#925) and RT-494 (#529).


# ── RT-729 (#922): H0 = NULL disables the energy check on EVERY return ───────
# `.HMCLeapfrog`'s `@param H0` promises that `NULL` skips the divergence check
# and leaves `hamiltonianDivergent` FALSE.  The gradient-failure early return
# hard-coded TRUE, so the contract held only when the integrator ran to
# completion.  Latent (the sole `H0 = NULL` caller, `.FindReasonableEpsilon`,
# ignores the field), which is exactly why a test is what keeps it true.

test_that(".HMCLeapfrog honours H0 = NULL on a gradient failure (RT-729)", {
  failingGrad <- function(params) list(logPost = NA_real_, grad = NULL,
                                       ok = FALSE)

  leapArgs <- list(
    q = c(0, 0), p = c(1, 1), grad = c(0, 0), stepSize = 0.1, nSteps = 3L,
    massMatInv = c(1, 1), gradFn = failingGrad, freeIdx = 1:2,
    fullParams = c(0, 0), temperature = 1
  )

  noCheck <- do.call(StratoBayes:::.HMCLeapfrog, c(leapArgs, list(H0 = NULL)))
  withCheck <- do.call(StratoBayes:::.HMCLeapfrog, c(leapArgs, list(H0 = 0)))

  # Both are hard integrator failures ...
  expect_true(noCheck$divergent)
  expect_true(withCheck$divergent)
  # ... but the energy verdict exists only when an energy check was requested.
  expect_false(noCheck$hamiltonianDivergent)
  expect_true(withCheck$hamiltonianDivergent)
})


# ── RT-730 (#923): no adaptation schedule is not an error ────────────────────
# `endAdapting`/`startAdapting` absent gives freezeStart = numeric(0), so
# `!is.null(currentIter) && currentIter >= freezeStart` collapses to NA and
# `if (NA)` raised a bare "missing value where TRUE/FALSE needed".  Every other
# legacy-object read in R/mcmcFunctions.R is is.null-guarded; this one was not.

test_that(".AdaptMassMatrix tolerates an mcmc with no adaptation schedule (RT-730)", {
  hmcArgs <- list(stepSize = 0.1, massMatInv = c(1, 1),
                  .hmcDA = new.env(parent = emptyenv()))
  hmcArgs[[".hmcDA"]]$stepSize <- 0.1

  freeHistory <- matrix(c(0.1, 0.4, 0.9, 1.7, -0.3, 0.8), ncol = 2)
  legacyMcmc <- list(currentIter = 5L)   # no endAdapting / startAdapting

  expect_silent(
    updated <- StratoBayes:::.AdaptMassMatrix(
      hmcArgs, freeHistory, historySize = nrow(freeHistory),
      mcmc = legacyMcmc, restartFn = StratoBayes:::.HMCRestartDualAvg)
  )
  # With no window to freeze, adaptation proceeds rather than short-circuiting.
  expect_equal(updated[["massMatInv"]], apply(freeHistory, 2, var))
  expect_true(isTRUE(updated[["restartDualAvg"]]))
})


# ── RT-732 (#925): .LogPost takes no `...` ───────────────────────────────────
# `proposalNumber`/`chain` were documented as arguments `.LogPost()` "may take"
# and passed at three call sites, but `...` was never read in the body -- dead
# since the first commit.  Removing `...` turns a silently-swallowed argument
# into an error, so a future caller cannot believe it is being honoured.

test_that(".LogPost rejects the removed proposalNumber/chain arguments (RT-732)", {
  expect_error(
    StratoBayes:::.LogPost(data = NULL, model = NULL, state = NULL,
                           proposalNumber = 1L),
    "unused argument"
  )
  expect_error(
    StratoBayes:::.LogPost(data = NULL, model = NULL, state = NULL, chain = 1L),
    "unused argument"
  )
})


# ── Helper: an R-engine gradient fixture ─────────────────────────────────────

setup_grad_fixture <- function(sData, sModel, knotRange) {
  model <- StratoBayes::StratModel(
    stratData = sData, priors = sModel$priors$metro,
    alignmentScale = sModel$alignmentScale, sedModel = sModel$sedModel,
    flexibleKnots = FALSE, knotRange = knotRange
  )
  td <- file.path(tempdir(), paste0("rehh_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(6418)
  result <- RunStratModel(
    gradientProposals = "on", stratObject = sData, stratModel = model,
    nIter = 10, nChains = 2, seed = 1, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "rehh", engine = "R", nCores = 1L
  )
  mcmcObj <- readRDS(file.path(td, "rehh_mcmc_run_1.rds"))
  modelObj <- result$model
  if (is.null(modelObj$.logpost_cpp))
    modelObj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(modelObj)

  list(data_obj = result$data, model_obj = modelObj, mcmc_obj = mcmcObj,
       state = mcmcObj$recentState[[1]], td = td)
}


# ── RT-494 (#529): one log-posterior convention across accept and reject ─────
# `.UpdateStateHMC` / `.UpdateStateNUTS` wrote `logPostNew` from
# `state$metro$logPost` (the post-Gibbs BETA-MARGINAL) when the move was
# accepted and from the trajectory's JOINT-at-beta value when it was rejected,
# so the exported series mixed two log-posterior scales depending on which
# branch happened to fire.  Both now store the joint-at-beta value the
# trajectory actually accepted on, matching the C++ engine
# (src/MCMCEngine.cpp update_state_hmc / update_state_nuts).
#
# Discriminator: pre-fix, an ACCEPTED iteration set `logPostNew` and
# `logPostOld` from the same expression, so they were bit-identical.  No
# posterior value is pinned -- only that the pair describes a real move.

test_that(".UpdateStateHMC reports the trajectory log-posterior on accept (RT-494)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_grad_fixture(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  gradIdx <- which(names(setup$mcmc_obj$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- StratoBayes:::.HMCDefaultArgs(setup$model_obj)
  hmcArgs$adaptStepSize <- FALSE
  hmcArgs$stepSize <- 0.005
  hmcArgs$nSteps <- 5L
  mcmc <- setup$mcmc_obj
  for (ch in seq_along(mcmc$metro$proposalArgs)) {
    mcmc$metro$proposalArgs[[ch]][[gradIdx]] <- hmcArgs
  }

  accepted <- NULL
  for (s in 1:40) {
    set.seed(s)
    updated <- StratoBayes:::.UpdateStateHMC(
      setup$data_obj, setup$model_obj, mcmc, setup$state,
      chain = 1L, proposalNumber = gradIdx)
    if (isTRUE(updated[[c("metro", "accept")]])) {
      accepted <- updated
      break
    }
  }

  # Non-vacuity: the assertion below is meaningless on a rejection.
  expect_false(is.null(accepted))
  expect_true(is.finite(accepted[[c("metro", "logPostNew")]]))
  expect_false(identical(accepted[[c("metro", "logPostNew")]],
                         accepted[[c("metro", "logPostOld")]]))
})


test_that(".UpdateStateNUTS reports the candidate log-posterior on accept (RT-494)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_grad_fixture(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  gradIdx <- which(names(setup$mcmc_obj$propose) %in% c("HMC", "NUTS"))
  nutsArgs <- StratoBayes:::.NUTSDefaultArgs(setup$model_obj)
  nutsArgs$adaptStepSize <- FALSE
  nutsArgs$stepSize <- 0.005
  mcmc <- setup$mcmc_obj
  for (ch in seq_along(mcmc$metro$proposalArgs)) {
    mcmc$metro$proposalArgs[[ch]][[gradIdx]] <- nutsArgs
  }

  accepted <- NULL
  for (s in 1:40) {
    set.seed(s)
    updated <- StratoBayes:::.UpdateStateNUTS(
      setup$data_obj, setup$model_obj, mcmc, setup$state,
      chain = 1L, proposalNumber = gradIdx)
    if (isTRUE(updated[[c("metro", "accept")]])) {
      accepted <- updated
      break
    }
  }

  expect_false(is.null(accepted))
  expect_true(is.finite(accepted[[c("metro", "logPostNew")]]))
  expect_false(identical(accepted[[c("metro", "logPostNew")]],
                         accepted[[c("metro", "logPostOld")]]))
})


# ── RT-731 (#924): dual averaging keeps its exploratory step size in warmup ──
# Nesterov dual averaging drives Hbar with the exploratory eps = exp(logEps)
# and freezes the smoothed exp(logEpsBar) only once adaptation ends.  The
# R-engine checkpoint block wrote the smoothed value into `da$stepSize` at
# EVERY checkpoint, so the trajectory immediately after each one ran at the
# averaged rate.  Bounded (the next DA update restores exp(logEps)) but wrong.
#
# Oracle: change detection, not value comparison.  `da$stepSize` is written
# only inside a NUTS transition (the DA update), so between the end of one
# transition and the start of the next it must be untouched -- anything else
# is the checkpoint block reaching in.  Comparing against exp(logEpsBar)
# instead would go vacuous once dual averaging settles, since the smoothed and
# exploratory values then agree to many digits.
#
# Two legitimate writes are excluded: a mass-matrix restart
# (`.NUTSRestartDualAvg` zeroes `daCounter` and raises `.needsEpsInit`), and
# the FINAL checkpoint, which is allowed to freeze the smoothed value and
# clears `adaptStepSize` in the same block.

test_that("R-engine DA keeps the exploratory step size mid-warmup (RT-731)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("da731_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  clobbered <- 0L
  gapsChecked <- 0L
  prevStep <- new.env(parent = emptyenv())
  prevCount <- new.env(parent = emptyenv())
  realNUTS <- StratoBayes:::.UpdateStateNUTS
  testthat::local_mocked_bindings(
    .UpdateStateNUTS = function(data, model, mcmc, state, chain,
                                proposalNumber) {
      ha <- mcmc[[c("metro", "proposalArgs")]][[chain]][[proposalNumber]]
      da <- ha[[".hmcDA"]]
      key <- as.character(chain)
      if (!is.null(da) && isTRUE(ha[["adaptStepSize"]]) &&
          !is.null(prevStep[[key]]) && !isTRUE(da$.needsEpsInit) &&
          identical(prevCount[[key]], da$daCounter)) {
        gapsChecked <<- gapsChecked + 1L
        if (!identical(prevStep[[key]], da$stepSize)) {
          clobbered <<- clobbered + 1L
        }
      }
      res <- realNUTS(data, model, mcmc, state, chain, proposalNumber)
      if (!is.null(da)) {
        prevStep[[key]] <- da$stepSize
        prevCount[[key]] <- da$daCounter
      }
      res
    },
    .package = "StratoBayes"
  )

  RunStratModel(
    gradientProposals = "on", stratObject = stratData1, stratModel = model,
    nIter = 400, nChains = 2, seed = 8327, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "da731", engine = "R", nCores = 1L
  )

  # Non-vacuity: enough between-transition gaps to span several checkpoints.
  expect_gt(gapsChecked, 20L)
  expect_identical(clobbered, 0L)
})
