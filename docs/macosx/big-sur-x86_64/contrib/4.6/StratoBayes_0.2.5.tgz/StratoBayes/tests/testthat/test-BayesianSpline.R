test_that("BayesianSpline() works with custom knots", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   testSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.25))

   burnin <- floor(0.5 * nrow(testSpline$beta))

   Bmat  <- splines::splineDesign(
      testSpline$model$splineBase$ext_knots, c(0, 4, 12), sparse = FALSE)

   mean_beta <- apply(testSpline$beta[(burnin + 1):nrow(testSpline$beta), ],
                       2, mean)

   pred <- round(.MatrixVectorMult(Bmat, mean_beta), 3)

   expect_equal(pred, c(0.363, 1.147, 5.313), tolerance = 0.01)

   predSp1 <- PredictSpline(testSpline)
   expect_equal(nrow(predSp1), 49)

   predSp2 <- PredictSpline(testSpline, at = c(2, 9), burnIn = 80)

   # RT-146: this is seeded/deterministic, so pin the actual value and use a
   # tight tolerance instead of the old 20% relative tolerance, which would
   # have let a substantially wrong posterior mean pass.
   expect_equal(predSp2$mu, c(1.490, 4.727), tolerance = 0.01)
})

test_that("BayesianSpline() rejects data outside the knot range (RT-246, RT-247)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   # RT-247: data extends above the knot range -> silent right-boundary
   # extrapolation in .sb_spline_design() without this guard.
   expect_error(
      BayesianSpline(x, y, knots = seq(0, 10, 0.5)),
      "must lie within the spline knot range")

   # RT-246: data extends below the knot range -> unkillable find_span() hang
   # in .sb_spline_design() without this guard. The R-side check errors before
   # any x reaches C++, so this test cannot hang.
   expect_error(
      BayesianSpline(x, y, xMin = 2, xMax = 12),
      "must lie within the spline knot range")

   # data fully covered by the knots -> no range error
   expect_error(
      BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 50),
      NA)
})

test_that("BayesianSpline() validates lambdaFixed (RT-029)", {
   set.seed(1)
   x <- runif(60, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(60)
   Fit <- function(...) {
      BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 10, ...)
   }

   # None of these is numeric, so the old `is.numeric()` guard fell through to
   # `model$lambdaFixed <- FALSE`, silently sampling lambda freely instead of
   # erroring on the misuse.
   for (bad in list(TRUE, NA, "5", c(1, 2), -1, Inf)) {
      expect_error(Fit(lambdaFixed = bad),
                   "lambdaFixed must be a numeric value",
                   info = paste(deparse(bad), collapse = " "))
   }

   # A single non-negative value, and the "estimate lambda" default, are still
   # accepted. (lambdaFixed = 0 is also legal, and is covered in
   # test-cpp-gibbs-spline.R, where it deliberately triggers the ridge warning.)
   expect_error(Fit(lambdaFixed = 5), NA)
   expect_error(Fit(lambdaFixed = FALSE), NA)
})

test_that("BayesianSpline() validates lambdaInitial", {
  set.seed(1)
  x <- runif(60, 0, 12)
  y <- 0.5 * x + sin(x) + rnorm(60)
  Fit <- function(...) {
    BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 10, ...)
  }

  # A negative or non-finite lambdaInitial reaches the C++ sampler unless
  # caught here, as does anything non-numeric or non-scalar.
  for (bad in list(TRUE, NA, "5", c(1, 2), -1, Inf, NaN)) {
    expect_error(Fit(lambdaInitial = bad),
                 "lambdaInitial must be a single non-negative finite",
                 info = paste(deparse(bad), collapse = " "))
  }

  # A single non-negative value, and NULL (the data-scaled default), are
  # still accepted; 0 is legal too.
  expect_error(Fit(lambdaInitial = 5), NA)
  expect_error(Fit(lambdaInitial = 0), NA)
  expect_error(Fit(lambdaInitial = NULL), NA)
})

test_that("first-iteration beta draw conditions on lambdaFixedValue, not lambdaInitial (RT-248)", {
   set.seed(1)
   x <- runif(80, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(80)
   d <- data.frame(x = x, y = y)

   # A fixed lambda far from the lambdaInitial default (1e-4) makes the
   # divergence visible: the initial Gibbs state must carry lambdaFixedValue,
   # not lambdaInitial, into the first beta draw's precision matrix.
   model <- .ModelBspline(d, nKnots = 15, knots = NULL, aSigma = 0.01,
                          bSigma = 0.01, aLambda = 1, bLambda = 1000,
                          lambdaInitial = 0.0001, lambdaFixed = 50,
                          xMin = NULL, xMax = NULL)

   state0 <- .InitializeGibbsBspline(d, model)
   expect_equal(state0[[c("gibbs", "lambda")]], 50)
})

test_that("a large lambdaFixed does not trip smooth.spline's tuning bounds", {
   set.seed(1)
   x <- runif(400, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(400)
   d <- data.frame(x = x, y = y)

   # lambdaFixedValue is the Gibbs state's lambda (iteration 1's precision
   # matrix), not stats::smooth.spline()'s tuning parameter. Routing it into
   # smooth.spline(lambda = ) as well made BayesianSpline() abort with
   # "smoothing parameter value too extreme" for any fixed lambda beyond
   # ~7e8 at 200 knots, where it previously ran; the initial coefficients
   # smooth.spline() produces reach the Gibbs loop only via the initial sigma.
   model <- .ModelBspline(d, nKnots = 200, knots = NULL, aSigma = 0.01,
                          bSigma = 0.01, aLambda = 1, bLambda = 1000,
                          lambdaInitial = 0.0001, lambdaFixed = 1e10,
                          xMin = NULL, xMax = NULL)

   expect_error(state0 <- .InitializeGibbsBspline(d, model), NA)
   expect_equal(state0[[c("gibbs", "lambda")]], 1e10)
})

test_that("the default lambda seed is data-scaled (GH #962)", {
  set.seed(962)
  d <- data.frame(x = seq(0, 1, length.out = 50), y = rnorm(50, sd = 3))
  mb <- .ModelBspline(d, nKnots = 10, knots = NULL, aSigma = 0.01,
                      bSigma = 0.01, aLambda = 1, bLambda = 1000,
                      lambdaInitial = NULL, lambdaFixed = FALSE,
                      xMin = NULL, xMax = NULL)
  expect_identical(mb[[c("initialValues", "lambda")]],
                   .LambdaStar(mb[["splineBase"]], d[["y"]]))
  # smooth.spline's tuning value stays absolute: its fit is linear in y, so
  # the tuning is scale-free, and extreme values error inside smooth.spline.
  expect_identical(mb[[c("initialValues", "lambdaTune")]], 1e-4)

  # An explicit lambdaInitial seeds lambda only: smooth.spline() errors above
  # ~1e9, which the documented default formula can itself reach (GH #1138).
  mb2 <- .ModelBspline(d, nKnots = 10, knots = NULL, aSigma = 0.01,
                       bSigma = 0.01, aLambda = 1, bLambda = 1000,
                       lambdaInitial = 5, lambdaFixed = FALSE,
                       xMin = NULL, xMax = NULL)
  expect_identical(mb2[[c("initialValues", "lambda")]], 5)
  expect_identical(mb2[[c("initialValues", "lambdaTune")]], 1e-4)

  # A constant signal has no scale to key to: absolute fallback.
  dc <- data.frame(x = seq(0, 1, length.out = 50), y = rep(1, 50))
  mbc <- .ModelBspline(dc, nKnots = 10, knots = NULL, aSigma = 0.01,
                       bSigma = 0.01, aLambda = 1, bLambda = 1000,
                       lambdaInitial = NULL, lambdaFixed = FALSE,
                       xMin = NULL, xMax = NULL)
  expect_identical(mbc[[c("initialValues", "lambda")]], 1e-4)
})

test_that("BayesianSpline stays scale-equivariant at y*1e5 (GH #962)", {
  # An absolute 1e-4 seed is ~8 orders too stiff at this scale: the first
  # beta draw is over-smoothed, sigma absorbs the signal, and the chain
  # settles in a prior-dominated over-smoothed state (y-scale ~3e3..1e4) or
  # crashes on a non-finite precision matrix (~1e5 up). The data-scaled seed
  # keeps every scale in the honest basin; basin entry needs >= ~7 orders of
  # seed stiffness, and the seed tracks healthy lambda within ~2 orders.
  k <- 1e5
  set.seed(603)
  n <- 200
  x <- seq(0, 1, length.out = n)
  mu0 <- sin(2 * pi * x)
  y0 <- mu0 + rnorm(n, sd = 0.1)

  set.seed(1)
  fit1 <- BayesianSpline(x = x, y = y0, nKnots = 20, nIter = 1000)
  set.seed(1)
  fitK <- BayesianSpline(x = x, y = k * y0, nKnots = 20, nIter = 1000)

  sel <- 501:1000
  lam1 <- median(fit1[["lambda"]][sel])
  lamK <- median(fitK[["lambda"]][sel])
  expect_gt(lamK * k^2 / lam1, 0.2)
  expect_lt(lamK * k^2 / lam1, 5)

  relRMSE <- function(fit, truth, scale) {
    pred <- PredictSpline(fit, at = x, burnIn = 0.5)
    sqrt(mean((pred[["mu"]] - truth)^2)) / scale
  }
  expect_lt(relRMSE(fitK, k * mu0, k), 1.5 * relRMSE(fit1, mu0, 1))
})

test_that("the default bSigma is data-scaled (GH #974)", {
  set.seed(974)
  # n * var(y) < 1, so the scaled rate sits below the 0.01 cap.
  d <- data.frame(x = seq(0, 1, length.out = 50), y = rnorm(50, sd = 0.01))
  args <- list(nKnots = 10, knots = NULL, aSigma = 0.01, aLambda = 1,
               bLambda = 1000, lambdaInitial = NULL, lambdaFixed = FALSE,
               xMin = NULL, xMax = NULL)
  Model <- function(data, bSigma) {
    do.call(.ModelBspline, c(list(data = data, bSigma = bSigma), args))
  }

  mb <- Model(d, NULL)
  expect_identical(mb[[c("priors", "gibbs", "bSigma")]], .bSigmaScaled(d$y))
  expect_lt(mb[[c("priors", "gibbs", "bSigma")]], 0.01)

  # Capped at the historic absolute rate: data of ordinary magnitude keep the
  # prior they had before GH #974.
  dBig <- data.frame(x = d$x, y = rnorm(50))
  expect_identical(Model(dBig, NULL)[[c("priors", "gibbs", "bSigma")]], 0.01)

  # An explicit rate is passed through untouched.
  expect_identical(Model(d, 5e-3)[[c("priors", "gibbs", "bSigma")]], 5e-3)

  # A constant signal has no variance to scale by, and a zero rate would let
  # sigma run away once the residuals vanish as well.
  dConst <- data.frame(x = d$x, y = rep(1, 50))
  expect_identical(Model(dConst, NULL)[[c("priors", "gibbs", "bSigma")]], 0.01)
})

test_that("BayesianSpline stays scale-equivariant at y*1e-3 (GH #974)", {
  # The mirror image of the GH #962 test above: an absolute bSigma = 0.01
  # outweighs 0.5*SSR (~1e-6 here) by ~5000x, holding sigma two orders above
  # the true noise and blurring the fit (measured relative RMSE 0.30 against
  # 0.017 at unit scale). A data-scaled rate tracks the reference fit under a
  # near-vague prior at every scale down to 1e-6.
  k <- 1e-3
  set.seed(603)
  n <- 200
  x <- seq(0, 1, length.out = n)
  mu0 <- sin(2 * pi * x)
  y0 <- mu0 + rnorm(n, sd = 0.1)

  set.seed(1)
  fit1 <- BayesianSpline(x = x, y = y0, nKnots = 20, nIter = 1000)
  set.seed(1)
  fitK <- BayesianSpline(x = x, y = k * y0, nKnots = 20, nIter = 1000)

  relRMSE <- function(fit, truth, scale) {
    pred <- PredictSpline(fit, at = x, burnIn = 0.5)
    sqrt(mean((pred[["mu"]] - truth)^2)) / scale
  }
  expect_lt(relRMSE(fitK, k * mu0, k), 1.5 * relRMSE(fit1, mu0, 1))
})

test_that("PredictSpline() handles thinned-chain burnIn edge cases (RT-114, RT-186)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   # RT-114 / RT-186 mode 1: fractional burnIn with nIter = 1, nThin = 1 ->
   # nRows = 1, ceiling(1 * 0.5) + 1 = 2 > nRows = 1 -> reversed sequence
   # (2:1) and subscript OOB without the fix.
   smallSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                  nIter = 1, nThin = 1)
   expect_error(PredictSpline(smallSpline, at = c(2, 9), burnIn = 0.5))

   # RT-186 mode 2: fractional burnIn selecting exactly one stored row
   # (selectRows collapses to a length-1 index) -> without drop = FALSE the
   # beta subset becomes a vector and apply() errors; with the fix, a single
   # row is a valid (if unusual) prediction, not a crash.
   thinnedSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                    nIter = 2000, nThin = 100)
   expect_error(
      PredictSpline(thinnedSpline, at = c(2, 9), burnIn = 0.95),
      NA)

   # RT-186 mode 3 / RT-115: integer burnIn exceeding the last stored
   # iteration under nThin > 1 -> validated against nIter (100) passes the
   # old check (burnIn = 99 < 100) but no saved iteration exceeds it, giving
   # an empty selectRows and silent NaN output without the fix.
   gappySpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                                  nIter = 100, nThin = 5)
   expect_error(PredictSpline(gappySpline, at = c(2, 9), burnIn = 99))
})

test_that("PredictSpline() accepts a single prediction location (RT-373)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)
   spline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 200)

   # length(at) == 1 makes each per-iteration prediction a scalar, so apply()
   # simplifies to a plain vector and `apply(allPred, 1, mean)` errored with
   # "dim(X) must have a positive length" before the fix.
   one <- PredictSpline(spline, at = 5)
   expect_s3_class(one, "data.frame")
   expect_equal(nrow(one), 1L)
   expect_equal(one[["x"]], 5)
   expect_true(all(is.finite(unlist(one))))

   # a scalar `at` must give exactly what the same location gives inside a
   # longer vector -- including the quantile columns, which are built from
   # `allPred` too.
   two <- PredictSpline(spline, at = c(5, 9))
   expect_identical(names(one), names(two))
   expect_equal(ncol(one), 3L + length(c(0.025, 0.25, 0.5, 0.75, 0.975)))
   expect_equal(unlist(one[1, -1]), unlist(two[1, -1]))
})

test_that("PredictSpline() rejects non-finite burnIn with its own message (RT-374)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)
   spline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5), nIter = 100)

   # `NaN < 0` is NA, so the `||` chain evaluated to NA and `if()` threw
   # "missing value where TRUE/FALSE needed" rather than the intended message.
   expect_error(PredictSpline(spline, burnIn = NaN), "burnIn must be a numeric")
   expect_error(PredictSpline(spline, burnIn = NA_real_),
                "burnIn must be a numeric")
   expect_error(PredictSpline(spline, burnIn = -Inf), "burnIn must be a numeric")
   # Inf already produced the intended message via `Inf >= maxStoredIter`;
   # the new `is.finite()` clause must not change that.
   expect_error(PredictSpline(spline, burnIn = Inf), "burnIn must be a numeric")
   expect_error(PredictSpline(spline, burnIn = "half"), "burnIn must be a numeric")
})

test_that("PredictSpline() validates burnIn against stored rows, not the schedule (RT-115)", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)
   spline <- BayesianSpline(x, y, knots = seq(0, 12, 0.5),
                            nIter = 100, nThin = 5)

   saveIter <- seq(1, spline[["nIter"]], spline[["nThin"]])
   expect_equal(nrow(spline[["beta"]]), length(saveIter))

   # Emulate a truncated / checkpointed chain: fewer stored rows than the run
   # scheduled. The last iteration actually stored is saveIter[5] = 21, not
   # saveIter[20] = 96, so burnIn = 30 must be rejected -- and, critically,
   # `which(saveIter > 30)` would otherwise index rows 8:20 of a 5-row matrix.
   truncated <- spline
   truncated[["beta"]] <- spline[["beta"]][1:5, , drop = FALSE]
   expect_equal(saveIter[5], 21)

   expect_error(PredictSpline(truncated, at = c(2, 9), burnIn = 30),
                "burnIn must be a numeric")
   # a burnIn below the last stored iteration still works
   expect_error(PredictSpline(truncated, at = c(2, 9), burnIn = 10), NA)
   pred <- PredictSpline(truncated, at = c(2, 9), burnIn = 10)
   expect_true(all(is.finite(pred[["mu"]])))
})

test_that("BayesianSpline() sorts and validates `knots` (RT-696)", {
  set.seed(1)
  x <- seq(0, 8, length.out = 50)
  y <- sin(x) + rnorm(50, 0, 0.1)
  knots <- c(0, 5, 1, 3, 8)

  set.seed(2)
  unsorted <- BayesianSpline(x, y, knots = knots, nIter = 50)
  set.seed(2)
  sorted <- BayesianSpline(x, y, knots = sort(knots), nIter = 50)

  expect_identical(unsorted[[c("model", "splineBase", "knots")]], sort(knots))

  # An unsorted pair gives `.bsplinepen()` a negative interval width, hence
  # negative quadrature weights and a penalty matrix that is not PSD -- which
  # nothing downstream rejects.
  penalty <- unsorted[[c("model", "splineBase", "D")]]
  eigenvalues <- eigen(penalty, symmetric = TRUE, only.values = TRUE)$values
  expect_true(min(eigenvalues) > -1e-8 * max(abs(penalty)))

  # Same seed, same model once sorted, so the chains agree bit for bit.
  expect_identical(unsorted[["beta"]], sorted[["beta"]])
  expect_identical(unsorted[["sigma"]], sorted[["sigma"]])
  expect_identical(unsorted[["lambda"]], sorted[["lambda"]])

  expect_error(BayesianSpline(x, y, knots = c(0, NA, 8)),
               "'knots' must not contain NA")
  expect_error(BayesianSpline(x, y, knots = c(0, Inf)),
               "'knots' must be finite")
  expect_error(BayesianSpline(x, y, knots = c("0", "8")),
               "'knots' must be numeric")
  # Fewer than two knots spans no interval, so nothing downstream has a
  # quadrature range or a knot span to work with.
  expect_error(BayesianSpline(x, y, knots = numeric(0)),
               "at least two knot positions")
  expect_error(BayesianSpline(x, y, knots = 3), "at least two knot positions")
})

test_that("BayesianSpline() does not hang on unsorted knots (RT-696)", {
  x <- seq(2.741, 9.026, length.out = 50)

  # The range gate in `.CreateSplineBaseBspline()` compares against
  # range(ext_knots), which equals [knots[1], knots[nKnots]] only for sorted
  # knots. These knots are the case it lets through: unsorted, every x lies
  # inside their range, and x below knots[1] stalls find_span().
  unsortedKnots <- c(3.057, 3.78, 5.685, 2.741, 9.026)
  set.seed(1)
  expect_no_error(BayesianSpline(x, sin(x), knots = unsortedKnots, nIter = 50))
})

test_that("BayesianSpline() validates nKnots (RT-699)", {
  x <- seq(0, 8, length.out = 30)
  y <- sin(x)

  # Pre-fix these died downstream on a collapsed knot vector -- in the RT-246
  # range check ("data must lie within the spline knot range [0, 0]") or
  # inside `.bsplinepen()` -- naming neither `nKnots` nor its constraint.
  expect_error(BayesianSpline(x, y, nKnots = 1), "'nKnots' must be an integer")
  expect_error(BayesianSpline(x, y, nKnots = 0), "'nKnots' must be an integer")
  expect_error(BayesianSpline(x, y, nKnots = NA), "'nKnots' must be an integer")
  expect_error(BayesianSpline(x, y, nKnots = c(5, 10)),
               "'nKnots' must be an integer")
  expect_error(BayesianSpline(x, y, nKnots = "10"),
               "'nKnots' must be an integer")

  # Explicit knots override nKnots entirely, so a degenerate nKnots alongside
  # them is not an error -- `knots` carries its own length check.
  set.seed(1)
  expect_no_error(
    BayesianSpline(x, y, nKnots = 1, knots = seq(0, 8, length.out = 6),
                   nIter = 20))
})

test_that("PredictSpline() accepts an empty quant (RT-702)", {
  set.seed(1)
  x <- seq(0, 8, length.out = 40)
  fit <- BayesianSpline(x, sin(x) + rnorm(40, 0, 0.1), nKnots = 6, nIter = 100)

  # `4:ncol(output)` counts DOWN to c(4, 3) when no quantile columns were
  # added, so the pre-fix naming failed with "replacement has length zero".
  pred <- PredictSpline(fit, at = c(1, 4, 7), quant = numeric(0))
  expect_equal(colnames(pred), c("x", "mu", "sd"))
  expect_equal(nrow(pred), 3L)
  expect_true(all(is.finite(pred[["mu"]])))

  # The default path still names its quantile columns.
  predQ <- PredictSpline(fit, at = c(1, 4, 7), quant = c(0.1, 0.9))
  expect_equal(colnames(predQ), c("x", "mu", "sd", "0.1", "0.9"))
})
