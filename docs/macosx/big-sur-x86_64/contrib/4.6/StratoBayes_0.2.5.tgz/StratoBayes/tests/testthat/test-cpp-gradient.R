# Tests for gradient computation (HMC infrastructure)
#
# Verifies analytical gradients against finite-difference approximations
# computed via the C++ engine's .sb_eval_logpost export.
#
# This file covers the FIXED-knots gradient (flexibleKnots = FALSE).
# Flexible knots are covered in test-flexible-knots-gradient.R.

# ── Helper: create engine from data/model, run short MCMC ────────────────────

make_test_engine <- function(sData, sModel, knotRange = NULL) {
  # If the model uses flexible knots, recreate with fixed knots
  if (sModel$flexibleKnots && !is.null(knotRange)) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }

  td <- file.path(tempdir(), paste0("grad_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(7261)
  result <- RunStratModel(
    stratObject = sData,
    stratModel  = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gtest",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gtest_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  tiesCallback <- if ("ties" %in% names(data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        data_obj, model_obj$ind, parameters, FALSE
      )
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(data_obj, model_obj, tmpState)
    }
  }

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj,
    state = state_obj, tiesCallback = tiesCallback
  )

  list(
    engine_ptr = engine_ptr,
    data_obj   = data_obj,
    model_obj  = model_obj,
    mcmc_obj   = mcmc_obj,
    state_obj  = state_obj,
    tiesCallback = tiesCallback,
    params     = state_obj[[1]]$metro$parameters,
    free_idx   = model_obj$ind$paramNotFixed,
    td         = td
  )
}


# ── Helper: compute FD gradient via C++ engine ────────────────────────────────

CppFdAt <- function(setup, i, h) {
  pIdx <- setup$free_idx[i]

  pPlus <- setup$params
  pPlus[pIdx] <- pPlus[pIdx] + h
  pMinus <- setup$params
  pMinus[pIdx] <- pMinus[pIdx] - h

  # Fresh engines to avoid state contamination
  ep <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  lpPlus <- StratoBayes:::.sb_eval_logpost(ep, 1L, pPlus)

  em <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$state_obj,
    tiesCallback = setup$tiesCallback
  )
  lpMinus <- StratoBayes:::.sb_eval_logpost(em, 1L, pMinus)

  (lpPlus - lpMinus) / (2 * h)
}

# nolint next: object_name_linter. Name and its ten call sites are pre-existing.
cpp_fd_gradient <- function(setup, h = 1e-5) {
  fd <- vapply(seq_along(setup$free_idx),
               function(i) CppFdAt(setup, i, h), numeric(1))
  # The step and a re-evaluator travel with the estimate so that
  # expect_gradients_match() can shrink the step for a single parameter.
  structure(fd, step = h, refine = function(i, hh) CppFdAt(setup, i, hh))
}


# ── Helper: compare gradients with informative failure messages ───────────────

expect_gradients_match <- function(grad_analytical, grad_fd, param_names,
                                    tol = 0.001) {
  expect_fd_close(grad_analytical, grad_fd,
                  refine = attr(grad_fd, "refine"),
                  h0 = attr(grad_fd, "step"), tol = tol,
                  param_names = param_names)
}


# ── Helper self-test: the step ladder (#989) ─────────────────────────────────
#
# Unskipped, unlike the gradient tests below, so the PR gate covers the logic
# deciding whether a disagreement is real.

test_that("#989: the ladder shrinks past a straddled jump but not past a bug", {
  # Measured on stratData4: an overlap-count boundary 5e-6 along
  # `gammaLog_top part., site 2` steps logPost by -2.216 nats, so the h = 1e-5
  # difference reports -1.097e5 where the analytical gradient is 1.091e3.
  trueGrad <- 1.090902e3
  jump <- -2.216455
  reach <- 5e-6
  FdOf <- function(h) if (h > reach) trueGrad + jump / (2 * h) else trueGrad
  fd <- structure(FdOf(1e-5), step = 1e-5, refine = function(i, h) FdOf(h))
  pname <- "gammaLog_top part., site 2"

  expect_lt(fd[[1]], -1e5)
  expect_gradients_match(trueGrad, fd, pname)
  expect_failure(expect_gradients_match(trueGrad * 1.01, fd, pname))
})


# ── Test: stratData1 (height/site, fixed knots) ──────────────────────────────

test_that("gradient matches FD for stratData1 with fixed knots", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  setup <- make_test_engine(stratData1, stratModel1, knotRange = c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: stratData2 (age/site, with ties) ───────────────────────────────────

test_that("gradient matches FD for stratData2 with ties", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  setup <- make_test_engine(stratData2, stratModel2, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: debug=TRUE breakdown is consistent with the production gradient ─────
# RT-307: the debug branch of .sb_compute_gradient now routes through the single
# production compute_logpost_gradient (component sink) instead of a hand-synced
# copy. Lock that the breakdown reassembles exactly to the non-debug gradient.

test_that(".sb_compute_gradient(debug=TRUE) matches the non-debug gradient", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")

  setup <- make_test_engine(stratData2, stratModel2, knotRange = c(0, 100))
  on.exit(unlink(setup$td, recursive = TRUE))

  plain <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  dbg   <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L, debug = TRUE)

  # Same scalar logPost and same free-parameter gradient (bit-identical: same code path)
  expect_identical(dbg$logPost, plain$logPost)
  expect_identical(dbg$grad, plain$grad)

  # The component breakdown reassembles to the reported gradient
  nParam <- length(dbg$grad_prior)
  expect_length(dbg$grad_ages, nParam)
  total <- dbg$grad_prior + dbg$grad_ages
  expect_equal(dbg$grad, total[setup$free_idx], tolerance = 0)

  # logPostSep sums (na.rm) to logPost; component vectors are well-formed
  expect_equal(sum(dbg$logPostSep, na.rm = TRUE), dbg$logPost, tolerance = 1e-9)
  expect_length(dbg$dLogLik_dAges, length(dbg$signalFlat))
  expect_true(all(is.finite(dbg$grad)))
})


# ── Test: stratData3 (partition model) ────────────────────────────────────────

test_that("gradient matches FD for stratData3 with partitions", {
  skip_on_cran()

  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")

  setup <- make_test_engine(stratData3, stratModel3, knotRange = c(-5, 15))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: stratData4 (partition model, 2 sites) ──────────────────────────────

test_that("gradient matches FD for stratData4 with partitions and 2 sites", {
  skip_on_cran()

  data(stratData4, package = "StratoBayes")
  data(stratModel4, package = "StratoBayes")

  setup <- make_test_engine(stratData4, stratModel4, knotRange = c(-5, 30))
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: dgamma tie type (RT-080) ────────────────────────────────────────────
# No existing fixture exercises Gradient_impl.h's dgamma tie branch (case 4);
# NB: may need reconciling with PR #318's SM_SITE_PARTITION/dlogis fixtures
# once both land.

test_that("gradient matches FD for a dgamma tie (RT-080)", {
  skip_on_cran()

  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  ties <- data.frame(
    SIT   = c("site1", "site1", "site3"),
    Hight = c(0, 80, 20),
    arg1  = c(40, 3, 0.05),    # dgamma shape = 3
    arg2  = c(1, 0.2, NA),     # dgamma rate = 0.2
    densityFun = c("dnorm", "dgamma", "dexp")
  )
  sData <- StratData(testData$signal, parts = testData$parts, ties = ties,
                     signalColumn = c("a", "b"), zColumn = "Hight",
                     siteColumn = "SIT")
  priors <- structure(list(
      "alpha_site1" = UniformPrior(min = 35, max = 45),
      "alpha_site2" = UniformPrior(min = 30, max = 40),
      "alpha_site3" = UniformPrior(min = 30, max = 40),
      "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 0.5)),
    class = c("StratPrior", "list"))
  sModel <- StratModel(sData, priors, alignmentScale = "age", sedModel = "site",
                       alphaPosition = "bottom", flexibleKnots = FALSE,
                       knotRange = c(0, 100))

  setup <- make_test_engine(sData, sModel)
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: SM_SITE_X_PARTITION sedModel + dunif/dcauchy/dt ties (RT-166) ──────
# Covers the "site x partition" sedModel (previously untested by any FD-gradient
# fixture) plus 3 of the remaining untested tie types. dunif's gradient (case 1)
# is hardcoded 0 regardless of placement; dcauchy (case 6) and dt (case 7) have
# no domain restriction, so placement is not a concern for any of the three.
# NB: may need reconciling with PR #318's SM_SITE_PARTITION/dlogis fixtures
# once both land.

test_that("gradient matches FD for site x partition sedModel with dunif/dcauchy/dt ties (RT-166)", {
  skip_on_cran()

  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  ties <- data.frame(
    SIT   = c("site1", "site1", "site3"),
    Hight = c(0, 80, 20),
    arg1  = c(10, 20, 5),   # dunif min = 10; dcauchy loc = 20; dt df = 5
    arg2  = c(60, 1, 0),    # dunif max = 60; dcauchy scale = 1; dt ncp = 0 (central)
    densityFun = c("dunif", "dcauchy", "dt")
  )
  sData <- StratData(testData$signal, parts = testData$parts, ties = ties,
                     signalColumn = c("a", "b"), zColumn = "Hight",
                     siteColumn = "SIT")
  # "site x partition" parameter names: alpha_<site> (all sites), gammaLog_<part>
  # (one per unique partition, not per site), zetaLog_<site> (all but site1), gap_*
  priors <- structure(list(
      "alpha_site1" = UniformPrior(min = 35, max = 45),
      "alpha_site2" = UniformPrior(min = 30, max = 40),
      "alpha_site3" = UniformPrior(min = 30, max = 40),
      "gammaLog_part 1.1" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_part 2.1" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_part 2.2" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_part 3.1" = NormalPrior(mean = 1, sd = 1),
      "zetaLog_site2" = NormalPrior(mean = 0, sd = 1),
      "zetaLog_site3" = NormalPrior(mean = 0, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 0.5)),
    class = c("StratPrior", "list"))
  sModel <- StratModel(sData, priors, alignmentScale = "age",
                       sedModel = "site x partition", alphaPosition = "bottom",
                       flexibleKnots = FALSE, knotRange = c(0, 100))

  setup <- make_test_engine(sData, sModel)
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: non-zero-width gap in a site x partition model (#1175) ─────────────
# Every other site x partition fixture inherits `.FillGaps()`'s zero-width gap
# encoding, for which dL_dRate at the gap boundary is exactly 0 and
# age_convert_backward's short-circuit makes the gap arm vacuous. A gap of
# non-zero width is reachable through a user-supplied `parts$sedRates` column,
# which `.FillGaps()` never touches, and is the only configuration in which the
# reverse pass's treatment of the gap can disagree with the forward pass's.
#
# Measured against the pre-fix build: age scale zetaLog_site2 = 27.0779 vs an
# FD of 127.527, height scale zetaLog_site3 = 99.8823 vs 273.100 -- both stable
# across h = 1e-5 .. 1.56e-7, with every other parameter already agreeing.

GapWidthFixture <- function(alignmentScale) {
  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")

  # The gap must sit in a site that OWNS a zeta parameter, or the reverse
  # pass's zeta arm is never reached: on the age scale that is site 2 upwards,
  # on the height scale (site 1 is the reference) site 3 upwards. Hence two
  # `parts` layouts. In both, every `partition` entry is non-NA, so .FillGaps()
  # is a no-op and cannot collapse the gap to zero width -- the NA that encodes
  # the gap rides on the user-supplied `sedRates` column instead. Each row's
  # height is the TOP of its boundary, so the gap spans the previous row's
  # height up to its own.
  gapSite <- if (identical(alignmentScale, "height")) 3L else 2L
  parts <- if (gapSite == 2L) {
    data.frame(
      SIT = c("site1", "site2", "site2", "site2", "site3"),
      Hight = c(80, 10.5, 20, 31, 25),
      partition = c("part 1.1", "part 2.1", "part 2.2", "part 2.3", "part 3.1"),
      sedRates = c("part 1.1", "part 2.1", NA, "part 2.2", "part 3.1"),
      stringsAsFactors = FALSE)
  } else {
    data.frame(
      SIT = c("site1", "site2", "site3", "site3", "site3"),
      Hight = c(80, 31, 3, 6, 25),
      partition = c("part 1.1", "part 2.1", "part 3.1", "part 3.2", "part 3.3"),
      sedRates = c("part 1.1", "part 2.1", "part 3.1", NA, "part 3.2"),
      stringsAsFactors = FALSE)
  }
  # Ties are not what this fixture exercises, and their densities are stated on
  # the age scale, so they are omitted from the height-scale variant rather
  # than re-tuned.
  ties <- if (alignmentScale == "height") NULL else data.frame(
    SIT = c("site1", "site1", "site3"), Hight = c(0, 80, 20),
    arg1 = c(10, 20, 5), arg2 = c(60, 1, 0),
    densityFun = c("dunif", "dcauchy", "dt")
  )
  sData <- StratData(testData$signal, parts = parts, ties = ties,
                     signalColumn = c("a", "b"), zColumn = "Hight",
                     siteColumn = "SIT")

  # Guard the fixture itself: the gap boundary must be coded 0 in sedRatesDF
  # and span a non-zero height, or the test reverts to the vacuous regime.
  gapB <- which(sData$partsAttr$sedRatesDF[, gapSite] == 0)
  expect_length(gapB, 1L)
  expect_gt(sData$partsAttr$Bound[gapB, gapSite] -
              sData$partsAttr$BoundLow[gapB, gapSite], 1)

  gammaNames <- paste0("gammaLog_",
                       sort(unique(stats::na.omit(parts$sedRates))))
  priors <- c(
    if (alignmentScale == "height") {
      list("alpha_site1" = UniformPrior(min = 0, max = 1),
           "alpha_site2" = UniformPrior(min = 0, max = 20),
           "alpha_site3" = UniformPrior(min = 0, max = 20))
    } else {
      list("alpha_site1" = UniformPrior(min = 35, max = 45),
           "alpha_site2" = UniformPrior(min = 30, max = 40),
           "alpha_site3" = UniformPrior(min = 30, max = 40))
    },
    stats::setNames(rep(list(NormalPrior(mean = 1, sd = 1)),
                        length(gammaNames)), gammaNames),
    list("zetaLog_site2" = NormalPrior(mean = 0, sd = 1),
         "zetaLog_site3" = NormalPrior(mean = 0, sd = 1)),
    stats::setNames(list(ExponentialPrior(rate = 0.5)),
                    paste0("gap_site", gapSite, "_1"))
  )
  # The height scale drops site 1's alpha, site 1's partition rates and site
  # 2's zeta (site 1 is the reference); .PriorsValidity() rejects any extras.
  if (alignmentScale == "height") {
    priors <- priors[setdiff(names(priors),
                             c("alpha_site1", "gammaLog_part 1.1",
                               "zetaLog_site2"))]
  }
  priors <- structure(priors, class = c("StratPrior", "list"))

  sModel <- StratModel(sData, priors, alignmentScale = alignmentScale,
                       sedModel = "site x partition", alphaPosition = "bottom",
                       flexibleKnots = FALSE, knotRange = c(0, 100))
  make_test_engine(sData, sModel)
}

test_that("gradient matches FD across a non-zero-width gap, age scale (#1175)", {
  skip_on_cran()

  setup <- GapWidthFixture("age")
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})

test_that("gradient matches FD across a non-zero-width gap, height scale (#1175)", {
  skip_on_cran()

  setup <- GapWidthFixture("height")
  on.exit(unlink(setup$td, recursive = TRUE))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: dbeta tie type, non-degenerate branch (RT-166) ─────────────────────
# dbeta's gradient (case 5) is only non-degenerate (the (a-1)/x - (b-1)/(1-x)
# arithmetic) when the tie's age lands strictly inside (0,1); outside that
# range Gradient_impl.h's guard returns 0. alpha_site1 is pinned to (0.2, 0.8)
# and the dbeta tie sits at height 0 (alphaPosition = "bottom"), so the tie age
# equals alpha_site1 directly with no rate contribution -- verified empirically
# to resolve to age ~0.537, strictly inside (0,1), genuinely exercising case 5.

test_that("gradient matches FD for a dbeta tie landing in (0,1) (RT-166)", {
  skip_on_cran()

  set.seed(0)
  testData <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  ties <- data.frame(
    SIT   = c("site1", "site1", "site3"),
    Hight = c(0, 80, 20),
    arg1  = c(2, 20, 0.05),   # dbeta shape1 = 2
    arg2  = c(3, 1, NA),      # dbeta shape2 = 3
    densityFun = c("dbeta", "dnorm", "dexp")
  )
  sData <- StratData(testData$signal, parts = testData$parts, ties = ties,
                     signalColumn = c("a", "b"), zColumn = "Hight",
                     siteColumn = "SIT")
  priors <- structure(list(
      "alpha_site1" = UniformPrior(min = 0.2, max = 0.8),
      "alpha_site2" = UniformPrior(min = 30, max = 40),
      "alpha_site3" = UniformPrior(min = 30, max = 40),
      "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
      "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
      "gap_site2_1" = ExponentialPrior(rate = 0.5)),
    class = c("StratPrior", "list"))
  sModel <- StratModel(sData, priors, alignmentScale = "age", sedModel = "site",
                       alphaPosition = "bottom", flexibleKnots = FALSE,
                       knotRange = c(-1, 100))

  setup <- make_test_engine(sData, sModel)
  on.exit(unlink(setup$td, recursive = TRUE))

  # Confirm the placement gotcha is satisfied: the dbeta tie's age must be
  # strictly inside (0, 1), or this test would only exercise the degenerate
  # zero-gradient guard branch in Gradient_impl.h case 5.
  ageResult <- StratoBayes:::.sb_age_convert(setup$data_obj, setup$model_obj$ind,
                                             setup$params, FALSE)
  dbetaTieAge <- ageResult$ties[[1]][1]
  expect_true(dbetaTieAge > 0 && dbetaTieAge < 1,
             info = sprintf("dbeta tie age = %.6f (must be in (0,1))", dbetaTieAge))

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: RT-277 — interior NaN-sed-rate gap with below-gap alpha ─────────────
#
# A `sedModel = "site, partition"` model with an interior gap (NaN sed rate) and
# `alphaPosition = "bottom"` puts the gap boundary inside the backward upward
# loop's range with signal above it. The forward pass keeps the coefficient-1
# alpha dependency across the gap, so the backward alpha pass-through must be
# ungated (Gradient_impl.h). Before the fix the pass-through was gated on
# isfinite(inverseSedRate), producing a wrong gradient for the site alpha and
# below-gap rates (analytic ~ -17.7 vs FD ~ -157). CONTROL: alphaPosition="top"
# (gap below datum) and sedModel="site" (no NaN rate) were already correct.

test_that("gradient matches FD for site,partition model with interior gap (RT-277)", {
  skip_on_cran()

  data(stratData4, package = "StratoBayes")

  mk <- function(sedModel, alphaPosition) {
    StratoBayes::StratModel(
      stratData4, priors = NULL, alignmentScale = "height",
      sedModel = sedModel, alphaPosition = alphaPosition,
      flexibleKnots = FALSE, knotRange = c(-5, 30)
    )
  }

  # TEST: the exact configuration that triggered the dropped pass-through.
  setup <- make_test_engine(stratData4, mk("site, partition", "bottom"))
  on.exit(unlink(setup$td, recursive = TRUE), add = TRUE)

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))
  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)

  # CONTROL: alphaPosition="top" puts the gap below the datum (was always OK).
  setup_ctl <- make_test_engine(stratData4, mk("site, partition", "top"))
  on.exit(unlink(setup_ctl$td, recursive = TRUE), add = TRUE)
  gr_ctl <- StratoBayes:::.sb_compute_gradient(setup_ctl$engine_ptr, 1L)
  gf_ctl <- cpp_fd_gradient(setup_ctl)
  expect_gradients_match(gr_ctl$grad, gf_ctl,
                         names(setup_ctl$params)[setup_ctl$free_idx])
})


# ── Test: RT-276 — unsupported tie density (dlogis) FD-fallback gradient ──────
#
# When a tie uses a density not natively supported in C++ (here dlogis), the
# engine sets densityType = -1 and ac.hasTies = FALSE, so compute_logpost
# evaluates the tie term via the per-tie R callback while the analytic gradient
# used to omit the entire ties term (early-return + backward skip, both gated on
# ac.hasTies). The leapfrog force was then missing the tie constraint that the
# accept energy included (analytic vs FD rel-err ~ 0.22 pre-fix). The fix runs
# the tie gradient whenever the model has ties and supplies a central-FD
# fallback via the same R callback for the unsupported density.
#
# This fixture needs the polymorphic per-tie callback (list(site, tie, age)) —
# the full-form callback in make_test_engine cannot answer that form.

test_that("gradient matches FD for unsupported tie density dlogis (RT-276)", {
  skip_on_cran()

  data(signalData2,  package = "StratoBayes")
  data(tiesData2,    package = "StratoBayes")
  data(partsData2,   package = "StratoBayes")
  data(stratPrior2,  package = "StratoBayes")

  # Rebuild StratData from raw frames so the swapped densityFun re-runs tie
  # processing — editing a processed StratData in place is inert.
  ties_custom <- tiesData2
  ties_custom$densityFun[1] <- "dlogis"  # location/scale args -> valid, unsupported in C++

  sData <- StratoBayes::StratData(
    signalData2, parts = partsData2, ties = ties_custom,
    signalColumn = c("a", "b"), zColumn = "height", siteColumn = "site"
  )
  sModel <- StratoBayes::StratModel(
    stratData = sData, priors = stratPrior2, alignmentScale = "age",
    sedModel = "site", alphaPosition = c("top", "middle", "bottom"),
    flexibleKnots = FALSE, knotRange = c(0, 100), sigmaFixed = TRUE
  )

  td <- file.path(tempdir(), paste0("grad_rt276_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(7261)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gt276", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gt276_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  # Polymorphic callback: per-tie form for the unsupported (default) C++ case,
  # full form otherwise (matches RunStratModel's T-110 dispatch).
  tdisp <- model_obj[[".tiesDispatch"]]
  if (is.null(tdisp)) tdisp <- StratoBayes:::.BuildTiesDispatch(data_obj, model_obj)
  tiesCallback <- function(arg) {
    if (is.list(arg) && !is.null(arg[["site"]])) {
      spec <- tdisp[["dispatch"]][[arg[["site"]]]][[arg[["tie"]]]]
      if (is.null(spec) || !spec[["active"]]) return(0)
      spec[["args"]][["x"]] <- arg[["age"]]
      return(do.call(spec[["fn"]], spec[["args"]]))
    }
    StratoBayes:::.LogLikTies(data_obj, model_obj, list(age = list(ties = arg)))
  }

  setup <- list(
    engine_ptr = StratoBayes:::.sb_create_engine(
      data = data_obj, model = model_obj, mcmc = mcmc_obj,
      state = state_obj, tiesCallback = tiesCallback),
    data_obj = data_obj, model_obj = model_obj, mcmc_obj = mcmc_obj,
    state_obj = state_obj, tiesCallback = tiesCallback,
    params = state_obj[[1]]$metro$parameters,
    free_idx = model_obj$ind$paramNotFixed
  )

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))
  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})


# ── Test: both gradient paths accept flexible knots ──────────────────────────
#
# Since RT-307 `debug = TRUE` reads its component split out of the production
# compute_logpost_gradient, so it inherits the knot-path chain rule instead of
# hand-deriving an incomplete one. Numerical checks: test-flexible-knots-gradient.R.

test_that("gradient supports flexible knots on both the plain and debug paths", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # Use the default flexible-knots model
  td <- file.path(tempdir(), "grad_flex_reject")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4382)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "gflex",
    engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "gflex_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj, state = state_obj
  )

  res <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L)
  expect_type(res, "list")
  expect_length(res$grad, model_obj$parametersLengthNotFixed)
  expect_true(all(is.finite(res$grad)))
  expect_true(is.finite(res$logPost))

  # The debug decomposition is the same computation with a component sink, so
  # it must agree exactly with the plain path, not just avoid erroring.
  dbg <- StratoBayes:::.sb_compute_gradient(engine_ptr, 1L, debug = TRUE)
  expect_equal(dbg$grad, res$grad)
  expect_equal(dbg$logPost, res$logPost)
  expect_length(dbg$grad_prior, model_obj$parametersLength)
  expect_length(dbg$grad_ages, model_obj$parametersLength)
  expect_true(all(is.finite(dbg$grad_ages)))
})


# ── RT-101: stale section-overlap in the HMC/NUTS leapfrog Hamiltonian ───────
#
# hmc_eval_gradient (C++-engine HMC/NUTS), sb_gradient_at (R-engine HMC/NUTS via
# gradFn) and sb_eval_logpost (FD helper) each set NEW parameters on a COPIED
# chain state whose cached `signalSectionOverlap` reflected the SOURCE state's
# parameters.  Before the RT-101 fix none of them recomputed the overlap for the
# new parameters, so the overlap-penalty term carried in the returned logPost --
# and therefore the HMC/NUTS Hamiltonian, the leapfrog MH acceptance ratio and
# the NUTS deltaH comparisons -- was stale.  That is an asymmetric error (the
# proposed endpoint used the previous state's overlap while the current endpoint
# used its own), which violates detailed balance whenever overlapPenalty = TRUE.
#
# Oracle independence: the overlap COUNTS come from the R `.SectionOverlap` path
# (-> `.SectionOverlapCpp`), a distinct implementation from MCMCEngine.cpp's
# `compute_section_overlap`; the penalty is summed in R with the model's
# adjustments.  The remaining log-posterior components do not depend on overlap,
# so combining the engine's (bug-independent) prior/signal/ties components with
# this independent overlap yields a sharp, independent oracle for each entry
# point.  Sharpness is asserted explicitly: the perturbed parameters must give an
# overlap penalty that DIFFERS from the stale (source-state) penalty, otherwise
# the check would pass vacuously with the bug live.

# Independent R oracle for the overlap penalty at arbitrary parameters, mirroring
# the R HMC path (R/HMCFunctions.R "Section overlap count" block).
rt101_overlap_penalty <- function(data, model, params) {
  age <- StratoBayes:::.sb_age_convert(
    data = data, indices = model[["ind"]], parameters = params)
  signalFlat <- unlist(age[["signal"]], recursive = FALSE, use.names = FALSE)

  signalN   <- data[[c("signalAttr", "signalN")]]
  countGaps <- model[[c("overlapPenalty", "countGaps")]]
  sepSignal <- data[[c("signalAttr", "signalGapSectBindSepSignal")]]
  sigs      <- data[[c("signalAttr", "sigs")]]
  adj       <- model[[c("overlapPenalty", "adjustments")]]

  penalty <- 0
  for (m in seq_len(signalN)) {
    signalIndSite <- sigs[[m]][["signalIndSite"]]
    ov <- unlist(
      StratoBayes:::.SectionOverlap(
        signalAges  = lapply(signalIndSite, function(s) signalFlat[s]),
        countGaps   = countGaps,
        gapSegments = sepSignal[[m]]
      ),
      recursive = FALSE, use.names = FALSE)
    # ov >= 1 for every age point (a section always overlaps itself); R's 1-based
    # adj[ov] equals the engine's 0-based adj[ov - 1].
    penalty <- penalty + sum(adj[[m]][ov])
  }
  penalty
}

test_that("HMC/NUTS leapfrog uses the proposed state's overlap, not a stale one (RT-101)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  # Fixed knots (gradient path requires them) + overlap penalty active.
  sModel <- StratoBayes::StratModel(
    stratData      = stratData1,
    priors         = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel       = stratModel1$sedModel,
    flexibleKnots  = FALSE,
    knotRange      = c(-5, 12),
    overlapPenalty = TRUE
  )
  expect_true(isTRUE(sModel[[c("overlapPenalty", "overlapPenalty")]]))

  setup <- make_test_engine(stratData1, sModel)
  on.exit(unlink(setup$td, recursive = TRUE))

  base_params <- setup$params
  # Stale value the buggy code would use = overlap penalty at the SOURCE state's
  # parameters (proposed/scratch copied the chain, whose overlap matches these).
  stale_penalty <- rt101_overlap_penalty(setup$data_obj, setup$model_obj,
                                         base_params)

  # Find a perturbation of the first free (alignment) parameter that (a) keeps
  # the log-posterior finite and (b) changes the overlap penalty, so the stale
  # and correct values genuinely differ (guarantees the test is not vacuous).
  pidx <- setup$free_idx[1]
  P <- NULL
  true_penalty <- NA_real_
  for (delta in c(1.5, -1.5, 3, -3, 5, -5, 0.7, -0.7)) {
    cand <- base_params
    cand[pidx] <- cand[pidx] + delta
    lp <- StratoBayes:::.sb_eval_logpost(setup$engine_ptr, 1L, cand)
    if (!is.finite(lp)) next
    pen <- rt101_overlap_penalty(setup$data_obj, setup$model_obj, cand)
    if (abs(pen - stale_penalty) > 1e-6) {
      P <- cand
      true_penalty <- pen
      break
    }
  }

  # Sharpness preconditions: a usable perturbation exists and it moves the
  # overlap penalty away from the stale value.
  expect_false(is.null(P),
    info = "no finite perturbation changed the overlap penalty")
  expect_true(is.finite(true_penalty))
  expect_gt(abs(true_penalty - stale_penalty), 1e-6)

  # ── 1. hmc_eval_gradient (the RT-101 target) via .sb_hmc_eval_logpost ──
  # Evaluated on the engine's `proposed` scratch, whose overlap is stale exactly
  # as during a live trajectory.  logPostSep[4] is the overlap term the
  # Hamiltonian used; it must equal the independent overlap for P, not the stale
  # source-state value.
  hmc <- StratoBayes:::.sb_hmc_eval_logpost(setup$engine_ptr, 1L, P)
  expect_true(isTRUE(hmc$ok))
  expect_equal(hmc$logPostSep[4], true_penalty, tolerance = 1e-8,
    info = "hmc_eval_gradient overlap term must match the proposed state")
  # The scalar logPost returned to leapfrog must account for that overlap.
  expect_equal(sum(hmc$logPostSep), hmc$logPost, tolerance = 1e-9)
  # Guard against a vacuous pass: the fix must have moved it off the stale value.
  expect_gt(abs(hmc$logPostSep[4] - stale_penalty), 1e-6)

  # ── 2. sb_eval_logpost (FD / oracle helper) ──
  cpp <- StratoBayes:::.sb_eval_logpost(setup$engine_ptr, 1L, P, debug = TRUE)
  expect_true(isTRUE(cpp$ok))
  expect_equal(cpp$logPostSep[4], true_penalty, tolerance = 1e-8,
    info = "sb_eval_logpost overlap term must match the evaluated params")

  # ── 3. sb_gradient_at (R-engine HMC/NUTS trajectory) ──
  # Only the total logPost is exposed; the non-overlap components are bug-
  # independent, so subtract the stale penalty the buggy path would have used and
  # compare the implied overlap to the independent value.  Equivalent to
  # requiring the total to match (non-overlap components) + (correct overlap).
  nonoverlap <- sum(cpp$logPostSep[1:3])
  grad_at <- StratoBayes:::.sb_gradient_at(setup$engine_ptr, 1L, P)
  expect_true(isTRUE(grad_at$ok))
  expect_equal(grad_at$logPost, nonoverlap + true_penalty, tolerance = 1e-6,
    info = "sb_gradient_at total must include the proposed state's overlap")
  expect_gt(abs(grad_at$logPost - (nonoverlap + stale_penalty)), 1e-6)
})


# ── Test: signal offsets (Gradient_impl.h's `resid -= delta[otg[i]]`) ────────
# Three groups, not two: obsToGroup is consumed 0-based here (the engine
# converts on the way in) and 1-based in Gibbs.cpp, so at G = 2 an index slip
# is only a transposition.

test_that("gradient matches FD with signal offsets active", {
  skip_on_cran()

  set.seed(4113)
  n <- 25
  # Distinct and all far from zero, so no group's delta can drift to where an
  # index slip would be invisible.
  offsets <- c(s1 = -1.5, s2 = 0.5, s3 = 1.0)
  h <- seq(0, 10, length.out = n)
  sig <- do.call(rbind, lapply(names(offsets), function(s) {
    data.frame(site = s, height = h,
               value = sin(h) + offsets[[s]] + rnorm(n, 0, 0.1))
  }))
  sData <- StratData(signal = sig,
                     group = data.frame(site = names(offsets),
                                        group = c("G1", "G2", "G3"),
                                        stringsAsFactors = FALSE))
  sModel <- StratModel(sData, priors = NULL, alignmentScale = "height",
                       sedModel = "site", nKnots = 8, knotRange = c(-2, 12),
                       flexibleKnots = FALSE, signalOffsets = TRUE,
                       sigmaFixed = FALSE)

  setup <- make_test_engine(sData, sModel)
  on.exit(unlink(setup$td, recursive = TRUE))

  # Precondition: without offsets that are active and mutually well separated
  # the subtraction is either a no-op or indistinguishable under a permuted
  # index, and these finite differences prove nothing about it. Measured
  # separation here is 2.3-2.4.
  expect_true(isTRUE(setup$model_obj$offsetConfig$active))
  delta <- unlist(setup$state_obj[[1]]$gibbs$delta)
  expect_length(delta, 3L)
  expect_gt(min(diff(sort(delta))), 0.1)

  grad_result <- StratoBayes:::.sb_compute_gradient(setup$engine_ptr, 1L)
  grad_fd <- cpp_fd_gradient(setup)

  expect_true(all(is.finite(grad_result$grad)))
  expect_true(all(is.finite(grad_fd)))

  pnames <- names(setup$params)[setup$free_idx]
  expect_gradients_match(grad_result$grad, grad_fd, pnames)
})
