# The signal-offset Gibbs step draws delta from the sum-zero *conditional* of
# delta ~ N(0, tau^2 I_G) (#748). Conditioning and plain-mean centering coincide
# exactly when every group has the same number of observations, so every fixture
# here uses unequal group sizes, and the second signal has an empty group.
#
# The oracles are written out from the conjugate full conditionals and replay
# .sb_gibbs's own RNG stream in R; nothing here is read off a second
# implementation of the kernel under test.
#
# SCOPE (#1226): .sb_gibbs is src/Gibbs.cpp. The C++ engine's own offset
# residual and precision loops live in src/MCMCEngine.cpp's `static`
# gibbs_one_signal and are not exercised here; test-signal-offsets*.R reach
# them, but assert "completes" or log-posterior agreement, not the delta draw
# against the conjugate algebra. Contract entry G1 (docs/r-engine-contract.md).

offsetGibbsFixture <- function() {
  p <- 5L
  nGroups <- 4L
  # n_g = (2, 3, 4, 5) and (6, 1, 0, 3): unequal within each signal, and
  # different between them, so a per-signal indexing slip shows as a mismatch.
  obsToGroup <- list(
    c(1L, 1L, 2L, 2L, 2L, 3L, 3L, 3L, 3L, 4L, 4L, 4L, 4L, 4L),
    c(1L, 1L, 1L, 1L, 1L, 1L, 2L, 4L, 4L, 4L)
  )
  nObs <- lengths(obsToGroup)
  sigma <- c(0.7, 1.3)

  B <- lapply(nObs, function(n) {
    u <- seq(0, 1, length.out = n)
    outer(u, seq_len(p), function(x, k) cos((k - 1) * pi * x))
  })
  y <- lapply(nObs, function(n) {
    u <- seq(0, 1, length.out = n)
    0.4 + 1.3 * u - 0.8 * u ^ 2
  })
  delta <- list(c(0.30, -0.10, -0.50, 0.30), c(-0.20, 0.45, 0.05, -0.30))

  yAdj <- Map(function(ym, dm, g) ym - dm[g], y, delta, obsToGroup)

  list(
    p = p, nGroups = nGroups, obsToGroup = obsToGroup, sigma = sigma,
    B = B, y = y, delta = delta, tau = c(0.9, 1.4),
    lambda = c(2.5, 0.4),
    D = crossprod(diff(diag(p), differences = 2)),
    H = Map(function(Bm, s) crossprod(Bm) / s ^ 2, B, sigma),
    tBy = Map(function(Bm, ym, s) as.numeric(crossprod(Bm, ym)) / s ^ 2,
              B, yAdj, sigma),
    aLambda = c(1.2, 0.8), bLambda = c(3, 5),
    shapeSigma = c(2.5, 1.7), bSigma = c(0.9, 1.4),
    aTau = 2.0, bTau = 0.5
  )
}

offsetGibbsArgs <- function(f) {
  list(
    H_list           = f$H,
    tBy_list         = f$tBy,
    B_list           = f$B,
    signalValuesVec  = f$y,
    sigma_in         = f$sigma,
    lambda_in        = f$lambda,
    D_mat            = f$D,
    Q_fallback       = lapply(f$H, function(H) diag(nrow(H))),
    aLambda          = f$aLambda,
    bLambda          = f$bLambda,
    shapeSigma       = f$shapeSigma,
    bSigma_prior     = f$bSigma,
    numBasis         = f$p,
    sigmaIsFixed     = TRUE,
    sigmaFixedValues = f$sigma,
    hasOffsets       = TRUE,
    delta_list       = f$delta,
    tau_in           = f$tau,
    obsToGroup_list  = f$obsToGroup,
    nGroups          = f$nGroups,
    tauFixed         = FALSE,
    tauFixedValue    = 0,
    aTau             = f$aTau,
    bTau             = f$bTau
  )
}

# The draws .sb_gibbs should make, in its own order: beta, lambda, the G
# offsets, then tau, per signal (sigma is fixed here, so it draws nothing).
# `unweighted` records what plain-mean centering returns from the same
# unconstrained draw, which is what makes this fixture discriminating.
offsetClosedFormDraws <- function(f, seed) {
  nSignal <- length(f$sigma)
  out <- list(delta = vector("list", nSignal),
              unweighted = vector("list", nSignal),
              tau = numeric(nSignal))

  set.seed(seed)
  for (m in seq_len(nSignal)) {
    M <- crossprod(f$B[[m]]) / f$sigma[m] ^ 2 + f$lambda[m] * f$D
    mu <- solve(M, f$tBy[[m]])
    beta <- mu + backsolve(chol(M), rnorm(f$p))

    rgamma(1, shape = f$aLambda[m] + (f$p - 2) / 2,          # lambda draw
           scale = 1 / (1 / f$bLambda[m] + 0.5 * sum(beta * (f$D %*% beta))))

    resid <- f$y[[m]] - as.numeric(f$B[[m]] %*% beta)
    g <- f$obsToGroup[[m]]
    nG <- tabulate(g, nbins = f$nGroups)
    sumResid <- vapply(seq_len(f$nGroups),
                       function(k) sum(resid[g == k]), numeric(1))

    prec <- nG / f$sigma[m] ^ 2 + 1 / f$tau[m] ^ 2
    variance <- 1 / prec
    x <- rnorm(f$nGroups, variance * sumResid / f$sigma[m] ^ 2, 1 / sqrt(prec))

    # Conditioning N(mu, diag(variance)) on sum(delta) = 0 subtracts the
    # variance-weighted mean, so data-rich groups move least.
    delta <- x - variance * (sum(x) / sum(variance))
    out$delta[[m]] <- delta
    out$unweighted[[m]] <- x - mean(x)

    out$tau[m] <- 1 / sqrt(rgamma(
      1, shape = f$aTau + (f$nGroups - 1) / 2,
      scale = 1 / (f$bTau + 0.5 * sum(delta ^ 2))
    ))
  }
  out
}

test_that(".sb_gibbs draws delta from the sum-zero conditional", {
  f <- offsetGibbsFixture()
  seed <- 4871

  set.seed(seed)
  res <- do.call(StratoBayes:::.sb_gibbs, offsetGibbsArgs(f))
  oracle <- offsetClosedFormDraws(f, seed)

  for (m in seq_along(f$sigma)) {
    expect_equal(res$delta[[m]], oracle$delta[[m]], tolerance = 1e-10)
    expect_equal(sum(res$delta[[m]]), 0, tolerance = 1e-12)
  }
})

test_that("the sum-zero conditional differs from plain-mean centering", {
  # Guards the test above: with equal group sizes the constrained draw and a
  # plain-mean centering agree exactly, and that assertion cannot fail.
  f <- offsetGibbsFixture()
  oracle <- offsetClosedFormDraws(f, 4871)

  for (m in seq_along(f$sigma)) {
    expect_gt(max(abs(oracle$delta[[m]] - oracle$unweighted[[m]])), 1e-3)
  }
})

test_that(".sb_gibbs draws tau with G - 1 degrees of freedom", {
  f <- offsetGibbsFixture()
  seed <- 4871

  set.seed(seed)
  res <- do.call(StratoBayes:::.sb_gibbs, offsetGibbsArgs(f))
  oracle <- offsetClosedFormDraws(f, seed)

  expect_equal(res$tau, oracle$tau, tolerance = 1e-10)
})

# ── Offset log-prior: G - 1 Gaussian terms plus the sqrt(G) normaliser ────────

offsetLogpostFixture <- function() {
  list(
    nGroups = 3L,
    obsToGroup = c(1L, 1L, 2L, 3L, 3L, 3L),
    delta = c(0.4, -0.9, 0.5),
    tau = 0.8,
    sigma = 1.1,
    y = c(0.2, -0.4, 1.1, 0.5, -0.7, 0.3)
  )
}

# log p(delta | tau) for delta ~ N(0, tau^2 I_G) conditioned on sum(delta) = 0,
# as a density in the G - 1 free coordinates.
offsetLogPrior <- function(delta, tau) {
  nGroups <- length(delta)
  -(nGroups - 1) * (log(tau) + log(sqrt(2 * pi))) +
    0.5 * log(nGroups) -
    0.5 * sum(delta ^ 2) / tau ^ 2
}

test_that(".sb_logpost carries the sum-zero offset prior (joint at beta)", {
  f <- offsetLogpostFixture()
  # A zero design matrix pins the fitted spline at zero, leaving a closed-form
  # signal log-likelihood that isolates the offset prior term.
  B <- matrix(0, nrow = length(f$y), ncol = 1L)

  got <- StratoBayes:::.sb_logpost(
    x = numeric(0), priorTypes = character(0), priorArgs = list(),
    rCustomFns = list(), B_list = list(B), beta_list = list(0),
    signalValues = list(f$y), sigma = f$sigma, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list(),
    hasOffsets = TRUE, delta_list = list(f$delta),
    obsToGroup_list = list(f$obsToGroup), tau = f$tau
  )

  resid <- f$y - f$delta[f$obsToGroup]
  expect_equal(
    got[2],
    -length(f$y) * (log(f$sigma) + log(sqrt(2 * pi))) -
      0.5 * sum(resid ^ 2) / f$sigma ^ 2 +
      offsetLogPrior(f$delta, f$tau),
    tolerance = 1e-12
  )
})

test_that(".sb_logpost carries the sum-zero offset prior (beta-marginal)", {
  f <- offsetLogpostFixture()
  p <- 3L
  u <- seq(0, 1, length.out = length(f$y))
  B <- outer(u, seq_len(p), function(x, k) cos((k - 1) * pi * x))
  D <- crossprod(diff(diag(p), differences = 2))

  logpostAt <- function(tau) {
    StratoBayes:::.sb_logpost(
      x = numeric(0), priorTypes = character(0), priorArgs = list(),
      rCustomFns = list(), B_list = list(B), beta_list = list(numeric(p)),
      signalValues = list(f$y), sigma = f$sigma, overlapPenalty = FALSE,
      signalSectionOverlap = list(), adjustments = list(),
      hasOffsets = TRUE, delta_list = list(f$delta),
      obsToGroup_list = list(f$obsToGroup), tau = tau,
      marginal = TRUE, lambda = 1.7, Dmat = D
    )[2]
  }

  # tau enters the marginal branch only through the offset prior, so the
  # increment pins its tau exponent at G - 1 without needing the marginal's
  # value. (The sqrt(G) normaliser cancels here; the joint test above pins it.)
  tauLo <- 0.8
  tauHi <- 1.9
  expect_true(is.finite(logpostAt(tauLo)))
  expect_equal(
    logpostAt(tauHi) - logpostAt(tauLo),
    offsetLogPrior(f$delta, tauHi) - offsetLogPrior(f$delta, tauLo),
    tolerance = 1e-12
  )
})
