# Issue #602: the `StratPosterior` adapter around `.AutoBurnInCore()`.
#
# The adapter slices the samples array directly instead of calling
# `ExtractParameters()`, so these tests pin it against the two authorities it
# bypasses: `summary.StratPosterior()`'s `psrfPar` column set, and
# `ExtractParameters()`'s aggregation of the two summed log densities.

test_that("the monitored column set matches summary()'s psrfPar", {
  sp <- stratPosterior1
  parNames <- dimnames(sp[["samples"]])[[2]]
  signalNames <- sp[[c("data", "signalAttr", "signalNames")]]
  sigmaNames <- paste("sigma", signalNames, sep = "_")

  psrfPar <- c(
    sp[[c("model", "parametersNames")]],
    if (all(sigmaNames %fin% parNames)) sigmaNames,
    paste("lambda", signalNames, sep = "_"),
    "log prior", "log likelihood", "log posterior"
  )

  draws <- .AutoBurnInDraws(sp)
  expect_identical(colnames(draws[["drawList"]][[1L]]), psrfPar)
  expect_length(draws[["drawList"]], sp[["nRun"]])
  expect_identical(draws[["iterList"]], sp[[c("mcmcSummary", "saveIter")]])
})

test_that("the summed log densities reproduce ExtractParameters exactly", {
  # `"log prior"` and `"log likelihood"` are display names with no column
  # behind them; the adapter sums their components itself, so it can drift from
  # ExtractParameters(). Compare by position: ExtractParameters() returns the
  # resolved internal names, not the display names asked for.
  sp <- stratPosterior1
  draws <- .AutoBurnInDraws(sp)[["drawList"]][[1L]]

  for (nm in c("log prior", "log likelihood", "log posterior")) {
    reference <- ExtractParameters(sp, parameters = nm, runs = 1, burnIn = 0)
    expect_equal(unname(as.numeric(reference[, 1L])),
                 unname(as.numeric(draws[, nm])),
                 info = nm)
  }
})

test_that("a converged fixture yields an absolute iteration on the lattice", {
  # `stratPosterior5b` reaches R-hat ~1.0005, comfortably inside the shipped
  # 1.02 default, so this pins the success path without loosening the
  # threshold.
  sp <- stratPosterior5b
  res <- .AutoBurnIn(sp)

  expect_identical(res[["status"]], "ok")
  expect_true(res[["iteration"]] %fin%
                c(0, unlist(sp[[c("mcmcSummary", "saveIter")]])))
  # At or beyond the end of adaptation (#260).
  expect_gte(res[["iteration"]], max(sp[[c("mcmcSummary", "endAdapting")]]))
  expect_lte(res[["rHat"]], res[["rHatMax"]])
})

test_that("a fixture that does not converge certifies no burn-in", {
  # `stratPosterior1` sits at R-hat ~1.0206, just above the 1.02 default: real
  # data on the fallback path, which is what most runs will take.
  res <- .AutoBurnIn(stratPosterior1)

  expect_identical(res[["status"]], "rHatNotReached")
  expect_identical(res[["iteration"]], .kAutoBurnInFallback)
  expect_gt(res[["rHat"]], res[["rHatMax"]])
})

test_that(".ResolveBurnIn passes through anything that is not exactly \"auto\"", {
  sp <- stratPosterior1

  expect_identical(.ResolveBurnIn(sp, 0.25), 0.25)
  expect_identical(.ResolveBurnIn(sp, 1500), 1500)
  # No partial or case-insensitive matching: these must reach the consumers'
  # own validation unchanged, and be rejected there.
  expect_identical(.ResolveBurnIn(sp, "AUTO"), "AUTO")
  expect_identical(.ResolveBurnIn(sp, "a"), "a")

  expect_identical(suppressWarnings(.ResolveBurnIn(sp, "auto")),
                   .AutoBurnIn(sp)[["iteration"]])
})

test_that(".ResolveBurnIn is silent on success and warns on fallback", {
  # Every plot and extraction resolves, so a success may not narrate. A
  # fallback must: the number returned certifies nothing, and the caller is
  # about to plot it as though it did.
  expect_silent(.ResolveBurnIn(stratPosterior1, 0.5))

  expect_warning(.ResolveBurnIn(stratPosterior1, "auto"),
                 "not a posterior sample")
  # `.AutoBurnIn()` itself stays quiet: the stopping rule asks the same
  # question at every checkpoint and reads only `status`.
  expect_silent(.AutoBurnIn(stratPosterior1))

  # A converged fixture resolves without comment.
  ok <- .AutoBurnIn(stratPosterior4)
  skip_if(.AutoBurnInFellBack(ok[["status"]]), "fixture does not converge")
  expect_silent(.ResolveBurnIn(stratPosterior4, "auto"))
})


# A posterior whose `.cache` actually belongs to it. No shipped fixture has
# one: stratPosterior1 carries no `.cache` field at all, and stratPosterior4
# carries one whose stamp no longer matches its own samples, so
# `.PosteriorCache()` disowns it. Both must therefore work uncached.
AbWithLiveCache <- function(sp) {
  cache <- new.env(parent = emptyenv())
  cache$stamp <- .CacheStamp(.subset2(sp, "samples"), .subset2(sp, "nRun"))
  sp[[".cache"]] <- cache
  sp
}

test_that("no shipped fixture has a live cache, and that is not fatal", {
  expect_null(.subset2(stratPosterior1, ".cache"))
  expect_false(is.null(.subset2(stratPosterior4, ".cache")))
  expect_null(.PosteriorCache(stratPosterior4))

  expect_identical(.AutoBurnIn(stratPosterior1), .AutoBurnIn(stratPosterior1))
})

test_that("the result is memoised when the object carries its own cache", {
  sp <- AbWithLiveCache(stratPosterior1)
  expect_false(is.null(.PosteriorCache(sp)))
  expect_null(.PosteriorCache(sp)$autoBurnIn)

  result <- .AutoBurnIn(sp)
  expect_identical(.PosteriorCache(sp)$autoBurnIn, result)
  # Second call must be served from the cache, not recomputed.
  expect_identical(.AutoBurnIn(sp), result)
})

test_that("the cache never answers a call with different criteria", {
  # The cache holds one answer per object and is keyed on nothing, so a call
  # supplying its own criteria must bypass it -- otherwise the stopping rule's
  # per-checkpoint `essTarget` would be answered by a search that never used it.
  sp <- AbWithLiveCache(stratPosterior1)
  default <- .AutoBurnIn(sp)
  expect_identical(.PosteriorCache(sp)$autoBurnIn, default)

  lenient <- .AutoBurnIn(sp, rHatMax = 1.5)
  expect_identical(lenient[["status"]], "ok")
  expect_identical(lenient[["rHatMax"]], 1.5)
  expect_false(identical(lenient, default))

  # ...and the bypassing call must not overwrite the cached default either.
  expect_identical(.PosteriorCache(sp)$autoBurnIn, default)
})

test_that("a cache inherited from another posterior is not served (RT-454)", {
  sp <- stratPosterior1

  planted <- sp
  cache <- new.env(parent = emptyenv())
  # A stamp taken from *different* samples: exactly what a posterior derived by
  # field assignment carries away from its parent.
  cache$stamp <- .CacheStamp(.subset2(sp, "samples")[, , 1, , drop = FALSE], 1L)
  cache$autoBurnIn <- list(iteration = -999, rHat = 1, ess = 1,
                           status = "ok")
  planted[[".cache"]] <- cache

  expect_null(.PosteriorCache(planted))
  expect_false(identical(.AutoBurnIn(planted)[["iteration"]], -999))
  expect_identical(.AutoBurnIn(planted), .AutoBurnIn(sp))
})

test_that("a posterior whose samples and mcmcSummary disagree errors clearly", {
  broken <- stratPosterior1
  broken[["samples"]] <- broken[["samples"]][, , 1, , drop = FALSE]

  expect_error(.AutoBurnInDraws(broken), "saved-iteration schedule")
})

test_that("a posterior with no cold chain says so, not \"subscript out of bounds\"", {
  relabelled <- stratPosterior1
  dimnames(relabelled[["samples"]])[[4]] <- "cold"

  expect_error(.AutoBurnInDraws(relabelled), "no `chain1`")
})

test_that("a burn-in past a run's last iteration is chosen, and survives use", {
  # The chooser may now exceed a run's whole span, so the consumers that then
  # subset zero rows from that run are exercised rather than assumed safe.
  sp <- stratPosterior5b
  saveIter <- sp[[c("mcmcSummary", "saveIter")]]
  endAdapt <- max(sp[[c("mcmcSummary", "endAdapting")]])
  # Truncated below the adaptation floor, so no admissible burn-in can retain a
  # row of it (#260).
  sp[["mcmcSummary"]][["saveIter"]][[1L]] <-
    saveIter[[1L]][saveIter[[1L]] < endAdapt]

  res <- .AutoBurnIn(sp)
  expect_identical(res[["status"]], "ok")
  expect_gt(res[["iteration"]], max(sp[[c("mcmcSummary", "saveIter")]][[1L]]))
  expect_identical(res[["nRunDropped"]], 1L)

  # R-hat must not come back NA beneath a message quoting a number: the run left
  # with no rows is dropped from the diagnostic, not carried into it as a
  # zero-length split.
  psrf <- suppressWarnings(summary(sp, burnIn = "auto"))[[c("general", "psrf")]]
  expect_true(all(is.finite(psrf)))
  expect_lte(max(psrf), res[["rHatMax"]])

  for (Consumer in list(ExtractIterations, Cluster)) {
    expect_no_error(suppressWarnings(Consumer(sp, burnIn = "auto")))
  }
})

test_that("summary(burnIn = \"auto\") runs the auto-burn-in search once, not twice (RT-710/#900)", {
  # `stratPosterior1` has no `.cache`, so nothing here is ever served from a
  # memo hit -- an oracle count of 1 can only happen if `summary()` reuses the
  # result it already computed, rather than asking `.ResolveBurnIn()` to
  # search again.
  sp <- stratPosterior1
  expect_null(.subset2(sp, ".cache"))

  coreCalls <- 0L
  realCore <- StratoBayes:::.AutoBurnInCore
  testthat::local_mocked_bindings(
    .AutoBurnInCore = function(...) {
      coreCalls <<- coreCalls + 1L
      realCore(...)
    },
    .package = "StratoBayes"
  )

  suppressWarnings(summary(sp, burnIn = "auto"))
  expect_identical(coreCalls, 1L)
})
