# Regression test for red-team finding RT-008.
#
# The HMC/NUTS early-return path in update_state_internal() (MCMCEngine.cpp)
# used to write proposal timing directly onto the SHARED `eng.timing.propose`
# accumulator instead of the per-chain `tm.propose` accumulator (chainTiming)
# that every other proposal type uses, then `return`s immediately — so the
# per-chain accumulator never sees any contribution from HMC/NUTS proposals.
# The real defect is that the direct write races unsynchronized across worker
# threads when nThreads > 1 (UB); a race is not required to see the
# structural symptom, though: an all-NUTS run should populate the per-chain
# accumulators, and pre-fix it does not.
#
# `.sb_get_chain_propose_timing()` exposes `chainTiming[c].propose` (in
# seconds) directly, untouched by `sb_run_block`'s end-of-block merge into the
# shared `timing` accumulator — a deterministic, thread-count-independent
# discriminator:
#   * fixed:  sum(per-chain propose) > 0  (HMC/NUTS time recorded per-chain)
#   * buggy:  sum(per-chain propose) == 0 (HMC/NUTS bypassed the per-chain
#             accumulator entirely) while `timing$propose` (shared) is > 0

test_that("RT-008: HMC/NUTS proposal timing is recorded per-chain, not just on the shared accumulator", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), paste0("rt008_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(9001)
  result <- RunStratModel(gradientProposals = "on", 
    stratObject = stratData1, stratModel = model,
    nIter = 5, nChains = 4, seed = 1,
    quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "rt008", engine = "R"
  )

  data_obj  <- result$data
  model_obj <- result$model
  mcmc_obj  <- readRDS(file.path(td, "rt008_mcmc_run_1.rds"))
  state_obj <- mcmc_obj$recentState

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  # Force every chain to select NUTS on every iteration.
  nutsIdx <- which(colnames(mcmc_obj$metro$proposalProbability) == "NUTS")
  mcmc_obj$metro$proposalProbability[, ] <- 0
  mcmc_obj$metro$proposalProbability[, nutsIdx] <- 1

  engine_ptr <- StratoBayes:::.sb_create_engine(
    data = data_obj, model = model_obj, mcmc = mcmc_obj,
    state = state_obj, tiesCallback = NULL
  )

  # nThreads = 2 (project cap): the scenario the finding names, though the
  # accounting invariant below holds regardless of thread count.
  StratoBayes:::.sb_set_threads(engine_ptr, 2L)
  out <- StratoBayes:::.sb_run_block(engine_ptr, 100L,
                                     diagnostics = FALSE, timing = TRUE)

  perChain <- StratoBayes:::.sb_get_chain_propose_timing(engine_ptr)

  expect_length(perChain, 4L)
  expect_true(all(is.finite(perChain)))

  # Bulletproof discriminator: an all-NUTS run must show up in the per-chain
  # accumulators. Pre-fix, HMC/NUTS proposals bypass them entirely, so this
  # sum is exactly 0 even though timing$propose (shared) is > 0.
  expect_gt(sum(perChain), 0)

  # Stronger invariant: the shared total (built solely from the per-chain
  # merge, now that HMC/NUTS no longer writes it directly) should equal the
  # sum of the per-chain accumulators.
  expect_equal(out$timing[["propose"]], sum(perChain), tolerance = 1e-6)
})
