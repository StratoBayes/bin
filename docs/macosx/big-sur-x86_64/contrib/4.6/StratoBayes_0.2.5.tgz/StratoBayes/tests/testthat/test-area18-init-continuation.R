test_that("each chain draws its own automatic starting point (#1219)", {
  set.seed(1)
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 4)
  expect_false(mcmc[[c("metro", "parametersInitialUserProvided")]])

  set.seed(42)
  starts <- vapply(
    seq_len(4),
    function(chain) {
      .GenerateInitialState(stratData1, stratModel1, mcmc, chain = chain)[[
        c("metro", "parameters")]]
    },
    numeric(length(stratModel1[["parametersNames"]]))
  )
  # Before the fix every chain returned the object's one stored draw, so this
  # was 1.
  expect_equal(nrow(unique(t(starts))), 4L)
})

test_that("a user-supplied parametersInitial is still honoured exactly", {
  set.seed(1)
  fixed <- StratMCMC(stratModel1, nIter = 10, nChains = 2)[[
    c("metro", "parametersInitial")]]
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 2,
                    parametersInitial = fixed)
  expect_true(mcmc[[c("metro", "parametersInitialUserProvided")]])

  starts <- lapply(1:2, function(chain) {
    .GenerateInitialState(stratData1, stratModel1, mcmc,
                          chain = chain)[[c("metro", "parameters")]]
  })
  expect_equal(starts[[1]], unname(fixed))
  expect_equal(starts[[2]], unname(fixed))
})

test_that("a supplied stratMCMC template does not share one start across runs (#1220)", {
  modelDir <- withr::local_tempdir()
  set.seed(1)
  template <- StratMCMC(stratModel1, nIter = 1, nChains = 2, nThreads = 1L)
  suppressWarnings(suppressMessages(capture.output(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = template,
                  nRun = 2, seed = TRUE, runParallel = FALSE,
                  visualise = FALSE, quiet = TRUE, nThreads = 1L,
                  modelDir = modelDir, modelName = "t1220")
  )))

  # `nIter = 1` leaves each run's `recentState` at the state it started from.
  runStart <- function(run) {
    readRDS(file.path(modelDir, paste0("t1220_mcmc_run_", run, ".rds")))[[
      "recentState"]][[1]][[c("metro", "parameters")]]
  }
  # Before the fix both runs reused the template's single stored draw, so this
  # was TRUE.
  expect_false(identical(runStart(1), runStart(2)))
})

test_that("the checkpoint records this call's nThreads (#1221)", {
  modelDir <- withr::local_tempdir()
  suppressWarnings(suppressMessages(capture.output(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 1,
                  nChains = 2, nThreads = 2L, runParallel = FALSE,
                  visualise = FALSE, quiet = TRUE,
                  modelDir = modelDir, modelName = "t1221")
  )))
  checkpoint <- readRDS(file.path(modelDir, "t1221_mcmc_run_1.rds"))
  # Before the fix this was StratMCMC()'s own fallback of 1, with the flag
  # FALSE, so `nThreads = 0`'s documented inheritance recovered neither.
  expect_equal(checkpoint[["nThreads"]], 2L)
  expect_true(checkpoint[[".nThreadsUserSet"]])
})

test_that("a checkpoint with no nThin fails the continuation check (#1222)", {
  runs <- list(list(nThin = 1), list(nThin = NULL))
  # Before the fix `unlist()` dropped run 2 and the uniqueness test passed on
  # the survivor, silently returning `nThin = 1` for both runs.
  expect_error(
    .ResolveContinuationThin(1, runs, c(10, 10), character(0)),
    "do not all record an `nThin`"
  )
  # A complete set still resolves silently.
  expect_equal(
    .ResolveContinuationThin(1, list(list(nThin = 1), list(nThin = 1)),
                             c(10, 10), character(0))[["nThin"]],
    1
  )
})

test_that("a legacy object with no user-provided flag keeps its stored start", {
  set.seed(1)
  mcmc <- StratMCMC(stratModel1, nIter = 10, nChains = 2)
  stored <- mcmc[[c("metro", "parametersInitial")]]
  # An object saved before the flag existed carries no such field, and
  # `isFALSE(NULL)` is FALSE, so it must keep its one stored draw. Writing the
  # gate as `!isTRUE()` would redraw here and change such an object's start.
  mcmc[["metro"]][["parametersInitialUserProvided"]] <- NULL
  expect_null(mcmc[[c("metro", "parametersInitialUserProvided")]])

  starts <- lapply(1:2, function(chain) {
    .GenerateInitialState(stratData1, stratModel1, mcmc,
                          chain = chain)[[c("metro", "parameters")]]
  })
  expect_equal(starts[[1]], stored)
  expect_equal(starts[[2]], stored)
})
