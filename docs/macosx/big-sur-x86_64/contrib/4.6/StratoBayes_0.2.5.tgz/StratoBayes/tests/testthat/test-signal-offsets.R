# tests/testthat/test-signal-offsets.R
# Tests for the between-site proxy offset feature.

# ══════════════════════════════════════════════════════════════════════════════
# 1. StratData group parsing
# ══════════════════════════════════════════════════════════════════════════════

test_that("StratData accepts a data.frame group argument", {
  grp <- data.frame(
    site  = c("site1", "site2"),
    group = c("BasinA", "BasinB"),
    stringsAsFactors = FALSE
  )
  d <- StratData(signal = signalData0, group = grp)
  expect_false(is.null(d[["groupAttr"]]))
  expect_equal(d[["groupAttr"]][["nGroups"]], 2L)
  # Do not re-sort: R/StratData.R:1125 already sorts, so a sort() here could
  # only hide a reordering.
  expect_equal(d[["groupAttr"]][["groups"]], c("BasinA", "BasinB"))
  expect_equal(d[["groupAttr"]][["siteToGroup"]],
               c(site1 = 1L, site2 = 2L))
  # The composed site -> group-label map, which nothing else pins.
  expect_equal(d[["groupAttr"]][["groupSites"]],
               list(BasinA = "site1", BasinB = "site2"))
})

test_that("StratData accepts a named character vector for group", {
  grp <- c(site1 = "G1", site2 = "G2")
  d <- StratData(signal = signalData0, group = grp)
  expect_equal(d[["groupAttr"]][["nGroups"]], 2L)
})

test_that("StratData with group = NULL has NULL groupAttr", {
  d <- StratData(signal = signalData0)
  expect_null(d[["groupAttr"]])
})

test_that("StratData errors on missing sites in group", {
  grp <- data.frame(site = "site1", group = "A", stringsAsFactors = FALSE)
  expect_error(
    StratData(signal = signalData0, group = grp),
    "missing from `group`"
  )
})

test_that("StratData errors on single group", {
  grp <- data.frame(
    site  = c("site1", "site2"),
    group = c("A", "A"),
    stringsAsFactors = FALSE
  )
  expect_error(
    StratData(signal = signalData0, group = grp),
    "at least 2 distinct groups"
  )
})

# ══════════════════════════════════════════════════════════════════════════════
# 2. StratModel offset configuration
# ══════════════════════════════════════════════════════════════════════════════

test_that("StratModel with signalOffsets = FALSE has NULL offsetConfig", {
  d <- StratData(signal = signalData0)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = FALSE)
  expect_null(m[["offsetConfig"]])
})

test_that("StratModel with signalOffsets = TRUE builds offsetConfig", {
  grp <- data.frame(
    site  = c("site1", "site2"),
    group = c("BasinA", "BasinB"),
    stringsAsFactors = FALSE
  )
  d <- StratData(signal = signalData0, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = TRUE)
  oc <- m[["offsetConfig"]]
  expect_true(oc[["active"]])
  expect_equal(oc[["nGroups"]], 2L)
  expect_length(oc[["obsToGroup"]], d[["signalAttr"]][["signalN"]])
  # That length holds by construction whatever each observation maps to, so the
  # expected value here is rebuilt from the raw site column instead.
  expect_equal(oc[["obsToGroup"]][[1]],
               match(signalData0[["site"]], c("site1", "site2")))
  expect_equal(oc[["nObsPerGroup"]][[1]],
               as.integer(table(factor(signalData0[["site"]],
                                       levels = c("site1", "site2")))))
})

test_that("StratModel errors when signalOffsets = TRUE without groups", {
  d <- StratData(signal = signalData0)
  expect_error(
    StratModel(d, priors = NULL, alignmentScale = "height",
               sedModel = "site", nKnots = 10, signalOffsets = TRUE),
    "requires `group`"
  )
})

test_that("StratModel outputParams include delta and tau when offsets active", {
  grp <- data.frame(
    site  = c("site1", "site2"),
    group = c("BasinA", "BasinB"),
    stringsAsFactors = FALSE
  )
  d <- StratData(signal = signalData0, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = TRUE)
  op <- m[["outputParams"]]
  expect_true(any(grepl("^delta_", op)))
  expect_true(any(grepl("^tau_", op)))
})

# ══════════════════════════════════════════════════════════════════════════════
# 3. Backward compatibility: existing datasets without groups
# ══════════════════════════════════════════════════════════════════════════════

test_that("pre-existing StratData without groupAttr still works", {
  d <- StratData(signal = signalData0)
  d[["groupAttr"]] <- NULL
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10)
  expect_null(m[["offsetConfig"]])
  expect_false(any(grepl("^delta_", m[["outputParams"]])))
})

# ── Helper: build synthetic 2-site offset data ──────────────────────────────
.make_offset_data <- function(n = 30, offset = 2.0, noise_sd = 0.1) {
  h <- seq(0, 10, length.out = n)
  sig <- data.frame(
    site   = c(rep("site_1", n), rep("site_2", n)),
    height = c(h, h),
    value  = c(sin(h) + rnorm(n, 0, noise_sd),
               sin(h) + offset + rnorm(n, 0, noise_sd))
  )
  grp <- data.frame(site = c("site_1", "site_2"),
                     group = c("A", "B"),
                     stringsAsFactors = FALSE)
  list(signal = sig, group = grp)
}

# Helper: extract parameter names from 4D samples array
.sample_params <- function(post) {
  dimnames(post[["samples"]])[[2]]
}

# Helper: flatten 4D samples array to matrix (iter × params), collapsing
# runs and chains.
.flatten_samples <- function(post) {
  s <- post[["samples"]]
  d <- dim(s)
  # d = [nIter, nParams, nRuns, nChains]
  nIter   <- d[1]
  nParams <- d[2]
  nRuns   <- d[3]
  nChains <- d[4]
  pnames  <- dimnames(s)[[2]]
  # aperm first: the parameter margin has to become the LAST one, or a plain
  # column-major reshape interleaves consecutive parameters down each column
  # instead of stacking one parameter across runs and chains.
  mat <- matrix(aperm(s, c(1L, 3L, 4L, 2L)),
                nrow = nIter * nRuns * nChains, ncol = nParams)
  colnames(mat) <- pnames
  mat
}

test_that(".flatten_samples collapses runs and chains, not parameters", {
  # Synthetic because every stored array here is [nIter, nParams, 1, 1], where
  # a wrong reshape and a right one coincide.
  s <- array(1:12, dim = c(3L, 2L, 1L, 2L),
             dimnames = list(NULL, c("p1", "p2"), NULL, NULL))
  mat <- .flatten_samples(list(samples = s))

  expect_equal(dim(mat), c(6L, 2L))
  expect_equal(mat[, "p1"], c(1:3, 7:9))
  expect_equal(mat[, "p2"], c(4:6, 10:12))
})

# ══════════════════════════════════════════════════════════════════════════════
# 4. Short MCMC run with offsets — R engine
# ══════════════════════════════════════════════════════════════════════════════

test_that("RunStratModel with signal offsets (R engine) completes", {
  skip_on_cran()

  set.seed(4827)
  dat <- .make_offset_data()
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 100, nChains = 2, nRun = 1,
    engine = "R", quiet = TRUE
  ))

  expect_s3_class(post, "StratPosterior")
  pnames <- .sample_params(post)
  expect_true(any(grepl("^delta_", pnames)))
  expect_true(any(grepl("^tau_", pnames)))
})

# ══════════════════════════════════════════════════════════════════════════════
# 5. Short MCMC run with offsets — C++ engine
# ══════════════════════════════════════════════════════════════════════════════

test_that("RunStratModel with signal offsets (C++ engine) completes", {
  skip_on_cran()

  set.seed(6193)
  dat <- .make_offset_data()
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 100, nChains = 2, nRun = 1,
    engine = "cpp", quiet = TRUE
  ))

  expect_s3_class(post, "StratPosterior")
  pnames <- .sample_params(post)
  expect_true(any(grepl("^delta_", pnames)))
  expect_true(any(grepl("^tau_", pnames)))
})

# ══════════════════════════════════════════════════════════════════════════════
# 6. Without offsets, existing tests should pass (spot check)
# ══════════════════════════════════════════════════════════════════════════════

test_that("RunStratModel without offsets is unchanged", {
  skip_on_cran()

  d <- StratData(signal = signalData0)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 50, nChains = 2, nRun = 1,
    engine = "cpp", quiet = TRUE
  ))
  expect_s3_class(post, "StratPosterior")
  pnames <- .sample_params(post)
  expect_false(any(grepl("^delta_", pnames)))
  expect_false(any(grepl("^tau_", pnames)))
})

# ══════════════════════════════════════════════════════════════════════════════
# 7. Fixed tau (offsetPriorScale) — both engines
# ══════════════════════════════════════════════════════════════════════════════

test_that("Fixed tau via offsetPriorScale works (R engine)", {
  skip_on_cran()

  set.seed(3194)
  dat <- .make_offset_data(n = 25, offset = 1.5)
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  offsetPriorScale = 1.0, sigmaFixed = FALSE)

  expect_true(m[["offsetConfig"]][["tauFixed"]])
  expect_equal(m[["offsetConfig"]][["tauFixedValue"]], 1.0)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 80, nChains = 2, nRun = 1,
    engine = "R", quiet = TRUE
  ))
  expect_s3_class(post, "StratPosterior")

  mat <- .flatten_samples(post)
  tau_cols <- grep("^tau_", colnames(mat), value = TRUE)
  expect_true(length(tau_cols) >= 1L)
  expect_true(all(mat[, tau_cols[1]] == 1.0))
})

test_that("Fixed tau via offsetPriorScale works (C++ engine)", {
  skip_on_cran()

  set.seed(8517)
  dat <- .make_offset_data(n = 25, offset = 1.5)
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  offsetPriorScale = 1.0, sigmaFixed = FALSE)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 80, nChains = 2, nRun = 1,
    engine = "cpp", quiet = TRUE
  ))
  expect_s3_class(post, "StratPosterior")

  mat <- .flatten_samples(post)
  tau_cols <- grep("^tau_", colnames(mat), value = TRUE)
  expect_true(length(tau_cols) >= 1L)
  expect_true(all(mat[, tau_cols[1]] == 1.0))
})

# ══════════════════════════════════════════════════════════════════════════════
# 8. Four sites, two groups (sum-to-zero constraint)
# ══════════════════════════════════════════════════════════════════════════════

test_that("Offsets work with 4 sites across 2 groups (C++ engine)", {
  skip_on_cran()

  set.seed(2756)
  n <- 20
  make_site <- function(name, h_range, offset) {
    h <- seq(h_range[1], h_range[2], length.out = n)
    data.frame(site = name, height = h,
               value = sin(h * pi / 5) + offset + rnorm(n, 0, 0.15))
  }
  sig <- rbind(
    make_site("s1", c(0, 10), 0),
    make_site("s2", c(1, 9),  0),
    make_site("s3", c(0.5, 8), 1.5),
    make_site("s4", c(2, 10),  1.5)
  )
  grp <- data.frame(
    site  = c("s1", "s2", "s3", "s4"),
    group = c("A",  "A",  "B",  "B")
  )
  d <- StratData(signal = sig, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 150, nChains = 2, nRun = 1,
    engine = "cpp", quiet = TRUE
  ))
  expect_s3_class(post, "StratPosterior")

  mat <- .flatten_samples(post)
  delta_cols <- grep("^delta_", colnames(mat), value = TRUE)
  expect_true(length(delta_cols) == 2L)

  delta_sums <- rowSums(mat[, delta_cols, drop = FALSE])
  expect_true(all(abs(delta_sums) < 1e-10))
})

# ══════════════════════════════════════════════════════════════════════════════
# 8b. Three groups
# ══════════════════════════════════════════════════════════════════════════════
#
# At G = 2 sum-to-zero fixes the second delta given the first, so a transposed
# mapping is the only error a test can see. test-748-offset-sum-zero.R reaches
# G = 3/4 but hands obsToGroup straight to .sb_gibbs, bypassing
# .BuildOffsetConfig and the 1-based -> 0-based conversion; this goes through
# both.

test_that("Offsets recover three distinct group offsets (C++ engine)", {
  skip_on_cran()

  set.seed(555)
  n <- 25
  offsets <- c(s1 = -1, s2 = 0, s3 = 1)
  h <- seq(0, 10, length.out = n)
  sig <- do.call(rbind, lapply(names(offsets), function(s) {
    data.frame(site = s, height = h,
               value = sin(h) + offsets[[s]] + rnorm(n, 0, 0.1))
  }))
  grp <- data.frame(site = names(offsets), group = c("G1", "G2", "G3"),
                    stringsAsFactors = FALSE)
  d <- StratData(signal = sig, group = grp)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 10, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  oc <- m[["offsetConfig"]]
  expect_equal(oc[["nGroups"]], 3L)
  expect_equal(oc[["obsToGroup"]][[1]], match(sig[["site"]], names(offsets)))
  expect_equal(d[["groupAttr"]][["groupSites"]],
               list(G1 = "s1", G2 = "s2", G3 = "s3"))

  # nChains = 16, not 8: three sites give the alignment more modes to lose
  # itself in, and at 8 rungs 2 of 15 seeds failed to align (recovery error up
  # to 0.13). At 16 the worst over the same 15 was 0.022.
  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 500, nChains = 16, nRun = 1, seed = 1L, nThreads = 1L,
    engine = "cpp", quiet = TRUE
  ))

  mat <- .flatten_samples(post)
  delta_cols <- grep("^delta_", colnames(mat), value = TRUE)
  expect_equal(delta_cols, c("delta_G1_value", "delta_G2_value",
                             "delta_G3_value"))
  expect_true(all(abs(rowSums(mat[, delta_cols, drop = FALSE])) < 1e-10))

  # The generating offsets already sum to zero, so each recovered delta must
  # match its own group's. 0.1 is 4.6x the worst error measured and a tenth of
  # the spacing between groups, so a transposition (2.0), a mis-mapped middle
  # group (1.0) or a doubled scale (1.0) are all caught by an order of
  # magnitude.
  post_burnin <- seq(nrow(mat) %/% 2 + 1, nrow(mat))
  recovered <- colMeans(mat[post_burnin, delta_cols, drop = FALSE])
  expect_lt(max(abs(recovered - offsets)), 0.1)
})

# ══════════════════════════════════════════════════════════════════════════════
# 9. Sum-to-zero constraint verification (R engine)
# ══════════════════════════════════════════════════════════════════════════════

test_that("Sum-to-zero constraint holds in R engine", {
  skip_on_cran()

  set.seed(5471)
  dat <- .make_offset_data()
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  post <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = 80, nChains = 2, nRun = 1,
    engine = "R", quiet = TRUE
  ))

  mat <- .flatten_samples(post)
  delta_cols <- grep("^delta_", colnames(mat), value = TRUE)
  # Without it the row sums below are zero-length and the check is vacuous.
  expect_true(length(delta_cols) == 2L)

  delta_sums <- rowSums(mat[, delta_cols, drop = FALSE])
  expect_true(all(abs(delta_sums) < 1e-10))
})

# ══════════════════════════════════════════════════════════════════════════════
# 10. C++ engine vs R engine comparison
# ══════════════════════════════════════════════════════════════════════════════

test_that("C++ and R engines recover the same delta posterior", {
  skip_on_cran()

  # nChains = 8 is load-bearing. Both engines draw delta from the same Gibbs
  # conditional, so this comparison really measures whether both found the same
  # ALIGNMENT -- and at nChains = 2 the R chain lands in a mode where delta is
  # unidentified on roughly 1 seed in 3. Over 8 rungs, 25 of 25 seeds aligned.
  set.seed(7283)
  dat <- .make_offset_data(offset = 1.5)
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  RunBoth <- function(engine) {
    suppressWarnings(RunStratModel(
      stratObject = d, stratModel = m,
      nIter = 500, nChains = 8, nRun = 1, seed = 7283, nThreads = 1L,
      engine = engine, quiet = TRUE
    ))
  }
  mat_r   <- .flatten_samples(RunBoth("R"))
  mat_cpp <- .flatten_samples(RunBoth("cpp"))
  delta_cols <- grep("^delta_", colnames(mat_r), value = TRUE)

  expect_equal(sort(delta_cols),
               sort(grep("^delta_", colnames(mat_cpp), value = TRUE)))

  # Burn-in is stored too, and drags the full-run mean from -0.736 to -0.580.
  post_burnin <- seq(nrow(mat_r) %/% 2 + 1, nrow(mat_r))
  draws_r   <- mat_r[post_burnin, "delta_A_value"]
  draws_cpp <- mat_cpp[post_burnin, "delta_A_value"]

  expect_true(all(abs(rowSums(mat_r[, delta_cols, drop = FALSE])) < 1e-10))
  expect_true(all(abs(rowSums(mat_cpp[, delta_cols, drop = FALSE])) < 1e-10))

  # 0.05 throughout: 2x the worst posterior SD measured over 25 seeds x 2
  # engines, 12x the worst gap and 3x the worst ground-truth error. Fixed
  # rather than derived from these draws, which would loosen the bound exactly
  # when the sampler degrades. Only delta_A is scored; sum-to-zero makes
  # delta_B its exact negative.

  # Convergence gate: an aligned chain's delta has SD 0.011-0.024, a stuck one
  # 0.08-0.31, so without this the agreement check can compare two wanderers.
  spread <- max(stats::sd(draws_r), stats::sd(draws_cpp))
  expect_lt(spread, 0.05)

  expect_lt(abs(mean(draws_r) - mean(draws_cpp)), 0.05)   # worst measured 0.0043

  # Ground truth, which nothing else in this file pins: an offset of 1.5 across
  # two single-site groups is +-0.75 under sum-to-zero, so a scale error shared
  # by both engines survives every other check here. Worst measured error 0.016,
  # and that residual is prior shrinkage, not Monte Carlo noise.
  expect_lt(abs(mean(draws_r)   + 0.75), 0.05)
  expect_lt(abs(mean(draws_cpp) + 0.75), 0.05)
})

# ══════════════════════════════════════════════════════════════════════════════
# 11. Continued run preserves delta/tau (P0 regression test)
# ══════════════════════════════════════════════════════════════════════════════

test_that("Continued C++ run preserves delta/tau from first run", {
  skip_on_cran()

  set.seed(9314)
  dat <- .make_offset_data()
  d <- StratData(signal = dat$signal, group = dat$group)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, signalOffsets = TRUE,
                  sigmaFixed = FALSE)

  td <- file.path(tempdir(), "offcont")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  nIter1 <- 100L
  # tempering = FALSE: the read-side pin below compares the first continued
  # row (stored AFTER one sweep) to the handover, so an accepted chain swap in
  # that sweep replaces the cold chain's state wholesale and fails it. The
  # 0.2.5 finite-top ladder makes such swaps common; the continuation
  # inherits this setting from the checkpoint.
  post1 <- suppressWarnings(RunStratModel(
    stratObject = d, stratModel = m,
    nIter = nIter1, nChains = 2, nRun = 1, seed = 42L, nThreads = 1L,
    tempering = FALSE,
    engine = "cpp", quiet = TRUE, modelDir = td, modelName = "offcont"
  ))

  s1 <- post1[["samples"]]
  pnames <- dimnames(s1)[[2]]
  delta_cols <- grep("^delta_", pnames, value = TRUE)
  tau_cols   <- grep("^tau_", pnames, value = TRUE)
  metro_cols <- c("alpha_site_2", "gammaLog_site_2")
  last_row <- s1[dim(s1)[1], , 1, 1]
  expect_true(any(abs(last_row[delta_cols]) > 0.01),
              info = "First run's last stored deltas should be non-zero")

  # Write side. A post-continuation delta SAMPLE cannot pin the handover --
  # delta is redrawn from its full conditional every sweep with no dependence
  # on its previous value -- so pin the handover value itself.
  ckpt <- readRDS(file.path(td, "offcont_mcmc_run_1.rds"))
  Handover <- function(what) unname(unlist(ckpt[["recentState"]][[1]][["gibbs"]][[what]]))
  expect_equal(Handover("delta"), unname(last_row[delta_cols]))
  expect_equal(Handover("tau"),   unname(last_row[tau_cols]))

  # Continued run from posterior
  post2 <- suppressWarnings(RunStratModel(
    stratObject = post1, stratModel = m,
    nIter = 50, nChains = 2, nRun = 1, nThreads = 1L,
    engine = "cpp", quiet = TRUE
  ))

  s2 <- post2[["samples"]]
  pnames2 <- dimnames(s2)[[2]]
  expect_true(all(delta_cols %in% pnames2))

  iters <- as.numeric(dimnames(s2)[[1]])
  idx_cont <- which(iters == nIter1 + 1L)
  expect_true(length(idx_cont) == 1L)
  expect_true(any(abs(s2[idx_cont, delta_cols, 1, 1]) > 0.01))

  # Read side. The metro parameters are NOT redrawn each sweep, so the first
  # continued row reports the handed-over state itself: measured agreement is
  # 1e-15 over six seeds, and a continuation that ignored recentState lands
  # tens of units away.
  expect_equal(unname(s2[idx_cont, metro_cols, 1, 1]),
               unname(last_row[metro_cols]), tolerance = 1e-8)

  # The continuation rewrites the same checkpoint, and has to carry its own
  # final delta forward on the same terms or a third run starts from stale
  # state.
  ckpt2 <- readRDS(file.path(td, "offcont_mcmc_run_1.rds"))
  expect_equal(unname(unlist(ckpt2[["recentState"]][[1]][["gibbs"]][["delta"]])),
               unname(s2[dim(s2)[1], delta_cols, 1, 1]))
})

# ══════════════════════════════════════════════════════════════════════════════
# 12. offsetPriorScale validation
# ══════════════════════════════════════════════════════════════════════════════

test_that("offsetPriorScale rejects invalid values", {
  grp <- data.frame(site = c("site1", "site2"),
                     group = c("A", "B"),
                     stringsAsFactors = FALSE)
  d <- StratData(signal = signalData0, group = grp)

  expect_error(
    StratModel(d, priors = NULL, alignmentScale = "height",
               sedModel = "site", nKnots = 10, signalOffsets = TRUE,
               offsetPriorScale = -1),
    "positive scalar"
  )

  expect_error(
    StratModel(d, priors = NULL, alignmentScale = "height",
               sedModel = "site", nKnots = 10, signalOffsets = TRUE,
               offsetPriorScale = c(1, 2)),
    "positive scalar"
  )
})
