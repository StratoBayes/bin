# Tests for R-engine proposer functions (R/proposerFunctions.R) that are not
# already covered via their C++ counterparts in test-cpp-propose.R.

test_that("RT-264: ProposeShiftAlphasRandJoint no-ops when all alphas are Fixed", {
  # nFree = 0 previously crashed via sample.int(0, size = 1) ("invalid first
  # argument"). The fix must return parameters unchanged instead of erroring.
  model <- list(
    ind = list(alphaNotFixed = integer(0), alpha = 1:3),
    parametersLength = 5
  )
  params <- c(1, 2, 3, 4, 5)

  expect_no_error(
    result <- StratoBayes:::.ProposeShiftAlphasRandJoint(
      n = 1, parameters = params, proposeArg = NULL, proposalFactor = 1,
      dimFactor = 1, model = model, alphaShift = 1
    )
  )
  expect_equal(result, params)
})

test_that("RT-264: ProposeShiftAlphasRandSeparate no-ops when all alphas are Fixed", {
  model <- list(
    ind = list(alphaNotFixed = integer(0), alpha = 1:3),
    parametersLength = 5
  )
  params <- c(1, 2, 3, 4, 5)

  expect_no_error(
    result <- StratoBayes:::.ProposeShiftAlphasRandSeparate(
      n = 1, parameters = params, proposeArg = NULL, proposalFactor = 1,
      dimFactor = 1, model = model, alphaShift = 1
    )
  )
  expect_equal(result, params)
})

test_that("RT-264: ProposeShiftAlphasRandJoint still proposes when some alphas are free", {
  model <- list(
    ind = list(alphaNotFixed = c(1L, 3L), alpha = 1:3),
    parametersLength = 5
  )
  params <- c(1, 2, 3, 4, 5)

  set.seed(1)
  result <- StratoBayes:::.ProposeShiftAlphasRandJoint(
    n = 1, parameters = params, proposeArg = NULL, proposalFactor = 1,
    dimFactor = 1, model = model, alphaShift = 1
  )
  expect_false(isTRUE(all.equal(result, params)))
})
