test_that("SiteBlock proposal is registered and initialised for site sedModel", {
  model <- stratModel1
  mcmc <- StratMCMC(stratModel = model, nIter = 100, nChains = 4, nThreads = 2L)

  expect_true("SiteBlock" %in% names(mcmc$propose))
  sb_idx <- which(names(mcmc$propose) == "SiteBlock")
  expect_length(sb_idx, 1)

  # Valid from start
  expect_true(mcmc$metro$proposalValid[1, sb_idx])

  # Check block structure: stratModel1 has 2 sites (height-scale)
  arg <- mcmc$metro$proposalArgs$chain1[[sb_idx]]
  expect_true(!is.null(arg$blocks))
  expect_equal(length(arg$blocks), 2)

  # Each block should have 2 indices (alpha, gamma)
  expect_equal(sort(arg$blocks[[1]]$indices), c(1L, 3L))
  expect_equal(sort(arg$blocks[[2]]$indices), c(2L, 4L))

  # Fallback SDs positive
  expect_true(all(arg$blocks[[1]]$fallbackSD > 0))
  expect_true(all(arg$blocks[[2]]$fallbackSD > 0))
})

test_that("SiteBlock blocks for age-scale model with 3 sites", {
  model <- stratModel2
  mcmc <- StratMCMC(stratModel = model, nIter = 100, nChains = 4, nThreads = 2L)

  sb_idx <- which(names(mcmc$propose) == "SiteBlock")
  arg <- mcmc$metro$proposalArgs$chain1[[sb_idx]]

  expect_equal(length(arg$blocks), 3)
  # Alpha indices 1,2,3 paired with gamma indices 4,5,6
  expect_equal(sort(arg$blocks[[1]]$indices), c(1L, 4L))
  expect_equal(sort(arg$blocks[[2]]$indices), c(2L, 5L))
  expect_equal(sort(arg$blocks[[3]]$indices), c(3L, 6L))
})

test_that("SiteBlock uses single block for partition models", {
  model <- stratModel4
  mcmc <- StratMCMC(stratModel = model, nIter = 100, nChains = 4, nThreads = 2L)

  sb_idx <- which(names(mcmc$propose) == "SiteBlock")
  arg <- mcmc$metro$proposalArgs$chain1[[sb_idx]]

  # Partition model: all alpha+gamma in one block
  expect_equal(length(arg$blocks), 1)
  expect_true(all(c(model$ind$alpha, model$ind$gamma) %in%
                    arg$blocks[[1]]$indices))
})

test_that("SiteBlock proposal generates valid perturbations", {
  model <- stratModel1
  nParam <- model$parametersLength

  # Build proposeArg manually
  blocks <- list(
    list(indices = c(1L, 3L), chol = NULL, fallbackSD = c(0.5, 0.1)),
    list(indices = c(2L, 4L), chol = NULL, fallbackSD = c(0.5, 0.1))
  )
  proposeArg <- list(blocks = blocks)
  params <- c(10, 20, -0.5, 0.3)

  set.seed(6284)
  proposed <- .ProposeSiteBlock(
    n = 1, parameters = params, proposeArg = proposeArg,
    proposalFactor = 1, dimFactor = 1, model = model
  )

  expect_length(proposed, nParam)
  expect_false(all(proposed == params))
})

test_that("SiteBlock with Cholesky respects correlation", {
  model <- stratModel1
  nParam <- model$parametersLength

  # Build a block with strong positive correlation
  sigma <- matrix(c(1, 0.9, 0.9, 1), 2, 2)
  cholFac <- t(chol(sigma))

  blocks <- list(
    list(indices = c(1L, 3L), chol = cholFac, fallbackSD = c(0.5, 0.5)),
    list(indices = c(2L, 4L), chol = NULL, fallbackSD = c(0.5, 0.5))
  )
  proposeArg <- list(blocks = blocks)
  params <- c(10, 20, -0.5, 0.3)

  set.seed(4591)
  n <- 500
  deltas <- matrix(NA, n, 2)
  for (i in seq_len(n)) {
    proposed <- .ProposeSiteBlock(
      n = 1, parameters = params, proposeArg = proposeArg,
      proposalFactor = 1, dimFactor = 1, model = model
    )
    deltas[i, ] <- proposed[c(1, 3)] - params[c(1, 3)]
  }

  # Perturbations to block 1 (indices 1,3) should be correlated
  r <- cor(deltas[, 1], deltas[, 2])
  expect_gt(r, 0.7)
})

test_that("SiteBlock integrates into full model run", {
  skip_on_cran()

  data <- stratData1
  model <- stratModel1
  mcmc <- StratMCMC(stratModel = model, nIter = 200, nChains = 4, nThreads = 2L)

  post <- RunStratModel(data, model, mcmc, quiet = TRUE, nRun = 1)

  sb_idx <- which(names(mcmc$propose) == "SiteBlock")
  prop_nums <- post$samples[, "proposal_number", 1, 1]
  expect_true(sb_idx %in% prop_nums)
})
