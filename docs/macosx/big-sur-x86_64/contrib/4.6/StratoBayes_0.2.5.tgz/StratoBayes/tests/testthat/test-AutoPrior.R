
# StratData0
# StratModelTemplate(stratData0)
r1 <- range(SignalLookUp(stratData0, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData0, type = "height", site = 2))
d2 <- diff(r2)

min_i <- r1[1] - d2
max_i <- r1[2] + d2

sd_i <- (max_i - min_i) / (2 * 1.96)

alphaPositionSite <- .MatchAlphaPosition(c(NA, "middle"),
                                         stratData0, "height")[2]

# relative position within site 2
relAlphaPos <- (alphaPositionSite - r2[1]) / (r2[2] - r2[1])

# same relative position mapped into reference section
m_i <- r1[1] + diff(r1) * relAlphaPos


prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
  class = c("StratPrior", "list"))
attr(prior0a, "alphaPosition") <- .MatchAlphaPosition("middle", stratData0,
                                                       "height", toNumeric = TRUE)

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     customPriors = NULL)

test_that("AutoPrior() creates the correct priors", {
  expect_equal(prior0a, prior0b)
})

# custom prior
gammaPrior <- NormalPrior(mean = 0, sd = 3)
prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = 3)),
  class = c("StratPrior", "list"))
attr(prior0a, "alphaPosition") <- .MatchAlphaPosition("middle", stratData0,
                                                       "height", toNumeric = TRUE)

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     customPriors = list(gammaLog_site2 = gammaPrior))

test_that("AutoPrior() creates the correct priors with added custom prior", {
  expect_equal(prior0a, prior0b)
})

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData2, type = "height", site = 2))
r3 <- range(SignalLookUp(stratData2, type = "height", site = 3))

d2 <- diff(r2)
d3 <- diff(r3)

min_2 <- r1[1] - d2
max_2 <- r1[2] + d2
min_3 <- r1[1] - d3
max_3 <- r1[2] + d3


sd_2 <- (max_2 - min_2) / (2 * 1.96)
sd_3 <- (max_3 - min_3) / (2 * 1.96)

alphaPositions <-  c(10, 20, 0)

relAlphaPos2 <- (alphaPositions[2] - r2[1]) / (r2[2] - r2[1])
relAlphaPos3 <- (alphaPositions[3] - r3[1]) / (r3[2] - r3[1])

m_2 <- r1[1] + diff(r1) * relAlphaPos2
m_3 <- r1[1] + diff(r1) * relAlphaPos3

prior2a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_2, sd = sd_2),
  "alpha_site3" = NormalPrior(mean = m_3, sd = sd_3),
  "gammaLog_part 2.1" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 2.2" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 3.1" = NormalPrior(mean = 0, sd = log(2)),
  "gap_site2_1" = ExponentialPrior(rate = 4 / diff(r1))),
  class = c("StratPrior", "list"))
attr(prior2a, "alphaPosition") <- .MatchAlphaPosition(alphaPositions, stratData2,
                                                       "height", toNumeric = TRUE)
prior2b <- AutoPrior(stratData = stratData2,
                     alignmentScale = "height",
                     sedModel = "p",
                     alphaPosition = alphaPositions,
                     customPriors = NULL,
                     delta_rate = NULL)
test_that("AutoPrior() creates the correct priors for stratData2", {
  expect_equal(prior2a, prior2b)
})

# bulk overwrite sd / rates of prior parameters

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData2, type = "height", site = 2))
r3 <- range(SignalLookUp(stratData2, type = "height", site = 3))

d2 <- diff(r2)
d3 <- diff(r3)

min_2 <- r1[1] - d2
max_2 <- r1[2] + d2
min_3 <- r1[1] - d3
max_3 <- r1[2] + d3


sd_2 <- (max_2 - min_2) / (2 * 1.96)
sd_3 <- (max_3 - min_3) / (2 * 1.96)

alphaPositions <-  c(10, 20, 0)

relAlphaPos2 <- (alphaPositions[2] - r2[1]) / (r2[2] - r2[1])
relAlphaPos3 <- (alphaPositions[3] - r3[1]) / (r3[2] - r3[1])

m_2 <- r1[1] + diff(r1) * relAlphaPos2
m_3 <- r1[1] + diff(r1) * relAlphaPos3


prior2a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_2, sd = 7),
  "alpha_site3" = NormalPrior(mean = m_3, sd = 7),
  "gammaLog_part 2.1" = NormalPrior(mean = 0, sd = 3),
  "gammaLog_part 2.2" = NormalPrior(mean = 0, sd = 4),
  "gammaLog_part 3.1" = NormalPrior(mean = 0, sd = 3),
  "zetaLog_site3" = NormalPrior(mean = 0, sd = 1),
  "gap_site2_1" = ExponentialPrior(rate = 0.1)),
  class = c("StratPrior", "list"))
attr(prior2a, "alphaPosition") <- .MatchAlphaPosition(alphaPositions, stratData2,
                                                       "height", toNumeric = TRUE)

customGammaLog_part_2.2 <- NormalPrior(mean = 0, sd = 4)
prior2b <- AutoPrior(stratData = stratData2,
                     alignmentScale = "height",
                     sedModel = "s x p",
                     alphaPosition = alphaPositions,
                     alpha_sd = 7,
                     gammaLog_sd = 3,
                     zetaLog_sd = 1,
                     delta_rate = 0.1,
                     customPriors = list('gammaLog_part 2.2' = customGammaLog_part_2.2))
test_that("AutoPrior() creates the correct priors for stratData2 with bulk overwrites", {
  expect_equal(prior2a, prior2b)


  model2b <- StratModel(stratData2, priors = prior2b, alphaPosition = alphaPositions,
                     alignmentScale = "height", sedModel =  "s x p")

  expect_equal(round(model2b$alphaPosition), c(NA, 20, 0))
})


# RT-025 / RT-182: a site whose signal heights are all identical has
# hi[2] - hi[1] == 0, so `relAlphaPos` divides by zero and AutoPrior() used to
# silently build a NormalPrior(mean = NaN) that freezes the MCMC chain later
# (every logPrior evaluates to NaN/-Inf) instead of failing at construction
# time.
test_that("AutoPrior() errors clearly on a site with zero height range", {
  degenerateData <- data.frame(
    site   = rep(c("site1", "site2"), c(10, 5)),
    height = c(seq(0, 9, length.out = 10), rep(3, 5)),
    value  = rnorm(15)
  )
  degenerateStrat <- StratData(degenerateData)

  expect_error(
    AutoPrior(stratData = degenerateStrat,
             alignmentScale = "height",
             sedModel = "site"),
    regexp = "zero height range"
  )
})

# RT-026 / RT-183: the *reference* site (site 1, not a correlated site) with
# all-identical signal heights has diff(h1) == 0. Before the fix, this
# silently produced gap_i ~ ExponentialPrior(rate = 4 / diff(h1) = Inf) --
# passes the rate > 0 guard, but assigns all probability mass to exactly 0,
# silently disallowing every stratigraphic gap with no error. It would also
# NaN-poison the alpha_i mean/sd computation, which is keyed off the same
# h1 range. Both are the same root cause as RT-025/RT-182 (division by a
# zero-width height range) but at the reference-site call site instead of a
# correlated site.
test_that("AutoPrior() errors clearly on a zero-range reference site (RT-026/RT-183)", {
  degenerateData <- data.frame(
    site   = rep(c("site1", "site2"), c(5, 10)),
    height = c(rep(3, 5), seq(0, 9, length.out = 10)),
    value  = rnorm(15)
  )
  degenerateStrat <- StratData(degenerateData)

  expect_error(
    AutoPrior(stratData = degenerateStrat,
             alignmentScale = "height",
             sedModel = "site"),
    regexp = "zero height range"
  )
})

# test_that("AutoPrior() gives correct alpha priors for the no-overlap case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(2, 4, length.out = n1)
#   h2 <- seq(0, 0.1, length.out = n2)
#
#   testdata8a <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8a)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean) == 3)
#
#   smod1 <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod1$alphaPosition, 2), c(NA, 0.05))
#
#   smod2 <- StratModel(sdat, priors = NULL,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod2$alphaPosition, 2), c(NA, 0.05))
#
#
# })
#
# test_that("AutoPrior() gives correct alpha priors for the partial-overlap case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(0,   1.0, length.out = n1)
#   h2 <- seq(0.9, 2.4, length.out = n2)
#
#   testdata8b <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8b)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean, 2) == 0.95)
#
#   smod <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod$alphaPosition, 2), c(NA, 0.95))
#
# })
#
# test_that("AutoPrior() gives correct alpha priors for full overlap case", {
#
#   set.seed(1)
#   n1 <- 30
#   n2 <- 25
#
#   h1 <- seq(0,   1.0, length.out = n1)
#   h2 <- seq(-1, 2.5, length.out = n2)
#
#   testdata8b <- data.frame(
#     height = c(h1, h2),
#     value  = c(rnorm(n1) +  4 * h1,
#                (rnorm(n2) +  3 * (h1[1:n2] + h2)) - 8),
#     site   = c(rep("A", n1), rep("B", n2))
#   )
#
#   sdat  <- StratData(testdata8b)
#   apr   <- AutoPrior(sdat)
#
#   expect_true(round(apr$alpha_B$args$mean, 1) == 0.5)
#
#   smod <- StratModel(sdat, priors = apr,
#                      alignmentScale = "height", sedModel = "site")
#
#   expect_equal(round(smod$alphaPosition, 1), c(NA, 0.5))
#
# })

# #93: `priors` defaults to NULL, so omitting it entirely (not just passing
# NULL) routes through AutoPrior() on the height scale.
test_that("StratModel() builds automatic priors when `priors` is omitted", {
  omitted <- StratModel(stratData = stratData0, alignmentScale = "height",
                        sedModel = "site", nKnots = 5)
  explicit <- StratModel(stratData = stratData0, priors = NULL,
                         alignmentScale = "height", sedModel = "site",
                         nKnots = 5)
  omittedPriors <- omitted[["priors"]][["metro"]]
  explicitPriors <- explicit[["priors"]][["metro"]]

  # Compare content, not the objects: prior name vectors carry a `.match.hash`
  # attribute that defeats a whole-object comparison.
  expect_equal(as.character(names(omittedPriors)),
               as.character(names(explicitPriors)))
  expect_equal(lapply(omittedPriors, `[[`, "args"),
               lapply(explicitPriors, `[[`, "args"))

  # The age scale has no automatic priors, so omission must still error.
  expect_error(
    StratModel(stratData = stratData0, alignmentScale = "age",
               sedModel = "site", nKnots = 5),
    "'priors' must be provided"
  )
})
