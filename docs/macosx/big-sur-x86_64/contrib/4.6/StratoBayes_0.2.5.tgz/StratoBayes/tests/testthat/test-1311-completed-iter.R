# #1311: `completedIter` is recomputed from each run's saved samples,
# discarding any row containing a non-finite value (the last-usable-row
# semantics `.CompleteSampleRows()` and every downstream consumer rely on --
# `StratMCMC()` continuation, `.CompletedRowIndex()`'s burn-in arithmetic and
# the resume recompute in `RunStratModel()` all resume/summarise from the
# last CLEAN saved row, never the last WRITTEN one). When that recount drops
# below the checkpoint's own tracked progress, the drop was previously
# silent: nothing told the user their run only has 1 usable sample even
# though the sampler visibly ran to completion and wrote every row (as
# happened, via a different route, in #1298).
#
# This does not change what `completedIter` reports -- only whether the user
# is told when it disagrees with the checkpoint.

test_that("StratPosterior warns when completedIter under-reports a completed run (#1311)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- withr::local_tempdir()
  modelName <- "sb1311"
  nIter <- 20L

  set.seed(1)
  RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = nIter, nChains = 2L, seed = 1, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = modelName, engine = "cpp", runParallel = FALSE,
    nThreads = 2L
  )

  binPath <- file.path(td, paste0(modelName, "_binarysamples_run_1.rds"))
  expect_true(file.exists(binPath))
  raw <- readRDS(binPath)

  # Poison every saved row of chain 1 (the cold chain -- the only one saved
  # by default) after the first: the run genuinely wrote every row (the
  # checkpoint below confirms it), but only row 1 is now numerically usable.
  paramCol <- setdiff(colnames(raw), c("iteration", "chain"))[1]
  chain1Rows <- which(raw[, "chain"] == 1 & raw[, "iteration"] > 1)
  expect_gt(length(chain1Rows), 0L)
  raw[chain1Rows, paramCol] <- NaN
  saveRDS(raw, binPath, compress = FALSE)

  mcmc1 <- readRDS(file.path(td, paste0(modelName, "_mcmc_run_1.rds")))
  model <- readRDS(file.path(td, paste0(modelName, "_model.rds")))
  # The run really did finish -- this is the checkpoint's own tracked
  # progress, independent of the (now-poisoned) saved sample content.
  expect_equal(mcmc1[["completedIter"]], nIter)

  expect_warning(
    post <- StratPosterior(readDir = td, modelName = modelName,
                           stratData = stratData1, stratModel = model),
    "reached iteration"
  )

  # completedIter correctly reports "1 usable row", not "20 written rows" --
  # asserted against the checkpoint's own record of what was actually
  # written, not merely checked for positivity.
  expect_equal(post[["mcmcSummary"]][["completedIter"]][1], 1)
  expect_equal(mcmc1[["completedIter"]], nIter)
})

test_that("StratPosterior does not warn for a clean, fully-completed run (#1311)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- withr::local_tempdir()
  modelName <- "sb1311clean"
  nIter <- 20L

  set.seed(1)
  post <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = nIter, nChains = 2L, seed = 1, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = modelName, engine = "cpp", runParallel = FALSE,
    nThreads = 2L
  )

  expect_no_warning(
    StratPosterior(readDir = td, modelName = modelName,
                   stratData = stratData1, stratModel = post[["model"]])
  )

  mcmc1 <- readRDS(file.path(td, paste0(modelName, "_mcmc_run_1.rds")))
  lastSaved <- max(mcmc1[["saveIter"]])
  expect_equal(post[["mcmcSummary"]][["completedIter"]][1], lastSaved)
})

# The checkpoint is an ITERATION COUNT; `completeIter` is a saved-row LABEL
# drawn from `saveIter`, so the two only coincide when the checkpoint itself
# lands on a scheduled save. `nThin` not dividing `nIter` evenly is the
# simplest way to pull them apart on an otherwise perfectly healthy run --
# without rebasing the checkpoint onto the last reachable save point, this
# alone would trip the #1311 warning on a run with nothing wrong.
test_that("StratPosterior does not warn when nThin leaves the checkpoint off a save point (#1311)", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- withr::local_tempdir()
  modelName <- "sb1311nthin"
  nIter <- 20L
  nThin <- 3L

  set.seed(1)
  post <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = nIter, nChains = 2L, nThin = nThin, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = modelName, engine = "cpp",
    runParallel = FALSE, nThreads = 2L
  )

  mcmc1 <- readRDS(file.path(td, paste0(modelName, "_mcmc_run_1.rds")))
  # Confirms this run actually exercises the mismatch: the checkpoint (an
  # iteration count) does not itself land on a scheduled save.
  expect_false(mcmc1[["completedIter"]] %in% mcmc1[["saveIter"]])

  expect_no_warning(
    StratPosterior(readDir = td, modelName = modelName,
                   stratData = stratData1, stratModel = post[["model"]])
  )

  lastSaved <- max(mcmc1[["saveIter"]])
  expect_equal(post[["mcmcSummary"]][["completedIter"]][1], lastSaved)
})
