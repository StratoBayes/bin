# Degenerate and extreme inputs reaching the standalone Bayesian spline's Gibbs
# sampler, and the scale hygiene of the priors it is handed
# (GH #1135, #1136, #1137, #1138, #1139, #1141, #1273, #1274). Each of these
# used either to run to completion on nonsense or to die several layers from
# the argument that caused it.

test_that("a constant or single-point signal gets a positive bSigma (#1135)", {
  # 0.01 * n * var(x) is exactly 0 for a constant signal and NA for one point;
  # min() then carries that through, and a zero rate lets sigma collapse to
  # ~1e-15 over a few hundred Gibbs iterations with no warning.
  expect_identical(.bSigmaScaled(rep(5, 10)), 0.01)
  expect_identical(.bSigmaScaled(3), 0.01)
  # the scaled branch is untouched
  set.seed(1135)
  y <- rnorm(20)
  expect_identical(.bSigmaScaled(y), min(0.01, 0.01 * 20 * var(y)))

  # StratModel() passes the computed value on explicitly, so BayesianSpline()'s
  # own is.null() guard never sees it -- which is how a 0 reached the sampler.
  # Pre-fix this chain sat at ~1e-15, which is positive: assert a real floor.
  bs <- BayesianSpline(x = seq(0, 1, length.out = 12), y = rep(2, 12),
                       nKnots = 4, nIter = 30,
                       bSigma = .bSigmaScaled(rep(2, 12)))
  expect_gt(min(bs[["sigma"]]), 1e-6)
})

test_that(".sb_gibbs rejects a non-positive bSigma_prior (#1135)", {
  p <- 3L
  args <- list(H_list = list(diag(p)), tBy_list = list(rep(1, p)),
               B_list = list(matrix(1, 1, p)), signalValuesVec = list(1),
               sigma_in = 1, lambda_in = 1, D_mat = diag(p),
               Q_fallback = list(diag(p)), aLambda = 1, bLambda = 1,
               shapeSigma = 1, bSigma_prior = 1, numBasis = p,
               sigmaIsFixed = TRUE, sigmaFixedValues = 1)
  expect_type(do.call(.sb_gibbs, args), "list")
  expect_error(do.call(.sb_gibbs, modifyList(args, list(bSigma_prior = 0))),
               "bSigma_prior must be finite and positive")
  expect_error(do.call(.sb_gibbs, modifyList(args, list(bSigma_prior = NA_real_))),
               "bSigma_prior must be finite and positive")
  expect_error(do.call(.sb_gibbs, modifyList(args, list(bSigma_prior = c(1, 1)))),
               "bSigma_prior must have one value per signal")
})

test_that("bLambda is raised only where it caps lambda below scale (#1136)", {
  set.seed(1136)
  y <- rnorm(50)
  # `bLambda` caps the conjugate posterior scale, so this is the largest mean
  # lambda can take.
  ceiling <- function(sb, bLambda, aLambda = 1) {
    (aLambda + (sb[["num_basis"]] - 2) / 2) * bLambda
  }
  # tr(D) ~ 1 / span^3, so a tiny penalty trace is the large-span regime in
  # which the #551 floor overtakes that ceiling.
  tinyD <- list(D = diag(8) * 1e-12, num_basis = 10L)
  base <- list(D = diag(8), num_basis = 10L)

  floorTiny <- .LambdaFloor(tinyD, list(y))
  expect_gt(floorTiny, ceiling(tinyD, 1000))
  raised <- .BLambdaAboveScale(1000, 1, tinyD[["num_basis"]], floorTiny)
  expect_gt(ceiling(tinyD, raised), floorTiny)

  # A scale whose ceiling still clears the healthy lambda keeps the absolute
  # default: `sb_lambda.h`'s floor calibration was measured under it. Here the
  # ceiling is ~4e3 times that scale, so the fixture is not near the boundary.
  floorBase <- .LambdaFloor(base, list(y))
  expect_gt(ceiling(base, 1000), floorBase / .LambdaFloorRel)
  expect_identical(.BLambdaAboveScale(1000, 1, base[["num_basis"]], floorBase),
                   1000)

  # per-signal, so one colliding signal does not move the others
  perSignal <- .BLambdaAboveScale(c(1000, 1000), c(1, 1), 10L,
                                  c(floorBase, floorTiny))
  expect_identical(perSignal[[1]], 1000)
  expect_gt(perSignal[[2]], 1000)

  # End to end, on data whose scale is nowhere near the collision: the default
  # must be untouched, and must not become a draw from the ambient RNG (the
  # flexible-knot `D` that `.LambdaFloor` reads is itself RNG-drawn).
  model <- StratModel(stratData1, stratPrior1, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "middle",
                      nKnots = 8, sigmaFixed = TRUE)
  gibbs <- model[[c("priors", "gibbs")]]
  expect_true(all(gibbs[["bLambda"]] == 1000))
  expect_true(all(gibbs[["lambdaMin"]] <
                    (gibbs[["aLambda"]] +
                       (model[[c("splineBase", "num_basis")]] - 2) / 2) *
                    gibbs[["bLambda"]]))

  # An explicit value is the caller's, collision or not.
  userModel <- StratModel(stratData1, stratPrior1, alignmentScale = "height",
                          sedModel = "site", alphaPosition = "middle",
                          nKnots = 8, sigmaFixed = TRUE, bLambda = 7)
  expect_true(all(userModel[[c("priors", "gibbs", "bLambda")]] == 7))
})

test_that("a degenerate spline range is named at input (#1137, #1273)", {
  set.seed(1137)
  x <- seq(0, 8, length.out = 30)
  y <- sin(x) + rnorm(30, 0, 0.2)

  # reversed bounds (#1137): used to reach the first Gibbs iteration and blame
  # nKnots for an unfactorisable precision matrix
  expect_error(BayesianSpline(x, y, nKnots = 6, nIter = 5,
                              xMin = 8, xMax = 0),
               "spline range must be increasing")
  # constant x (#1273): used to die inside splines with "empty 'derivs'"
  expect_error(BayesianSpline(rep(5, 10), y[1:10], nKnots = 6, nIter = 5),
               "spline range must be increasing")
  expect_error(BayesianSpline(x, y, nKnots = 6, nIter = 5,
                              xMin = 4, xMax = 4),
               "spline range must be increasing")
  # an explicit collapsed knot vector reaches the same dead end
  expect_error(BayesianSpline(x, y, knots = rep(3, 6), nIter = 5),
               "must span a positive range")
  # a valid range is unaffected
  expect_type(BayesianSpline(x, y, nKnots = 6, nIter = 5), "list")
})

test_that("lambdaInitial no longer sets the smooth.spline tuning value (#1138)", {
  set.seed(1138)
  x <- seq(0, 8, length.out = 60)
  y <- sin(x) + rnorm(60, 0, 0.2)
  data <- data.frame(x = x, y = y)

  m <- .ModelBspline(data, nKnots = 10, knots = NULL, aSigma = 0.01,
                     bSigma = NULL, aLambda = 1, bLambda = 1000,
                     lambdaInitial = 1e10, lambdaFixed = FALSE,
                     xMin = NULL, xMax = NULL)
  expect_identical(m[[c("initialValues", "lambda")]], 1e10)
  expect_identical(m[[c("initialValues", "lambdaTune")]], 1e-4)

  # smooth.spline() errors above ~1e9, which the documented default formula for
  # lambdaInitial can itself reach, and .InitializeGibbsBspline does not catch.
  expect_type(BayesianSpline(x, y, nKnots = 10, nIter = 10,
                             lambdaInitial = 1e10), "list")
})

test_that("a non-finite y cannot produce a silent all-NaN chain (#1139)", {
  set.seed(1139)
  x <- seq(0, 8, length.out = 40)
  y <- sin(x) + rnorm(40, 0, 0.2)
  yInf <- y
  yInf[10] <- Inf

  fit <- BayesianSpline(x, yInf, nKnots = 6, nIter = 30)
  expect_false(anyNA(fit[["beta"]]))
  expect_true(all(is.finite(fit[["lambda"]])))
  expect_true(all(is.finite(fit[["sigma"]])))
  # the offending observation is dropped, exactly as an NA already was
  expect_equal(fit[[c("model", "shapeSigma")]],
               BayesianSpline(x[-10], y[-10], nKnots = 6,
                              nIter = 5)[[c("model", "shapeSigma")]])

  expect_error(BayesianSpline(c(1, 2), c(Inf, NA), nKnots = 3, nIter = 5),
               "no pair of finite values")
})

test_that("PredictSpline leaves the caller's RNG stream alone (#1141)", {
  set.seed(1141)
  x <- seq(0, 8, length.out = 40)
  y <- sin(x) + rnorm(40, 0, 0.2)
  # > 1000 stored iterations post-burn-in, so the sample() cap actually fires
  fit <- BayesianSpline(x, y, nKnots = 6, nIter = 2100)
  expect_gt(sum(seq(1, fit[["nIter"]], fit[["nThin"]]) > fit[["nIter"]] / 2),
            1000)

  set.seed(42)
  before <- runif(3)
  set.seed(42)
  invisible(PredictSpline(fit, at = x))
  expect_identical(runif(3), before)

  # and with no stream to begin with, none is left behind
  savedSeed <- get(".Random.seed", envir = .GlobalEnv)
  rm(".Random.seed", envir = .GlobalEnv)
  invisible(PredictSpline(fit, at = x))
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
  assign(".Random.seed", savedSeed, envir = .GlobalEnv)
})

test_that(".CreateSplineS returns no stray unnamed element (#1274)", {
  model <- StratModel(stratData1, stratPrior1, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "middle",
                      nKnots = 8, sigmaFixed = TRUE)
  splineBase <- model[["splineBase"]]
  expect_false(any(names(splineBase) == ""))
  expect_false(any(vapply(splineBase, is.null, logical(1))))
})
