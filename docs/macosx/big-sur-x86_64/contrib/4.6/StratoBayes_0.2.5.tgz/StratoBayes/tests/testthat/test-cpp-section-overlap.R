# Regression pin for the C++ ENGINE's section-overlap computation.
#
# The overlap algorithm is implemented TWICE in C++:
#
#   * `sectionOverlapCpp` (src/FindMaxSect.cpp), reached from R as
#     `.SectionOverlapCpp` / `.SectionOverlap` and used by the R engine.
#     tests/testthat/test-SectionOverlap.R covers this one.
#   * `compute_section_overlap` (src/MCMCEngine.cpp), a `static` inline copy
#     used by the C++ engine.  It shares NOTHING with the above: the engine's
#     `sectionOverlapFn` R-callback field is dead (constructed as "identity",
#     never invoked), so nothing in the engine path re-enters R or FindMaxSect.
#     Nothing else covers it.
#
# Observation point.  `.sb_eval_logpost(engine, chain, params, debug = TRUE)`
# copies the chain state, sets `params`, runs age conversion, then calls
# `refresh_overlap` -> `compute_section_overlap` before assembling the
# log-posterior.  Component 4 of the returned `logPostSep` is
# `sum(adjustments[[m]][overlap])` over every signal observation, and the same
# call returns the `signalFlat` ages the overlap was computed from.  Everything
# here is therefore evaluated at FIXED parameters — no MCMC value is asserted.
#
# Making a scalar carry the whole answer.  `adjustments[[m]]` is indexed by the
# overlap count, so setting it to `1000^(0:(S - 1))` turns component 4 into a
# base-1000 encoding of the histogram of overlap counts for signal `m` (counts
# per bucket are < 1000 here, and the total stays far below 2^53, so the
# encoding is exact and decodes uniquely).  A single datum's count changing
# moves two digits.
#
# Non-vacuity.  The `signalSectionOverlap` imported into the engine is poisoned
# to all-1s beforehand.  `compute_section_overlap` overwrites it in full, so a
# match with the oracle can only arise from the engine having run; delete or
# no-op that function and the poisoned 1s reach component 4 instead.  The final
# block below asserts both halves of that.
#
# Deliberately NOT skip_on_cran: at ~2 s this is cheap enough to gate every PR,
# which is the point of a regression pin.  Nothing here asserts a value the
# setup run produced — only relations the engine must satisfy at fixed
# parameters.
#
# Oracle.  Derived from the DEFINITION, not from either implementation: a
# datum's overlap is the number of non-empty sections whose [min, max] age range
# contains it.  The engine instead maximises an interval-wise count over the
# intervals containing the datum; the two agree, which is what makes this a real
# cross-check rather than a restatement.

# ── Fixture ──────────────────────────────────────────────────────────────────
#
# Engineered so the sorted-bounds array hits the cases a binary-search lookup
# can get wrong.  For signal `sigB`: site_3 holds exactly ONE datum (a section
# with sMin == sMax, i.e. a repeated value in the bounds array) and site_4 holds
# none (zero sections under countGaps = FALSE, a zero-length section under
# countGaps = TRUE).  site_2 repeats a z-coordinate, so two data share an age.
# Sites 2-4 share a height range, so parameters that equate their alignment give
# bit-identical bounds — runs of length 2 and 3.

ovlSignal <- local({
  h <- 0:9
  sig <- rbind(
    data.frame(site = "site_1", height = 0:18,
               sigA = sin((0:18) / 3), sigB = cos((0:18) / 4)),
    data.frame(site = "site_2", height = h,
               sigA = sin((h + 2) / 3), sigB = cos((h + 2) / 4)),
    data.frame(site = "site_3", height = h,
               sigA = sin((h + 3) / 3), sigB = NA_real_),
    data.frame(site = "site_4", height = h,
               sigA = sin((h + 1) / 3), sigB = NA_real_)
  )
  sig$sigB[sig$site == "site_3" & sig$height == 4] <- 0.5
  sig <- rbind(sig, data.frame(site = "site_2", height = 5,
                               sigA = 0.77, sigB = -0.11))
  sig[order(sig$site, sig$height), ]
})

# Fixed parameter vectors (alpha_site_2..4, gammaLog_site_2..4), chosen for the
# bounds geometry each produces; asserted below rather than assumed.
ovlCases <- list(
  nested      = c(2, 3, 1, 0, 0, 0),
  coincident2 = c(2, 3, 2, 0, 0, 0),
  coincident3 = c(9, 9, 9, 0, 0, 0),
  touching    = c(-4.5, 3, 1, 0, 0, 0),
  sloped      = c(2, 3, 1, 0.2, -0.15, 0.3),
  disjoint    = c(-14, 3, 20, 0, 0, 0)
)

# One short R-engine run supplies a well-formed `mcmc`/`state` pair (the
# `equiv_setup` pattern of test-cpp-logpost-equivalence.R).  Only the Gibbs
# state is taken from it: every evaluation below overrides the parameters, and
# the overlap depends on the parameters alone.  Memoised — the runs are the
# only slow part of this file.
ovlSetup <- local({
  cached <- NULL
  function() {
    if (!is.null(cached)) return(cached)
    data <- StratData(signal = ovlSignal, signalColumn = c("sigA", "sigB"))
    model <- StratModel(stratData = data, priors = NULL,
                        alignmentScale = "height", sedModel = "site",
                        overlapPenalty = c(-0.31, -0.57, -1.13, -2.29),
                        countGaps = FALSE, flexibleKnots = FALSE,
                        knotRange = c(-20, 40))
    td <- file.path(tempdir(), "sbOverlapPin")
    dir.create(td, showWarnings = FALSE, recursive = TRUE)
    set.seed(11)
    run <- RunStratModel(stratObject = data, stratModel = model, nIter = 10,
                         nChains = 1, seed = 1, quiet = TRUE, visualise = FALSE,
                         nThreads = 1L, modelDir = td, modelName = "ovl",
                         engine = "R")
    mcmc <- readRDS(file.path(td, "ovl_mcmc_run_1.rds"))
    unlink(td, recursive = TRUE)
    workingModel <- run$model
    if (is.null(workingModel$.logpost_cpp)) {
      workingModel$.logpost_cpp <-
        StratoBayes:::.PrepareLogPostArgs(workingModel)
    }
    if (is.null(workingModel$.tiesDispatch)) {
      workingModel$.tiesDispatch <-
        StratoBayes:::.BuildTiesDispatch(run$data, workingModel)
    }
    state <- mcmc$recentState
    state[[1]]$age$signalSectionOverlap <-
      lapply(state[[1]]$age$signalSectionOverlap,
             function(v) rep(1L, length(v)))
    cached <<- list(data = run$data, model = workingModel, mcmc = mcmc,
                    state = state, S = data$S)
    cached
  }
})

# countGaps is a flag the engine reads at creation; the gap-segment index it
# consults under FALSE is part of the StratData either way, so flipping it here
# is equivalent to rebuilding the model and saves a second setup run.
OvlEngine <- function(setup, signal, countGaps, adjustments = NULL) {
  model <- setup$model
  model$overlapPenalty$countGaps <- countGaps
  nSignal <- length(model$overlapPenalty$adjustments)
  model$overlapPenalty$adjustments <- if (is.null(adjustments)) {
    lapply(seq_len(nSignal), function(m) {
      if (m == signal) 1000^(seq_len(setup$S) - 1) else rep(0, setup$S)
    })
  } else {
    adjustments
  }
  StratoBayes:::.sb_create_engine(setup$data, model, setup$mcmc, setup$state)
}

# Sections as the engine defines them: sites under countGaps, else the
# gap-separated sub-segments of each site.
OvlSections <- function(data, signalFlat, signal, countGaps) {
  ages <- lapply(data$signalAttr$sigs[[signal]]$signalIndSite,
                 function(i) signalFlat[i])
  if (countGaps) {
    return(ages)
  }
  segments <- data$signalAttr$signalGapSectBindSepSignal[[signal]]
  unlist(lapply(seq_along(ages), function(s) {
    apply(segments[[s]], 2, function(y) ages[[s]][y[[1]]:y[[2]]],
          simplify = FALSE)
  }), recursive = FALSE, use.names = FALSE)
}

OvlOracleCounts <- function(sectionAges) {
  lo <- vapply(sectionAges,
               function(a) if (length(a)) min(a) else NA_real_, numeric(1))
  hi <- vapply(sectionAges,
               function(a) if (length(a)) max(a) else NA_real_, numeric(1))
  populated <- !is.na(lo)
  unlist(lapply(sectionAges, function(a) {
    vapply(a, function(x) sum(lo[populated] <= x & hi[populated] >= x),
           integer(1))
  }), use.names = FALSE)
}

OvlHistogram <- function(counts, nBucket) {
  vapply(seq_len(nBucket), function(k) sum(counts == k), integer(1))
}

OvlDecode <- function(encoded, nBucket) {
  encoded <- round(encoded)
  vapply(seq_len(nBucket),
         function(k) as.integer((encoded %/% (1000^(k - 1))) %% 1000),
         integer(1))
}

# Length of the longest run of equal values in the sorted bounds array: 1 when
# every section boundary is distinct, higher when the lookup has to collapse a
# run.
OvlMaxBoundRun <- function(sectionAges) {
  lo <- vapply(sectionAges,
               function(a) if (length(a)) min(a) else NA_real_, numeric(1))
  hi <- vapply(sectionAges,
               function(a) if (length(a)) max(a) else NA_real_, numeric(1))
  bounds <- sort(c(lo, hi), na.last = NA)
  if (!length(bounds)) 0L else max(as.integer(table(bounds)))
}

# nolint start: object_usage_linter. testthat's expectations are
# in scope at run time; lintr cannot see them from a bare function.
OvlCheck <- function(countGaps) {
  setup <- ovlSetup()
  S <- setup$S
  for (signal in seq_len(2L)) {
    engine <- OvlEngine(setup, signal, countGaps)
    for (case in names(ovlCases)) {
      tag <- sprintf("countGaps=%s signal=%d params=%s",
                     countGaps, signal, case)
      got <- StratoBayes:::.sb_eval_logpost(engine, 1L, ovlCases[[case]],
                                            debug = TRUE)
      expect_true(isTRUE(got$ok), info = paste(tag, "- age conversion valid"))
      if (!isTRUE(got$ok)) next

      sections <- OvlSections(setup$data, got$signalFlat, signal, countGaps)
      expected <- OvlHistogram(OvlOracleCounts(sections), S)
      expect_equal(OvlDecode(got$logPostSep[[4]], S), expected, info = tag)
    }
  }
}

# nolint end

test_that("engine section overlap matches the oracle (countGaps = FALSE)", {
  OvlCheck(FALSE)
})

test_that("engine section overlap matches the oracle (countGaps = TRUE)", {
  OvlCheck(TRUE)
})

test_that("the overlap fixture still holds the edge cases it was built for", {
  # Without this the fixture could drift into ordinary geometry and the tests
  # above would keep passing while covering nothing interesting.
  setup <- ovlSetup()
  engine <- OvlEngine(setup, 2L, FALSE)

  runLength <- list()
  for (case in names(ovlCases)) {
    got <- StratoBayes:::.sb_eval_logpost(engine, 1L, ovlCases[[case]],
                                          debug = TRUE)
    expect_true(isTRUE(got$ok), info = case)

    gapped <- OvlSections(setup$data, got$signalFlat, 2L, FALSE)
    ungapped <- OvlSections(setup$data, got$signalFlat, 2L, TRUE)
    expect_equal(sum(lengths(gapped) == 1L), 1L,
                 info = paste(case, "- one single-point section"))
    expect_equal(sum(lengths(ungapped) == 0L), 1L,
                 info = paste(case, "- one section with no data"))
    expect_equal(length(gapped), length(ungapped) - 1L,
                 info = paste(case, "- the empty site contributes no segment"))

    signalOne <- OvlSections(setup$data, got$signalFlat, 1L, FALSE)
    expect_true(any(duplicated(signalOne[[2]])),
                info = paste(case, "- site_2's repeated height gives two data",
                             "the same age"))
    runLength[[case]] <- OvlMaxBoundRun(signalOne)

    counts <- OvlOracleCounts(signalOne)
    expect_true(all(counts >= 1L),
                info = paste(case, "- every datum lies in its own section"))
  }

  # Runs of 1, 2 and 3 equal bounds are all reached, so the lookup's
  # run-collapsing branch is exercised as well as its plain binary search.
  # These three hold because equal parameters over equal heights give bitwise
  # equal ages; `touching` (a section's max landing on another's min) is left
  # unasserted because it depends on exact cancellation in the age conversion.
  expect_equal(runLength$nested, 1L)
  expect_equal(runLength$coincident2, 2L)
  expect_equal(runLength$coincident3, 3L)

  # The full adjustment vector is indexed, including its last element.
  got <- StratoBayes:::.sb_eval_logpost(engine, 1L, ovlCases$nested,
                                        debug = TRUE)
  sections <- OvlSections(setup$data, got$signalFlat, 1L, FALSE)
  counts <- OvlOracleCounts(sections)
  expect_equal(sort(unique(counts)), seq_len(setup$S))
})

test_that("the engine overlap comparison is not vacuous", {
  setup <- ovlSetup()
  S <- setup$S
  probe <- 1000^(seq_len(S) - 1)

  # The state handed to the engine carries a deliberately wrong overlap vector,
  # and it survives import untouched...
  engine <- OvlEngine(setup, 1L, FALSE)
  imported <-
    StratoBayes:::.sb_extract_state(engine)[[1]]$age$signalSectionOverlap
  expect_true(all(unlist(imported) == 1L))

  # ...so the value component 4 would take had `compute_section_overlap` not run
  # is known, and it is not the answer the engine gives.
  poisoned <- probe[[1]] * length(imported[[1]])
  got <- StratoBayes:::.sb_eval_logpost(engine, 1L, ovlCases$nested,
                                        debug = TRUE)
  expect_true(isTRUE(got$ok))
  expect_false(isTRUE(all.equal(got$logPostSep[[4]], poisoned)))

  sections <- OvlSections(setup$data, got$signalFlat, 1L, FALSE)
  expect_equal(OvlDecode(got$logPostSep[[4]], S),
               OvlHistogram(OvlOracleCounts(sections), S))
})
