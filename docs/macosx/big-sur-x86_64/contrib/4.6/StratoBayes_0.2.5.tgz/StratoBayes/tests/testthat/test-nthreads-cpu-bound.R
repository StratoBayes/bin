# Regression test for red-team finding RT-382.
#
# `nThreads` was used only as an on/off gate (`eng->nThreads > 1`) while
# `start_thread_pool` spawned one worker per *chain*, so `nThreads = 2` with
# `nChains = 8` ran 8 concurrent OS threads.  The pool now holds
# `min(nThreads, nChains)` workers that claim chains from a shared queue.
#
# Wall-clock timing cannot discriminate this: a pool that ignores `nThreads`
# and one that honours it both "work", and on an idle machine the oversubscribed
# version may even be faster.  The discriminator is the worker count itself,
# exposed by `.sb_n_workers()`:
#   * fixed:  min(nThreads, nChains) workers
#   * buggy:  nChains workers, whatever nThreads was
#
# Concurrency stays within the project's 2-core cap throughout: the arms that
# actually iterate use nThreads <= 2, and the clamping arm asserts on the worker
# count without running any iterations.

.rt382_engine <- function(nChains, seed = 4471) {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), paste0("rt382_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(seed)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 5, nChains = nChains, seed = 1,
    quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "rt382", engine = "cpp"
  )

  mcmc_obj <- readRDS(file.path(td, "rt382_mcmc_run_1.rds"))
  model_obj <- result$model
  if (is.null(model_obj$.logpost_cpp)) {
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)
  }

  unlink(td, recursive = TRUE)
  list(
    data = result$data, model = model_obj, mcmc = mcmc_obj,
    state = mcmc_obj$recentState
  )
}

.rt382_new_ptr <- function(parts) {
  StratoBayes:::.sb_create_engine(
    data = parts$data, model = parts$model, mcmc = parts$mcmc,
    state = parts$state, tiesCallback = NULL
  )
}

test_that("RT-382: pool size is min(nThreads, nChains), not nChains", {
  skip_on_cran()

  nChains <- 6L
  parts <- .rt382_engine(nChains)

  # The finding's own scenario: fewer threads than chains.  Pre-fix this
  # returns 6; post-fix 2.
  ptr <- .rt382_new_ptr(parts)
  StratoBayes:::.sb_set_threads(ptr, 2L)
  expect_equal(StratoBayes:::.sb_n_workers(ptr), 2L)

  # Sequential requests must not start a pool at all.
  for (nt in c(0L, 1L)) {
    ptr_seq <- .rt382_new_ptr(parts)
    StratoBayes:::.sb_set_threads(ptr_seq, nt)
    expect_equal(StratoBayes:::.sb_n_workers(ptr_seq), 0L)
  }
})

test_that("RT-382: more threads than chains clamps to nChains", {
  skip_on_cran()

  # nChains = 2 keeps this within the 2-core cap even though 8 are requested;
  # no iterations are run, so the workers only ever park on the condvar.
  parts <- .rt382_engine(2L)
  ptr <- .rt382_new_ptr(parts)
  StratoBayes:::.sb_set_threads(ptr, 8L)
  expect_equal(StratoBayes:::.sb_n_workers(ptr), 2L)
})

test_that("RT-382: sampler output does not depend on nThreads", {
  skip_on_cran()

  # Dynamic chain hand-out is only safe if which worker runs a chain cannot
  # change that chain's result.  update_state_internal() draws from
  # chainRNG[chainIdx] and touches only [chainIdx]-indexed state, so a queued
  # pool must reproduce the sequential path bit-for-bit.  This is the assertion
  # that would catch a hand-out bug -- a chain claimed twice, or skipped -- and
  # that failure mode is interleaving-dependent, so it needs volume behind it,
  # not one short run: 3 repeats x 250 iterations x 6 chains = 4500 claims.
  nChains <- 6L
  nIter <- 250L
  parts <- .rt382_engine(nChains)

  run_with <- function(nt, seed) {
    ptr <- .rt382_new_ptr(parts)
    if (nt > 1L) StratoBayes:::.sb_set_threads(ptr, nt)
    # chainRNG is seeded from R's stream inside .sb_run_block, so the same seed
    # here gives every arm identical per-chain streams.
    set.seed(seed)
    out <- StratoBayes:::.sb_run_block(ptr, nIter, diagnostics = TRUE,
                                       timing = FALSE)
    list(logPost = out$logPost, accept = out$accept,
         state = StratoBayes:::.sb_extract_state(ptr))
  }

  for (seed in c(20260727L, 991L, 13L)) {
    seq_res <- run_with(1L, seed)
    par_res <- run_with(2L, seed)

    expect_identical(par_res$logPost, seq_res$logPost)
    expect_identical(par_res$accept, seq_res$accept)

    # Final per-chain parameter vectors must agree exactly, not just the
    # cold-chain summary the diagnostics report.
    for (c in seq_len(nChains)) {
      expect_equal(par_res$state[[c]]$parameters, seq_res$state[[c]]$parameters,
                   tolerance = 0)
    }
  }
})
