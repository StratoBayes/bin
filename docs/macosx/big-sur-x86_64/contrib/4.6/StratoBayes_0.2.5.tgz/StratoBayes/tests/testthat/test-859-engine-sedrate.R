# GH #859 (RT-675) — the C++ ENGINE's sed-rate branches must match the fixed
# src/AgeConvert.cpp.
#
# RT-239 (644e8f1f) fixed src/AgeConvert.cpp: at a partition lookup miss
# (sedRatesDF == 0, the standard gap/unconformity encoding) R's
# prod(parameters[zeta[...]], numeric(0)) is the ZETA value, not 1.0, so the
# miss must fall through to the zeta multiply rather than return 1.0 early.
# src/MCMCEngine.cpp's ac_get_sed_rate kept both pre-fix branches, so the C++
# engine could compute a different sed-rate multiplier from the same state than
# the package's own fixed entry point — a maintained-parity-core divergence.
#
# The oracle is not a second implementation of the same code: `.LogPost` reads
# the spline basis from a state built through the FIXED `.sb_age_convert`,
# while `.sb_eval_logpost` makes the engine re-derive it from the parameters
# through its own age conversion. A disagreement is therefore a real engine
# defect.
#
# Normal data cannot exercise this: StratData()'s .FillGaps always builds gap
# boundaries with zero width, so the rate difference is multiplied by a zero
# interval. The fixture below relaxes that invariant on one boundary, as a wide
# unconformity or a `parts$sedRates` column bypassing .FillGaps would.

skip_on_cran()

test_that("the C++ engine applies the zeta multiplier at a gap boundary (#859)", {
  d <- StratoBayes:::.EnsurePreExtracted(stratData2)
  indices <- StratoBayes:::.CreateIndices(d, "age", "site x partition",
                                          "middle")

  sedRatesDF <- d[["partsAttr"]][["sedRatesDF"]]
  nBound     <- d[["partsAttr"]][["nBound"]]
  zeta       <- indices[["zeta"]]

  gapCells <- which(sedRatesDF == 0, arr.ind = TRUE)
  gapCells <- gapCells[gapCells[, "row"] <= nBound[gapCells[, "col"]] &
                         (gapCells[, "col"] - 1) >= 1 &
                         (gapCells[, "col"] - 1) <= length(zeta), , drop = FALSE]
  expect_gt(nrow(gapCells), 0)   # a usable gap boundary exists
  expect_gt(length(zeta), 0)     # a zeta factor is present to be dropped

  b <- gapCells[1, "row"]
  s <- gapCells[1, "col"]
  d[["partsAttr"]][["Bound"]][b, s] <-
    d[["partsAttr"]][["BoundLow"]][b, s] + 10
  expect_gt(d[["partsAttr"]][["Bound"]][b, s] -
              d[["partsAttr"]][["BoundLow"]][b, s], 0)

  # No bundled prior set covers age x site-x-partition on this fixture.
  priors <- lapply(indices[["names"]], function(nm) {
    if (startsWith(nm, "alpha")) UniformPrior(min = -50, max = 50)
    else if (startsWith(nm, "gap")) ExponentialPrior(rate = 0.1)
    else NormalPrior(mean = 0, sd = 1)
  })
  names(priors) <- indices[["names"]]
  class(priors) <- c("list", "StratPrior")

  model <- StratModel(d, priors, alignmentScale = "age",
                      sedModel = "site x partition", flexibleKnots = FALSE)

  td <- file.path(tempdir(), "rt675")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  set.seed(675)
  result <- RunStratModel(
    stratObject = d, stratModel = model,
    nIter = 10, nChains = 2, seed = 1, quiet = TRUE, visualise = FALSE,
    nThreads = 1L, modelDir = td, modelName = "rt675", engine = "R"
  )

  dataObj  <- result[["data"]]
  modelObj <- result[["model"]]
  mcmcObj  <- readRDS(file.path(td, "rt675_mcmc_run_1.rds"))
  stateObj <- mcmcObj[["recentState"]]

  if (is.null(modelObj[[".logpost_cpp"]]))
    modelObj[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(modelObj)
  if (is.null(modelObj[[".tiesDispatch"]]))
    modelObj[[".tiesDispatch"]] <-
      StratoBayes:::.BuildTiesDispatch(dataObj, modelObj)

  tiesCallback <- if ("ties" %in% names(dataObj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(dataObj, modelObj[["ind"]],
                                                 parameters, FALSE)
      StratoBayes:::.LogLikTies(dataObj, modelObj,
                                list(age = list(ties = ageResult[["ties"]])))
    }
  }

  engine <- StratoBayes:::.sb_create_engine(
    data = dataObj, model = modelObj, mcmc = mcmcObj, state = stateObj,
    tiesCallback = tiesCallback)

  for (ch in seq_along(stateObj)) {
    params <- stateObj[[ch]][["metro"]][["parameters"]]
    rComp <- StratoBayes:::.LogPost(dataObj, modelObj, stateObj[[ch]])
    cpp <- StratoBayes:::.sb_eval_logpost(engine, ch, params, debug = TRUE)
    expect_true(isTRUE(cpp[["ok"]]))
    # The signal likelihood is where a wrong sed rate lands: it shifts every
    # age above the gap boundary, so the spline basis moves.
    expect_equal(cpp[["logPostSep"]][2], rComp[2], tolerance = 1e-8,
                 info = sprintf("chain %d logLikSignal", ch))
    expect_equal(cpp[["logPost"]], sum(rComp, na.rm = TRUE), tolerance = 1e-8,
                 info = sprintf("chain %d total", ch))
  }
})
