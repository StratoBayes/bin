# Regression test for RT-497 (#535).
#
# The StratPosterior-continuation reconstruction path (RunStratModel.R, the
# `inherits(stratObject, "StratPosterior")` branch that rebuilds a missing
# `_samples_run_N.txt`) built a data.frame from two independently-sourced
# vectors -- `iterations` from the freshly-read on-disk mcmc RDS, and
# `sampleDataNonNA` from the (possibly stale) in-memory `stratObject`. When
# their row counts disagreed by an exact multiple, `data.frame()` recycled
# the shorter one silently, writing a corrupted TSV with duplicated
# iteration labels. This must be forced onto the TSV (not the RDS fast
# path): see binarysamples-rds-masks-tsv-bugs.

test_that("RT-497: a stale StratPosterior handle used for continuation after a
          later run has extended saveIter errors loudly instead of silently
          recycling rows into a corrupted samples TSV", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 20,
                      nChains = 2, nThreads = 0L, visualise = FALSE,
                      seed = 1, runParallel = FALSE, saveMCMC = TRUE, quiet = TRUE)

  modelDir <- r1[["modelDir"]]
  modelName <- r1[["modelName"]]

  # Continue from r1, extending saveIter to 40 on disk. r1 itself is left
  # behind, stale: its own in-memory saveIter/samples still reflect only the
  # first 20 iterations.
  r2 <- RunStratModel(r1, nIter = 20, visualise = FALSE, quiet = TRUE)
  expect_equal(length(r2[["mcmcSummary"]][["saveIter"]][[1]]), 40)

  # Force the TSV-rebuild branch: delete the on-disk samples file so
  # RunStratModel() must reconstruct it from the (stale) `stratObject`, per
  # the same set-up as RT-347's guard test. If the RDS binary fast path were
  # used instead, this bug would not be reachable (RDS masks TSV damage).
  txtFile <- list.files(
    modelDir,
    pattern = paste0("^", modelName, "_samples_run_1\\.txt$"),
    full.names = TRUE
  )
  expect_length(txtFile, 1)
  file.remove(txtFile)

  # r1 is stale: `.ReadMCMC` on this continuation reads the on-disk mcmc RDS,
  # whose saveIter is now length 40, while r1$samples (used to rebuild the
  # TSV) only has 20 completed rows -- an exact 2x multiple, the case
  # `data.frame()` recycles silently rather than erroring.
  expect_error(
    RunStratModel(r1, nIter = 5, visualise = FALSE, quiet = TRUE),
    regexp = "iteration|row"
  )

  # The rebuilt TSV must not have been written at all -- no corrupted file
  # left on disk for a later read to silently pick up.
  rebuiltTxt <- list.files(
    modelDir,
    pattern = paste0("^", modelName, "_samples_run_1\\.txt$"),
    full.names = TRUE
  )
  expect_length(rebuiltTxt, 0)
})
