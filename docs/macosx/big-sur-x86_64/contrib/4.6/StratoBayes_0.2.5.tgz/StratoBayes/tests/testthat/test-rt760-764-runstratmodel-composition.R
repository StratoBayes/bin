# Composition defects in RunStratModel(), issue #1091.

test_that("RT-761: .ReadMCMC() glob branch rejects a run-number gap", {
  dir <- withr::local_tempdir()
  modelName <- "rt761"
  Write <- function(run) {
    saveRDS(structure(list(run = run), class = "StratMCMC"),
            file.path(dir, paste0(modelName, "_mcmc_run_", run, ".rds")))
  }
  Write(1)
  Write(3)

  # Two files, nRun = 2: the count matches, so nothing downstream notices that
  # run 3's checkpoint is being handed to run 2.
  expect_error(.ReadMCMC(NULL, dir, modelName, nRun = 2),
               "run\\(s\\) 1, 3")

  # No nRun supplied (StratPosterior()'s call): read whatever is there.
  expect_length(.ReadMCMC(NULL, dir, modelName), 2)

  Write(2)
  expect_error(.ReadMCMC(NULL, dir, modelName, nRun = 2), "1, 2, 3")
  expect_length(.ReadMCMC(NULL, dir, modelName, nRun = 3), 3)
  expect_identical(names(.ReadMCMC(NULL, dir, modelName, nRun = 3)),
                   c("1", "2", "3"))
})

test_that("RT-760: a numeric runParallel resolves to a logical isParallel", {
  # A sequential run must not leave the parallel plot-coordination files
  # behind: `_plotIteration_read.txt` suppresses plotting in a later run in the
  # same `modelDir` until it passes the stale iteration.
  dir <- withr::local_tempdir()
  withr::local_options(StratoBayes.openBrowser = FALSE)
  withr::local_pdf(NULL)

  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                runParallel = 2, nIter = 20, nChains = 2, nThreads = 1,
                seed = 1, quiet = TRUE, modelDir = dir,
                visualise = list(interval = 5, signal = 1, parameter = 1))

  expect_false(any(grepl("_plotIteration", list.files(dir))))
})

test_that("RT-762: plotting keeps up when no checkpoint divides the interval", {
  plotted <- integer(0)
  local_mocked_bindings(
    .PlotDuringMCMC = function(data, model, mcmc, modelDir, modelName,
                               saveVisualiseDir, nRun, run, isParallel,
                               visualise, colourScale, i) {
      plotted <<- c(plotted, i)
    }
  )

  # The C++ engine visits checkpoints at multiples of 10 or 20 here, so an
  # interval of 7 shares almost no multiple with them: under a modulo trigger
  # the live plot freezes for hundreds of iterations at a time.
  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 200,
                nChains = 2, nThreads = 1, seed = 1, quiet = TRUE,
                modelDir = withr::local_tempdir(),
                visualise = list(interval = 7, signal = 1, parameter = 1))

  expect_gt(length(plotted), 8)
  expect_lt(max(diff(c(0L, plotted))), 30)
})

test_that("RT-763: write checkpoints before startAdapting are honoured", {
  dir <- withr::local_tempdir()
  # Writes fall at 10, 20, ..., 100; adaptation starts at 50, so 10-40 sit in
  # the stretch the C++ engine batches over in a single block.
  mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 2, nThreads = 1,
                    startAdapting = 50, writeMCMCfile = 0.1, saveMCMC = FALSE)
  withr::local_options(StratoBayes.testInterruptAtIter = 45)

  expect_error(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = mcmc,
                  nRun = 1, seed = 1, visualise = FALSE, quiet = TRUE,
                  modelName = "rt763", modelDir = dir),
    "simulated interrupt"
  )

  onDisk <- readRDS(file.path(dir, "rt763_mcmc_run_1.rds"))
  expect_equal(onDisk[["completedIter"]], 40)
  expect_true(file.exists(file.path(dir, "rt763_binarysamples_run_1.rds")))
})

test_that("RT-764: a StratMCMC without adaptTemperaturesMonitor still runs", {
  mcmc <- StratMCMC(stratModel1, nIter = 3, nChains = 2, nThreads = 1,
                    saveMCMC = FALSE)
  mcmc[["temper"]][["adaptTemperaturesMonitor"]] <- NULL

  expect_no_error(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = mcmc,
                  nRun = 1, seed = 1, visualise = FALSE, quiet = TRUE,
                  modelDir = withr::local_tempdir())
  )
})

test_that("RT-764: an empty iteration segment does not configure samples at NA", {
  segmentStarts <- integer(0)
  enginePtr <- NULL
  configure <- .sb_configure_samples
  local_mocked_bindings(
    .sb_configure_samples = function(ptr, saveIter, saveChains, sigmaFixed,
                                     priorOverlap, likTies, segmentStart,
                                     binaryOnly) {
      segmentStarts <<- c(segmentStarts, segmentStart)
      enginePtr <<- ptr
      configure(ptr, saveIter, saveChains, sigmaFixed, priorOverlap, likTies,
                segmentStart, binaryOnly)
    }
  )

  # nIter = 1 leaves nothing for the loop to run, so `runIterations` is empty.
  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 1,
                nChains = 2, nThreads = 1, seed = 1, visualise = FALSE,
                quiet = TRUE, modelDir = withr::local_tempdir())

  expect_length(segmentStarts, 1)
  expect_identical(segmentStarts, 2L)

  # segmentStart (2L) exceeds endIter (1) for nIter = 1: confirm
  # .sb_configure_samples() tolerated a start past the segment end rather than
  # leaving the engine in a state that faults on the next call.
  expect_no_error(StratoBayes:::.sb_extract_state(enginePtr))
})
