withr::local_options(
  cli.progress_handlers_only = character(0),
  .local_envir = testthat::teardown_env()
)
