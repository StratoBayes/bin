# #996: a hand-supplied HMC/NUTS `proposalArgs` slot REPLACES the lazily-built
# defaults rather than merging with them, so a partial list used to run to
# completion on a sampler with no step size, mass matrix or dual-averaging
# state. It must now fail, naming the entries that are absent.

nuts_test_model <- function() {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
}


test_that("required-argument lists match the default builders", {
  model <- nuts_test_model()
  expect_setequal(StratoBayes:::.kNUTSRequiredArgs,
                  names(StratoBayes:::.NUTSDefaultArgs(model)))
  expect_setequal(StratoBayes:::.kHMCRequiredArgs,
                  names(StratoBayes:::.HMCDefaultArgs(model)))
})


test_that(".ValidateGradientProposalArgs accepts complete args and NULL", {
  model <- nuts_test_model()
  Validate <- StratoBayes:::.ValidateGradientProposalArgs
  expect_silent(Validate(NULL, "NUTS"))
  expect_silent(Validate(StratoBayes:::.NUTSDefaultArgs(model), "NUTS"))
  expect_silent(Validate(StratoBayes:::.HMCDefaultArgs(model), "HMC"))

  # Names added at run time by .AdaptMassMatrix() / the C++ checkpoint path
  # must not be mistaken for user error.
  extra <- StratoBayes:::.NUTSDefaultArgs(model)
  extra[[".massMatUpdateCount"]] <- 64L
  extra[["restartDualAvg"]] <- TRUE
  expect_silent(Validate(extra, "NUTS"))

  # A proposal with no argument contract is not policed.
  expect_silent(Validate(list(nonsense = 1), "Univariate"))
})


test_that(".ValidateGradientProposalArgs names the missing entries", {
  Validate <- StratoBayes:::.ValidateGradientProposalArgs
  expect_error(Validate(list(epsMin = 1e-6), "NUTS", chain = 3L),
               "chain 3.*NUTS.*missing")
  expect_error(Validate(list(epsMin = 1e-6), "NUTS"), "maxTreeDepth")
  expect_error(Validate(list(epsMin = 1e-6), "NUTS"), "\\.hmcDA")
  expect_error(Validate(list(epsMin = 1e-6), "HMC"), "nSteps")
  expect_error(Validate(1e-6, "NUTS"), "must be a list")
})


test_that("RunStratModel rejects a partial NUTS proposalArgs (#996)", {
  skip_on_cran()

  model <- nuts_test_model()
  mcmc <- StratoBayes::StratMCMC(stratModel = model, nIter = 50, nChains = 2,
                                 gradientProposals = "on", nThreads = 1L)
  nutsCol <- which(names(mcmc[["propose"]]) == "NUTS")
  expect_length(nutsCol, 1L)

  # The intuitive partial override, exactly as reported in #996.
  mcmc[[c("metro", "proposalArgs")]][[1]][[nutsCol]] <- list(epsMin = 1e-6)

  td <- file.path(tempdir(), paste0("pa996_", as.integer(Sys.time())))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  data(stratData1, package = "StratoBayes")
  expect_error(
    StratoBayes::RunStratModel(
      stratObject = stratData1, stratModel = model, stratMCMC = mcmc,
      seed = 1, quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = "pa996", nCores = 1L
    ),
    "missing: massMatInv"
  )
})
