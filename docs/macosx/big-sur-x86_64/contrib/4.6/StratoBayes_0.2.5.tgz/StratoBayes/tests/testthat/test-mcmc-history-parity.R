# Regression tests for MCMC history / covariance-adaptation internals.
#
# RT-224: .BulkSaveMCMChistory (C++-engine bulk path) must apply the same
#   duplicate filter as .SaveMCMChistory (R-engine single-iteration path), so
#   rejected/duplicate states are not injected into chainHistory (which feeds
#   the Multivariate adaptive-proposal covariance).
#
# RT-223: .UpdateMCMCforContinuedRun must transfer the *chronologically most
#   recent* acceptance entries when a continued run shrinks acceptanceLength,
#   not an arbitrary positional slice of the raw ring buffer.

# ---- shared minimal fixture helpers -----------------------------------------

# Minimal model exercising the clustWithParametersMCMC = TRUE path (heights are
# zero-length, so a history row is just c(parameters, logPost)).
.make_model <- function(parametersLength) {
  list(
    heightsForClustering = list(),
    siteIndices = integer(0),
    parametersLength = parametersLength
  )
}

# Fresh metro with an empty history/acceptance buffer.
.make_metro <- function(parametersLength, historyLength, acceptanceLength,
                        nProposals = 1L, enableRingBuffer = TRUE) {
  ncolHist <- parametersLength + 1L  # + logPost (no heights)
  list(
    historyLength = historyLength,
    acceptanceLength = acceptanceLength,
    clustWithParametersMCMC = TRUE,
    enableRingBuffer = enableRingBuffer,
    historySize = 0L,
    historyRingPos = 1L,
    chainHistory = list(matrix(0, nrow = historyLength, ncol = ncolHist)),
    acceptance = array(NA_real_, dim = c(1L, acceptanceLength, nProposals)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = nProposals)
  )
}

test_that("RT-224: bulk save filters duplicates identically to per-iteration save", {
  parametersLength <- 2L
  model <- .make_model(parametersLength)

  # State sequence with two rejected (duplicate) iterations: 3 and 5 repeat the
  # immediately-preceding accepted state, exactly as a rejected MH step does.
  params <- rbind(
    c(1, 1),   # 1 accepted -> stored
    c(2, 2),   # 2 accepted -> stored
    c(2, 2),   # 3 rejected -> duplicate of 2, must be dropped
    c(3, 3),   # 4 accepted -> stored
    c(3, 3)    # 5 rejected -> duplicate of 4, must be dropped
  )
  logPost <- c(-10, -9, -9, -8, -8)
  accept  <- c(TRUE, TRUE, FALSE, TRUE, FALSE)
  propNum <- rep(1L, 5)
  n <- nrow(params)

  # --- R engine: one .SaveMCMChistory call per iteration ---
  mcmcR <- list(
    temper = list(temperatures = 1),
    metro = .make_metro(parametersLength, historyLength = 20L,
                        acceptanceLength = 10L)
  )
  for (k in seq_len(n)) {
    state <- list(list(metro = list(
      parameters = params[k, ],
      logPost = logPost[k],
      accept = accept[k],
      proposalNumber = propNum[k]
    )))
    mcmcR[["metro"]] <- .SaveMCMChistory(data = NULL, model = model,
                                         mcmc = mcmcR, state = state,
                                         inLateAdaptation = FALSE)
  }

  # --- C++ engine: one .BulkSaveMCMChistory call for the whole block ---
  mcmcB <- list(
    temper = list(temperatures = 1),
    metro = .make_metro(parametersLength, historyLength = 20L,
                        acceptanceLength = 10L)
  )
  historyData <- list(list(
    count = n,
    parameters = params,
    logPost = logPost,
    accept = accept,
    proposalNumber = propNum
  ))
  mcmcB[["metro"]] <- .BulkSaveMCMChistory(model = model, mcmc = mcmcB,
                                           historyData = historyData,
                                           inLateAdaptation = FALSE)

  # Only 3 unique states should have been stored (2 rejections dropped).
  expect_equal(mcmcB[["metro"]][["historySize"]], 3L)

  # Engine parity: bulk path matches per-iteration path exactly.
  expect_identical(mcmcB[["metro"]][["chainHistory"]],
                   mcmcR[["metro"]][["chainHistory"]])
  expect_identical(mcmcB[["metro"]][["historySize"]],
                   mcmcR[["metro"]][["historySize"]])
  expect_identical(mcmcB[["metro"]][["historyRingPos"]],
                   mcmcR[["metro"]][["historyRingPos"]])
  # Acceptance tracking stays unconditional (all 5 iterations recorded).
  expect_identical(mcmcB[["metro"]][["acceptance"]],
                   mcmcR[["metro"]][["acceptance"]])
  expect_identical(mcmcB[["metro"]][["acceptanceIndex"]],
                   mcmcR[["metro"]][["acceptanceIndex"]])

  # The stored rows are exactly the three distinct states.
  stored <- mcmcB[["metro"]][["chainHistory"]][[1]][seq_len(3L), , drop = FALSE]
  expect_equal(stored, rbind(c(1, 1, -10), c(2, 2, -9), c(3, 3, -8)),
               ignore_attr = TRUE)
})

test_that("RT-223: acceptance transfer keeps most-recent entries when length shrinks", {
  # Old run: full, wrapped acceptance ring of length 25, next-write = 13.
  oldAcceptanceLength <- 25L
  newAcceptanceLength <- 10L
  # Trace value = physical row index, so chronology is easy to verify.
  oldAcc <- array(as.numeric(seq_len(oldAcceptanceLength)),
                  dim = c(1L, oldAcceptanceLength, 1L))
  nextWrite <- 13L

  histLen <- 25L
  ncolHist <- 3L  # 2 params + logPost

  mcmc <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      historyLength = histLen,
      acceptanceLength = oldAcceptanceLength,
      historySize = 0L,          # keep history transfer trivial / out of scope
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = oldAcc,
      acceptanceIndex = matrix(nextWrite, nrow = 1L, ncol = 1L)
    )
  )

  mcmcNew <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      adaptProposal = TRUE,
      historyLength = histLen,
      acceptanceLength = newAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = array(NA_real_, dim = c(1L, newAcceptanceLength, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    ),
    recentState = NULL
  )

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  # Chronological order (oldest->newest) with next-write = 13 is physical rows
  # 13,14,...,25,1,...,12; the most recent 10 are physical rows 3..12.
  expect_equal(as.numeric(out[[c("metro", "acceptance")]][1, , 1]),
               as.numeric(3:12))
  # Buffer is now exactly full -> next write wraps to 1.
  expect_identical(out[[c("metro", "acceptanceIndex")]][1, 1], 1L)

  # Guard against the old bug: a raw positional slice would have copied physical
  # rows 16:25 and set the index to (13-1) %% 10 + 1 = 3.
  expect_false(isTRUE(all.equal(
    as.numeric(out[[c("metro", "acceptance")]][1, , 1]), as.numeric(16:25))))
})

test_that("RT-223: acceptance transfer is unchanged when length grows or is equal", {
  # Growing acceptanceLength must preserve the safe pre-existing behaviour:
  # verbatim physical copy + index remap.
  oldAcceptanceLength <- 10L
  newAcceptanceLength <- 25L
  oldAcc <- array(as.numeric(seq_len(oldAcceptanceLength)),
                  dim = c(1L, oldAcceptanceLength, 1L))
  nextWrite <- 4L
  histLen <- 25L
  ncolHist <- 3L

  mcmc <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      historyLength = histLen,
      acceptanceLength = oldAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = oldAcc,
      acceptanceIndex = matrix(nextWrite, nrow = 1L, ncol = 1L)
    )
  )
  mcmcNew <- list(
    temper = list(temperatures = 1),
    nChains = 1L,
    metro = list(
      adaptProposal = TRUE,
      historyLength = histLen,
      acceptanceLength = newAcceptanceLength,
      historySize = 0L,
      historyRingPos = 1L,
      chainHistory = list(matrix(0, nrow = histLen, ncol = ncolHist)),
      acceptance = array(NA_real_, dim = c(1L, newAcceptanceLength, 1L)),
      acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
    ),
    recentState = NULL
  )

  out <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)

  # Physical rows copied verbatim into rows 1:oldAcceptanceLength.
  expect_equal(as.numeric(out[[c("metro", "acceptance")]][1, 1:oldAcceptanceLength, 1]),
               as.numeric(1:oldAcceptanceLength))
  # Remaining rows stay NA.
  expect_true(all(is.na(
    out[[c("metro", "acceptance")]][1, (oldAcceptanceLength + 1L):newAcceptanceLength, 1])))
  # Index remapped as (oldIndex - 1) %% newLen + 1 = 4 (legacy path returns a
  # double, unchanged by this fix -> compare by value).
  expect_equal(out[[c("metro", "acceptanceIndex")]][1, 1], 4)
})

# ---- #757: C++ bulk path against the R engine's per-iteration writer --------
#
# .SaveMCMChistory is the oracle, and .BulkSaveMCMChistory must match it
# exactly, RNG draws included: the reservoir branch consumes runif() and
# sample.int(), and the C++ path calls R's own R_unif_index() so the stream is
# shared. Reservoir cases use ONE finite chain, because .SaveMCMChistory
# consumes the stream per iteration across chains and .BulkSaveMCMChistory per
# chain across iterations; the orders coincide only at nChains = 1. A reservoir
# position is arbitrary, so the asymmetry costs nothing but comparability.

.parityMetro <- function(parametersLength, historyLength,
                         acceptanceLength = 10L, nProposals = 1L,
                         nChains = 1L, withStamp = TRUE,
                         enableRingBuffer = FALSE, logicalHistory = FALSE,
                         productionTypes = FALSE) {
  ncolHist <- parametersLength + 1L
  hist0 <- if (logicalHistory) {
    matrix(NA, nrow = historyLength, ncol = ncolHist)
  } else {
    matrix(0, nrow = historyLength, ncol = ncolHist)
  }
  metro <- list(
    historyLength = historyLength,
    acceptanceLength = acceptanceLength,
    clustWithParametersMCMC = TRUE,
    enableRingBuffer = enableRingBuffer,
    historySize = if (productionTypes) rep(0, nChains) else rep(0L, nChains),
    historyRingPos = rep(1L, nChains),
    chainHistory = rep(list(hist0), nChains),
    acceptance = if (productionTypes) {
      array(NA, dim = c(nChains, acceptanceLength, nProposals))
    } else {
      array(NA_real_, dim = c(nChains, acceptanceLength, nProposals))
    },
    acceptanceIndex = if (productionTypes) {
      matrix(1, nrow = nChains, ncol = nProposals)
    } else {
      matrix(1L, nrow = nChains, ncol = nProposals)
    }
  )
  if (withStamp) {
    metro[["historyStamp"]] <-
      rep(list(rep(NA_integer_, historyLength)), nChains)
    metro[["historyStampNext"]] <- rep(1L, nChains)
  }
  metro
}

.PerIterHistory <- function(metro, model, params, logPost, accept, propNum,
                            inLateAdaptation, seed, temperatures = 1) {
  mcmc <- list(temper = list(temperatures = temperatures), metro = metro)
  set.seed(seed)
  for (k in seq_len(nrow(params))) {
    state <- lapply(seq_along(temperatures), function(ch) {
      list(metro = list(parameters = params[k, ], logPost = logPost[k],
                        accept = accept[k], proposalNumber = propNum[k]))
    })
    mcmc[["metro"]] <- .SaveMCMChistory(data = NULL, model = model, mcmc = mcmc,
                                        state = state,
                                        inLateAdaptation = inLateAdaptation)
  }
  mcmc[["metro"]]
}

.BulkHistory <- function(metro, model, params, logPost, accept, propNum,
                         inLateAdaptation, seed, temperatures = 1,
                         counts = NULL) {
  mcmc <- list(temper = list(temperatures = temperatures), metro = metro)
  if (is.null(counts)) counts <- rep(nrow(params), length(temperatures))
  historyData <- lapply(counts, function(cnt) {
    list(count = cnt, parameters = params, logPost = logPost,
         accept = accept, proposalNumber = propNum)
  })
  set.seed(seed)
  .BulkSaveMCMChistory(model = model, mcmc = mcmc, historyData = historyData,
                       inLateAdaptation = inLateAdaptation)
}

.ExpectSameHistory <- function(bulk, perIter) {
  fields <- c("chainHistory", "historySize", "historyRingPos", "acceptance",
              "acceptanceIndex", "historyStamp", "historyStampNext")
  for (f in fields) {
    testthat::expect_identical(bulk[[f]], perIter[[f]], info = f)
  }
}

# Distinct states, so nothing is filtered as a duplicate: the first
# historyLength fill the buffer and every later one takes a replacement branch.
.parityStates <- function(n) {
  list(params = cbind(seq_len(n), -seq_len(n)),
       logPost = -sqrt(seq_len(n)),
       accept = rep(c(TRUE, FALSE), length.out = n),
       propNum = rep(1L, n))
}

test_that("#757: bulk history matches per-iteration on a full reservoir", {
  model <- .make_model(2L)
  s <- .parityStates(60L)
  for (seed in c(1L, 42L, 2024L)) {
    metro <- .parityMetro(2L, historyLength = 4L)
    perIter <- .PerIterHistory(metro, model, s$params, s$logPost, s$accept,
                               s$propNum, FALSE, seed)
    bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept,
                         s$propNum, FALSE, seed)
    .ExpectSameHistory(bulk, perIter)
  }
})

test_that("#757: bulk history matches per-iteration in late adaptation", {
  model <- .make_model(2L)
  s <- .parityStates(60L)
  metro <- .parityMetro(2L, historyLength = 4L)
  perIter <- .PerIterHistory(metro, model, s$params, s$logPost, s$accept,
                             s$propNum, TRUE, 99L)
  bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept,
                       s$propNum, TRUE, 99L)
  .ExpectSameHistory(bulk, perIter)
})

test_that("#757: a failed replacement coin evicts the lowest-logPost row", {
  # set.seed(7) draws 0.9889 first, so the single snapshot below takes the
  # which.min branch rather than a random position.
  model <- .make_model(2L)
  fill <- .parityStates(4L)
  metro <- .parityMetro(2L, historyLength = 4L)
  full <- .BulkHistory(metro, model, fill$params, fill$logPost, fill$accept,
                       fill$propNum, FALSE, 1L)
  expect_identical(full[["historySize"]], 4L)
  worst <- which.min(full[["chainHistory"]][[1]][, 3L])

  bulk <- .BulkHistory(full, model, cbind(99, -99), 0, TRUE, 1L, FALSE, 7L)
  perIter <- .PerIterHistory(full, model, cbind(99, -99), 0, TRUE, 1L,
                             FALSE, 7L)

  expect_equal(bulk[["chainHistory"]][[1]][worst, ], c(99, -99, 0))
  .ExpectSameHistory(bulk, perIter)
})

test_that("#757: bulk history preserves buffer storage types", {
  model <- .make_model(2L)
  s <- .parityStates(20L)

  # Production initialises historySize double, acceptance and chainHistory
  # logical; R coerces chainHistory on first write but leaves the rest alone.
  metro <- .parityMetro(2L, historyLength = 8L, logicalHistory = TRUE,
                        productionTypes = TRUE)
  perIter <- .PerIterHistory(metro, model, s$params, s$logPost, s$accept,
                             s$propNum, FALSE, 5L)
  bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept,
                       s$propNum, FALSE, 5L)
  .ExpectSameHistory(bulk, perIter)
  expect_identical(typeof(bulk[["chainHistory"]][[1]]), "double")
  expect_identical(typeof(bulk[["historySize"]]), "double")
  expect_identical(typeof(bulk[["acceptance"]]), "logical")
  expect_identical(typeof(bulk[["acceptanceIndex"]]), "double")

  metroInt <- .parityMetro(2L, historyLength = 8L)
  bulkInt <- .BulkHistory(metroInt, model, s$params, s$logPost, s$accept,
                          s$propNum, FALSE, 5L)
  expect_identical(typeof(bulkInt[["historySize"]]), "integer")
  expect_identical(typeof(bulkInt[["acceptanceIndex"]]), "integer")
  expect_identical(typeof(bulkInt[["acceptance"]]), "double")
})

test_that("#757: bulk history tolerates a metro with no stamp vector", {
  model <- .make_model(2L)
  s <- .parityStates(10L)
  metro <- .parityMetro(2L, historyLength = 4L, withStamp = FALSE)
  perIter <- .PerIterHistory(metro, model, s$params, s$logPost, s$accept,
                             s$propNum, FALSE, 3L)
  bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept,
                       s$propNum, FALSE, 3L)
  .ExpectSameHistory(bulk, perIter)
  expect_null(bulk[["historyStamp"]])
})

test_that("#757: a count-0 chain leaves its buffers untouched", {
  model <- .make_model(2L)
  s <- .parityStates(6L)
  metro <- .parityMetro(2L, historyLength = 8L, nChains = 2L,
                        enableRingBuffer = TRUE)
  bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept, s$propNum,
                       FALSE, 11L, temperatures = c(1, 2), counts = c(6L, 0L))
  expect_identical(bulk[["historySize"]][2], metro[["historySize"]][2])
  expect_identical(bulk[["chainHistory"]][[2]],
                   matrix(0, nrow = 8L, ncol = 3L))
  expect_true(all(is.na(bulk[["acceptance"]][2, , ])))
  expect_gt(bulk[["historySize"]][1], 0L)
})

test_that("#757: an infinite-temperature chain is skipped by both paths", {
  # Ring buffer, so neither path draws and multi-chain stays comparable.
  model <- .make_model(2L)
  s <- .parityStates(6L)
  metro <- .parityMetro(2L, historyLength = 8L, nChains = 2L,
                        enableRingBuffer = TRUE)
  temps <- c(1, Inf)
  perIter <- .PerIterHistory(metro, model, s$params, s$logPost, s$accept,
                             s$propNum, FALSE, 8L, temperatures = temps)
  bulk <- .BulkHistory(metro, model, s$params, s$logPost, s$accept, s$propNum,
                       FALSE, 8L, temperatures = temps)
  .ExpectSameHistory(bulk, perIter)
  expect_identical(bulk[["chainHistory"]][[2]],
                   matrix(0, nrow = 8L, ncol = 3L))
})

test_that("#757: the wrapper rejects malformed buffers, never reads OOB", {
  model <- .make_model(2L)
  s <- .parityStates(3L)
  metro <- .parityMetro(2L, historyLength = 4L)

  bad <- metro
  bad[["historySize"]] <- 99L
  expect_error(.BulkHistory(bad, model, s$params, s$logPost, s$accept,
                            s$propNum, FALSE, 1L), "historySize")

  bad <- metro
  bad[["historyRingPos"]] <- 0L
  expect_error(.BulkHistory(bad, model, s$params, s$logPost, s$accept,
                            s$propNum, FALSE, 1L), "historyRingPos")

  bad <- metro
  bad[["chainHistory"]] <- list(matrix(0, nrow = 2L, ncol = 3L))
  expect_error(.BulkHistory(bad, model, s$params, s$logPost, s$accept,
                            s$propNum, FALSE, 1L), "historyLength")

  expect_error(.BulkHistory(metro, model, s$params, s$logPost, s$accept,
                            rep(2L, 3L), FALSE, 1L), "proposalNumber")
})
