# Regression tests for RT-682.
#
# A `Fixed(value)` entry in `priors` must have a matching `Fixed()` entry
# (same value) in `priorsProposals`, or none at all (defaulting to `priors`).
# `.MetroPriorSample()` draws the whole parameter vector from
# `priorsProposals` with no `paramNotFixed` mask, and `.fixed_D()` returns a
# constant density for any `x`: a `Fixed` parameter that disagrees between
# the two lists can drift to and stay at an arbitrary value for a whole run.

set.seed(0)
.rtFixedPPData <- .GenerateTestData("multi",
                                    version = "gap-names-3-sites-dates")
tmultiFixedPP <- StratData(.rtFixedPPData$signal, parts = .rtFixedPPData$parts,
                           ties = .rtFixedPPData$ties,
                           signalColumn = c("a", "b"), zColumn = "Hight",
                           siteColumn = "SIT")

# `alpha_site2` is `Fixed(20)`; every other entry is a live prior.
.makeFixedPriors <- function() {
  priors <- list(alpha_site1    = UniformPrior(min = 10, max = 60),
                 alpha_site2    = Fixed(20),
                 alpha_site3    = UniformPrior(min = -10, max = 60),
                 gammaLog_site1 = NormalPrior(mean = 1, sd = 1),
                 gammaLog_site2 = NormalPrior(mean = 2, sd = 0.5),
                 gammaLog_site3 = NormalPrior(mean = 3, sd = 2),
                 gap_site2_1    = ExponentialPrior(rate = 0.1))
  structure(priors, class = c("StratPrior", "list"))
}

.buildFixedModel <- function(priorsProposals = NULL) {
  StratModel(tmultiFixedPP, priors = .makeFixedPriors(),
             priorsProposals = priorsProposals,
             alignmentScale = "age", sedModel = "site",
             alphaPosition = "bottom")
}

test_that("RT-682: a live `priorsProposals` entry for a `Fixed` param errors", {
  live <- .makeFixedPriors()
  live[["alpha_site2"]] <- NormalPrior(mean = 50, sd = 5)

  expect_error(.buildFixedModel(priorsProposals = live), "alpha_site2")
  expect_error(.buildFixedModel(priorsProposals = live),
               "priorsProposals.*Fixed")
})

test_that("RT-682: a differently-valued `Fixed` `priorsProposals` errors", {
  mismatchedFixed <- .makeFixedPriors()
  mismatchedFixed[["alpha_site2"]] <- Fixed(99)

  expect_error(.buildFixedModel(priorsProposals = mismatchedFixed),
               "alpha_site2")
})

test_that("RT-682: a matching `Fixed` `priorsProposals` entry is accepted", {
  matching <- .makeFixedPriors()
  m <- .buildFixedModel(priorsProposals = matching)
  expect_s3_class(m, "StratModel")
  expect_true(inherits(m[["priorsProposals"]][["alpha_site2"]], "Fixed"))
})

test_that("RT-682: omitting `priorsProposals` defaults to `priors`", {
  m <- .buildFixedModel(priorsProposals = NULL)
  expect_s3_class(m, "StratModel")
  expect_true(inherits(m[["priorsProposals"]][["alpha_site2"]], "Fixed"))
})

test_that("RT-682: `.MetroPriorSample()` keeps a `Fixed` param at its value", {
  m <- .buildFixedModel(priorsProposals = .makeFixedPriors())
  draws <- .MetroPriorSample(50, m)
  alphaSite2Col <- draws[, "alpha_site2"]
  expect_true(all(alphaSite2Col == 20))
})

test_that(".CheckFixedPriorsProposals is a no-op with no `Fixed` entries", {
  noFixedList <- list(alpha_site1 = UniformPrior(min = 10, max = 60),
                      alpha_site2 = UniformPrior(min = -10, max = 60))
  noFixed <- structure(noFixedList, class = c("StratPrior", "list"))

  liveList <- list(alpha_site1 = NormalPrior(mean = 20, sd = 5),
                   alpha_site2 = NormalPrior(mean = 20, sd = 5))
  liveProposals <- structure(liveList, class = c("StratPrior", "list"))

  expect_true(isTRUE(.CheckFixedPriorsProposals(noFixed, liveProposals)))
})
