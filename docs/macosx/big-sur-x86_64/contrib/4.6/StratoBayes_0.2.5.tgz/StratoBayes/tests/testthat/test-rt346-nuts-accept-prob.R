# RT-346 (#417): NUTS self-transitions must not be recorded as flat rejects.
#
# NUTS's multinomial tree sampling may legitimately re-select the current point.
# That is a valid self-transition, not a failure, but collapsing it to
# `candidateChanged == FALSE` makes it indistinguishable from a divergence or an
# empty tree in the acceptance ring buffer that drives proposalProb adaptation
# (.UpdateProposalProbAndFac, R/mcmcFunctions.R).  `.UpdateStateNUTS` now also
# reports `acceptProb` -- the same alpha_tree it already computes for dual
# averaging -- and `.SaveMCMChistory` prefers it over the binary flag.
#
# These tests target the recording seam rather than trying to seed a
# deterministic self-transition: R-engine NUTS tree structure is not pinned by
# the seed, so a "this tree self-transitions at seed N" test would be flaky.
# See dev/red-team/findings.md.

test_that(".SaveMCMChistory records acceptProb over the binary flag (RT-346)", {
  skip_on_cran()

  # Minimal metro shaped like the real one: 1 chain, 1 proposal, buffer of 4.
  makeMCMC <- function() {
    list(
      temper = list(temperatures = 1),
      metro = list(
        historyLength = 4L, acceptanceLength = 4L,
        historySize = 0L, historyRingPos = 1L, enableRingBuffer = FALSE,
        clustWithParametersMCMC = TRUE,
        chainHistory = list(matrix(0, nrow = 4L, ncol = 2L)),
        acceptance = array(NA_real_, dim = c(1L, 4L, 1L)),
        acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L)
      )
    )
  }
  model <- list(parametersLength = 1L,
                heightsForClustering = list(numeric(0)),
                siteIndices = 1L)
  makeState <- function(...) {
    metro <- list(parameters = 1.5, logPost = -10, accept = FALSE,
                  proposalNumber = 1L)
    list(list(metro = utils::modifyList(metro, list(...))))
  }
  recorded <- function(state) {
    StratoBayes:::.SaveMCMChistory(NULL, model, makeMCMC(), state,
                                   FALSE)[["acceptance"]][1L, 1L, 1L]
  }

  # A NUTS iteration whose tree was valid but self-transitioned: the buffer must
  # receive the real acceptance probability.  Pre-fix it received 0, identical to
  # a divergence.
  expect_equal(recorded(makeState(acceptProb = 0.85)), 0.85)

  # An empty-tree failure genuinely is a zero -- that is the distinction the fix
  # buys, so it must still be recorded as one.
  expect_equal(recorded(makeState(acceptProb = 0)), 0)

  # Proposals that report no probability keep the binary behaviour, so MH
  # accounting is untouched.  Both the NA and the field-absent forms must work:
  # .UpdateState clears to NA_real_, but a state built before that clear (or by
  # the C++ bulk path) has no field at all.
  expect_equal(recorded(makeState(acceptProb = NA_real_)), 0)
  expect_equal(recorded(makeState(acceptProb = NA_real_, accept = TRUE)), 1)
  expect_equal(recorded(makeState(accept = TRUE)), 1)
  expect_equal(recorded(makeState(accept = FALSE)), 0)
})


test_that(".UpdateStateNUTS reports acceptProb == 0 only on an empty tree (RT-346)", {
  skip_on_cran()
  # Structural assertion rather than a pinned numeric: alpha_tree is a mean of
  # per-leaf Metropolis probabilities, so it is 0 exactly when no leaf was built.
  # Pinning a value would tie the test to the RNG stream; pinning the invariant
  # would not.
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  sModel <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("rt346_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4471)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = sModel, nIter = 10, nChains = 2,
    seed = 1, quiet = TRUE, visualise = FALSE, modelDir = td,
    modelName = "rt346", engine = "R", nThreads = 1L, gradientProposals = "on"
  )
  mcmc <- readRDS(file.path(td, "rt346_mcmc_run_1.rds"))
  state <- mcmc$recentState[[1]]
  model_obj <- result$model
  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  # Checked, not indexed blind: `gradientProposals` decides whether this
  # proposal exists at all, and it is set a dozen lines above, so the failure
  # has to name what is registered rather than raise a bare subscript error.
  nutsIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  if (length(nutsIdx) != 1L) {
    stop("expected exactly one gradient proposal; `propose` holds ",
         toString(names(mcmc$propose)))
  }
  runNUTS <- function(stepSize) {
    # Adaptation off is the post-warmup path, where alpha_tree is still owed.
    nutsArgs <- StratoBayes:::.NUTSDefaultArgs(model_obj)
    nutsArgs$adaptStepSize <- FALSE
    nutsArgs$stepSize <- stepSize
    for (ch in seq_along(mcmc$metro$proposalArgs)) {
      mcmc$metro$proposalArgs[[ch]][[nutsIdx]] <- nutsArgs
    }
    set.seed(19)
    StratoBayes:::.UpdateStateNUTS(
      result$data, model_obj, mcmc, state, chain = 1L, proposalNumber = nutsIdx)
  }

  # Two step sizes: 0.05 builds a shallow tree, 1e-3 runs to the depth cap.
  runs <- list(runNUTS(0.05), runNUTS(1e-3))

  for (updated in runs) {
    acceptProb <- updated[[c("metro", "acceptProb")]]
    # Present, finite, a probability -- and, crucially, computed even though
    # step-size adaptation is off.
    expect_false(is.null(acceptProb))
    expect_true(is.finite(acceptProb))
    expect_gte(acceptProb, 0)
    expect_lte(acceptProb, 1)
  }

  # alpha_tree is totalMetroProb / totalLeapfrog, so it is 0 only when no leaf
  # was built -- and a trajectory that never diverged built one. Acceptance
  # would be the wrong proxy for a non-empty tree: NUTS may re-select the
  # current point, which is the self-transition this file exists to tell apart
  # from a failure. `any(built)` keeps the invariant from going untested.
  built <- !vapply(runs, function(u) isTRUE(u[[c("metro", "nutsDivergent")]]),
                   logical(1))
  expect_true(any(built))
  for (updated in runs[built]) {
    expect_gt(updated[[c("metro", "acceptProb")]], 0)
  }
})
