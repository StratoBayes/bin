test_that("ScatterPlot works", {
  skip_if_not_snapshot_os()
  set.seed(1)
  vdiffr::expect_doppelganger("ScatterPlot 1", function() {
    ScatterPlot(stratPosterior1)
  })})

test_that("ScatterPlot works with custom colours", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("ScatterPlot 2", function() {

    ScatterPlot(stratPosterior2, colourBy = "none", parameters = 2:3,
                type = "o", alpha = 1,
                alignment = "all", pch = 21, bg = "red", col = "gold")
  })})

test_that("ScatterPlot works with iterations passed as list and maxSamples", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("ScatterPlot 3", function() {
    set.seed(1)
    ScatterPlot(stratPosterior2, colourBy = "al",
                parameters = "gamma",
                runs = c(2,3), alpha = 1, iterations = list(1:2500,1:2500,NULL,NULL),
                maxSamples = 100)
  })})

test_that("ScatterPlot works with colourBy = 'run'", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("ScatterPlot 4", function() {
    set.seed(1)
    ScatterPlot(stratPosterior2, colourBy = "run",
                type = "o", iterations = 4000:5000,
                parameters = 3:4)
  })})


test_that("ScatterPlot works with type = 'l'", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("ScatterPlot 5", function() {
    set.seed(1)
    ScatterPlot(stratPosterior3, colourBy = "alignment",
                type = "o", parameters = c(1,3))
  })})


test_that("ScatterPlot with new cluster object and iterations before burnIn", {
  skip_if_not_snapshot_os()
  set.seed(6)
  clustNew <- Cluster(stratPosterior1, iterations = 100:200)

  vdiffr::expect_doppelganger("ScatterPlot 6", function() {
    ScatterPlot(stratPosterior1, colourBy = "alignment",
                stratCluster = clustNew, type = "o")
  })
})


test_that("ScatterPlot produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  on.exit(unlink(tmpFile))
  expect_error({ScatterPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})

test_that("ScatterPlot attributes samples to the correct run for non-ascending runs (RT-255)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  set.seed(1)
  pars <- c("alpha_site_2", "alpha_site_3")
  out <- ScatterPlot(stratPosterior1, parameters = pars, runs = c(3, 1))
  df <- out[[1]]

  # Before the fix, runIndex was built in runSelect (user-input) order while
  # ExtractParameters() returned rows in ascending run-number order, so the run
  # labels were swapped: the "run 3" points were actually run 1's samples.
  truth3 <- sort(ExtractParameters(stratPosterior1, parameters = pars[1], runs = 3)[, 1])
  truth1 <- sort(ExtractParameters(stratPosterior1, parameters = pars[1], runs = 1)[, 1])
  expect_equal(sort(df[df[["run"]] == 3, 1]), truth3)
  expect_equal(sort(df[df[["run"]] == 1, 1]), truth1)
})

test_that("ScatterPlot does not crash for explicit NULL dots args (RT-297/298/299)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_no_error(ScatterPlot(stratPosterior1, type = NULL))
  expect_no_error(ScatterPlot(stratPosterior1, pch = NULL))
})

test_that("ScatterPlot accepts every documented `type` value and rejects unrecognised ones (RT-603)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  for (ty in c("p", "l", "o", "b", "c", "s", "S", "h", "n")) {
    expect_no_error(ScatterPlot(stratPosterior1, type = ty))
  }
  expect_error(ScatterPlot(stratPosterior1, type = "zz"), "Invalid `type`")
})

test_that("ScatterPlot validates `type` even when no legend is drawn (RT-603)", {
  # the stop() for an invalid type used to live inside the
  # `if (addLegend && ...)` block, nested inside `if (isTRUE(display))` -
  # so colourBy = "none" (no legend) or display = FALSE let a bad type
  # through silently instead of erroring
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(ScatterPlot(stratPosterior1, type = "zz", colourBy = "none"),
               "Invalid `type`")
  expect_error(ScatterPlot(stratPosterior1, type = "zz", display = FALSE),
               "Invalid `type`")
  expect_error(ScatterPlot(stratPosterior1, type = c("p", "l")),
               "Invalid `type`")
})

test_that("ScatterPlot's legend correctly shows both line and point for type = 'b' (RT-603)", {
  # the point-drawing block overwrites tempArgs[["type"]] to "p" for "o"/"b"
  # before the legend switch reads it, so it always fell into the "p" arm
  # (points only) - dropping the line entry from the legend for "b"/"o"
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  capturedLwd <- "unset"
  testthat::local_mocked_bindings(
    legend = function(...) {
      capturedLwd <<- list(...)[["lwd"]]
      invisible(NULL)
    },
    .package = "StratoBayes"
  )
  invisible(ScatterPlot(stratPosterior1, type = "b", colourBy = "run"))
  expect_false(identical(capturedLwd, "unset"))
  expect_false(anyNA(capturedLwd))
})

test_that("ScatterPlot validates `alignment` before dereferencing it (RT-604)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(ScatterPlot(stratPosterior1, alignment = NULL),
               "`alignment` cannot be NULL")
  expect_error(ScatterPlot(stratPosterior1, alignment = character(0)),
               "`alignment` cannot be an empty vector")
  expect_error(ScatterPlot(stratPosterior1, alignment = NA),
               "`alignment` must not contain missing values")
})

test_that("ScatterPlot validates maxSamples instead of crashing inside .maxSampleDeterministicRows (RT-606)", {
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)

  expect_error(ScatterPlot(stratPosterior1, maxSamples = NA), "`maxSamples`")
  expect_error(ScatterPlot(stratPosterior1, maxSamples = -5), "`maxSamples`")
})

test_that("ScatterPlot reserves legend margin using cex.lab, matching what the legend is drawn with (RT-608)", {
  capturedCex <- NULL
  testthat::local_mocked_bindings(
    .EstimateLegendWidth = function(labels, cex = 1) {
      capturedCex <<- cex
      6
    },
    .package = "StratoBayes"
  )
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  invisible(ScatterPlot(stratPosterior1, colourBy = "run", cex.lab = 3))
  expect_equal(capturedCex, 3)
})
