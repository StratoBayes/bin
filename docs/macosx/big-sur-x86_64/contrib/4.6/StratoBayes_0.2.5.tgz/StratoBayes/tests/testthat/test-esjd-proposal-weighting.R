# Tests for the ESJD-per-second proposal frequency criterion (#760)
#
# Assertions are on the *schedule* — the relative weights that follow from known
# jump-distance and timing inputs — never on sampler output, which is not
# portable across platforms.

# Two proposal types, one chain, with fully specified interval measurements.
# `jumpSq`/`jumpSqSq` are sums over `count` draws; passing sumsq == count * m^2
# means every draw scored the same, i.e. a zero-variance (fully resolved) rate.
esjdArgs <- function(pOld = c(0.5, 0.5),
                     sqJump, sqJumpSq, timeNs, count,
                     valid = c(TRUE, TRUE), updateCount = 1L) {
  list(pOld = pOld, sqJump = sqJump, sqJumpSq = sqJumpSq, timeNs = timeNs,
       count = count, valid = valid, updateCount = updateCount)
}

test_that("equal ESJD reduces exactly to the ratified 1/sqrt(cost) weighting", {
  # Equal squared jump per draw is the case that must reduce to RT-323's
  # ratified 1/sqrt(cost): a 100x cost ratio buys a 10x share ratio.
  n <- 100
  res <- do.call(StratoBayes:::.EsjdProposalShares, esjdArgs(
    sqJump = c(n, n), sqJumpSq = c(n, n),          # mean 1 per draw, no spread
    timeNs = c(n * 1e6, n * 100e6),                # 1 ms vs 100 ms per draw
    count = c(n, n)
  ))

  floorShare <- 5 / (2 * n)              # .kMinRateDraws over total draws
  expect_equal(sum(res), 1)
  expect_equal((res[1] - floorShare) / (res[2] - floorShare), sqrt(100))
  expect_gt(res[1] / res[2], 3)
})

test_that("a dead proposal with a cheap rejection path loses weight", {
  # Out-of-support proposals short-circuit to the -1e30 sentinel, making the
  # failing type the CHEAPEST in the registry.
  n <- 1000
  res <- do.call(StratoBayes:::.EsjdProposalShares, esjdArgs(
    sqJump = c(0, n),                              # dead type never moves
    sqJumpSq = c(0, n),
    timeNs = c(n * 0.2e6, n * 0.5e6),              # and is 2.5x cheaper
    count = c(n, n)
  ))

  expect_equal(res[1], 5 / (2 * n))                # exactly the floor
  expect_lt(res[1], 0.01)
  expect_gt(res[2], 0.98)
})

test_that("the exploration floor is a draw count, not a budget share", {
  # The floor costs .kMinRateDraws draws, so its share falls as the interval
  # grows. Same measurements, 100x longer interval.
  deadArgs <- function(n) {
    esjdArgs(sqJump = c(0, n), sqJumpSq = c(0, n),
             timeNs = c(n * 0.2e6, n * 0.5e6), count = c(n, n))
  }
  short <- do.call(StratoBayes:::.EsjdProposalShares, deadArgs(100))
  long  <- do.call(StratoBayes:::.EsjdProposalShares, deadArgs(10000))

  expect_equal(short[1], 5 / 200)
  expect_equal(long[1], 5 / 20000)
  expect_lt(long[1], short[1] / 50)
})

test_that("floors cannot exceed the uniform share on a short interval", {
  # 3 draws over 4 types cannot support 5 each; the cap degrades to uniform
  # rather than to floors summing above 1.
  res <- StratoBayes:::.EsjdProposalShares(
    pOld = rep(0.25, 4),
    sqJump = c(0, 1, 2, 0), sqJumpSq = c(0, 1, 4, 0),
    timeNs = rep(1e6, 4), count = c(1, 1, 1, 0),
    valid = rep(TRUE, 4), updateCount = 1L
  )
  expect_equal(res, rep(0.25, 4))
})

test_that("no weight moves on differences inside the standard error", {
  # One large jump in 10 draws each: the rate difference is far inside its own
  # SE, and a gate-closed update is the identity.
  pOld <- c(0.7, 0.3)
  res <- StratoBayes:::.EsjdProposalShares(
    pOld = pOld,
    sqJump = c(10, 12), sqJumpSq = c(100, 144),    # one jump each, sizes 10/12
    timeNs = c(10e6, 10e6), count = c(10, 10),
    valid = c(TRUE, TRUE), updateCount = 1L
  )
  expect_equal(res, pOld)
})

test_that("a resolved rate difference does move weight", {
  # Same rate ratio as the gated case over 1000 draws with no spread.
  n <- 1000
  res <- StratoBayes:::.EsjdProposalShares(
    pOld = c(0.5, 0.5),
    sqJump = c(n * 1.0, n * 1.2), sqJumpSq = c(n * 1.0, n * 1.44),
    timeNs = c(n * 1e6, n * 1e6), count = c(n, n),
    valid = c(TRUE, TRUE), updateCount = 1L
  )
  expect_gt(res[2], res[1])
  expect_equal((res[2] - 5 / (2 * n)) / (res[1] - 5 / (2 * n)), sqrt(1.2))
})

test_that("the 1/sqrt(t) envelope shrinks later weight updates", {
  n <- 1000
  args <- esjdArgs(sqJump = c(0, n), sqJumpSq = c(0, n),
                   timeNs = c(n * 0.2e6, n * 0.5e6), count = c(n, n))
  early <- do.call(StratoBayes:::.EsjdProposalShares, args)
  args$updateCount <- 400L
  late <- do.call(StratoBayes:::.EsjdProposalShares, args)

  # eta = 1/sqrt(400) = 0.05, so the dead type keeps most of its old share --
  # but it does move, which is what lets weights track indefinitely.
  expect_lt(early[1], late[1])
  expect_lt(late[1], 0.5)
  expect_gt(late[1], 0.4)
})

test_that("an invalid type is never allocated budget", {
  res <- StratoBayes:::.EsjdProposalShares(
    pOld = c(0.4, 0.4, 0.2),
    sqJump = c(100, 200, 999), sqJumpSq = c(100, 400, 999),
    timeNs = c(100e6, 100e6, 100e6), count = c(100, 100, 100),
    valid = c(TRUE, TRUE, FALSE), updateCount = 1L
  )
  expect_equal(res[3], 0)
  expect_equal(sum(res), 1)
})


# ── .UpdateProposalProbAndFac() end to end ──────────────────────────────────
# Synthetic metro structure, as in test-cost-aware-weighting.R.

metroFixture <- function(propNames, sqJump, sqJumpSq, timeNs, count,
                         pOld = rep(0.5, length(propNames)),
                         acceptRate = 0.7, probUpdateCount = 0L) {
  nProp <- length(propNames)
  one <- function(x, int = FALSE) {
    matrix(if (int) as.integer(x) else x, nrow = 1,
           dimnames = list("chain1", propNames))
  }
  list(
    proposalProbability = one(pOld),
    proposalProbabilityWeights = one(rep(1, nProp)),
    proposalValid = matrix(TRUE, nrow = 1, ncol = nProp,
                           dimnames = list("chain1", propNames)),
    proposalFactor = one(rep(1, nProp)),
    proposalTimeNs = one(timeNs),
    proposalTimeCount = one(count, int = TRUE),
    proposalSqJump = one(sqJump),
    proposalSqJumpSq = one(sqJumpSq),
    probUpdateCount = probUpdateCount,
    nProposals = setNames(nProp, "chain1"),
    acceptance = array(rep(acceptRate, 25 * nProp), dim = c(1, 25, nProp),
                       dimnames = list("chain1", NULL, propNames)),
    acceptanceLength = 25L,
    acceptanceIndex = matrix(1L, nrow = 1, ncol = nProp,
                             dimnames = list("chain1", propNames)),
    onlyMultivariateProposalsAfterAdapt = FALSE,
    scaleMultivariateProposals = TRUE
  )
}

mcmcFixture <- function(metro, currentIter = 100L, endAdapting = 200L) {
  list(metro = metro,
       propose = setNames(vector("list", ncol(metro$proposalProbability)),
                          colnames(metro$proposalProbability)),
       temper = list(temperatures = 1, tempering = FALSE),
       currentIter = currentIter,
       endAdapting = endAdapting)
}

test_that("a dead Multivariate proposal is no longer floored at 0.2", {
  # Late adaptation on a cold chain, where minMultivariateProb used to fire.
  # Multivariate accepts nothing and is the cheapest type.
  n <- 2000
  metro <- metroFixture(
    c("Prior", "Univariate", "Multivariate"),
    sqJump   = c(n * 0.5, n * 1.0, 0),
    sqJumpSq = c(n * 0.25, n * 1.0, 0),
    timeNs   = c(n * 0.5e6, n * 0.5e6, n * 0.2e6),
    count    = c(n, n, n)
  )
  res <- StratoBayes:::.UpdateProposalProbAndFac(
    list(), mcmcFixture(metro), inLateAdaptation = TRUE
  )
  prob <- res[["proposalProbability"]][1, ]

  expect_lt(prob[["Multivariate"]], 0.01)
  expect_equal(prob[["Prior"]], 0)      # cold-chain Prior zeroing preserved
  expect_equal(sum(prob), 1)
})

test_that("Prior keeps its budget outside late adaptation", {
  n <- 2000
  metro <- metroFixture(
    c("Prior", "Univariate", "Multivariate"),
    sqJump   = c(n * 0.5, n * 1.0, 0),
    sqJumpSq = c(n * 0.25, n * 1.0, 0),
    timeNs   = c(n * 0.5e6, n * 0.5e6, n * 0.2e6),
    count    = c(n, n, n)
  )
  res <- StratoBayes:::.UpdateProposalProbAndFac(
    list(), mcmcFixture(metro), inLateAdaptation = FALSE
  )
  expect_gt(res[["proposalProbability"]][1, "Prior"], 0)
})

test_that("a type whose ESJD rises after endAdapting regains weight", {
  # A kernel that only becomes useful after burn-in (DE-MC needs history
  # spanning two basins) must be able to earn budget back.
  n <- 2000
  weak <- metroFixture(
    c("Univariate", "ModeHop"),
    sqJump   = c(n * 1.0, 0),                     # ModeHop finds nothing yet
    sqJumpSq = c(n * 1.0, 0),
    timeNs   = c(n * 0.5e6, n * 0.5e6),
    count    = c(n, n)
  )
  burnedIn <- StratoBayes:::.UpdateProposalProbAndFac(
    list(), mcmcFixture(weak, currentIter = 200L, endAdapting = 200L),
    inLateAdaptation = TRUE
  )
  pAfterBurnIn <- burnedIn[["proposalProbability"]][1, "ModeHop"]
  expect_lt(pAfterBurnIn, 0.01)

  # Post-adaptation: ModeHop now jumps 4x as far at the same cost.
  strong <- metroFixture(
    c("Univariate", "ModeHop"),
    sqJump   = c(n * 1.0, n * 4.0),
    sqJumpSq = c(n * 1.0, n * 16.0),
    timeNs   = c(n * 0.5e6, n * 0.5e6),
    count    = c(n, n),
    pOld = c(1 - pAfterBurnIn, pAfterBurnIn),
    probUpdateCount = burnedIn[["probUpdateCount"]]
  )
  recovered <- StratoBayes:::.UpdateProposalProbAndFac(
    list(), mcmcFixture(strong, currentIter = 5000L, endAdapting = 200L),
    inLateAdaptation = TRUE
  )
  expect_gt(recovered[["proposalProbability"]][1, "ModeHop"],
            10 * pAfterBurnIn)
})

# ── C++ instrumentation ─────────────────────────────────────────────────────

# Pinned to Univariate at a fixed SD, so acceptance is a property of the fixture
# and not of the 20 adapting iterations that seeded it -- which is what lets
# esjdPushScales re-push the same proposal state without moving acceptance.
#
# `narrowPrior` collapses the alpha prior to 1e-9 wide, so against SD 1 every
# proposal is out of support (the RT-381 fixture).
esjdEngine <- function(univariateSD, narrowPrior = FALSE) {
  stratData1 <- StratoBayes::stratData1
  stratModel1 <- StratoBayes::stratModel1
  model <- stratModel1
  if (narrowPrior) {
    centre <- -2.2
    model <- StratModel(
      stratData1,
      priors = list(alpha_site_2 = UniformPrior(centre, centre + 1e-9),
                    alpha_site_3 = Fixed(4),
                    gammaLog_site_2 = Fixed(0),
                    gammaLog_site_3 = Fixed(0)),
      alignmentScale = stratModel1[["alignmentScale"]],
      sedModel = stratModel1[["sedModel"]],
      sigmaFixed = FALSE, flexibleKnots = FALSE, knotRange = c(-12, 20)
    )
  }

  td <- file.path(tempdir(), paste0("esjd_", as.integer(runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  RunStratModel(stratData1, model, nIter = 20L, nChains = 1L, seed = 11L,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "esjd", engine = "cpp", nThreads = 1L)
  mcmc <- readRDS(file.path(td, "esjd_mcmc_run_1.rds"))
  if (is.null(model[[".logpost_cpp"]])) {
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  }

  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[] <- 0
  pp[, "Univariate"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp
  pw <- mcmc[[c("metro", "proposalProbabilityWeights")]]
  pw[] <- 1
  mcmc[[c("metro", "proposalProbabilityWeights")]] <- pw
  pf <- mcmc[[c("metro", "proposalFactor")]]
  pf[] <- 1
  mcmc[[c("metro", "proposalFactor")]] <- pf
  ua <- mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]]
  ua[] <- univariateSD
  mcmc[[c("metro", "proposalArgs")]][["chain1"]][["Univariate"]] <- ua

  eng <- StratoBayes:::.sb_create_engine(stratData1, model, mcmc,
                                         mcmc[["recentState"]])
  list(engine = eng, metro = mcmc[["metro"]],
       nProp = ncol(pp), nParam = ncol(mcmc[[c("metro", "jumpInvScale")]]))
}

# Re-push the fixture's own proposal state, changing only the whitening scales.
esjdPushScales <- function(fx, scale) {
  StratoBayes:::.sb_update_proposals(
    fx$engine, fx$metro[["proposalArgs"]], fx$metro[["proposalFactor"]],
    fx$metro[["proposalProbability"]],
    matrix(scale, nrow = 1, ncol = fx$nParam)
  )
}

test_that("a rejected proposal contributes exactly zero squared jump", {
  skip_on_cran()

  fx <- esjdEngine(univariateSD = 1, narrowPrior = TRUE)
  StratoBayes:::.sb_configure_monitor(fx$engine, fx$nProp)
  # Unit scales: without them a zero below would be the absent scales, which
  # score 0 for every move, rather than the rejection.
  esjdPushScales(fx, 1)
  set.seed(760)
  StratoBayes:::.sb_run_block(fx$engine, 50L)
  mon <- StratoBayes:::.sb_get_monitor(fx$engine)

  # Every proposal left the 1e-9-wide support...
  expect_equal(sum(mon$acceptCount), 0L)
  # ...so the criterion's numerator is 0 while its denominator is not.
  expect_equal(sum(mon$proposalSqJump), 0)
  expect_equal(sum(mon$proposalSqJumpSq), 0)
  expect_gt(sum(mon$proposalTimeNs), 0)
})

test_that("accepted moves accumulate squared jump per proposal type", {
  skip_on_cran()

  fx <- esjdEngine(univariateSD = 1e-3)
  StratoBayes:::.sb_configure_monitor(fx$engine, fx$nProp)
  esjdPushScales(fx, 1)
  set.seed(761)
  StratoBayes:::.sb_run_block(fx$engine, 200L)
  mon <- StratoBayes:::.sb_get_monitor(fx$engine)

  expect_gt(sum(mon$acceptCount), 0L)
  expect_gt(sum(mon$proposalSqJump), 0)
  expect_true(all(mon$proposalSqJump >= 0))
  expect_true(all(is.finite(mon$proposalSqJump)))
  # No gradient proposal here, so a type accepting nothing cannot have moved.
  expect_equal(sum(mon$proposalSqJump[mon$acceptCount == 0L]), 0)
  # Same per-draw quantity squared, so one nonzero draw makes it positive.
  expect_gt(sum(mon$proposalSqJumpSq), 0)
})

test_that("pushed whitening scales are what jumps are measured against", {
  skip_on_cran()

  fx <- esjdEngine(univariateSD = 1e-3)
  StratoBayes:::.sb_configure_monitor(fx$engine, fx$nProp)

  # All-zero scales must read as zero jump however far the chain moves: that
  # closes the noise gate instead of inventing a rate.
  esjdPushScales(fx, 0)
  set.seed(762)
  StratoBayes:::.sb_run_block(fx$engine, 200L)
  zeroed <- StratoBayes:::.sb_get_monitor(fx$engine)
  expect_gt(sum(zeroed$acceptCount), 0L)
  expect_equal(sum(zeroed$proposalSqJump), 0)

  # Unit scales measure the raw jump.
  esjdPushScales(fx, 1)
  StratoBayes:::.sb_run_block(fx$engine, 200L)
  unit <- StratoBayes:::.sb_get_monitor(fx$engine)
  expect_gt(sum(unit$acceptCount), 0L)
  expect_gt(sum(unit$proposalSqJump), 0)
})

test_that("weight updates run on schedule through the whole sampling phase", {
  skip_on_cran()

  # Post-adapt the engine visits only checkpoints, so a weight update has to be
  # one. 1500 iterations at interval 100 owe 15; a `%%` trigger delivers one.
  td <- file.path(tempdir(), paste0("esjdsched_", as.integer(runif(1, 0, 1e8))))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  suppressWarnings(RunStratModel(
    StratoBayes::stratData1, StratoBayes::stratModel1,
    nIter = 2000L, nChains = 1L, seed = 13L, nThin = 10L,
    startAdapting = 100L, endAdapting = 500L, adaptProposalInterval = 100L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "sched",
    engine = "cpp", nThreads = 1L
  ))
  mcmc <- readRDS(file.path(td, "sched_mcmc_run_1.rds"))

  expect_gte(mcmc[[c("metro", "probUpdateCount")]][[1L]],
             (2000L - 500L) / 100L)
})

test_that("legacy metro without ESJD accumulators keeps its weights", {
  n <- 1000
  metro <- metroFixture(
    c("Prior", "Univariate"),
    sqJump = c(0, 0), sqJumpSq = c(0, 0),
    timeNs = c(n * 1e6, n * 100e6), count = c(n, n),
    pOld = c(0.25, 0.75)
  )
  metro[["proposalSqJump"]] <- NULL
  metro[["proposalSqJumpSq"]] <- NULL
  metro[["probUpdateCount"]] <- NULL

  res <- StratoBayes:::.UpdateProposalProbAndFac(
    list(), mcmcFixture(metro), inLateAdaptation = FALSE
  )
  # No measured jumps: the gate stays shut and the cost ratio alone moves
  # nothing, however lopsided.
  expect_equal(res[["proposalProbability"]][1, ],
               c(Prior = 0.25, Univariate = 0.75))
  expect_equal(res[["probUpdateCount"]], 1L)
})
