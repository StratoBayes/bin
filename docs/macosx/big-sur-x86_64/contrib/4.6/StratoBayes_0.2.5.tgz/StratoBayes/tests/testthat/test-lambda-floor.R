# The spline smoothness penalty lambda (GH #551, #603) is drawn from a prior
# truncated below at a PER-SIGNAL, SCALE-RELATIVE floor on the alignment path,
# and from an UNtruncated prior in the standalone fitter.
#
# WHY A FLOOR AT ALL (#551). At a degenerate alignment the conjugate marginal
# reaches +1e8 to +1e19 against ~-8800 for an honest fit, and a chain that
# accepts such a state then rejects everything forever. The floor makes the
# state unreachable. See src/sb_lambda.h for the calibration.
#
# WHY SCALE-RELATIVE (#603, #953). lambda's posterior scales as
# x_span^3 / y_scale^2, so an absolute floor over-smooths data whose honest
# lambda is small (#603) and sits inside the trap's inflated region on data
# whose honest lambda is large (#953). The floor is .LambdaFloorRel times
# num_basis / (sd(y)^2 tr(D)), computed per signal at StratModel() setup
# (.LambdaFloor) and stored in priors$gibbs$lambdaMin; .LambdaMin is only the
# fallback when no scale is available.
#
# WHERE THE FLOOR APPLIES — the two ALIGNMENT lambda draw sites:
# src/Gibbs.cpp (the Gibbs sweep shared by both engines) and src/MCMCEngine.cpp
# (the threaded engine). A floor missing from either leaves the #551 trap
# reachable through that path.
#
# WHERE IT DELIBERATELY DOES NOT APPLY (#603) — the STANDALONE fitter,
# src/GibbsSpline.cpp and its R reference .GibbsSampleBspline: the design
# matrix there is fixed and no alignment marginal exists, so the #551 trap is
# unreachable, and a floor only distorts honest low-lambda fits (measured: an
# absolute 1e-6 floor inflates the fit RMSE ~12x at a y-rescale of 1e3).
# Incidental rank deficiency is covered by GibbsSpline's own Cholesky ridge
# ladder. DO NOT re-add a floor to the standalone path; the scale-equivariance
# test below is the regression guard.

test_that(".LambdaFloor follows the scale law in both directions", {
  base <- list(D = diag(8), num_basis = 10L)
  set.seed(603)
  y <- rnorm(50)

  f1 <- StratoBayes:::.LambdaFloor(base, list(y))
  expect_length(f1, 1L)
  expect_true(is.finite(f1) && f1 > 0)

  # .LambdaStar is the exact scale the floor is keyed to: num_basis = 10,
  # tr(D) = 8 here.
  expect_equal(StratoBayes:::.LambdaStar(base, y),
               10 / (stats::sd(y)^2 * 8))
  # sd(y) finite but sd(y)^2 = Inf: the ratio is exactly 0, which would
  # disable the #551 floor (and the #962 seed) if kept -- must signal
  # "no usable scale" instead.
  expect_identical(StratoBayes:::.LambdaStar(base, c(0, 1e160)), NA_real_)

  # floor ~ 1 / sd(y)^2: scaling y by 10 divides the floor by 100.
  f2 <- StratoBayes:::.LambdaFloor(base, list(10 * y))
  expect_equal(f2, f1 / 100)

  # floor ~ 1 / tr(D): doubling the penalty trace halves the floor.
  f3 <- StratoBayes:::.LambdaFloor(list(D = 2 * diag(8), num_basis = 10L),
                                   list(y))
  expect_equal(f3, f1 / 2)

  # A tiny tr(D) (huge healthy lambda, the Cambrian regime of GH #953) must
  # RAISE the floor above the absolute 1e-6, which sits inside the trap's
  # inflated region there; a min(.LambdaMin, .) cap re-introduces #953.
  tinyD <- list(D = diag(8) * 1e-12, num_basis = 10L)
  fUp <- StratoBayes:::.LambdaFloor(tinyD, list(y))
  expect_gt(fUp, StratoBayes:::.LambdaMin)
  expect_equal(fUp, StratoBayes:::.LambdaFloorRel *
                 StratoBayes:::.LambdaStar(tinyD, y))

  # One floor per signal.
  fMulti <- StratoBayes:::.LambdaFloor(base, list(y, 10 * y))
  expect_equal(fMulti, c(f1, f1 / 100))
})

test_that(".LambdaFloor falls back to .LambdaMin without a usable scale", {
  base <- list(D = diag(8), num_basis = 10L)
  # Constant signal: sd = 0.
  expect_identical(StratoBayes:::.LambdaFloor(base, list(rep(1, 5))),
                   StratoBayes:::.LambdaMin)
  # Single observation: sd = NA.
  expect_identical(StratoBayes:::.LambdaFloor(base, list(3)),
                   StratoBayes:::.LambdaMin)
  # Degenerate penalty: tr(D) = 0.
  zeroD <- list(D = matrix(0, 4, 4), num_basis = 6L)
  expect_identical(StratoBayes:::.LambdaFloor(zeroD, list(rnorm(10))),
                   StratoBayes:::.LambdaMin)
  # sd(y) finite but sd(y)^2 = Inf: the computed ratio is exactly 0, which
  # would disable the #551 guard if stored, so it must fall back too.
  expect_identical(StratoBayes:::.LambdaFloor(base, list(c(0, 1e160))),
                   StratoBayes:::.LambdaMin)
})

test_that(".UpdateLambda never dips below an explicit floor at extreme btDb", {
  # btDb enters the Gibbs rate as 1/bLambda + 0.5*btDb, so a huge beta drives
  # the conditional arbitrarily close to zero. This is the field regime: beta
  # explodes when the basis goes collinear.
  numBasis <- 8L
  D <- diag(numBasis)
  set.seed(551)
  for (scaleBeta in c(1e3, 1e8, 1e15, 1e30)) {
    beta <- rep(scaleBeta, numBasis)
    draws <- vapply(seq_len(200L), function(i) {
      StratoBayes:::.UpdateLambda(beta = beta, D = D, aLambda = 1,
                                  bLambda = 1000, numBasis = numBasis,
                                  lambdaMin = StratoBayes:::.LambdaMin)
    }, numeric(1))
    expect_true(all(is.finite(draws)),
                info = sprintf("non-finite lambda, scaleBeta = %g", scaleBeta))
    expect_gte(min(draws), StratoBayes:::.LambdaMin)
  }
})

test_that(".UpdateLambda without a floor is a plain untruncated Gamma draw", {
  # The standalone fitter's setting (#603): at lambdaMin = 0 even a conditional
  # far below .LambdaMin must come back untruncated, on the same RNG stream as
  # a bare rgamma().
  numBasis <- 8L
  D <- diag(numBasis)
  # btDb = 8e8 puts the conditional mean at ~1e-8, two decades below
  # .LambdaMin.
  beta <- rep(1e4, numBasis)
  newscale <- 1 / (1 / 1000 + 0.5 * sum(beta * beta))
  shape <- 1 + (numBasis - 2) / 2

  set.seed(603)
  got <- vapply(seq_len(50L), function(i) {
    StratoBayes:::.UpdateLambda(beta = beta, D = D, aLambda = 1,
                                bLambda = 1000, numBasis = numBasis,
                                lambdaMin = 0)
  }, numeric(1))
  set.seed(603)
  want <- stats::rgamma(50L, shape = shape, scale = newscale)

  expect_identical(got, want)
  expect_lt(max(got), StratoBayes:::.LambdaMin)
})

test_that("the floor does not bind in the healthy regime", {
  # With a small btDb the conditional sits many orders of magnitude above the
  # floor, so truncation must be inert -- no uniform consumed, and the draws
  # must match an untruncated Gamma from the same seed exactly. This is what
  # keeps healthy runs bit-identical.
  numBasis <- 8L
  D <- diag(numBasis)
  beta <- rep(1e-3, numBasis)
  newscale <- 1 / (1 / 1000 + 0.5 * sum(beta * beta))
  shape <- 1 + (numBasis - 2) / 2

  set.seed(99)
  got <- vapply(seq_len(50L), function(i) {
    StratoBayes:::.UpdateLambda(beta = beta, D = D, aLambda = 1,
                                bLambda = 1000, numBasis = numBasis,
                                lambdaMin = StratoBayes:::.LambdaMin)
  }, numeric(1))
  set.seed(99)
  want <- stats::rgamma(50L, shape = shape, scale = newscale)

  expect_identical(got, want)
  expect_gt(min(got), StratoBayes:::.LambdaMin)
})

test_that("the truncated draw is exact, not merely bounded", {
  # Single-trial rejection with an inverse-CDF fallback must reproduce the
  # truncated Gamma. Compare against an independent reference: rejection
  # sampling to exhaustion. A clamp to the floor would fail this -- it would
  # pile an atom at the floor instead of spreading mass over the tail.
  shape <- 4
  # Chosen so a decent fraction (but not all) of the mass falls below the floor,
  # exercising both branches.
  newscale <- StratoBayes:::.LambdaMin / shape
  numBasis <- 10L
  D <- diag(numBasis)
  aLambda <- shape - (numBasis - 2) / 2
  # Recover the beta/bLambda that produce this newscale through .UpdateLambda's
  # own arithmetic, so the test drives the real code path rather than a
  # reimplementation.
  bLambda <- 1e12                       # 1/bLambda negligible
  target <- 1 / newscale                # = 1/bLambda + 0.5*btDb
  betaVal <- sqrt(2 * (target - 1 / bLambda) / numBasis)
  beta <- rep(betaVal, numBasis)

  set.seed(2026)
  got <- vapply(seq_len(4000L), function(i) {
    StratoBayes:::.UpdateLambda(beta = beta, D = D, aLambda = aLambda,
                                bLambda = bLambda, numBasis = numBasis,
                                lambdaMin = StratoBayes:::.LambdaMin)
  }, numeric(1))
  expect_gte(min(got), StratoBayes:::.LambdaMin)

  # Reference truncated sample, by exhaustive rejection.
  set.seed(4711)
  ref <- numeric(0)
  while (length(ref) < 4000L) {
    cand <- stats::rgamma(20000L, shape = shape, scale = newscale)
    ref <- c(ref, cand[cand >= StratoBayes:::.LambdaMin])
  }
  ref <- ref[seq_len(4000L)]

  # Distributional agreement. Two-sample KS: a clamp would put ~all its mass
  # in a single atom and be rejected outright.
  expect_gt(suppressWarnings(stats::ks.test(got, ref)$p.value), 0.01)
  # And no atom at the floor beyond what the reference shows.
  expect_lt(mean(got == StratoBayes:::.LambdaMin), 0.01)
})

# ── Standalone fitter: floor-free (#603) ─────────────────────────────────────

test_that("BayesianSpline is scale-equivariant at large y scales", {
  # lambda's posterior scales as 1/y_scale^2, so fitting y and k*y from the
  # same seed must give the same fit at scale k: lambda shrinks by k^-2 and
  # the relative fit error is unchanged. An absolute 1e-6 floor pins lambda
  # ~80x too high here and inflates the relative RMSE ~12x (GH #603).
  k <- 1e3
  set.seed(603)
  n <- 200
  x <- seq(0, 1, length.out = n)
  mu0 <- sin(2 * pi * x)
  y0 <- mu0 + rnorm(n, sd = 0.1)

  set.seed(1)
  fit1 <- BayesianSpline(x = x, y = y0, nKnots = 20, nIter = 1000)
  set.seed(1)
  fitK <- BayesianSpline(x = x, y = k * y0, nKnots = 20, nIter = 1000)

  sel <- 501:1000
  lam1 <- median(fit1[["lambda"]][sel])
  lamK <- median(fitK[["lambda"]][sel])
  # Same-seed chains stay approximately paired (measured ratio 0.97 locally),
  # but the k-run's transient walks lambda down four orders from its fixed
  # initial value, so allow platform/BLAS trajectory differences a wide berth:
  # an absolute floor distorts this ratio ~80x, so [0.2, 5] still discriminates.
  expect_gt(lamK * k^2 / lam1, 0.2)
  expect_lt(lamK * k^2 / lam1, 5)
  # The honest lambda at scale k sits below .LambdaMin: the regime an absolute
  # floor destroys.
  expect_lt(lamK, 1e-6)

  relRMSE <- function(fit, truth, scale) {
    pred <- PredictSpline(fit, at = x, burnIn = 0.5)
    sqrt(mean((pred[["mu"]] - truth)^2)) / scale
  }
  r1 <- relRMSE(fit1, mu0, 1)
  rK <- relRMSE(fitK, k * mu0, k)
  expect_lt(rK, 1.5 * r1)
})

test_that("the standalone fitter draws lambda below .LambdaMin freely", {
  # bLambda = 1e-9 puts the conditional mean near 1e-8, below .LambdaMin; the
  # draws must follow the conditional, not a floor (GH #603). Exercises
  # GibbsSpline.cpp (the production loop).
  set.seed(551)
  n <- 200L
  x <- seq(0, 1, length.out = n)
  y <- sin(2 * pi * x) + stats::rnorm(n, sd = 0.1)

  fit <- BayesianSpline(x = x, y = y, nKnots = 20L, nIter = 400L,
                        bLambda = 1e-9)
  lam <- fit[["lambda"]][201:400]
  expect_true(all(is.finite(lam)) && all(lam > 0))
  expect_lt(stats::median(lam), 1e-6)
  expect_gt(stats::median(lam), 1e-10)
})

test_that("the R reference .GibbsSampleBspline is floor-free too", {
  # Parity with GibbsSpline.cpp: same stimulus, same freedom below 1e-6.
  set.seed(551)
  n <- 100L
  x <- seq(0, 1, length.out = n)
  y <- sin(2 * pi * x) + stats::rnorm(n, sd = 0.1)
  d <- data.frame(x = x, y = y)
  model <- StratoBayes:::.ModelBspline(d, 20, NULL, 0.01, 0.01, 1, 1e-9,
                                       0.0001, FALSE, NULL, NULL)
  state <- StratoBayes:::.InitializeGibbsBspline(d, model)
  lam <- vapply(seq_len(200L), function(i) {
    state <<- StratoBayes:::.GibbsSampleBspline(d, model, state)
    state[[c("gibbs", "lambda")]]
  }, numeric(1))
  expect_true(all(is.finite(lam)) && all(lam > 0))
  expect_lt(stats::median(lam[101:200]), 1e-6)
})

# ── Alignment path: scale-relative floor ─────────────────────────────────────

# The stimulus for the engine sites is bLambda = 1e-12. The Gibbs rate is
# 1/bLambda + 0.5*btDb, so 1/bLambda = 1e12 alone drives the conditional mean to
# shape/1e12 ~ 1e-11, well below stratData1's computed floor (~2e-7..6e-7),
# WITHOUT needing a degenerate basis. (A collapsed-x-span stimulus trips
# GibbsSpline's own Cholesky guard and the run dies before lambda is drawn.)
#
# Each test asserts BOTH that no draw is below the model's computed floor AND
# that the median sits within a decade of it. The second assertion is what stops
# the test passing vacuously: without truncation these draws land at ~1e-11, so
# a build lacking the floor fails the first assertion, and a build where the
# stimulus failed to bite fails the second. The floor must also equal
# .LambdaFloor recomputed from the model's own ingredients and differ from
# .LambdaMin, proving the scale-relative branch (not the fallback) is in
# force on this data.
lambdaFloorStimulus <- 1e-12

# Shared builders for the engine tests. nThreads = 1L and no parallel runs:
# the two levels multiply, and this must stay inside a 2-core budget.
# nolint start: object_usage_linter. # bindings resolve at run time.

# One stratData1 model per test, never a shared fixture: the flexible-knot
# splineBase (and so tr(D) and the computed floor) consumes ambient RNG at
# build, so each test seeds its own copy to stay independently reproducible.
buildFloorModel <- function(seed, ...) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  set.seed(seed)
  StratModel(stratData = stratData1,
             priors = stratModel1[[c("priors", "metro")]],
             alignmentScale = stratModel1[["alignmentScale"]],
             sedModel = stratModel1[["sedModel"]],
             alphaPosition = stratModel1[["alphaPosition"]],
             ...)
}

# Runs the stimulus model under one engine; returns the lambda samples and the
# floor recorded in the model. stripLambdaMin = TRUE mimics a pre-#603 saved
# model (no floor field); floorOverride plants an arbitrary field.
runWithTinyBLambda <- function(engine, seed, stripLambdaMin = FALSE,
                               floorOverride = NULL) {
  data(stratData1, package = "StratoBayes", envir = environment())
  model <- buildFloorModel(seed, bLambda = lambdaFloorStimulus)
  if (stripLambdaMin) {
    model[[c("priors", "gibbs")]][["lambdaMin"]] <- NULL
  } else if (!is.null(floorOverride)) {
    model[[c("priors", "gibbs")]][["lambdaMin"]] <- floorOverride
  }

  td <- file.path(tempdir(), paste0("lamfloor_", engine, "_",
                                    format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  args <- list(stratObject = stratData1, stratModel = model,
               nIter = 100, nChains = 2, seed = seed,
               quiet = TRUE, visualise = FALSE,
               modelDir = td, modelName = paste0("lamfloor_", engine),
               engine = engine, nThreads = 1L)
  post <- suppressWarnings(do.call(RunStratModel, args))

  samp <- post[["samples"]]
  j <- grep("^lambda", dimnames(samp)[[2]])
  sv <- StratoBayes:::.EnsurePreExtracted(stratData1)
  sv <- sv[[c("signalAttr", "signalValuesVec")]]
  list(lambda = as.numeric(samp[, j, , , drop = TRUE]),
       floor = model[[c("priors", "gibbs", "lambdaMin")]],
       floorExpected = StratoBayes:::.LambdaFloor(model[["splineBase"]], sv))
}

# Saved samples round-trip through a fixed-precision text file, so a stored
# lambda can sit one ULP below the floor actually enforced in memory.
floorTol <- function(floor) floor * (1 - 1e-12)

expectFlooredStimulus <- function(res) {
  # The stored floor is the scale-relative computation, not the .LambdaMin
  # fallback (a computed floor equals the constant only with probability 0) ...
  expect_length(res$floor, 1L)
  expect_gt(res$floor, 0)
  expect_identical(res$floor, res$floorExpected)
  expect_true(res$floor != StratoBayes:::.LambdaMin)
  # ... and every stimulated draw is held at it.
  lam <- res$lambda[is.finite(res$lambda)]
  expect_true(length(lam) > 0L)
  expect_gte(min(lam), floorTol(res$floor))
  expect_lt(stats::median(lam), 10 * res$floor)
}
# nolint end

test_that("MCMCEngine.cpp respects the computed floor", {
  # The field-critical site: this is the threaded engine's lambda draw, the one
  # that actually absorbed 18/18 runs in #551.
  skip_on_cran()
  expectFlooredStimulus(runWithTinyBLambda("cpp", 8813L))
})

test_that("Gibbs.cpp respects the computed floor (both engines' Gibbs sweep)", {
  skip_on_cran()
  expectFlooredStimulus(runWithTinyBLambda("R", 8814L))
})

test_that("a model lacking lambdaMin falls back to the absolute floor", {
  # Models saved before #603 lack priors$gibbs$lambdaMin; each engine's
  # consumption seam (sb_create_engine for "cpp"; .GibbsSample -> .sb_gibbs
  # for "R") must then enforce .LambdaMin.
  skip_on_cran()
  for (engine in c("cpp", "R")) {
    res <- runWithTinyBLambda(engine, 8815L, stripLambdaMin = TRUE)
    expect_null(res$floor, label = paste0(engine, ": stored floor"))
    lam <- res$lambda[is.finite(res$lambda)]
    expect_true(length(lam) > 0L, info = engine)
    expect_gte(min(lam), floorTol(StratoBayes:::.LambdaMin),
               label = paste0(engine, ": min(lambda)"))
    expect_lt(stats::median(lam), 10 * StratoBayes:::.LambdaMin,
              label = paste0(engine, ": median(lambda)"))
  }
})

test_that("a wrong-length lambdaMin errors instead of a silent substitute", {
  # A wrong-length floor does not describe the prior the engine would
  # enforce; each engine must refuse it loudly, never swap in a default.
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  nSig <- stratData1[[c("signalAttr", "signalN")]]
  for (engine in c("cpp", "R")) {
    expect_error(runWithTinyBLambda(engine, 8816L,
                                    floorOverride = rep(1e-6, nSig + 1L)),
                 "one value per signal")
  }
})

test_that("StratModel stores a scale-relative per-signal floor", {
  # Cheap (no MCMC), so this runs on the PR gate: pins the setup-time
  # computation the engines consume.
  data(stratData1, package = "StratoBayes", envir = environment())
  model <- buildFloorModel(603L)
  floor <- model[[c("priors", "gibbs", "lambdaMin")]]
  nSignal <- stratData1[[c("signalAttr", "signalN")]]
  expect_length(floor, nSignal)
  expect_true(all(is.finite(floor) & floor > 0))
  # On stratData1 the computed floor must be the scale-relative value, not the
  # .LambdaMin fallback, and stay far below the O(1) healthy lambda region.
  expect_true(all(floor != StratoBayes:::.LambdaMin))
  expect_true(all(floor < 1e-2))
  # And it reproduces .LambdaFloor applied to the model's own ingredients.
  sb <- model[["splineBase"]]
  d <- StratoBayes:::.EnsurePreExtracted(stratData1)
  sv <- d[[c("signalAttr", "signalValuesVec")]]
  expect_identical(floor, StratoBayes:::.LambdaFloor(sb, sv))
})
