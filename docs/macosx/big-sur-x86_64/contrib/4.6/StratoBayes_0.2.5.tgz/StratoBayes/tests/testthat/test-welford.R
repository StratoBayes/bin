# tests/testthat/test-welford.R
# Tests for Welford online covariance in mass matrix adaptation
#
# Deliberately NOT skip_on_cran(): seeded, pure-R arithmetic checked against
# R's own mean/var/cov in 0.4s. NOT_CRAN is true only on the nightly cron
# (#1026), so gating this would keep it out of the PR merge gate for no gain.

test_that(".WelfordReset zeroes all accumulators", {
  blocks <- list(
    list(idx = 1L, k = 1L, cholMat = 2, invMat = 0.5,
         wMean = 5, wM2 = 10, wN = 50L),
    list(idx = c(2L, 3L), k = 2L, cholMat = c(1, 0, 0, 1),
         invMat = c(1, 0, 0, 1),
         wMean = c(1, 2), wM2 = c(3, 4, 5, 6), wN = 20L)
  )
  reset <- StratoBayes:::.WelfordReset(blocks)
  expect_equal(reset[[1]]$wMean, 0)
  expect_equal(reset[[1]]$wM2, 0)
  expect_equal(reset[[1]]$wN, 0L)
  expect_equal(reset[[2]]$wMean, c(0, 0))
  expect_equal(reset[[2]]$wM2, c(0, 0, 0, 0))
  expect_equal(reset[[2]]$wN, 0L)
  # cholMat/invMat should be untouched

  expect_equal(reset[[1]]$cholMat, 2)
  expect_equal(reset[[2]]$invMat, c(1, 0, 0, 1))
})

test_that(".WelfordUpdateBlocks matches base::var for scalar block", {
  set.seed(4729)
  x <- rnorm(200, mean = 5, sd = 3)
  mat <- matrix(x, ncol = 1)

  blocks <- list(list(idx = 1L, k = 1L, cholMat = 1, invMat = 1,
                      wMean = 0, wM2 = 0, wN = 0L))
  blocks <- StratoBayes:::.WelfordUpdateBlocks(blocks, mat)

  expect_equal(blocks[[1]]$wN, 200L)
  expect_equal(blocks[[1]]$wMean, mean(x), tolerance = 1e-10)
  welford_var <- blocks[[1]]$wM2 / (blocks[[1]]$wN - 1L)
  expect_equal(welford_var, var(x), tolerance = 1e-10)
})

test_that(".WelfordUpdateBlocks matches stats::cov for 2D block", {
  set.seed(6831)
  n <- 300
  mat <- cbind(rnorm(n, 2, 1.5), rnorm(n, -1, 0.8))
  # Induce correlation
  mat[, 2] <- mat[, 2] + 0.6 * mat[, 1]

  blocks <- list(list(idx = c(1L, 2L), k = 2L,
                      cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                      wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L))
  blocks <- StratoBayes:::.WelfordUpdateBlocks(blocks, mat)

  expect_equal(blocks[[1]]$wN, n)
  expect_equal(blocks[[1]]$wMean, colMeans(mat), tolerance = 1e-10)

  welford_cov <- matrix(blocks[[1]]$wM2, 2, 2) / (n - 1L)
  expect_equal(welford_cov, cov(mat), tolerance = 1e-10)
})

test_that("Welford accumulates incrementally (same result as batch)", {
  set.seed(3185)
  n <- 200
  mat <- cbind(rnorm(n, 0, 2), rnorm(n, 3, 1))

  # Batch: all at once
  blocks_batch <- list(list(idx = c(1L, 2L), k = 2L,
                            cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                            wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L))
  blocks_batch <- StratoBayes:::.WelfordUpdateBlocks(blocks_batch, mat)

  # Incremental: 3 chunks
  blocks_inc <- list(list(idx = c(1L, 2L), k = 2L,
                          cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                          wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L))
  blocks_inc <- StratoBayes:::.WelfordUpdateBlocks(blocks_inc, mat[1:70, , drop = FALSE])
  blocks_inc <- StratoBayes:::.WelfordUpdateBlocks(blocks_inc, mat[71:150, , drop = FALSE])
  blocks_inc <- StratoBayes:::.WelfordUpdateBlocks(blocks_inc, mat[151:200, , drop = FALSE])

  expect_equal(blocks_inc[[1]]$wN, blocks_batch[[1]]$wN)
  expect_equal(blocks_inc[[1]]$wMean, blocks_batch[[1]]$wMean, tolerance = 1e-10)
  expect_equal(blocks_inc[[1]]$wM2, blocks_batch[[1]]$wM2, tolerance = 1e-10)
})

test_that(".AdaptMassBlocks produces correct chol and inv from Welford state", {
  set.seed(9014)
  n <- 500
  mat <- cbind(rnorm(n, 0, 2), rnorm(n, 0, 0.5))
  mat[, 2] <- mat[, 2] + 0.8 * mat[, 1]

  blocks <- list(list(idx = c(1L, 2L), k = 2L,
                      cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
                      wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L))
  blocks <- StratoBayes:::.WelfordUpdateBlocks(blocks, mat)
  blocks <- StratoBayes:::.AdaptMassBlocks(blocks)

  # RT-162: the inverse mass matrix M^{-1} (= invMat) equals the empirical
  # covariance Sigma; the mass matrix M (= L L^T) equals Sigma^{-1}.
  Minv <- matrix(blocks[[1]]$invMat, 2, 2)
  expected_cov <- cov(mat) + diag(1e-10, 2)
  expect_equal(Minv, expected_cov, tolerance = 1e-6)

  # cholMat factors M = Sigma^{-1}, so M * Minv = I
  L <- matrix(blocks[[1]]$cholMat, 2, 2)
  M <- L %*% t(L)
  expect_equal(M %*% Minv, diag(2), tolerance = 1e-6)
})

test_that(".AdaptMassBlocks handles k=1 blocks correctly", {
  set.seed(2287)
  x <- rnorm(100, 3, 2)
  mat <- matrix(x, ncol = 1)

  blocks <- list(list(idx = 1L, k = 1L, cholMat = 1, invMat = 1,
                      wMean = 0, wM2 = 0, wN = 0L))
  blocks <- StratoBayes:::.WelfordUpdateBlocks(blocks, mat)
  blocks <- StratoBayes:::.AdaptMassBlocks(blocks)

  # RT-162: M^{-1} (= invMat) is the empirical variance; M (= cholMat^2) is
  # its reciprocal.
  expected_var <- var(x)
  expect_equal(blocks[[1]]$invMat, expected_var, tolerance = 1e-10)
  expect_equal(blocks[[1]]$cholMat, 1 / sqrt(expected_var), tolerance = 1e-10)
})

test_that(".WelfordUpdateBlocks with empty input is a no-op", {
  blocks <- list(list(idx = 1L, k = 1L, cholMat = 1, invMat = 1,
                      wMean = 5, wM2 = 10, wN = 20L))
  empty_mat <- matrix(numeric(0), nrow = 0, ncol = 1)
  result <- StratoBayes:::.WelfordUpdateBlocks(blocks, empty_mat)
  expect_equal(result[[1]]$wN, 20L)
  expect_equal(result[[1]]$wMean, 5)
  expect_equal(result[[1]]$wM2, 10)
})

test_that("mixed block sizes work together", {
  set.seed(7742)
  n <- 150
  mat <- cbind(rnorm(n, 1, 2), rnorm(n, -1, 3), rnorm(n, 5, 0.5))
  mat[, 2] <- mat[, 2] + 0.5 * mat[, 1]

  blocks <- list(
    # 2D block for cols 1-2
    list(idx = c(1L, 2L), k = 2L,
         cholMat = c(1, 0, 0, 1), invMat = c(1, 0, 0, 1),
         wMean = c(0, 0), wM2 = c(0, 0, 0, 0), wN = 0L),
    # 1D block for col 3
    list(idx = 3L, k = 1L, cholMat = 1, invMat = 1,
         wMean = 0, wM2 = 0, wN = 0L)
  )

  blocks <- StratoBayes:::.WelfordUpdateBlocks(blocks, mat)
  blocks <- StratoBayes:::.AdaptMassBlocks(blocks)

  # 2D block covariance
  welford_cov <- matrix(blocks[[1]]$wM2, 2, 2) / (n - 1)
  expect_equal(welford_cov, cov(mat[, 1:2]), tolerance = 1e-10)

  # 1D block variance
  welford_var <- blocks[[2]]$wM2 / (n - 1)
  expect_equal(welford_var, var(mat[, 3]), tolerance = 1e-10)
})
