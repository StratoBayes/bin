# A swap between adjacent rungs is accepted on Delta(1/T) . Delta E, so what
# governs whether the ladder is connected is the span per rung,
# `Tmax^(1 / (nChains - 1))`, not the chain count. A ladder at span 3.38 has a
# worst adjacent link of 0.008 (#981): cut in two, so a mode found by a hot
# chain never reaches the cold chain the user reports.
#
# The span a dataset can afford is not a constant, so 1.9 bounds a span rather
# than marking a threshold: across 13 datasets at an identical 1.87, the worst
# interior link still ranges 2959-fold (#982). These tests pin the bound, never
# a claim that the bound suffices.

test_that(".LadderTmax bounds the span per rung at 1.9", {
  nChains <- 2:40
  span <- vapply(nChains, function(n) .LadderTmax(n) ^ (1 / (n - 1)), double(1))
  expect_true(all(span <= 1.9 + 1e-12))
})

test_that(".LadderTmax pins the shipped and stress chain counts", {
  expect_equal(.LadderTmax(2), 1.9)
  expect_equal(.LadderTmax(4), 1.9 ^ 3)
  # nChains = 8 is where the 80 cap first binds: 1.9^7 is 89.4, so the span
  # rule alone would over-heat the top rung here.
  expect_equal(.LadderTmax(8), 80)
  # Beyond 8 chains extra rungs buy density, never heat: 1.9^23 is ~2.6e6, a
  # span no end metric has scored, whereas 80 is the measured winner at 24.
  expect_equal(.LadderTmax(24), 80)
})

test_that(".LadderTmax never cools below the target temperature", {
  expect_true(all(vapply(2:40, .LadderTmax, double(1)) > 1))
})

test_that("the default ladder tops out at a finite rung", {
  # No Inf rung to waste a chain on, and a top rung the span rule can bound.
  for (nChains in c(2L, 3L, 8L, 24L)) {
    temperatures <- .TemperatureLadder(NULL, nChains)
    expect_length(temperatures, nChains)
    expect_true(all(is.finite(temperatures)))
    expect_identical(temperatures[[nChains]], .LadderTmax(nChains))
  }
})

test_that("the default ladder is a valid ladder at every chain count", {
  for (nChains in 2:24) {
    temperatures <- .TemperatureLadder(NULL, nChains)
    expect_identical(temperatures[[1]], 1)
    expect_false(is.unsorted(temperatures, strictly = TRUE))
  }
})

test_that("the default ladder keeps its per-run jitter", {
  # Deliberate: runs should not all start from an identical ladder. The jitter
  # is on the relative rung spacing only, so it must not move the top rung.
  set.seed(1)
  first <- .TemperatureLadder(NULL, 8L)
  second <- .TemperatureLadder(NULL, 8L)
  expect_false(isTRUE(all.equal(first, second)))
  expect_identical(first[[8]], second[[8]])
  expect_identical(first[[1]], second[[1]])
})

test_that("the jitter stays small enough to leave the span bounded", {
  # The rescaling pins the endpoints, so an outlying draw can only redistribute
  # rungs within the ladder -- but a big enough one would starve a link.
  set.seed(2)
  spans <- replicate(50, max(diff(log(.TemperatureLadder(NULL, 8L)))))
  expect_true(all(exp(spans) < 2.5))
})

test_that("StratMCMC resolves an all-finite default ladder", {
  mcmc <- StratMCMC(stratModel = stratModel1, nIter = 10, nChains = 8)
  temperatures <- mcmc[[c("temper", "temperatures")]]
  expect_true(all(is.finite(temperatures)))
  expect_identical(temperatures[[8]], 80)
})

test_that("StratMCMC() flags every chain of the default ladder for adaptation", {
  # Construction time only -- `StratMCMC()` runs no sampler, so this pins the
  # flag the loop will later read, not any adaptation that happened.
  # `adaptProposal` is switched off for non-finite rungs, so an all-finite
  # ladder brings the hottest chain into proposal adaptation.
  mcmc <- StratMCMC(stratModel = stratModel1, nIter = 10, nChains = 8,
                    adaptProposal = TRUE)
  expect_length(mcmc[[c("metro", "adaptProposal")]], 8)
  expect_true(all(mcmc[[c("metro", "adaptProposal")]]))
})
