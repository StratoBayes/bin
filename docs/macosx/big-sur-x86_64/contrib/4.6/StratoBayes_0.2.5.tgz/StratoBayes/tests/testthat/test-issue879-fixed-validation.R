# Regression test for RT-693 (#879): `Fixed()` was the only prior constructor
# with no argument validation, so `Fixed(NA_real_)` and `Fixed(Inf)` both
# construct and pass `.PriorsValidity()`, silently pinning a parameter at a
# value that makes every downstream age conversion non-finite.

test_that("Fixed() rejects NA and non-finite values (RT-693, #879)", {
  expect_error(Fixed(NA_real_), "'value' must not be NA")
  expect_error(Fixed(Inf), "value")
  expect_error(Fixed(-Inf), "value")
})

test_that("Fixed() rejects non-scalar values (RT-693, #879)", {
  expect_error(Fixed(c(1, 2)), "'value' must be a single")
})

test_that("Fixed() still accepts an ordinary finite scalar", {
  expect_s3_class(Fixed(3), "Prior")
})
