# Component-selective ("partial", temperingComponents = "signal") tempering.
#
# Proven invariant (dev/red-team/proofs/partial-tempering-correctness.md §1): at
# T = 1 every partial formula reduces to the full-tempering formula, so a single
# cold chain must produce a BIT-IDENTICAL trace under "full" and "signal". This is
# the regression guarantee that the reported (cold-chain) posterior is unchanged.
#
# Comparisons are RELATIVE (full vs signal, same seed, same machine) so they are
# platform-portable; runs are nThreads = 1 because the engine is intentionally
# non-deterministic across threads (RNG stream partition). Raw samples (r$samples,
# pre-clustering) are compared so the deterministic MCMC trace is tested directly,
# not the post-hoc clustering/summary. A discarded warmup run absorbs a one-time
# first-call effect (the first RunStratModel in a session differs from later ones).

.pt_raw <- function(tc, flex) {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = flex)
  mc <- StratMCMC(sm, nIter = 200L, nChains = 1L, nThin = 1L, nThreads = 1L,
                  tempering = FALSE, temperingComponents = tc,
                  # Fixed knots no longer register NUTS on their own: #526 made
                  # `gradientProposals = "auto"` equivalent to "off". Without
                  # this the "NUTS proposals" test below silently ran MH and
                  # duplicated the MH test.
                  gradientProposals = if (flex) "auto" else "on",
                  adaptProposal = FALSE)
  RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                visualise = FALSE, seed = 1L)$samples[, , 1, 1]
}

test_that("partial tempering is bit-identical to full at T=1 (MH proposals)", {
  skip_on_cran()
  invisible(.pt_raw("full", TRUE))            # warmup (discard first-call effect)
  f <- .pt_raw("full", TRUE)
  s <- .pt_raw("signal", TRUE)
  expect_equal(dim(f), dim(s))
  # identical(), not a tolerance: at T=1 tempered_energy multiplies by exactly
  # 1.0, so the two paths are the same arithmetic. A tolerance would admit a
  # mis-scaled component too small to see — which is how RT-302 hid.
  expect_identical(as.numeric(f), as.numeric(s))
})

test_that("partial tempering is bit-identical to full at T=1 (NUTS proposals)", {
  skip_on_cran()
  # flexibleKnots = FALSE enables the gradient-based NUTS proposal path.
  invisible(.pt_raw("full", FALSE))           # warmup
  f <- .pt_raw("full", FALSE)
  s <- .pt_raw("signal", FALSE)
  expect_equal(dim(f), dim(s))
  expect_identical(as.numeric(f), as.numeric(s))
})

test_that("partial tempering runs multi-chain (tempered) without error", {
  skip_on_cran()
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                   sigmaFixed = TRUE, flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 200L, nChains = 4L, nThin = 1L, nThreads = 2L,
                  tempering = TRUE, temperingComponents = "signal",
                  adaptProposal = FALSE)
  r <- RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                     visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

test_that("temperingComponents rejects invalid values", {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE)
  expect_error(
    StratMCMC(sm, nIter = 10L, nChains = 2L, temperingComponents = "banana"),
    "should be one of"
  )
})

# RT-303: a continued run rebuilds the StratMCMC object via StratMCMC(), which
# defaults temperingComponents = "full", so .UpdateMCMCforContinuedRun must carry
# the original mask across — otherwise a resumed partial run silently reverts to
# full tempering. Tested at the fix site with real StratMCMC objects
# (adaptProposal = FALSE keeps the history-transfer block inert).
test_that("continued run preserves the tempering mask (RT-303)", {
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE)
  mcNew <- StratMCMC(sm, nIter = 100L, nChains = 4L, tempering = TRUE,
                     temperingComponents = "full", adaptProposal = FALSE)
  expect_equal(mcNew[["temper"]][["mask"]], 15L)

  # Every subset must survive the rebuild, including "ties"/"signal+ties" which
  # the retired signalOnly flag could not represent at all.
  expectedMask <- c("signal" = 2L, "ties" = 4L, "signal+ties" = 6L)
  for (tc in names(expectedMask)) {
    # stratData1 has no ties, so the ties-selecting masks warn that they are a
    # no-op; mask carry-over is what is under test here, and it is mask-agnostic.
    mcOld <- suppressWarnings(
      StratMCMC(sm, nIter = 100L, nChains = 4L, tempering = TRUE,
                temperingComponents = tc, adaptProposal = FALSE))
    expect_equal(mcOld[["temper"]][["mask"]], expectedMask[[tc]], label = tc)
    updated <- StratoBayes:::.UpdateMCMCforContinuedRun(mcOld, mcNew,
                                                       newRun = FALSE)
    # 15 (mcNew's default) pre-fix — a silent revert to full tempering.
    expect_equal(updated[["temper"]][["mask"]], expectedMask[[tc]], label = tc)
  }

  # An object carrying no mask must not clobber the rebuilt object's.
  mcNoMask <- mcNew
  mcNoMask[["temper"]][["mask"]] <- NULL
  expect_equal(
    StratoBayes:::.UpdateMCMCforContinuedRun(mcNoMask, mcNew,
                                             newRun = FALSE)[["temper"]][["mask"]],
    15L
  )
})

# RT-304: temperature-ladder adaptation must tune against the SAME energy the
# replica swap uses — the tempered-component sum, surfaced by the ring buffer as
# swapEnergy. Exercises the adaptTemperatures path under a partial mask
# end-to-end (pre-fix R had no access to that energy at all).
test_that("partial tempering adapts the temperature ladder without error (RT-304)", {
  skip_on_cran()
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE,
                   flexibleKnots = TRUE)
  mc <- StratMCMC(sm, nIter = 400L, nChains = 4L, nThin = 1L, nThreads = 2L,
                  tempering = TRUE, temperingComponents = "signal",
                  adaptTemperatures = TRUE, adaptProposal = FALSE)
  r <- RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                     visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

# RT-305: temperingComponents must be reachable through RunStratModel (not only by
# hand-building a StratMCMC object). Pre-fix it was neither a formal nor forwarded,
# so this call raised "unused argument".
test_that("RunStratModel exposes and forwards temperingComponents (RT-305)", {
  skip_on_cran()
  expect_true("temperingComponents" %in% names(formals(RunStratModel)))
  sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                   sedModel = "site", nKnots = 10, sigmaFixed = TRUE,
                   flexibleKnots = TRUE)
  r <- RunStratModel(stratData1, sm, temperingComponents = "signal",
                     nIter = 200L, nChains = 4L, nThin = 1L, nThreads = 2L,
                     tempering = TRUE, adaptProposal = FALSE,
                     nRun = 1L, runParallel = FALSE, visualise = FALSE, seed = 1L)
  expect_true(is.finite(summary(r)[[1]][["summary"]]["log posterior", "mean"]))
})

# Component-selective tempering generalises to an arbitrary subset (mask over
# logPostSep = [prior, signal, ties, overlap]). "ties" tempers component [2] only,
# "signal+ties" tempers {1,2}. The T=1 identity is mask-invariant: at a single cold
# chain tempered_energy(sep, 1, mask) = sum(sep) = logPost for EVERY mask, so all
# subsets must give a BIT-IDENTICAL trace to "full".
test_that("all tempering subsets are bit-identical to full at T=1 (MH proposals)", {
  skip_on_cran()
  invisible(.pt_raw("full", TRUE))            # warmup
  f <- .pt_raw("full", TRUE)
  for (tc in c("signal", "ties", "signal+ties")) {
    x <- .pt_raw(tc, TRUE)
    expect_equal(dim(f), dim(x))
    expect_identical(as.numeric(f), as.numeric(x),
                     label = paste0("T=1 trace for temperingComponents='", tc, "'"))
  }
})

# Stage A: gradient (HMC/NUTS) component-selective tempering is implemented for
# "signal" only; "ties"/"signal+ties" are MH-only and MUST error (not silently
# temper the wrong component) when a NUTS proposal is registered (flexibleKnots =
# FALSE). "full"/"signal" must still run under NUTS.
test_that("non-signal subsets error under NUTS; full/signal run (Stage A guard)", {
  skip_on_cran()
  runNUTS <- function(tc) {
    sm <- StratModel(stratData1, priors = stratPrior1, alignmentScale = "height",
                     sedModel = "site", alphaPosition = "bottom", nKnots = 10,
                     sigmaFixed = TRUE, flexibleKnots = FALSE)
    # `gradientProposals = "on"` is load-bearing: since #526 fixed knots alone no
    # longer register NUTS, so without it the guard under test never fires.
    mc <- suppressWarnings(
      StratMCMC(sm, nIter = 400L, nChains = 2L, nThreads = 1L, tempering = TRUE,
                temperingComponents = tc, gradientProposals = "on",
                adaptProposal = TRUE))
    RunStratModel(stratData1, sm, mc, nRun = 1L, runParallel = FALSE,
                  visualise = FALSE, seed = 1L, quiet = TRUE)
  }
  expect_error(runNUTS("ties"), "MH-only")
  expect_error(runNUTS("signal+ties"), "MH-only")
  rSig <- runNUTS("signal")                      # signal gradient path still works
  expect_true(is.finite(summary(rSig)[[1]][["summary"]]["log posterior", "mean"]))
})

# Tempering a component the model does not have divides an identically-zero term
# by T, so the "tempered" ladder samples the cold posterior in every chain and
# accepts every swap -- at nChains times the cost, and undetectably, since the
# ladder's own adaptation sees equal energies and holds still. stratData1 carries
# no ties; stratData2 does.
test_that("a tempering mask selecting an absent component warns (no-op mask)", {
  mkModel <- function(data, priors, scale) {
    StratModel(data, priors = priors, alignmentScale = scale, sedModel = "site",
               nKnots = 10, sigmaFixed = TRUE, flexibleKnots = TRUE)
  }
  noTies <- mkModel(stratData1, stratPrior1, "height")
  withTies <- mkModel(stratData2, stratPrior2, "age")
  expect_true(is.null(noTies[["tiesActive"]]))    # the condition being warned about
  expect_true(any(as.logical(withTies[["tiesActive"]])))

  mc <- function(model, tc, tempering = TRUE, nChains = 4L) {
    StratMCMC(model, nIter = 100L, nChains = nChains, tempering = tempering,
              temperingComponents = tc, adaptProposal = FALSE)
  }
  expect_warning(mc(noTies, "ties"), "no active ties")
  expect_warning(mc(noTies, "signal+ties"), 'equivalent to "signal"')

  # Masks that select a component the model HAS must stay silent.
  expect_no_warning(mc(noTies, "signal"))
  expect_no_warning(mc(noTies, "full"))
  expect_no_warning(mc(withTies, "ties"))
  expect_no_warning(mc(withTies, "signal+ties"))

  # The warning is about a tempered ladder, so it must not fire where there is
  # no ladder to be a no-op on.
  expect_no_warning(mc(noTies, "ties", tempering = FALSE))
  expect_no_warning(mc(noTies, "ties", nChains = 1L))
})

# The premise of that warning -- that the ties component is identically 0 on a
# tie-free model, so dividing it by T changes nothing -- is pinned against the
# engine in test-cpp-engine-guards.R, where the engine helper lives.
