# Issue #129: convergence-based early termination.
#
# The decision logic is exercised here against hand-written files rather than
# through a real run: every branch -- including the ones that only occur when a
# peer is mid-write -- is reachable without spawning a worker, and the result
# is deterministic, so these run on every PR.

CsDraws <- function(n = 400, seed = 1, offset = 0, nCol = 2) {
  set.seed(seed)
  m <- matrix(stats::rnorm(n * nCol) + offset, n, nCol)
  colnames(m) <- paste0("p", seq_len(nCol))
  m
}

CsWrite <- function(dir, run, draws, iters = seq_len(nrow(draws)),
                    endAdapting = 0, name = "m") {
  .WriteConvergenceDraws(dir, name, run, draws, iters, endAdapting)
}

# ── criteria validation ──────────────────────────────────────────────────────

test_that("convergenceStop is validated, and FALSE disables it", {
  expect_null(.ConvergenceCriteria(FALSE))
  expect_null(.ConvergenceCriteria(NULL))

  expect_identical(.ConvergenceCriteria(list(rHat = 1.02)),
                   list(rHat = 1.02, ess = NULL))
  expect_identical(.ConvergenceCriteria(list(ess = 400)),
                   list(rHat = NULL, ess = 400))

  expect_error(.ConvergenceCriteria(list()), "at least one")
  # A validly named list whose only entry is NULL leaves nothing binding, so
  # every candidate burn-in would qualify -- the opposite of what it reads as.
  expect_error(.ConvergenceCriteria(list(rHat = NULL)), "at least one")
  expect_error(.ConvergenceCriteria(list(1.02)), "named list")
  expect_error(.ConvergenceCriteria(1.02), "named list")
  expect_error(.ConvergenceCriteria(list(foo = 1)), "rHat")
  # R-hat is bounded below by 1, so a threshold at or under it can never bind.
  expect_error(.ConvergenceCriteria(list(rHat = 1)), "greater than 1")
  expect_error(.ConvergenceCriteria(list(rHat = NA_real_)), "greater than 1")
  expect_error(.ConvergenceCriteria(list(ess = 0)), "at least 1")
})

# ── the sentinel ─────────────────────────────────────────────────────────────

test_that("the stop sentinel is written, seen and cleared", {
  dir <- withr::local_tempdir()

  expect_false(.StopSentinelExists(dir, "m"))
  .WriteStopSentinel(dir, "m")
  expect_true(.StopSentinelExists(dir, "m"))
  .ClearStopSentinel(dir, "m")
  expect_false(.StopSentinelExists(dir, "m"))

  # Clearing an absent sentinel is a no-op, not an error.
  expect_silent(.ClearStopSentinel(dir, "m"))
})

# ── gathering peers ──────────────────────────────────────────────────────────

test_that("a complete set of peers is gathered and trimmed to shared iterations", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1), endAdapting = 50)
  CsWrite(dir, 2, CsDraws(n = 250, seed = 2), endAdapting = 70)

  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  expect_length(set[["drawList"]], 2L)
  # Trimmed to the iterations both runs reached, so R-hat compares like with
  # like rather than one run's tail against the other's middle.
  expect_identical(nrow(set[["drawList"]][[1]]), 250L)
  expect_identical(nrow(set[["drawList"]][[2]]), 250L)
  expect_identical(set[["floorIter"]], 70)
})

test_that("an incomplete or damaged peer defers the decision", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws())

  # Peer 2 has not written yet.
  expect_null(.ConvergenceDrawSet(dir, "m", run = 1, nRun = 2))

  # Peer 2 caught mid-write: present but not readable.
  writeBin(raw(0), .ConvergenceDrawsPath(dir, "m", 2))
  expect_null(.ConvergenceDrawSet(dir, "m", run = 1, nRun = 2))

  # Peer 2 readable but structurally wrong.
  saveRDS(list(run = 2, draws = "not a matrix", iters = 1:10, endAdapting = 0),
          .ConvergenceDrawsPath(dir, "m", 2))
  expect_null(.ConvergenceDrawSet(dir, "m", run = 2, nRun = 2))

  # Rows and labels disagreeing is the silent-corruption shape, not a crash.
  saveRDS(list(run = 2, draws = CsDraws(), iters = 1:10, endAdapting = 0),
          .ConvergenceDrawsPath(dir, "m", 2))
  expect_null(.ConvergenceDrawSet(dir, "m", run = 2, nRun = 2))
})

test_that("runs sharing no iterations defer rather than compare nothing", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(n = 100), iters = seq(1, 199, by = 2))
  CsWrite(dir, 2, CsDraws(n = 100, seed = 2), iters = seq(2, 200, by = 2))

  expect_null(.ConvergenceDrawSet(dir, "m", run = 1, nRun = 2))
})

test_that("a single run is assessed on its own draws", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws())

  # crossRun = FALSE never looks for peers, so a sequential run is not blocked
  # by runs that have not started.
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 4, crossRun = FALSE)
  expect_length(set[["drawList"]], 1L)
})

test_that("dyadic thinning levels still align exactly", {
  # A run that has thinned further saves a subset of the finer grid, so the
  # coarser labels are shared and no interpolation is needed.
  dir <- withr::local_tempdir()
  fine <- CsDraws(n = 200, seed = 1)
  coarse <- CsDraws(n = 100, seed = 2)
  CsWrite(dir, 1, fine, iters = seq(2, 400, by = 2))
  CsWrite(dir, 2, coarse, iters = seq(4, 400, by = 4))

  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)
  expect_identical(nrow(set[["drawList"]][[1]]), 100L)
  expect_identical(nrow(set[["drawList"]][[2]]), 100L)
  expect_identical(set[["iterList"]][[1]], seq(4, 400, by = 4))
})

# ── the decision ─────────────────────────────────────────────────────────────

test_that("agreeing runs meet the criteria and disagreeing ones do not", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1))
  CsWrite(dir, 2, CsDraws(seed = 2))
  agree <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)
  expect_true(.ConvergenceCriteriaMet(agree, list(rHat = 1.02, ess = NULL)))

  apart <- withr::local_tempdir()
  CsWrite(apart, 1, CsDraws(seed = 1))
  CsWrite(apart, 2, CsDraws(seed = 2, offset = 20))
  stuck <- .ConvergenceDrawSet(apart, "m", run = 1, nRun = 2)
  expect_false(.ConvergenceCriteriaMet(stuck, list(rHat = 1.02, ess = NULL)))
})

test_that("an unreachable criterion never fires", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1))
  CsWrite(dir, 2, CsDraws(seed = 2))
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  expect_false(.ConvergenceCriteriaMet(set, list(ess = 1e9)))
  # Both must hold, not either.
  expect_false(.ConvergenceCriteriaMet(set, list(rHat = 1.02, ess = 1e9)))
})

test_that("a tiny R-hat threshold is not the way to make the rule strict", {
  # The rule takes the *minimum* R-hat over ~19 candidate burn-ins, so on
  # well-mixed draws a threshold barely above 1 is reachable by chance. That
  # multiple-comparisons bias is why stopping additionally requires the
  # criterion to hold at two consecutive checkpoints; do not read a very small
  # `rHat` as a strict rule.
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1))
  CsWrite(dir, 2, CsDraws(seed = 2))
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  expect_true(.ConvergenceCriteriaMet(set, list(rHat = 1.0000001)))
  expect_gte(.kConvergenceStreak, 2L)
})

test_that("an absent criterion does not bind", {
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1))
  CsWrite(dir, 2, CsDraws(seed = 2))
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  # ESS alone, with a target these draws clear easily.
  expect_true(.ConvergenceCriteriaMet(set, list(ess = 50)))
})

test_that("the decision fails closed on anything it cannot assess", {
  expect_false(.ConvergenceCriteriaMet(NULL, list(rHat = 1.02)))
  expect_false(.ConvergenceCriteriaMet(list(), NULL))

  # Too few retained draws to split.
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(n = 6))
  CsWrite(dir, 2, CsDraws(n = 6, seed = 2))
  tiny <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)
  expect_false(.ConvergenceCriteriaMet(tiny, list(rHat = 1.02)))
})

test_that("no burn-in inside the adaptation window can satisfy the rule (#260)", {
  # With the floor above every stored iteration, nothing is admissible however
  # well the chains agree.
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(seed = 1), endAdapting = 1e6)
  CsWrite(dir, 2, CsDraws(seed = 2), endAdapting = 1e6)
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  expect_identical(set[["floorIter"]], 1e6)
  expect_false(.ConvergenceCriteriaMet(set, list(rHat = 1.02)))
})

test_that("writing draws is atomic and leaves no temporary behind", {
  dir <- withr::local_tempdir()
  path <- CsWrite(dir, 1, CsDraws())

  expect_true(file.exists(path))
  expect_false(file.exists(paste0(path, ".tmp")))

  CsWrite(dir, 1, CsDraws(n = 50, seed = 5))
  expect_identical(nrow(readRDS(path)[["draws"]]), 50L)
  expect_false(file.exists(paste0(path, ".tmp")))
})

test_that("the write still lands when rename refuses to overwrite", {
  # Windows can refuse to rename onto an existing file (and OneDrive or a
  # virus scanner can hold one transiently). That fallback never runs on a
  # machine where rename succeeds, so force it.
  skip_if_not_installed("testthat", "3.2.0")
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(n = 20))
  path <- .ConvergenceDrawsPath(dir, "m", 1)

  testthat::local_mocked_bindings(
    file.rename = function(from, to) FALSE, .package = "base")

  CsWrite(dir, 1, CsDraws(n = 33, seed = 7))

  # The copy fallback ran: the new content is there and nothing is left over.
  expect_identical(nrow(readRDS(path)[["draws"]]), 33L)
  expect_false(file.exists(paste0(path, ".tmp")))
})

test_that("a checkpoint reports how close the run came", {
  # The short-circuit search abandons a candidate at the parameter that refutes
  # it, so a failed checkpoint used to carry no numbers at all.
  dir <- withr::local_tempdir()
  CsWrite(dir, 1, CsDraws(200, offset = 0))
  CsWrite(dir, 2, CsDraws(200, seed = 2, offset = 8))
  set <- .ConvergenceDrawSet(dir, "m", run = 1, nRun = 2)

  # The property the display rests on, and the only one that survives the
  # shortcuts: a reading that refuted lies on the failing side of its own
  # threshold, so no criterion can be shown as met when it was not. It is *not*
  # the aggregate, and not comparable with what a full search would report --
  # an early break can leave the better-mixing candidates unvisited.
  stuck <- .ConvergenceAssess(set, list(rHat = 1.02, ess = 200))
  expect_false(identical(stuck[["status"]], "ok"))
  expect_true(is.finite(stuck[["rHat"]]))
  expect_gt(stuck[["rHat"]], 1.02)

  # Nothing is abandoned on a candidate that succeeds, so a converged run does
  # report its true aggregate.
  CsWrite(dir, 1, CsDraws(200, seed = 1), name = "a")
  CsWrite(dir, 2, CsDraws(200, seed = 2), name = "a")
  agree <- .ConvergenceDrawSet(dir, "a", run = 1, nRun = 2)
  ok <- .ConvergenceAssess(agree, list(rHat = 1.02))
  expect_identical(ok[["status"]], "ok")
  expect_lte(ok[["rHat"]], 1.02)
})

test_that("the progress string names only the criteria that bind", {
  store <- list(rHat = 1.0734, ess = 142.6)

  expect_identical(.ConvergenceProgress(store, list(rHat = 1.02, ess = 200)),
                   "R-hat 1.073/1.02, ESS 143/200")
  expect_identical(.ConvergenceProgress(store, list(rHat = 1.02)),
                   "R-hat 1.073/1.02")
  expect_identical(.ConvergenceProgress(store, list(ess = 200)), "ESS 143/200")

  # Before the first checkpoint, and with the rule off, there is nothing to say.
  expect_identical(.ConvergenceProgress(.ConvergenceStore(),
                                        list(rHat = 1.02, ess = 200)), "")
  expect_identical(.ConvergenceProgress(store, NULL), "")
  # An R-hat that could not be computed is omitted rather than printed as NA.
  expect_identical(.ConvergenceProgress(list(rHat = NA_real_, ess = 142.6),
                                        list(rHat = 1.02, ess = 200)),
                   "ESS 143/200")
})
