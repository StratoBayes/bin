# ── RT-648 / #828: the -Inf log-posterior clamp on the HMC and NUTS paths ────
#
# Every R-engine transition stores the post-Gibbs β-marginal in
# `state$metro$logPost`, and that value is the OLD side of the NEXT iteration's
# MH ratio. `.AcceptProposal` treats `logPostOld == -Inf` as "escape from a bad
# state" and accepts unconditionally, so an unclamped -Inf left by a gradient
# iteration silently forces the following MH proposal through whatever its true
# ratio was. `.UpdateState` (R/ModelFunctions.R step 8) and
# `.GenerateInitialState` clamp to the -1e30 sentinel for exactly this reason,
# and so must the two gradient transitions. The C++ engine never emits -Inf
# here at all (`compute_logpost` returns the sentinel directly), so an
# unclamped R value is a divergence inside the maintained-parity MH accept
# core, not a Tier-2 gradient-sampler difference.
#
# `.LogPost` is mocked rather than driven to -Inf through the model: within
# these two functions it is called only at the four post-sweep refresh sites
# (R/HMCFunctions.R), so the mock reaches the clamp and nothing else — the
# leapfrog/tree build runs on the C++ gradient engine and the Gibbs sweep does
# not consult it. Each test pairs the mocked call with an unmocked control, so
# a fixture that stopped producing the branch would fail rather than pass
# vacuously.

.rt648NegInf <- function(...) c(-Inf, NA_real_, NA_real_, NA_real_)

.rt648TempDir <- function(prefix) {
  td <- file.path(tempdir(), paste0(prefix, format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  td
}

.rt648Setup <- function(td) {
  e <- new.env()
  utils::data("stratData1", "stratModel1", package = "StratoBayes", envir = e)
  sData <- e[["stratData1"]]
  base <- e[["stratModel1"]]
  sModel <- StratoBayes::StratModel(
    stratData = sData, priors = base[["priors"]][["metro"]],
    alignmentScale = base[["alignmentScale"]],
    sedModel = base[["sedModel"]],
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  set.seed(6481)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel, gradientProposals = "on",
    nIter = 10, nChains = 1, seed = 1, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "rt648", engine = "R", nThreads = 1L
  )
  mcmc <- readRDS(file.path(td, "rt648_mcmc_run_1.rds"))
  model <- result[["model"]]
  if (is.null(model[[".logpost_cpp"]])) {
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  list(data = result[["data"]], model = model, mcmc = mcmc,
       state = mcmc[["recentState"]][[1]],
       propIdx = which(names(mcmc[["propose"]]) %in% c("HMC", "NUTS"))[[1]])
}

# Install `args` for the gradient proposal on every chain.
.rt648WithArgs <- function(mcmc, propIdx, args) {
  for (ch in seq_along(mcmc[[c("metro", "proposalArgs")]])) {
    mcmc[[c("metro", "proposalArgs")]][[ch]][[propIdx]] <- args
  }
  mcmc
}

# The defect this clamp exists to prevent, expressed at the consumer: a stored
# -Inf accepts the next MH proposal however bad it is, whereas the sentinel
# rejects the same one (exp(-1e30) underflows to 0, no RNG draw needed).
.rt648AcceptsAWorseProposal <- function(logPostOld) {
  StratoBayes:::.AcceptProposal(logPostOld = logPostOld, logPostNew = -2e30,
                                temperature = 1)
}

test_that(".UpdateStateHMC clamps a -Inf post-sweep logPost (RT-648)", {
  skip_on_cran()

  td <- .rt648TempDir("rt648h_")
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  f <- .rt648Setup(td)

  hmcArgs <- StratoBayes:::.HMCDefaultArgs(f$model)
  hmcArgs[["adaptStepSize"]] <- FALSE
  hmcArgs[["nSteps"]] <- 2L
  hmcArgs[["divergenceMax"]] <- 1000

  runHMC <- function(stepSize, mocked) {
    args <- hmcArgs
    args[["stepSize"]] <- stepSize
    mcmc <- .rt648WithArgs(f$mcmc, f$propIdx, args)
    if (mocked) {
      testthat::local_mocked_bindings(.LogPost = .rt648NegInf,
                                      .package = "StratoBayes")
    }
    set.seed(648)
    StratoBayes:::.UpdateStateHMC(f$data, f$model, mcmc, f$state, chain = 1L,
                                  proposalNumber = f$propIdx)
  }

  # A tiny step barely moves the Hamiltonian, so the trajectory is accepted; an
  # oversized one diverges and is rejected. Both branches end by storing the
  # post-sweep marginal, so both must clamp.
  accepted <- runHMC(1e-4, mocked = FALSE)
  expect_true(isTRUE(accepted[[c("metro", "accept")]]))
  expect_true(is.finite(accepted[[c("metro", "logPost")]]))

  rejected <- runHMC(50, mocked = FALSE)
  expect_false(isTRUE(rejected[[c("metro", "accept")]]))
  expect_true(is.finite(rejected[[c("metro", "logPost")]]))

  for (stepSize in c(1e-4, 50)) {
    updated <- runHMC(stepSize, mocked = TRUE)
    expect_identical(updated[[c("metro", "logPost")]], -10^30)
    expect_identical(updated[[c("metro", "logPostOld")]], -10^30)
    # Only the scalar is clamped: the per-component vector keeps the raw -Inf,
    # as it does on the MH path.
    expect_identical(updated[[c("metro", "logPostSep")]][[1]], -Inf)
    # Discrimination: an unclamped -Inf accepts the same proposal.
    expect_true(.rt648AcceptsAWorseProposal(-Inf))
    expect_false(.rt648AcceptsAWorseProposal(updated[[c("metro", "logPost")]]))
  }
})

test_that(".UpdateStateNUTS clamps a -Inf post-sweep logPost (RT-648)", {
  skip_on_cran()

  td <- .rt648TempDir("rt648n_")
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  f <- .rt648Setup(td)

  nutsArgs <- StratoBayes:::.NUTSDefaultArgs(f$model)
  nutsArgs[["adaptStepSize"]] <- FALSE

  runNUTS <- function(stepSize, mocked) {
    args <- nutsArgs
    args[["stepSize"]] <- stepSize
    mcmc <- .rt648WithArgs(f$mcmc, f$propIdx, args)
    if (mocked) {
      testthat::local_mocked_bindings(.LogPost = .rt648NegInf,
                                      .package = "StratoBayes")
    }
    set.seed(648)
    StratoBayes:::.UpdateStateNUTS(f$data, f$model, mcmc, f$state, chain = 1L,
                                   proposalNumber = f$propIdx)
  }

  # `accept` is `candidateChanged && ...` (R/HMCFunctions.R:1311), so a NUTS
  # self-transition reads as a reject; divergence splits the regimes reliably.
  # The finite logPost proves the mocked runs' clamp came from the mock.
  fine <- runNUTS(1e-3, mocked = FALSE)
  expect_false(isTRUE(fine[[c("metro", "nutsDivergent")]]))
  expect_true(is.finite(fine[[c("metro", "logPost")]]))

  coarse <- runNUTS(50, mocked = FALSE)
  expect_true(isTRUE(coarse[[c("metro", "nutsDivergent")]]))
  expect_true(is.finite(coarse[[c("metro", "logPost")]]))

  for (stepSize in c(1e-3, 50)) {
    updated <- runNUTS(stepSize, mocked = TRUE)
    expect_identical(updated[[c("metro", "logPost")]], -10^30)
    expect_identical(updated[[c("metro", "logPostOld")]], -10^30)
    expect_identical(updated[[c("metro", "logPostSep")]][[1]], -Inf)
    expect_false(.rt648AcceptsAWorseProposal(updated[[c("metro", "logPost")]]))
  }
})
