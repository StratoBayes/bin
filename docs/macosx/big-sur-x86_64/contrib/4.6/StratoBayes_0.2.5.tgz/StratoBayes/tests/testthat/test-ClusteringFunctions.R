test_that("ClusteringFunctions work", {
  set.seed(1)
  test <- cbind(c(runif(20), runif(30, 2, 4)),
                c(rnorm(20), rnorm(30, 10, 0.5)))
  expect_equal(.PamCluster(test, 10, 0, 0),
               .ProtoCluster(test, 10, 0, 0))
})

test_that("ClusteringFunctions agree with a deterministic ground truth (RT-083)", {
  # Three tightly co-located points with no real substructure: the only
  # reasonable clustering keeps them all in one cluster. This anchors the
  # differential test above against a known-correct answer, rather than only
  # checking the two algorithms agree with each other (which a shared
  # systematic error, e.g. a wrong distance metric, would not catch). A high
  # silCutOff means a spurious 2-way split (poor silhouette on near-identical
  # points) is rejected in favour of the single-cluster fallback.
  test <- rbind(c(0, 0), c(0.001, 0.001), c(0.002, 0.002))
  pamResult <- .PamCluster(test, clustMax = 2, silCutOff = 0.9, silOutlierThreshold = 0)
  protoResult <- .ProtoCluster(test, clustMax = 2, silCutOff = 0.9, silOutlierThreshold = 0)
  expect_equal(unname(pamResult), c(1, 1, 1))
  expect_equal(unname(protoResult), c(1, 1, 1))
})

test_that("pamSils 0.6 cutoff works", {
  set.seed(1)
  test <- cbind(runif(30, 2, 4), rnorm(30, 10, 0.5))
  expect_equal(.PamCluster(test, 10, 0.6),
               .ProtoCluster(test, 10, 0.6))
})

test_that(".PamCluster handles a single surviving cluster after outlier removal (RT-124)", {
  # One far outlier point plus a tight group of 4: with silOutlierThreshold
  # flagging only the outlier, the survivors all collapse to one cluster
  # label, so silhouette() on the survivors returns scalar NA. .PamCluster
  # must handle this the same way .ProtoCluster does (retain outliers with
  # a warning) instead of erroring on `newSil[, "sil_width"]`.
  set.seed(42)
  test <- rbind(matrix(rnorm(8, sd = 0.01), ncol = 2),
                c(1000, 1000))

  expect_warning(
    pamResult <- .PamCluster(test, clustMax = 2, silCutOff = 0,
                              silOutlierThreshold = 0.9),
    "retaining outliers"
  )
  expect_warning(
    protoResult <- .ProtoCluster(test, clustMax = 2, silCutOff = 0,
                                  silOutlierThreshold = 0.9),
    "retaining outliers"
  )
  expect_equal(pamResult, protoResult)
})

test_that(".myNrow works", {
  set.seed(1)
  test <- cbind(runif(30, 2, 4), rnorm(30, 10, 0.5))
  expect_equal(.myNrow(test), nrow(test))
  test2 <- 1:2
  expect_equal(.myNrow(test2), length(test2))
})
