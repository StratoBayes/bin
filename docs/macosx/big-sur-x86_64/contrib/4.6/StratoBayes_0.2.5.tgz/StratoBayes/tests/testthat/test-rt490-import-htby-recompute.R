# #490: `sb_create_engine()` must rebuild the unscaled B'B / B'y caches from the
# imported B, not back-derive them as `BtB = H * sigma^2`.
#
# The back-derivation is exact only if the exporter refreshed H after its last
# sigma draw.  The R engine did not — `.UpdateHtBy()` ran before the Gibbs sweep
# that moves sigma, so an exported R state carried an H off by
# (sigma_new / sigma_old)^2 — and an error admitted at import never self-heals,
# because `rescale_htby()` consumes BtB rather than rebuilding it.
#
# That exporter defect is now fixed (#508), so the R engine no longer supplies
# the staleness.  The import must not depend on that: test 2 below corrupts H
# deliberately, which is the statement of the #490 fix that survives any
# exporter.  `test-508-post-gibbs-htby.R` is what pins the exporter itself.

# ── Fixture ──────────────────────────────────────────────────────────────────

# A short R-engine chain, whose `recentState` is then handed to the C++ engine —
# the handoff the defect lives on.  `sigmaFixed = FALSE` is the interesting arm;
# the fixed-sigma one is the negative control.
.rt490_setup <- function(sigmaFixed, flexibleKnots = FALSE) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = flexibleKnots,
    knotRange = if (flexibleKnots) NULL else c(-5, 12),
    sigmaFixed = sigmaFixed)

  td <- file.path(tempdir(), paste0("rt490_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  set.seed(4200)
  RunStratModel(stratData1, model, nIter = 30, nChains = 1, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  list(data = stratData1, model = model, mcmc = mcmc)
}

# Engine state and log posterior at import, with no iteration run at all.
.rt490_at_import <- function(s, state = s$mcmc$recentState) {
  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc, state)
  st <- StratoBayes:::.sb_extract_state(eng)[[1]]
  # Independent oracle: a full forward pass that rebuilds B/H/tBy from scratch
  # via `update_spline_state()`, versus the engine's imported caches.
  list(state = st,
       oracle = StratoBayes:::.sb_eval_logpost(eng, 1L, st$metro$parameters,
                                               marginal = TRUE))
}

# ── The import does not trust the H it is handed ─────────────────────────────

test_that("#490: imported log posterior matches a forward pass at import", {
  skip_on_cran()

  # Pre-fix this arm disagreed by ~316 log units.
  free <- .rt490_at_import(.rt490_setup(FALSE))
  expect_equal(free$state$metro$logPost, free$oracle, tolerance = 1e-10)

  # The import recomputes from the imported B without touching the knots, so
  # the flexible-knot path has to hold too.
  flex <- .rt490_at_import(.rt490_setup(FALSE, flexibleKnots = TRUE))
  expect_equal(flex$state$metro$logPost, flex$oracle, tolerance = 1e-10)

  # Negative control: with sigma pinned the back-derivation was already exact,
  # so this arm passed before the fix too and must keep passing.
  fixed <- .rt490_at_import(.rt490_setup(0.15))
  expect_equal(fixed$state$metro$logPost, fixed$oracle, tolerance = 1e-10)
})

test_that("#490: import ignores the H/tBy it is handed", {
  skip_on_cran()

  # Direct statement of the fix, with no dependence on how stale the R engine's
  # H happens to be: scale the exported H/tBy as though they had been computed
  # at sigma/2, and the engine must land in the same place regardless.
  s <- .rt490_setup(FALSE)
  clean <- .rt490_at_import(s)

  corrupt <- s$mcmc$recentState
  corrupt[[1]]$metro$H <- lapply(corrupt[[1]]$metro$H, `*`, 4)
  corrupt[[1]]$metro$tBy <- lapply(corrupt[[1]]$metro$tBy, `*`, 4)
  dirty <- .rt490_at_import(s, corrupt)

  expect_equal(dirty$state$metro$H, clean$state$metro$H)
  expect_equal(dirty$state$metro$tBy, clean$state$metro$tBy)
  expect_identical(dirty$state$metro$logPost, clean$state$metro$logPost)
})

test_that("#490: import rejects a B that does not match the data", {
  skip_on_cran()

  # Rebuilding indexes the signal values by row of the imported B, so a state
  # imported against data it was not produced from would read past the end of
  # `values`. Pre-fix nothing touched the values at import, so this was silent.
  s <- .rt490_setup(FALSE)
  short <- s$mcmc$recentState
  short[[1]]$metro$B[[1]] <- head(short[[1]]$metro$B[[1]], -3L)

  expect_error(
    StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc, short),
    "does not match this data/model")
})

# ── The C++ -> C++ resume path stays bit-exact ───────────────────────────────

# The silent-regression surface of the fix: every resumed C++ run re-imports a
# state the engine itself wrote.  That is safe only because the engine rescales
# H/tBy from BtB after every Gibbs sweep, so its exported H already satisfies
# `H == B'B / sigma^2` exactly and the rebuild reproduces it to the bit (same
# sparse accumulation over the same B).  `expect_identical`, not `expect_equal`:
# a rebuild that merely *nearly* reproduced it would move every resumed chain.
test_that("#490: re-importing a C++-exported state reproduces H exactly", {
  skip_on_cran()

  s <- .rt490_setup(FALSE)
  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, s$mcmc,
                                         s$mcmc$recentState)
  StratoBayes:::.sb_configure_monitor(
    eng, ncol(s$mcmc[[c("metro", "proposalProbability")]]))
  set.seed(24L)
  StratoBayes:::.sb_run_block(eng, 20L)
  exported <- StratoBayes:::.sb_extract_state(eng)

  # sigma moved during those iterations, so this is not a trivially fixed-sigma
  # round trip.
  expect_false(isTRUE(all.equal(exported[[1]]$gibbs$sigma,
                                s$mcmc$recentState[[1]]$gibbs$sigma)))

  reimported <- .rt490_at_import(s, exported)
  expect_identical(reimported$state$metro$H, exported[[1]]$metro$H)
  expect_identical(reimported$state$metro$tBy, exported[[1]]$metro$tBy)
  expect_equal(reimported$state$metro$logPost, reimported$oracle,
               tolerance = 1e-10)
})
