# `alpha` is the age *at* `alphaPosition`, so an `alpha_*` prior is only valid
# for the position it was written for. These tests cover the stamp that
# records the `alphaPosition` a `StratPrior` list was resolved against, and
# the warning that fires when reused priors carry a stale one.
# See .agent/specs/stamp-alphaposition/spec.md.

# Full-precision alphaPosition for c("top", "middle", "bottom") on stratData2,
# age scale -- approximately c(104, 14.916, 0). Used, not the rounded literal,
# wherever a stamp is compared numerically (`isTRUE(all.equal(...))` has no
# tolerance headroom for rounding to 3 decimal places).
topMidBottom <- .MatchAlphaPosition(c("top", "middle", "bottom"), stratData2,
                                    "age", toNumeric = TRUE)

test_that("StratModel() stamps priors$metro with the resolved alphaPosition", {
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                       alignmentScale = "age", sedModel = "site",
                       alphaPosition = c("top", "middle", "bottom"),
                       nKnots = 25)

  expect_equal(attr(model$priors$metro, "alphaPosition"),
               c(104, 14.916, 0), tolerance = 1e-3)
})

test_that("reusing stamped priors under a different alphaPosition warns", {
  # Simulate `stratModel2`-style priors: stamped for alphaPosition =
  # c("top", "middle", "bottom") on stratData2, i.e. c(104, 14.916, 0).
  stampedPriors <- stratPrior2
  attr(stampedPriors, "alphaPosition") <- topMidBottom

  # `alphaPosition` omitted -> resolves to "middle" for every site, i.e.
  # c(52, 14.916, 10). site1 (104 vs 52) and site3 (0 vs 10) mismatch. Pin to
  # this function's own wording so an unrelated warning mentioning the same
  # parameter or numbers can't make this pass for the wrong reason.
  expect_warning(
    StratModel(stratData = stratData2, priors = stampedPriors,
               alignmentScale = "age", sedModel = "site", nKnots = 25),
    "carries an `alphaPosition` stamp.*104.*does not match.*52.*alpha_site1"
  )
})

test_that("unstamped priors with alphaPosition omitted do not warn", {
  expect_warning(
    StratModel(stratData = stratData2, priors = stratPrior2,
               alignmentScale = "age", sedModel = "site", nKnots = 25),
    regexp = NA
  )
})

test_that("the same alphaPosition supplied explicitly does not warn", {
  stampedPriors <- stratPrior2
  attr(stampedPriors, "alphaPosition") <- topMidBottom

  expect_warning(
    StratModel(stratData = stratData2, priors = stampedPriors,
               alignmentScale = "age", sedModel = "site",
               alphaPosition = c("top", "middle", "bottom"), nKnots = 25),
    regexp = NA
  )
})

test_that("a reversed prior order still ends up stamped", {
  reversedPriors <- structure(stratPrior2[rev(names(stratPrior2))],
                              class = c("StratPrior", "list"))
  expect_false(identical(names(reversedPriors), names(stratPrior2)))

  model <- StratModel(stratData = stratData2, priors = reversedPriors,
                       alignmentScale = "age", sedModel = "site",
                       alphaPosition = c("top", "middle", "bottom"),
                       nKnots = 25)

  expect_equal(attr(model$priors$metro, "alphaPosition"),
               c(104, 14.916, 0), tolerance = 1e-3)
})

test_that("AutoPrior() stamps its output", {
  priors <- AutoPrior(stratData = stratData1, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "middle")

  expect_equal(attr(priors, "alphaPosition"),
               .MatchAlphaPosition("middle", stratData1, "height",
                                   toNumeric = TRUE))
})

test_that("height scale: NA first position does not spuriously warn", {
  # site 1 is the reference section on the height scale and has no alpha, so
  # alphaPosition[1] is NA; reusing a model's own stamp under the same
  # alphaPosition must not warn just because both sides are NA at position 1.
  model <- StratModel(stratData = stratData1, priors = NULL,
                       alignmentScale = "height", sedModel = "site",
                       alphaPosition = "middle", nKnots = 5)

  expect_true(is.na(attr(model$priors$metro, "alphaPosition")[1]))

  expect_warning(
    StratModel(stratData = stratData1, priors = model$priors$metro,
               alignmentScale = "height", sedModel = "site",
               alphaPosition = "middle", nKnots = 5),
    regexp = NA
  )
})

test_that("height scale: reusing priors under a different alphaPosition warns", {
  # On the height scale `priors` always routes through AutoPrior() (even when
  # fully user-supplied), which always returns a freshly, correctly stamped
  # object -- this is the path that must not swallow a stale incoming stamp.
  modelA <- StratModel(stratData = stratData1, priors = NULL,
                       alignmentScale = "height", sedModel = "site",
                       alphaPosition = "top", nKnots = 5)

  # `alphaPosition` omitted -> resolves via the overlap-midpoint default,
  # which differs from "top" for stratData1. Pin to this function's own
  # wording, not just the parameter name, so an unrelated warning that
  # happens to mention `alpha_site_2` (e.g. from `.PriorsValidity()`) can't
  # make this pass for the wrong reason.
  expect_warning(
    StratModel(stratData = stratData1, priors = modelA$priors$metro,
               alignmentScale = "height", sedModel = "site", nKnots = 5),
    "carries an `alphaPosition` stamp.*does not match.*alpha_site_2"
  )
})

test_that("priorsProposals is stamped and checked the same way as priors", {
  model <- StratModel(stratData = stratData2, priors = stratPrior2,
                       priorsProposals = stratPrior2,
                       alignmentScale = "age", sedModel = "site",
                       alphaPosition = c("top", "middle", "bottom"),
                       nKnots = 25)

  expect_equal(attr(model$priorsProposals, "alphaPosition"),
               topMidBottom)

  # Reusing a stale `priorsProposals` (not `priors`) must warn too, naming
  # `priorsProposals` specifically, not `priors`.
  stalePriorsProposals <- stratPrior2
  attr(stalePriorsProposals, "alphaPosition") <- topMidBottom

  expect_warning(
    StratModel(stratData = stratData2, priors = stratPrior2,
               priorsProposals = stalePriorsProposals,
               alignmentScale = "age", sedModel = "site", nKnots = 25),
    "`priorsProposals` carries an `alphaPosition` stamp.*104.*does not match.*52"
  )
})

test_that("AutoPrior(customPriors =) checks the incoming stamp before re-stamping", {
  # RT-524: this was the one unmatched write. Re-stamping `customPriors` with
  # the newly requested convention turns a stale stamp into an affirmative
  # (and wrong) certificate, which then suppresses the very warning that
  # exists to catch reuse.
  stampedTop <- AutoPrior(stratData = stratData1, alignmentScale = "height",
                          sedModel = "site", alphaPosition = "top")

  expect_warning(
    AutoPrior(stratData = stratData1, alignmentScale = "height",
              sedModel = "site", alphaPosition = "bottom",
              customPriors = stampedTop),
    "`customPriors` carries an `alphaPosition` stamp.*does not match.*alpha_site_2"
  )

  # The laundering itself is unchanged: the returned priors are still the ones
  # built for "top", but the object is now stamped "bottom".
  laundered <- suppressWarnings(
    AutoPrior(stratData = stratData1, alignmentScale = "height",
              sedModel = "site", alphaPosition = "bottom",
              customPriors = stampedTop))
  expect_identical(laundered[["alpha_site_2"]], stampedTop[["alpha_site_2"]])
  expect_equal(attr(laundered, "alphaPosition"),
               .MatchAlphaPosition("bottom", stratData1, "height",
                                   toNumeric = TRUE))

  # A stamp that does match must stay silent, as must an unstamped list.
  unstamped <- stampedTop
  attr(unstamped, "alphaPosition") <- NULL
  expect_warning(
    AutoPrior(stratData = stratData1, alignmentScale = "height",
              sedModel = "site", alphaPosition = "top",
              customPriors = stampedTop),
    regexp = NA)
  expect_warning(
    AutoPrior(stratData = stratData1, alignmentScale = "height",
              sedModel = "site", alphaPosition = "bottom",
              customPriors = unstamped),
    regexp = NA)
})

test_that("height scale: a stale incoming stamp warns exactly once", {
  # `StratModel()` routes `priors` through `AutoPrior(customPriors = )` and
  # reports the mismatch itself, naming the user-facing `priors`. Both guards
  # see the same stamp, so only one of them may fire.
  modelA <- StratModel(stratData = stratData1, priors = NULL,
                       alignmentScale = "height", sedModel = "site",
                       alphaPosition = "top", nKnots = 5)

  warnings <- capture_warnings(
    StratModel(stratData = stratData1, priors = modelA$priors$metro,
               alignmentScale = "height", sedModel = "site", nKnots = 5))

  # Filter rather than counting every warning: the spline fit this builds is
  # entitled to warn about unrelated things without breaking the pin.
  stampWarnings <- grep("alphaPosition", warnings, value = TRUE)
  expect_length(stampWarnings, 1)
  expect_match(stampWarnings, "^`priors` carries an `alphaPosition` stamp")
})
