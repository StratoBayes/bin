# The load hooks are never on the search path, so read them off the namespace.
LoadHookSource <- function(hook) {
  deparse(get(hook, envir = asNamespace("StratoBayes")))
}

test_that("the compiled expiry date is what the runtime reads", {
  expiry <- .sb_expiry_days()
  expect_type(expiry, "integer")
  expect_length(expiry, 1L)
  expect_gte(expiry, 0L)

  # The date is compiled in, so no DESCRIPTION field can move it -- reading
  # one at load time would hand a trial user an edit that resets the clock.
  onLoad <- LoadHookSource(".onLoad")
  for (reader in c("packageDescription", "read.dcf")) {
    expect_false(any(grepl(reader, onLoad, fixed = TRUE)))
  }

  # Anything that got far enough to run this is, by construction, not expired:
  # both .onLoad and the C++ gates in sb_create_engine / sb_run_block would
  # have refused first.
  expect_false(.sb_expired())
})

test_that("no environment variable or option can switch expiry off", {
  for (hook in c(".onLoad", ".onAttach")) {
    source <- LoadHookSource(hook)
    for (bypass in c("DISABLE_EXPIRY", "disable_expiry")) {
      expect_false(any(grepl(bypass, source, fixed = TRUE)))
    }
  }
})

test_that("the C++ clock agrees with R's, give or take a timezone", {
  today <- .sb_clock_days()
  expect_gt(today, 0L)
  expect_lte(abs(today - as.integer(Sys.Date())), 1L)
})

test_that("a clock set back behind either lower bound is refused", {
  # today, highWater, installed
  expect_false(.ClockRollback(20000L, 19990L, 19990L))
  expect_false(.ClockRollback(20000L, 20001L, NA_integer_))  # within grace
  expect_true(.ClockRollback(19000L, 20000L, NA_integer_))   # rolled back

  # Deleting the high-water file leaves the installed-file mtime standing.
  expect_true(.ClockRollback(19000L, NA_integer_, 20000L))

  # Neither bound available: nothing to contradict, so this is not the gate
  # that refuses -- the compiled date is.
  expect_false(.ClockRollback(20000L, NA_integer_, NA_integer_))

  # An unreadable clock fails closed.
  expect_true(.ClockRollback(NA_integer_, NA_integer_, NA_integer_))
})

test_that("the grace period is applied to the later of the two bounds", {
  expect_false(.ClockRollback(19998L, 20000L, 19000L, grace = 2L))
  expect_true(.ClockRollback(19997L, 20000L, 19000L, grace = 2L))
})

test_that("a damaged high-water file reads as absent, not as day zero", {
  path <- withr::local_tempfile()

  expect_true(is.na(.ReadClockHighWater(path)))       # missing

  writeLines(character(0), path)
  expect_true(is.na(.ReadClockHighWater(path)))       # empty

  writeLines("not a day", path)
  expect_true(is.na(.ReadClockHighWater(path)))       # garbage

  writeLines("20000", path)
  expect_identical(.ReadClockHighWater(path), 20000L)
})

test_that("an unwritable high-water path does not stop the package loading", {
  # A regular file standing where the config directory should be: dir.create()
  # warns, writeLines() errors, and neither may surface.
  blocked <- withr::local_tempfile()
  writeLines("", blocked)

  expect_silent(.WriteClockHighWater(file.path(blocked, "clock"), 20000L))
})
