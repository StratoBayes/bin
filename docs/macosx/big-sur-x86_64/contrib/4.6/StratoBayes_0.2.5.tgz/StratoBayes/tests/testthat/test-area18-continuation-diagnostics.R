# Regression tests for a batch of area:18 findings in the continuation-
# diagnostics and thread-resolution path:
#   #1339 adaptFreeze dropped on continuation
#   #1340 iterationsMonitored is a dead, wrongly-computed field
#   #1341 ambient mc.cores overrides an explicit engine = "R"
#   #1342 nThreads bypasses validation when reached via RunStratModel()
#   #1343 a continuation truncates _options.txt
#   #1344 nDomainFailure/nGibbsCholeskyFailures reset on continuation

# ── #1339 / #1344: the transfer block ──────────────────────────────────────
# Direct unit test on minimal mock objects, as for RT-098/099/100: omitting
# `metro$chainHistory` skips the ring-buffer branch of the same function.

.MockOld1344 <- function() {
  list(
    nDivergent = 40L,
    nDomainFailure = 31L,
    nGibbsCholeskyFailures = 7L,
    adaptFreeze = list(iteration = 43, spent = 1.5, predicted = 9),
    endAdapting = 43,
    temper = list(),
    metro = list(
      proposalProbability = matrix(0.5, 1, 2),
      proposalFactor = matrix(1, 1, 2),
      proposalValid = matrix(TRUE, 1, 2),
      proposalArgs = list(list(NULL, NULL))
    ),
    recentState = list(dummy = TRUE)
  )
}

.MockNew1344 <- function(endAdapting = 43) {
  list(
    nDivergent = 0L,
    endAdapting = endAdapting,
    temper = list(temperatures = c(1, Inf)),
    metro = list(
      proposalProbability = matrix(0, 1, 2),
      proposalFactor = matrix(0, 1, 2),
      proposalValid = matrix(FALSE, 1, 2),
      proposalArgs = list()
    ),
    nChains = 1,
    recentState = NULL
  )
}

test_that("a continuation carries the failure counters forward (#1344)", {
  result <- .UpdateMCMCforContinuedRun(mcmc = .MockOld1344(),
                                       mcmcNew = .MockNew1344(),
                                       newRun = FALSE)

  # Pre-fix both were NULL here and `.InnerRunMCMC()` re-seeded them at 0,
  # so the reported domain-failure subset shrank while its superset grew.
  expect_equal(result[["nDomainFailure"]], 31L)
  expect_equal(result[["nGibbsCholeskyFailures"]], 7L)
  expect_equal(result[["nDivergent"]], 40L)
})

test_that("a carried Cholesky-failure count does not re-warn the next segment (#1344)", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                      nChains = 2, nThreads = 0L, visualise = FALSE, seed = 1,
                      runParallel = FALSE, quiet = TRUE)
  mcmcFile <- file.path(r1[["modelDir"]],
                        paste0(r1[["modelName"]], "_mcmc_run_1.rds"))
  stored <- readRDS(mcmcFile)
  stored[["nGibbsCholeskyFailures"]] <- 5L
  saveRDS(stored, mcmcFile)

  # The count must survive the transfer (that is #1344) without the run-end
  # warning, which names *this* run, firing for a segment that never failed.
  expect_no_warning(
    RunStratModel(r1, nIter = 2, visualise = FALSE, quiet = TRUE)
  )
  expect_equal(
    readRDS(mcmcFile)[["nGibbsCholeskyFailures"]], 5L)
})

test_that("a continuation carries the adaptation freeze forward (#1339)", {
  result <- .UpdateMCMCforContinuedRun(mcmc = .MockOld1344(),
                                       mcmcNew = .MockNew1344(),
                                       newRun = FALSE)

  expect_equal(result[[c("adaptFreeze", "iteration")]], 43)
})

test_that("a run that never froze gains no adaptFreeze record (#1339)", {
  mcmcOld <- .MockOld1344()
  mcmcOld[["adaptFreeze"]] <- NULL

  result <- .UpdateMCMCforContinuedRun(mcmc = mcmcOld,
                                       mcmcNew = .MockNew1344(),
                                       newRun = FALSE)

  expect_null(result[["adaptFreeze"]])
})

test_that("a genuinely frozen run keeps its freeze across a plain continuation (#1339)", {
  skip_on_cran()
  # The mock objects above choose the `endAdapting` the gate reads. Only a real
  # run says whether `StratMCMC()`'s `lastAdapted` inheritance reproduces the
  # rebased window -- if it re-opened it instead, the gate would drop the
  # record on every continuation and #1339 would be fixed in name only.
  dir <- withr::local_tempdir()
  r1 <- testthat::with_mocked_bindings(
    RunStratModel(stratData1, stratModel1, nIter = 200, nChains = 4, nRun = 1,
                  seed = 1, quiet = TRUE, nThreads = 1L, modelDir = dir,
                  modelName = "freeze1339", visualise = FALSE,
                  convergenceStop = FALSE),
    .AdaptTimerCheckpoint = function(store, essShare, spent) {
      list(freeze = TRUE, predicted = 0)
    }
  )
  freezeAt <- r1[["mcmcSummary"]][["adaptFreeze"]][[1L]][["iteration"]]
  expect_false(is.null(freezeAt))

  # Outside the mock, so the continuation cannot re-create the record itself.
  r2 <- RunStratModel(r1, nIter = 20, visualise = FALSE, quiet = TRUE)
  expect_equal(r2[["mcmcSummary"]][["adaptFreeze"]][[1L]][["iteration"]],
               freezeAt)
})

test_that("a continuation that re-opens adaptation drops the stale freeze (#1339)", {
  # The record describes the window that produced it. Carried past a re-opened
  # `endAdapting` it would claim adaptation both stopped at 43 and ran to 5000.
  result <- .UpdateMCMCforContinuedRun(mcmc = .MockOld1344(),
                                       mcmcNew = .MockNew1344(endAdapting = 5000),
                                       newRun = FALSE)

  expect_null(result[["adaptFreeze"]])
})

# ── #1340: the dead iterationsMonitored field ──────────────────────────────

test_that("no object records the dead iterationsMonitored field (#1340)", {
  mcmc <- StratMCMC(stratModel1, nIter = 20, nChains = 2)

  expect_false("iterationsMonitored" %in%
                 names(mcmc[[c("metro", "acceptanceMonitor")]]))
  # `startMonitoring` is live -- `.InnerRunMCMC()` reads it -- so its
  # companion's removal must not take it with it.
  expect_false(is.null(mcmc[[c("metro", "acceptanceMonitor", "startMonitoring")]]))

  rebased <- .RebaseAdaptCursors(mcmc, 10,
                                 mcmc[[c("metro", "adaptProposalInterval")]])
  expect_false("iterationsMonitored" %in%
                 names(rebased[["mcmc"]][[c("metro", "acceptanceMonitor")]]))
})

# ── #1341: an inherited thread count must not defeat engine = "R" ──────────

test_that("an ambient mc.cores does not override an explicit engine = 'R' (#1341)", {
  withr::local_options(mc.cores = 2L)
  mcmcObj <- StratMCMC(stratModel1, nIter = 2, nChains = 2)
  # The premise: threading was inherited, never requested.
  expect_equal(mcmcObj[["nThreads"]], 2L)
  expect_false(mcmcObj[[".nThreadsUserSet"]])

  msgs <- testthat::capture_messages(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = mcmcObj,
                  nRun = 1, engine = "R", visualise = FALSE,
                  seed = 1, runParallel = FALSE, quiet = TRUE)
  )
  expect_false(any(grepl("Switching to", msgs, fixed = TRUE)))
})

test_that("an explicitly requested nThreads still overrides engine = 'R' (#1341)", {
  msgs <- testthat::capture_messages(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                  nChains = 2, nThreads = 2L, engine = "R", visualise = FALSE,
                  seed = 1, runParallel = FALSE, quiet = TRUE)
  )
  expect_true(any(grepl("Switching to", msgs, fixed = TRUE)))
})

# ── #1342: nThreads validation on the RunStratModel() path ─────────────────

test_that("RunStratModel() rejects the nThreads values StratMCMC() rejects (#1342)", {
  # Lazily evaluated arguments are never forced, so these fail on `nThreads`
  # alone -- no data or model is needed to reach the check.
  expect_error(RunStratModel(nThreads = NULL),
               "`nThreads` must be a non-negative integer")
  expect_error(RunStratModel(nThreads = NA),
               "`nThreads` must be a non-negative integer")
  expect_error(RunStratModel(nThreads = c(2, 3)),
               "`nThreads` must be a non-negative integer")
  expect_error(RunStratModel(nThreads = -1L),
               "`nThreads` must be a non-negative integer")
  # `NULL` is a `StratMCMC()` idiom alone -- there it means `mc.cores`, while
  # `RunStratModel()`'s "inherit" sentinel is `0` -- so only its message may
  # offer `NULL`.
  expect_error(StratMCMC(stratModel1, nThreads = c(2, 3)),
               "`nThreads` must be NULL or a non-negative integer")
})

test_that("nThreads reaches the per-chain cap as an integer (#1342)", {
  # The cap is `min(nThreads, nChains)`; against a character `nThreads` that
  # comparison is lexicographic, and `min("10", 2L)` is `"10"`.
  expect_identical(.ValidateNThreads("10"), 10L)
  expect_identical(min(.ValidateNThreads("10"), 2L), 2L)
})

# ── #1343: _options.txt must survive a continuation ────────────────────────

test_that("a continuation appends to _options.txt rather than truncating it (#1343)", {
  dir <- withr::local_tempdir()
  .CompileArgsToFile(dir, "m", nRun = 2L, newRun = TRUE,
                     call = quote(RunStratModel(nChains = 4, tempering = TRUE)))
  .CompileArgsToFile(dir, "m", nRun = 2L, newRun = FALSE,
                     call = quote(RunStratModel(nIter = 40)))
  lines <- readLines(file.path(dir, "m_options.txt"))

  expect_true(any(grepl("nChains = 4", lines, fixed = TRUE)))
  expect_true(any(grepl("tempering = TRUE", lines, fixed = TRUE)))
  expect_true(any(grepl("nIter = 40", lines, fixed = TRUE)))
  # `.CheckRequiredFiles()` takes `nRun` only from a single matching line, and
  # silently falls back to 1 given two.
  expect_length(grep("nRun =", lines, value = TRUE), 1L)
})

test_that("RunStratModel() itself passes newRun through to the options file (#1343)", {
  # The unit test above cannot see the call site, which is where a hard-coded
  # `newRun = TRUE` would put the truncation back.
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 2,
                      nChains = 2, nThreads = 0L, bactrianM = 0.5,
                      visualise = FALSE, seed = 1, runParallel = FALSE,
                      quiet = TRUE)
  optionsFile <- file.path(r1[["modelDir"]],
                           paste0(r1[["modelName"]], "_options.txt"))
  expect_true(any(grepl("bactrianM = 0.5", readLines(optionsFile), fixed = TRUE)))

  RunStratModel(r1, nIter = 2, visualise = FALSE, quiet = TRUE)
  lines <- readLines(optionsFile)

  expect_true(any(grepl("bactrianM = 0.5", lines, fixed = TRUE)))
  expect_length(grep("nRun =", lines, value = TRUE), 1L)
  # The appended file must still read back cleanly through the consumer that
  # the single-`nRun`-line rule belongs to.
  expect_equal(.CheckRequiredFiles(r1[["modelDir"]], r1[["modelName"]])[["nRun"]],
               1)
})
