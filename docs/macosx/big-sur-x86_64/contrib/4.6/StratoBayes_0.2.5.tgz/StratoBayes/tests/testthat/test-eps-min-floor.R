# #349 item 3 — configurable NUTS/HMC step-size floor (epsMin).
#
# The floor was a hard-coded static constexpr (HMCState::EPS_MIN = 1e-4); it is
# now a per-HMCState field `epsMin`, settable via proposalArgs (the same channel
# as maxTreeDepth / divergenceMax / targetAccept). Default is unchanged (1e-4).
#
# These tests are deterministic WITHOUT pinning any absolute posterior value:
# the floor is an exact clamp, so `adapted stepSize >= epsMin` holds for ANY RNG
# stream (see [[mcmc-value-tests-not-portable]]). We drive the engine directly
# with a single .sb_run_block (the RT-007 pattern) so there is no between-block
# cost-aware reweighting; a fixed seed then makes a within-process A/B of two
# epsMin values reproducible for the "no behaviour change" and guard checks.

# Build a NUTS-only, fully-initialised engine setup (mirror of .rt007_setup in
# test-divergence-diagnostics.R). adaptStepSize + .needsEpsInit are forced TRUE
# so the floor path (find_reasonable_epsilon at init AND the DA clamp per iter)
# is guaranteed to execute in the block we drive.
.epsmin_setup <- function(nChains = 2L) {
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  model <- StratoBayes::StratModel(
    stratData = stratData1, priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale, sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )
  td <- file.path(tempdir(), paste0("epsmin_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  # `gradientProposals = "on"` is load-bearing: #526 made "auto" (the default)
  # equivalent to "off", so fixed knots alone no longer register NUTS and the
  # `which(colnames(pp) == "NUTS")` lookup below yields integer(0).
  RunStratModel(stratData1, model, nIter = 30, nChains = nChains, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "s", engine = "R", gradientProposals = "on")
  mcmc <- readRDS(file.path(td, "s_mcmc_run_1.rds"))

  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)

  # NUTS-only proposal set (0 weight elsewhere).
  pp <- mcmc[[c("metro", "proposalProbability")]]
  pp[, ] <- 0
  pp[, which(colnames(pp) == "NUTS")] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- pp

  # Force re-initialisation + adaptation so the floor path runs in our block.
  nutsPropNum <- which(colnames(pp) == "NUTS")
  for (ch in seq_len(nChains)) {
    mcmc[[c("metro", "proposalArgs")]][[ch]][[nutsPropNum]][["adaptStepSize"]] <- TRUE
    mcmc[[c("metro", "proposalArgs")]][[ch]][[nutsPropNum]][[".needsEpsInit"]] <- TRUE
  }

  list(data = stratData1, model = model, mcmc = mcmc, state = mcmc$recentState,
       nutsPropNum = nutsPropNum, nChains = nChains)
}

# Run one NUTS-only block with `epsMin` set (NULL = leave default field as-is;
# NA = remove the field entirely to exercise the C++ ctor fallback) and return
# the per-chain adapted step sizes.
.epsmin_adapted <- function(s, epsMin, nIter = 200L, seed = 42L) {
  mcmc <- s$mcmc
  for (ch in seq_len(s$nChains)) {
    if (is.null(epsMin)) {
      # leave whatever the defaults set (1e-4)
    } else if (length(epsMin) == 1L && is.na(epsMin) && !is.nan(epsMin)) {
      mcmc[[c("metro", "proposalArgs")]][[ch]][[s$nutsPropNum]][["epsMin"]] <- NULL
    } else {
      mcmc[[c("metro", "proposalArgs")]][[ch]][[s$nutsPropNum]][["epsMin"]] <- epsMin
    }
  }
  eng <- StratoBayes:::.sb_create_engine(s$data, s$model, mcmc, s$state)
  StratoBayes:::.sb_configure_monitor(eng, mcmc[[c("metro", "nProposals")]][[1L]])
  set.seed(seed)
  StratoBayes:::.sb_run_block(eng, as.integer(nIter))
  adapted <- StratoBayes:::.sb_hmc_get_adapted(eng)
  vapply(adapted, function(a) a[["stepSize"]], numeric(1))
}


test_that("#349 item 3: a large epsMin floors the adapted step size", {
  skip_on_cran()

  s <- .epsmin_setup(nChains = 2L)
  bigFloor <- 5.0
  eps <- .epsmin_adapted(s, epsMin = bigFloor, seed = 42L)

  # Exact clamp => adapted step size can never fall below the floor, for ANY
  # RNG stream. Tiny fp slack only.
  expect_true(all(is.finite(eps)))
  expect_true(all(eps >= bigFloor * (1 - 1e-9)),
    info = sprintf("adapted stepSizes: %s (floor %g)",
                   paste(signif(eps, 4), collapse = ", "), bigFloor))
})


test_that("#349 item 3: default epsMin reproduces the pre-change floor (1e-4)", {
  skip_on_cran()

  s <- .epsmin_setup(nChains = 2L)
  # Field present at its default (1e-4) vs field entirely absent (C++ ctor
  # default EPS_MIN) must be bit-identical at the same seed => no behaviour
  # change, and legacy proposalArgs without epsMin resume identically.
  epsDefault <- .epsmin_adapted(s, epsMin = 1e-4,     seed = 7L)
  epsAbsent  <- .epsmin_adapted(s, epsMin = NA_real_, seed = 7L)  # removes field
  expect_equal(epsDefault, epsAbsent)

  # And a large floor genuinely changes the outcome (guards against the A/B
  # being trivially equal because the floor never binds).
  epsBig <- .epsmin_adapted(s, epsMin = 5.0, seed = 7L)
  expect_false(isTRUE(all.equal(epsDefault, epsBig)))
})


test_that("#349 item 3: invalid epsMin falls back to the default floor", {
  skip_on_cran()

  s <- .epsmin_setup(nChains = 2L)
  baseline <- .epsmin_adapted(s, epsMin = 1e-4, seed = 11L)

  # Non-finite / non-positive values must be rejected by the C++ guard and fall
  # back to EPS_MIN (1e-4) — i.e. identical to the baseline at the same seed,
  # never NaN and never silently floored at the bad value.
  for (bad in list(-1.0, 0.0, Inf, NaN)) {
    epsBad <- .epsmin_adapted(s, epsMin = bad, seed = 11L)
    expect_true(all(is.finite(epsBad)),
      info = sprintf("epsMin=%s produced a non-finite step size", bad))
    expect_equal(epsBad, baseline,
      info = sprintf("epsMin=%s should fall back to the 1e-4 default", bad))
  }
})
