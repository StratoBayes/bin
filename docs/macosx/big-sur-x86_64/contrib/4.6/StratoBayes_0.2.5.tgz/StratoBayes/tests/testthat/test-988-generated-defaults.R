# Rcpp transcribes each C++ default argument into the generated R signature, so
# a default R cannot evaluate leaves the argument unusable while still appearing
# in the signature. `NumericMatrix(0, 0)` became `matrix(0, 0)`, whose ncol R
# must infer from length-1 data over zero rows -- an error as of R-devel r90199
# (#988). The two callers that omitted the argument were both skip_on_cran(), so
# only the nightly cron saw it; this check is deliberately cheap and unskipped.
#
# Lane: the `matrix(0, 0)` regression itself is R-devel-only behaviour, and the
# PR merge gate runs `r-version: 'release'` -- so THAT case is caught only by
# the weekly R-CMD-check-all-systems R-devel leg, not on a PR. What this file
# adds to the PR lane is any default broken on every R version.

# The generated wrappers do not all share a prefix: five carry none
# (`.FindMaxSect` and friends), so filter on the `.Call` body over the whole
# namespace rather than on `^.sb_`.
.GeneratedCallWrappers <- function(ns = asNamespace("StratoBayes")) {
  Filter(
    function(nm) {
      fn <- get(nm, envir = ns)
      is.function(fn) &&
        any(grepl(".Call", deparse(body(fn)), fixed = TRUE))
    },
    ls(ns, all.names = TRUE)
  )
}

test_that("#988: the wrapper list covers the unprefixed generated functions", {
  cppFns <- .GeneratedCallWrappers()
  # Named explicitly: a prefix filter silently dropped exactly these five.
  expect_true(all(c(".ClusterDistSumsCpp", ".FindMaxSect", ".SectionOverlapCpp",
                    ".IsDuplicateInHistory", ".FirstAndLastCPP") %in% cppFns))
  # 52 at time of writing; a floor close to it, so half the list cannot vanish
  # unnoticed the way `> 20` allowed.
  expect_gte(length(cppFns), 50)
})

test_that("#988: every generated default argument is evaluable", {
  ns <- asNamespace("StratoBayes")
  cppFns <- .GeneratedCallWrappers(ns)

  broken <- character(0)
  for (nm in cppFns) {
    args <- formals(get(nm, envir = ns))
    supplied <- names(args)[!vapply(args, identical, logical(1),
                                    quote(expr = ))]
    for (arg in supplied) {
      value <- try(eval(args[[arg]], envir = ns), silent = TRUE)
      if (inherits(value, "try-error"))
        broken <- c(broken, sprintf("%s(%s = %s)", nm, arg,
                                    deparse1(args[[arg]])))
    }
  }
  expect_identical(broken, character(0))
})
