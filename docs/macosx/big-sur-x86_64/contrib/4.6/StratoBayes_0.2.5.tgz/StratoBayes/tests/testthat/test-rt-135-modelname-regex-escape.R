test_that(".EscapeRegex neutralises regex metacharacters", {
  expect_equal(.EscapeRegex("model.v2"), "model\\.v2")
  expect_equal(.EscapeRegex("model(1)"), "model\\(1\\)")
  expect_true(grepl(paste0("^", .EscapeRegex("model.v2"), "_x$"), "model.v2_x"))
  expect_false(grepl(paste0("^", .EscapeRegex("model.v2"), "_x$"), "modelXv2_x"))
})

test_that("modelName with regex metacharacters does not over-match decoy files (.CheckRequiredFiles)", {
  saveDir <- withr::local_tempdir()

  # complete set of files required for modelName "model.v2" (the "." must be literal)
  file.create(file.path(saveDir, "model.v2_data.rds"))
  file.create(file.path(saveDir, "model.v2_model.rds"))
  writeLines("nRun = 1", file.path(saveDir, "model.v2_options.txt"))
  file.create(file.path(saveDir, "model.v2_samples_run_1.txt"))
  file.create(file.path(saveDir, "model.v2_mcmc_run_1.rds"))

  # decoy file that a raw (unescaped) "." pattern would wrongly match against
  # "model.v2" (any char in place of "."), but a literal prefix should not
  file.create(file.path(saveDir, "modelXv2_decoy_run_1.rds"))

  dirInfo <- .CheckRequiredFiles(saveDir, "model.v2")

  expect_true(isTRUE(dirInfo[["readModel"]]))
  expect_equal(dirInfo[["nRun"]], 1L)
})

test_that("modelName with '(' does not error out list.files pattern matching", {
  saveDir <- withr::local_tempdir()

  file.create(file.path(saveDir, "model(1)_data.rds"))
  file.create(file.path(saveDir, "model(1)_model.rds"))
  writeLines("nRun = 1", file.path(saveDir, "model(1)_options.txt"))
  file.create(file.path(saveDir, "model(1)_samples_run_1.txt"))
  file.create(file.path(saveDir, "model(1)_mcmc_run_1.rds"))

  expect_error(
    dirInfo <- .CheckRequiredFiles(saveDir, "model(1)"),
    NA
  )
  expect_true(isTRUE(dirInfo[["readModel"]]))
  expect_equal(dirInfo[["nRun"]], 1L)
})

test_that(".ReadMCMC only matches files for the literal modelName, not regex-decoys", {
  readDir <- withr::local_tempdir()

  # intended file
  file.create(file.path(readDir, "model.v2_mcmc_run_1.rds"))
  # decoy that raw-"." pattern (matching any char) would also pick up
  file.create(file.path(readDir, "modelXv2_mcmc_run_1.rds"))

  mcmcFiles <- list.files(
    readDir,
    pattern = paste0(.EscapeRegex("model.v2"), "_mcmc_run_(\\d+)\\.rds$"),
    full.names = TRUE
  )

  expect_length(mcmcFiles, 1L)
  expect_true(grepl("^model\\.v2_mcmc_run_1\\.rds$", basename(mcmcFiles)))
})
