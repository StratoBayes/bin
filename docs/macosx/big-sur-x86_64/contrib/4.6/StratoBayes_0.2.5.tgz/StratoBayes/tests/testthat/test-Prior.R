test_that("UniformPrior works", {

  expect_error(UniformPrior(2,1), "min must be < max")

  expect_s3_class(UniformPrior(1,2), "Prior")

})

test_that("Fixed works", {

  expect_error(Fixed(2,1), "unused argument")

  expect_s3_class(Fixed(1), "Prior")

})

test_that("ExponentialPrior works", {

  expect_error(ExponentialPrior(-1), "rate must be")

  expect_s3_class(ExponentialPrior(1), "Prior")

})

test_that("NormalPrior works", {

  expect_error(NormalPrior(-1, 0), "sd must be")

  expect_s3_class(NormalPrior(2,2), "Prior")

})

test_that("LogNormalPrior works", {

  expect_error(LogNormalPrior(-2, -1), "sdlog must be")

  expect_s3_class(LogNormalPrior(-2,2), "Prior")

})

# RT-027/RT-113/RT-185: LogNormalPrior() must store its args *by name*
# (meanlog, sdlog), not positionally. `.PriorsValidity()` validates prior
# args via `modifyList(list(n = 1), prior[["args"]])`, which merges by name;
# a positional-only args list is silently dropped there and validation ran
# against the *default* rlnorm(n = 1) values rather than the user-supplied
# meanlog/sdlog. Named args also protect direct `Prior()` calls (and any
# future reordering of `dlnorm()`'s signature) against silently swapping the
# two parameters.
test_that("LogNormalPrior() stores args by name (RT-027/RT-113/RT-185)", {
  pri <- LogNormalPrior(meanlog = 3, sdlog = 0.5)

  expect_identical(names(pri[["args"]]), c("meanlog", "sdlog"))
  expect_equal(pri[["args"]][["meanlog"]], 3)
  expect_equal(pri[["args"]][["sdlog"]], 0.5)

  # RT-113: modifyList()-by-name (as used by .PriorsValidity()) must pick up
  # the user-supplied values, not silently fall back to rlnorm()'s defaults.
  merged <- modifyList(list(n = 1), pri[["args"]])
  expect_equal(merged[["meanlog"]], 3)
  expect_equal(merged[["sdlog"]], 0.5)
})

test_that("TruncNormalPrior works", {

  expect_error(TruncNormalPrior(0, 0, 1, 2), "sd must be")
  expect_error(TruncNormalPrior(0, 1, 3, 2), "lower must be")

  expect_s3_class(TruncNormalPrior(0,1,2,3), "Prior")

})

test_that("TruncLogNormalPrior works", {
  expect_error(TruncLogNormalPrior(0, 0, 1, 2), "sdlog must be")
  expect_error(TruncLogNormalPrior(0, 1, 3, 2), "lower must be")
  expect_error(TruncLogNormalPrior(0, 1, -1, 2), "lower must be >= 0")

  expect_s3_class(TruncLogNormalPrior(0, 1, 0, 3), "Prior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 2, 3), "Prior")

})

# RT-024: `.dtnorm()` (the density backing `TruncNormalPrior`) has no guard
# on its own -- the `TruncNormalPrior()` constructor guards `lower >= upper`,
# but a direct call to `.dtnorm()` bypassed it, and `upper == lower` used to
# silently yield a density of +Inf via log(Phi(z) - Phi(z)) = log(0) = -Inf
# normalisation.
test_that(".dtnorm() errors on a width-zero truncation interval (RT-024)", {
  expect_error(.dtnorm(1, mean = 0, sd = 1, lower = 2, upper = 1))
  expect_error(.dtnorm(1, mean = 0, sd = 1, lower = 1, upper = 1))

  expect_true(is.finite(.dtnorm(1, mean = 0, sd = 1, lower = 0, upper = 2)))
})

test_that("Fixed Q function returns value, not 1", {
  pri <- Fixed(42)
  result <- do.call(pri$Q, c(list(p = c(0.25, 0.5, 0.75)), pri$args))
  expect_equal(result, rep(42, 3))
})

# ── RT-244: deep-tail underflow in truncated sampling / quantile inversion ────

test_that("RT-244: deep-tail TruncNormalPrior draws are finite and in range", {
  set.seed(1)
  pri <- TruncNormalPrior(mean = 0, sd = 0.01, lower = 1, upper = 2)
  x <- do.call(pri$R, c(list(n = 100), pri$args))
  expect_true(all(is.finite(x)))
  expect_true(all(x >= 1 & x <= 2))
})

test_that("RT-244: deep-tail TruncLogNormalPrior draws are finite and in range", {
  set.seed(1)
  pri <- TruncLogNormalPrior(meanlog = 0, sdlog = 0.1, lower = 5, upper = 6)
  x <- do.call(pri$R, c(list(n = 100), pri$args))
  expect_true(all(is.finite(x)))
  expect_true(all(x >= 5 & x <= 6))
})

test_that("RT-244: .qtnorm/.qlnormTrunc return finite quantiles in deep tails", {
  p <- seq(0, 1, length.out = 51)
  qn <- .qtnorm(p, mean = 0, sd = 0.01, lower = 1, upper = 2)
  expect_true(all(is.finite(qn)))
  expect_true(all(qn >= 1 & qn <= 2))
  ql <- .qlnormTrunc(p, meanlog = 0, sdlog = 0.1, min = 5, max = 6)
  expect_true(all(is.finite(ql)))
  expect_true(all(ql >= 5 & ql <= 6))
})

test_that("RT-244: quantile endpoints p=0 / p=1 return exactly lower / upper", {
  # Moderate bounds (span branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 1, lower = -2, upper = 2), -2)
  expect_identical(.qtnorm(1, mean = 0, sd = 1, lower = -2, upper = 2), 2)
  # Deep-tail bounds (upper-tail branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 0.01, lower = 1, upper = 2), 1)
  expect_identical(.qtnorm(1, mean = 0, sd = 0.01, lower = 1, upper = 2), 2)
  # Deep left-tail bounds (lower-tail branch)
  expect_identical(.qtnorm(0, mean = 0, sd = 0.01, lower = -2, upper = -1), -2)
  expect_identical(.qtnorm(1, mean = 0, sd = 0.01, lower = -2, upper = -1), -1)
  # Log-normal, exact on the exponentiated scale
  expect_identical(.qlnormTrunc(0, 0, 0.1, min = 5, max = 6), 5)
  expect_identical(.qlnormTrunc(1, 0, 0.1, min = 5, max = 6), 6)
})

test_that("RT-244: stable rewrite matches naive formula where naive is valid", {
  p <- seq(0, 1, length.out = 101)
  # One-sided upper-tail regime, moderate enough that the naive form is a
  # trustworthy oracle (no underflow) yet still exercises the tail branch.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = 1, upper = 3),
               qnorm(pnorm(1) + p * (pnorm(3) - pnorm(1))),
               tolerance = 1e-9)
  # Lower-tail branch oracle.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = -3, upper = -1),
               qnorm(pnorm(-3) + p * (pnorm(-1) - pnorm(-3))),
               tolerance = 1e-9)
  # Log-normal upper-tail branch (log(min) > meanlog => upper tail).
  expect_equal(.qlnormTrunc(p, 0, 1, min = 2, max = 5),
               qlnorm(plnorm(2) + p * (plnorm(5) - plnorm(2))),
               tolerance = 1e-9)
  # Span branch: identical to the pre-fix naive computation.
  expect_equal(.qtnorm(p, mean = 0, sd = 1, lower = -2, upper = 2),
               qnorm(pnorm(-2) + p * (pnorm(2) - pnorm(-2))),
               tolerance = 1e-12)
})

test_that("RT-244: distribution unchanged in non-degenerate regime (KS test)", {
  set.seed(42)
  pri <- TruncNormalPrior(mean = 0, sd = 1, lower = -2, upper = 2)
  x <- do.call(pri$R, c(list(n = 5000), pri$args))
  # Theoretical truncated-normal CDF on [-2, 2].
  ptrunc <- function(q) {
    (pnorm(q) - pnorm(-2)) / (pnorm(2) - pnorm(-2))
  }
  expect_gt(suppressWarnings(ks.test(x, ptrunc)$p.value), 0.01)
  # Sample mean of a symmetric truncated normal should be ~0.
  expect_equal(mean(x), 0, tolerance = 0.05)
})

test_that("RT-245: bare truncated log-normal helpers reject min < 0", {
  expect_error(.rlnormTrunc(5, meanlog = 0, sdlog = 1, min = -1, max = 2),
               "lower must be >= 0")
  expect_error(.qlnormTrunc(0.5, meanlog = 0, sdlog = 1, min = -1, max = 2),
               "lower must be >= 0")
  # min == 0 must still succeed (log-normal support boundary).
  expect_silent(.qlnormTrunc(0.5, meanlog = 0, sdlog = 1, min = 0, max = 2))
})

test_that("NormalToLogNormal works", {

  expect_error(NormalToLogNormal(-1,0),
               "mu and sigma must be positive")

  a <- 0.5
  b <- 0.3
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)

  a <- 21
  b <- 2
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)
  }

          )

# ── RT-368: constructors don't validate scalar-ness ──────────────────────────

test_that("Prior constructors reject vector args with a clear message (RT-368)", {
  # Before the fix, a length>1 arg made the constructor's own `if (x <= 0)`
  # guard throw R's generic "the condition has length > 1" instead of the
  # constructor's intended message.
  expect_error(UniformPrior(min = c(0, 1), max = 2), "'min' must be a single")
  expect_error(UniformPrior(min = 0, max = c(1, 2)), "'max' must be a single")
  expect_error(ExponentialPrior(rate = c(1, 2)), "'rate' must be a single")
  expect_error(NormalPrior(mean = 0, sd = c(1, 2)), "'sd' must be a single")
  expect_error(LogNormalPrior(meanlog = 0, sdlog = c(1, 2)),
               "'sdlog' must be a single")
  expect_error(TruncNormalPrior(mean = 0, sd = 1, lower = c(-2, -1), upper = 2),
               "'lower' must be a single")
  expect_error(TruncLogNormalPrior(meanlog = 0, sdlog = 1, lower = 0.1,
                                    upper = c(1, 2)),
               "'upper' must be a single")
})

test_that("Prior constructors reject NA scalar args with a clear message (RT-368)", {
  # Before the fix, `NA` made the constructor's own `if (x <= 0)` guard
  # throw R's generic "missing value where TRUE/FALSE needed".
  expect_error(UniformPrior(min = NA, max = 2), "'min' must not be NA")
  expect_error(ExponentialPrior(rate = NA), "'rate' must not be NA")
  expect_error(NormalPrior(mean = 0, sd = NA), "'sd' must not be NA")
  expect_error(TruncNormalPrior(mean = 0, sd = 1, lower = NA, upper = 2),
               "'lower' must not be NA")
})

# ── RT-366: sampling/quantile side missing the lower<upper guard ─────────────

test_that(".rtnorm/.qtnorm/.rlnormTrunc/.qlnormTrunc reject lower>=upper (RT-366)", {
  # Before the fix, a reversed bound silently returned a degenerate point
  # mass at `upper` instead of erroring, unlike the already-guarded density
  # side (`.dtnorm()`/`TruncLogNormDensity()`, RT-024).
  expect_error(.qtnorm(0.5, lower = 5, upper = 2),
               "'upper' must be greater than 'lower'")
  expect_error(.rtnorm(1, lower = 5, upper = 2),
               "'upper' must be greater than 'lower'")
  expect_error(.qlnormTrunc(0.5, min = 5, max = 2),
               "'upper' must be greater than 'lower'")
  expect_error(.rlnormTrunc(1, min = 5, max = 2),
               "'upper' must be greater than 'lower'")
  # zero-width interval must also error, mirroring .dtnorm()'s guard
  expect_error(.qtnorm(0.5, lower = 2, upper = 2),
               "'upper' must be greater than 'lower'")
})

# ── RT-367: TruncLogNormDensity/.dtnorm/.qtnorm lost parameter vectorization ─
# (documented, not restored -- see the @note on TruncLogNormDensity() and the
# comments on .dtnorm()/.qtnorm() in R/Prior.R for why)

test_that("TruncLogNormDensity/.dtnorm/.qtnorm require scalar params (RT-367)", {
  expect_error(
    TruncLogNormDensity(x = c(0.5, 1, 2), min = c(0.1, 0.2, 0.1),
                         max = c(3, 3, 3))
  )
  expect_error(.dtnorm(1, mean = 0, sd = 1, lower = c(-2, -1), upper = 2))
  expect_error(.qtnorm(c(0.5, 0.5, 0.5), mean = c(0, 10, 20), sd = 1))
})

# ── RT-369: .qtnorm clamps out-of-[0,1] p rather than returning NaN ──────────
# (documented as intentional -- matches the C++ ThreadRNG::qtnorm_std core;
# locked in here so a future edit doesn't silently change this on one side
# only and break R/C++ parity)

test_that(".qtnorm clamps out-of-range p to the nearer bound (RT-369)", {
  expect_equal(.qtnorm(-0.1, lower = -2, upper = 2), -2)
  expect_equal(.qtnorm(1.5, lower = -2, upper = 2), 2)
  # contrast with stats::qnorm's NaN-on-out-of-range convention
  expect_true(is.nan(suppressWarnings(qnorm(-0.1))))
})

# ── RT-536/537/538 (#591): sd/sdlog/rate guards only rejected x <= 0, so
# Inf passed (Inf > 0 is TRUE) and produced a degenerate NaN/-Inf density
# instead of erroring at construction.
test_that("scale/rate constructors reject Inf (RT-536/537/538, #591)", {
  expect_error(NormalPrior(0, Inf), "sd must be")
  expect_error(LogNormalPrior(0, Inf), "sdlog must be")
  expect_error(ExponentialPrior(Inf), "rate must be")
  expect_error(TruncNormalPrior(0, Inf, -1, 1), "sd must be")
  expect_error(TruncLogNormalPrior(0, Inf, 0, 1), "sdlog must be")
})
