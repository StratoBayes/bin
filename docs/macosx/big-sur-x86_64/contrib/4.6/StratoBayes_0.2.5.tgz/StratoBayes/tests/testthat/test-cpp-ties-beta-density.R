# RT-030: the native ties dbeta density (MCMCEngine.cpp compute_logpost,
# densityType case 5) used a blanket `x <= 0 || x >= 1 -> -Inf` boundary
# guard. R's dbeta() gives a finite value at x=0 when shape1==1 (and
# symmetrically at x=1 when shape2==1), so the two diverged for Beta-prior
# ties pinned exactly at a support boundary.
#
# .sb_beta_ties_logdensity() is a thin internal export of the exact helper
# compute_logpost() calls, added so this boundary logic is unit-testable
# without needing a full StratData/engine setup with a tie age pinned to
# exactly 0 or 1.

test_that("native ties dbeta density matches R's dbeta() at and away from the boundary (RT-030)", {
  cases <- list(
    c(x = 0, a = 1,   b = 3),    # shape1 == 1 at x=0: finite (was -Inf pre-fix)
    c(x = 0, a = 1,   b = 1),    # both shapes 1 at x=0
    c(x = 1, a = 3,   b = 1),    # shape2 == 1 at x=1: finite (was -Inf pre-fix)
    c(x = 0, a = 0.5, b = 3),    # shape1 < 1 at x=0: density diverges (+Inf)
    c(x = 0, a = 2,   b = 3),    # shape1 > 1 at x=0: density is 0 (-Inf)
    c(x = 1, a = 3,   b = 0.5),  # shape2 < 1 at x=1: density diverges (+Inf)
    c(x = 1, a = 3,   b = 2),    # shape2 > 1 at x=1: density is 0 (-Inf)
    c(x = 0.3, a = 2, b = 3)     # interior point: unaffected by the fix
  )

  for (cs in cases) {
    expect_equal(
      StratoBayes:::.sb_beta_ties_logdensity(cs[["x"]], cs[["a"]], cs[["b"]]),
      dbeta(cs[["x"]], cs[["a"]], cs[["b"]], log = TRUE),
      info = sprintf("x=%s a=%s b=%s", cs[["x"]], cs[["a"]], cs[["b"]])
    )
  }

  # Outside [0,1] is always -Inf, matching dbeta()'s support.
  expect_equal(StratoBayes:::.sb_beta_ties_logdensity(-0.1, 1, 3), -Inf)
  expect_equal(StratoBayes:::.sb_beta_ties_logdensity(1.1, 1, 3), -Inf)
})
