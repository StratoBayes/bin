# RT-134: newRun=TRUE reusing a modelDir/modelName that previously held more
# runs must not leave stale _binarysamples_run_*.rds, _mcmc_run_*.rds, or
# _samples_run_*.txt files behind for the runs that no longer exist.

test_that("newRun=TRUE with fewer nRun removes stale files from a prior larger run", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), paste0("rt134_", format(Sys.time(), "%H%M%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  modelName <- "rt134test"

  # First run: nRun = 3
  suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = model,
      nIter = 20, nChains = 2, nRun = 3, seed = c(1, 2, 3),
      quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = modelName,
      engine = "cpp", nCores = 2L
    )
  )

  filesAfterFirstRun <- list.files(td, pattern = paste0("^", modelName, "_"))
  expect_true(any(grepl("_run_3", filesAfterFirstRun)))

  # Second run: reuses the same modelDir/modelName but nRun = 1 (newRun = TRUE
  # since stratObject is a fresh StratData object, not a StratPosterior)
  post <- suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = model,
      nIter = 20, nChains = 2, nRun = 1, seed = 2,
      quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = modelName,
      engine = "cpp", nCores = 2L
    )
  )

  # No stale run-2/run-3 files of any kind should remain
  filesAfterSecondRun <- list.files(td, pattern = paste0("^", modelName, "_"))
  expect_false(any(grepl("_run_2", filesAfterSecondRun)))
  expect_false(any(grepl("_run_3", filesAfterSecondRun)))

  posterior <- StratPosterior(readDir = td, modelName = modelName)
  expect_equal(posterior[["nRun"]], 1L)
  expect_equal(post[["nRun"]], 1L)
})
