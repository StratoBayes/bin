# Area-11 clustering fixes: #1163 (dead MCMC silhouette arguments, k = 1
# unreachable), #1164 (clustering the uncapped selection), #1165 (drifted
# `maxSamples` defaults), #1166 (dead code).
# `.WithClusterCache()` lives in helper-cluster-cache.R.

# ---------------------------------------------------------------------------
# #1164: `ExtractIterations()` must cap *before* it clusters
# ---------------------------------------------------------------------------

.ClusteredRowCount <- function(cacheEnv) {
  sum(lengths(cacheEnv$clusterCache[[1]][["value"]][["rowIndex"]]))
}

test_that("ExtractIterations() clusters the capped selection (#1164)", {
  # Pre-fix `.maxSampleDeterministicRows()` ran *after* `.ClusterInternal()`,
  # so the clustering saw all 300 post-burn-in rows however low `maxSamples`
  # was: this asserted 300 before the fix and asserts 100 after it.
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")

  ExtractIterations(sp, alignment = 1, burnIn = 0.5, maxSamples = 100)

  expect_length(ce$clusterCache, 1L)
  expect_equal(.ClusteredRowCount(ce), 100)
})

test_that("ExtractIterations()'s clustering matches Cluster()'s (#1164)", {
  # The user-visible symptom: two calls on the same object with the same
  # arguments disagreed about the alignments, because only one of them capped
  # its rows first.
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")

  ExtractIterations(sp, alignment = 1, burnIn = 0.5, maxSamples = 100)
  fromExtract <- ce$clusterCache[[1]][["value"]]

  direct <- Cluster(stratPosterior1, burnIn = 0.5, maxSamples = 100)

  expect_equal(lengths(fromExtract[["rowIndex"]]),
               lengths(direct[["rowIndex"]]))
  expect_equal(fromExtract[["nClustWithZero"]], direct[["nClustWithZero"]])
  expect_equal(fromExtract[["cluster"]], direct[["cluster"]])
})

test_that("an alignment selection is a subset of the clustered rows (#1164)", {
  # Regression guard, not a discriminator: this held before the fix too (the
  # clustering then covered a *superset* of the returned rows). It pins the
  # invariant the fix must not break -- no row may be labelled by a
  # clustering it did not take part in.
  sp <- .WithClusterCache(stratPosterior1, lazy = TRUE)
  ce <- .subset2(sp, ".cache")

  rows <- ExtractIterations(sp, alignment = 1, burnIn = 0.5, maxSamples = 100)
  clustered <- ce$clusterCache[[1]][["value"]][["rowIndex"]]

  expect_true(all(vapply(seq_along(rows), function(r) {
    all(rows[[r]] %in% clustered[[r]])
  }, logical(1))))
})

# ---------------------------------------------------------------------------
# #1165 / #903 / #393: one `maxSamples` default across every entry point
# ---------------------------------------------------------------------------

test_that("every maxSamples default is 2500 (#1165)", {
  # A hand-written list of call sites is what let this defect recur three
  # times (#393, #903, #1165), so enumerate the namespace instead: any future
  # entry point is covered automatically.
  ns <- asNamespace("StratoBayes")
  # `ExtractParameters()` is the documented exception: it returns posterior
  # draws rather than plotting them, so capping its output by default would
  # silently truncate the package's primary extraction function. Its
  # *clustering* is capped inside `ExtractIterations()` instead.
  exceptions <- c("ExtractParameters")

  defaults <- Filter(Negate(is.null), lapply(ls(ns), function(nm) {
    obj <- get(nm, envir = ns)
    if (!is.function(obj) || nm %in% exceptions) return(NULL)
    fm <- formals(obj)
    if (!"maxSamples" %in% names(fm)) return(NULL)
    d <- fm[["maxSamples"]]
    if (identical(d, quote(expr = ))) return(NULL) # no default
    setNames(list(eval(d)), nm)
  }))
  defaults <- unlist(defaults)

  expect_gt(length(defaults), 10L) # the guard is worthless if it found nothing
  expect_equal(defaults, setNames(rep(2500, length(defaults)),
                                  names(defaults)))
})

test_that("the maxSamples default matches the clustering budget (#1164)", {
  # `.kMaxClusterSamples` is what `ExtractIterations()` caps its clustering
  # at; `maxClusterSamples` is where `.ProtoClusterSubsample()` switches to
  # its outlier-blind path. Drift between them re-opens #903.
  expect_equal(eval(formals(Cluster.StratPosterior)[["maxClusterSamples"]]),
               .kMaxClusterSamples)
  expect_equal(eval(formals(Cluster.StratPosterior)[["maxSamples"]]),
               .kMaxClusterSamples)
})

# ---------------------------------------------------------------------------
# #1163: `.ProtoClusterFast()` must be able to return a single cluster
# ---------------------------------------------------------------------------

test_that(".ProtoClusterFast() returns k = 1 for a unimodal cloud (#1163)", {
  # The issue's own experiment: single-mode Gaussian fixtures returned k >= 2
  # in 80/80 cases before the fix, because `k_opt` was confined to
  # [2, clustMax] by construction. `silCutOff = 0.5` is the MCMC default.
  set.seed(1)
  reps <- vapply(seq_len(20), function(i) {
    dat <- matrix(rnorm(200 * 3), ncol = 3)
    max(.ProtoClusterFast(dat, clustMax = 12, silCutOff = 0.5))
  }, numeric(1))
  expect_true(all(reps == 1))

  # `silOutlierThreshold = TRUE` is `StratMCMC()`'s own default, and stripping
  # outliers *raises* the mean width -- so it could in principle lift a
  # unimodal cloud back over the cut-off and undo the escape. It does not.
  set.seed(1)
  production <- vapply(seq_len(20), function(i) {
    dat <- matrix(rnorm(200 * 3), ncol = 3)
    max(.ProtoClusterFast(dat, clustMax = 12, silCutOff = 0.5,
                          silOutlierThreshold = TRUE))
  }, numeric(1))
  expect_true(all(production == 1))
})

test_that(".ProtoClusterFast() still splits a genuinely bimodal cloud (#1163)", {
  set.seed(2)
  dat <- rbind(matrix(rnorm(100 * 2), ncol = 2),
               matrix(rnorm(100 * 2, mean = 30), ncol = 2))
  expect_equal(max(.ProtoClusterFast(dat, clustMax = 12, silCutOff = 0.5)), 2)
  expect_equal(max(.ProtoClusterFast(dat, clustMax = 12, silCutOff = 0.5,
                                     silOutlierThreshold = TRUE)), 2)
})

test_that("silCutOff = -Inf reproduces the pre-fix k >= 2 behaviour (#1163)", {
  # Pins the gate itself: with the cut-off disabled the gap heuristic's
  # answer is returned unchanged, so the k = 1 escape above is the gate's
  # doing and not a change to k selection.
  set.seed(3)
  dat <- matrix(rnorm(200 * 3), ncol = 3)
  expect_gte(max(.ProtoClusterFast(dat, clustMax = 12, silCutOff = -Inf)), 2)
})

test_that("silOutlierThreshold reaches .ProtoClusterFast() (#1163)", {
  # Both MCMC tuning arguments were dead: neither reached any clustering
  # call, and `.ProtoClusterFast()` could not emit the `0` outlier label at
  # all. The bridging points score badly enough to be flagged at 0.7.
  set.seed(4)
  dat <- rbind(matrix(rnorm(60 * 2, sd = 0.2), ncol = 2),
               matrix(rnorm(60 * 2, mean = 30, sd = 0.2), ncol = 2),
               cbind(seq(8, 22, length.out = 6), 15)) # bridging points
  keen <- .ProtoClusterFast(dat, clustMax = 6, silCutOff = -Inf,
                            silOutlierThreshold = 0.7)
  expect_true(any(keen == 0))
  none <- .ProtoClusterFast(dat, clustMax = 6, silCutOff = -Inf,
                            silOutlierThreshold = FALSE)
  expect_false(any(none == 0))
})

test_that("StratMCMC stores the silhouette arguments where the clustering
          reads them (#1163)", {
  mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 1, nThreads = 2L,
                    silCutOffMCMC = 0.25, silOutlierThresholdMCMC = FALSE)
  # `.UpdateProposal()` reads exactly these two slots; before the fix they
  # were written and never read.
  expect_equal(mcmc[[c("metro", "silCutOff")]], 0.25)
  expect_false(mcmc[[c("metro", "silOutlierThreshold")]])
})
