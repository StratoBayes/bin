# The -1e30 out-of-support sentinel and the consumers that still trusted it.
#
# Both engines clamp a non-finite prior/signal/ties term to -1e30. A DIFFERENCE
# of two sentinels is exactly 0, so anything reading a log-posterior difference
# sees the most reassuring number it can print at the moment the sampler is
# least healthy. These are the consumers that still read that difference
# (#1272, #1365) plus the residual R/C++ ties divergence (#1248, #1365 part 1).

# ── #1248 / #1365(1): an arithmetic NaN tie term must fold, not error ────────
# `is.na(NaN)` is TRUE in R, so the per-term guard hard-errored on a NaN term
# while the C++ accumulator folds every non-finite outcome onto the sentinel
# (src/MCMCEngine.cpp, `if (!R_finite(logLikTies))`).
# PRE-FIX both NaN tests below fail with "returned NA log-likelihood".
# A NaN tie AGE is what makes this reachable with a native density and no user
# callback at all: dnorm(NaN, 0, 1, log = TRUE) is NaN.

dispatchFixture <- function(ages, fns, args = NULL) {
  if (is.null(args)) args <- rep(list(list()), length(fns))
  list(
    data = list(ties = TRUE),
    model = list(.tiesDispatch = list(
      siteIndices = 1L,
      dispatch = list(Map(function(f, a) list(active = TRUE, fn = f, args = a),
                          fns, args))
    )),
    state = list(age = list(ties = list(as.list(ages))))
  )
}

normArgs <- list(mean = 0, sd = 1, log = TRUE)

test_that(".LogLikTies folds a NaN term onto the sentinel (#1365)", {
  f <- dispatchFixture(NaN, list(stats::dnorm), list(normArgs))
  expect_true(is.nan(do.call(stats::dnorm, c(list(NaN), normArgs))))
  expect_equal(.LogLikTies(f$data, f$model, f$state), -1e30)
})

test_that(".LogLikTies folds a NaN term beside a finite one (#1365)", {
  # Order-independence: the C++ accumulator does not short-circuit on NaN
  # either, so whichever term comes first the total folds.
  f1 <- dispatchFixture(c(NaN, 0), list(stats::dnorm, stats::dnorm),
                        list(normArgs, normArgs))
  expect_equal(.LogLikTies(f1$data, f1$model, f1$state), -1e30)

  f2 <- dispatchFixture(c(0, NaN), list(stats::dnorm, stats::dnorm),
                        list(normArgs, normArgs))
  expect_equal(.LogLikTies(f2$data, f2$model, f2$state), -1e30)
})

test_that(".LogLikTies still errors on a genuine NA term (#1365)", {
  # Deliberately NOT folded, and the one outcome on which the two engines still
  # differ: the C++ accumulator folds every NA too. Kept because this error
  # replaced an `na.rm = TRUE` that silently DROPPED the term. Tracked in #1413.
  f <- dispatchFixture(0, list(function(x) NA_real_))
  expect_error(.LogLikTies(f$data, f$model, f$state),
               "returned NA log-likelihood")
})

# The dynamic-lookup fallback path (no pre-built .tiesDispatch) carries its own
# copy of the guard.
fallbackFixture <- function(age) {
  list(
    data = list(
      ties = TRUE, S = 1L,
      tiesAttr = list(densityFun = matrix("dnorm", 1, 1),
                      arg1 = matrix(0, 1, 1), arg2 = matrix(1, 1, 1))
    ),
    model = list(alignmentScale = "age", tiesActive = matrix(TRUE, 1, 1)),
    state = list(age = list(ties = list(age)))
  )
}

test_that(".LogLikTies folds a NaN term on the fallback path too (#1365)", {
  f <- fallbackFixture(NaN)
  expect_equal(.LogLikTies(f$data, f$model, f$state), -1e30)

  ok <- fallbackFixture(0)
  expect_equal(.LogLikTies(ok$data, ok$model, ok$state),
               stats::dnorm(0, 0, 1, log = TRUE))
})

test_that(".LogLikTies still errors on a genuine NA on the fallback path", {
  # An NA tie AGE, not a broken densityFun: dnorm(NA_real_) is NA, not NaN, so
  # the surviving divergence covers a native density too (#1413).
  f <- fallbackFixture(NA_real_)
  expect_error(.LogLikTies(f$data, f$model, f$state),
               "returned NA log-likelihood")
})

# ── #1272 / #1365(2): a collapsed swap link must not score as perfect ────────

test_that(".SwapCollapsed fires only when BOTH endpoints are clamped (#1272)", {
  expect_true(.SwapCollapsed(-1e30, -1e30))
  expect_true(.SwapCollapsed(-1e31, -1e30))  # partial tempering sums components
  # One-sided is the escape route out of collapse and must keep its Inf/0.
  expect_false(.SwapCollapsed(-1e30, -50))
  expect_false(.SwapCollapsed(-50, -1e30))
  expect_false(.SwapCollapsed(-50, -52))
  # An NA energy must not error out of the `if`.
  expect_false(.SwapCollapsed(NA_real_, -1e30))
  expect_false(.SwapCollapsed(-1e30, NaN))
})

temperFixture <- function(logPost, temperatures) {
  nChains <- length(logPost)
  swapIndices <- t(utils::combn(nChains, 2))
  list(
    mcmc = list(
      nChains = nChains,
      endAdapting = 100,
      temper = list(
        tempering = TRUE,
        adaptTemperatures = TRUE,
        adaptTemperaturesIterations = 100,
        adaptTemperaturesIntervall = 100,
        temperatures = temperatures,
        temperRatioCapped = matrix(NA_real_, 4, nChains - 1),
        temperAdaptIndex = 1L,
        nSwapCombinations = nrow(swapIndices),
        nSwaps = nrow(swapIndices),
        swapIndices = swapIndices,
        ratio = rep(NA_real_, nrow(swapIndices)),
        accept = rep(NA, nrow(swapIndices)),
        newChainPositions = seq_len(nChains)
      )
    ),
    state = lapply(logPost, function(lp) list(metro = list(logPost = lp)))
  )
}

test_that(".Tempering scores a collapsed link 0, not 1 (#1272)", {
  # PRE-FIX: exp((L1-L2)/T2 + (L2-L1)/T1) is exp(0) == 1 for two sentinels, so
  # the ladder adapter was told the dead link mixed perfectly and the swap was
  # accepted with probability 1.
  set.seed(1)
  f <- temperFixture(c(-1e30, -1e30), c(1, 2))
  out <- .Tempering(f$mcmc, f$state, iteration = 1)

  expect_equal(out[["temperRatioCapped"]][1, 1], 0)
  expect_equal(out[["ratio"]][1], 0)
  expect_false(out[["accept"]][1])
})

test_that(".Tempering leaves the one-sided case as the escape route (#1272)", {
  # Cold chain collapsed, hot chain healthy: the ratio is a genuine +Inf and
  # the swap must still be accepted - that is how a collapsed state gets moved
  # up the ladder and out of the way.
  set.seed(1)
  esc <- temperFixture(c(-1e30, -50), c(1, 2))
  out <- .Tempering(esc$mcmc, esc$state, iteration = 1)
  expect_equal(out[["ratio"]][1], Inf)
  expect_true(out[["accept"]][1])
  expect_equal(out[["temperRatioCapped"]][1, 1], 1)

  # Hot chain collapsed instead: ratio 0, refused, and that 0 is honest.
  set.seed(1)
  rev <- temperFixture(c(-50, -1e30), c(1, 2))
  outRev <- .Tempering(rev$mcmc, rev$state, iteration = 1)
  expect_equal(outRev[["ratio"]][1], 0)
  expect_false(outRev[["accept"]][1])
})

test_that(".Tempering is unchanged on a healthy pair (#1272)", {
  set.seed(1)
  f <- temperFixture(c(-50, -52), c(1, 2))
  out <- .Tempering(f$mcmc, f$state, iteration = 1)
  expect_equal(out[["ratio"]][1], exp((-50 + 52) / 2 + (-52 + 50) / 1))
  expect_equal(out[["temperRatioCapped"]][1, 1], exp(-1))
})

test_that(".Tempering scores only the collapsed link of a mixed ladder (#1272)", {
  # The regime the fix actually changes. `.UpdateTemperatures()` moves rung j by
  # dS[j] = A[j-1] - A[j], so a UNIFORM column is a no-op whatever its value:
  # all-1 (pre-fix) and all-0 (post-fix) both freeze the ladder. Only a window
  # in which some links collapsed and others did not can move it.
  set.seed(1)
  f <- temperFixture(c(-1e30, -1e30, -50, -55), c(1, 2, 4, 8))
  out <- .Tempering(f$mcmc, f$state, iteration = 1)

  row <- out[["temperRatioCapped"]][1, ]
  expect_equal(row[[1]], 0)        # collapsed pair; PRE-FIX 1
  expect_equal(row[[2]], 1)        # one-sided, capped: the escape route survives
  expect_gt(row[[3]], 0)           # healthy pair, untouched
  expect_lt(row[[3]], 1)
})

test_that("a collapsed link moves the ladder it used to freeze (#1272)", {
  ladder <- function(A) {
    .UpdateTemperatures(list(
      nChains = 4L,
      temper = list(adaptTemperaturesCount = 0, adaptTemperaturesDecay = FALSE,
                    temperatures = c(1, 2, 4, 8),
                    temperRatioCapped = matrix(A, 1, 3, byrow = TRUE),
                    temperAdaptIndex = 5L)
    ))[["temperatures"]]
  }
  healthy <- exp((-50 + 55) / 8 + (-55 + 50) / 4)

  # Pre-fix the collapsed link reported the same 1 as its one-sided neighbour,
  # so dS[2] was 0 and the adapter spent the update confirming a fiction.
  expect_equal(ladder(c(1, 1, healthy)), c(1, 2, 4, 8))

  # Post-fix the two disagree, and the rung between them contracts towards the
  # cold end - the standard response to a link that never swaps.
  moved <- ladder(c(0, 1, healthy))
  expect_lt(moved[[2]], 2)
  expect_lt(moved[[3]], 4)
  expect_equal(moved[c(1, 4)], c(1, 8))  # both pinned rungs stay put
})

# ── #1272 end-to-end: the C++ engine's ladder-adaptation buffer ──────────────
# `RunStratModel()` recomputes the swap ratio from the ring buffer's energies
# rather than reading the C++ accept flags, so #1271's `temper_step()` override
# does not reach it. Same collapsed fixture as test-1247-1258: a tie on the
# non-reference site demanding an age of 1e6-2e6 that the sampler can never
# reach, so every chain sits at the sentinel.
test_that("a collapsed run stores 0 ladder ratios, not 1 (#1272)", {
  skip_on_cran()

  set.seed(9)
  h <- seq(0, 10, length.out = 20)
  sig <- data.frame(
    site = rep(c("s1", "s2"), each = 20), height = c(h, h),
    value = c(sin(h) + rnorm(20, 0, 0.1), sin(h) + rnorm(20, 0, 0.1))
  )
  ties <- data.frame(site = "s2", height = c(0, 10), densityFun = "dunif",
                     arg1 = 1e6, arg2 = 2e6)
  d <- StratData(signal = sig, ties = ties)
  m <- StratModel(d, priors = NULL, alignmentScale = "height",
                  sedModel = "site", nKnots = 8, knotRange = c(-2, 12),
                  flexibleKnots = FALSE)

  td <- file.path(tempdir(), "sb1272")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  mc <- StratMCMC(m, nIter = 60, nChains = 4L, nThreads = 2L,
                  tempering = TRUE, adaptTemperatures = TRUE,
                  adaptTemperaturesMonitor = TRUE)
  expect_warning(  # #1247: the fixture is collapsed by construction
    RunStratModel(stratObject = d, stratModel = m, stratMCMC = mc,
                  seed = 1, quiet = TRUE, visualise = FALSE,
                  modelDir = td, modelName = "t1272"),
    "stuck outside the support"
  )
  ratios <- readRDS(file.path(td, "t1272_mcmc_run_1.rds"))[[
    c("temper", "temperRatioCapped")]]

  recorded <- ratios[!is.na(ratios)]
  expect_gt(length(recorded), 0L)   # the buffer was actually filled
  expect_true(all(recorded == 0))   # PRE-FIX: all exactly 1
})
