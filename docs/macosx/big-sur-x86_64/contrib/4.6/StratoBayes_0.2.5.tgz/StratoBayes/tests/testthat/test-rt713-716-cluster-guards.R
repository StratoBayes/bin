# Area 11, round 2026-08-12: RT-713 (< 3 samples), RT-714 (NA input) and
# RT-716 (runs vs runSelect) against `R/Cluster.R`. RT-715 is a comment-only
# fix (fallback behaviour unchanged) and needs no regression test.

# ---------------------------------------------------------------------------
# RT-713: fewer than 3 selected samples is one degenerate cluster, not one
# per sample.
# ---------------------------------------------------------------------------

test_that("fewer than 3 selected samples yields one alignment, not one per sample (RT-713)", {
  cl <- Cluster(stratPosterior1, runs = 1, maxSamples = 2)
  expect_equal(cl[["nClust"]], 1)
  expect_equal(cl[["clustUnique"]], 1)
  expect_true(all(cl[["cluster"]] == 1L))
})

# ---------------------------------------------------------------------------
# RT-714: NA in clustering data must raise a clear R-level error, not an
# opaque C-level abort from protoclust().
# ---------------------------------------------------------------------------

test_that(".ProtoCluster errors clearly on an all-NA row (RT-714)", {
  m <- matrix(c(1, 2, NA, 4, 5, NA), nrow = 3)
  expect_error(.ProtoCluster(m, clustMax = 3), "entirely NA")
})

test_that(".ProtoClusterFast errors clearly on an all-NA row (RT-714)", {
  m <- matrix(c(1, 2, NA, 4, 5, NA), nrow = 3)
  expect_error(.ProtoClusterFast(m, clustMax = 3), "entirely NA")
})

test_that(".PamCluster errors clearly on an all-NA row (RT-714)", {
  m <- matrix(c(1, 2, NA, 4, 5, NA), nrow = 3)
  expect_error(.PamCluster(m, clustMax = 3), "entirely NA")
})

test_that(".ProtoCluster errors clearly when rows share no non-missing column (RT-714)", {
  # No single row is all-NA, but rows 1 and 3 share no non-missing column, so
  # their pairwise distance is NaN just the same.
  m <- matrix(c(1, NA, 3, NA, 5, 6), nrow = 3)
  expect_error(.ProtoCluster(m, clustMax = 3), "NA")
})

# ---------------------------------------------------------------------------
# RT-716: `runs` must not silently disagree with `options$runSelect`.
# ---------------------------------------------------------------------------

test_that("runs is documented as possibly narrower than options$runSelect (RT-716)", {
  cl <- suppressWarnings(Cluster(stratPosterior1, maxSamples = 2))
  expect_setequal(cl[["options"]][["runSelect"]], 1:3)
  # A run selected but contributing zero rows (via maxSamples rounding) is
  # absent from `runs` -- this is documented behaviour (see ?Cluster), not
  # tested as a bug: consumers must read `options$runSelect` for the full
  # selected set.
  expect_true(all(cl[["runs"]] %in% cl[["options"]][["runSelect"]]))
})
