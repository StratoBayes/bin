# Regression tests for #1330 item 7: colourBy = "none" left `bg`/`pch`
# unset, so `NULL[[1]]` produced NULL fill/point-shape values and points
# fell back to open unfilled circles instead of the filled pch 21-25 style
# used by colourBy = "run"/"alignment".

test_that("ScatterPlot fills points with a default bg/pch under colourBy = 'none'", {
  capturedPch <- "unset"
  capturedBg <- "unset"
  testthat::local_mocked_bindings(
    points = function(...) {
      dots <- list(...)
      if ("pch" %in% names(dots)) {
        capturedPch <<- dots[["pch"]]
        capturedBg <<- dots[["bg"]]
      }
      invisible(NULL)
    },
    .package = "StratoBayes"
  )
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  invisible(ScatterPlot(stratPosterior1, colourBy = "none", type = "p"))

  # guards against the mock silently never firing (e.g. after a refactor of
  # the `do.call(points, ...)` this test targets), which would otherwise
  # leave the assertions below vacuously true
  expect_false(identical(capturedPch, "unset"))
  expect_false(is.null(capturedPch))
  expect_false(is.null(capturedBg))
})

test_that("TracePlot fills points with a default pch under colourBy = 'none'", {
  capturedPch <- "unset"
  capturedBg <- "unset"
  testthat::local_mocked_bindings(
    points = function(...) {
      dots <- list(...)
      if ("pch" %in% names(dots)) {
        capturedPch <<- dots[["pch"]]
        capturedBg <<- dots[["bg"]]
      }
      invisible(NULL)
    },
    .package = "StratoBayes"
  )
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  invisible(TracePlot(stratPosterior1, colourBy = "none", type = "p"))

  # guards against the mock silently never firing; see ScatterPlot test above
  expect_false(identical(capturedPch, "unset"))
  expect_false(is.null(capturedPch))
  # `bg` was already defaulted before this fix; kept here as a guard against
  # regressing it while adding the `pch` default.
  expect_false(is.null(capturedBg))
})
