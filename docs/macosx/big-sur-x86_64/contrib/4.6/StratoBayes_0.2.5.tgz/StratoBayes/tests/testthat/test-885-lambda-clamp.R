# GH #885 — the alignment Gibbs sweep must form M = H + lambda*D from the
# lambda it was given, with no pre-factorisation clamp.
#
# src/Gibbs.cpp used to raise any incoming lambda below an absolute 1e-10
# before building M, while src/MCMCEngine.cpp's gibbs_one_signal never did.
# Since #603 made lambdaMin = 1e-5 * lambdaStar scale-relative, a large-y-scale
# fit has lambdaMin BELOW 1e-10, so the clamp bound on the estimated path and
# the two alignment engines factorised different matrices from identical state.
# Measured at sd(y) = 425 on the bundled multi-site data: the clamp inflated
# lambda 29-112x and moved the conjugate mean of beta 0.3%, while the
# accept/reject marginal (src/LogPost.cpp) read lambda unclamped and separated
# the same two states by 230 nats.
# Full measurement: dev/red-team/heavy-tests/RT-698-lambda-clamp-divergence.md
#
# Oracle is the conjugate algebra, not a second implementation: .GibbsSample()
# is a thin Rcpp wrapper on .sb_gibbs (#584).
#
# SCOPE (#1226): every assertion below routes through .sb_gibbs, so this file
# pins src/Gibbs.cpp only, despite the header above naming both engines.
# src/MCMCEngine.cpp's gibbs_one_signal is a separate implementation --
# `static`, reached only through a full engine run, forming M by a banded path
# with its own Cholesky/ridge ladder -- so re-introducing the same clamp there
# would leave this file fully green. Contract entry G1
# (docs/r-engine-contract.md); a value-level pin needs an engine-reachable
# export this file cannot supply.

clamp_fixture <- function(lambda) {
  set.seed(885)
  p <- 6L
  n <- 40L
  # H on a scale where a 1e-10 ridge is a visible perturbation, as it is for
  # the large-y-scale fits that reach this regime (H = B'B / sigma^2).
  A <- matrix(stats::rnorm(n * p), n, p)
  H <- crossprod(A) * 1e-6
  # Second-difference penalty: the shape D actually has (rank p - 2).
  Dif <- diff(diag(p), differences = 2L)
  D <- crossprod(Dif)
  tBy <- as.numeric(H %*% stats::rnorm(p))
  list(
    H_list = list(H), tBy_list = list(tBy), B_list = list(A),
    signalValuesVec = list(as.numeric(A %*% stats::rnorm(p))),
    sigma_in = 1, lambda_in = lambda, D_mat = D,
    Q_fallback = list(diag(p)),
    aLambda = 1, bLambda = 1, shapeSigma = 1, bSigma_prior = 1,
    numBasis = p, sigmaIsFixed = TRUE, sigmaFixedValues = 1,
    hasOffsets = FALSE, delta_list = list(), tau_in = numeric(0),
    obsToGroup_list = list(), nGroups = 0L, tauFixed = FALSE,
    tauFixedValue = 0, aTau = 1, bTau = 1,
    lambdaMin = 1e-16
  )
}

# Q = M^{-1} is a deterministic function of the inputs, so it pins which M was
# factorised without any dependence on the RNG stream.
q_for <- function(lambda) {
  set.seed(1)
  do.call(StratoBayes:::.sb_gibbs, clamp_fixture(lambda))[["Q"]][[1]]
}

test_that(".sb_gibbs factorises M at the lambda it was given (#885)", {
  args <- clamp_fixture(1e-14)
  H <- args$H_list[[1]]
  D <- args$D_mat

  # Sub-clamp lambda: Q must invert H + 1e-14 D, not the clamped H + 1e-10 D.
  expect_equal(q_for(1e-14), solve(H + 1e-14 * D), tolerance = 1e-8)

  # RED before the fix: the clamp made every sub-1e-10 lambda give the same M.
  expect_false(isTRUE(all.equal(q_for(1e-14), q_for(1e-10))))
  expect_false(isTRUE(all.equal(q_for(1e-14), solve(H + 1e-10 * D),
                                tolerance = 1e-8)))
})

test_that("removing the clamp leaves lambda >= 1e-10 untouched (#885)", {
  args <- clamp_fixture(3e-9)
  # The clamp was a no-op at or above 1e-10, so every run at an ordinary
  # y-scale is bit-identical across the fix.
  expect_equal(q_for(3e-9), solve(args$H_list[[1]] + 3e-9 * args$D_mat),
               tolerance = 1e-8)
  expect_equal(q_for(1e-10), solve(args$H_list[[1]] + 1e-10 * args$D_mat),
               tolerance = 1e-8)
})
