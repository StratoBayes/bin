test_that("Tops works", {

   expect_error(Tops(1, 2, 2), "stratObject must be")

  tops6 <- Tops(stratPosterior1, 6)
  tops6Site2 <- round(tops6[1,"50%"])
  expect_equal(tops6Site2, 0)

  tops6Site3 <- round(tops6[2,"50%"])
  expect_equal(tops6Site3, 5)

  expect_s3_class(Tops(stratPosterior3, -2), "data.frame")

})

#
test_that("Tops works with prior", {
   #set.seed(1)
   h1 <- Tops(stratModel1, refHeights = 6, stratData = stratData1)

   prior2Q25 <- round(h1[1, "2.5%"]/10)
   prior3Q25 <- round(h1[2, "2.5%"]/10)
   prior2Q500 <- round(h1[1, "50%"]/2 - 0.1)
   prior3Q500 <- round(h1[2, "50%"]/2 - 0.1)

   expect_equal(prior2Q25, -1)
   expect_equal(prior3Q25, -1)
   expect_equal(prior2Q500, 1)
   expect_equal(prior3Q500, 1)

})

test_that("Tops works with returning samples", {
  #set.seed(1)
  # RT-195: quantiles = "samples" now returns wide format (one row per
  # refHeight x site, one column per sample) to match StratMap()'s wide
  # output, rather than the previous long (ref x site x sample) format.
  t1 <- Tops(stratPosterior1, refHeights = 6,
             quantiles = "samples", iterations = c(100, 150), runs = 1)

  expect_equal(nrow(t1), 2)
  expect_equal(ncol(t1), 4)
  expect_equal(names(t1)[1:2], c("refHeight", "site"))
  expect_equal(names(t1)[-(1:2)], c("sample_1", "sample_2"))
})

test_that("Tops() quantiles = 'samples' wide output matches StratMap() shape (RT-195)", {
  tSamples <- Tops(stratPosterior1, refHeights = c(1, 6),
                    quantiles = "samples", iterations = c(100, 150), runs = 1)
  nRef   <- 2
  nSites <- length(unique(tSamples$site))
  nSamp  <- ncol(tSamples) - 2

  expect_equal(nrow(tSamples), nRef * nSites)
  expect_true(all(vapply(tSamples[-(1:2)], is.numeric, logical(1))))

  # shape parity with StratMap(quantiles = "samples"): first column is the
  # height/refHeight axis, remaining columns are one per retained sample.
  mapSamples <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                          quantiles = "samples", iterations = c(100, 150), runs = 1)
  expect_equal(ncol(mapSamples) - 1, nSamp)
})


test_that("Tops works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              Tops(stratPosterior3,
                       refHeights = -1,
                       stratCluster = clustNew,
                       alignment = 1)[ , "sd"]
              <
                Tops(stratPosterior3,
                         refHeights = -1,
                         stratCluster = clustNew,
                         alignment = "all")[ , "sd"]

            )
          })

test_that("Tops works with default refHeights", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              round(Tops(stratPosterior1)[4, "50%"]) == 4)
          })

test_that("Tops(quantiles = numeric(0)) errors clearly instead of crashing (RT-283)", {
  expect_error(
    Tops(stratPosterior1, refHeights = c(1, 2), quantiles = numeric(0)),
    "quantiles must not be empty"
  )
})

test_that("Tops(refHeights = numeric(0)) errors clearly instead of crashing (RT-284)", {
  expect_error(
    Tops(stratPosterior1, refHeights = numeric(0)),
    "refHeights must not be empty"
  )
})

test_that("Tops(quantiles containing NA) errors clearly instead of silently returning an all-NA column (RT-458)", {
  expect_error(
    Tops(stratPosterior1, refHeights = c(1, 2), quantiles = c(0.025, 0.5, NA)),
    "quantiles must not contain NA"
  )
})

test_that("Tops(alignment = NA) errors clearly instead of crashing (RT-461)", {
  expect_error(
    Tops(stratPosterior1, refHeights = c(1, 2), alignment = NA),
    "`alignment` must not contain NA"
  )
})

test_that("Tops() requires explicit refHeights on the age scale instead of silently extrapolating (RT-455)", {
  expect_equal(stratPosterior2[[c("model", "ind", "alignmentScale")]], "age")

  expect_error(
    Tops(stratPosterior2),
    "must be supplied explicitly for age-scale alignments"
  )

  # explicit refHeights still work -- the core age-scale mapping is correct,
  # only the height-based default was the problem
  expect_no_error(
    Tops(stratPosterior2, refHeights = c(20.41, 27.20, 33.99), maxSamples = 5)
  )
})

test_that("Tops(parameters = <numeric vector>) matches the named-data.frame form instead of returning NaN (RT-466)", {
  # selectRows = 1 selects run 1's whole chain (3 rows here); take a single
  # posterior draw so the numeric-vector and data.frame forms carry the same
  # one sample -- otherwise mean/sd legitimately differ (1 vs several draws).
  p <- ExtractParameters(stratPosterior1, parameters = "parameters", selectRows = 1)
  p1 <- p[1, , drop = FALSE]
  pvec <- as.numeric(p1)

  topsVec <- Tops(stratPosterior1, refHeights = c(1, 2), parameters = pvec,
                  quantiles = 0.5)
  expect_true(all(is.finite(topsVec[["50%"]])))

  # cross-check against the already-correct named-data.frame path (per the
  # issue, only the plain-vector form went through the name-less coercion)
  topsDf <- Tops(stratPosterior1, refHeights = c(1, 2), parameters = p1,
                quantiles = 0.5)
  expect_equal(topsVec, topsDf)
})

test_that("Tops() prior branch: maxSamples = 1 returns a shape-correct single-sample matrix, not a transposed vector (RT-589, #698)", {
  set.seed(1)
  out <- Tops(stratModel1, refHeights = 0, stratData = stratData1,
              maxSamples = 1, quantiles = "samples")
  expect_equal(ncol(out), 3)  # refHeight, site, 1 sample column
  expect_true(all(is.finite(out[[3]])))

  set.seed(1)
  out5 <- Tops(stratModel1, refHeights = 0, stratData = stratData1,
               maxSamples = 5, quantiles = "samples")
  expect_equal(ncol(out5), 7)  # refHeight, site, 5 sample columns
  expect_true(all(is.finite(as.matrix(out5[, -(1:2)]))))
})

test_that("Tops() prior branch rejects invalid maxSamples instead of silently returning NA (RT-591, #698)", {
  expect_error(
    Tops(stratModel1, refHeights = 0, stratData = stratData1, maxSamples = 0),
    "maxSamples` must be a single finite whole number"
  )
  expect_error(
    Tops(stratModel1, refHeights = 0, stratData = stratData1, maxSamples = -1),
    "maxSamples` must be a single finite whole number"
  )
  expect_error(
    Tops(stratModel1, refHeights = 0, stratData = stratData1, maxSamples = 2.5),
    "maxSamples` must be a whole number"
  )
})

test_that("Tops() posterior branch validates maxSamples as strictly as the prior branch (#1013, #912)", {
  expect_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = -1),
    "maxSamples"
  )
  expect_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = NA),
    "maxSamples"
  )
  expect_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = "2"),
    "maxSamples"
  )
  expect_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = c(2, 3)),
    "maxSamples"
  )
  # non-integer maxSamples must be rejected on both branches identically
  expect_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = 2.5),
    "maxSamples` must be a whole number"
  )
  # Inf remains a legitimate "no cap" value on the posterior branch
  expect_no_error(
    Tops(stratPosterior1, refHeights = 1, maxSamples = Inf)
  )
})

test_that("Tops() rejects non-finite refHeights instead of silently extrapolating (RT-596, #700)", {
  expect_error(
    Tops(stratPosterior1, refHeights = c(1, Inf)),
    "refHeights must be finite"
  )
  # a large-but-finite value now hits the extrapolation range check below
  expect_error(
    Tops(stratPosterior1, refHeights = 1e9),
    "extrapolation is not supported"
  )
})

test_that("Tops() rejects extreme refHeights (RT-718, #910)", {
  # stratPosterior1 site 1 spans 0 to 10
  expect_error(
    Tops(stratPosterior1, refHeights = 1010),
    "extrapolation is not supported"
  )
  expect_error(
    Tops(stratPosterior1, refHeights = -500),
    "extrapolation is not supported"
  )
  # boundary values and in-range values are unaffected
  expect_no_error(Tops(stratPosterior1, refHeights = 0))
  expect_no_error(Tops(stratPosterior1, refHeights = 10))
  expect_no_error(Tops(stratPosterior1, refHeights = 5))

  # age-scale alignments have no fixed reference-site bound to check against
  expect_equal(stratPosterior2[[c("model", "ind", "alignmentScale")]], "age")
  expect_no_error(
    Tops(stratPosterior2, refHeights = 1e6, maxSamples = 5)
  )
})

test_that("Tops() applies the maxSamples cap on the stratCluster-supplied selectRows path (RT-599, #701)", {
  clustNew <- Cluster(stratPosterior3, iterations = 300:400)
  out <- Tops(stratPosterior3, refHeights = -1, stratCluster = clustNew,
              alignment = 1, maxSamples = 10, quantiles = "samples")
  expect_lte(ncol(out) - 2, 10)  # sample columns, excluding refHeight/site
})

test_that("Tops() matches StratMap()'s partial-match convention for quantiles = 'samples' (RT-601, #703)", {
  full <- Tops(stratPosterior1, refHeights = 1, quantiles = "samples", maxSamples = 3)
  partial <- Tops(stratPosterior1, refHeights = 1, quantiles = "sam", maxSamples = 3)
  expect_equal(full, partial)
})

test_that("Tops() prior branch honours `parameters` instead of always drawing fresh (RT-717, #909)", {
  set.seed(1)
  a <- Tops(stratModel1, refHeights = c(1, 2), stratData = stratData1,
            parameters = rep(1, stratModel1[["parametersLength"]]))
  set.seed(1)
  b <- Tops(stratModel1, refHeights = c(1, 2), stratData = stratData1,
            parameters = rep(5, stratModel1[["parametersLength"]]))
  # before the fix, both calls drew fresh prior samples and ignored
  # `parameters` entirely, so identical seeds gave identical() output
  # regardless of the (very different) supplied parameter values
  expect_false(identical(a, b))
})

test_that("Tops() prior branch rejects alignment/runs/iterations instead of silently ignoring them (RT-717, #909)", {
  expect_error(
    Tops(stratModel1, refHeights = 1, stratData = stratData1, runs = 99),
    "do not apply when `stratObject` is a `StratModel`"
  )
  expect_error(
    Tops(stratModel1, refHeights = 1, stratData = stratData1, alignment = 1),
    "do not apply when `stratObject` is a `StratModel`"
  )
  expect_error(
    Tops(stratModel1, refHeights = 1, stratData = stratData1, iterations = 1:10),
    "do not apply when `stratObject` is a `StratModel`"
  )
  # defaults (i.e. not explicitly supplying these args) still work
  expect_no_error(
    Tops(stratModel1, refHeights = 1, stratData = stratData1)
  )
})

test_that("Tops() quantiles bounds are validated for numeric input (RT-601, #703)", {
  expect_error(
    Tops(stratPosterior1, refHeights = 1, quantiles = 1.5),
    "quantiles must be numeric values between 0 and 1"
  )
  expect_error(
    Tops(stratPosterior1, refHeights = 1, quantiles = c(-0.1, 0.5)),
    "quantiles must be numeric values between 0 and 1"
  )
})
