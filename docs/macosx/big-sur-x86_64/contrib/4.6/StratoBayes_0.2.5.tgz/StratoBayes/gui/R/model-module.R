model_server <- function(input, output, session, data_api, priorSettings, r) {

  # Windows/callr: trailing slash makes RunStratModel nest output under modelName;
  # empty nested dirs from older runs must not override the folder that has *_data.rds.
  .strip_trailing_path_sep <- function(p) {
    if (!length(p) || !nzchar(p)) return(p)
    sub("[/\\\\]+$", "", p)
  }

  # Pre-flight: count sites with non-NA values for each signal column on the
  # actual StratData object that will be sent to RunStratModel. The hard rule
  # in StratData() is "each signalColumn must have non-NA values in >=2 sites";
  # we mirror it here so we can abort the run with an actionable, GUI-visible
  # error before launching the background process.
  .signalCoverageReport <- function(sd) {
    if (!inherits(sd, "StratData")) return(NULL)
    sig_df <- sd[["signal"]]
    site_col <- sd[["siteColumn"]] %||% "site"
    sig_names <- sd[[c("signalAttr", "signalNames")]]
    if (is.null(sig_names) || !length(sig_names)) sig_names <- setdiff(colnames(sig_df), c(site_col, sd[["zColumn"]]))
    sites <- sd[["sites"]] %||% unique(sig_df[[site_col]])
    out <- lapply(sig_names, function(sig) {
      per_site <- vapply(sites, function(s) {
        any(!is.na(sig_df[[sig]][sig_df[[site_col]] == s]))
      }, logical(1))
      list(signal = sig,
           sitesWithData = sites[per_site],
           nSitesWithData = sum(per_site))
    })
    names(out) <- sig_names
    out
  }

  .resolve_run_output_dir <- function(base_dir, model_name) {
    base_dir <- .strip_trailing_path_sep(base_dir)
    flat_rds <- file.path(base_dir, paste0(model_name, "_data.rds"))
    if (file.exists(flat_rds)) return(base_dir)
    nested_dir <- file.path(base_dir, model_name)
    nested_rds <- file.path(nested_dir, paste0(model_name, "_data.rds"))
    if (file.exists(nested_rds)) return(nested_dir)
    base_dir
  }

  # Helper function to format parameter names for display
  formatParameterName <- function(name) {
    if (grepl("^gammaLog_", name, ignore.case = TRUE)) {
      sub("^gammaLog_", "relative sed. rate (\u03bd) ", name, ignore.case = TRUE)
    } else if (grepl("^alpha_", name, ignore.case = TRUE)) {
      sub("^alpha_", "correlation anchor (\u03b1) ", name, ignore.case = TRUE)
    } else {
      name
    }
  }

  output$siteModelNote <- renderUI({
    HeaderLine <- paste(
      "Distinct sedimentation rate for each",
      switch(
        input$sedModel,
        "site"             = "site",
        "partition"        = "partition",
        "site x partition" = "site × partition",
        "site, partition"  = "partition at each site",
        input$sedModel
      )
    )

    Idx   <- indices()
    if (is.null(Idx)) {
      return(tags$div(
        style = "color: #d9534f; padding: 10px; border: 1px solid #d9534f; border-radius: 4px;",
        tags$strong("⚠ Error: Invalid alpha position values"),
        tags$p("Please check the custom alpha position values and ensure they are within the valid range for each section.",
               style = "margin-top: 5px;")
      ))
    }
    Names <- if (!is.null(Idx) && length(Idx$names) > 0) Idx$names else character(0)

    Alphas <- sort(unique(Names[grepl("(^|_)alpha", Names, ignore.case = TRUE)]))
    Gammas <- sort(unique(Names[grepl("(^|_)gamma", Names, ignore.case = TRUE)]))
    Zetas  <- sort(unique(Names[grepl("(^|_)zeta",  Names, ignore.case = TRUE)]))
    Deltas <- sort(unique(Names[grepl("(^|_)(delta|gap)", Names, ignore.case = TRUE)]))

    AlphasDisplay <- vapply(Alphas, formatParameterName, character(1))
    GammasDisplay <- vapply(Gammas, formatParameterName, character(1))
    ZetasDisplay  <- vapply(Zetas,  formatParameterName, character(1))
    DeltasDisplay <- vapply(Deltas, formatParameterName, character(1))

    GammaLabel <- if (!is.null(input$alignmentScale) &&
                      tolower(input$alignmentScale) == "height") {
      "Relative sedimentation rates"
    } else {
      "Sedimentation rates"
    }

    MakeSection <- function(Label, Items) {
      if (length(Items) == 0) return(NULL)
      tags$div(
        tags$div(tags$u(paste0(Label, ":"))),
        lapply(Items, function(x) tags$div(x))
      )
    }

    Sections <- Filter(Negate(is.null), list(
      MakeSection("Correlation anchor", AlphasDisplay),
      MakeSection(GammaLabel,           GammasDisplay),
      MakeSection("Site-specific sedimentation rate multipliers", ZetasDisplay),
      MakeSection("Unconformities",     DeltasDisplay)
    ))

    Children <- if (length(Sections) > 0) {
      unlist(Map(function(s) list(s, tags$br()), Sections), recursive = FALSE)[-length(Sections)*2]
    } else NULL

    tags$div(
      tags$div(tags$strong(HeaderLine)),
      if (!is.null(Children)) list(tags$br(), Children)
    )
  })

  # Store last non-custom alpha position to default custom values
  lastAlphaPosition <- reactiveVal("middle")

  # Store validated custom alpha values (only updated when Update button is clicked)
  storedCustomAlphaValues <- reactiveVal(list())

  isLoadingSettings <- reactiveVal(FALSE)

  storedPenaltyMultiplier <- reactiveVal(NULL)
  storedNKnots <- reactiveVal(NULL)
  storedBLambdaLog <- reactiveVal(NULL)

  observeEvent(input$alphaPosition, {
    if (input$alphaPosition != "custom") {
      lastAlphaPosition(input$alphaPosition)
      if (!isLoadingSettings()) storedCustomAlphaValues(list())
    }
  })

  customAlphaInitialized <- reactiveVal(FALSE)

  observeEvent(input$alphaPosition, {
    if (input$alphaPosition != "custom") customAlphaInitialized(FALSE)
  })

  output$customAlphaInputs <- renderUI({
    req(data_api$signalValid())
    req(input$alphaPosition == "custom")

    sd <- data_api$stratData()
    sites <- sd$sites
    alignmentScale <- input$alignmentScale %||% "height"

    if (alignmentScale == "height") {
      inputSites <- sites[-1]
      if (length(inputSites) == 0) return(tags$p("No sites available for custom alpha position."))
    } else {
      inputSites <- sites
      if (length(inputSites) == 0) return(tags$p("No sites available for custom alpha position."))
    }

    lastPos <- isolate(lastAlphaPosition())
    storedValues <- isolate(storedCustomAlphaValues())
    isInitialized <- isolate(customAlphaInitialized())

    siteInputs <- lapply(seq_along(inputSites), function(i) {
      site <- inputSites[i]
      site_idx <- match(site, sites)

      bottom <- tryCatch({ sd[[c("partsAttr", "BoundLow")]][1, site_idx] }, error = function(e) NULL)
      top    <- tryCatch({ max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE) }, error = function(e) NULL)

      if (is.null(bottom) || is.null(top) || is.na(bottom) || is.na(top) || !is.finite(bottom) || !is.finite(top)) {
        heights <- tryCatch({
          StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
        }, error = function(e) NULL)

        if (!is.null(heights) && length(heights) > 0) {
          heights <- heights[is.finite(heights) & !is.na(heights)]
          if (length(heights) > 0) {
            bottom <- min(heights, na.rm = TRUE)
            top    <- max(heights, na.rm = TRUE)
            if (!is.finite(bottom) || !is.finite(top) || bottom >= top) {
              median_height <- median(heights, na.rm = TRUE)
              if (is.finite(median_height)) {
                bottom <- median_height - 10
                top    <- median_height + 10
              } else {
                bottom <- 0; top <- 100
              }
            }
          } else {
            bottom <- 0; top <- 100
          }
        } else {
          bottom <- 0; top <- 100
        }
      }

      if (!is.finite(bottom) || !is.finite(top) || bottom >= top) { bottom <- 0; top <- 100 }

      inputId <- paste0("customAlpha_", site)

      # Get current value - check existing input first, then stored, then default (only if not initialized)
      existingInput <- isolate(input[[inputId]])
      storedValue   <- storedValues[[site]]

      # Determine value to use
      if (!is.null(existingInput) && !is.na(existingInput)) {
        # Always preserve existing input value - never auto-update
        currentVal <- existingInput
      } else if (!is.null(storedValue) && !is.na(storedValue)) {
        # Use stored value if available
        currentVal <- storedValue
      } else if (!isInitialized) {
        # Only set default on first initialization
        if (lastPos == "top") {
          currentVal <- top
        } else if (lastPos == "bottom") {
          currentVal <- bottom
        } else {
          currentVal <- (bottom + top) / 2
        }
      } else {
        # Already initialized - use a safe default to avoid errors
        currentVal <- (bottom + top) / 2
      }

      # Create numeric input
      numericInput(
        inputId = inputId,
        label   = paste0("Alpha position for ", site),
        value   = currentVal,
        step    = (top - bottom) / 100
      )
    })

    if (!isInitialized) customAlphaInitialized(TRUE)

    tagList(
      tags$div(
        style = "margin-top: 10px;",
        tags$strong("Custom alpha positions:"),
        tags$p("Enter numeric values for each site (beyond reference site for height scale). Click 'Update' to validate.",
               style = "font-size: 0.9em; color: #666;")
      ),
      siteInputs
    )
  })

  observeEvent(input$updateAlphaPositions, {
    req(data_api$signalValid())
    req(input$alphaPosition == "custom")

    sd <- data_api$stratData()
    sites <- sd$sites
    alignmentScale <- input$alignmentScale %||% "height"

    inputSites <- if (alignmentScale == "height") sites[-1] else sites

    errors <- character(0)
    storedValues <- list()

    for (site in inputSites) {
      inputId <- paste0("customAlpha_", site)
      val <- input[[inputId]]

      if (!is.null(val) && !is.na(val)) {
        site_idx <- match(site, sites)
        bottom <- tryCatch({ sd[[c("partsAttr", "BoundLow")]][1, site_idx] }, error = function(e) NULL)
        top    <- tryCatch({ max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE) }, error = function(e) NULL)

        if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
          if (val < bottom || val > top) {
            errors <- c(errors, paste0(site, ": ", signif(val, 3),
                                       " is outside range [", signif(bottom, 3), ", ", signif(top, 3), "]"))
          } else storedValues[[site]] <- val
        } else {
          heights <- tryCatch({
            StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
          }, error = function(e) NULL)

          if (!is.null(heights) && length(heights) > 0) {
            ymin <- min(heights, na.rm = TRUE)
            ymax <- max(heights, na.rm = TRUE)
            if (val < ymin || val > ymax) {
              errors <- c(errors, paste0(site, ": ", signif(val, 3),
                                         " is outside range [", signif(ymin, 3), ", ", signif(ymax, 3), "]"))
            } else storedValues[[site]] <- val
          } else {
            storedValues[[site]] <- val
          }
        }
      }
    }

    if (length(errors) > 0) {
      showNotification(
        paste0("Validation error: ", paste(errors, collapse = "; ")),
        type = "error",
        duration = 10
      )
    } else {
      storedCustomAlphaValues(storedValues)
      showNotification("Alpha positions updated successfully.", type = "message", duration = 3)
    }
  })

  resolvedAlphaPosition <- reactive({
    alphaPos <- input$alphaPosition

    if (!is.null(alphaPos) && length(alphaPos) == 1 && alphaPos == "custom") {
      if (!data_api$signalValid()) return("middle")

      sd <- data_api$stratData()
      sites <- sd$sites
      alignmentScale <- input$alignmentScale %||% "height"

      inputSites <- if (alignmentScale == "height") sites[-1] else sites
      storedValues <- storedCustomAlphaValues()

      customValues <- numeric(length(sites))
      lastPos <- isolate(lastAlphaPosition())

      if (alignmentScale == "height") {
        customValues[1] <- NA
        for (i in seq_along(inputSites)) {
          site <- inputSites[i]
          val <- storedValues[[site]]

          if (!is.null(val) && !is.na(val)) {
            customValues[i + 1] <- val
          } else {
            site_idx <- match(site, sites)
            bottom <- tryCatch({ sd[[c("partsAttr", "BoundLow")]][1, site_idx] }, error = function(e) NULL)
            top    <- tryCatch({ max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE) }, error = function(e) NULL)

            if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
              customValues[i + 1] <- if (lastPos == "top") top else if (lastPos == "bottom") bottom else (bottom + top) / 2
            } else {
              heights <- tryCatch({
                StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                ymin <- min(heights, na.rm = TRUE)
                ymax <- max(heights, na.rm = TRUE)
                customValues[i + 1] <- if (lastPos == "top") ymax else if (lastPos == "bottom") ymin else mean(range(heights, na.rm = TRUE))
              } else {
                customValues[i + 1] <- 0
              }
            }
          }
        }
      } else {
        for (i in seq_along(inputSites)) {
          site <- inputSites[i]
          val <- storedValues[[site]]

          if (!is.null(val) && !is.na(val)) {
            customValues[i] <- val
          } else {
            site_idx <- match(site, sites)
            bottom <- tryCatch({ sd[[c("partsAttr", "BoundLow")]][1, site_idx] }, error = function(e) NULL)
            top    <- tryCatch({ max(sd[[c("partsAttr", "Bound")]][, site_idx], na.rm = TRUE) }, error = function(e) NULL)

            if (!is.null(bottom) && !is.null(top) && !is.na(bottom) && !is.na(top)) {
              customValues[i] <- if (lastPos == "top") top else if (lastPos == "bottom") bottom else (bottom + top) / 2
            } else {
              heights <- tryCatch({
                StratoBayes::SignalLookUp(sd, "height", site, includeNAsignal = FALSE)
              }, error = function(e) NULL)
              if (!is.null(heights) && length(heights) > 0) {
                ymin <- min(heights, na.rm = TRUE)
                ymax <- max(heights, na.rm = TRUE)
                customValues[i] <- if (lastPos == "top") ymax else if (lastPos == "bottom") ymin else mean(range(heights, na.rm = TRUE))
              } else {
                customValues[i] <- 0
              }
            }
          }
        }
      }

      return(customValues)
    }

    alphaPos
  })

  indices <- reactive({
    if (!isTRUE(data_api$signalValid())) return(NULL)
    sd <- tryCatch(data_api$stratData(), error = function(e) NULL)
    if (!inherits(sd, "StratData")) return(NULL)
    {
      tryCatch({
        StratoBayes:::.CreateIndices(
          sd,
          input$alignmentScale,
          input$sedModel,
          resolvedAlphaPosition()
        )
      }, error = function(e) {
        if (grepl("alphaPosition", e$message, ignore.case = TRUE) ||
            grepl("must be >= 0 and <=", e$message)) {
          showNotification(
            paste0("Error: Custom alpha position value is outside the valid range for this section. ",
                   "Please check the alpha position values and click 'Update' to validate them."),
            type = "error",
            duration = 10
          )
        } else {
          showNotification(
            paste0("Error creating model indices: ", e$message),
            type = "error",
            duration = 10
          )
        }
        NULL
      })
    }
  })

  output$priorSelectorUI <- renderUI({
    idx <- indices()
    req(!is.null(idx), length(idx$names) > 0)
    nms <- idx$names

    current <- isolate(input$activePrior)
    selectedName <- if (!is.null(current) && current %in% nms) current else nms[[1]]

    displayNames <- vapply(nms, formatParameterName, character(1))
    choices_vec <- nms
    names(choices_vec) <- displayNames

    tagList(
      radioButtons(
        "activePrior", "Prior to set",
        choices  = choices_vec,
        selected = selectedName
      ),
      div(style = "margin-top: .5rem;",
          actionButton("resetPriors", "Auto Priors", icon = icon("rotate-left")))
    )
  })

  activePriorName <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)
    nm <- input$activePrior
    if (!is.null(nm) && nm %in% idx$names) return(nm)
    idx$names[[1]]
  })

  activePriorIndex <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)
    match(activePriorName(), idx$names)
  })

  activePrior <- reactive({
    nm <- activePriorName()
    if (length(nm) == 1 && nm %in% names(priorSettings)) priorSettings[[nm]] else NULL
  })

  activePriorType <- reactive({
    if (!is.null(input$priorType)) return(input$priorType)
    p <- activePrior()
    if (!is.null(p) && !is.null(p$priorType)) return(p$priorType)
    "Normal"
  })

  output$priorParams <- renderUI({
    req(activePriorType())
    req(activePrior())
    priorParams(activePriorType, activePrior)
  })

  output$viewPrior <- renderPlot({
    switch(input$priorType,
           Uniform = {
             req(input$uniformMin, input$uniformMax)
             minVal <- as.numeric(input$uniformMin)
             maxVal <- as.numeric(input$uniformMax)
             if (any(is.na(c(minVal, maxVal))) || any(!is.finite(c(minVal, maxVal)))) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid numeric values", cex = 1.2, col = "red")
               return()
             }
             PlotUniform(sort(c(minVal, maxVal)), formatParameterName(activePriorName()))
           },
           Gamma = {
             req(input$gammaAlpha, input$gammaBeta)
             alpha <- as.numeric(input$gammaAlpha)
             beta  <- as.numeric(input$gammaBeta)
             if (any(is.na(c(alpha, beta))) || any(!is.finite(c(alpha, beta))) || alpha <= 0 || beta <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid positive numeric values", cex = 1.2, col = "red")
               return()
             }
             PlotGamma(alpha, beta, formatParameterName(activePriorName()))
           },
           Normal = {
             req(input$normalMean, input$normalSD)
             meanVal <- as.numeric(input$normalMean)
             sdVal   <- as.numeric(input$normalSD)
             if (any(is.na(c(meanVal, sdVal))) || any(!is.finite(c(meanVal, sdVal))) || sdVal <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter valid numeric values (SD must be positive)", cex = 1.2, col = "red")
               return()
             }
             PlotNormal(meanVal, sdVal, formatParameterName(activePriorName()))
           },
           Exponential = {
             req(input$expRate)
             rate <- as.numeric(input$expRate)
             if (is.na(rate) || !is.finite(rate) || rate <= 0) {
               plot(1, 1, type = "n", xlab = "", ylab = "", main = "Invalid input values")
               text(1, 1, "Please enter a valid positive numeric value", cex = 1.2, col = "red")
               return()
             }
             PlotExp(rate, formatParameterName(activePriorName()))
           }
    )
  })

  # Helper function to ensure priors are initialized with AutoPrior
  ensurePriorsInitialized <- function() {
    req(data_api$signalValid())
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    all_params <- idx$names
    missing_params <- setdiff(all_params, names(priorSettings))

    if (length(missing_params) > 0) {
      autoP <- AutoPrior(
        stratData      = data_api$stratData(),
        alignmentScale = input$alignmentScale,
        sedModel       = input$sedModel,
        alphaPosition  = resolvedAlphaPosition(),
        gammaLog_sd    = 0.2,
        zetaLog_sd     = 0.2
      )

      for (nm in missing_params) {
        if (!is.null(autoP[[nm]])) priorSettings[[nm]] <- .map_prior(autoP[[nm]])
      }
    }
  }

  priors <- reactive({
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    ensurePriorsInitialized()

    structure(
      class = c("list", "StratPrior"),
      names = idx$names,
      lapply(idx$names, function(param) {
        x <- priorSettings[[param]]
        if (is.null(x)) {
          defaultSD <- if (grepl("gamma|zeta", param, ignore.case = TRUE)) 0.2 else 1
          x <- list(priorType = "Normal", normalMean = 0, normalSD = defaultSD)
          priorSettings[[param]] <- x
        }
        switch(
          x$priorType,
          "Exponential" = ExponentialPrior(x$expRate),
          # "Gamma"       = GammaPrior(x$gammaAlpha, x$gammaBeta),
          "Normal"      = NormalPrior(x$normalMean, x$normalSD),
          "Uniform"     = UniformPrior(x$uniformMin, x$uniformMax)
        )
      })
    )
  })

  .syncing <- reactiveVal(FALSE)

  observeEvent(activePriorName(), ignoreInit = TRUE, {
    p <- activePrior(); req(p)
    .syncing(TRUE)

    if (!is.null(p$priorType)) updateRadioButtons(session, "priorType", selected = p$priorType)

    switch(p$priorType,
           "Normal" = {
             if (!is.null(p$normalMean)) {
               currentMean <- isolate(input$normalMean)
               if (is.null(currentMean) || is.na(currentMean) || !is.finite(currentMean) || abs(currentMean - p$normalMean) > 1e-10) {
                 updateNumericInput(session, "normalMean", value = signif(p$normalMean, digits = 4))
               }
             }
             if (!is.null(p$normalSD)) {
               currentSD <- isolate(input$normalSD)
               if (is.null(currentSD) || is.na(currentSD) || !is.finite(currentSD) || abs(currentSD - p$normalSD) > 1e-10) {
                 updateNumericInput(session, "normalSD", value = signif(p$normalSD, digits = 4))
               }
             }
           },
           "Gamma" = {
             if (!is.null(p$gammaAlpha)) {
               currentAlpha <- isolate(input$gammaAlpha)
               if (is.null(currentAlpha) || is.na(currentAlpha) || !is.finite(currentAlpha) || abs(currentAlpha - p$gammaAlpha) > 1e-10) {
                 updateNumericInput(session, "gammaAlpha", value = signif(p$gammaAlpha, digits = 4))
               }
             }
             if (!is.null(p$gammaBeta)) {
               currentBeta <- isolate(input$gammaBeta)
               if (is.null(currentBeta) || is.na(currentBeta) || !is.finite(currentBeta) || abs(currentBeta - p$gammaBeta) > 1e-10) {
                 updateNumericInput(session, "gammaBeta", value = signif(p$gammaBeta, digits = 4))
               }
             }
           },
           "Exponential" = {
             if (!is.null(p$expRate)) {
               currentRate <- isolate(input$expRate)
               if (is.null(currentRate) || is.na(currentRate) || !is.finite(currentRate) || abs(currentRate - p$expRate) > 1e-10) {
                 updateNumericInput(session, "expRate", value = signif(p$expRate, digits = 4))
               }
             }
           },
           "Uniform" = {
             if (!is.null(p$uniformMin)) {
               currentMin <- isolate(input$uniformMin)
               if (is.null(currentMin) || is.na(currentMin) || !is.finite(currentMin) || abs(currentMin - p$uniformMin) > 1e-10) {
                 updateNumericInput(session, "uniformMin", value = signif(p$uniformMin, digits = 4))
               }
             }
             if (!is.null(p$uniformMax)) {
               currentMax <- isolate(input$uniformMax)
               if (is.null(currentMax) || is.na(currentMax) || !is.finite(currentMax) || abs(currentMax - p$uniformMax) > 1e-10) {
                 updateNumericInput(session, "uniformMax", value = signif(p$uniformMax, digits = 4))
               }
             }
           }
    )

    session$onFlushed(function() .syncing(FALSE), once = TRUE)
  })

  priorInputs <- reactive({
    list(
      priorType   = input$priorType,
      normalMean  = input$normalMean,
      normalSD    = input$normalSD,
      gammaAlpha  = input$gammaAlpha,
      gammaBeta   = input$gammaBeta,
      expRate     = input$expRate,
      uniformMin  = input$uniformMin,
      uniformMax  = input$uniformMax
    )
  })

  debouncedPriorInputs <- debounce(priorInputs, millis = 300)

  observeEvent(debouncedPriorInputs(), {
    if (isTRUE(.syncing())) return()

    nm <- isolate(activePriorName()); req(nm)
    pt <- isolate(input$priorType);   if (is.null(pt)) return()

    old <- priorSettings[[nm]]

    ps <- switch(pt,
                 "Normal" = {
                   m <- .get_or(isolate(input$normalMean), old$normalMean)
                   s <- .get_or(isolate(input$normalSD),   old$normalSD)
                   if (is.null(m) || is.null(s)) return()
                   list(priorType = "Normal", normalMean = m, normalSD = s)
                 },
                 "Gamma" = {
                   a <- .get_or(isolate(input$gammaAlpha), old$gammaAlpha)
                   b <- .get_or(isolate(input$gammaBeta),  old$gammaBeta)
                   if (is.null(a) || is.null(b)) return()
                   list(priorType = "Gamma", gammaAlpha = a, gammaBeta = b)
                 },
                 "Exponential" = {
                   rr <- .get_or(isolate(input$expRate), old$expRate)
                   if (is.null(rr)) return()
                   list(priorType = "Exponential", expRate = rr)
                 },
                 "Uniform" = {
                   umin <- .get_or(isolate(input$uniformMin), old$uniformMin)
                   umax <- .get_or(isolate(input$uniformMax), old$uniformMax)
                   if (is.null(umin) || is.null(umax)) return()
                   list(priorType = "Uniform", uniformMin = umin, uniformMax = umax)
                 },
                 { return() }
    )

    priorSettings[[nm]] <- ps
  }, ignoreInit = TRUE)

  observeEvent(input$priorType, {
    if (isTRUE(.syncing())) return()
    nm <- isolate(activePriorName()); req(nm)
    if (!data_api$signalValid()) return()

    stored <- priorSettings[[nm]]
    needs_prefill <- is.null(stored) || is.null(stored$priorType) || stored$priorType != input$priorType

    if (needs_prefill) {
      if (data_api$signalValid()) {
        ap <- AutoPrior(
          stratData      = data_api$stratData(),
          alignmentScale = input$alignmentScale,
          sedModel       = input$sedModel,
          alphaPosition  = resolvedAlphaPosition(),
          gammaLog_sd    = 0.2,
          zetaLog_sd     = 0.2
        )[[nm]]
        stored <- if (!is.null(ap)) .map_prior(ap) else (stored %||% list())
      } else stored <- stored %||% list()
    }

    .syncing(TRUE)
    switch(input$priorType,
           "Normal" = {
             if (!is.null(stored$normalMean)) updateNumericInput(session, "normalMean", value = signif(stored$normalMean, digits = 4))
             if (!is.null(stored$normalSD))   updateNumericInput(session, "normalSD",   value = signif(stored$normalSD, digits = 4))
           },
           "Gamma" = {
             if (!is.null(stored$gammaAlpha)) updateNumericInput(session, "gammaAlpha", value = signif(stored$gammaAlpha, digits = 4))
             if (!is.null(stored$gammaBeta))  updateNumericInput(session, "gammaBeta",  value = signif(stored$gammaBeta, digits = 4))
           },
           "Exponential" = {
             if (!is.null(stored$expRate))    updateNumericInput(session, "expRate",    value = signif(stored$expRate, digits = 4))
           },
           "Uniform" = {
             if (!is.null(stored$uniformMin)) updateNumericInput(session, "uniformMin", value = signif(stored$uniformMin, digits = 4))
             if (!is.null(stored$uniformMax)) updateNumericInput(session, "uniformMax", value = signif(stored$uniformMax, digits = 4))
           }
    )

    if (input$priorType != "Normal") {
      updateNumericInput(session, "normalMean", value = NA)
      updateNumericInput(session, "normalSD",   value = NA)
    }
    if (input$priorType != "Gamma") {
      updateNumericInput(session, "gammaAlpha", value = NA)
      updateNumericInput(session, "gammaBeta",  value = NA)
    }
    if (input$priorType != "Exponential") updateNumericInput(session, "expRate", value = NA)
    if (input$priorType != "Uniform") {
      updateNumericInput(session, "uniformMin", value = NA)
      updateNumericInput(session, "uniformMax", value = NA)
    }

    session$onFlushed(function() .syncing(FALSE), once = TRUE)
  }, ignoreInit = TRUE)

  observeEvent(input$modelTabs, {
    if (input$modelTabs != "prior") return()
    if (!data_api$signalValid())    return()

    ensurePriorsInitialized()
    LogMsg("Priors initialized for missing parameters (existing values preserved).")
    session$sendInputMessage("activePrior", list(value = input$activePrior))
  }, priority = 100)

  observeEvent(input$resetPriors, {
    req(data_api$signalValid())
    idx <- indices(); req(!is.null(idx), length(idx$names) > 0)

    autoP <- AutoPrior(
      stratData      = data_api$stratData(),
      alignmentScale = input$alignmentScale,
      sedModel       = input$sedModel,
      alphaPosition  = input$alphaPosition,
      gammaLog_sd    = 0.2,
      zetaLog_sd     = 0.2
    )

    for (nm in idx$names) {
      if (!is.null(autoP[[nm]])) priorSettings[[nm]] <- .map_prior(autoP[[nm]])
    }

    cur <- isolate(activePrior()); req(cur)
    .syncing(TRUE)
    if (!is.null(cur$priorType)) updateRadioButtons(session, "priorType", selected = cur$priorType)

    switch(cur$priorType,
           "Normal" = {
             if (!is.null(cur$normalMean)) updateNumericInput(session, "normalMean", value = signif(cur$normalMean, digits = 4))
             if (!is.null(cur$normalSD))   updateNumericInput(session, "normalSD",   value = signif(cur$normalSD, digits = 4))
           },
           "Gamma" = {
             if (!is.null(cur$gammaAlpha)) updateNumericInput(session, "gammaAlpha", value = signif(cur$gammaAlpha, digits = 4))
             if (!is.null(cur$gammaBeta))  updateNumericInput(session, "gammaBeta",  value = signif(cur$gammaBeta, digits = 4))
           },
           "Exponential" = {
             if (!is.null(cur$expRate))    updateNumericInput(session, "expRate",    value = signif(cur$expRate, digits = 4))
           },
           "Uniform" = {
             if (!is.null(cur$uniformMin)) updateNumericInput(session, "uniformMin", value = signif(cur$uniformMin, digits = 4))
             if (!is.null(cur$uniformMax)) updateNumericInput(session, "uniformMax", value = signif(cur$uniformMax, digits = 4))
           }
    )
    session$onFlushed(function() .syncing(FALSE), once = TRUE)

    showNotification("Priors reset to AutoPrior.", type = "message")
  })

  paramsDefined <- reactive({
    !is.null(input$alignmentScale) && !is.null(input$sedModel) && !is.null(input$alphaPosition)
  })

  observeEvent(list(input$modelTabs, input$alignmentScale, input$sedModel, input$alphaPosition), {
    if (paramsDefined()) shinyjs::enable(selector = '#modelTabs li a[data-value="prior"]')
    else                shinyjs::disable(selector = '#modelTabs li a[data-value="prior"]')
  })

  observeEvent(input$modelTabs, {
    if (input$modelTabs == "prior") {
      shinyjs::runjs("
        setTimeout(function() {
          var labels = ['0.1', '1', '10', '100', '10³', '10⁴', '10⁵'];
          var $input = $('#bLambdaLog');
          if ($input.length) {
            var $irs = $input.next('.irs');
            if ($irs.length) {
              var $gridTexts = $irs.find('.irs-grid-text');
              $gridTexts.each(function(index) {
                if (index < labels.length) {
                  $(this).html(labels[index]);
                }
              });
            }
          }
        }, 400);
      ")
    }
  })

  bLambda <- reactive({
    if (is.null(input$bLambdaLog)) return(100)
    val <- tryCatch({ as.numeric(input$bLambdaLog) }, warning = function(w) NULL, error = function(e) NULL)
    if (is.null(val) || is.na(val) || !is.finite(val)) return(100)
    10^val
  })

  output$bLambdaValue <- renderText({
    val <- bLambda()
    paste0("Value: ", format(val, scientific = FALSE, big.mark = ","))
  })

  output$priorUI <- renderUI({
    req(data_api$signalValid())
    req(paramsDefined())

    ensurePriorsInitialized()

    shinyjs::runjs("
      setTimeout(function() {
        var labels = ['0.1', '1', '10', '100', '10³', '10⁴', '10⁵'];
        var $input = $('#bLambdaLog');
        if ($input.length) {
          var $irs = $input.next('.irs');
          if ($irs.length) {
            var $gridTexts = $irs.find('.irs-grid-text');
            $gridTexts.each(function(index) {
              if (index < labels.length) {
                $(this).html(labels[index]);
              }
            });
          }
        }
      }, 500);
    ")

    tagList(
      fluidRow(
        column(8,
               uiOutput("priorSelectorUI"),
               br(),
               radioButtons("priorType", "Prior type",
                            choices = c("Normal", "Exponential", "Uniform"),
                            selected = isolate(activePriorType()),
                            inline = TRUE),
               uiOutput("priorParams")
        ),
        column(4,
               tags$div(
                 style = "padding: 10px; background-color: #f9f9f9; border-radius: 4px;",
                 tags$strong("Model Settings"),
                 br(), br(),
                 sliderInput("penaltyMultiplier", "Enforce overlap (penalty multiplier)",
                             value = isolate({
                               stored <- storedPenaltyMultiplier()
                               current <- input$penaltyMultiplier
                               if (!is.null(stored)) { storedPenaltyMultiplier(NULL); stored }
                               else if (!is.null(current) && !is.na(current)) current
                               else 0.25
                             }),
                             min = 0, max = 1, step = 0.01, width = "100%"),
                 tags$div(
                   style = "font-size: 0.75em; color: #666; margin-top: -5px; margin-bottom: 10px;",
                   "Higher values enforce more overlap. Default: 0.25"
                 ),
                sliderInput("nKnots", "Number of knots",
                            value = isolate({
                              stored <- storedNKnots()
                              current <- input$nKnots
                              if (!is.null(stored)) { storedNKnots(NULL); stored }
                              else if (!is.null(current) && !is.na(current)) current
                              else 30
                            }),
                             min = 5, max = 100, step = 1, width = "100%"),
                 tags$div(
                   style = "font-size: 0.75em; color: #666; margin-top: -5px; margin-bottom: 10px;",
                   "More knots allow for a more detailed spline curve, but slow down the model run."
                 ),
                 br(),
                 tags$div(
                   style = "margin-bottom: 15px;",
                   tags$label(
                     HTML("Spline Smoothness <span style='font-size: 0.75em; color: #666;'>(bLambda prior)</span>"),
                     style = "display: block; margin-bottom: 12px;"
                   ),
                   tags$div(
                     style = "display: flex; justify-content: space-between; align-items: center; position: relative; padding: 0 10px;",
                     tags$div(style = "position: absolute; left: 10px; top: -18px; font-size: 0.7em; color: #666;", "rough"),
                     tags$input(
                       type = "range",
                       id = "bLambdaLog",
                       name = "bLambdaLog",
                       min = "-1",
                       max = "5",
                      value = as.character(isolate({
                        stored <- storedBLambdaLog()
                        current <- input$bLambdaLog
                        if (!is.null(stored)) { storedBLambdaLog(NULL); stored }
                        else if (!is.null(current) && !is.na(current)) current
                        else 2
                      })),
                       step = "0.5",
                       style = "width: 100%;",
                       class = "slider"
                     ),
                     tags$div(style = "position: absolute; right: 10px; top: -18px; font-size: 0.7em; color: #666;", "smooth"),
                     tags$div(
                       style = "position: absolute; width: 100%; display: flex; justify-content: space-between; pointer-events: none; top: 20px; padding: 0 10px;",
                       tags$span("0.1", style = "font-size: 0.7em; color: #666;"),
                       tags$span("1",   style = "font-size: 0.7em; color: #666;"),
                       tags$span("10",  style = "font-size: 0.7em; color: #666;"),
                       tags$span("100", style = "font-size: 0.7em; color: #666;"),
                       tags$span(HTML("10<sup>3</sup>"), style = "font-size: 0.7em; color: #666; font-weight: bold;"),
                       tags$span(HTML("10<sup>4</sup>"), style = "font-size: 0.7em; color: #666;"),
                       tags$span(HTML("10<sup>5</sup>"), style = "font-size: 0.7em; color: #666;")
                     )
                   ),
                   tags$div(
                     style = "text-align: center; margin-top: 15px;",
                     tags$span(
                       style = "font-size: 0.75em; color: #666;",
                       "Selected value: ",
                       tags$span(id = "bLambdaValueDisplay", style = "font-weight: bold; color: #333;", "100")
                     )
                   )
                 ),
                 tags$script(HTML("
                   function updateBLambdaDisplay() {
                     var slider = $('#bLambdaLog')[0];
                     if (!slider) return;
                     var val = parseFloat(slider.value);
                     var actualValue = Math.pow(10, val);
                     var displayValue;
                     if (actualValue >= 10000) {
                       var exp = actualValue.toExponential(2);
                       var parts = exp.split('e+');
                       if (parts.length === 2) {
                         displayValue = parseFloat(parts[0]).toFixed(2) + '×10<sup>' + parts[1] + '</sup>';
                       } else displayValue = actualValue.toFixed(0);
                     } else if (actualValue >= 1000) {
                       displayValue = Math.round(actualValue).toLocaleString();
                     } else if (actualValue >= 1) {
                       displayValue = actualValue.toFixed(actualValue >= 10 ? 0 : 1);
                     } else {
                       displayValue = actualValue.toFixed(actualValue >= 0.1 ? 1 : 2);
                     }
                     $('#bLambdaValueDisplay').html(displayValue);
                   }

                   $(document).on('change input', '#bLambdaLog', function() {
                     var val = parseFloat($(this).val());
                     if (!isNaN(val)) {
                       Shiny.setInputValue('bLambdaLog', val, {priority: 'event'});
                       updateBLambdaDisplay();
                     }
                   });

                   $(document).ready(function() {
                     setTimeout(function() {
                       var slider = $('#bLambdaLog')[0];
                       if (slider) {
                         var val = parseFloat(slider.value);
                         if (!isNaN(val)) Shiny.setInputValue('bLambdaLog', val, {priority: 'event'});
                       }
                       updateBLambdaDisplay();
                     }, 100);
                   });
                 "))
               )
        )
      ),
      br(),
      plotOutput("viewPrior", height = "300px")
    )
  })

  # --- static serving for StratoBayes progress HTML/PNGs ---
  ns_id   <- gsub("\\W", "", session$ns(""))
  mountId <- paste0("strato-", ns_id)
  model_base <- normalizePath(file.path(tempdir(), mountId), mustWork = FALSE)
  dir.create(model_base, recursive = TRUE, showWarnings = FALSE)
  addResourcePath(mountId, model_base)

  modelNameRV <- reactiveVal(NULL)
  modelRunning <- reactiveVal(FALSE)
  modelProcess <- reactiveVal(NULL)

  output$runUI <- renderUI({
    req(data_api$signalValid())
    tagList(
      tags$div(
        style = "text-align: center; padding: 20px;",
        tags$h4("Ready to run model"),
        tags$p("Configure your model settings above, then click 'Run Model' to start the analysis.")
      )
    )
  })

  output$runIframeUI <- renderUI({
    if (is.null(modelNameRV())) {
      return(tags$div(
        style = "text-align: center; padding: 50px;",
        tags$h3("No model run initiated"),
        tags$p("Click 'Run Model' to start analysis and view live progress here.")
      ))
    }

    scale <- 1
    baseH <- 600

    tags$div(
      style = sprintf(
        "transform: scale(%f);
         transform-origin: 0 0;
         width: calc(100%% / %f);
         height: %fpx;
         overflow: hidden;",
        scale, scale, baseH / scale
      ),
      tags$iframe(
        src    = sprintf("/%s/%s/results.html", mountId, modelNameRV()),
        width  = "100%",
        height = as.character(baseH / scale),
        style  = "border:0;"
      )
    )
  })

  # ---------- FIX 1: make *all* run params safe even if Priors tab UI never rendered ----------
  getModelParams <- function(useDefaults = FALSE) {
    detectedCores <- tryCatch(parallel::detectCores(logical = TRUE), error = function(e) NA_integer_)
    if (is.na(detectedCores) || detectedCores < 1L) detectedCores <- 1L
    defaultThreads <- max(1L, detectedCores - 1L)
    useThreads <- if (is.null(input$useMultithreading)) TRUE else isTRUE(input$useMultithreading)
    nThreads <- if (useThreads) {
      val <- suppressWarnings(as.integer(input$nThreads %||% defaultThreads))
      if (is.na(val) || val < 1L) defaultThreads else min(val, detectedCores)
    } else {
      1L
    }

    if (useDefaults) {
      list(
        alignmentScale = "height",
        sedModel = "site",
        alphaPosition = "middle",
        nRun = 1,
        nIter = 1000,
        nThin = 1,
        nChains = 8,
        nKnots = 30,
        penaltyMultiplier = 0.25,
        bLambda = 100,
        nThreads = defaultThreads
      )
    } else {
      list(
        alignmentScale = input$alignmentScale %||% "height",
        sedModel = input$sedModel %||% "site",
        alphaPosition = resolvedAlphaPosition() %||% "middle",
        nRun = input$nRun %||% 1,
        nIter = input$nIter %||% 1000,
        nThin = input$nThin %||% 1,
        nChains = input$nChains %||% 8,
        nKnots = input$nKnots %||% 30,                  # default if Priors UI not visited
        penaltyMultiplier = input$penaltyMultiplier %||% 0.25,
        bLambda = bLambda() %||% 100,
        nThreads = nThreads
      )
    }
  }

  # ---------- FIX 2: initialize prerequisites when entering Run tab (not only Priors tab) ----------
  observeEvent(input$modelTabs, {
    if (input$modelTabs != "run") return()              # adjust if your run tab value differs
    if (!data_api$signalValid()) return()
    ensurePriorsInitialized()
    indices()  # warm/catch alphaPosition issues early
  }, priority = 100)

  Align <- function(useDefaults = FALSE) {
    if (modelRunning()) {
      showNotification("A model is already running. Please wait for it to complete.", type = "warning")
      return()
    }

    if (!data_api$signalValid()) {
      showNotification("Please provide a valid data set before running the model.", type = "error")
      return()
    }

    # Pre-flight: ensure every well-log curve still has data in >=2 wells on the
    # actual StratData object. Mirrors the hard rule in StratData(); guards
    # against edge cases where downsampling drops sparse non-NA values from a
    # site so the user sees an explicit, actionable message instead of a
    # background-process gzfile/saveRDS failure.
    .sd_for_check <- tryCatch(data_api$stratData(), error = function(e) NULL)
    cov_report <- .signalCoverageReport(.sd_for_check)
    if (!is.null(cov_report)) {
      bad <- Filter(function(x) x$nSitesWithData < 2L, cov_report)
      if (length(bad)) {
        details <- vapply(bad, function(x) {
          sites_str <- if (length(x$sitesWithData)) paste(x$sitesWithData, collapse = ", ") else "(none)"
          paste0("'", x$signal, "': ", x$nSitesWithData, " well(s) with data [", sites_str, "]")
        }, character(1))
        msg <- paste0(
          "Cannot run alignment. Each well-log curve must have non-NA values in at least 2 wells, but the following do not:\n",
          paste(details, collapse = "\n"),
          "\nFix: deselect the curve under 'Well log curves', include another well that contains it, or relax data cleaning/downsampling so its non-NA values survive."
        )
        showNotification(msg, type = "error", duration = 20, id = "stratdata-curve-coverage")
        modelRunning(FALSE)
        return()
      }
    }

    params <- getModelParams(useDefaults)

    # ---------- FIX 3: fail fast if anything critical is missing/invalid ----------
    ok_num1 <- function(x) is.numeric(x) && length(x) == 1 && is.finite(x) && !is.na(x)
    validate(
      need(!is.null(params$alignmentScale) && nzchar(params$alignmentScale), "alignmentScale is not set."),
      need(!is.null(params$sedModel) && nzchar(params$sedModel), "sedModel is not set."),
      need(!is.null(params$alphaPosition), "alphaPosition is not set."),
      need(ok_num1(params$nRun), "nRun is not set."),
      need(ok_num1(params$nIter), "nIter is not set."),
      need(ok_num1(params$nThin), "nThin is not set."),
      need(ok_num1(params$nChains), "nChains is not set."),
      need(ok_num1(params$nKnots), "nKnots is not set (visit Priors tab or use defaults)."),
      need(ok_num1(params$penaltyMultiplier), "penaltyMultiplier is not set (visit Priors tab or use defaults)."),
      need(ok_num1(params$bLambda), "bLambda is not set (visit Priors tab or use defaults)."),
      need(ok_num1(params$nThreads), "nThreads is not set.")
    )

    modelRunning(TRUE)

    # ---------- FIX 4: ALWAYS seed missing priors on advanced runs before building priors list ----------
    if (!useDefaults) ensurePriorsInitialized()

    # For QuickRun or if priors might not be initialized at all, ensure AutoPriors are used
    if (useDefaults || length(names(priorSettings)) == 0) {
      autoP <- AutoPrior(
        stratData      = data_api$stratData(),
        alignmentScale = params$alignmentScale,
        sedModel       = params$sedModel,
        alphaPosition  = params$alphaPosition,
        gammaLog_sd    = 0.2,
        zetaLog_sd     = 0.2
      )
      for (nm in names(autoP)) {
        if (!is.null(autoP[[nm]])) priorSettings[[nm]] <- .map_prior(autoP[[nm]])
      }
    }

    thisModelName <- paste0("run_", format(Sys.time(), "%Y%m%d_%H%M%S"))
    modelNameRV(thisModelName)

    model_dir <- .strip_trailing_path_sep(file.path(model_base, thisModelName))
    dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)

    placeholder_html <- paste0('<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="3">
  <title>StratoBayes Progress</title>
  <style>
    body { font: 14px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial;
           margin: 20px; background: #f5f5f5; }
    .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .spinner { border: 3px solid #f3f3f3; border-top: 3px solid #3498db; border-radius: 50%;
               width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 20px auto; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .status { background: #e8f4fd; padding: 10px; border-radius: 4px; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="container">
    <h2>StratoBayes Model Running</h2>
    <div class="spinner"></div>
    <div class="status">
      <p><strong>Status:</strong> Initializing model parameters...</p>
      <p><strong>Started:</strong> ', format(Sys.time()), '</p>
    </div>
    <p>Live progress plots will appear here once the MCMC sampling begins.</p>
    <p><em>This page refreshes automatically every 3 seconds to show live updates.</em></p>
  </div>
</body>
</html>')
    writeLines(placeholder_html, file.path(model_dir, "results.html"))

    if (useDefaults) {
      showNotification("Quick run started with default settings and AutoPriors. Live progress will appear below.",
                       type = "message", duration = 5)
    } else {
      showNotification("Model started. Live progress will appear in the viewer below.",
                       type = "message", duration = 5)
    }

    current_priors <- tryCatch({
      if (useDefaults) {
        sd <- data_api$stratData()
        if (!inherits(sd, "StratData")) {
          stop("stratData is not ready; reload or fix the data set and try again.")
        }
        idx <- StratoBayes:::.CreateIndices(sd, params$alignmentScale, params$sedModel, params$alphaPosition)
        structure(
          class = c("list", "StratPrior"),
          names = idx$names,
          lapply(idx$names, function(param) {
            x <- priorSettings[[param]]
            if (is.null(x)) {
              defaultSD <- if (grepl("gamma|zeta", param, ignore.case = TRUE)) 0.2 else 1
              x <- list(priorType = "Normal", normalMean = 0, normalSD = defaultSD)
            }
            switch(
              x$priorType,
              "Exponential" = ExponentialPrior(x$expRate),
              # "Gamma"       = GammaPrior(x$gammaAlpha, x$gammaBeta),
              "Normal"      = NormalPrior(x$normalMean, x$normalSD),
              "Uniform"     = UniformPrior(x$uniformMin, x$uniformMax)
            )
          })
        )
      } else {
        priors()
      }
    }, error = function(e) {
      modelRunning(FALSE)
      modelProcess(NULL)
      removeModal()
      showNotification(paste("Error preparing model priors:", e$message), type = "error", duration = 15)
      NULL
    })

    if (is.null(current_priors)) return()

    if (requireNamespace("callr", quietly = TRUE)) {

      tryCatch({
        process <- callr::r_bg(
          function(stratData, nRun, nIter, nThin, nChains, priors_list,
                   alignmentScale, sedModel, nKnots, penaltyMultiplier, bLambda,
                   nThreads, model_dir, modelName) {

            library(StratoBayes)
            options(StratoBayes.openBrowser = FALSE)

            posterior <- RunStratModel(
              stratObject    = stratData,
              nRun           = nRun,
              nIter          = nIter,
              nThin          = nThin,
              nChains        = nChains,
              priors         = priors_list,
              alignmentScale = alignmentScale,
              sedModel       = sedModel,
              nKnots         = nKnots,
              penaltyMultiplier = penaltyMultiplier,
              bLambda        = bLambda,
              nThreads       = nThreads,
              runParallel    = TRUE,
              visualise      = list(interval = 50, signal = 1:3, parameter = 1),
              # Pass directory without trailing slash; RunStratModel treats a
              # trailing slash as "create modelName subfolder", which then
              # breaks result retrieval expecting files in model_dir.
              modelDir       = model_dir,
              modelName      = modelName
            )

            posterior
          },
          args = list(
            stratData      = data_api$stratData(),
            nRun           = params$nRun,
            nIter          = params$nIter,
            nThin          = params$nThin,
            nChains        = params$nChains,
            priors_list    = current_priors,
            alignmentScale = params$alignmentScale,
            sedModel       = params$sedModel,
            nKnots         = params$nKnots,
            penaltyMultiplier = params$penaltyMultiplier,
            bLambda        = params$bLambda,
            nThreads       = params$nThreads,
            model_dir      = model_dir,
            modelName      = thisModelName
          ),
          supervise = TRUE
        )

        modelProcess(process)
        showNotification("Background model process started successfully.", type = "message")

      }, error = function(e) {
        modelRunning(FALSE)
        modelProcess(NULL)
        removeModal()
        showNotification(paste("Error starting background process:", e$message), type = "error")
      })

    } else {
      showNotification("callr package not available. Running synchronously (UI will be blocked).",
                       type = "warning", duration = 10)

      old_open_browser <- getOption("StratoBayes.openBrowser", TRUE)
      options(StratoBayes.openBrowser = FALSE)
      tryCatch({
        posterior <- RunStratModel(
          stratObject    = data_api$stratData(),
          nRun           = params$nRun,
          nIter          = params$nIter,
          nThin          = params$nThin,
          nChains        = params$nChains,
          priors         = current_priors,
          alignmentScale = params$alignmentScale,
          sedModel       = params$sedModel,
          nKnots         = params$nKnots,
          penaltyMultiplier = params$penaltyMultiplier,
          bLambda        = params$bLambda,
          nThreads       = params$nThreads,
          runParallel    = TRUE,
          visualise      = list(interval = 100, signal = 1:3, parameter = 1),
          # Keep modelDir exact (no trailing slash) for consistent output paths.
          modelDir       = model_dir,
          modelName      = thisModelName
        )

        r$alignment <- posterior
        modelRunning(FALSE)

        final_results_path <- file.path(model_dir, "results.html")
        if (!file.exists(final_results_path)) {
          success_html <- paste0('<!doctype html>
<html><head><meta charset="utf-8"><title>StratoBayes Complete</title>
<style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
.container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
.success{background:#d4edda;border:1px solid #c3e6cb;color:#155724;padding:15px;border-radius:4px;margin:10px 0;}
</style></head>
<body><div class="container">
<div class="success">
<h2>✅ Model Run Complete</h2>
<p><strong>Model:</strong> ', thisModelName, '</p>
<p><strong>Completed:</strong> ', format(Sys.time()), '</p>
<p>Results have been loaded into the application. You can now view alignment results in other tabs.</p>
</div></div></body></html>')
          writeLines(success_html, final_results_path)
        }

        showNotification("Model completed successfully! Results are now available.",
                         type = "message", duration = 10)
        removeModal()

      }, error = function(e) {
        modelRunning(FALSE)

        error_html <- paste0('<!doctype html>
<html><head><meta charset="utf-8"><title>StratoBayes Error</title>
<style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
.container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
.error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24;padding:15px;border-radius:4px;}
</style></head>
<body><div class="container">
<div class="error">
<h2>❌ Model Run Failed</h2>
<p><strong>Error:</strong> ', as.character(e$message), '</p>
<p><strong>Time:</strong> ', format(Sys.time()), '</p>
</div></div></body></html>')
        writeLines(error_html, file.path(model_dir, "results.html"))

        showNotification(paste("Model run failed:", e$message), type = "error", duration = 15)
        removeModal()
      }, finally = {
        options(StratoBayes.openBrowser = old_open_browser)
      })
    }
  }

  observe({
    invalidateLater(1000, session)

    process <- modelProcess()
    if (!is.null(process) && modelRunning()) {

      if (process$is_alive()) return()

      tryCatch({
        exit_status <- process$get_exit_status()
        if (is.null(exit_status)) return()

        if (exit_status == 0) {
          model_dir <- .strip_trailing_path_sep(file.path(model_base, modelNameRV()))
          read_root <- .resolve_run_output_dir(model_dir, modelNameRV())
          read_dir <- if (dir.exists(read_root)) normalizePath(read_root, winslash = "/", mustWork = TRUE) else read_root
          mn <- modelNameRV()
          # Track underlying causes so we can surface them when both paths fail.
          get_result_err <- NULL
          fallback_err  <- NULL
          result <- tryCatch({
            process$get_result()
          }, error = function(e) {
            get_result_err <<- conditionMessage(e)
            if (dir.exists(model_dir)) {
              tryCatch({
                StratPosterior(readDir = read_dir, modelName = mn)
              }, error = function(e2) {
                fallback_err <<- conditionMessage(e2)
                NULL
              })
            } else NULL
          })

          if (!is.null(result)) {
            r$alignment <- result
            modelRunning(FALSE)
            modelProcess(NULL)

            model_dir <- file.path(model_base, modelNameRV())
            final_results_path <- file.path(model_dir, "results.html")
            if (!file.exists(final_results_path)) {
              success_html <- paste0('<!doctype html>
<html><head><meta charset="utf-8"><title>StratoBayes Complete</title>
<style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
.container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
.success{background:#d4edda;border:1px solid #c3e6cb;color:#155724;padding:15px;border-radius:4px;margin:10px 0;}
</style></head>
<body><div class="container">
<div class="success">
<h2>✅ Model Run Complete</h2>
<p><strong>Model:</strong> ', modelNameRV(), '</p>
<p><strong>Completed:</strong> ', format(Sys.time()), '</p>
<p>Results have been loaded into the application. You can now view alignment results in other tabs.</p>
</div></div></body></html>')
              writeLines(success_html, final_results_path)
            }

            showNotification("Model completed successfully! Results are now available.",
                             type = "message", duration = 10)
            removeModal()

          } else {
            modelRunning(FALSE)
            modelProcess(NULL)
            warn_msg <- "Model process completed but results could not be retrieved. Check the model directory for output files."
            warn_html <- paste0('<!doctype html>
<html><head><meta charset="utf-8"><title>StratoBayes — results not loaded</title>
<style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
.container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
.warn{background:#fff3cd;border:1px solid #ffc107;color:#856404;padding:15px;border-radius:4px;}
</style></head>
<body><div class="container">
<div class="warn">
<h2>Results could not be loaded into the app</h2>
<p>', warn_msg, '</p>
<p><strong>Model:</strong> ', htmltools::htmlEscape(as.character(mn)), '</p>
<p><strong>Directory:</strong> ', htmltools::htmlEscape(as.character(read_dir)), '</p>
</div></div></body></html>')
            writeLines(warn_html, file.path(model_dir, "results.html"))
            showNotification(warn_msg, type = "warning", duration = 15)
            removeModal()
          }

        } else {
          error_msg <- tryCatch({
            process$get_result()
          }, error = function(e) {
            model_dir <- file.path(model_base, modelNameRV())
            error_files <- list.files(model_dir, pattern = "*error*.txt", full.names = TRUE)
            if (length(error_files) > 0) paste(readLines(error_files[1], warn = FALSE), collapse = "\n")
            else paste("Process exited with status", exit_status)
          })

          modelRunning(FALSE)
          modelProcess(NULL)

          model_dir <- file.path(model_base, modelNameRV())
          error_html <- paste0('<!doctype html>
<html><head><meta charset="utf-8"><title>StratoBayes Error</title>
<style>body{font:14px/1.4 system-ui;margin:20px;background:#f5f5f5;}
.container{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
.error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24;padding:15px;border-radius:4px;}
</style></head>
<body><div class="container">
<div class="error">
<h2>❌ Model Run Failed</h2>
<p><strong>Error:</strong> ', as.character(error_msg), '</p>
<p><strong>Time:</strong> ', format(Sys.time()), '</p>
</div></div></body></html>')
          writeLines(error_html, file.path(model_dir, "results.html"))

          showNotification(paste("Model run failed:", as.character(error_msg)), type = "error", duration = 15)
          removeModal()
        }

      }, error = function(e) {
        modelRunning(FALSE)
        modelProcess(NULL)
        removeModal()
        showNotification(paste("Error retrieving model results:", e$message), type = "error", duration = 15)
      })
    }
  })

  QuickRun <- function() {
    Align(useDefaults = TRUE)
  }

  observeEvent(input$align,       { Align() })
  observeEvent(input$alignModal,  { Align() })
  observeEvent(input$setupRun,    { showModal(runModal()) })
  observeEvent(input$setupRunModal, { showModal(runModal()) })

  selectedAlignment <- reactive({
    req(r$alignment)
    sel <- input$alnToShow
    if (is.null(sel) || sel == "") return(1L)
    if (sel == "unassigned") return(0L)
    val <- as.integer(sel)
    if (is.na(val) || !(val %in% r$alignment$stratCluster$clustUnique)) {
      return(r$alignment$stratCluster$clustUnique[1])
    }
    val
  })

  stratCluster <- reactive({
    req(r$alignment)
    runs <- StratoBayes:::.ValidateRunSelect("all", r$alignment$nRun)
    StratoBayes:::.ClusterInternal(r$alignment,
                                   burnIn      = input$posteriorBurn/100,
                                   iterations  = NULL,
                                   maxSamples  = 2500,
                                   runSelect   = runs,
                                   selectRows  = NULL)
  })

  restoreCustomAlphaValues <- function(values) {
    if (!is.null(values) && length(values) > 0) {
      isLoadingSettings(TRUE)
      storedCustomAlphaValues(values)
      shinyjs::delay(500, { isLoadingSettings(FALSE) })
    }
  }

  setStoredPenaltyMultiplier <- function(value) storedPenaltyMultiplier(value)
  setStoredNKnots            <- function(value) storedNKnots(value)
  setStoredBLambdaLog        <- function(value) storedBLambdaLog(value)

  list(
    indices      = indices,
    priors       = priors,
    alignment    = reactive(r$alignment),
    stratCluster = stratCluster,
    modelNameRV  = modelNameRV,
    mountId      = mountId,
    selectedAlignment = selectedAlignment,
    Align        = Align,
    QuickRun     = QuickRun,
    storedCustomAlphaValues = reactive(storedCustomAlphaValues()),
    restoreCustomAlphaValues = restoreCustomAlphaValues,
    setStoredPenaltyMultiplier = setStoredPenaltyMultiplier,
    setStoredNKnots = setStoredNKnots,
    setStoredBLambdaLog = setStoredBLambdaLog
  )
}

# helper
.map_prior <- function(p) {
  a <- p$args; cls <- class(p)[1]
  switch(
    cls,
    "UniformPrior"     = list(priorType="Uniform",     uniformMin=a$min,  uniformMax=a$max),
    "NormalPrior"      = list(priorType="Normal",      normalMean=a$mean, normalSD=a$sd),
    "ExponentialPrior" = list(priorType="Exponential", expRate=a$rate),
    # "GammaPrior"       = list(priorType="Gamma", gammaAlpha=a$shape, gammaBeta=a$rate),
    list(priorType="Custom", object=p, class=cls)
  )
}

.get_or <- function(x, or = NULL) if (is.null(x) || (length(x) == 1 && is.na(x))) or else x
`%||%` <- function(x, y) if (is.null(x)) y else x
