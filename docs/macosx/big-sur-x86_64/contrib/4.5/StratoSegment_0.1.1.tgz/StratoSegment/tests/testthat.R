# Run with: testthat::test_check("StratoSegment")
library(testthat)
library(StratoSegment)

test_check("StratoSegment")
