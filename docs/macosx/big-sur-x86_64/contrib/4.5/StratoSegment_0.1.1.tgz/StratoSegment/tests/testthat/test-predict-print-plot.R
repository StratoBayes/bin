test_that("predict.StratoSegment returns the right slices", {
  sim <- make_test_sim()
  fit <- StratoSegment(sim$y, sim$depth, K = 1L, minSegLen = 5L, minObsPerCurve = 3L)
  expect_identical(predict(fit, type = "segments"), fit$segment_summary)
  expect_identical(predict(fit, type = "fitted"), fit$fitted)
  expect_identical(predict(fit, type = "coefficients"), fit$coefficients)
})

test_that("print.StratoSegment runs without error", {
  sim <- make_test_sim(n = 50L, p = 1L, changepoints = integer(0), seed = 1L)
  fit <- StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_output(print(fit), "StratoSegment fit")
})

test_that("plot.StratoSegment draws without error", {
  sim <- make_test_sim(n = 60L, p = 2L, changepoints = c(25L), seed = 5L)
  fit <- StratoSegment(sim$y, sim$depth, K = 1L, minSegLen = 4L, minObsPerCurve = 3L)
  path <- tempfile(fileext = ".pdf")
  on.exit(unlink(path), add = TRUE)
  pdf(path)
  on.exit(dev.off(), add = TRUE)
  expect_no_error(plot(fit, curves = 1:2))
})
