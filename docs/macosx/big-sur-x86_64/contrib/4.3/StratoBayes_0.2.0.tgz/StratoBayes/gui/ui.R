# ui.R

ui <- fluidPage(
  title = "StratoBayes",
  includeCSS("www/app.css"),

  # hide notifications during test mode
  if (isTRUE(getOption("shiny.testmode"))) {
    tags$head(
      tags$style(HTML("#shiny-notification-panel {visibility: hidden;}"))
    )
  },

  useShinyjs(),

  # Hidden download button for export results
  # Keep it in the DOM but hidden - Shiny will enable it when download handler is ready
  downloadButton("exportResultsDownload", "", style = "position: absolute; left: -9999px; visibility: hidden;"),

  fluidRow(
    ## ── Sidebar ───────────────────────────────────────────────────────────
    column(3,
           tags$h1("StratoBayes", style = "margin-top: 0.4em;"),

           # only Load & Plot lives here now
           actionButton(
             "loadSignal",
             signalText,
             icon = signalIcon,
             class = "btn-primary"
           ),

           br(), # Add some spacing

          actionButton(
            "loadResults",
             "Load Results",
             icon = icon("folder-open")
           ),

           br(), # Add some spacing

          actionButton(
            "exportResults",
            "Save Results",
            icon = icon("download")
          ),

           br(), # Add some spacing

           actionButton(
             "importResults",
             "Import Results",
             icon = icon("upload")
           ),

           # Correlation-specific controls in left sidebar
           conditionalPanel(
             "input.plotTypeMain === 'correlation'",
             br(),
             tags$h4("Correlation Lines", style = "margin-top: 1em; margin-bottom: 0.5em;"),
             uiOutput("correlationSourceSite_ui"),
             div(class = "correlation-ref-heights-wrapper", style = "overflow: visible; min-width: 0;",
                 uiOutput("correlationRefHeightsBlock_ui")),
             br(),
             sliderInput("confidenceLevel", "Confidence Interval",
                        min = 0, max = 100, value = 90, step = 1,
                        width = "100%"),
             helpText("Confidence level sets quantiles for the correlation plot.
                      E.g., the 90% confidence interval displays the 0.05 and
                      the 0.95 quantile as dashed lines.",
                     style = "font-size: 0.8em; color: #666;"),
             br(),
             downloadButton("exportWellTops", "Export Well Tops",
                           class = "btn-primary",
                           style = "width: 100%; margin-top: 10px;")
           )
    ),

    ## ── Main plot area ─────────────────────────────────────────────────────
    column(9,
           fluidRow(
             id = "plotConfig",
             tabsetPanel(
               id   = "plotTypeMain",
               type = "tabs",
               tabPanel("Correlation", value = "correlation"),
               tabPanel("Alignment",   value = "alignment"),
               tabPanel("Trace Plot",  value = "traceplot"),
               selected = "correlation"
             )
           ),
          fluidRow(
            id = "plotOptionsRow",
            style = "position: relative; z-index: 10;",
            uiOutput("plotOptionsUI")
          ),

           #   div(
           #     id = "saveAs",
           #     span("Save plot: "),
           #     downloadButton("savePlotZip", "R script", icon = Icon("download")),
           #     downloadButton("savePdf",    "PDF",      icon = Icon("download")),
           #     downloadButton("savePng",    "PNG",      icon = Icon("download"))
           #   )
           # ),
           fluidRow(
             id = "mainPlotRow",
             style = "position: relative; z-index: 1;",
             plotOutput(outputId = "mainPlot", height = "600px"),
             htmlOutput("references",    style = "clear: both;")
           )
    )
  )
)
