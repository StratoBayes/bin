results_server <- function(input, output, session, data_api, model_api) {

  # User-added named partitions per site (persist when switching wells)
  # Structure: list(siteName = data.frame(name = character(), height = numeric()))
  userPartitionsPerSite <- reactiveValues()

  # Normalize heights: remove duplicates, sort ascending, format as string
  # This ensures consistent ordering and no duplicates
  normalizeHeightsString <- function(raw) {
    if (is.null(raw) || !nzchar(trimws(raw))) return("")
    vals <- suppressWarnings(
      as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(raw)), ",")))
    )
    vals <- vals[is.finite(vals)]
    if (length(vals) == 0) return("")

    # Remove duplicates and sort in ascending order
    vals_rounded <- round(vals, 10)
    unique_indices <- !duplicated(vals_rounded)
    vals_unique <- vals[unique_indices]
    vals_sorted <- sort(vals_unique)

    if (length(vals_sorted) == 0) "" else paste(round(vals_sorted, 5), collapse = ", ")
  }

  # Parse comma-separated heights from a text input. Returns NULL if empty/invalid.
  # Automatically removes duplicate entries and sorts in ascending order.
  parseRefHeightsInput <- function(raw) {
    if (is.null(raw) || !nzchar(trimws(raw))) return(NULL)
    vals <- suppressWarnings(
      as.numeric(unlist(strsplit(gsub("\\s+", ",", trimws(raw)), ",")))
    )
    vals <- vals[is.finite(vals)]
    if (length(vals) == 0) return(NULL)

    # Remove duplicates and sort in ascending order
    vals_rounded <- round(vals, 10)
    unique_indices <- !duplicated(vals_rounded)
    vals_unique <- vals[unique_indices]
    vals_sorted <- sort(vals_unique)

    if (length(vals_sorted) == 0) NULL else vals_sorted
  }

  # Clamp heights to just inside the site data range to avoid StratMap out-of-bounds
  # errors caused by floating-point boundary values stored in partsAttr$Bound.
  # Strategy:
  #   - Heights significantly outside range (intentional Top_ buffers): preserve as-is
  #   - Heights slightly outside range (floating-point rounding only): snap to boundary
  #   - Heights at or near boundary (within boundary_tolerance): preserve as-is
  #   - Heights clearly inside range: apply epsilon inward nudge for safety
  clampRefHeightsToSite <- function(heights, alignm, sourceSite,
                                    eps_fraction = 1e-4, eps_abs = 1e-6) {
    if (is.null(heights) || length(heights) == 0) return(heights)
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(heights)
    if (is.null(sourceSite)) return(heights)
    tryCatch({
      # Use BoundLow and Bound from partsAttr to match what .AgeConversionGeneral validates against
      # This ensures our clamping matches the validation logic
      data <- alignm$data
      sites <- data$sites
      if (is.null(sites)) return(heights)

      # Convert site name to index if needed
      siteIdx <- if (is.character(sourceSite)) {
        match(sourceSite, sites)
      } else {
        as.integer(sourceSite)
      }
      if (is.na(siteIdx) || siteIdx < 1 || siteIdx > length(sites)) return(heights)

      # Get bounds from partsAttr (same as .AgeConversionGeneral uses)
      boundLow <- data[[c("partsAttr", "BoundLow")]][, siteIdx]
      boundHigh <- data[[c("partsAttr", "Bound")]][, siteIdx]

      # Get valid bounds (non-NA)
      boundLow <- boundLow[is.finite(boundLow)]
      boundHigh <- boundHigh[is.finite(boundHigh)]

      if (length(boundLow) == 0 || length(boundHigh) == 0) return(heights)

      siteMin <- min(boundLow, na.rm = TRUE)
      siteMax <- max(boundHigh, na.rm = TRUE)
      height_range <- siteMax - siteMin

      # Tolerance for floating-point rounding errors only (very tight: 0.001% of range, min 0.0001 units)
      rounding_tolerance <- max(height_range * 0.00001, 0.0001, na.rm = TRUE)

      # Tolerance for "at the boundary" detection — heights this close to siteMax/siteMin
      # are treated as boundary values and NOT nudged inward with epsilon
      boundary_tolerance <- max(height_range * 0.0001, 0.001, na.rm = TRUE)

      # Epsilon for nudging clearly-interior heights slightly away from boundaries
      eps <- max(height_range * eps_fraction, eps_abs)

      # Buffer threshold for intentional buffers (like Top_ partitions): 1% of range or 0.1 units
      buffer_threshold <- max(height_range * 0.01, 0.1, na.rm = TRUE)

      for (i in seq_along(heights)) {
        excess_above <- heights[i] - siteMax
        excess_below <- siteMin - heights[i]

        if (excess_above > buffer_threshold) {
          # Significantly above siteMax (beyond buffer threshold): likely intentional Top_ partition buffer
          # However, .AgeConversionGeneral validates against Bound, so we need to clamp to max(Bound)
          # to ensure validation passes. Top partitions should be stored in Bound anyway.
          heights[i] <- siteMax

        } else if (excess_above > rounding_tolerance) {
          # Moderately above siteMax (between rounding_tolerance and buffer_threshold)
          # Clamp to siteMax to ensure validation passes
          heights[i] <- siteMax

        } else if (excess_above > 0) {
          # Slightly above siteMax (floating-point rounding error only): snap to siteMax
          heights[i] <- siteMax

        } else if (excess_below > buffer_threshold) {
          # Significantly below siteMin: intentional buffer — clamp to siteMin
          heights[i] <- siteMin

        } else if (excess_below > rounding_tolerance) {
          # Moderately below siteMin: clamp to siteMin
          heights[i] <- siteMin

        } else if (excess_below > 0) {
          # Slightly below siteMin (floating-point rounding error only): snap to siteMin
          heights[i] <- siteMin

        } else {
          # Height is within [siteMin, siteMax]
          # If it is AT or very near a boundary, preserve it exactly (no inward nudge)
          at_max <- (siteMax - heights[i]) <= boundary_tolerance
          at_min <- (heights[i] - siteMin) <= boundary_tolerance
          if (!at_max && !at_min) {
            # Clearly interior: nudge slightly inward so StratMap never sees an exact boundary
            heights[i] <- min(heights[i], siteMax - eps)
            heights[i] <- max(heights[i], siteMin + eps)
          }
          # If at_max or at_min: leave exactly as-is
        }
      }

      heights
    }, error = function(e) heights)
  }


  # Convert heights-at-source-well to reference heights for TopsPlot.
  # heightsAtSite must be numeric heights/depths at the well named sourceSite (site index 1 = reference).
  # When sourceSite is the reference well, return as-is; otherwise use StratMap to convert to reference scale.
  refHeightsFromSourceSite <- function(alignm, heightsAtSite, sourceSite) {
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(NULL)
    sites <- alignm$data$sites
    if (is.null(sites) || length(sites) == 0) return(heightsAtSite)
    refIdx <- 1L
    srcIdx <- match(as.character(sourceSite), as.character(sites), nomatch = NA)
    if (is.na(srcIdx)) return(heightsAtSite)
    if (srcIdx == refIdx || length(heightsAtSite) == 0) return(heightsAtSite)
    tryCatch({
      out <- StratoBayes::StratMap(alignm, heightsAtSite, site = sourceSite)[["mean"]]
      if (is.null(out) || any(!is.finite(out))) heightsAtSite else as.numeric(out)
    }, error = function(e) heightsAtSite)
  }

  # Set default refHeights only when switching TO the correlation tab (not when changing alignment selection).
  # This avoids overwriting the user's refHeights and prevents UI jump when toggling alignments.
  observeEvent(input$plotTypeMain, {
    if (!identical(input$plotTypeMain, "correlation")) return()
    alignm <- model_api$alignment()
    if (is.null(alignm) || is.null(alignm$data)) return()
    dataObj <- alignm$data

    defaultRefHeights <- NULL
    if (dataObj[["S"]] == 2) {
      site2Range <- range(c(dataObj[[c("partsAttr", "Bound")]][,2],
                          dataObj[[c("partsAttr", "BoundLow")]][,2]), na.rm = TRUE)
      site2Span <- diff(site2Range)
      refHeightsSite2 <- c(site2Range[1], mean(site2Range), site2Range[2]) + c(0.1, 0, -0.1) * site2Span
      tryCatch({
        defaultRefHeights <- StratoBayes::StratMap(alignm, refHeightsSite2, 2)[["mean"]]
      }, error = function(e) {
        defaultRefHeights <<- NULL
      })
    } else {
      bounds <- unique(c(na.omit(dataObj[[c("partsAttr", "Bound")]][, 1]),
                       na.omit(dataObj[[c("partsAttr", "BoundLow")]][, 1])))
      if (length(bounds) > 2) {
        bounds_sorted <- sort(bounds)
        defaultRefHeights <- bounds_sorted[is.finite(bounds_sorted)]
      } else {
        tryCatch({
          h1 <- StratoBayes::SignalLookUp(dataObj, "height", 1, signal = 1, includeNAsignal = FALSE)
          h1_vals <- c(min(h1, na.rm = TRUE), mean(range(h1, na.rm = TRUE)), max(h1, na.rm = TRUE))
          h1_vals <- h1_vals[is.finite(h1_vals)]
          defaultRefHeights <- if (length(h1_vals) > 0) sort(h1_vals) else c(0, 1, 2)
        }, error = function(e) {
          defaultRefHeights <<- c(0, 1, 2)
        })
      }
    }

    if (is.null(defaultRefHeights) || length(defaultRefHeights) == 0 || any(!is.finite(defaultRefHeights))) {
      defaultRefHeights <- c(0, 1, 2)
    } else {
      defaultRefHeights <- defaultRefHeights[is.finite(defaultRefHeights)]
      if (length(defaultRefHeights) == 0) defaultRefHeights <- c(0, 1, 2)
    }
    # Normalize default heights (sort, remove duplicates)
    defaultRefHeights_normalized <- sort(unique(round(defaultRefHeights, 10)))
    refHeightsStr <- paste(round(defaultRefHeights_normalized, 3), collapse = ", ")
    updateTextInput(session, "refHeights", value = refHeightsStr)
  }, ignoreInit = TRUE)

  # Correlation tab: well selector (heights/depths at this well are mapped to reference and plotted)
  output$correlationSourceSite_ui <- renderUI({
    alignm <- model_api$alignment()
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(NULL)
    sites <- alignm$data$sites
    if (is.null(sites) || length(sites) == 0) return(NULL)
    selected <- input$correlationSourceSite
    if (is.null(selected) || !selected %in% sites) selected <- sites[1]
    div(
      style = "margin-bottom: 8px;",
      tags$strong("Select Well", style = "display: block; margin-bottom: 4px;"),
      selectInput("correlationSourceSite", NULL, choices = sites, selected = selected, width = "100%")
    )
  })

  # Partitions (name + height) for the currently selected well from alignment data
  correlationPartitions <- reactive({
    alignm <- model_api$alignment()
    if (is.null(alignm) || !inherits(alignm$data, "StratData")) return(data.frame(name = character(0), height = numeric(0)))
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return(data.frame(name = character(0), height = numeric(0)))
    dataObj <- alignm$data
    sites <- dataObj$sites
    idx <- match(siteName, sites, nomatch = NA)
    if (is.na(idx)) return(data.frame(name = character(0), height = numeric(0)))
    bound <- tryCatch(dataObj[[c("partsAttr", "Bound")]], error = function(e) NULL)
    sedOri <- tryCatch(dataObj[[c("partsAttr", "sedRatesDFOri")]], error = function(e) NULL)
    if (is.null(bound) || !is.matrix(bound) || idx > ncol(bound)) return(data.frame(name = character(0), height = numeric(0)))
    h <- bound[, idx]
    nms <- if (!is.null(sedOri) && is.matrix(sedOri) && idx <= ncol(sedOri))
      as.character(sedOri[, idx]) else rep("", length(h))
    keep <- is.finite(h) & !is.na(h) & !is.na(nms) & nzchar(trimws(nms)) & trimws(nms) != "unconformity-NA"
    if (!any(keep)) return(data.frame(name = character(0), height = numeric(0)))
    out <- data.frame(name = trimws(nms[keep]), height = as.numeric(h[keep]), stringsAsFactors = FALSE)
    out <- out[order(out$height), ]
    out <- out[!duplicated(out$height), ]
    out
  })

  # Combined partitions: model partitions + user-added for current site (persist per site)
  combinedPartitions <- reactive({
    modelParts <- correlationPartitions()
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return(data.frame(name = character(0), height = numeric(0), isUser = logical(0)))
    userParts <- userPartitionsPerSite[[siteName]]
    if (is.null(userParts) || !is.data.frame(userParts) || nrow(userParts) == 0) {
      modelParts$isUser <- FALSE
      return(modelParts)
    }
    userParts$isUser <- TRUE
    modelParts$isUser <- FALSE
    merged <- rbind(modelParts, userParts[, c("name", "height", "isUser")])
    merged <- merged[order(merged$height), ]
    merged <- merged[!duplicated(round(merged$height, 8)), ]
    merged
  })

  # Correlation tab: heights or depths at selected well + tooltip + partition buttons + add partition
  output$correlationRefHeightsBlock_ui <- renderUI({
    alignm <- model_api$alignment()
    if (is.null(alignm)) return(NULL)
    dataScale <- input$dataScale %||% "depth"
    label <- if (identical(dataScale, "depth")) "Depths at selected well" else "Heights at selected well"
    placeholder <- if (identical(dataScale, "depth")) "e.g. -10, -20, -30" else "e.g. 1, 2, 3"
    heightPlaceholder <- if (identical(dataScale, "depth")) "e.g. -7500" else "e.g. 100"
    parts <- combinedPartitions()
    siteName <- input$correlationSourceSite
    tagList(
      div(
        style = "margin-bottom: 6px; display: flex; align-items: center;",
        tags$label(tags$strong(label), style = "margin: 0 6px 0 0;"),
        tags$span(
          class = "correlation-depths-tooltip",
          style = "color: #6c757d; font-size: 0.85em;",
          icon("circle-info", class = "fas"),
          tags$span(
            class = "correlation-depths-tooltiptext",
            "Comma-separated values; mapped to reference and drawn across all sites."
          )
        )
      ),
      textInput("refHeights", NULL, placeholder = placeholder, width = "100%"),
      div(
        class = "correlation-partitions-block",
        style = "margin-top: 8px; overflow: visible;",
        div(
          style = "display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; margin-bottom: 4px;",
          tags$strong("Boundaries / Partitions", style = "font-size: 0.9em; white-space: nowrap;"),
          tags$span(
            class = "correlation-depths-tooltip",
            style = "color: #6c757d; font-size: 0.85em; flex-shrink: 0;",
            icon("circle-info", class = "fas"),
            tags$span(
              class = "correlation-depths-tooltiptext",
              "Click a partition to add its depth/height to the correlation lines. Add custom named partitions for this well (saved per well)."
            )
          )
        ),
        if (nrow(parts) > 0) {
          div(
            style = "display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px;",
            lapply(seq_len(nrow(parts)), function(i) {
              row <- parts[i, ]
              btn <- tags$button(
                row$name,
                class   = "btn btn-sm btn-default",
                style   = "min-width: 2em;",
                onclick = sprintf(
                  "Shiny.setInputValue('appendPartitionHeight', {height: %s, counter: Math.random()}, {priority: 'event'});",
                  row$height
                )
              )
              if (isTRUE(row$isUser)) {
                div(
                  style = "display: inline-flex; align-items: center; gap: 2px;",
                  btn,
                  tags$button(
                    icon("times", class = "fas"),
                    class = "btn btn-sm btn-default",
                    style = "padding: 2px 6px;",
                    onclick = sprintf(
                      "Shiny.setInputValue('removeUserPartition', {site: '%s', height: %s}, {priority: 'event'});",
                      gsub("'", "\\'", siteName), row$height
                    ),
                    title = "Remove this partition"
                  )
                )
              } else {
                btn
              }
            })
          )
        },
        div(
          style = "display: flex; flex-wrap: wrap; align-items: center; gap: 4px;",
          textInput("newPartitionName", NULL, placeholder = "Name", width = "80px"),
          textInput("newPartitionHeight", NULL, placeholder = heightPlaceholder, width = "70px"),
          actionButton("addUserPartition", "Add", class = "btn-sm btn-primary")
        )
      )
    )
  })

  # Add user partition for current site
  observeEvent(input$addUserPartition, {
    siteName <- input$correlationSourceSite
    if (is.null(siteName)) return()
    nm <- trimws(input$newPartitionName %||% "")
    h <- suppressWarnings(as.numeric(input$newPartitionHeight %||% ""))
    if (!nzchar(nm)) {
      showNotification("Enter a partition name.", type = "warning")
      return()
    }
    if (is.na(h) || !is.finite(h)) {
      showNotification("Enter a valid depth or height.", type = "warning")
      return()
    }
    existing <- userPartitionsPerSite[[siteName]]
    if (is.null(existing) || !is.data.frame(existing)) {
      existing <- data.frame(name = character(0), height = numeric(0), stringsAsFactors = FALSE)
    }
    newRow <- data.frame(name = nm, height = h, stringsAsFactors = FALSE)
    combined <- rbind(existing, newRow)
    combined <- combined[order(combined$height), ]
    combined <- combined[!duplicated(round(combined$height, 8)), ]
    userPartitionsPerSite[[siteName]] <- combined
    updateTextInput(session, "newPartitionName", value = "")
    updateTextInput(session, "newPartitionHeight", value = "")
    # Add the new partition's height to refHeights (correlation lines) without clearing existing selection
    current <- trimws(input$refHeights %||% "")
    newVal  <- round(h, 5)
    added   <- if (nzchar(current)) paste(current, newVal, sep = ", ") else as.character(newVal)
    updateTextInput(session, "refHeights", value = normalizeHeightsString(added))
    showNotification(paste("Added partition", nm, "for", siteName), type = "message", duration = 2)
  })

  # Remove user partition
  observeEvent(input$removeUserPartition, {
    site <- input$removeUserPartition$site
    height <- as.numeric(input$removeUserPartition$height)
    if (is.null(site) || is.na(height) || !is.finite(height)) return()
    existing <- userPartitionsPerSite[[site]]
    if (is.null(existing) || !is.data.frame(existing) || nrow(existing) == 0) return()
    tol <- 1e-6
    keep <- abs(existing$height - height) > tol
    if (any(!keep)) {
      userPartitionsPerSite[[site]] <- existing[keep, , drop = FALSE]
      # Remove this partition's height from refHeights (correlation lines) but keep the rest
      currentVals <- parseRefHeightsInput(input$refHeights)
      if (!is.null(currentVals) && length(currentVals) > 0) {
        remaining <- currentVals[abs(currentVals - height) > tol]
        updateTextInput(session, "refHeights", value = normalizeHeightsString(
          if (length(remaining) > 0) paste(round(remaining, 5), collapse = ", ") else ""))
      }
      showNotification("Partition removed", type = "message", duration = 2)
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Keep current partitions (name + height) for append buttons
  correlationPartitionsForAppend <- reactiveVal(data.frame(name = character(0), height = numeric(0)))
  observe({
    correlationPartitionsForAppend(combinedPartitions()[, c("name", "height"), drop = FALSE])
  })

  # Partition buttons: a single JS message handler replaces pre-registering N observers.
  # The button's onclick (injected in renderUI below) sends the height value directly.
  observeEvent(input$appendPartitionHeight, {
    height  <- as.numeric(input$appendPartitionHeight$height)
    counter <- input$appendPartitionHeight$counter  # ensures repeated clicks on same button fire
    if (is.null(height) || !is.finite(height)) return()
    current <- trimws(input$refHeights %||% "")
    newVal  <- round(height, 5)
    # Add new value to current string, then normalize (remove duplicates, sort)
    added   <- if (nzchar(current)) paste(current, newVal, sep = ", ") else as.character(newVal)
    normalized <- normalizeHeightsString(added)
    updateTextInput(session, "refHeights", value = normalized)
    # Clamping happens at plot/export time via clampRefHeightsToSite()
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Create a debounced version of refHeights input to wait for user to finish typing
  # This prevents normalization from triggering on every keystroke
  refHeightsDebounced <- debounce(reactive({ input$refHeights }), millis = 750)

  # Observer to normalize heights whenever user manually edits the input
  # This ensures duplicates are removed and values are sorted after user stops typing
  # Debounced to wait 0.75 seconds of inactivity before triggering
  observeEvent(refHeightsDebounced(), {
    current <- trimws(refHeightsDebounced() %||% "")
    if (!nzchar(current)) return()
    normalized <- normalizeHeightsString(current)
    # Only update if normalization changed the value (to avoid infinite loops)
    if (normalized != current) {
      updateTextInput(session, "refHeights", value = normalized)
    }
  }, ignoreInit = TRUE)

  # Export well tops download handler
  output$exportWellTops <- downloadHandler(
    filename = function() {
      paste0("well-tops-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S"), ".csv")
    },
    content = function(file) {
      # Get alignment object
      alignm <- model_api$alignment()
      if (is.null(alignm)) {
        showNotification("No results available. Please run a model first.", type = "error")
        return()
      }

      # Parse and clamp heights at selected source site; convert to reference heights if needed.
      sourceSite <- input$correlationSourceSite %||% alignm$data$sites[1]
      refHeights <- parseRefHeightsInput(input$refHeights)
      if (!is.null(refHeights)) {
        refHeights <- clampRefHeightsToSite(refHeights, alignm, sourceSite)
        refHeights <- refHeightsFromSourceSite(alignm, refHeights, sourceSite)
      }

      # Get alignment selection
      alignmentSel <- input$posteriorAlignments
      clustUnique <- model_api$stratCluster()$clustUnique

      # Convert selected cluster IDs to integers
      selected_clusters <- tryCatch({
        if (is.null(alignmentSel) || length(alignmentSel) == 0) {
          # No selection: default to first 4 (or all if <= 4)
          if (length(clustUnique) <= 4) {
            as.integer(clustUnique)
          } else {
            as.integer(clustUnique[1:4])
          }
        } else {
          # Convert to integers
          as.integer(alignmentSel)
        }
      }, error = function(e) {
        return(integer(0))
      })

      # Filter out invalid cluster IDs
      valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
      valid_clusters <- valid_clusters[!is.na(valid_clusters)]

      # Limit to maximum of 4 alignments
      if (length(valid_clusters) == 0) {
        # No valid clusters: default to first 4 (or all if <= 4)
        if (length(clustUnique) <= 4) {
          alignmentSel <- as.integer(clustUnique)
        } else {
          alignmentSel <- as.integer(clustUnique[1:4])
        }
      } else if (length(valid_clusters) > 4) {
        # More than 4 selected: limit to first 4
        alignmentSel <- valid_clusters[1:4]
      } else {
        alignmentSel <- valid_clusters
      }

      # Get sites
      sites <- input$posteriorSites %||% "all"

      # Calculate quantiles based on confidence level
      confidenceLevel <- input$confidenceLevel %||% 80
      if (confidenceLevel == 0) {
        quantiles <- 0.5
      } else if (confidenceLevel >= 100) {
        quantiles <- c(0.0, 0.5, 1.0)
      } else {
        alpha <- (100 - confidenceLevel) / 100
        lowerQuantile <- alpha / 2
        upperQuantile <- 1 - (alpha / 2)
        quantiles <- c(lowerQuantile, 0.5, upperQuantile)
      }

      # Get stratCluster if needed (always needed when alignmentSel is a vector)
      stratCluster <- model_api$stratCluster()

      # Call Tops function
      tryCatch({
        tops_df <- StratoBayes::Tops(
          stratObject = alignm,
          refHeights = refHeights,
          alignment = alignmentSel,
          burnIn = input$posteriorBurn/100,
          stratCluster = stratCluster,
          quantiles = quantiles
        )

        # Write to CSV
        write.csv(tops_df, file = file, row.names = FALSE)
      }, error = function(e) {
        showNotification(paste("Error generating well tops:", e$message), type = "error")
        # Write error message to file
        write.csv(data.frame(Error = e$message), file = file, row.names = FALSE)
      })
    },
    contentType = "text/csv"
  )

  # sync plot types between load and view
  observeEvent(input$sigPlotType_load, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_view", selected = input$sigPlotType_load)
  })
  observeEvent(input$sigPlotType_view, ignoreInit = TRUE, {
    updateRadioButtons(session, "sigPlotType_load", selected = input$sigPlotType_view)
  })

  # Posterior controls
  # Get sites and signals from alignment result, NOT from current dataset
  output$posteriorSiteSel <- renderUI({
    req(model_api$alignment())
    alignm <- model_api$alignment()
    # Get sites from alignment result's data
    sites <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData")) {
      alignm$data$sites
    } else {
      # Fallback to current dataset if alignment doesn't have data
      if (data_api$signalValid()) {
        data_api$stratData()$sites
      } else {
        character(0)
      }
    }

    # Get current selection to preserve user choices
    currentSelection <- input$posteriorSites

    # Default to first 4 sites (or all if 4 or fewer), unless user has already selected
    if (is.null(currentSelection) || length(currentSelection) == 0) {
      if (length(sites) <= 4) {
        selectedSites <- sites
      } else {
        selectedSites <- sites[1:4]
      }
    } else {
      # Preserve user's selection
      selectedSites <- currentSelection
    }

    checkboxGroupInput("posteriorSites", NULL,
                       choices = sites,
                       selected = selectedSites,
                       inline = TRUE
    )
  })
  output$posteriorSignalSel <- renderUI({
    req(model_api$alignment())
    alignm <- model_api$alignment()
    # Get signal columns from alignment result's data
    sigCols <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData") &&
                   !is.null(alignm$data$signalAttr) && !is.null(alignm$data$signalAttr$signalNames)) {
      alignm$data$signalAttr$signalNames
    } else {
      # Fallback to current dataset if alignment doesn't have data
      if (data_api$signalValid()) {
        data_api$signalCols()
      } else {
        character(0)
      }
    }
    plotType <- input$plotTypeMain %||% "alignment"

    # For correlation plot (TopsPlot), only allow one signal at a time
    # Auto-select first signal
    if (plotType == "correlation") {
      # Get current selection or default to first signal
      currentSel <- input$posteriorSignals
      if (is.null(currentSel) || length(currentSel) == 0 || length(currentSel) > 1) {
        currentSel <- if (length(sigCols) > 0) sigCols[1] else character(0)
      } else {
        # Ensure selected signal is still valid
        if (!currentSel %in% sigCols) {
          currentSel <- if (length(sigCols) > 0) sigCols[1] else character(0)
        }
      }
      radioButtons("posteriorSignals", NULL,
                   choices  = setNames(sigCols, sigCols),
                   selected = currentSel,
                   inline   = TRUE
      )
    } else {
      # For other plots, allow multiple signals
      checkboxGroupInput("posteriorSignals", NULL,
                         choices  = sigCols,
                         selected = if (is.null(input$posteriorSignals)) sigCols else input$posteriorSignals,
                         inline   = TRUE
      )
    }
  })
  # Track whether to show all alignments
  showAllAlignments <- reactiveVal(FALSE)

  # Reset show all when plot type changes (do NOT change alignment selection - avoids loops)
  observeEvent(input$plotTypeMain, {
    showAllAlignments(FALSE)
  }, ignoreInit = TRUE)

  # Handle show all alignments button
  observeEvent(input$showAllAlignments, {
    showAllAlignments(TRUE)
  })

  # Debounce alignment selection so plot doesn't re-run on every checkbox click (breaks reactive loops)
  alignmentSelectionDebounced <- debounce(reactive({
    input$posteriorAlignments
  }), millis = 500)

  output$posteriorAlnSel <- renderUI({
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    nClust <- length(cl)
    cl_char <- as.character(cl)

    # Determine which clusters to show (for Show All / hide beyond 4)
    if (showAllAlignments() || nClust <= 4) {
      clustersToShow <- cl
    } else {
      clustersToShow <- cl[1:4]
    }

    # CRITICAL: Use isolate() so we do NOT create a reactive dependency on these inputs.
    # Otherwise: user clicks -> renderUI runs -> selection used -> widget updates -> renderUI runs again -> loop.
    currentSelection <- isolate(input$posteriorAlignments)
    plotType <- isolate(input$plotTypeMain) %||% "alignment"

    # Restrict to valid cluster IDs only (avoids Shiny errors from selected not in choices)
    currentSelection <- intersect(as.character(currentSelection %||% character(0)), cl_char)

    # Set default ONLY when nothing selected; otherwise keep user's selection as-is (no auto-modify).
    if (length(currentSelection) == 0) {
      if (plotType == "correlation") {
        selectedClusters <- cl_char
      } else {
        selectedClusters <- if (length(cl) <= 4) cl_char else as.character(cl[1:4])
      }
    } else {
      selectedClusters <- currentSelection
    }

    tagList(
      tags$div(
        id = "alignmentSelectorContainer",
        class = "strat-checklist",
        style = "margin-bottom: 10px;",
        checkboxGroupInput("posteriorAlignments", NULL,
                         choices  = setNames(cl_char, cl_char),
                         selected = selectedClusters,
                         inline   = FALSE
        )
      ),
      if (nClust > 4 && !showAllAlignments()) {
        tags$script(HTML(paste0("
          $(document).ready(function() {
            setTimeout(function() {
              var container = $('#alignmentSelectorContainer');
              var checkboxes = container.find('input[type=\"checkbox\"]');
              var clusterValues = ", jsonlite::toJSON(cl_char), ";
              checkboxes.each(function(index) {
                var value = $(this).val();
                var clusterIndex = clusterValues.indexOf(value);
                if (clusterIndex >= 4) {
                  $(this).closest('div.checkbox').hide();
                }
              });
            }, 100);
          });
        ")))
      } else {
        tags$script(HTML("
          $(document).ready(function() {
            setTimeout(function() {
              $('#alignmentSelectorContainer').find('div.checkbox').show();
            }, 100);
          });
        "))
      },
      tags$div(
        style = "display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;",
        actionButton("selectAllAlignments", "Select All",
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        actionButton("deselectAllAlignments", "Deselect All (keep 1)",
                    class = "btn-sm btn-default",
                    style = "font-size: 0.85em; padding: 2px 8px;"),
        if (nClust > 4 && !showAllAlignments()) {
          actionButton("showAllAlignments", "Show All Alignments",
                      class = "btn-sm btn-info",
                      style = "font-size: 0.85em; padding: 2px 8px;")
        } else {
          NULL
        }
      )
    )
  })

  # Reactive: selected trace plot parameter (so plot clearly depends on it)
  tracePlotParameter <- reactive({
    p <- input$tracePlotParameter
    if (is.null(p) || !nzchar(trimws(p))) return("log posterior")
    as.character(p)
  })

  # Format parameter names for display (aligned with Prior tab: alpha, gamma/sed rate, zeta, delta)
  formatTraceParamName <- function(name) {
    if (grepl("^gammaLog_", name, ignore.case = TRUE)) {
      sub("^gammaLog_", "relative sed. rate (\u03bd) ", name, ignore.case = TRUE)
    } else if (grepl("^alpha_", name, ignore.case = TRUE)) {
      sub("^alpha_", "correlation anchor (\u03b1) ", name, ignore.case = TRUE)
    } else if (grepl("^gamma_", name, ignore.case = TRUE)) {
      sub("^gamma_", "sed. rate ", name, ignore.case = TRUE)
    } else if (grepl("^zetaLog_", name, ignore.case = TRUE)) {
      sub("^zetaLog_", "sed. rate multiplier (\u03b6) ", name, ignore.case = TRUE)
    } else if (grepl("^zeta_", name, ignore.case = TRUE)) {
      sub("^zeta_", "sed. rate multiplier ", name, ignore.case = TRUE)
    } else if (grepl("^(delta|gap)_", name, ignore.case = TRUE)) {
      sub("^(delta|gap)_", "unconformity ", name, ignore.case = TRUE)
    } else {
      name
    }
  }

  # Trace plot: single-parameter dropdown (log posterior / log prior / log likelihood + model params)
  # Choices use display names (labels) with values = internal names for TracePlot; match selected by value.
  output$tracePlotParameterSel <- renderUI({
    choices <- c(
      "log posterior"  = "log posterior",
      "log prior"      = "log prior",
      "log likelihood" = "log likelihood"
    )
    alignm <- model_api$alignment()
    if (!is.null(alignm) && inherits(alignm, "StratPosterior")) {
      pnames <- alignm[[c("model", "parametersNames")]]
      if (!is.null(pnames) && length(pnames) > 0L) {
        displayNames <- vapply(pnames, formatTraceParamName, character(1))
        choices <- c(choices, setNames(pnames, displayNames))
      }
    }
    choiceValues <- unname(choices)
    current <- isolate(input$tracePlotParameter)
    selected <- if (!is.null(current) && current %in% choiceValues) current else "log posterior"
    selectInput(
      "tracePlotParameter",
      NULL,
      choices  = choices,
      selected = selected,
      width    = "100%"
    )
  })

  # Handle select all alignments (ignoreInit prevents triggering on session init)
  observeEvent(input$selectAllAlignments, {
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    updateCheckboxGroupInput(session, "posteriorAlignments",
                            selected = as.character(cl))
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Handle deselect all alignments (keep only alignment 1)
  observeEvent(input$deselectAllAlignments, {
    req(model_api$stratCluster())
    cl <- model_api$stratCluster()$clustUnique
    if (1 %in% cl) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = "1")
    } else if (length(cl) > 0) {
      updateCheckboxGroupInput(session, "posteriorAlignments",
                              selected = as.character(cl[1]))
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Main plot
  output$plotOptionsUI <- renderUI({
    req(input$plotTypeMain)
    switch(input$plotTypeMain,
           "alignment" = div(class = "sb-settings-row",
                             div(class = "sb-setting-block", style="min-width:140px;",
                                 tags$strong("Sites", style="display:block; margin-bottom:6px;"),
                                 tags$div(class="strat-checklist", uiOutput("posteriorSiteSel"))
                             ),
                             div(class = "sb-setting-block", style="min-width:140px;",
                                 tags$strong("Signals", style="display:block; margin-bottom:6px;"),
                                 tags$div(class="strat-checklist", uiOutput("posteriorSignalSel"))
                             ),
                             div(class = "sb-setting-block", style="min-width:170px;",
                                 tags$strong("Alignments", style="display:block; margin-bottom:6px;"),
                                 tags$div(class="strat-checklist", uiOutput("posteriorAlnSel"))
                             ),
                             div(class = "sb-setting-block", style="min-width:100px;",
                                 tags$strong("q", style="display:block; margin-bottom:6px;"),
                                 numericInput("posteriorQuantile", NULL, .5, 0, 1, step = .01, width = "100px")
                             ),
                             div(class = "sb-setting-block", style="min-width:120px;",
                                 tags$strong("Burn-in", style="display:block; margin-bottom:6px;"),
                                 numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")
                             ),
                             div(class = "sb-setting-block", style="min-width:280px;",
                                 tags$strong("Style & Size", style="display:block; margin-bottom:6px;"),
                                 div(style="display:flex; gap:0.5rem; align-items:center;",
                                     radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"), inline = TRUE, selected = "l"),
                                     sliderInput("posteriorCex",  "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                     sliderInput("posteriorLwd",  "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                 )
                             )
           ),
           "traceplot" = div(class = "sb-traceplot-options",
                             style = "position: relative; z-index: 1050; overflow: visible; white-space: nowrap; padding-bottom: 0.5rem;",
                             div(style="display:inline-block; vertical-align:top; min-width:180px;",
                                 tags$strong("Parameter", style="display:block; margin-bottom:6px;"),
                                 uiOutput("tracePlotParameterSel")
                             ),
                             div(style="display:inline-block; vertical-align:top; min-width:140px;",
                                 tags$strong("Alignments", style="display:block; margin-bottom:6px;"),
                                 tags$div(class="strat-checklist", uiOutput("posteriorAlnSel"))
                             ),
                             div(style="display:inline-block; vertical-align:top; min-width:120px;",
                                 tags$strong("Burn-in", style="display:block; margin-bottom:6px;"),
                                 numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")
                             ),
                             div(style="display:inline-block; vertical-align:top; min-width:280px;",
                                 tags$strong("Style & Size", style="display:block; margin-bottom:6px;"),
                                 div(style="display:flex; gap:0.5rem; align-items:center;",
                                     radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"),
                                                  inline = TRUE, selected = "l"),
                                     sliderInput("posteriorCex", "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                     sliderInput("posteriorLwd", "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                 )
                             )
           ),
           "correlation" = div(style = "overflow-x:auto; white-space:nowrap; padding-bottom:0.5rem;",
                               div(style="display:inline-block; vertical-align:top; min-width:120px;",
                                   tags$strong("Sites", style="display:block; margin-bottom:6px;"),
                                   uiOutput("posteriorSiteSel")
                               ),
                               div(style="display:inline-block; vertical-align:top; min-width:120px;",
                                   tags$strong("Signals", style="display:block; margin-bottom:6px;"),
                                   uiOutput("posteriorSignalSel")
                               ),
                               div(style="display:inline-block; vertical-align:top; min-width:140px;",
                                   tags$strong("Alignments", style="display:block; margin-bottom:6px;"),
                                   tags$div(class="strat-checklist", uiOutput("posteriorAlnSel"))
                               ),
                               div(style="display:inline-block; vertical-align:top; min-width:120px;",
                                   tags$strong("Burn-in", style="display:block; margin-bottom:6px;"),
                                   numericInput("posteriorBurn", NULL, 50, 0, 99, step = 1, width = "100px")
                               ),
                               div(style="display:inline-block; vertical-align:top; min-width:280px;",
                                   tags$strong("Style & Size", style="display:block; margin-bottom:6px;"),
                                   div(style="display:flex; gap:0.5rem; align-items:center;",
                                       radioButtons("posteriorStyle", NULL, c("Pts"="p","Lines"="l","Both"="o"), inline = TRUE, selected = "l"),
                                       sliderInput("posteriorCex", "● size", min=.5, max=5, step=.1, value=1, width="80px"),
                                       sliderInput("posteriorLwd", "— width", min=.5, max=5, step=.5, value=2, width="80px")
                                   )
                               )
           )
    )
  })

  output$mainPlot <- renderPlot({
    # Only run when these exist (prevents the getDims crash inside your plotting fns)
    req(input$plotTypeMain)
    req(model_api$alignment())
    req(model_api$stratCluster())

    alignm <- model_api$alignment()
    clust  <- model_api$stratCluster()

    switch(input$plotTypeMain,
           alignment = {
             alignmentSel <- alignmentSelectionDebounced()
             clustUnique <- model_api$stratCluster()$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- input$posteriorSites   %||% "all"
             signals <- input$posteriorSignals %||% 1
             style   <- input$posteriorStyle   %||% "p"

             # Validate quantile
             quantile_val <- input$posteriorQuantile
             if (is.null(quantile_val) || is.na(quantile_val) ||
                 !is.numeric(quantile_val) || quantile_val < 0 || quantile_val > 1) {
               quantile_val <- 0.5  # Default to median
             }

             plot(alignm,
                  alignment     = alignmentSel,
                  stratCluster  = clust,
                  sites         = sites,
                  signal        = signals,
                  separateSites = TRUE,
                  quantile      = quantile_val,
                  burnIn        = input$posteriorBurn/100,
                  type          = style,
                  cex           = input$posteriorCex,
                  lwd           = input$posteriorLwd,
                  cex.lab = 1.4, cex.axis = 1.3, cex.main = 1.4)
           },
           traceplot = {
             alignmentSel <- alignmentSelectionDebounced()
             clustUnique <- model_api$stratCluster()$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             style <- input$posteriorStyle %||% "l"
             param <- tracePlotParameter()
             # Y-axis label: formatted in Shiny (same as dropdown); add "log " for probability terms
             probTerms <- c("posterior", "prior", "likelihood", "prior_parameters", "prior_overlap", "likelihood_spline", "likelihood_ties")
             ylabTrace <- if (param %in% probTerms) paste("log", param) else formatTraceParamName(param)
             TracePlot(alignm,
                       alignment  = alignmentSel,
                       parameters = param,
                       burnIn     = input$posteriorBurn/100,
                       type       = style,
                       cex        = input$posteriorCex,
                       lwd        = input$posteriorLwd,
                       ylab       = ylabTrace)
           },
           correlation = {
             alignmentSel <- alignmentSelectionDebounced()
             clustUnique <- model_api$stratCluster()$clustUnique

             # Convert selected cluster IDs to integers
             selected_clusters <- tryCatch({
               if (is.null(alignmentSel) || length(alignmentSel) == 0 ||
                   setequal(alignmentSel, as.character(clustUnique))) {
                 # No selection or all selected: default to first 4 (or all if <= 4)
                 if (length(clustUnique) <= 4) {
                   as.integer(clustUnique)
                 } else {
                   as.integer(clustUnique[1:4])
                 }
               } else {
                 # Convert to integers
                 as.integer(alignmentSel)
               }
             }, error = function(e) {
               return(integer(0))
             })

             # Filter out invalid cluster IDs - must be in clustUnique
             valid_clusters <- selected_clusters[selected_clusters %in% clustUnique]
             # Remove any NAs
             valid_clusters <- valid_clusters[!is.na(valid_clusters)]

             # Limit to maximum of 4 alignments
             if (length(valid_clusters) == 0) {
               # No valid clusters: default to first 4 (or all if <= 4)
               if (length(clustUnique) <= 4) {
                 alignmentSel <- as.integer(clustUnique)
               } else {
                 alignmentSel <- as.integer(clustUnique[1:4])
               }
             } else if (length(valid_clusters) > 4) {
               # More than 4 selected: limit to first 4
               alignmentSel <- valid_clusters[1:4]
             } else {
               # Pass the actual cluster IDs (not indices) - validation expects values in clustUnique
               alignmentSel <- valid_clusters
             }
             sites   <- input$posteriorSites   %||% "all"
             # For correlation plot, ensure only one signal is used
             # Get signal columns from alignment result, NOT from current dataset
             alignm <- model_api$alignment()
             sigCols <- if (!is.null(alignm$data) && inherits(alignm$data, "StratData") &&
                            !is.null(alignm$data$signalAttr) && !is.null(alignm$data$signalAttr$signalNames)) {
               alignm$data$signalAttr$signalNames
             } else {
               # Fallback to current dataset if alignment doesn't have data
               if (data_api$signalValid()) {
                 data_api$signalCols()
               } else {
                 character(0)
               }
             }

             if (is.null(input$posteriorSignals)) {
               signals <- 1
             } else if (is.character(input$posteriorSignals) && length(input$posteriorSignals) > 0) {
               # If it's a character vector (from radioButtons), convert to index
               sigName <- input$posteriorSignals[1]  # Take first one
               if (sigName %in% sigCols) {
                 signals <- match(sigName, sigCols)
               } else {
                 signals <- 1
               }
             } else if (is.numeric(input$posteriorSignals)) {
               # If it's numeric, use first one
               signals <- if (length(input$posteriorSignals) > 1) {
                 input$posteriorSignals[1]
               } else {
                 input$posteriorSignals
               }
             } else {
               signals <- 1
             }
             style   <- input$posteriorStyle   %||% "p"

             # Parse and clamp heights at selected source site before passing to TopsPlot.
             sourceSite     <- input$correlationSourceSite %||% alignm$data$sites[1]
             refHeights     <- parseRefHeightsInput(input$refHeights)
             refHeightsSite <- NULL
             if (!is.null(refHeights)) {
               refHeights     <- clampRefHeightsToSite(refHeights, alignm, sourceSite)
               refHeightsSite <- sourceSite
             }

            # If refHeights is still NULL or invalid, let TopsPlot calculate it automatically
            # This prevents "missing value where TRUE/FALSE needed" errors

             # Calculate quantiles based on confidence level
             confidenceLevel <- input$confidenceLevel %||% 80
             if (confidenceLevel == 0) {
               # 0% confidence - just median
               quantiles <- 0.5
             } else if (confidenceLevel >= 100) {
               # 100% confidence - full range
               quantiles <- c(0.0, 0.5, 1.0)
             } else {
               # Calculate symmetric quantiles around median
               alpha <- (100 - confidenceLevel) / 100
               lowerQuantile <- alpha / 2
               upperQuantile <- 1 - (alpha / 2)
               quantiles <- c(lowerQuantile, 0.5, upperQuantile)
             }

            tryCatch({
              TopsPlot(alignm,
                       alignment = alignmentSel,
                       sites     = sites,
                       signal    = signals,
                       burnIn    = input$posteriorBurn/100,
                       type      = style,
                       cex       = input$posteriorCex,
                       lwd       = input$posteriorLwd,
                       refHeights = refHeights,
                       refHeightsSite = refHeightsSite,
                       quantiles = quantiles)
             }, error = function(e) {
               # If TopsPlot fails (e.g., during QuickRun before data is fully ready),
               # show a message instead of crashing
               plot(1, 1, type = "n",
                    xlab = "", ylab = "",
                    main = "Tops plot not available",
                    sub = "Model may still be running or data not fully loaded")
               text(1, 1, paste("Error:", e$message), cex = 0.8, col = "red")
             })
           }
    )
  },
  height = 600,
  width  = 600  ) |> bindEvent(
    model_api$alignment(),
    input$plotTypeMain,
    alignmentSelectionDebounced(),
    input$posteriorSites,
    input$posteriorSignals,
    input$posteriorStyle,
    input$posteriorCex,
    input$posteriorLwd,
    input$posteriorQuantile,
    input$posteriorBurn,
    tracePlotParameter(),
    input$refHeights,
    input$correlationSourceSite,
    input$confidenceLevel
  )

  # simple export
  output$download_session <- downloadHandler(
    filename = function() paste0("session-", Sys.Date(), ".rds"),
    content = function(file) {
      saveRDS(list(
        data = list(
          dataset    = r$dataset,
          siteColumn = data_api$siteColumn(),
          zColumn    = data_api$zColumn(),
          signalCols = data_api$signalCols(),
          stratData  = data_api$stratData()
        ),
        model = list(
          indices      = model_api$indices(),
          priors       = model_api$priors(),
          alignment    = model_api$alignment(),
          stratCluster = model_api$stratCluster()
        )
      ), file)
    }
  )
}
