test_that("Tops works", {

   expect_error(Tops(1, 2, 2), "stratObject must be")

  tops6 <- Tops(stratPosterior1, 6)
  tops6Site2 <- round(tops6[1,"50%"])
  expect_equal(tops6Site2, 0)

  tops6Site3 <- round(tops6[2,"50%"])
  expect_equal(tops6Site3, 5)

  expect_s3_class(Tops(stratPosterior3, 2), "data.frame")

})

#
test_that("Tops works with prior", {
   #set.seed(1)
   h1 <- Tops(stratModel1, refHeights = 6, stratData = stratData1)

   prior2Q25 <- round(h1[1, "2.5%"]/10)
   prior3Q25 <- round(h1[2, "2.5%"]/10)
   prior2Q500 <- round(h1[1, "50%"]/2 - 0.1)
   prior3Q500 <- round(h1[2, "50%"]/2 - 0.1)

   expect_equal(prior2Q25, -1)
   expect_equal(prior3Q25, -1)
   expect_equal(prior2Q500, 1)
   expect_equal(prior3Q500, 1)

})

test_that("Tops works with returning samples", {
  #set.seed(1)
  t1 <- Tops(stratPosterior1, refHeights = 6,
             quantiles = "samples", iterations = c(100, 150), runs = 1)

  expect_equal(nrow(t1), 4)
})


test_that("Tops works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              Tops(stratPosterior3,
                       refHeights = -1,
                       stratCluster = clustNew,
                       alignment = 1)[ , "sd"]
              <
                Tops(stratPosterior3,
                         refHeights = -1,
                         stratCluster = clustNew,
                         alignment = "all")[ , "sd"]

            )
          })

test_that("Tops works with default refHeights", {
            clustNew <- Cluster(stratPosterior3, iterations = 300:400)
            expect_true(
              round(Tops(stratPosterior1)[4, "50%"]) == 4)
          })
