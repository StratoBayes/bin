
# StratData0
# StratModelTemplate(stratData0)
r1 <- range(SignalLookUp(stratData0, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData0, type = "height", site = 2))
d2 <- diff(r2)

min_i <- r1[1] - d2
max_i <- r1[2] + d2

sd_i <- (max_i - min_i) / (2 * 1.96)

alphaPositionSite <-  .MatchAlphaPosition(c(NA, "middle"), stratData0, "height")[2]

relAlphaPos <- alphaPositionSite / r2[2]

m_i <- r1[2] - diff(r1) * relAlphaPos

prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = log(2))),
  class = c("StratPrior", "list"))

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     userPriors = NULL)

test_that("AutoPrior() creates the correct priors", {
  expect_equal(prior0a, prior0b)
})

# custom prior
gammaPrior <- NormalPrior(mean = 0, sd = 3)
prior0a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_i, sd = sd_i),
  "gammaLog_site2" = NormalPrior(mean = 0, sd = 3)),
  class = c("StratPrior", "list"))

prior0b <- AutoPrior(stratData = stratData0,
                     alignmentScale = "height",
                     sedModel = "site",
                     alphaPosition = "middle",
                     userPriors = list(gammaLog_site2 = gammaPrior))

test_that("AutoPrior() creates the correct priors with added custom prior", {
  expect_equal(prior0a, prior0b)
})

# StratData2
# StratModelTemplate(stratData2, alignmentScale = "height", sedModel = "p")
r1 <- range(SignalLookUp(stratData2, type = "height", site = 1))
r2 <- range(SignalLookUp(stratData2, type = "height", site = 2))
r3 <- range(SignalLookUp(stratData2, type = "height", site = 3))

d2 <- diff(r2)
d3 <- diff(r3)

min_2 <- r1[1] - d2
max_2 <- r1[2] + d2
min_3 <- r1[1] - d3
max_3 <- r1[2] + d3


sd_2 <- (max_2 - min_2) / (2 * 1.96)
sd_3 <- (max_3 - min_3) / (2 * 1.96)

alphaPositions <-  c(10, 20, 0)

relAlphaPos2 <- alphaPositions[2] / r2[2]
relAlphaPos3 <- alphaPositions[3] / r3[2]

m_2 <- r1[2] - diff(r1) * relAlphaPos2
m_3 <- r1[2] - diff(r1) * relAlphaPos3

prior2a <- structure(list(
  "alpha_site2" = NormalPrior(mean = m_2, sd = sd_2),
  "alpha_site3" = NormalPrior(mean = m_3, sd = sd_3),
  "gammaLog_part 2.1" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 2.2" = NormalPrior(mean = 0, sd = log(2)),
  "gammaLog_part 3.1" = NormalPrior(mean = 0, sd = log(2)),
  "gap_site2_1" = ExponentialPrior(rate = 4 / diff(r1))),
  class = c("StratPrior", "list"))
prior2b <- AutoPrior(stratData = stratData2,
                     alignmentScale = "height",
                     sedModel = "p",
                     alphaPosition = alphaPositions,
                     userPriors = NULL)
test_that("AutoPrior() creates the correct priors for stratData2", {
  expect_equal(prior2a, prior2b)
})
