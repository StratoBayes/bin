# Tests for C++ Gibbs sampling (.sb_gibbs) and H/tBy update (.sb_update_htby).
# Validates against R implementations .GibbsSample / .UpdateHtBy.

# ── Setup: create model with initialized state ──────────────────────────────

setup_gibbs_state <- function(sigmaFixed = TRUE) {
  set.seed(8821)
  testData <- .GenerateTestData(
    "multi", version = "gap-names-3-sites-dates"
  )
  sData <- StratData(
    testData$signal, parts = testData$parts,
    ties = testData$ties,
    signalColumn = c("a", "b"), zColumn = "Hight",
    siteColumn = "SIT"
  )

  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = 10, max = 60),
    "alpha_site2" = UniformPrior(min = -10, max = 60),
    "alpha_site3" = UniformPrior(min = -10, max = 60),
    "gammaLog_site1" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site2" = NormalPrior(mean = 1, sd = 1),
    "gammaLog_site3" = NormalPrior(mean = 1, sd = 1),
    "gap_site2_1" = ExponentialPrior(rate = 0.1)
  ), class = c("list", "StratPrior"))

  model <- StratModel(sData, priors,
    alignmentScale = "age",
    sedModel = "site",
    alphaPosition = "bottom",
    sigmaFixed = sigmaFixed
  )
  mcmc <- StratMCMC(model, nIter = 10, nChains = 2)

  # Generate a valid initial state with Gibbs parameters
  state <- .GenerateValidProposal(
    sData, model, mcmc,
    stateOld = NULL,
    ProposeMetro = .MetroPriorSample,
    initialState = TRUE, chain = 1
  )
  state <- .FlexibleKnotsUpdateDB(sData, model, state)
  state <- .InitializeGibbs(sData, model, state)
  state <- .UpdateHtBy(sData, state)

  list(data = sData, model = model, state = state)
}

# ── Extract C++ inputs from R state/model objects ───────────────────────────

extract_gibbs_args <- function(env) {
  data  <- env$data
  model <- env$model
  state <- env$state

  nSignal <- data[["signalAttr"]][["signalN"]]

  # Determine D (penalty matrix)
  if ("spline" %in% names(state)) {
    D <- state[["spline"]][["D"]]
  } else {
    D <- model[["splineBase"]][["D"]]
  }

  # Convert lambda list to vector
  lambda <- vapply(
    seq_len(nSignal),
    function(m) state[["gibbs"]][["lambda"]][[m]],
    numeric(1)
  )

  sigma_fixed <- !isFALSE(model[["sigmaFixed"]])
  sigma_vals <- if (sigma_fixed) {
    as.numeric(model[["sigmaFixed"]])
  } else {
    numeric(nSignal)
  }

  list(
    H_list            = state[["metro"]][["H"]],
    tBy_list          = state[["metro"]][["tBy"]],
    B_list            = state[["metro"]][["B"]],
    signalValuesVec   = data[["signalAttr"]][["signalValuesVec"]],
    sigma             = state[["gibbs"]][["sigma"]],
    lambda            = lambda,
    D                 = D,
    Q_fallback        = state[["gibbs"]][["Q"]],
    aLambda           = model[["priors"]][["gibbs"]][["aLambda"]],
    bLambda           = model[["priors"]][["gibbs"]][["bLambda"]],
    shapeSigma        = model[["priors"]][["gibbs"]][["shapeSigma"]],
    bSigma_prior      = model[["priors"]][["gibbs"]][["bSigma"]],
    numBasis          = model[["splineBase"]][["num_basis"]],
    sigmaIsFixed      = sigma_fixed,
    sigmaFixedValues  = sigma_vals
  )
}

# ── Test: sb_update_htby matches .UpdateHtBy ────────────────────────────────

test_that("sb_update_htby matches R .UpdateHtBy", {
  env <- setup_gibbs_state()
  data  <- env$data
  state <- env$state
  nSignal <- data[["signalAttr"]][["signalN"]]

  cpp_res <- .sb_update_htby(
    B_list           = state[["metro"]][["B"]],
    signalValuesVec  = data[["signalAttr"]][["signalValuesVec"]],
    sigma            = state[["gibbs"]][["sigma"]]
  )

  for (m in seq_len(nSignal)) {
    expect_equal(cpp_res$H[[m]], state[["metro"]][["H"]][[m]],
      tolerance = 1e-10,
      label = paste("H signal", m))
    expect_equal(as.numeric(cpp_res$tBy[[m]]),
      as.numeric(state[["metro"]][["tBy"]][[m]]),
      tolerance = 1e-10,
      label = paste("tBy signal", m))
  }
})

# ── Test: sb_gibbs Q matches R Q (solve) ──────────────────────────────────

test_that("sb_gibbs Q (inverse) matches R .GibbsSample Q", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)

  nSignal <- length(args$H_list)

  for (m in seq_len(nSignal)) {
    lambda_m <- max(args$lambda[m], 1e-10)
    M <- args$H_list[[m]] + lambda_m * args$D
    # R reference: solve() then symmetrise
    Q_r <- solve(M)
    Q_r <- (Q_r + t(Q_r)) / 2

    # C++ via Cholesky
    Q_cpp <- chol2inv(chol(M))
    Q_cpp <- (Q_cpp + t(Q_cpp)) / 2

    expect_equal(Q_cpp, Q_r,
      tolerance = 1e-9,
      label = paste("Q signal", m))
  }
})

# ── Test: sb_gibbs mu matches R mu (Q * tBy) ───────────────────────────────

test_that("sb_gibbs mu (posterior mean) matches R", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)
  nSignal <- length(args$H_list)

  for (m in seq_len(nSignal)) {
    lambda_m <- max(args$lambda[m], 1e-10)
    M <- args$H_list[[m]] + lambda_m * args$D
    # R reference: solve() then symmetrise
    Q_r <- solve(M)
    Q_r <- (Q_r + t(Q_r)) / 2
    mu_r <- as.numeric(Q_r %*% args$tBy_list[[m]])

    # C++ via Cholesky solve
    L <- chol(M)  # upper Cholesky: L'L = M in R convention (t(L) %*% L)
    mu_cpp <- as.numeric(chol2inv(L) %*% args$tBy_list[[m]])

    expect_equal(mu_cpp, mu_r,
      tolerance = 1e-9,
      label = paste("mu signal", m))
  }
})

# ── Test: sb_gibbs returns correct structure ────────────────────────────────

test_that("sb_gibbs returns correct structure", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)
  nSignal <- length(args$H_list)
  p <- args$numBasis

  set.seed(4472)
  res <- do.call(.sb_gibbs, args)

  expect_named(res, c("beta", "lambda", "sigma", "Q"))
  expect_length(res$beta, nSignal)
  expect_length(res$lambda, nSignal)
  expect_length(res$sigma, nSignal)
  expect_length(res$Q, nSignal)

  for (m in seq_len(nSignal)) {
    expect_length(res$beta[[m]], p)
    expect_equal(nrow(res$Q[[m]]), p)
    expect_equal(ncol(res$Q[[m]]), p)
    expect_true(is.finite(res$lambda[m]) && res$lambda[m] > 0)
    expect_true(is.finite(res$sigma[m]) && res$sigma[m] > 0)
  }
})

# ── Test: sb_gibbs Q is symmetric and PD ────────────────────────────────────

test_that("sb_gibbs Q is symmetric positive definite", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)

  set.seed(3917)
  res <- do.call(.sb_gibbs, args)

  for (m in seq_along(res$Q)) {
    Q <- res$Q[[m]]
    expect_equal(Q, t(Q), tolerance = 1e-14,
      label = paste("Q symmetry signal", m))
    eig <- eigen(Q, symmetric = TRUE, only.values = TRUE)$values
    expect_true(all(eig > 0),
      label = paste("Q positive definite signal", m))
  }
})

# ── Test: sb_gibbs lambda update matches R .UpdateLambda ────────────────────

test_that("sb_gibbs lambda update matches R .UpdateLambda", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)
  nSignal <- length(args$H_list)

  # Use a known beta to isolate the lambda update
  set.seed(6123)
  beta_fixed <- lapply(seq_len(nSignal), function(m) rnorm(args$numBasis))
  D <- args$D

  for (m in seq_len(nSignal)) {
    # R reference
    set.seed(7701)
    lambda_r <- .UpdateLambda(
      beta = beta_fixed[[m]],
      D = D,
      aLambda = args$aLambda[m],
      bLambda = args$bLambda[m],
      numBasis = args$numBasis
    )

    # C++ equivalent computation
    set.seed(7701)
    Dbeta <- as.numeric(D %*% beta_fixed[[m]])
    bDb <- sum(Dbeta * beta_fixed[[m]])
    newscale <- 1 / (1 / args$bLambda[m] + 0.5 * bDb)
    shape_lam <- args$aLambda[m] + (args$numBasis - 2) / 2
    lambda_cpp <- rgamma(1, shape = shape_lam, scale = newscale)

    expect_equal(lambda_cpp, lambda_r,
      tolerance = 1e-14,
      label = paste("lambda update signal", m))
  }
})

# ── Test: sb_gibbs sigma update matches R .UpdateSigma ──────────────────────

test_that("sb_gibbs sigma update matches R .UpdateSigma (unfixed)", {
  env <- setup_gibbs_state(sigmaFixed = FALSE)
  args <- extract_gibbs_args(env)
  nSignal <- length(args$H_list)

  set.seed(2288)
  beta_fixed <- lapply(seq_len(nSignal), function(m) rnorm(args$numBasis))

  for (m in seq_len(nSignal)) {
    B <- args$B_list[[m]]
    y <- args$signalValuesVec[[m]]
    splinepred <- as.numeric(B %*% beta_fixed[[m]])
    ssr <- sum((y - splinepred)^2)

    # R reference
    set.seed(5501)
    sigma_r <- sqrt(1 / rgamma(
      1,
      args$shapeSigma[m],
      args$bSigma_prior[m] + 0.5 * ssr
    ))

    # C++ equivalent
    set.seed(5501)
    rate_sig <- args$bSigma_prior[m] + 0.5 * ssr
    sigma_cpp <- sqrt(1 / rgamma(1, shape = args$shapeSigma[m],
                                  scale = 1 / rate_sig))

    expect_equal(sigma_cpp, sigma_r,
      tolerance = 1e-14,
      label = paste("sigma update signal", m))
  }
})

# ── Test: sb_gibbs sigma remains fixed when sigmaIsFixed = TRUE ─────────────

test_that("sb_gibbs preserves fixed sigma", {
  env <- setup_gibbs_state(sigmaFixed = TRUE)
  args <- extract_gibbs_args(env)

  set.seed(9243)
  res <- do.call(.sb_gibbs, args)

  expect_equal(res$sigma, as.numeric(env$model[["sigmaFixed"]]),
    tolerance = 1e-14,
    label = "sigma fixed values preserved")
})

# ── Test: full sb_gibbs vs R .GibbsSample (Q comparison) ────────────────────

test_that("sb_gibbs Q matches R .GibbsSample Q across trials", {
  for (trial in seq_len(5)) {
    env <- setup_gibbs_state()
    args <- extract_gibbs_args(env)
    nSignal <- length(args$H_list)

    set.seed(1000 + trial)
    res <- do.call(.sb_gibbs, args)

    for (m in seq_len(nSignal)) {
      # Compute R reference Q
      lambda_m <- max(args$lambda[m], 1e-10)
      M <- args$H_list[[m]] + lambda_m * args$D
      Q_r <- solve(M)
      Q_r <- (Q_r + t(Q_r)) / 2

      expect_equal(res$Q[[m]], Q_r,
        tolerance = 1e-8,
        label = paste("trial", trial, "signal", m, "Q"))
    }
  }
})

# ── Test: sb_gibbs beta draws have correct mean (statistical) ───────────────

test_that("sb_gibbs beta draws centre on posterior mean", {
  env <- setup_gibbs_state()
  args <- extract_gibbs_args(env)
  nReps <- 500

  m <- 1  # test first signal
  lambda_m <- max(args$lambda[m], 1e-10)
  M <- args$H_list[[m]] + lambda_m * args$D
  Q_r <- solve(M)
  Q_r <- (Q_r + t(Q_r)) / 2
  mu_r <- as.numeric(Q_r %*% args$tBy_list[[m]])

  beta_draws <- matrix(NA_real_, nrow = nReps, ncol = args$numBasis)
  for (i in seq_len(nReps)) {
    set.seed(2000 + i)
    res <- do.call(.sb_gibbs, args)
    beta_draws[i, ] <- res$beta[[m]]
  }

  beta_means <- colMeans(beta_draws)
  beta_sds <- apply(beta_draws, 2, sd)
  # Each mean should be within ~3 SE of the true mean
  se <- beta_sds / sqrt(nReps)
  z_scores <- abs(beta_means - mu_r) / se
  # At most 1 of p coefficients should exceed 3.5 SE
  expect_true(sum(z_scores > 3.5) <= 1,
    label = "beta draws centred on posterior mean")
})

# ── Test: sb_update_htby with sigmaFixed = FALSE model ──────────────────────

test_that("sb_update_htby works with unfixed sigma", {
  env <- setup_gibbs_state(sigmaFixed = FALSE)
  data  <- env$data
  state <- env$state
  nSignal <- data[["signalAttr"]][["signalN"]]

  cpp_res <- .sb_update_htby(
    B_list           = state[["metro"]][["B"]],
    signalValuesVec  = data[["signalAttr"]][["signalValuesVec"]],
    sigma            = state[["gibbs"]][["sigma"]]
  )

  for (m in seq_len(nSignal)) {
    expect_equal(cpp_res$H[[m]], state[["metro"]][["H"]][[m]],
      tolerance = 1e-10,
      label = paste("H signal", m, "unfixed sigma"))
    expect_equal(as.numeric(cpp_res$tBy[[m]]),
      as.numeric(state[["metro"]][["tBy"]][[m]]),
      tolerance = 1e-10,
      label = paste("tBy signal", m, "unfixed sigma"))
  }
})
