# Sources of NA draws (#2072), the unclamped -Inf log-posterior they start from
# (#1594), and the custom-prior gradient at a support edge (#1852).
#
# A huge `aLambda` drives the Gibbs lambda draw so high that the β-marginal's
# conditioning gate fails, so `signal_logmarginal` returns -Inf after the sweep.
# That is the degenerate-but-in-support state each fix below is about.

.Nan2072Priors <- function() {
  e <- new.env()
  utils::data("stratModel1", package = "StratoBayes", envir = e)
  e$stratModel1$priors$metro
}

.Nan2072Model <- function(priors = .Nan2072Priors(), aLambda = 1e9) {
  e <- new.env()
  utils::data("stratData1", package = "StratoBayes", envir = e)
  list(data = e$stratData1,
       model = suppressWarnings(StratModel(
         e$stratData1, priors = priors, alignmentScale = "height",
         sedModel = "site", flexibleKnots = FALSE, knotRange = c(-5, 12),
         aLambda = aLambda
       )))
}

.Nan2072CustomPriors <- function(min, max) {
  priors <- .Nan2072Priors()
  # Wrapped so the prior is not recognised as the built-in UniformPrior.
  priors[["alpha_site_2"]] <- Prior(
    R = function(n, min, max) stats::runif(n, min, max),
    D = function(x, min, max, log = FALSE) stats::dunif(x, min, max, log = log),
    Q = function(p, min, max) stats::qunif(p, min, max),
    min = min, max = max
  )
  priors
}

# An engine whose every iteration makes one `proposal` move. StratModel()
# estimates sigma by MCMC, so it is seeded too.
.Nan2072Engine <- function(fx, proposal, state = NULL, seed = 1L,
                           ties = NULL, gradientArgs = list()) {
  model <- fx$model
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  gradient <- proposal %in% c("NUTS", "HMC")
  mcmc <- suppressWarnings(StratMCMC(
    model, nIter = 10, nChains = 1, tempering = FALSE, nThreads = 1L,
    gradientProposals = if (gradient) "on" else "off"
  ))
  probability <- mcmc[[c("metro", "proposalProbability")]]
  slot <- if (gradient) which(colnames(probability) == "NUTS") else
    which(colnames(probability) == proposal)
  if (proposal == "HMC") {
    names(mcmc$propose)[slot] <- "HMC"
    colnames(probability)[slot] <- "HMC"
    weights <- mcmc[[c("metro", "proposalProbabilityWeights")]]
    if (!is.null(colnames(weights))) colnames(weights)[slot] <- "HMC"
    mcmc[[c("metro", "proposalProbabilityWeights")]] <- weights
  }
  if (gradient) {
    args <- if (proposal == "HMC") .HMCDefaultArgs(model) else
      .NUTSDefaultArgs(model)
    args$adaptStepSize <- FALSE
    args[names(gradientArgs)] <- gradientArgs
    mcmc$metro$proposalArgs[[1]][[slot]] <- args
  }
  probability[, ] <- 0
  probability[, slot] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- probability
  set.seed(seed)
  if (is.null(state)) {
    state <- .GenerateInitialState(fx$data, model, mcmc, 1L)
  }
  .sb_create_engine(data = fx$data, model = .SafeModelCallbacks(model),
                    mcmc = mcmc, state = list(state), tiesCallback = ties)
}

.Nan2072Metro <- function(engine) .sb_extract_metro(engine)[[1]]$metro

test_that(paste0("a zero-density proposal is never accepted from a degenerate ",
                 "state (#2072)"), {
            skip_on_cran()
            # A custom prior's support is known only to its density, so a
            # proposal outside it passes the engine's bound checks and is scored
            # at the -1e30 sentinel with its likelihood components NA. From a
            # state whose own log-posterior is degenerate (-Inf, or the -1e30 it
            # is clamped to) the MH step accepted it, and its NA components were
            # saved.
            set.seed(2072)
            fx <- .Nan2072Model(.Nan2072CustomPriors(0, 2), aLambda = 1)
            expect_identical(.PrepareLogPostArgs(fx$model)$priorTypes[[1]], "")

            warm <- .Nan2072Engine(fx, "SiteBlock")
            .sb_run_block(warm, 1L)
            state <- .sb_extract_state(warm)[[1]]
            state$metro$parameters[[1]] <- 1.999
            # Degenerate β-marginal on import: the first MH step reads it as the
            # old side.
            state$gibbs$lambda[] <- 1e15

            steps <- lapply(1:20, function(seed) {
              engine <- .Nan2072Engine(fx, "SiteBlock", state = state,
                                       seed = seed)
              .sb_run_block(engine, 1L)
              .Nan2072Metro(engine)
            })
            # Precondition: some proposals were scored at the sentinel.
            expect_true(any(vapply(steps, `[[`, 0, "logPostNew") <= -1e30))
            alpha <- vapply(steps, function(x) x$parameters[[1]], 0)
            expect_true(all(alpha >= 0 & alpha <= 2))
            expect_false(anyNA(unlist(lapply(steps, `[[`, "logPostSep"))))
          })

test_that("the R engine never accepts a zero-density proposal either (#2072)", {
  skip_on_cran()
  # Base MH acceptance is Tier 1 (docs/r-engine-contract.md): R must make the
  # same decision. .LogPost scores a custom prior's out-of-support point at
  # the -1e30 sentinel too, and R has no bound pre-screen at all.
  set.seed(2072)
  fx <- .Nan2072Model(.Nan2072CustomPriors(0, 2), aLambda = 1)
  model <- fx$model
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  mcmc <- suppressWarnings(StratMCMC(
    model, nIter = 10, nChains = 1, tempering = FALSE, nThreads = 1L,
    gradientProposals = "off"
  ))
  probability <- mcmc[[c("metro", "proposalProbability")]]
  probability[, ] <- 0
  probability[, "SiteBlock"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- probability
  mcmc$currentIter <- 1L
  state <- .GenerateInitialState(fx$data, model, mcmc, 1L)
  state$metro$parameters[[1]] <- 1.999
  state$metro$logPost <- -1e30

  steps <- lapply(1:20, function(seed) {
    set.seed(seed)
    .UpdateState(fx$data, model, mcmc, state, 1L)$metro
  })
  expect_true(any(vapply(steps, `[[`, 0, "logPostNew") <= -1e30))
  alpha <- vapply(steps, function(x) x$parameters[[1]], 0)
  expect_true(all(alpha >= 0 & alpha <= 2))
  expect_false(anyNA(unlist(lapply(steps, `[[`, "logPostSep"))))
})

for (.proposal in c("NUTS", "HMC")) local({
  proposal <- .proposal
  test_that(paste(proposal, "accept path clamps a -Inf marginal (#1594)"), {
    skip_on_cran()
    set.seed(2072)
    engine <- .Nan2072Engine(.Nan2072Model(aLambda = 1e12), proposal)
    steps <- lapply(1:40, function(i) {
      .sb_run_block(engine, 1L)
      .Nan2072Metro(engine)
    })
    # Precondition: the huge aLambda did make the β-marginal -Inf.
    expect_true(any(vapply(steps, function(x) x$logPostSep[[2]], 0) == -Inf))
    # The reject path always clamped; the accept path stored the raw -Inf,
    # which the next MH step reads as "accept anything".
    expect_false(any(vapply(steps, `[[`, 0, "logPost") == -Inf))
  })
})

test_that("partial tempering clamps a -Inf old-side energy (#1594)", {
  skip_on_cran()
  # The clamp is on the scalar logPost; the partial branch assembles its old
  # energy from the components, where the β-marginal is still -Inf, so every
  # proposal was accepted, however degenerate.
  set.seed(2072)
  fx <- .Nan2072Model(aLambda = 1)
  warm <- .Nan2072Engine(fx, "SiteBlock")
  .sb_run_block(warm, 1L)
  state <- .sb_extract_state(warm)[[1]]
  state$gibbs$lambda[] <- 1e15

  model <- fx$model
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  mcmc <- suppressWarnings(StratMCMC(
    model, nIter = 10, nChains = 2, tempering = TRUE, nThreads = 1L,
    temperingComponents = "signal", gradientProposals = "off"
  ))
  probability <- mcmc[[c("metro", "proposalProbability")]]
  probability[, ] <- 0
  probability[, "SiteBlock"] <- 1
  mcmc[[c("metro", "proposalProbability")]] <- probability
  steps <- lapply(1:10, function(seed) {
    set.seed(seed)
    engine <- .sb_create_engine(data = fx$data, model = model, mcmc = mcmc,
                                state = list(state, state), tiesCallback = NULL)
    .sb_run_block(engine, 1L)
    .Nan2072Metro(engine)
  })
  newSide <- vapply(steps, `[[`, 0, "logPostNew")
  accepted <- vapply(steps, function(x) isTRUE(x$accept), TRUE)
  # Precondition: the proposals themselves had a -Inf β-marginal.
  expect_true(any(newSide == -Inf))
  expect_false(any(accepted & newSide == -Inf))
})

test_that("NUTS and HMC never accept an endpoint of zero density (#2072)", {
  skip_on_cran()
  # From a current state whose joint log-posterior is the -1e30 sentinel (here
  # a violated tie), an out-of-support leaf scores -1e30 too; the difference
  # absorbs to 0, so the endpoint was selected on kinetic energy alone and
  # saved with NA likelihood components.
  e <- new.env()
  utils::data("stratData2", package = "StratoBayes", envir = e)
  data <- e$stratData2
  set.seed(1)
  base <- suppressWarnings(StratModel(
    data, alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-2000, 2000)
  ))
  priors <- base$priors$metro
  priors[["gammaLog_site2"]] <- Prior(
    R = function(n, min, max) stats::runif(n, min, max),
    D = function(x, min, max, log = FALSE) stats::dunif(x, min, max, log = log),
    Q = function(p, min, max) stats::qunif(p, min, max),
    min = -0.1, max = 0.1
  )
  set.seed(1)
  model <- suppressWarnings(StratModel(
    data, priors = priors, alignmentScale = "height", sedModel = "site",
    flexibleKnots = FALSE, knotRange = c(-2000, 2000)
  ))
  model$.logpost_cpp <- .PrepareLogPostArgs(model)
  model$.tiesDispatch <- .BuildTiesDispatch(data, model)
  fx <- list(data = data, model = model)
  names <- names(model$priors$metro)
  tiesCallback <- .SafeCallback(.MakeTiesCallback(data, model), "ties")

  warm <- .Nan2072Engine(fx, "SiteBlock", ties = tiesCallback)
  .sb_run_block(warm, 5L)
  state <- .sb_extract_state(warm)[[1]]
  params <- state$metro$parameters
  params[[which(names == "gammaLog_site2")]] <- 0.0999
  params[[which(names == "alpha_site3")]] <- -50
  sep <- .sb_eval_logpost(warm, 1L, unlist(params), debug = TRUE)$logPostSep
  # Precondition: in prior support, but the tie term is the sentinel.
  expect_gt(sep[[1]], -1e30)
  expect_lte(sep[[3]], -1e30)
  state$metro$parameters <- params

  # A single short HMC step keeps the kinetic energy change small enough for
  # the absorbed ratio to accept.
  gradientArgs <- list(NUTS = list(), HMC = list(stepSize = 1e-3, nSteps = 1L))
  RunSteps <- function(proposal, state) {
    lapply(1:15, function(seed) {
      engine <- .Nan2072Engine(fx, proposal, state = state, seed = seed,
                               ties = tiesCallback,
                               gradientArgs = gradientArgs[[proposal]])
      .sb_run_block(engine, 1L)
      .Nan2072Metro(engine)
    })
  }
  # Far from the prior's edge, the same violated tie must not strand the
  # gradient moves: only zero PRIOR density is pinned, as in the MH step.
  inside <- state
  inside$metro$parameters[[which(names == "gammaLog_site2")]] <- 0
  for (proposal in c("NUTS", "HMC")) {
    steps <- RunSteps(proposal, state)
    gamma <- vapply(steps, function(x) {
      x$parameters[[which(names == "gammaLog_site2")]]
    }, 0)
    expect_true(all(abs(gamma) <= 0.1), label = proposal)
    expect_false(anyNA(unlist(lapply(steps, `[[`, "logPostSep"))),
                 label = proposal)

    accepted <- vapply(RunSteps(proposal, inside), function(x) {
      isTRUE(x$accept)
    }, logical(1))
    expect_true(any(accepted), label = proposal)
  }
})

test_that("state import clamps a -Inf marginal (#1594)", {
  skip_on_cran()
  set.seed(2072)
  fx <- .Nan2072Model(aLambda = 1)
  td <- tempfile("nan2072_")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(suppressMessages(RunStratModel(
    fx$data, fx$model, nIter = 20, nChains = 1, seed = 1, quiet = TRUE,
    visualise = FALSE, modelDir = td, modelName = "nan", nThreads = 1L,
    convergenceStop = FALSE
  )))
  mcmc <- readRDS(file.path(td, "nan_mcmc_run_1.rds"))
  model <- result$model
  if (is.null(model$.logpost_cpp)) model$.logpost_cpp <-
    .PrepareLogPostArgs(model)

  ImportedLogPost <- function(lambda) {
    state <- mcmc$recentState
    state[[1]]$gibbs$lambda[] <- lambda
    engine <- .sb_create_engine(data = result$data, model = model, mcmc = mcmc,
                                state = state, tiesCallback = NULL)
    .sb_extract_metro(engine)[[1]]$metro
  }
  healthy <- ImportedLogPost(1)
  expect_true(is.finite(healthy$logPost))

  degenerate <- ImportedLogPost(1e15)
  expect_identical(degenerate$logPostSep[[2]], -Inf)
  expect_identical(degenerate$logPost, -1e30)
})

test_that(paste0("custom-prior FD gradient is finite within one step of its ",
                 "support edge (#1852)"), {
            skip_on_cran()
            set.seed(2072)
            fx <- .Nan2072Model(.Nan2072CustomPriors(0, 2), aLambda = 1)
            engine <- .Nan2072Engine(fx, "SiteBlock")
            .sb_run_block(engine, 1L)
            params <- .Nan2072Metro(engine)$parameters

            interior <- .sb_gradient_at(engine, 1L, params)
            expect_true(interior$ok)
            expect_true(all(is.finite(interior$grad)))

            # The FD step is 1e-6 * max(1, |x|): half a step inside the upper
            # bound puts x + h outside the support, where the density's log is
            # -Inf.
            params[[1]] <- 2 - 0.5e-6 * 2
            atEdge <- .sb_gradient_at(engine, 1L, params)
            expect_true(atEdge$ok)
            expect_true(all(is.finite(atEdge$grad)))
          })

test_that(paste0("custom-tie FD gradient is finite within one step of its ",
                 "support edge (#1852)"), {
            skip_on_cran()
            e <- new.env()
            utils::data("signalData2", "tiesData2", "partsData2", "stratPrior2",
                        package = "StratoBayes", envir = e)
            # A density C++ does not evaluate natively, so the tie goes through
            # the per-tie R callback and its gradient through finite
            # differences.
            ties <- e$tiesData2
            ties$densityFun[1] <- "dlogis"
            data <- StratData(e$signalData2, parts = e$partsData2, ties = ties,
                              signalColumn = c("a", "b"), zColumn = "height",
                              siteColumn = "site")
            set.seed(2072)
            model <- suppressWarnings(StratModel(
              data, priors = e$stratPrior2, alignmentScale = "age",
              sedModel = "site",
              alphaPosition = c("top", "middle", "bottom"),
              flexibleKnots = FALSE,
              knotRange = c(0, 100), sigmaFixed = TRUE
            ))
            model$.logpost_cpp <- .PrepareLogPostArgs(model)
            model$.tiesDispatch <- .BuildTiesDispatch(data, model)
            mcmc <- suppressWarnings(StratMCMC(model, nIter = 10, nChains = 1,
                                               tempering = FALSE,
                                               nThreads = 1L))
            set.seed(1)
            state <- .GenerateInitialState(data, model, mcmc, 1L)

            # The first tie's log-density, truncated above `edge`; the rest
            # unchanged.
            edge <- new.env()
            edge$at <- Inf
            edge$ages <- numeric(0)
            dispatch <- model$.tiesDispatch$dispatch
            callback <- function(arg) {
              spec <- dispatch[[arg$site]][[arg$tie]]
              if (is.null(spec) || !spec$active) return(0)
              first <- arg$site == 1 && arg$tie == 1
              if (first) edge$ages <- c(edge$ages, arg$age)
              if (first && arg$age > edge$at) return(-Inf)
              spec$args$x <- arg$age
              do.call(spec$fn, spec$args)
            }
            engine <- .sb_create_engine(data = data, model = model, mcmc = mcmc,
                                        state = list(state),
                                        tiesCallback = callback)
            interior <- .sb_compute_gradient(engine, 1L)
            expect_true(all(is.finite(interior$grad)))
            # Precondition: the first tie is evaluated by finite differences, at
            # x +/- h.
            steps <- range(edge$ages)
            expect_gt(diff(steps), 0)

            # Put the edge between x and x + h, so only the forward step leaves
            # support.
            edge$at <- mean(steps) + diff(steps) / 4
            atEdge <- .sb_compute_gradient(engine, 1L)
            expect_true(all(is.finite(atEdge$grad)))
          })
