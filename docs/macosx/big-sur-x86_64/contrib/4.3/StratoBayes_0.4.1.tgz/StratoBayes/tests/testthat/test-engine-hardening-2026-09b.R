# ── #2241: NeighbourScaled SDs break ties as R's stable order() does ─────────

test_that("C++ neighbour-scaled SDs match R on tied groups larger than 16", {
  nParam <- 30L
  params <- rep(c(1, 1, 1, 2, 2, 5), length.out = nParam)
  fallback <- seq_len(nParam) / 10
  for (n in c(17L, 20L, nParam)) {
    idx <- seq_len(n)
    model <- list(ind = list(alpha = idx, gamma = integer(0)))
    expect_identical(
      StratoBayes:::.sb_neighbour_scaled_sds_cpp(params, fallback, idx - 1L,
                                                 integer(0)),
      StratoBayes:::.NeighbourScaledSDs(params, fallback, model)
    )
  }
})

test_that("C++ neighbour-scaled SDs sort NaN last, as order() does", {
  params <- c(3, NaN, 1, 2, NaN, 1, 4)
  fallback <- rep(1, length(params))
  idx <- seq_along(params)
  model <- list(ind = list(alpha = idx, gamma = integer(0)))
  expect_identical(
    StratoBayes:::.sb_neighbour_scaled_sds_cpp(params, fallback, idx - 1L,
                                               integer(0)),
    StratoBayes:::.NeighbourScaledSDs(params, fallback, model)
  )
})

# ── #2242: no pool claim crosses a dispatch boundary ─────────────────────────

test_that("threaded tempering with more chains than workers matches serial", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  # Pins thread-count invariance on the queued, tempered path; x86 timing
  # cannot expose the race itself, so this is not a race detector.
  Samples <- function(nThreads) {
    set.seed(2242L)
    mc <- StratMCMC(stratModel1, nIter = 400L, nChains = 5L, nThin = 1L,
                    nThreads = nThreads, tempering = TRUE,
                    adaptProposal = FALSE, adaptTemperatures = FALSE)
    RunStratModel(stratData1, stratModel1, mc, nRun = 1L,
                  runParallel = FALSE, visualise = FALSE, quiet = TRUE,
                  seed = 2242L)$samples
  }
  expect_identical(Samples(2L), Samples(1L))
})

# ── #2243 item 2: .sb_bulk_history_update bounds its write indices ───────────

BulkHistoryArgs <- function() {
  nCols <- 3L
  list(
    historyData = list(list(
      count = 1L,
      parameters = matrix(c(0.5, 0.25), nrow = 1L),
      logPost = -1,
      accept = TRUE,
      proposalNumber = 1L
    )),
    chains = 1L,
    chainHistory = list(matrix(NA_real_, nrow = 4L, ncol = nCols)),
    historySize = 0L,
    historyRingPos = 1L,
    historyStamp = list(rep(NA_integer_, 4L)),
    historyStampNext = 1L,
    acceptance = array(NA_real_, dim = c(1L, 2L, 1L)),
    acceptanceIndex = matrix(1L, nrow = 1L, ncol = 1L),
    historyLength = 4L,
    acceptanceLength = 2L,
    skipCol0 = 2L,
    nHeights = 0L,
    useRingBuffer = TRUE,
    inLateAdaptation = FALSE
  )
}

test_that(".sb_bulk_history_update rejects an out-of-range acceptanceIndex", {
  args <- BulkHistoryArgs()
  expect_no_error(do.call(StratoBayes:::.sb_bulk_history_update, args))

  for (bad in list(0L, 3L, NA_integer_, 1e6)) {
    args[["acceptanceIndex"]][1, 1] <- bad
    expect_error(
      do.call(StratoBayes:::.sb_bulk_history_update, args),
      "acceptanceIndex.*outside"
    )
  }
})

test_that(".sb_bulk_history_update checks the stamp buffers' shapes", {
  args <- BulkHistoryArgs()
  args[["historyStampNext"]] <- integer(0)
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "historyStampNext"
  )

  args <- BulkHistoryArgs()
  args["historyStampNext"] <- list(NULL)
  expect_no_error(do.call(StratoBayes:::.sb_bulk_history_update, args))

  args <- BulkHistoryArgs()
  args[["historyStamp"]] <- list()
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "historyStamp. must be a list"
  )
  args[["historyStamp"]] <- rep(1, 4L)
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "historyStamp. must be a list"
  )
})

# ── #2243 item 3: a NULL chain entry in proposalArgs is an error ─────────────

test_that(".sb_update_proposals refuses a NULL chain entry", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  td <- withr::local_tempdir()
  RunStratModel(stratData1, stratModel1, nIter = 10L, nChains = 2L,
                nThreads = 1L, nRun = 1L, runParallel = FALSE,
                visualise = FALSE, quiet = TRUE, seed = 1L,
                modelDir = td, modelName = "nullArgs")
  mcmc <- readRDS(file.path(td, "nullArgs_mcmc_run_1.rds"))
  model <- stratModel1
  if (is.null(model[[".logpost_cpp"]])) {
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  eng <- StratoBayes:::.sb_create_engine(stratData1, model, mcmc,
                                         mcmc[["recentState"]])
  metro <- mcmc[["metro"]]
  args <- metro[["proposalArgs"]]
  expect_no_error(StratoBayes:::.sb_update_proposals(
    eng, args, metro[["proposalFactor"]], metro[["proposalProbability"]]
  ))

  args[2L] <- list(NULL)
  expect_error(
    StratoBayes:::.sb_update_proposals(
      eng, args, metro[["proposalFactor"]], metro[["proposalProbability"]]
    ),
    "proposalArgs\\[\\[2\\]\\] is NULL"
  )
})

test_that(".sb_bulk_history_update checks chains and history vector types", {
  args <- BulkHistoryArgs()
  args[["chains"]] <- NA_integer_
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "chains. contains an index outside"
  )

  args <- BulkHistoryArgs()
  args[["historyData"]][[1]][["logPost"]] <- "a"
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "must be numeric or logical"
  )
  args <- BulkHistoryArgs()
  args[["historyData"]][[1]][["accept"]] <- list(TRUE)
  expect_error(
    do.call(StratoBayes:::.sb_bulk_history_update, args),
    "must be numeric or logical"
  )
})
