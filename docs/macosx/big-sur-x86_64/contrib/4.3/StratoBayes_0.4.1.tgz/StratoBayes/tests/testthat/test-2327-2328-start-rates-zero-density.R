.VagueRateModel <- function() {
  e <- new.env()
  utils::data("stratData1", package = "StratoBayes", envir = e)
  data <- e$stratData1
  base <- suppressWarnings(StratModel(
    data, alignmentScale = "height", sedModel = "site"
  ))
  priors <- base$priors$metro
  for (nm in grep("^gammaLog", names(priors), value = TRUE)) {
    priors[[nm]] <- NormalPrior(0, 10)
  }
  model <- suppressWarnings(StratModel(
    data, priors = priors, alignmentScale = "height", sedModel = "site"
  ))
  list(data = data, model = model)
}

test_that("an out-of-range automatic start retries from the prior (#2327)", {
  skip_on_cran()
  withr::local_options(mc.cores = 2L)
  fx <- .VagueRateModel()
  model <- fx$model
  ratesRange <- unlist(model$proposeChecks[c("ratesMin", "ratesMax")])
  expect_equal(unname(ratesRange), c(-14, 14))

  # A NormalPrior(0, 10) log-rate falls outside the default ratesRange with
  # probability 0.16, so across 24 automatic starts some are out of range.
  set.seed(2327)
  autoRates <- unlist(replicate(24, .AutoParametersInitial(model)[
    model$indRates
  ], simplify = FALSE))
  expect_true(any(autoRates < ratesRange[[1]] | autoRates > ratesRange[[2]]))

  set.seed(2327)
  for (i in 1:6) {
    mcmc <- suppressWarnings(StratMCMC(model, nIter = 10, nChains = 4,
                                       tempering = FALSE, nThreads = 2L))
    for (chain in 1:4) {
      state <- suppressWarnings(
        .GenerateInitialState(fx$data, model, mcmc, chain)
      )
      rates <- state$metro$parameters[model$indRates]
      expect_true(all(rates >= ratesRange[[1]] & rates <= ratesRange[[2]]))
    }
  }

  # Seed 7 stopped this run before the fix.
  td <- withr::local_tempdir("sb2327_")
  set.seed(7)
  result <- suppressWarnings(suppressMessages(RunStratModel(
    fx$data, model, nIter = 20, nChains = 4, nThreads = 2L,
    runParallel = FALSE, quiet = TRUE, visualise = FALSE, modelDir = td,
    modelName = "sb2327", convergenceStop = FALSE
  )))
  expect_s3_class(result, "StratPosterior")
})

test_that("a user-supplied out-of-range start still stops (#2327)", {
  skip_on_cran()
  fx <- .VagueRateModel()
  model <- fx$model
  set.seed(2327)
  mcmc <- suppressWarnings(StratMCMC(model, nIter = 10, nChains = 1,
                                     tempering = FALSE, nThreads = 1L))
  # StratMCMC() refuses such a start, so place it directly, as a legacy or
  # hand-edited object would carry it.
  start <- .MetroPriorSample(1L, model)
  start[model$indRates[[1]]] <- 20
  mcmc$metro$parametersInitial <- start
  for (flag in list(TRUE, NULL)) {
    mcmc$metro["parametersInitialUserProvided"] <- list(flag)
    expect_error(
      suppressWarnings(.GenerateInitialState(fx$data, model, mcmc, 1L)),
      "inside the permitted range"
    )
  }
})

test_that("R-engine NUTS and HMC never accept zero prior density (#2328)", {
  skip_on_cran()
  # From a start whose joint log-posterior is the -1e30 sentinel (a violated
  # tie), an out-of-support leaf scores -1e30 too, so the difference absorbs
  # to 0.
  e <- new.env()
  utils::data("stratData2", package = "StratoBayes", envir = e)
  data <- e$stratData2
  set.seed(1)
  base <- suppressWarnings(StratModel(
    data, alignmentScale = "height", sedModel = "site", flexibleKnots = FALSE,
    knotRange = c(-2000, 2000)
  ))
  priors <- base$priors$metro
  priors[["gammaLog_site2"]] <- Prior(
    R = function(n, min, max) stats::runif(n, min, max),
    D = function(x, min, max, log = FALSE) stats::dunif(x, min, max, log = log),
    Q = function(p, min, max) stats::qunif(p, min, max),
    min = -0.1, max = 0.1
  )
  set.seed(1)
  model <- suppressWarnings(StratModel(
    data, priors = priors, alignmentScale = "height", sedModel = "site",
    flexibleKnots = FALSE, knotRange = c(-2000, 2000)
  ))
  td <- withr::local_tempdir("sb2328_")
  set.seed(1)
  result <- suppressWarnings(suppressMessages(RunStratModel(
    data, model, gradientProposals = "on", engine = "R", nIter = 5,
    nChains = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "sb2328", convergenceStop = FALSE
  )))
  mcmc <- readRDS(file.path(td, "sb2328_mcmc_run_1.rds"))
  model <- result$model
  if (is.null(model$.logpost_cpp)) model$.logpost_cpp <-
    .PrepareLogPostArgs(model)
  paramNames <- model$parametersNames
  slot <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))[[1]]

  state <- mcmc$recentState[[1]]
  state$metro$parameters[[which(paramNames == "gammaLog_site2")]] <- 0.0999
  state$metro$parameters[[which(paramNames == "alpha_site3")]] <- -50
  engine <- .HMCCreateEngine(result$data, model, state)
  sep <- .sb_eval_logpost(engine, 1L, state$metro$parameters,
                          debug = TRUE)$logPostSep
  # Precondition: in prior support, but the tie term is the sentinel.
  expect_gt(sep[[1]], -1e30)
  expect_lte(sep[[3]], -1e30)

  Steps <- function(proposal, state) {
    args <- if (proposal == "HMC") .HMCDefaultArgs(model) else
      .NUTSDefaultArgs(model)
    args$adaptStepSize <- FALSE
    if (proposal == "HMC") {
      args$stepSize <- 1e-3
      args$nSteps <- 1L
    }
    mcmc$metro$proposalArgs[[1]][[slot]] <- args
    Update <- if (proposal == "HMC") .UpdateStateHMC else .UpdateStateNUTS
    lapply(1:15, function(seed) {
      set.seed(seed)
      suppressWarnings(Update(result$data, model, mcmc, state, chain = 1L,
                              proposalNumber = slot))$metro
    })
  }
  inside <- state
  inside$metro$parameters[[which(paramNames == "gammaLog_site2")]] <- 0
  for (proposal in c("NUTS", "HMC")) {
    steps <- Steps(proposal, state)
    gamma <- vapply(steps, function(x) {
      x$parameters[[which(paramNames == "gammaLog_site2")]]
    }, 0)
    expect_true(all(abs(gamma) <= 0.1), label = proposal)
    expect_false(anyNA(unlist(lapply(steps, `[[`, "logPostSep"))),
                 label = proposal)

    # Only zero PRIOR density is pinned: the same violated tie far from the
    # prior's edge must not strand the gradient moves.
    accepted <- vapply(Steps(proposal, inside), function(x) {
      isTRUE(x$accept)
    }, logical(1))
    expect_true(any(accepted), label = proposal)
  }
})
