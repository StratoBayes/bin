# The overlap-penalty taper follows the sedSmooth formations (#1930, #1932,
# #1936); alphaPosition and AutoPrior() ignore rows with no signal (#2016).

TaperBySite <- function(data, weights, signal) {
  sites <- data[["sites"]]
  n <- vapply(sites, function(s) {
    length(SignalLookUp(data, "height", s, signal = signal,
                        includeNAsignal = FALSE))
  }, integer(1))
  split(weights, factor(rep(sites, n), levels = sites))
}

HeightsBySite <- function(data, signal) {
  lapply(setNames(data[["sites"]], data[["sites"]]), function(s) {
    SignalLookUp(data, "height", s, signal = signal, includeNAsignal = FALSE)
  })
}

test_that("site 1 on the height scale is untapered (#1932)", {
  info <- .SetupSedSmooth(stratData2, "height", 6L)
  w <- .ComputeOverlapTaperWeights(stratData2, info, taperFraction = 0.15)
  for (m in seq_along(w)) {
    sig <- stratData2[[c("signalAttr", "signalNames")]][[m]]
    expect_true(all(TaperBySite(stratData2, w[[m]], sig)[[1]] == 1))
  }
})

test_that("interior formation edges are tapered (#1930)", {
  info <- .SetupSedSmooth(stratData2, "height", 6L)
  w <- .ComputeOverlapTaperWeights(stratData2, info, taperFraction = 0.15)
  # Signal "b" samples site 2 on both sides of 10.5 and just below 20
  sig <- stratData2[[c("signalAttr", "signalNames")]][[2]]
  w2 <- TaperBySite(stratData2, w[[2]], sig)[[2]]
  h2 <- HeightsBySite(stratData2, sig)[[2]]

  # Site 2's middle formation, [10.5, 20], has only interior edges
  width <- 0.15 * (20 - 10.5)
  nearEdge <- (h2 >= 10.5 & h2 < 10.5 + width) | (h2 < 20 & h2 > 20 - width)
  expect_gt(sum(nearEdge), 0)
  expect_true(all(w2[nearEdge] < 1))
  expect_equal(w2[nearEdge],
               pmin(h2[nearEdge] - 10.5, 20 - h2[nearEdge]) / width)
})

test_that("StratModel() stores the formation taper (#1930, #1932)", {
  m <- StratModel(stratData1, alignmentScale = "height",
                  sedModel = "site, partition",
                  priors = AutoPrior(stratData1, "height"), sedSmooth = TRUE)
  info <- .SetupSedSmooth(stratData1, "height", 6L)
  expect_equal(m[[c("overlapPenalty", "weights")]],
               .ComputeOverlapTaperWeights(stratData1, info, 0.15))
})

test_that("the taper anchors to the declared partition top (#1936)", {
  signal <- data.frame(
    site = c(rep("s1", 11), "s2", "s2"),
    height = c(0:10, 0, 10),
    value = c(sin(0:10), 0.1, 0.9)
  )
  parts <- data.frame(site = c("s1", "s2"), height = c(10, 20),
                      partition = c("a", "a"))
  d <- StratData(signal = signal, parts = parts)
  info <- .SetupSedSmooth(d, "height", 6L)
  w <- .ComputeOverlapTaperWeights(d, info, taperFraction = 0.15)
  w2 <- TaperBySite(d, w[[1]], d[[c("signalAttr", "signalNames")]])[[2]]

  # The bottom partition's lower bound is the site's lowest datum, so the
  # sample there sits on a formation edge; the top sample lies well inside
  # the declared [0, 20] formation.
  expect_equal(w2, c(0, 1))
})

AlphaPriors <- function(priors) {
  unclass(priors)[startsWith(names(priors), "alpha_")]
}

test_that("alphaPosition ignores rows with no signal value (#2016)", {
  site2 <- unique(signalData1[["site"]])[[2]]
  padded <- rbind(signalData1,
                  data.frame(height = 100, site = site2, value = NA))
  clean <- StratData(signalData1)
  withNA <- StratData(padded)
  expect_equal(max(SignalLookUp(withNA, "height", 2)), 100)

  for (pos in c("top", "middle", "bottom")) {
    expect_equal(.MatchAlphaPosition(pos, withNA, "height"),
                 .MatchAlphaPosition(pos, clean, "height"))
    expect_equal(AlphaPriors(AutoPrior(withNA, alphaPosition = pos)),
                 AlphaPriors(AutoPrior(clean, alphaPosition = pos)))
  }
  expect_equal(AlphaPriors(AutoPrior(withNA, alphaPosition = NULL)),
               AlphaPriors(AutoPrior(clean, alphaPosition = NULL)))
  expect_equal(
    StratModel(withNA, priors = NULL, alignmentScale = "height",
               sedModel = "site", nKnots = 5)[["alphaPosition"]],
    StratModel(clean, priors = NULL, alignmentScale = "height",
               sedModel = "site", nKnots = 5)[["alphaPosition"]]
  )
})
