MakeSplineModel <- function(data, xMin = NULL, xMax = NULL) {
  .ModelBspline(
    data, nKnots = 6, knots = NULL, aSigma = 0.01, bSigma = 0.01,
    aLambda = 1, bLambda = 1000, lambdaInitial = NULL, lambdaFixed = FALSE,
    xMin = xMin, xMax = xMax
  )
}

test_that("sigma0 seed smooths on the model's own knots (#1745)", {
  set.seed(1745)
  data <- data.frame(x = seq(0, 10, length.out = 40))
  data[["y"]] <- sin(data[["x"]]) + rnorm(40, sd = 0.2)
  expected <- function(model, knots) {
    stats::smooth.spline(
      data[["x"]], data[["y"]], df = 4,
      lambda = model[[c("initialValues", "lambdaTune")]],
      all.knots = (knots - 0) / 10
    )[[c("fit", "coef")]]
  }

  wide <- MakeSplineModel(data, xMin = -5, xMax = 15)
  widened <- .InitializeGibbsBspline(data, wide)
  expect_equal(widened[[c("gibbs", "beta")]],
               expected(wide, wide[[c("splineBase", "knots")]]))

  custom <- .ModelBspline(
    data, nKnots = 6, knots = c(-1, 2, 3, 6, 9, 12), aSigma = 0.01,
    bSigma = 0.01, aLambda = 1, bLambda = 1000, lambdaInitial = NULL,
    lambdaFixed = FALSE, xMin = NULL, xMax = NULL
  )
  expect_equal(.InitializeGibbsBspline(data, custom)[[c("gibbs", "beta")]],
               expected(custom, custom[[c("splineBase", "knots")]]))
})

test_that("BayesianSpline() returns an object of class BayesianSpline (#1832)", {
  set.seed(1832)
  x <- seq(0, 4, length.out = 30)
  fit <- BayesianSpline(x, sin(x) + rnorm(30, sd = 0.1), nKnots = 5,
                        nIter = 40)
  expect_s3_class(fit, "BayesianSpline")
  expect_true(is.list(fit))
  expect_false(inherits(fit[[c("model", "splineBase")]], "BayesianSpline"))
  expect_identical(nrow(PredictSpline(fit, burnIn = 0.5)), 5L)
})

test_that("PredictSpline() gives NA quantiles for a non-finite draw (#1468)", {
  set.seed(1468)
  x <- seq(0, 4, length.out = 30)
  fit <- BayesianSpline(x, sin(x) + rnorm(30, sd = 0.1), nKnots = 5,
                        nIter = 40)
  fit[["beta"]][30, 1] <- NaN
  pred <- PredictSpline(fit, at = c(0, 2), burnIn = 0)
  expect_true(all(is.na(pred[["mu"]])))
  expect_true(all(is.na(pred[["sd"]])))
  expect_true(all(is.na(pred[, as.character(c(0.025, 0.5, 0.975))])))
  expect_identical(dim(pred), c(2L, 8L))
})
