test_that("default modelDir is a dedicated subdirectory, not tempdir()", {
  oldOpts <- options(StratoBayesModelDirs = NULL, StratoBayesDeleteFlags = NULL)
  on.exit(options(oldOpts))
  modelDir <- .SetModelDir(NULL, "m1")
  on.exit(unlink(modelDir, recursive = TRUE), add = TRUE)

  expect_false(.SameDir(modelDir, tempdir()))
  expect_true(dir.exists(modelDir))
  expect_true(.SameDir(dirname(modelDir), tempdir()))
})

test_that("cleanup removes the model directory but never tempdir()", {
  oldOpts <- options(StratoBayesModelDirs = NULL, StratoBayesDeleteFlags = NULL)
  on.exit(options(oldOpts))
  planted <- tempfile("planted")
  writeLines("keep", planted)
  on.exit(unlink(planted), add = TRUE)

  modelDir <- .SetModelDir(NULL, "m1")
  writeLines("x", file.path(modelDir, "m1_data.rds"))
  .CleanModelDirs()

  expect_false(dir.exists(modelDir))
  expect_true(file.exists(planted))
  expect_true(dir.exists(tempdir()))
})

test_that("cleanup refuses to delete tempdir() even if flagged", {
  oldOpts <- options(StratoBayesModelDirs = list(tempdir()),
                     StratoBayesDeleteFlags = list(TRUE))
  on.exit(options(oldOpts))
  planted <- tempfile("planted")
  writeLines("keep", planted)
  on.exit(unlink(planted), add = TRUE)

  .CleanModelDirs()
  expect_true(file.exists(planted))
})

test_that(".CheckRequiredFiles anchors the model name (m1 beside m10)", {
  dir <- tempfile("chk")
  dir.create(dir)
  on.exit(unlink(dir, recursive = TRUE))
  for (f in c("m1_data.rds", "m1_model.rds", "m1_samples_run_1.txt",
              "m1_mcmc_run_1.rds", "m10_data.rds", "m10_model.rds",
              "m10_samples_run_1.txt", "m10_samples_run_2.txt",
              "m10_mcmc_run_1.rds")) {
    file.create(file.path(dir, f))
  }
  writeLines("nRun = 1", file.path(dir, "m1_options.txt"))
  writeLines("nRun = 2", file.path(dir, "m10_options.txt"))

  expect_no_error(.CheckRequiredFiles(dir, "m1"))
})
