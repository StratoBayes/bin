test_that(".GenerateTestData generates valid data", {
  testData <- .GenerateTestData("multi", "gap-3-sites-dates-longer")
  stratD <- StratData(testData$signal, testData$ties, testData$parts,
                      signalColumn = c("a", "b"))
  expect_s3_class(stratD, "StratData")
  expect_equal(stratD[["S"]], 3)
  # `longer` appends 30 site1 rows and lifts site1's top partition boundary
  expect_equal(testData$parts$height[1], 104)
  expect_equal(sum(testData$signal$site == "site1"), 80 + 30)

  testData <- .GenerateTestData("single", "1c")
  stratD <- StratData(testData$signal, testData$ties, testData$parts,
                      signalColumn = c("value"))
  expect_s3_class(stratD, "StratData")
  expect_equal(stratD[["S"]], 3)
  expect_equal(nrow(testData$signal), 9L)

  testData <- .GenerateTestData("single", "4")
  stratD <- StratData(testData$signal, testData$ties, testData$parts,
                      signalColumn = c("value"))
  expect_s3_class(stratD, "StratData")
  expect_equal(nrow(testData$parts), 15L)
  expect_equal(nrow(testData$ties), 3L)
})

test_that(".GenerateTestData multi tokens change the fixture as documented", {
  base <- .GenerateTestData("multi")
  expect_named(base, c("signal", "parts"))
  expect_named(base$signal, c("a", "b", "height", "site"))
  expect_equal(base$parts$height[1], 80)
  expect_equal(nrow(base$parts), 3L)

  longer <- .GenerateTestData("multi", "longer")
  expect_equal(nrow(longer$signal), nrow(base$signal) + 30L)
  expect_equal(longer$parts$height[1], 104)

  gap <- .GenerateTestData("multi", "gap")
  expect_lt(nrow(gap$signal), nrow(base$signal))
  expect_equal(nrow(gap$parts), 5L)

  dates <- .GenerateTestData("multi", "dates")
  expect_named(dates, c("signal", "parts", "ties"))
  expect_equal(nrow(dates$ties), 2L)

  named <- .GenerateTestData("multi", "dates-names")
  expect_named(named$signal, c("a", "b", "Hight", "SIT"))
  expect_named(named$parts, c("SIT", "Hight", "partition"))
  expect_equal(colnames(named$ties)[1:2], c("SIT", "Hight"))
})

test_that(".GenerateTestData single and depth versions have their shapes", {
  v1 <- .GenerateTestData("single", "1")
  expect_named(v1, "signal")
  expect_equal(dim(v1$signal), c(9L, 3L))

  v1a <- .GenerateTestData("single", "1a")
  expect_named(v1a, c("signal", "parts", "ties"))
  expect_equal(nrow(v1a$parts), 7L)
  expect_named(v1a$ties, c("site", "height", "mean", "sd"))

  v1b <- .GenerateTestData("single", "1b")
  expect_named(v1b, c("signal", "parts", "ties"))
  expect_type(v1b$signal$site, "character")
  expect_equal(v1b$ties$densityFun, c("dnorm", "dunif"))

  depth <- .GenerateTestData("depth", "1")
  expect_named(depth, c("signal", "parts", "ties"))
  expect_equal(nrow(depth$signal), 12L)
  expect_true("depth" %in% names(depth$signal))
})

test_that(".GenerateTestData validates `testdata` and `version`", {
  expect_error(.GenerateTestData("triple"), "Unrecognised `testdata`")
  expect_error(.GenerateTestData("depth", "2"), "Unrecognised `version`")
})

test_that(".GenerateTestData leaves the caller's RNG stream untouched", {
  set.seed(42)
  before <- .Random.seed
  invisible(.GenerateTestData("multi", "gap-3-sites-dates"))
  expect_identical(.Random.seed, before)

  # ... and does not leave a seed behind when the caller had none, which would
  # silently fix the stream for everything after it.
  withr::defer(assign(".Random.seed", before, envir = globalenv()))
  rm(".Random.seed", envir = globalenv())
  invisible(.GenerateTestData("multi"))
  expect_false(exists(".Random.seed", envir = globalenv(), inherits = FALSE))
})

test_that(".GenerateTestData is reproducible from its internal seed pin", {
  expect_identical(.GenerateTestData("multi", "gap-3-sites-dates"),
                   .GenerateTestData("multi", "gap-3-sites-dates"))
})

test_that(".GenerateTestData rejects a version it no longer ships", {
  # "2" was byte-identical to "1c" and has been withdrawn.
  expect_error(.GenerateTestData("single", "2"), "Unrecognised `version`")
})

test_that('.GenerateTestData("multi") is pinned to its seed-1 stream', {
  # Every "multi" fixture in the suite is built from these draws, so any
  # inserted, removed or reordered rnorm() call in the generator -- including
  # deleting the unread `hb2` -- moves them all. Values are those of the
  # generator as shipped; a change here is a fixture change, not a test bug.
  signal <- .GenerateTestData("multi")[["signal"]]
  # Shape only: nrow is n1 + 2 * n2, with no RNG dependence.
  expect_identical(nrow(signal), 164L)
  # Leading values localise a break to the first draws; the column sums are
  # what make the pin whole-stream, catching a reordering confined to the tail.
  expect_equal(signal[["a"]][1:2], c(2.0454451, 2.8349948), tolerance = 1e-7)
  expect_equal(signal[["b"]][c(1, 2, 4)],
               c(9.8068785, 9.8383991, 10.641400), tolerance = 1e-7)
  expect_equal(sum(signal[["a"]], na.rm = TRUE), 3012.0711018, tolerance = 1e-9)
  expect_equal(sum(signal[["b"]], na.rm = TRUE), 1531.7356160, tolerance = 1e-9)
})

test_that(".GenerateTestData builds site 3 without a `gap` token (#1230)", {
  # `3-sites` used to be nested inside the `gap` branch, so this composition
  # silently produced two sites -- and, with `dates`, a tie on the absent
  # third.
  noGap <- .GenerateTestData("multi", "3-sites-dates")
  expect_setequal(unique(noGap[["signal"]][["site"]]),
                  c("site1", "site2", "site3"))
  expect_true("site3" %in% noGap[["parts"]][["site"]])
  expect_true("site3" %in% noGap[["ties"]][["site"]])

  # Every tie names a site the signal actually holds.
  expect_true(all(noGap[["ties"]][["site"]] %in% noGap[["signal"]][["site"]]))

  # Discriminator: the two-site composition still has no site 3 and no tie
  # naming one, so the assertions above are not true of every version.
  twoSites <- .GenerateTestData("multi", "dates")
  expect_false("site3" %in% twoSites[["signal"]][["site"]])
  expect_false("site3" %in% twoSites[["ties"]][["site"]])
})

test_that(".GenerateTestData rejects an unrecognised multi token (#1230)", {
  # A typo used to fall through to a different, incomplete fixture in silence.
  expect_error(.GenerateTestData("multi", "date"), "Unrecognised token .date.")
  expect_error(.GenerateTestData("multi", "3sites"), "Unrecognised token")
  expect_error(.GenerateTestData("multi", "gap-nmaes"),
               "Unrecognised token .nmaes.")

  # Every composition the test suite and data-raw/ actually pass must survive.
  inUse <- c("1", "gap", "gap-names", "gap-names-3-sites",
             "gap-names-3-sites-dates", "gap-3-sites-dates-longer")
  for (version in inUse) {
    expect_s3_class(.GenerateTestData("multi", version)[["signal"]],
                    "data.frame")
  }
})

test_that("a repeated token is rejected, not silently collapsed (#1230)", {
  # `sub()`'s single pass is what leaves a residue here; a `gsub()` would strip
  # `"gap-gap"` to `""` and accept it. This pins the choice, which reads like an
  # oversight and is not.
  expect_error(.GenerateTestData("multi", "gap-gap"), "Unrecognised token")
  expect_error(.GenerateTestData("multi", "3-sites-3-sites"),
               "Unrecognised token")
  # The over-rejection control: a legitimate composition sharing a token still
  # strips cleanly.
  expect_named(.GenerateTestData("multi", "gap-3-sites"), c("signal", "parts"))
})
