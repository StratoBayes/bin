# #1812 (duplicate #794): `adaptProposal = FALSE` leaves no adaptation window,
# so an explicit `adaptTemperatures = TRUE` cannot take effect.
test_that(paste0("adaptProposal = FALSE warns when it discards ",
                 "adaptTemperatures = TRUE"), {
            expect_warning(
              mcmc <- StratMCMC(stratModel1, nIter = 200, nChains = 4,
                                nThreads = 1L,
                                adaptProposal = FALSE,
                                adaptTemperatures = TRUE),
              "adaptTemperatures = TRUE.*adaptProposal = FALSE"
            )
            expect_false(mcmc[[c("temper", "adaptTemperatures")]])

            # Discriminator: without the explicit request the coercion is the
            # default and stays quiet.
            expect_no_warning(
              StratMCMC(stratModel1, nIter = 200, nChains = 4, nThreads = 1L,
                        adaptProposal = FALSE)
            )
          })

# #1814: an early stop can fall before the adaptation timer's scheduled freeze,
# which the run then never reached.
test_that("an early stop drops a freeze point the run never reached", {
  mcmc <- list(
    completedIter = 150,
    saveIter = c(50, 100, 150, 200),
    endAdapting = 400,
    adaptFreeze = list(iteration = 180, spent = 1, predicted = 2)
  )
  pruned <- StratoBayes:::.PruneToCompleted(mcmc)
  expect_equal(pruned[["saveIter"]], c(50, 100, 150))
  expect_equal(pruned[["endAdapting"]], 150)
  expect_null(pruned[["adaptFreeze"]])

  mcmc[["adaptFreeze"]][["iteration"]] <- 120
  kept <- StratoBayes:::.PruneToCompleted(mcmc)
  expect_equal(kept[["adaptFreeze"]][["iteration"]], 120)
})
