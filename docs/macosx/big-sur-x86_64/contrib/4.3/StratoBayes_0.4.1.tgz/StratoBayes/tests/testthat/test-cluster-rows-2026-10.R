# .ClusterRows() never exceeds its cap (#2279); Cluster.default() refuses
# infinite and non-numeric input (#2280); summary() reports the burn-in the
# supplied rows applied (#2254).

test_that(".ClusterRows keeps the total within the cap when a run is floored (#2279)", {
  rows <- .ClusterRows(list(1:5000, 1:10))
  expect_lte(sum(lengths(rows)), .kMaxClusterSamples)
  expect_gte(length(rows[[2]]), .kAutoBurnInMinRows)

  rows <- .ClusterRows(list(1:5000, 1:10, 1:3, 1:5000, 1:4000), cap = 100)
  expect_lte(sum(lengths(rows)), 100)
  expect_equal(lengths(rows)[2:3], c(8L, 3L))
  expect_true(all(lengths(rows)[c(1, 4, 5)] >= .kAutoBurnInMinRows))
})

test_that(".ClusterRows keeps NULL entries of unselected runs in place (#2279)", {
  rows <- .ClusterRows(list(1:5000, NULL, 1:3000), cap = 5)
  expect_length(rows, 3)
  expect_null(rows[[2]])
  rows <- .ClusterRows(list(1:5000, integer(0), NULL, 1:3), cap = 10)
  expect_length(rows, 4)
})

test_that(".ClusterRows passes a selection under the cap through, and honours floors that exceed it (#2279)", {
  sel <- list(1:5, 1:10)
  expect_identical(.ClusterRows(sel), sel)
  floors <- rep(list(1:100), 5)
  expect_equal(lengths(.ClusterRows(floors, cap = 20)),
               rep(.kAutoBurnInMinRows, 5))
})

test_that("Cluster.default() rejects infinite cells under every backend (#2280)", {
  set.seed(1)
  m <- matrix(rnorm(40), 20, 2)
  m[3, 1] <- Inf
  for (method in c("proto", "hdbscan", "pam")) {
    expect_error(Cluster(m, clusterMethod = method),
                 "infinite values in row\\(s\\): 3", info = method)
  }
  m[3, 1] <- -Inf
  expect_error(Cluster(c(m[, 2], Inf)), "infinite values")
})

test_that("the NA/Inf helpers refuse infinite cells (#2280)", {
  m <- matrix(c(1:19, Inf, 1:20), 20, 2)
  expect_error(.CheckNoNAInMatrix(m), "infinite values in row\\(s\\): 20")
  expect_error(.CheckNoNAInDist(stats::dist(m), m), "infinite values")
})

test_that("Cluster.default() rejects non-numeric data.frame columns (#2280)", {
  df <- data.frame(a = rnorm(20), b = rep(c("x", "y"), 10))
  expect_error(Cluster(df), "must be numeric")
  df <- data.frame(a = rnorm(20), b = factor(rep(c("10", "20"), 10)))
  expect_error(Cluster(df), "must be numeric")
})

test_that("overflowing distances are reported, not called missing data (#2280)", {
  m <- matrix(c(1e200, -1e200, 0, 1e200, -1e200, 0), 3, 2)
  expect_error(.CheckNoNAInDist(stats::dist(m), m), "overflow")
})
