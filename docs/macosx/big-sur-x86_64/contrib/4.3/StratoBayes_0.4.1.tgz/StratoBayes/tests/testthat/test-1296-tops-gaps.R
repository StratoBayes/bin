test_that("a repeated site is a clean argument error (#1296.1)", {
  expect_error(TopsPlot(stratPosterior1, sites = c(1, 1), display = FALSE),
               "same site twice")
  expect_error(.ValidateSites(c("site_1", "site_1"), stratPosterior1[["data"]]),
               "same site twice")
})

test_that("a fractional refHeightsSite truncates loudly (#1296.2)", {
  # truncation itself is intended (RT-721); the gap was that it was silent
  expect_warning(
    TopsPlot(stratPosterior1, refHeights = c(1, 2), refHeightsSite = 2.9,
             display = FALSE),
    "not a whole number"
  )
  # Control: a whole-number index raises no *truncation* warning. Scoped to
  # that message rather than `expect_no_warning()`, because refHeight 2 at
  # site 2 falls outside site 1's range and #1169's clamp warns about it --
  # a different complaint about a different argument.
  warned <- character(0)
  invisible(withCallingHandlers(
                                TopsPlot(stratPosterior1, refHeights = c(1, 2),
                                         refHeightsSite = 2,
                                         display = FALSE),
                                warning = function(w) {
                                  warned <<- c(warned, conditionMessage(w))
                                  invokeRestart("muffleWarning")
                                }))
  expect_false(any(grepl("not a whole number", warned)))
})

test_that("the all-alignments fast path matches .ValidateAlignment() (#1296.5)",
          {
            expect_true(.IsAllAlignment("all"))
            expect_true(.IsAllAlignment("All"))
            expect_true(.IsAllAlignment("none"))
            expect_false(.IsAllAlignment(1))

            # `alignment = "All"` skipped the fast path and clustered for
            # nothing; the result was identical either way, so the observable is
            # that the clustering branch is no longer entered -- assert it via
            # the answer plus the absence of the clustering-only warning path
            expect_equal(
              Tops(stratPosterior1, refHeights = c(1, 2), quantiles = 0.5,
                   alignment = "All"),
              Tops(stratPosterior1, refHeights = c(1, 2), quantiles = 0.5,
                   alignment = "all")
            )
            expect_equal(
              StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                       quantiles = 0.5,
                       alignment = "All"),
              StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                       quantiles = 0.5,
                       alignment = "all")
            )
          })

test_that(paste0("Tops() row order is as documented for each `quantiles` mode ",
                 "(#1296.6)"), {
            refHeights <- c(1, 2, 3)
            numeric <- Tops(stratPosterior1, refHeights = refHeights,
                            quantiles = 0.5)
            samples <- suppressWarnings(
              Tops(stratPosterior1,
                   refHeights = refHeights,
                   quantiles = "samples",
                   maxSamples = 2)
            )

            # numeric: site varies fastest within each refHeight
            expect_identical(numeric[["refHeight"]], rep(refHeights, each = 2))
            # samples: refHeight varies fastest within each site
            expect_identical(samples[["refHeight"]], rep(refHeights, times = 2))
          })
