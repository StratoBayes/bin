# #1724: `sedModel = "site, partition"` names parameters
# `gammaLog_<partition>_<site>` via `paste0()`; an underscore inside either
# label can make two distinct (partition, site) pairs collide on the same
# string, silently misbinding priors. `StratModel()` must refuse the input
# rather than construct a model with duplicate parameter names.
test_that(paste0("StratModel() rejects a sedModel = 'site, partition' name ",
                 "collision (#1724)"), {
            sig <- data.frame(
              site   = rep(c("A", "y_z", "z"), each = 6),
              height = rep(seq(0, 10, length.out = 6), 3),
              value  = rep(c(1, 3, 2, 5, 4, 6), 3)
            )
            # site "y_z" is wholly partition "x"; site "z" is wholly partition
            # "x_y" -- gammaLog_x_y_z is built for both (partition "x" @ site
            # "y_z", and partition "x_y" @ site "z").
            parts <- data.frame(
              site      = c("A", "A", "y_z", "y_z", "z", "z"),
              height    = c(0, 10, 0, 10, 0, 10),
              partition = c("p0", "p0", "x", "x", "x_y", "x_y")
            )
            stratData <- StratData(signal = sig, parts = parts)

            # Confirms the collision is real, at the level .CreateIndices()
            # itself constructs names -- not just a property of the higher-level
            # guard.
            ind <- .CreateIndices(stratData, "height", "site, partition",
                                  "bottom")
            expect_identical(anyDuplicated(ind[["names"]]) > 0, TRUE)
            expect_true(
              "gammaLog_x_y_z" %in% ind[["names"]][duplicated(ind[["names"]])]
            )

            expect_error(
              StratModel(stratData, alignmentScale = "height",
                         sedModel = "site, partition",
                         alphaPosition = "bottom"),
              "duplicate parameter name.*gammaLog_x_y_z"
            )
          })

# #1804: a second, structurally distinct collision site -- output-parameter
# names `delta_<group>_<signal>`, built outside `ind$names`, so #1724's guard
# does not catch it.
test_that("StratModel() rejects a delta_ output-column name collision (#1804)",
          {
            n <- 12
            h <- seq(0, 10, length.out = n)
            signal <- data.frame(
              site   = c(rep("s1", n), rep("s2", n)),
              height = c(h, h),
              y_z    = c(sin(h), sin(h) + 1),
              z      = c(cos(h), cos(h) + 1)
            )
            # group "x" (site s1) + signal "y_z" -> delta_x_y_z, and group "x_y"
            # (site s2) + signal "z" -> delta_x_y_z: same collision as #1724's,
            # but at the delta output-name construction site rather than
            # ind$names.
            group <- data.frame(site = c("s1", "s2"), group = c("x", "x_y"),
                                stringsAsFactors = FALSE)
            data <- StratData(signal = signal, signalColumn = c("y_z", "z"),
                              group = group)

            expect_error(
              StratModel(data, alignmentScale = "height", sedModel = "site",
                         alphaPosition = "bottom", signalOffsets = TRUE),
              "output columns contain duplicate name.*delta_x_y_z"
            )
          })

# #1803: an NA group label is silently dropped by `sort(unique(...))`,
# corrupting the offset config rather than erroring.
test_that("StratData() rejects an NA group label (#1803)", {
  sig <- data.frame(
    site   = c(rep("s1", 8), rep("s2", 8), rep("s3", 8)),
    height = rep(seq(0, 10, length.out = 8), 3),
    value  = rnorm(24)
  )
  group <- data.frame(site = c("s1", "s2", "s3"), group = c("A", "B", NA),
                      stringsAsFactors = FALSE)

  expect_error(
    StratData(signal = sig, group = group),
    "missing \\(NA\\) group label.*s3"
  )
})

# #2065: two `signalColumn` entries resolving to the same LAS column (e.g.
# case-insensitive duplicates) must error, not silently keep only the last
# write. `.MapAndRenameColumns()` only runs on the LAS-folder ingestion path
# (a data.frame `signal` goes through `.CheckDataColumns()`'s exact-name
# matching instead, which is a different check entirely), so this is
# exercised directly, the same way #1800's sibling test does.
test_that(paste0(".MapAndRenameColumns() errors when two signalColumn entries ",
                 "resolve to the same LAS column (#2065)"), {
            df <- data.frame(Depth = 1:3, A = c(1, 2, 3))
            expect_error(
              .MapAndRenameColumns(df, zColumn = "Depth",
                                   signalColumn = c("A", "a")),
              "resolve to the same column.*Use distinct columns"
            )
          })
