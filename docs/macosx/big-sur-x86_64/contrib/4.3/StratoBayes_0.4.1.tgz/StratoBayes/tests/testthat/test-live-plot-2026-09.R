.MakeLivePlotFixture <- function(run = 1) {
  model <- stratPosterior1[["model"]]
  paramNames <- model[["outputParams"]]
  allNames <- c("iteration", "chain", "posterior", paramNames)
  samples <- array(NA_real_, dim = c(3, length(allNames), 1, 1))
  dimnames(samples) <- list(NULL, allNames, "run1", "chain1")
  samples[1:2, "iteration", 1, 1] <- c(100, 201)
  samples[1:2, "chain", 1, 1] <- 1
  samples[1:2, "posterior", 1, 1] <- c(-120, -100)
  samples[1:2, paramNames, 1, 1] <- rep(
    stratPosterior1[["samples"]][201, , run, 1], each = 2
  )
  list(
    data = stratPosterior1[["data"]], model = model,
    mcmc = list(nIter = 5000), samples = samples,
    sectionCol = hcl.colors(stratPosterior1[["data"]][["S"]], "Dark 3"),
    sectionSymbol = rep(21L, stratPosterior1[["data"]][["S"]])
  )
}

test_that("#2125/#741: a plot frame leaves the RNG stream untouched", {
  fixture <- .MakeLivePlotFixture()
  set.seed(1)
  seedBefore <- .Random.seed
  png(tempfile())
  on.exit(dev.off(), add = TRUE)
  drawn <- StratoBayes:::.PlotSignal(
    fixture$data, fixture$model, fixture$mcmc, fixture$samples, run = 1,
    sig = 1, plotIterRowAll = 2, fixture$sectionCol, fixture$sectionSymbol
  )
  expect_true(drawn)
  expect_identical(.Random.seed, seedBefore)
})

test_that("#743: a skipped frame keeps the last good PNG and closes the device", {
  saveVisualiseDir <- withr::local_tempdir()
  final <- file.path(saveVisualiseDir, "m_plot_run_1_sig_1.png")
  writeBin(as.raw(1:10), final)
  good <- readBin(final, "raw", 100)
  nDevBefore <- length(dev.list())

  pngFilenameTemp <- StratoBayes:::.SavePng(
    TRUE, saveVisualiseDir, "m", info1 = "run_1", info2 = "sig_1",
    info3 = "task_1"
  )
  writeBin(as.raw(99), pngFilenameTemp)  # a native backend's blank page
  StratoBayes:::.CloseAndRenamePng(
    TRUE, pngFilenameTemp, saveVisualiseDir, "m", info1 = "run_1",
    info2 = "sig_1", drawn = FALSE
  )
  expect_identical(readBin(final, "raw", 100), good)
  expect_false(file.exists(pngFilenameTemp))
  expect_equal(length(dev.list()), nDevBefore)
})

test_that("#743: a non-finite signal range leaves an existing PNG unchanged", {
  fixture <- .MakeLivePlotFixture()
  fixture$data[["signal"]][["value"]] <- NA_real_
  saveVisualiseDir <- withr::local_tempdir()
  final <- file.path(saveVisualiseDir, "m_plot_run_1_sig_1.png")
  writeBin(as.raw(1:10), final)
  testthat::local_mocked_bindings(
    .CompileSamplesDuringMCMC = function(...) fixture$samples,
    .PlotParameter = function(...) invisible(FALSE),
    .package = "StratoBayes"
  )
  suppressWarnings(
    StratoBayes:::.PlotDuringMCMC(
      fixture$data, fixture$model, fixture$mcmc, "m",
      saveVisualiseDir, nRun = 1, run = 1, isParallel = TRUE,
      visualise = list(signal = 1, parameter = 1), colourScale = "Dark 3",
      i = 1
    )
  )
  expect_identical(readBin(final, "raw", 100), as.raw(1:10))
})

test_that("#743: skipped panels still advance the layout cursor", {
  fixture <- .MakeLivePlotFixture()
  panels <- 0L
  testthat::local_mocked_bindings(
    .CompileSamplesDuringMCMC = function(...) fixture$samples,
    .PlotSignal = function(...) invisible(FALSE),
    .PlotParameter = function(...) invisible(FALSE),
    plot.new = function() panels <<- panels + 1L,
    layout = function(...) invisible(1),
    .package = "StratoBayes"
  )
  png(tempfile())
  on.exit(dev.off(), add = TRUE)
  StratoBayes:::.PlotDuringMCMC(
    fixture$data, fixture$model, fixture$mcmc, "m",
    withr::local_tempdir(), nRun = 1, run = 1, isParallel = FALSE,
    visualise = list(signal = c(1, 1), parameter = 1), colourScale = "Dark 3",
    i = 1
  )
  expect_equal(panels, 4L)
})

test_that("#746: .PlotSignal uses the caller's row, not the newest iteration", {
  fixture <- .MakeLivePlotFixture()
  parNames <- fixture$model[["parametersNames"]]
  fixture$samples[1, parNames, 1, 1] <- fixture$samples[2, parNames, 1, 1] + 1
  ageConvert <- StratoBayes:::.sb_age_convert
  usedPar <- NULL
  testthat::local_mocked_bindings(
    .sb_age_convert = function(data, indices, parameters) {
      usedPar <<- parameters
      ageConvert(data, indices, parameters)
    },
    .package = "StratoBayes"
  )
  png(tempfile())
  on.exit(dev.off(), add = TRUE)
  suppressWarnings(
    StratoBayes:::.PlotSignal(
      fixture$data, fixture$model, fixture$mcmc, fixture$samples, run = 1,
      sig = 1, plotIterRowAll = 1, fixture$sectionCol, fixture$sectionSymbol
    )
  )
  expect_equal(usedPar, as.numeric(fixture$samples[1, parNames, 1, 1]))
})

test_that("#745: an unrecognised alignmentScale is named in the error", {
  fixture <- .MakeLivePlotFixture()
  fixture$model[["alignmentScale"]] <- "sideways"
  png(tempfile())
  on.exit(dev.off(), add = TRUE)
  expect_error(
    StratoBayes:::.PlotSignal(
      fixture$data, fixture$model, fixture$mcmc, fixture$samples, run = 1,
      sig = 1, plotIterRowAll = 2, fixture$sectionCol, fixture$sectionSymbol
    ),
    "Unrecognised alignmentScale: sideways"
  )
})
