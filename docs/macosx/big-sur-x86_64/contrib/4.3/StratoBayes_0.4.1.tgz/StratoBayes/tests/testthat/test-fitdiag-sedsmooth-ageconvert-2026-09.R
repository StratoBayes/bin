.RunQuick <- function(data, model, name, nIter = 400L) {
  dir <- withr::local_tempdir(.local_envir = parent.frame())
  suppressMessages(suppressWarnings(RunStratModel(
    stratObject = data, stratModel = model, nIter = nIter, nChains = 1L,
    nRun = 1L, nThreads = 1L, seed = 2142, quiet = TRUE, visualise = FALSE,
    convergenceStop = FALSE, modelDir = dir, modelName = name
  )))
}

.OffsetData <- function(shift) {
  n <- 30
  h <- seq(0, 10, length.out = n)
  noise <- withr::with_seed(2143, rnorm(2 * n, 0, 0.1))
  sig <- data.frame(
    site = rep(c("site_1", "site_2"), each = n),
    height = c(h, h),
    value = c(sin(h), sin(h) + shift) + noise
  )
  grp <- data.frame(site = c("site_1", "site_2"), group = c("A", "B"))
  StratData(signal = sig, group = grp)
}

# The engine stores `likelihood_spline` as the beta-marginal log-likelihood of
# the values it fitted, plus the offsets' log-prior; rebuilding it from the ages
# and values FitDiagnostics() uses must reproduce it draw for draw.
.LikelihoodOracle <- function(sp, nDraw = 5L) {
  sigNames <- sp[[c("data", "signalAttr", "signalNames")]]
  lambdaNames <- paste0("lambda_", sigNames)
  model <- sp[["model"]]
  draws <- .FitDiagnosticsDraws(sp, sigNames, "all", 0.5, nDraw, "all", NULL)
  offsetNames <- .OffsetOutputParams(model[["offsetConfig"]], sigNames)
  saved <- ExtractParameters(
    sp,
    parameters = c("likelihood_spline", lambdaNames, offsetNames),
    alignment = "all", burnIn = 0.5, maxSamples = nDraw, runs = "all"
  )
  OffsetLogPrior <- function(d) {
    sum(vapply(sigNames, function(sig) {
      delta <- saved[d, grep(paste0("^delta_.*_", sig, "$"), colnames(saved))]
      tau <- saved[d, paste0("tau_", sig)]
      nFree <- length(delta) - 1
      -nFree * (log(tau) + 0.5 * log(2 * pi)) + 0.5 * log(length(delta)) -
        0.5 * sum(delta^2) / tau^2
    }, numeric(1)))
  }
  layout <- lapply(sigNames, function(sig) .FitSignalLayout(sp[["data"]], sig))
  names(layout) <- sigNames
  lp <- .PrepareLogPostArgs(model)

  rebuilt <- vapply(seq_len(nrow(draws[["metro"]])), function(d) {
    ageFlat <- .FitDrawAges(sp[["data"]], model, draws, d)
    extKnots <- .FitExtKnots(model, ageFlat)
    penalty <- model[[c("splineBase", "D")]]
    flexTerm <- 0
    if (isTRUE(model[["flexibleKnots"]])) {
      scale <- model[[c("splineBase", "ageSpan")]] / diff(range(ageFlat))
      penalty <- penalty * scale^3
      flexTerm <- 1.5 * (ncol(penalty) - 2) * log(scale)
    }
    logLik <- .sb_logpost(
      x = as.numeric(draws[["metro"]][d, ]),
      priorTypes = lp[["priorTypes"]],
      priorArgs = lp[["priorArgs"]],
      rCustomFns = lp[["rCustomFns"]],
      B_list = lapply(layout, function(lay) {
        splineDesign(extKnots, ageFlat[lay[["pointInd"]]], sparse = FALSE)
      }),
      beta_list = lapply(sigNames, function(sig) draws[[c("beta", sig)]][d, ]),
      signalValues = lapply(layout, .FitObserved, draws = draws, d = d),
      sigma = vapply(sigNames, function(sig) draws[[c("sigma", sig)]][[d]], 1),
      overlapPenalty = FALSE,
      signalSectionOverlap = list(),
      adjustments = list(),
      marginal = TRUE,
      lambda = as.numeric(saved[d, lambdaNames]),
      Dmat = penalty,
      flexTerm = flexTerm
    )[[2]]
    logLik + if (length(offsetNames)) OffsetLogPrior(d) else 0
  }, numeric(1))

  # Return:
  max(abs(rebuilt - as.numeric(saved[, "likelihood_spline"])))
}

test_that(".sb_age_convert() refuses a sedSmooth model's indices (#2142)", {
  for (sedModel in c("site", "partition", "site, partition")) {
    for (scale in c("height", "age")) {
      ind <- .CreateIndices(
        stratData1, scale, sedModel, "middle", sedSmooth = TRUE
      )
      params <- rep(0, length(ind[["names"]]))
      label <- paste(sedModel, scale)
      expect_error(
        .sb_age_convert(stratData1, ind, params),
        "sedSmooth models have no gamma rates", info = label
      )
      expect_error(
        .sb_age_convert_batch(stratData1, ind, matrix(params, 1L), 1:3, 2L),
        "sedSmooth models have no gamma rates", info = label
      )
    }
  }

  ind <- stratModel1[["ind"]]
  params <- rep(0, length(ind[["names"]]))
  ind[["gamma"]] <- integer(0)
  expect_error(.sb_age_convert(stratData1, ind, params), "gamma` is empty")

  ind <- .CreateIndices(stratData2, "height", "site, partition", "middle")
  params <- rep(0, length(ind[["names"]]))
  ind[["gammaInd"]] <- NULL
  expect_error(.sb_age_convert(stratData2, ind, params), "gammaInd` is missing")
})

test_that("an age-scale sedSmooth model builds fixed knots from the data", {
  priors <- structure(list(
    "alpha_site1" = UniformPrior(min = -100, max = 100),
    "alpha_site2" = UniformPrior(min = -100, max = 100),
    "alpha_site3" = UniformPrior(min = -100, max = 100),
    "gap_site2_1" = ExponentialPrior(rate = 1)
  ), class = c("StratPrior", "list"))
  for (sedModel in c("site", "site, partition")) {
    model <- suppressWarnings(suppressMessages(StratModel(
      stratData2, priors = priors, alignmentScale = "age",
      sedModel = sedModel, sedSmooth = TRUE, flexibleKnots = FALSE,
      nKnots = 10
    )))
    info <- .SetupSedSmooth(stratData2, "age", 6L)
    medians <- .MetroPriorMedians(model[[c("priors", "metro")]])
    ages <- .AgeConversionStratData(
      stratData2, model[["ind"]], medians,
      sedSmoothInfo = info, sedBeta = rep(0, info[["totalBeta"]])
    )
    span <- range(unlist(ages[["signal"]]))
    expect_equal(
      model[[c("splineBase", "knotRange")]],
      span + c(-0.25, 0.25) * diff(span), info = sedModel
    )
  }
})

test_that("FitDiagnostics() converts sedSmooth ages with sedBeta (#2142)", {
  skip_on_cran()
  model <- StratModel(
    stratData1, alignmentScale = "height", sedModel = "site, partition",
    sedSmooth = TRUE, nKnots = 10
  )
  sp <- .RunQuick(stratData1, model, "sedSmooth")
  expect_lt(.LikelihoodOracle(sp), 1e-8)

  fd <- suppressMessages(FitDiagnostics(sp, maxSamples = 20L))
  expect_true(all(is.finite(fd[["sites"]][["lpd"]])))

  # Every other sampled quantity held fixed, the fit must follow sedBeta.
  shifted <- sp
  sedBetaCols <- grep("^sedBeta_", dimnames(sp[["samples"]])[[2]])
  shifted[["samples"]][, sedBetaCols, , ] <-
    shifted[["samples"]][, sedBetaCols, , ] + 0.5
  fdShifted <- suppressMessages(FitDiagnostics(shifted, maxSamples = 20L))
  expect_false(isTRUE(all.equal(fd[["sites"]], fdShifted[["sites"]])))
})

test_that("FitDiagnostics() removes the fitted signal offsets (#2143)", {
  skip_on_cran()
  data <- .OffsetData(shift = 5)
  model <- StratModel(
    data, alignmentScale = "height", sedModel = "site", nKnots = 8,
    signalOffsets = TRUE
  )
  sp <- .RunQuick(data, model, "offsets", nIter = 1000L)
  expect_lt(.LikelihoodOracle(sp), 1e-8)

  fd <- suppressMessages(FitDiagnostics(sp, maxSamples = 50L))
  expect_true(fd[[c("general", "signalOffsets")]])
  # A shift of fifty noise SDs would put both sites far off the shared curve if
  # the offsets the model fitted were left in the residuals.
  expect_true(all(abs(fd[["sites"]][["offset"]]) < 3))
  expect_true(all(fd[["sites"]][["pppOffset"]] > 0.01))
})

test_that(".FitReadings() does not recommend an offset the model has", {
  row <- data.frame(
    signal = "value", site = "s", pppDrift = 0.5, pppScatter = 0.5,
    pppOffset = 0.001
  )
  expect_match(.FitReadings(row, 0.01), "a real between-site signal offset")
  expect_match(
    .FitReadings(row, 0.01, signalOffsets = TRUE),
    "even after its group's fitted signal offset"
  )
})

test_that(".sb_sed_spline_*() refuse NaN heights (#2152)", {
  info <- .SetupSedSmooth(stratData1, "height", 6L)
  beta <- rep(0, info[["totalBeta"]])
  heightsMsg <- "`heights` must not contain NA or NaN"
  boundsMsg <- "`a` and `b` must not be NA or NaN"
  Ages <- function(h) .sb_sed_spline_ages(beta, info, 1L, h, 0, 1)
  Integral <- function(a, b) {
    .sb_sed_spline_partial_integral(beta, info, 1L, a, b)
  }
  expect_error(Ages(c(0, NA)), heightsMsg)
  expect_error(Ages(NaN), heightsMsg)
  expect_error(Integral(0, NA), boundsMsg)
  expect_error(Integral(NaN, 1), boundsMsg)
})

test_that(".sb_age_convert() refuses a short parameter vector (#2152)", {
  ind <- stratModel1[["ind"]]
  params <- rep(0, length(ind[["names"]]))
  expect_error(
    .sb_age_convert(stratData1, ind, params[-1]),
    "must hold a value for each of the"
  )
  # a full saved row carries the alignment parameters first
  expect_identical(
    .sb_age_convert(stratData1, ind, c(params, 99, 99)),
    .sb_age_convert(stratData1, ind, params)
  )
})

test_that(".sb_age_convert_batch() refuses a site with no boundaries (#2152)", {
  ind <- stratModel1[["ind"]]
  data <- stratData1
  data[[c("partsAttr", "nBound")]][[2]] <- 0L
  params <- matrix(0, 1L, length(ind[["names"]]))
  expect_error(
    .sb_age_convert_batch(data, ind, params, 1:3, 2L),
    "not a valid row count"
  )
})

test_that("FitDiagnostics() gates on the caller's burnIn and runs (#2144)", {
  sp <- stratPosterior1
  cached <- max(sp[["summary"]]$general$psrf)

  early <- max(summary(sp, burnIn = 0, alignment = "none")$general$psrf)
  expect_false(isTRUE(all.equal(early, cached)))
  expect_equal(FitDiagnostics(sp, burnIn = 0)$general$rhatMax, early)

  oneRun <- max(summary(sp, runs = 1, alignment = "none")$general$psrf)
  expect_false(isTRUE(all.equal(oneRun, cached)))
  expect_equal(FitDiagnostics(sp, runs = 1)$general$rhatMax, oneRun)
})

test_that("FitDiagnostics() reads multiESS for the draws it pooled (#2144)", {
  sp <- stratPosterior5a
  pooled <- summary(sp, alignment = "none")$alignmentAll$multiESS
  expect_false(isTRUE(all.equal(pooled, sp[["summary"]][[1]][["multiESS"]])))
  expect_equal(FitDiagnostics(sp)$general$multiESS, pooled)
})

test_that("every pooled alignment selection is flagged (#2144)", {
  clean <- list(
    rhatMax = 1.01, multiESS = 500, nDivergent = 0, nAlignments = 3
  )
  Gate <- function(alignment) {
    .FitGateMessages(utils::modifyList(clean, list(alignment = alignment)))
  }
  expect_match(Gate("All"), "pooled over 3 alignments")
  expect_match(Gate("none"), "pooled over 3 alignments")
  expect_match(Gate(c(1, 2)), "pooled over 2 alignments")
  expect_length(Gate(2), 0)

  # the count follows a clustering the caller supplied
  own <- list(nClust = 5L)
  expect_identical(.FitAlignmentCount(stratPosterior1, own), 5L)
})

test_that("an unassessable gate is said, not skipped (#2144)", {
  fd <- FitDiagnostics(stratPosterior1)
  expect_length(.FitGateUnknown(fd[["general"]]), 0)

  Printed <- function(field, value) {
    fd[["general"]][[field]] <- value
    capture.output(print(fd))
  }
  expect_match(
    Printed("rhatMax", NA_real_), "Convergence could not be assessed",
    all = FALSE
  )
  expect_match(Printed("rhatMax", NA_real_), "provisional", all = FALSE)
  expect_match(
    Printed("multiESS", NA_real_), "Multivariate ESS could not be computed",
    all = FALSE
  )
  expect_match(
    Printed("nAlignments", NA_integer_),
    "number of alignments could not be determined", all = FALSE
  )

  # every psrf undefined is unknown, not -Inf
  smry <- list(alignmentAll = list(multiESS = 1), general = list(psrf = NA))
  expect_true(is.na(.FitConvergenceSummary(smry)[["rhatMax"]]))
})
