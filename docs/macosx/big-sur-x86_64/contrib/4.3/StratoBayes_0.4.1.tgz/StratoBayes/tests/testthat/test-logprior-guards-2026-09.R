# Non-finite log-prior and accept-step parity (#2159, #1513), degenerate
# priors (#2176), AutoPrior() entry-point consistency (#2177) and the sedSmooth
# rate bound (#2187).

# ── #2159: a +Inf log-prior is out of support ───────────────────────────────

test_that(".sb_logpost scores a +Inf log-prior as out of support (#2159)", {
  # dgamma(0, shape < 1) is +Inf: a custom prior whose automatic start draws
  # exactly 0 lands here.
  lp <- .PrepareLogPostArgs(list(priors = list(
    metro = list(Prior(rgamma, dgamma, qgamma, shape = 0.01, rate = 1))
  )))
  expect_identical(lp$priorTypes, "")

  out <- .sb_logpost(
    x = 0, priorTypes = lp$priorTypes, priorArgs = lp$priorArgs,
    rCustomFns = lp$rCustomFns,
    B_list = list(matrix(1, nrow = 3L, ncol = 2L)),
    beta_list = list(c(0.5, 0.5)),
    signalValues = list(c(1, 2, 3)),
    sigma = 1, overlapPenalty = FALSE,
    signalSectionOverlap = list(), adjustments = list()
  )
  expect_identical(out[[1]], -1e30)
  expect_true(all(is.na(out[-1])))
})

test_that(".LogPost does not error on a NaN gap parameter (#2159)", {
  lp <- .PrepareLogPostArgs(list(priors = list(
    metro = list(ExponentialPrior(1))
  )))
  model <- list(.logpost_cpp = lp, ind = list(gap = 1L),
                overlapPenalty = list(overlapPenalty = FALSE))
  state <- list(metro = list(parameters = NaN, B = list()),
                gibbs = list(beta = list(), sigma = numeric(0)))
  data <- list(signalAttr = list(signalValuesVec = list()))

  out <- .LogPost(data, model, state)
  expect_true(out[[1]] <= -1e30)
})

# ── #1513: .AcceptProposal matches accept_proposal on non-finite input ──────

test_that(".AcceptProposal treats every non-finite log posterior alike (#1513)",
          {
            # accept_proposal: a non-finite new state is accepted only from a
            # non-finite old one; a finite new state always escapes a
            # non-finite old one.
            for (bad in c(NaN, Inf, -Inf, NA_real_)) {
              expect_false(.AcceptProposal(0, bad, 1), label = format(bad))
              expect_true(.AcceptProposal(bad, 0, 1), label = format(bad))
              for (bad2 in c(NaN, Inf, -Inf)) {
                expect_true(.AcceptProposal(bad, bad2, 1),
                            label = paste(format(bad), format(bad2)))
              }
            }
          })

# ── #2159: the C++ engine re-scores an imported state in full ───────────────

test_that("the C++ engine does not import a +Inf log posterior (#2159)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1,
    nIter = 10, nChains = 1, seed = 1, gradientProposals = "off",
    quiet = TRUE, visualise = FALSE, runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "imp", engine = "R"
  ))
  mcmcObj <- readRDS(file.path(td, "imp_mcmc_run_1.rds"))
  model <- readRDS(file.path(td, "imp_model.rds"))
  data <- readRDS(file.path(td, "imp_data.rds"))
  if (is.null(model$.logpost_cpp)) {
    model$.logpost_cpp <- .PrepareLogPostArgs(model)
  }
  state <- mcmcObj$recentState

  # A degenerate uniform at the chain's current value scores +Inf; the stored
  # log posterior is what an older build recorded for such a state.
  v <- unname(state[[1]]$metro$parameters[[1]])
  model$.logpost_cpp$priorTypes[[1]] <- "UniformPrior"
  model$.logpost_cpp$priorArgs[[1]] <- list(min = v, max = v)
  state[[1]]$metro$logPost <- Inf
  state[[1]]$metro$logPostSep[[1]] <- Inf

  eng <- .sb_create_engine(data = data, model = model, mcmc = mcmcObj,
                           state = state)
  metro <- .sb_extract_metro(eng)[[1]][["metro"]]
  expect_identical(metro[["logPost"]], -1e30)
})

# ── #2176: degenerate priors are refused, not scored NaN/+Inf ───────────────

test_that("a zero-scale bare Prior() fails validation (#2176)", {
  zeroSd <- Prior(rnorm, dnorm, qnorm, mean = 0, sd = 0)
  expect_error(
    .PriorsValidity(structure(list(a = zeroSd), class = c("StratPrior", "list"))),
    "non-finite"
  )
  expect_identical(.InferPriorType(zeroSd), "")
})

test_that(".InferPriorType promotes only valid scale arguments (#2176)", {
  expect_identical(.InferPriorType(Prior(rnorm, dnorm, qnorm, mean = 0,
                                         sd = 1)), "NormalPrior")
  expect_identical(.InferPriorType(Prior(rnorm, dnorm, qnorm, mean = 0,
                                         sd = -1)), "")
  expect_identical(.InferPriorType(Prior(rlnorm, dlnorm, qlnorm, meanlog = 0,
                                         sdlog = 0)), "")
  expect_identical(.InferPriorType(Prior(rexp, dexp, qexp, rate = 0)), "")
  expect_identical(.InferPriorType(Prior(rexp, dexp, qexp, rate = Inf)), "")
  expect_identical(.InferPriorType(Prior(runif, dunif, qunif, min = 1,
                                         max = 1)), "")
  expect_identical(.InferPriorType(Prior(runif, dunif, qunif, min = 0,
                                         max = 1)), "UniformPrior")
})

test_that("truncated priors refuse bounds that collapse in z-space (#2176)", {
  expect_error(TruncNormalPrior(1e17, 1, 1, 2), "truncation")
  expect_error(TruncLogNormalPrior(1e17, 1, 1, 2), "truncation")
  expect_s3_class(TruncNormalPrior(0, 1, 1, 2), "TruncNormalPrior")
  expect_s3_class(TruncLogNormalPrior(0, 1, 1, 2), "TruncLogNormalPrior")
})

# ── #2177: AutoPrior() agrees with StratModel() ─────────────────────────────

test_that("AutoPrior() accepts every alignmentScale spelling (#2177)", {
  data(stratData1, package = "StratoBayes", envir = environment())
  expect_identical(AutoPrior(stratData1, alignmentScale = "Height"),
                   AutoPrior(stratData1, alignmentScale = "height"))
})

test_that("AutoPrior() warns on a customPriors name it does not generate (#2177)",
          {
            data(stratData1, package = "StratoBayes", envir = environment())
            expect_warning(
              AutoPrior(stratData1,
                        customPriors = list(alpha_typo = NormalPrior(0, 1))),
              "alpha_typo"
            )
            nm <- names(AutoPrior(stratData1))[[1]]
            expect_no_warning(
              AutoPrior(stratData1,
                        customPriors = setNames(list(NormalPrior(0, 1)), nm))
            )
          })

test_that("equivalent typed and bare priors raise no priorsProposals warning (#2177)",
          {
            model <- list(
              priors = list(metro = list(a = NormalPrior(0, 1))),
              priorsProposals = list(a = Prior(rnorm, dnorm, qnorm,
                                               mean = 0, sd = 1))
            )
            expect_no_warning(.WarnPriorsProposalsIgnored(model, "cpp"))

            model$priorsProposals$a <- NormalPrior(0, 2)
            expect_warning(.WarnPriorsProposalsIgnored(model, "cpp"),
                           "ignored for built-in")
          })

# ── #2187: ratesRange bounds the log rate, not the log inverse rate ─────────

test_that("sedSmooth bounds the log rate by ratesRange (#2187)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  rr <- c(-0.05, 0.5)
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10, ratesRange = rr)
  mcmc <- StratMCMC(model, nChains = 1, nIter = 400)
  result <- suppressWarnings(RunStratModel(
    stratData1, model, mcmc, engine = "cpp", seed = 1, visualise = FALSE,
    quiet = TRUE, runParallel = FALSE, nThreads = 1L, modelDir = withr::local_tempdir()
  ))
  samples <- result[["samples"]]
  sedBetaCols <- grep("^sedBeta_", dimnames(samples)[[2]], value = TRUE)
  logRate <- -samples[, sedBetaCols, , , drop = TRUE]
  expect_true(all(is.finite(logRate)))
  expect_true(all(logRate >= rr[[1]] & logRate <= rr[[2]]))
  # The chain must actually explore, or the bound is never tested.
  expect_gt(max(logRate), 0.05)
})

test_that("a quantile on the support boundary does not fail validation (#2176)",
          {
            # qgamma(0.1, shape = 0.001) underflows to 0, where dgamma is +Inf.
            vague <- Prior(rgamma, dgamma, qgamma, shape = 0.001, rate = 1)
            expect_true(.PriorsValidity(
              structure(list(a = vague), class = c("StratPrior", "list"))
            ))
          })
