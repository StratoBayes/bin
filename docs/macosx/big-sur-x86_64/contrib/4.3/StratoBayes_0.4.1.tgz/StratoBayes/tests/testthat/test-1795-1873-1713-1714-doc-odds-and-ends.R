pkgDir <- testthat::test_path("..", "..")

test_that("#1795: ?StratoBayes example doesn't bind the name 'data'", {
  rFile <- file.path(pkgDir, "R", "StratoBayes-package.R")
  skip_if_not(file.exists(rFile),
              "R/ not found (not running against a source tree)")
  lines <- readLines(rFile)
  expect_false(any(grepl("^#'\\s*data\\s*<-\\s*StratData\\(", lines)))
})

test_that("#1873: REFERENCES.bib has no unused Vats2021 entry", {
  bibFile <- file.path(pkgDir, "inst", "REFERENCES.bib")
  skip_if_not(file.exists(bibFile),
              "inst/ not found (not running against a source tree)")
  bibText <- paste(readLines(bibFile), collapse = "\n")
  expect_false(grepl("Vats2021", bibText, fixed = TRUE))
})

test_that(paste0("#1713: maintainer email agrees between ",
                 "StratoBayes-package.R and DESCRIPTION"), {
            rFile <- file.path(pkgDir, "R", "StratoBayes-package.R")
            descFile <- file.path(pkgDir, "DESCRIPTION")
            skip_if_not(
              file.exists(rFile) && file.exists(descFile),
              "R/ or DESCRIPTION not found (not running against a source tree)"
            )

            pkgLines <- readLines(rFile)
            authorLine <- grep("Kilian Eichenseer", pkgLines, value = TRUE)[1]
            rdEmail <- sub(".*Kilian Eichenseer \\(\\\\email\\{([^}]*)\\}.*",
                           "\\1",
                           authorLine)

            descLines <- readLines(descFile)
            creIdx <- grep('role = c\\("aut", "cre"', descLines)
            descEmail <- sub('.*email = "([^"]*)".*', "\\1",
                             descLines[creIdx + 1])

            expect_identical(rdEmail, descEmail)
          })

test_that(paste0("#1714: Signal-offsets.qmd Example 2 uses enough iterations ",
                 "to avoid the adaptation warning"), {
            vignDir <- testthat::test_path("..", "..", "vignettes")
            skip_if_not(dir.exists(vignDir),
                        paste0("vignettes/ not found (not running against a ",
                               "source tree)"))
            lines <- readLines(file.path(vignDir, "Signal-offsets.qmd"))
            iterLine <- grep("^\\s*nIter\\s*=\\s*3000\\s*,?\\s*$", lines,
                             value = TRUE)
            expect_length(iterLine, 0)
          })
