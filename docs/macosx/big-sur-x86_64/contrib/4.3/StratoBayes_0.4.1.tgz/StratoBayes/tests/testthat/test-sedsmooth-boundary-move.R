# The boundary-relocation move accepts on pi(x') / pi(x). That is the MH ratio
# only if, for each target, the map x -> x' is volume-preserving (|det J| = 1)
# and a step of -delta undoes a step of delta (the step density is symmetric).
# These tests pin both, and that each target moves exactly one mapped boundary.

BoundaryMoveFixture <- function() {
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  td <- tempfile("sedbound")
  dir.create(td)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bound"
  ))
  mcmc <- readRDS(file.path(td, "bound_mcmc_run_1.rds"))
  unlink(td, recursive = TRUE)
  model <- result$model
  model$sedSmoothInfo$boundaryMove <- list(prob = 0)
  model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  state <- mcmc$recentState[[1]]
  # Give every formation a non-constant shape, so the alpha offset inside its
  # formation (rho) and the thicknesses are not trivial.
  set.seed(2)
  state$gibbs$sedBeta <- state$gibbs$sedBeta +
    stats::rnorm(length(state$gibbs$sedBeta), 0, 0.3)
  list(data = result$data, model = model, state = state)
}

EngineAt <- function(fx, params, sedBeta) {
  s <- fx$state
  s$metro$parameters <- params
  s$gibbs$sedBeta <- sedBeta
  StratoBayes:::.HMCCreateEngine(fx$data, fx$model, s)
}

MappedBoundaries <- function(fx, params, sedBeta, site) {
  ssi <- fx$model$sedSmoothInfo
  fs <- ssi$betaMap[, site]
  fs <- fs[!is.na(fs)]
  h <- c(ssi$formations[[fs[1]]]$hLow,
         vapply(ssi$formations[fs], `[[`, numeric(1), "hHigh"))
  StratoBayes:::.AgeConversionBatch(matrix(params, 1), h, site, fx$data,
                                    fx$model$ind, ssi, matrix(sedBeta, 1))[, 1]
}

test_that("boundary move: one boundary moves, inverse step, unit Jacobian", {
  skip_on_cran()
  fx <- BoundaryMoveFixture()
  p0 <- fx$state$metro$parameters
  b0 <- fx$state$gibbs$sedBeta
  e0 <- EngineAt(fx, p0, b0)
  targets <- StratoBayes:::.sb_sed_boundary_stats(e0)$targets
  expect_gt(nrow(targets), 0L)
  expect_true(all(targets[, 2] %in% 0:2))
  ssi <- fx$model$sedSmoothInfo
  delta <- 0.6

  for (i in seq_len(nrow(targets))) {
    site <- targets[i, 1]
    kind <- targets[i, 2]
    prop <- StratoBayes:::.sb_sed_boundary_probe(e0, 1L, i, delta)
    expect_true(prop$ok)

    moved <- MappedBoundaries(fx, prop$parameters, prop$sedBeta, site) -
      MappedBoundaries(fx, p0, b0, site)
    nForm <- sum(!is.na(ssi$betaMap[, site]))
    # boundary index (1-based) of the moved boundary within the site
    mapped <- which(!is.na(ssi$betaMap[, site]))
    mv <- switch(kind + 1L, match(targets[i, 3], mapped) + 1L, 1L, nForm + 1L)
    expect_gt(abs(moved[mv]), 1e-6)
    expect_lt(max(abs(moved[-mv])), 1e-6 * max(1, abs(moved[mv])))

    eBack <- EngineAt(fx, prop$parameters, prop$sedBeta)
    back <- StratoBayes:::.sb_sed_boundary_probe(eBack, 1L, i, -delta)
    expect_equal(back$parameters, p0, tolerance = 1e-10)
    expect_equal(back$sedBeta, b0, tolerance = 1e-10)

    # Jacobian over the coordinates the map can change: the site's alpha and
    # the coefficients of the formations of partitions bLow..bHigh.
    fs <- ssi$betaMap[targets[i, 3]:targets[i, 4], site]
    fs <- fs[!is.na(fs)]
    bi <- unlist(lapply(fs, function(f) ssi$betaStart[f] + 0:(ssi$nBasis - 1)))
    ai <- site - 1L
    x0 <- c(p0[ai], b0[bi])
    Map1 <- function(x) {
      p <- p0
      b <- b0
      p[ai] <- x[1]
      b[bi] <- x[-1]
      e <- EngineAt(fx, p, b)
      o <- StratoBayes:::.sb_sed_boundary_probe(e, 1L, i, delta)
      c(o$parameters[ai], o$sedBeta[bi])
    }
    h <- 1e-5
    J <- vapply(seq_along(x0), function(k) {
      e <- replace(numeric(length(x0)), k, h)
      (Map1(x0 + e) - Map1(x0 - e)) / (2 * h)
    }, numeric(length(x0)))
    expect_equal(abs(det(J)), 1, tolerance = 1e-6)
  }
})

test_that("boundary move runs in the sampler and records its counts", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  sModel$sedSmoothInfo$boundaryMove <- list(prob = 1, rwSd = 0.5,
                                            unifWidth = 8, pUnif = 0.5,
                                            includeCold = TRUE)
  td <- tempfile("sedbound")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 300, nChains = 2L, seed = 3, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bound"
  ))
  stats <- readRDS(file.path(td, "bound_mcmc_run_1.rds"))$sedBoundaryStats
  expect_true(stats$active)
  expect_equal(dim(stats$counts), c(2L, 2L))
  expect_true(all(stats$counts[, 1] > 250))
  expect_true(all(stats$counts[, 2] > 0))
  expect_true(all(stats$counts[, 2] <= stats$counts[, 1]))
})

test_that("boundary move settings are validated before the engine is built", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  RunWith <- function(bm) {
    m <- sModel
    m$sedSmoothInfo$boundaryMove <- bm
    td <- tempfile("sedbound")
    dir.create(td)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)
    suppressWarnings(RunStratModel(
      stratObject = stratData1, stratModel = m, nIter = 5, nChains = 1L,
      seed = 1, nThreads = 1L, quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = "bound"
    ))
  }
  expect_error(RunWith(list(includeCold = NA)), "includeCold must be TRUE")
  expect_error(RunWith(list(adapt = 1)), "adapt must be TRUE or FALSE")
  expect_error(RunWith(list(targetAccept = 1)), "targetAccept must be")
  expect_error(RunWith(list(prob = 2)), "prob must lie in \\[0, 1\\]")
  expect_error(RunWith(list(prob = 1, rwSd = -1)), "rwSd must be positive")
  expect_error(RunWith(list(prob = 1, pUnif = "a")), "pUnif must be a single")
})

test_that("boundary move defaults: hot rungs only, at probability 0.2", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  sModel$sedSmoothInfo$boundaryMove <- list()
  td <- tempfile("sedbound")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 1000, nChains = 3L, seed = 4, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bound"
  ))
  m <- readRDS(file.path(td, "bound_mcmc_run_1.rds"))
  temps <- m$temper$temperatures
  expect_equal(temps[1], 1)
  expect_true(all(temps[-1] > 1))
  counts <- m$sedBoundaryStats$counts
  expect_equal(counts[1, ], c(0, 0))
  # About 0.2 * 1000 attempts on each hot rung.
  expect_true(all(counts[-1, 1] > 120 & counts[-1, 1] < 280))
})

test_that("boundary move step sds adapt, then hold once adaptation stops", {
  skip_on_cran()
  fx <- BoundaryMoveFixture()
  fx$model$sedSmoothInfo$boundaryMove <- list(prob = 1, rwSd = 0.5)
  e <- EngineAt(fx, fx$state$metro$parameters, fx$state$gibbs$sedBeta)
  Sds <- function() StratoBayes:::.sb_sed_boundary_stats(e)$rwSd
  expect_equal(unname(Sds()), matrix(0.5, 1, 2))
  StratoBayes:::.sb_run_block(e, 300L)
  adapted <- Sds()
  st <- StratoBayes:::.sb_sed_boundary_stats(e)
  expect_true(st$adapt)
  # Every kind with targets has moved off its initial sd.
  hasKind <- c(any(st$targets[, 2] != 0), any(st$targets[, 2] == 0))
  expect_true(all(adapted[1, hasKind] != 0.5))

  StratoBayes:::.sb_sed_boundary_set_adapt(e, FALSE)
  StratoBayes:::.sb_run_block(e, 300L)
  st <- StratoBayes:::.sb_sed_boundary_stats(e)
  expect_false(st$adapt)
  expect_identical(st$rwSd, adapted)
  expect_gt(st$counts[1, 1], 500)
  expect_error(StratoBayes:::.sb_sed_boundary_set_adapt(e, NA),
               "adapt must be TRUE or FALSE")

  StratoBayes:::.sb_sed_boundary_set_sd(e, matrix(c(0.2, 0.3), 1))
  expect_equal(unname(Sds()), matrix(c(0.2, 0.3), 1))
  expect_error(StratoBayes:::.sb_sed_boundary_set_sd(e, matrix(0.2, 2, 2)),
               "one row per chain")
  expect_error(StratoBayes:::.sb_sed_boundary_set_sd(e, matrix(-1, 1, 2)),
               "positive and finite")
})

test_that("RunStratModel freezes step sds at endAdapting and resumes them", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes")
  sModel <- StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  sModel$sedSmoothInfo$boundaryMove <- list(prob = 1)
  td <- tempfile("sedbound")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  run1 <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 400, endAdapting = 200, convergenceStop = FALSE,
    nChains = 2L, seed = 5, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bound"
  ))
  f <- file.path(td, "bound_mcmc_run_1.rds")
  s1 <- readRDS(f)$sedBoundaryStats
  expect_false(s1$adapt)
  expect_true(any(s1$rwSd != 0.5))

  suppressWarnings(RunStratModel(run1, nIter = 100, quiet = TRUE,
                                 visualise = FALSE, nThreads = 1L))
  s2 <- readRDS(f)$sedBoundaryStats
  expect_false(s2$adapt)
  expect_identical(s2$rwSd, s1$rwSd)
  expect_gt(sum(s2$counts[, 1]), 0)
})

BoundaryStatsFor <- function(dataName, boundaryMove, engine = "cpp") {
  e <- new.env()
  data(list = dataName, package = "StratoBayes", envir = e)
  sd <- get(dataName, envir = e)
  sModel <- StratModel(sd, priors = AutoPrior(sd, "height"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE)
  sModel$sedSmoothInfo["boundaryMove"] <- list(boundaryMove)
  td <- tempfile("sedbound")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  suppressMessages(suppressWarnings(RunStratModel(
    stratObject = sd, stratModel = sModel, engine = engine,
    nIter = 200, nChains = 2L, seed = 6, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "bound"
  )))
  readRDS(file.path(td, "bound_mcmc_run_1.rds"))$sedBoundaryStats
}

test_that("boundary move is on by default only with a shared boundary", {
  skip_on_cran()
  multi <- BoundaryStatsFor("stratData4", NULL)
  expect_true(multi$active)
  expect_true(any(multi$targets[, 2] == 0))
  # Free-end targets stay in, beside the shared boundaries.
  expect_true(any(multi$targets[, 2] != 0))
  expect_gt(sum(multi$counts[, 1]), 0)

  expect_null(BoundaryStatsFor("stratData1", NULL))
})

test_that("boundaryMove = FALSE turns the move off; TRUE or a list forces it", {
  skip_on_cran()
  expect_null(BoundaryStatsFor("stratData4", FALSE))
  for (bm in list(TRUE, list())) {
    single <- BoundaryStatsFor("stratData1", bm)
    expect_true(single$active)
    expect_true(all(single$targets[, 2] != 0))
    expect_gt(sum(single$counts[, 1]), 0)
  }
  expect_error(BoundaryStatsFor("stratData1", NA),
               "boundaryMove must be TRUE, FALSE or a list")
})

test_that("engine = \"R\" runs the default move through the C++ engine", {
  skip_on_cran()
  # sedSmooth is C++-only (Tier 3) and switches engine = "R" to "cpp", which
  # carries the move with it.
  stats <- BoundaryStatsFor("stratData4", NULL, engine = "R")
  expect_true(stats$active)
  expect_gt(sum(stats$counts[, 1]), 0)
})
