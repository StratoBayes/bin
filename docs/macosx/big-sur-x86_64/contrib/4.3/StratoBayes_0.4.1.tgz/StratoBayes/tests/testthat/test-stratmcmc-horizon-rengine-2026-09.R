# #2166: with no adaptation window, `startMonitoring` was derived from
# `endIter`, which is `Inf` for an unbounded run, so it was `NaN` and the loop
# errored on its first iteration.
data(stratData1, package = "StratoBayes", envir = environment())
data(stratModel1, package = "StratoBayes", envir = environment())

.RunUnbounded <- function(stratObject, ...) {
  suppressWarnings(RunStratModel(
    stratObject, ..., timeLimit = 1 / 3600, convergenceStop = FALSE,
    quiet = TRUE, visualise = FALSE, runParallel = FALSE, nThreads = 1L
  ))
}

test_that("an unbounded run without adaptation starts monitoring (#2166)", {
  mcmc <- StratMCMC(stratModel1, adaptProposal = FALSE, nChains = 1)
  expect_identical(
    mcmc[[c("metro", "acceptanceMonitor", "startMonitoring")]],
    2
  )
})

test_that("a collapsed window monitors from an interval boundary (#2166)", {
  mcmc <- StratMCMC(stratModel1, nIter = 3000, startAdapting = 1000,
                    endAdapting = 1000, adaptProposalInterval = 7,
                    nChains = 1)
  expect_identical(
    mcmc[[c("metro", "acceptanceMonitor", "startMonitoring")]],
    2002
  )
})

test_that("an unbounded run without adaptation completes (#2166)", {
  skip_on_cran()
  post <- .RunUnbounded(stratData1, stratModel1, adaptProposal = FALSE,
                        nChains = 1, modelDir = withr::local_tempdir())
  expect_s3_class(post, "StratPosterior")
})

test_that("a run without adaptation continues unbounded (#2166)", {
  skip_on_cran()
  fixed <- suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 50, adaptProposal = FALSE, nChains = 1,
    convergenceStop = FALSE, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L, modelDir = withr::local_tempdir()
  ))
  expect_s3_class(.RunUnbounded(fixed), "StratPosterior")
})

test_that("a run stopped before adapting continues unbounded (#2166)", {
  skip_on_cran()
  td <- withr::local_tempdir()
  # A store this small stops the run long before `startAdapting`, collapsing
  # the window the continuation inherits. A finite run this certain to fill is
  # refused up front (#2214), so that check is mocked away to reach the stop.
  withr::local_options(StratoBayes.maxStore = 200)
  local_mocked_bindings(.CheckFiniteStoreFits = function(...) invisible(NULL))
  early <- suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 20000, startAdapting = 19000,
    endAdapting = 19500, nChains = 1, convergenceStop = FALSE, quiet = TRUE,
    visualise = FALSE, runParallel = FALSE, nThreads = 1L,
    modelDir = td, modelName = "early"
  ))
  stopped <- readRDS(file.path(td, "early_mcmc_run_1.rds"))
  expect_lt(stopped[["completedIter"]], 19000)
  expect_s3_class(.RunUnbounded(early), "StratPosterior")
})

# #2150: with `clustWithParametersMCMC = FALSE` the chain history's heights
# went through the constant-rate conversion, which ignores `sedBeta`, so a
# sedSmooth run clustered on NA or fabricated heights without a word.
.SedSmoothModel <- function() {
  StratModel(stratData1, priors = AutoPrior(stratData1, "height"),
             alignmentScale = "height", sedModel = "site, partition",
             sedSmooth = TRUE, flexibleKnots = FALSE, knotRange = c(-5, 12))
}

test_that("StratMCMC() refuses height clustering with sedSmooth (#2150)", {
  sModel <- .SedSmoothModel()
  expect_error(
    StratMCMC(sModel, nIter = 10, nChains = 1,
              clustWithParametersMCMC = FALSE),
    "clustWithParametersMCMC = FALSE.*sedSmooth"
  )
  expect_s3_class(StratMCMC(sModel, nIter = 10, nChains = 1), "StratMCMC")
})

test_that(".CalculateNewAges() refuses a sedSmooth model (#2150)", {
  sModel <- .SedSmoothModel()
  heights <- sort(sModel[["heightsForClustering"]][[2]])
  expect_error(
    .CalculateNewAges(stratData1, sModel[["ind"]],
                      rep(1, sModel[["parametersLength"]]), 2, heights),
    "sedSmooth"
  )
})

# #2132: with one free parameter, `rbind(scalar, 1 x K)` recycled the scalar
# into a 2 x K matrix, so the R engine always chose cluster 1.
test_that("Multivariate finds the nearest cluster with p = 1 (#2132)", {
  model <- list(ind = list(paramNotFixed = 2L), parametersLengthNotFixed = 1L)
  clusters <- list(list(0, matrix(1)), list(5, matrix(2)), list(9, matrix(3)))
  Sigma <- function(x) {
    .MultivariateProposalSigma(c(100, x), clusters, 1, 1, model)[1, 1]
  }
  expect_equal(Sigma(0.5), 1 + 1e-10)
  expect_equal(Sigma(5.5), 2 + 1e-10)
  expect_equal(Sigma(8), 3 + 1e-10)
})

test_that("a continuation does not share the source's .hmcDA (#2132)", {
  # Untuned NUTS is set up at construction, so its `.hmcDA` exists already.
  mcmc <- suppressWarnings(StratMCMC(
    stratModel1, nIter = 20, nChains = 2, gradientProposals = "on",
    adaptProposal = FALSE
  ))
  mcmcNew <- StratMCMC(stratModel1, nIter = 20, nChains = 2,
                       gradientProposals = "on")
  gradProp <- which(names(mcmc[["propose"]]) %in% c("HMC", "NUTS"))
  Da <- function(m, chain) {
    m[[c("metro", "proposalArgs")]][[chain]][[gradProp]][[".hmcDA"]]
  }
  expect_true(is.environment(Da(mcmc, 1)))

  continued <- .UpdateMCMCforContinuedRun(mcmc, mcmcNew, newRun = FALSE)
  before <- as.list(Da(mcmc, 1), all.names = TRUE)
  for (chain in 1:2) {
    expect_false(identical(Da(continued, chain), Da(mcmc, chain)))
    # Any other parent would drag the caller's frame into every checkpoint.
    expect_identical(parent.env(Da(continued, chain)), emptyenv())
    assign("stepSize", 123, envir = Da(continued, chain))
  }
  expect_identical(as.list(Da(mcmc, 1), all.names = TRUE), before)
  expect_identical(
    sort(names(as.list(Da(continued, 1), all.names = TRUE))),
    sort(names(before))
  )
})
