# Prior-derived proposal scales and starting values must stay finite, and
# follow the prior's own scale, whatever argument names the prior carries.

data(stratModel1, package = "StratoBayes", envir = environment())

.WithAlphaPrior <- function(prior, param = "alpha_site_3") {
  model <- stratModel1
  model[[c("priors", "metro")]][[param]] <- prior
  model
}

.ProposalArgs <- function(mcmc, type) {
  mcmc[[c("metro", "proposalArgs")]][[1]][[type]]
}

test_that("NeighbourScaled SDs are finite for a one-sided prior (#1842)", {
  model <- .WithAlphaPrior(TruncNormalPrior(0, 1, 0, Inf))
  mcmc <- StratMCMC(model, nIter = 100, nChains = 1, nThreads = 2L)
  nsArgs <- .ProposalArgs(mcmc, "NeighbourScaled")

  expect_true(all(is.finite(nsArgs)))
  expect_equal(nsArgs, .PriorRanges(model) / 8)
})

test_that("Univariate SDs are finite for a one-sided prior (#1567)", {
  model <- .WithAlphaPrior(TruncNormalPrior(0, 1, 0, Inf))
  mcmc <- StratMCMC(model, nIter = 100, nChains = 1, nThreads = 2L,
                    adaptProposal = FALSE)
  uvArgs <- .ProposalArgs(mcmc, "Univariate")

  expect_true(all(is.finite(uvArgs)))
  expect_equal(uvArgs, .PriorRangeSDs(model))
})

test_that("bounded priors keep their exact prior-range SDs (#1567)", {
  mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 1, nThreads = 2L,
                    adaptProposal = FALSE)
  alphaIdx <- stratModel1[[c("ind", "alpha")]]
  # stratModel1's alphas are UniformPrior(min = 0, max = 18).
  expect_equal(.ProposalArgs(mcmc, "NeighbourScaled")[alphaIdx],
               rep(18 / 8, length(alphaIdx)))
  expect_equal(.ProposalArgs(mcmc, "Univariate")[alphaIdx],
               rep(0.01 * 18, length(alphaIdx)))
})

test_that(".PriorRanges() follows the scale of unbounded priors (#1843)", {
  model <- .WithAlphaPrior(ExponentialPrior(rate = 0.01))
  gammaIdx <- stratModel1[[c("ind", "gamma")]]
  prior <- stratModel1[[c("priors", "metro")]][[gammaIdx[[1]]]]
  m <- prior[["args"]][["mean"]]
  s <- prior[["args"]][["sd"]]
  ranges <- .PriorRanges(model)

  expect_equal(ranges[[2]], qexp(0.995, 0.01) - qexp(0.005, 0.01))
  expect_equal(ranges[[gammaIdx[[1]]]],
               qnorm(0.995, m, s) - qnorm(0.005, m, s))
})

test_that("a Fixed prior still takes the unit backstop (#1843)", {
  model <- .WithAlphaPrior(Fixed(3))
  expect_equal(.PriorRanges(model)[[2]], 1)
})

test_that("overlap-aware initialisation covers every prior family (#1939)", {
  for (prior in list(TruncNormalPrior(0, 1, 0, Inf),
                     UniformPrior(min = 0, max = 18),
                     NormalPrior(9, 4))) {
    model <- .WithAlphaPrior(prior)
    q <- prior[["Q"]]
    lo <- do.call(q, c(p = 0.025, prior[["args"]]))
    hi <- do.call(q, c(p = 0.975, prior[["args"]]))
    draws <- replicate(200L, .AutoParametersInitial(model)[[2]])

    # A plain prior draw leaves the central 95% one time in twenty, so 200
    # draws all inside it would be a 3e-5 coincidence.
    expect_true(all(draws >= lo & draws <= hi))
  }
})

test_that("overlap-aware initialisation leaves a Fixed alpha alone (#1939)", {
  model <- .WithAlphaPrior(Fixed(3))
  model[["priorsProposals"]][["alpha_site_3"]] <- Fixed(3)
  model[[c("ind", "paramNotFixed")]] <-
    setdiff(model[[c("ind", "paramNotFixed")]], 2L)
  expect_equal(.AutoParametersInitial(model)[[2]], 3)
})
