test_that("auto burn-in fallback keeps to the adaptation floor", {
  result <- .AutoBurnInCore(
    list(), list(seq(100, 10000, 100), seq(1, 5050, 1)), floorIter = 5001
  )
  expect_equal(result[["iteration"]], 5001)

  set.seed(2252)
  iters <- list(c(1, seq(10, 3600, 10)), c(1, seq(10, 1610, 10)))
  draws <- lapply(iters, function(it) {
    matrix(rnorm(2 * length(it)), ncol = 2, dimnames = list(NULL, c("a", "b")))
  })
  result <- .AutoBurnInCore(draws, iters, floorIter = 1602)
  expect_equal(result[["status"]], "insufficientDraws")
  expect_equal(result[["iteration"]], 1602)
})

test_that("an NA no candidate retains does not block the search", {
  set.seed(2255)
  iters <- list(1:10000, 1:10000)
  draws <- lapply(iters, function(it) {
    matrix(rnorm(2 * length(it)), ncol = 2, dimnames = list(NULL, c("a", "b")))
  })
  # Decimated with stride 5, the lattice holds 5001 and 5006; floor 5002
  # snaps up to 5006, so iteration 5004 is below every candidate.
  draws[[1]][5004, 1] <- NA
  result <- .AutoBurnInCore(draws, iters, floorIter = 5002, rHatMax = Inf)
  expect_equal(result[["status"]], "ok")
  expect_gte(result[["iteration"]], 5006)

  draws[[1]][5010, 1] <- NA
  result <- .AutoBurnInCore(draws, iters, floorIter = 5002, rHatMax = Inf)
  expect_equal(result[["status"]], "nonFiniteDraws")
})

test_that(".PersistedRHatMax() takes the strictest ceiling of any run", {
  Posterior <- function(criteria) {
    list(mcmcSummary = list(convergenceCriteria = criteria))
  }
  expect_equal(
    .PersistedRHatMax(Posterior(list(list(rHat = 1.05), list(rHat = 1.01)))),
    1.01
  )
  withr::local_options(StratoBayes.rHatMax = 1.1)
  expect_equal(
    .PersistedRHatMax(Posterior(list(list(ess = 100), list(rHat = 1.03)))),
    1.03
  )
  expect_equal(.PersistedRHatMax(Posterior(list(list(rHat = 1.04)))), 1.04)
  expect_equal(.PersistedRHatMax(Posterior(list(NULL, NULL))), 1.1)
  expect_equal(.PersistedRHatMax(Posterior(NULL)), 1.1)
})

test_that("a thin run beside a longer one does not certify a candidate", {
  set.seed(2257)
  Draws <- function(n) {
    matrix(rnorm(2 * n), ncol = 2, dimnames = list(NULL, c("a", "b")))
  }
  Search <- function(lengths, ...) {
    .AutoBurnInCore(
      lapply(lengths, Draws), lapply(lengths, seq_len), rHatMax = Inf, ...
    )
  }
  for (short in c(8L, 30L, 49L)) {
    expect_equal(Search(c(1000L, short))[["status"]], "insufficientDraws")
  }

  result <- Search(c(1000L, 1000L, 30L))
  expect_equal(result[["status"]], "ok")
  expect_equal(result[["nRunUsed"]], 2L)
  expect_equal(result[["nRunDropped"]], 1L)

  result <- Search(c(1000L, 50L))
  expect_equal(result[["status"]], "ok")
  expect_equal(result[["nRunUsed"]], 2L)
  expect_equal(result[["minRunRows"]], 50L)
  expect_match(
    .AutoBurnInMessage(result), "shortest run keeps 50 draws", fixed = TRUE
  )

  result <- Search(c(1000L, 50L), stopAtFirst = TRUE)
  expect_equal(result[["status"]], "ok")
  expect_equal(result[["minRunRows"]], 50L)

  # Kept rows too few to test veto the candidate, rather than being retained
  # unassessed.
  lengths <- c(1000L, 1000L, 30L)
  draws <- lapply(lengths, Draws)
  draws[[3]] <- draws[[3]] + 3
  result <- .AutoBurnInCore(draws, lapply(lengths, seq_len), grid = 0)
  expect_equal(result[["status"]], "insufficientDraws")
  result <- .AutoBurnInCore(draws, lapply(lengths, seq_len))
  expect_equal(result[["status"]], "ok")
  expect_gte(result[["iteration"]], 30)

  # Runs that all keep fewer rows are judged as before.
  for (short in list(c(30L, 30L), c(45L, 44L))) {
    result <- Search(short)
    expect_equal(result[["status"]], "ok")
    expect_equal(result[["nRunUsed"]], 2L)
  }
})

test_that("the screen never reaches back into adaptation", {
  set.seed(1601)
  iters <- list(1:9996, 1:9996)
  draws <- lapply(iters, function(it) {
    matrix(rnorm(length(it)), ncol = 1, dimnames = list(NULL, "a"))
  })
  draws[[1]][100, 1] <- NA
  result <- .AutoBurnInCore(draws, iters, floorIter = 9993)
  expect_equal(result[["status"]], "insufficientDraws")
})

test_that("a cached choice from an earlier rule is recomputed", {
  post <- stratPosterior1
  fresh <- .AutoBurnIn(post)
  cache <- .PosteriorCache(post)
  cache$autoBurnIn <- modifyList(fresh, list(iteration = 0))
  cache$autoBurnInRule <- NULL
  expect_equal(.AutoBurnIn(post)[["iteration"]], fresh[["iteration"]])
})

test_that("a marginally offset thin run is rarely certified", {
  expect_gte(.kAutoBurnInMinSurvivorRows, 50L)
  certified <- vapply(seq_len(50), function(i) {
    set.seed(i)
    nB <- sample(8:16, 1)
    draws <- list(
      cbind(a = rnorm(1000), b = rnorm(1000)),
      cbind(a = rnorm(nB, 0.5), b = rnorm(nB, 0.5))
    )
    result <- .AutoBurnInCore(draws, list(seq_len(1000), seq_len(nB)))
    identical(result[["status"]], "ok") && result[["iteration"]] < nB
  }, logical(1))
  expect_lt(sum(certified), 3)
})
