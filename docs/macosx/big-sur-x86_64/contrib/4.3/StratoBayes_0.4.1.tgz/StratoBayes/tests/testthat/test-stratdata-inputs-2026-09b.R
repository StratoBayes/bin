tiesInput <- function(...) {
  data.frame(
    site = "b", height = 5, densityFun = "dnorm", ...,
    stringsAsFactors = FALSE
  )
}
tiesSignal <- data.frame(
  site = rep(c("a", "b"), each = 4),
  height = rep(c(0, 4, 8, 12), 2),
  value = seq_len(8)
)

test_that("Stray arg columns in ties are rejected (#2203)", {
  for (bad in c("arg0", "arg00", "arg01")) {
    ties <- tiesInput(arg1 = 30, arg2 = 0.2)
    ties[[bad]] <- NA_real_
    expect_error(StratData(tiesSignal, ties = ties), bad, fixed = TRUE)
  }
  ok <- StratData(tiesSignal, ties = tiesInput(arg1 = 30, arg2 = 0.2))
  expect_true(all(c("arg1", "arg2") %in% names(ok$tiesAttr)))
})

test_that("A named parameter vector is reordered by name (#2204)", {
  expect_equal(
    unlist(.ValidateParams(c(b = 2, a = 1), 2, NULL, paramNames = c("a", "b"))),
    c(a = 1, b = 2)
  )
  expect_warning(
    .ValidateParams(c(x = 2, y = 1), 2, NULL, paramNames = c("a", "b")),
    "do not match"
  )
})

test_that("Site IDs keep leading zeros (#2205.1)", {
  csv <- tempfile(fileext = ".csv")
  on.exit(unlink(csv))
  write.csv(
    data.frame(
      site = rep(c("0500106234", "0500106235"), each = 3),
      height = rep(1:3, 2), value = 1:6
    ),
    csv, row.names = FALSE
  )
  sd <- StratData(csv)
  expect_true(all(c("0500106234", "0500106235") %in% sd$signal$site))
})

test_that("Duplicate NA gap rows are collapsed (#2205.2)", {
  parts <- data.frame(
    site = c("a", "a", "a", "a", "b"),
    height = c(4, 8, 8, 12, 12),
    partition = c("p1", NA, NA, "p2", "p1")
  )
  sd <- StratData(tiesSignal, parts = parts)
  expect_equal(sum(is.na(sd$parts$sedRates[sd$parts$site == "a"])), 1)
})

test_that("ThinSignal accepts a data.table (#2205.3)", {
  skip_if_not_installed("data.table")
  dt <- data.table::as.data.table(tiesSignal)
  expect_no_error(ThinSignal(dt, blockLength = 4))
})

test_that("Duplicate CSV headers are rejected (#2205.4)", {
  csv <- tempfile(fileext = ".csv")
  on.exit(unlink(csv))
  writeLines(c("site,height,value,value", "a,1,1,9", "a,2,2,9", "b,1,1,9", "b,2,2,9"), csv)
  expect_error(StratData(csv), "duplicate", ignore.case = TRUE)
  partsCsv <- tempfile(fileext = ".csv")
  on.exit(unlink(partsCsv), add = TRUE)
  writeLines(c("site,height,partition,partition", "a,12,p1,p1", "b,12,p1,p1"), partsCsv)
  expect_error(StratData(tiesSignal, parts = partsCsv), "duplicate",
               ignore.case = TRUE)
})

test_that("Column arguments must be single strings (#2205.5)", {
  expect_error(StratData(tiesSignal, zColumn = c("height", "site")),
               "zColumn.*single")
  expect_error(StratData(tiesSignal, siteColumn = NA_character_),
               "siteColumn.*single")
  expect_error(StratData(tiesSignal, signalColumn = "site"),
               "signalColumn.*siteColumn")
})

test_that("Blank trailing headers and absent ID columns are tolerated", {
  csv <- tempfile(fileext = ".csv")
  on.exit(unlink(csv))
  writeLines(c("site,height,value,,", "a,1,1,,", "a,2,2,,", "b,1,1,,",
               "b,2,2,,"), csv)
  expect_no_error(StratData(csv))
  writeLines(c("height,value", "1,1"), csv)
  expect_no_warning(try(StratData(csv), silent = TRUE))
})
