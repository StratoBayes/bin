MakeRunData <- function(iterations, offset = 0, nParams = 2L) {
  cbind(iteration = iterations, chain = 1,
        matrix(iterations + offset, nrow = length(iterations),
               ncol = nParams))
}

test_that("#1570: live-plot slices are labelled by run identity", {
  run2 <- MakeRunData(c(10, 20), offset = 0.2)
  run3 <- MakeRunData(c(10, 20, 30), offset = 0.3)
  arr <- StratoBayes:::.SamplesArrayFromRunListDuringMCMC(
    list(FALSE, run2, run3), c("a", "b"))

  expect_equal(dimnames(arr)[["runs"]], c("run1", "run2", "run3"))
  expect_true(all(is.na(arr[, , "run1", 1])))
  expect_equal(arr[1, "a", "run2", 1], 10.2)
  expect_equal(arr[3, "a", "run3", 1], 30.3)
})

test_that("#1573: duplicate iteration labels keep the latest row", {
  stale <- MakeRunData(c(10, 20, 10, 20, 30))
  stale[3, 3] <- 99
  arr <- expect_no_error(
    StratoBayes:::.SamplesArrayFromRunListDuringMCMC(list(stale), c("a", "b"))
  )
  expect_equal(dim(arr)[[1]], 3L)
  expect_setequal(arr[, "iteration", 1, 1], c(10, 20, 30))
  expect_equal(arr[arr[, "iteration", 1, 1] == 10, "a", 1, 1], 99)
})

test_that("#1571: a single saved iteration keeps every column", {
  samples <- array(c(1.5, 2.5), dim = c(1, 2, 1, 1),
                   dimnames = list(NULL, c("a", "b"), NULL, NULL))
  frame <- StratoBayes:::.ChainSampleFrame(10, 1L, samples[, , 1, 1,
                                                            drop = FALSE])
  expect_equal(dim(frame), c(1L, 4L))
  expect_equal(names(frame), c("iteration", "chain", "a", "b"))
  expect_equal(frame[["b"]], 2.5)
})

test_that("#1678: a reordered visualise list is matched by name", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  checked <- StratoBayes:::.CheckVisualise(
    list(interval = 100, parameter = 1:2, signal = 1),
    stratData1, stratModel1)
  expect_equal(checked[["signal"]], 1)
  expect_equal(checked[["parameter"]], 1:2)

  positional <- StratoBayes:::.CheckVisualise(
    list(50, 1, 1:2), stratData1, stratModel1)
  expect_equal(positional[["interval"]], 50)
  expect_equal(positional[["parameter"]], 1:2)
})

test_that("#2333: a visualise parameter can be given by name", {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  outputParams <- stratModel1[["outputParams"]]
  checked <- StratoBayes:::.CheckVisualise(
    list(100, 1, outputParams[c(3, 1)]), stratData1, stratModel1)
  expect_equal(checked[["parameter"]], c(3, 1))
  expect_error(
    StratoBayes:::.CheckVisualise(
      list(100, 1, "notAParameter"), stratData1, stratModel1),
    "'parameter' with indices or names"
  )
})

test_that("#1677: a failed replacement leaves the old file in place", {
  dir <- withr::local_tempdir()
  to <- file.path(dir, "checkpoint.rds")
  from <- paste0(to, ".tmp")
  saveRDS("old", to)
  saveRDS("new", from)

  testthat::local_mocked_bindings(
    file.rename = function(from, to) FALSE,
    file.copy = function(from, to, overwrite = FALSE) FALSE,
    .package = "base"
  )
  expect_warning(StratoBayes:::.ReplaceFile(from, to), "Could not replace")
  expect_equal(readRDS(to), "old")
  expect_true(file.exists(from))
})

test_that("#1677: the copy fallback removes the temp file only on success", {
  dir <- withr::local_tempdir()
  to <- file.path(dir, "checkpoint.rds")
  from <- paste0(to, ".tmp")
  saveRDS("old", to)
  saveRDS("new", from)

  testthat::local_mocked_bindings(
    file.rename = function(from, to) FALSE,
    .package = "base"
  )
  expect_no_warning(StratoBayes:::.ReplaceFile(from, to))
  expect_equal(readRDS(to), "new")
  expect_false(file.exists(from))
})

test_that("#1677: .WriteConvergenceDraws() uses the shared replacement", {
  dir <- withr::local_tempdir()
  path <- StratoBayes:::.ConvergenceDrawsPath(dir, "m", 1L)
  StratoBayes:::.WriteConvergenceDraws(dir, "m", 1L, matrix(1), 1, 0)
  saveRDS("old", path)

  testthat::local_mocked_bindings(
    file.rename = function(from, to) FALSE,
    file.copy = function(from, to, overwrite = FALSE) FALSE,
    .package = "base"
  )
  expect_warning(
    StratoBayes:::.WriteConvergenceDraws(dir, "m", 1L, matrix(2), 1, 0),
    "Could not replace"
  )
  expect_equal(readRDS(path), "old")
})
