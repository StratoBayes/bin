# Two signals of different lengths, so a per-signal length slip shows up.
.GibbsArgs <- function(...) {
  p <- 5L
  nObs <- c(12L, 9L)
  sigma <- c(0.7, 1.3)
  B <- lapply(nObs, function(n) {
    x <- seq(0, 1, length.out = n)
    outer(x, seq_len(p), function(u, k) cos((k - 1) * pi * u))
  })
  y <- lapply(nObs, function(n) {
    x <- seq(0, 1, length.out = n)
    0.4 + 1.3 * x - 0.8 * x ^ 2
  })
  utils::modifyList(
    list(
      H_list = Map(function(Bm, s) crossprod(Bm) / s ^ 2, B, sigma),
      tBy_list = Map(
        function(Bm, ym, s) as.numeric(crossprod(Bm, ym)) / s ^ 2,
        B, y, sigma
      ),
      B_list = B,
      signalValuesVec = y,
      sigma_in = sigma,
      lambda_in = c(2.5, 0.4),
      D_mat = crossprod(diff(diag(p), differences = 2)),
      Q_fallback = rep(list(diag(p)), 2),
      aLambda = c(1.2, 0.8),
      bLambda = c(3, 5),
      shapeSigma = c(2.5, 1.7),
      bSigma_prior = c(0.9, 1.4),
      numBasis = p,
      sigmaIsFixed = FALSE,
      sigmaFixedValues = numeric(2)
    ),
    list(...)
  )
}

.ExpectGibbsError <- function(args, pattern) {
  set.seed(1)
  expect_error(suppressWarnings(do.call(.sb_gibbs, args)), pattern)
}

test_that(".sb_gibbs accepts well-formed arguments", {
  set.seed(1)
  expect_silent(do.call(.sb_gibbs, .GibbsArgs()))
  expect_silent(do.call(.sb_gibbs, .GibbsArgs(
    sigmaIsFixed = TRUE, sigmaFixedValues = c(0.7, 1.3),
    shapeSigma = c(2.5, 1.7)
  )))
  # aLambda only has to keep the gamma shape aLambda + (numBasis - 2) / 2
  # positive, so an improper aLambda = 0 stays legal.
  expect_silent(do.call(.sb_gibbs, .GibbsArgs(aLambda = c(0, -1))))
  # Q_fallback is only indexed, so a whole state's longer list is fine.
  expect_silent(
    do.call(.sb_gibbs, .GibbsArgs(Q_fallback = rep(list(diag(5)), 3)))
  )
})

test_that(".sb_gibbs rejects a per-signal prior of the wrong length (#1463)", {
  for (arg in c("aLambda", "bLambda", "shapeSigma")) {
    args <- .GibbsArgs()
    args[[arg]] <- args[[arg]][1]
    .ExpectGibbsError(args, arg)
  }
})

test_that(".sb_gibbs rejects prior values it cannot use (#1463)", {
  for (bad in c(0, -1, NA_real_, Inf)) {
    .ExpectGibbsError(.GibbsArgs(shapeSigma = c(2.5, bad)), "shapeSigma")
  }
  # 5e-324 is positive, but its reciprocal overflows to Inf.
  for (bad in c(0, -1, NA_real_, Inf, 5e-324)) {
    .ExpectGibbsError(.GibbsArgs(bLambda = c(3, bad)), "bLambda")
  }
  for (bad in c(-2, NA_real_, Inf)) {
    .ExpectGibbsError(.GibbsArgs(aLambda = c(1.2, bad)), "aLambda")
  }
})

test_that(".sb_gibbs rejects per-signal state of the wrong length (#1588)", {
  .ExpectGibbsError(.GibbsArgs(sigma_in = 0.7), "sigma_in")
  .ExpectGibbsError(.GibbsArgs(lambda_in = 2.5), "lambda_in")
  .ExpectGibbsError(
    .GibbsArgs(sigmaIsFixed = TRUE, sigmaFixedValues = 0.7),
    "sigmaFixedValues"
  )
  for (bad in c(0, NaN)) {
    .ExpectGibbsError(
      .GibbsArgs(sigmaIsFixed = TRUE, sigmaFixedValues = c(0.7, bad)),
      "sigmaFixedValues"
    )
  }
  for (arg in c("tBy_list", "B_list", "signalValuesVec", "Q_fallback")) {
    args <- .GibbsArgs()
    args[[arg]] <- args[[arg]][1]
    .ExpectGibbsError(args, arg)
  }
})

test_that(".sb_gibbs rejects per-signal inputs mis-sized against p (#1588)", {
  args <- .GibbsArgs()
  # An over-wide basis previously read past beta and returned sigma[2] ~ 1e12
  # with no condition raised.
  args$B_list[[2]] <- cbind(args$B_list[[2]], 1)
  .ExpectGibbsError(args, "B_list\\[\\[2\\]\\]")

  args <- .GibbsArgs()
  args$tBy_list[[2]] <- args$tBy_list[[2]][-1]
  .ExpectGibbsError(args, "tBy_list\\[\\[2\\]\\]")

  args <- .GibbsArgs()
  args$H_list[[2]] <- diag(4)
  .ExpectGibbsError(args, "H_list\\[\\[2\\]\\]")

  args <- .GibbsArgs()
  args$Q_fallback[[2]] <- diag(6)
  .ExpectGibbsError(args, "Q_fallback\\[\\[2\\]\\]")

  args <- .GibbsArgs()
  args$signalValuesVec[[2]] <- args$signalValuesVec[[2]][-1]
  .ExpectGibbsError(args, "signalValuesVec\\[\\[2\\]\\]")

  .ExpectGibbsError(.GibbsArgs(D_mat = matrix(0, 5, 4)), "D_mat")

  # Non-numeric storage would otherwise throw from Rcpp's as<>() inside the
  # implementation frame.
  for (arg in c("H_list", "tBy_list", "B_list", "signalValuesVec",
                "Q_fallback")) {
    args <- .GibbsArgs()
    storage.mode(args[[arg]][[2]]) <- "character"
    .ExpectGibbsError(args, paste0(arg, "\\[\\[2\\]\\]"))
  }
  args <- .GibbsArgs()
  args$H_list[[2]] <- as.numeric(args$H_list[[2]])
  .ExpectGibbsError(args, "H_list\\[\\[2\\]\\]")
})

test_that(".sb_gibbs rejects a bad obsToGroup_list (#1588)", {
  offsets <- function(otg) {
    .GibbsArgs(
      hasOffsets = TRUE, delta_list = list(c(0, 0), c(0, 0)),
      tau_in = c(1, 1), obsToGroup_list = otg, nGroups = 2L
    )
  }
  good <- list(rep(1:2, 6), rep(1:2, length.out = 9))
  set.seed(1)
  expect_silent(do.call(.sb_gibbs, offsets(good)))
  short <- good
  short[[2]] <- short[[2]][-1]
  .ExpectGibbsError(offsets(short), "obsToGroup_list\\[\\[2\\]\\]")
  for (bad in list(3L, 0L, NA_integer_)) {
    outOfRange <- good
    outOfRange[[2]][1] <- bad
    .ExpectGibbsError(offsets(outOfRange), "obsToGroup_list\\[\\[2\\]\\]")
  }
  character <- good
  character[[2]] <- as.character(character[[2]])
  .ExpectGibbsError(offsets(character), "obsToGroup_list\\[\\[2\\]\\]")
})

# A clamped cubic basis, as test-1422-1424-gibbs-spline-guards.R uses.
.SplineArgs <- function(...) {
  knots <- c(rep(0, 4), seq(0, 1, length.out = 8)[-c(1, 8)], rep(1, 4))
  p <- length(knots) - 4L
  n <- 20L
  utils::modifyList(
    list(
      B = .sb_spline_design(knots, seq(0, 1, length.out = n), 4L),
      y = sin(seq_len(n) / 3), D = crossprod(diff(diag(p), differences = 2)),
      sigma0 = 1, lambda0 = 1, aLambda = 1, bLambda = 1000, shapeSigma = 5,
      bSigma = 1, numBasis = p, nIter = 2L, outInd = 1:2,
      lambdaFixed = FALSE, lambdaFixedValue = 0
    ),
    list(...)
  )
}

test_that(".sb_gibbs_spline rejects an unusable lambda0 (#1588)", {
  set.seed(1)
  expect_silent(do.call(.sb_gibbs_spline, .SplineArgs()))
  for (bad in c(-1, NaN, NA_real_, Inf)) {
    set.seed(1)
    expect_error(
      suppressWarnings(do.call(.sb_gibbs_spline, .SplineArgs(lambda0 = bad))),
      "lambda0", info = paste("lambda0 =", bad)
    )
  }
})

test_that(".sb_gibbs_spline rejects an unusable lambdaFixedValue (#1588)", {
  for (bad in c(-1, NaN, Inf)) {
    set.seed(1)
    expect_error(
      suppressWarnings(do.call(.sb_gibbs_spline, .SplineArgs(
        lambdaFixed = TRUE, lambdaFixedValue = bad
      ))),
      "lambdaFixedValue", info = paste("lambdaFixedValue =", bad)
    )
  }
  # Read only when lambda is pinned.
  set.seed(1)
  expect_silent(do.call(.sb_gibbs_spline, .SplineArgs(lambdaFixedValue = NaN)))
})
