# Under sedSmooth the partition integrals depend on sedBeta alone, so an MH
# proposal that moves only alphas rebuilds its ages from the current state's
# SedAgeCache instead of re-running the quadrature, and re-integrates just the
# formations whose sedBeta changed. The ages must equal a full conversion's bit
# for bit, and a change to any other parameter must take the full path.

AlphaReuseEngine <- function(stratData, alphaPosition) {
  sModel <- StratModel(
    stratData,
    priors = AutoPrior(stratData, "height", sedModel = "site, partition",
                       alphaPosition = alphaPosition),
    alignmentScale = "height", sedModel = "site, partition",
    alphaPosition = alphaPosition, sedSmooth = TRUE
  )
  td <- tempfile("sedalpha")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "alpha"
  ))
  model <- result$model
  data <- result$data
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  if (is.null(model$.tiesDispatch))
    model$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(data, model)
  mcmc <- readRDS(file.path(td, "alpha_mcmc_run_1.rds"))
  StratoBayes:::.sb_create_engine(
    data = data, model = model, mcmc = mcmc, state = mcmc$recentState,
    tiesCallback = StratoBayes:::.MakeTiesCallback(data, model)
  )
}

# Four partitions per converted site, a gap in site 2 spanned by one
# formation, and ties below and above the middle of each site.
AlphaReuseStratData <- function() {
  data("stratData1", package = "StratoBayes", envir = environment())
  tops <- list(site_1 = c(2.5, 5, 7.5, 10), site_2 = c(0.6, 1.1, 1.6, 2.19),
               site_3 = c(1.1, 2.2, 3.3, 4.46))
  parts <- do.call(rbind, lapply(names(tops), function(s) {
    data.frame(site = s, height = tops[[s]],
               partition = paste0(s, "_p", seq_along(tops[[s]])))
  }))
  parts <- rbind(parts, data.frame(site = "site_2", height = 1.1,
                                   partition = NA))
  parts$partition[parts$site == "site_2" & parts$height == 1.6] <- "site_2_p2"
  ties <- data.frame(site = c("site_2", "site_2", "site_3", "site_3"),
                     height = c(0.3, 1.9, 0.5, 4.0), arg1 = c(1, 2, 1, 3),
                     arg2 = c(0.5, 0.5, 0.5, 0.5), densityFun = "dnorm")
  StratData(signal = stratData1$signal, parts = parts, ties = ties,
            signalColumn = "value", zColumn = "height",
            referenceSite = "site_1", maxPointsPerSite = Inf)
}

ChainNow <- function(eng) {
  state <- StratoBayes:::.sb_extract_state(eng)[[1]]
  list(parameters = state$metro$parameters, sedBeta = state$gibbs$sedBeta)
}

ProbeState <- function(eng, parameters, sedBeta) {
  StratoBayes:::.sb_sed_alpha_reuse_probe(eng, 1L, parameters, sedBeta)
}

# The overlap counts too: the MH step counts reused ages incrementally from
# the chain's OverlapCache, which must never pair them with stale counts.
ExpectSameConversion <- function(p) {
  expect_identical(p$okReused, p$okFull)
  expect_identical(p$agesReused, p$agesFull)
  expect_identical(p$tiesReused, p$tiesFull)
  expect_true(p$cacheIdentical)
  expect_true(p$overlapActive)
  expect_identical(p$overlapChain, p$overlapChainScratch)
  if (p$okFull) {
    expect_gt(length(p$overlapFull), 0L)
    expect_identical(p$overlapReused, p$overlapFull)
  }
}

# Random alpha-only moves: all alphas together, or one alone. Returns the
# number of in-support moves checked.
ExpectAlphaMovesReuse <- function(eng, nDraws, scale) {
  now <- ChainNow(eng)
  alphaIdx <- ProbeState(eng, now$parameters, now$sedBeta)$alphaIdx
  nOK <- 0L
  for (i in seq_len(nDraws)) {
    moved <- if (i %% 2L == 0L) alphaIdx else sample(alphaIdx, 1L)
    params <- now$parameters
    params[moved] <- params[moved] + stats::rnorm(length(moved), sd = scale)
    p <- ProbeState(eng, params, now$sedBeta)
    expect_true(p$served)
    ExpectSameConversion(p)
    nOK <- nOK + p$okFull
  }
  nOK
}

test_that("alpha-only moves reuse the age cache and match a full conversion", {
  set.seed(2236)
  sd <- AlphaReuseStratData()
  for (alphaPosition in c("bottom", "middle", "top")) {
    eng <- AlphaReuseEngine(sd, alphaPosition)
    invisible(StratoBayes:::.sb_run_block(eng, 30L))
    nOK <- ExpectAlphaMovesReuse(eng, nDraws = 8L, scale = 0.2)
    expect_gt(nOK, 0L)
    # A far or non-finite alpha: both paths must agree on support
    now <- ChainNow(eng)
    alphaIdx <- ProbeState(eng, now$parameters, now$sedBeta)$alphaIdx
    for (shift in c(1e6, Inf)) {
      far <- now$parameters
      far[alphaIdx[1]] <- far[alphaIdx[1]] + shift
      p <- ProbeState(eng, far, now$sedBeta)
      expect_true(p$served)
      expect_identical(p$okReused, p$okFull)
      if (is.infinite(shift)) expect_false(p$okFull)
      if (p$okFull) expect_identical(p$agesReused, p$agesFull)
    }
  }
})

test_that("alpha-only reuse handles ties and a formation split by a gap", {
  set.seed(2237)
  data("stratData2", package = "StratoBayes", envir = environment())
  data("stratData4b", package = "StratoBayes", envir = environment())
  for (sd in list(stratData2, stratData4b)) {
    eng <- AlphaReuseEngine(sd, "middle")
    invisible(StratoBayes:::.sb_run_block(eng, 30L))
    expect_gt(ExpectAlphaMovesReuse(eng, nDraws = 6L, scale = 0.2), 0L)
  }
})

test_that("sedBeta moves re-integrate; other parameters convert in full", {
  set.seed(2238)
  eng <- AlphaReuseEngine(AlphaReuseStratData(), "middle")
  # An imported state carries no cache
  now <- ChainNow(eng)
  p0 <- ProbeState(eng, now$parameters, now$sedBeta)
  expect_false(p0$served)
  ExpectSameConversion(p0)

  invisible(StratoBayes:::.sb_run_block(eng, 30L))
  now <- ChainNow(eng)
  alphaIdx <- ProbeState(eng, now$parameters, now$sedBeta)$alphaIdx
  expect_true(ProbeState(eng, now$parameters, now$sedBeta)$served)

  sedBeta <- now$sedBeta
  sedBeta[1] <- sedBeta[1] + 0.05
  p <- ProbeState(eng, now$parameters, sedBeta)
  expect_true(p$served)
  ExpectSameConversion(p)

  # A move of several formations at once, as a transfer move makes
  shifted <- now$sedBeta + 0.05
  p <- ProbeState(eng, now$parameters, shifted)
  expect_true(p$served)
  ExpectSameConversion(p)

  params <- now$parameters
  params[alphaIdx] <- params[alphaIdx] + 0.1
  for (beta in list(sedBeta, shifted)) {
    p <- ProbeState(eng, params, beta)
    expect_true(p$served)
    ExpectSameConversion(p)
  }

  others <- setdiff(seq_along(now$parameters), alphaIdx)
  expect_gt(length(others), 0L)
  for (j in others) {
    params <- now$parameters
    params[j] <- params[j] + 1e-3
    p <- ProbeState(eng, params, now$sedBeta)
    expect_false(p$served)
    ExpectSameConversion(p)
  }

  # Bitwise: a signed zero or a one-ulp change outside the alphas is a change
  j <- others[1]
  params <- now$parameters
  params[j] <- params[j] * (1 + .Machine$double.eps)
  if (!identical(params[j], now$parameters[j]))
    expect_false(ProbeState(eng, params, now$sedBeta)$served)
})

test_that("the age cache follows accepted and rejected alpha moves", {
  set.seed(2239)
  eng <- AlphaReuseEngine(AlphaReuseStratData(), "bottom")
  invisible(StratoBayes:::.sb_run_block(eng, 5L))
  params <- ChainNow(eng)$parameters
  moved <- 0L
  stayed <- 0L
  # Alpha moves are accepted in only about 2% of iterations here.
  for (i in seq_len(80)) {
    invisible(StratoBayes:::.sb_run_block(eng, 1L))
    now <- ChainNow(eng)$parameters
    if (identical(now, params)) stayed <- stayed + 1L else moved <- moved + 1L
    params <- now
    ExpectAlphaMovesReuse(eng, nDraws = 1L, scale = 0.1)
  }
  expect_gt(moved, 0L)
  expect_gt(stayed, 0L)
})
