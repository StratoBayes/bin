OneFormation <- function(nBasis) {
  form <- .BuildFormationSpline(0, 10, nBasis, 1L)
  list(nFormations = 1L, nBasis = form[["nBasis"]],
       totalBeta = form[["nBasis"]], betaStart = 1L,
       betaMap = matrix(1L), formations = list(form))
}

ReferenceIntegral <- function(beta, info, lo, hi) {
  form <- info[["formations"]][[1]]
  Integrand <- function(h) .SedSplineRate(beta, info, 1L, h)
  cuts <- sort(unique(c(lo, hi, form[["knots"]][form[["knots"]] > lo &
                                                  form[["knots"]] < hi])))
  sum(vapply(seq_along(cuts[-1]), function(i) {
    integrate(Integrand, cuts[[i]], cuts[[i + 1]], rel.tol = 1e-12,
              subdivisions = 1000L)[["value"]]
  }, double(1)))
}

test_that("sedSmooth quadrature is accurate in either orientation (#2261)", {
  info <- OneFormation(6L)
  rising <- c(0, 0, 0, 0, 10, 20)
  for (beta in list(rising, rev(rising))) {
    expect_equal(.sb_sed_spline_full_integral(beta, info, 1L),
                 ReferenceIntegral(beta, info, 0, 10), tolerance = 1e-8)
    expect_equal(.sb_sed_spline_partial_integral(beta, info, 1L, 1.3, 9.2),
                 ReferenceIntegral(beta, info, 1.3, 9.2), tolerance = 1e-8)
  }
})

test_that("steep random sedSmooth draws integrate accurately (#2261)", {
  info <- OneFormation(8L)
  set.seed(7)
  beta <- rnorm(info[["nBasis"]], sd = 6)
  for (b in list(beta, -beta, rev(beta))) {
    expect_equal(.sb_sed_spline_full_integral(b, info, 1L),
                 ReferenceIntegral(b, info, 0, 10), tolerance = 1e-8)
  }
})

test_that("sedSmooth forward map stays monotone in either orientation", {
  info <- OneFormation(8L)
  heights <- seq(0, 10, length.out = 5001)
  set.seed(2261)
  for (i in seq_len(25)) {
    beta <- runif(info[["nBasis"]], -14, 14)
    for (ageHeightSign in c(1, -1)) {
      ages <- .sb_sed_spline_ages(beta, info, 1L, heights, 0, ageHeightSign)
      expect_true(all(is.finite(ages)))
      expect_true(all(ageHeightSign * diff(ages) >= 0))
    }
  }
})

GapData <- function() {
  set.seed(0)
  td <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  .EnsurePreExtracted(
    StratData(td[["signal"]], parts = td[["parts"]],
              signalColumn = c("a", "b"), zColumn = "Hight",
              siteColumn = "SIT")
  )
}

SedSmoothGapModel <- function(d) {
  StratModel(d, priors = NULL, alignmentScale = "height",
             sedModel = "site, partition", sedSmooth = TRUE, nKnots = 5)
}

test_that(".AgeConversionStratData refuses sedSmooth without spline (#2263)", {
  d <- GapData()
  model <- SedSmoothGapModel(d)
  ind <- model[["ind"]]
  par <- rep(0.5, length(ind[["names"]]))
  expect_error(.AgeConversionStratData(d, ind, par),
               "requires both `sedSmoothInfo` and `sedBeta`")
  info <- model[["sedSmoothInfo"]]
  expect_error(.AgeConversionStratData(d, ind, par, sedSmoothInfo = info),
               "requires both `sedSmoothInfo` and `sedBeta`")
  ind[["sedSmooth"]] <- FALSE
  expect_error(.AgeConversionStratData(d, ind, par, sedSmoothInfo = info),
               "requires both `sedSmoothInfo` and `sedBeta`")
})

test_that(".AgeConversionBatch rejects a factor site (#860)", {
  ind <- stratModel1[["ind"]]
  par <- matrix(0.5, nrow = 1, ncol = length(ind[["names"]]))
  sites <- stratData1[["sites"]]
  site <- factor(sites[[3]], levels = rev(sites))
  expect_error(.AgeConversionBatch(par, c(0, 1, 2), site, stratData1, ind),
               "single site index")
})

test_that(".AgeConversionBatch rejects a short parameter row (#860)", {
  d <- GapData()
  model <- SedSmoothGapModel(d)
  ind <- model[["ind"]]
  info <- model[["sedSmoothInfo"]]
  par <- matrix(0.5, nrow = 2, ncol = length(ind[["names"]]) - 1L)
  beta <- matrix(0, nrow = 2, ncol = info[["totalBeta"]])
  expect_error(.AgeConversionBatch(par, c(11, 15), 2L, d, ind,
                                   sedSmoothInfo = info, sedBetaMatrix = beta),
               "one column per model parameter")
  # the constant-rate route is guarded too, whichever layer catches it
  ind1 <- stratModel1[["ind"]]
  short <- matrix(0.5, nrow = 1, ncol = length(ind1[["names"]]) - 1L)
  expect_error(.AgeConversionBatch(short, c(0, 1, 2), 2L, stratData1, ind1),
               "one column per")
})

test_that("inverse map rejects a multi-row parameter data.frame (#860)", {
  ind <- stratModel1[["ind"]]
  par <- as.data.frame(matrix(0.5, nrow = 2, ncol = length(ind[["names"]])))
  expect_error(.CalculateRefHeightToHeights(stratData1, ind, par, 2L, 1),
               "one-row data.frame; got 2 rows")
})

test_that("inverse map returns NA across a gap that has height (#862)", {
  d <- GapData()
  ind <- .CreateIndices(d, "height", "partition", "bottom")
  par <- rep(0, length(ind[["names"]]))
  par[ind[["alpha"]]] <- c(0, 5)
  par[ind[["gap"]]] <- 2
  # partitions 3 and 4 of site 2 no longer meet in height, so no single
  # height corresponds to an age between them
  d[[c("partsAttr", "Bound")]][3, 2] <- 22
  d[[c("partsAttr", "BoundLow")]][4, 2] <- 23
  expect_warning(
    out <- .CalculateRefHeightToHeights(d, ind, par, 2L, c(5, 24, 26)),
    "do not meet in height"
  )
  expect_true(is.na(out[[2]]))
  expect_true(all(is.finite(out[-2])))
})

test_that("inverse map never gives NaN or Inf at an underflowed rate (#1386)", {
  d <- GapData()
  refs <- seq(-5, 40, by = 0.01)
  for (sedModel in c("site", "partition", "site, partition")) {
    ind <- .CreateIndices(d, "height", sedModel, "bottom")
    for (g in ind[["gamma"]]) {
      par <- rep(0, length(ind[["names"]]))
      par[ind[["alpha"]]] <- c(0, 5)
      par[ind[["gap"]]] <- 2
      par[[g]] <- 800
      for (site in 2:3) {
        out <- suppressWarnings(
          .CalculateRefHeightToHeights(d, ind, par, site, refs)
        )
        expect_false(any(is.nan(out) | is.infinite(out)))
      }
    }
  }
})
