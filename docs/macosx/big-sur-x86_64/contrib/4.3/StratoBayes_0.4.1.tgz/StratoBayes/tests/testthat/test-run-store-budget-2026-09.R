# The run driver's stores: the convergence store the default early stop reads
# (#2215, #1676), the retained-sample ceiling (#2214, #2216), checkpoint
# integrity (#2218) and the live plot's slot lookup (#2217).

StoreRows <- function(iters, seed = 1L) {
  set.seed(seed)
  cbind(iteration = iters, chain = 1, a = stats::rnorm(length(iters)),
        b = stats::rnorm(length(iters)))
}

# Feeds a store checkpoint by checkpoint, as `.InnerRunMCMC()` does.
FillStore <- function(iters, floorIter, cap = .kConvergenceMaxDraws,
                      every = 1000L, seed = 1L) {
  store <- .ConvergenceStore()
  for (chunk in split(iters, ceiling(seq_along(iters) / every))) {
    store <- .ConvergenceAppend(store, StoreRows(chunk, seed), cols = 3:4,
                                floorIter = floorIter)
    store <- .ConvergenceCollapse(store, cap)
  }
  store
}

Store1RunData <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  list(data = stratData1,
       model = StratModel(stratData1, alignmentScale = "height",
                          sedModel = "site"))
}

# ── #1676: parallel runs' convergence grids stay commensurate ───────────────

test_that("runs whose adaptation froze apart still share draws (#1676)", {
  # Floors from two runs whose adaptive timers froze at different iterations.
  saved <- seq(10, 200000, by = 10)
  early <- FillStore(saved, floorIter = 3000)
  late <- FillStore(saved, floorIter = 4990)
  expect_identical(early[["thin"]], late[["thin"]])
  shared <- intersect(early[["iters"]], late[["iters"]])
  expect_gte(length(shared), .kAutoBurnInMinRows)

  dir <- withr::local_tempdir()
  .WriteConvergenceDraws(dir, "m1676", 1L, early[["draws"]], early[["iters"]],
                         endAdapting = 3000)
  .WriteConvergenceDraws(dir, "m1676", 2L, late[["draws"]], late[["iters"]],
                         endAdapting = 4990)
  expect_false(is.null(.ConvergenceDrawSet(dir, "m1676", 1L, 2L)))
})

test_that("a store rebuilt after thinning shares draws with its peer (#1676)", {
  saved <- 2001:12000
  peer <- FillStore(saved, floorIter = 2000)
  expect_gte(peer[["thin"]], 1L)

  # As the sample-store thin in `.InnerRunMCMC()`: the saved rows move to
  # stride 2 and the convergence store is rebuilt from them.
  thinned <- saved[saved %% 2 == 0]
  rebuilt <- .ConvergenceCollapse(
    .ConvergenceAppend(.ConvergenceStore(), StoreRows(thinned), cols = 3:4,
                       floorIter = 2000)
  )
  shared <- intersect(peer[["iters"]], rebuilt[["iters"]])
  expect_gte(length(shared), .kAutoBurnInMinRows)
  expect_true(all(rebuilt[["iters"]] %in% peer[["iters"]]) ||
                all(peer[["iters"]] %in% rebuilt[["iters"]]))
})

# ── #2215: the rebuilt store keeps room for the ESS target ──────────────────

test_that("the post-thin rebuild keeps 2 * ess rows (#2215)", {
  skip_on_cran()
  fx <- Store1RunData()
  withr::local_options(StratoBayes.maxStore = 8192L)
  realCollapse <- .ConvergenceCollapse
  seen <- new.env()
  seen[["caps"]] <- numeric(0)
  local_mocked_bindings(
    .ConvergenceCollapse = function(store, cap = .kConvergenceMaxDraws) {
      seen[["caps"]] <- c(seen[["caps"]], cap)
      realCollapse(store, cap)
    }
  )
  result <- suppressMessages(suppressWarnings(RunStratModel(
    fx$data, fx$model, nIter = 10000, nChains = 1, nThreads = 1L,
    tempering = FALSE, endAdapting = 500,
    convergenceStop = list(ess = 4096), visualise = FALSE, quiet = TRUE,
    runParallel = FALSE, seed = 1, modelDir = withr::local_tempdir(),
    modelName = "m2215"
  )))
  # The store thinned, so the convergence store was rebuilt.
  expect_gt(result[[c("mcmcSummary", "nThin")]][[1]], 1)
  expect_gt(length(seen[["caps"]]), 0L)
  expect_true(all(seen[["caps"]] >= 2 * 4096))
})

# ── #2216: options reach every run; maxStore validated; ESS guard per run ────

test_that("a run is handed the store options, not left to read them (#2216)", {
  skip_on_cran()
  fx <- Store1RunData()
  realInnerRunMCMC <- .InnerRunMCMC
  captured <- new.env()
  local_mocked_bindings(.InnerRunMCMC = function(...) {
    captured[["args"]] <- list(...)
    NULL
  })
  modelDir <- withr::local_tempdir()
  withr::with_options(
    list(StratoBayes.maxStore = 256L, StratoBayes.adaptTimerEss = 50),
    try(suppressMessages(suppressWarnings(RunStratModel(
      fx$data, fx$model, nIter = 2000, nChains = 1, nThreads = 1L,
      tempering = FALSE, endAdapting = 100, convergenceStop = FALSE,
      visualise = FALSE, quiet = TRUE, runParallel = FALSE, seed = 1,
      modelDir = modelDir, modelName = "m2216"
    ))), silent = TRUE)
  )
  args <- captured[["args"]]
  expect_identical(args[["maxStore"]], 256)
  expect_identical(args[["adaptTimerEss"]], 50)

  # A parallel worker has none of this session's options.
  withr::local_options(StratoBayes.maxStore = NULL,
                       StratoBayes.adaptTimerEss = NULL)
  suppressMessages(suppressWarnings(do.call(realInnerRunMCMC, args)))
  checkpoint <- readRDS(file.path(modelDir, "m2216_mcmc_run_1.rds"))
  expect_gt(checkpoint[["nThin"]], 1)
})

test_that("a maxStore below 2 is refused, not left to hang (#2216)", {
  withr::with_options(list(StratoBayes.maxStore = Inf),
                      expect_identical(.MaxStoreOption(), Inf))
  fx <- Store1RunData()
  for (bad in list(0L, -1, 1.5, NA_real_, c(64, 128), "64")) {
    withr::with_options(list(StratoBayes.maxStore = bad), expect_error(
      RunStratModel(fx$data, fx$model, nIter = 10, nChains = 1,
                    nThreads = 1L, convergenceStop = FALSE, visualise = FALSE,
                    quiet = TRUE, runParallel = FALSE,
                    modelDir = withr::local_tempdir()),
      "StratoBayes.maxStore"
    ))
  }
})

test_that("the ESS guard gives parallel runs a share each (#2216)", {
  fx <- Store1RunData()
  withr::local_options(StratoBayes.maxStore = 512L)
  Run <- function(runParallel, nRun, nCores = nRun) {
    RunStratModel(fx$data, fx$model, stratMCMC = "not a template",
                  nRun = nRun, runParallel = runParallel, nCores = nCores,
                  nThreads = 1L, convergenceStop = list(ess = 600),
                  visualise = FALSE, quiet = TRUE,
                  modelDir = withr::local_tempdir())
  }
  # Four runs reach 4 * 256: past the guard, to the next argument check.
  expect_error(Run(TRUE, 4L), "`stratMCMC` must be")
  expect_error(Run(FALSE, 4L), "above the effective sample size a run")
  expect_error(Run(TRUE, 2L), "2 parallel runs can reach \\(512\\)")
  # Runs in waves are each assessed alone (#2304).
  expect_error(Run(TRUE, 4L, nCores = 2L), "effective sample size a run")
})

# ── #2214: a finite nIter past the ceiling ───────────────────────────────────

RunFinite <- function(fx, ..., nIter, maxStore, nChains = 1,
                      convergenceStop = FALSE,
                      modelDir = withr::local_tempdir()) {
  withr::local_options(StratoBayes.maxStore = maxStore)
  RunStratModel(
    fx$data, fx$model, nIter = nIter, nChains = nChains, nThreads = 1L,
    tempering = FALSE, convergenceStop = convergenceStop, visualise = FALSE,
    quiet = TRUE, runParallel = FALSE, seed = 1, modelDir = modelDir, ...
  )
}

test_that("a finite run filling its store at its end is kept (#2214)", {
  skip_on_cran()
  fx <- Store1RunData()
  warned <- new.env()
  result <- withCallingHandlers(
    RunFinite(fx, engine = "R", nIter = 300, maxStore = 280L),
    warning = function(w) {
      warned[["messages"]] <- c(warned[["messages"]], conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  expect_false(any(grepl("WITHOUT converging", warned[["messages"]])))
  expect_identical(dim(result[["samples"]])[[1]], 300L)
})

test_that("a finite run sure to fill where it cannot thin is refused (#2214)", {
  fx <- Store1RunData()
  expect_error(
    RunFinite(fx, nIter = 400, endAdapting = 300, maxStore = 128L),
    paste0("holds? .*at iteration .*while still adapting.*",
           "raise `nThin`, or lower `endAdapting`")
  )
  expect_error(RunFinite(fx, engine = "R", nIter = 400, maxStore = 128L),
               "R engine does not thin.*use `engine = \"cpp\"`")
  # Convergence cannot end a run inside its window.
  expect_error(
    RunFinite(fx, engine = "R", nIter = 400, endAdapting = 300,
              maxStore = 128L, nChains = 2, convergenceStop = list(rHat = 1.1)),
    "R engine does not thin"
  )
})

test_that("a finite run is not refused when its fill is uncertain (#2214)", {
  skip_on_cran()
  fx <- Store1RunData()
  Unrefused <- function(...) {
    result <- suppressWarnings(suppressMessages(RunFinite(fx, ...)))
    expect_s3_class(result, "StratPosterior")
  }
  # The adaptive timer may end the default window before the store fills.
  Unrefused(nIter = 400, maxStore = 128L)
  # A time limit may end the run first.
  Unrefused(engine = "R", nIter = 400, maxStore = 128L, timeLimit = 1)
  # Convergence may end the run once its window closes.
  Unrefused(engine = "R", nIter = 400, endAdapting = 100, maxStore = 128L,
            nChains = 2, convergenceStop = list(rHat = 1.1))
})

test_that("a finite run says when its store starts thinning (#2214)", {
  skip_on_cran()
  fx <- Store1RunData()
  expect_message(
    suppressWarnings(
      RunFinite(fx, nIter = 2000, endAdapting = 100, maxStore = 256L)
    ),
    "StratoBayes.maxStore = 256.*thinned to one in every 2 iterations"
  )
})

# ── #2218: checkpoint integrity ──────────────────────────────────────────────

test_that("every checkpoint of a run is written atomically (#2218)", {
  skip_on_cran()
  fx <- Store1RunData()
  realSave <- .SaveRDSAtomic
  written <- new.env()
  local_mocked_bindings(.SaveRDSAtomic = function(object, to, ...) {
    written[["to"]] <- c(written[["to"]], basename(to))
    realSave(object, to, ...)
  })
  RunFinite(fx, nIter = 200, maxStore = 65536L, modelName = "atomic")
  # Iteration 1, then every `writeMCMCfile` checkpoint.
  expect_gte(sum(written[["to"]] == "atomic_mcmc_run_1.rds"), 11L)
})

test_that("a thinned store that cannot be moved in stops its run (#2218)", {
  skip_on_cran()
  fx <- Store1RunData()
  realReplace <- .ReplaceFile
  refused <- new.env()
  refused[["n"]] <- 0L
  local_mocked_bindings(.ReplaceFile = function(from, to) {
    if (grepl("\\.thin\\d+$", from) && refused[["n"]] == 0L) {
      refused[["n"]] <- 1L
      return(invisible(FALSE))
    }
    realReplace(from, to)
  })
  expect_warning(
    post <- suppressMessages(RunFinite(fx, nIter = 2000, endAdapting = 100,
                                       maxStore = 256L)),
    "stopped at iteration \\d+ because its thinned samples could not be moved"
  )
  expect_identical(refused[["n"]], 1L)
  completed <- unname(post[[c("mcmcSummary", "completedIter")]])
  expect_lt(completed, 2000)
  saved <- post[[c("mcmcSummary", "saveIter")]][[1]]
  expect_identical(dim(post[["samples"]])[[1]], length(saved))
  expect_identical(as.numeric(dimnames(post[["samples"]])[[1]]),
                   as.numeric(saved))
})

# The real move-refused state: the new checkpoint complete beside the old.
RefuseMove <- function(object, to) {
  saveRDS(object, paste0(to, ".tmp"), compress = FALSE)
  invisible(FALSE)
}

test_that("a thin whose schedule cannot be moved in stops its run (#2218)", {
  skip_on_cran()
  fx <- Store1RunData()
  realSave <- .SaveRDSAtomic
  refused <- new.env()
  local_mocked_bindings(.SaveRDSAtomic = function(object, to, ...) {
    if (is.list(object) && !is.null(object[["thinGeneration"]]) &&
          is.null(refused[["at"]])) {
      refused[["at"]] <- object[["completedIter"]]
      return(RefuseMove(object, to))
    }
    realSave(object, to, ...)
  })
  expect_warning(
    post <- suppressMessages(
      RunFinite(fx, nIter = 2000, endAdapting = 100, maxStore = 256L)
    ),
    "stopped at iteration \\d+ because its thinned samples could not be moved"
  )
  completed <- unname(post[[c("mcmcSummary", "completedIter")]])
  expect_identical(completed, refused[["at"]])
  saved <- post[[c("mcmcSummary", "saveIter")]][[1]]
  expect_identical(
    as.numeric(dimnames(post[["samples"]])[[1]]), as.numeric(saved)
  )
})

test_that("a checkpoint that cannot be moved in stops its run (#2218)", {
  skip_on_cran()
  fx <- Store1RunData()
  realSave <- .SaveRDSAtomic
  refused <- new.env()
  local_mocked_bindings(.SaveRDSAtomic = function(object, to, ...) {
    if (is.list(object) && isTRUE(object[["completedIter"]] > 100) &&
          is.null(refused[["at"]])) {
      refused[["at"]] <- object[["completedIter"]]
      return(RefuseMove(object, to))
    }
    realSave(object, to, ...)
  })
  expect_warning(
    post <- RunFinite(fx, nIter = 400, maxStore = 65536L),
    "stopped at iteration \\d+ because its checkpoint could not be moved"
  )
  completed <- unname(post[[c("mcmcSummary", "completedIter")]])
  expect_identical(completed, refused[["at"]])
  expect_identical(
    as.numeric(dimnames(post[["samples"]])[[1]]),
    as.numeric(post[[c("mcmcSummary", "saveIter")]][[1]])
  )
})

test_that("a run another live session is writing is not continued (#2218)", {
  skip_on_cran()
  fx <- Store1RunData()
  dir <- withr::local_tempdir()
  post <- suppressWarnings(
    RunFinite(fx, nIter = 20, maxStore = 65536L, modelDir = dir,
              modelName = "busy")
  )
  writeLines(c(Sys.info()[["nodename"]], Sys.getpid() + 1L),
             .WriterMarkerPath(dir, "busy"))
  local_mocked_bindings(.ProcessAlive = function(pid) TRUE)
  expect_error(
    RunStratModel(post, nIter = 20, quiet = TRUE, visualise = FALSE,
                  nThreads = 1L),
    "still being written by another session.*busy_writing"
  )
})

test_that("recovery keeps the newer of a checkpoint and its .tmp (#2218)", {
  dir <- withr::local_tempdir()
  target <- file.path(dir, "m_mcmc_run_1.rds")
  saveRDS(list(completedIter = 20), paste0(target, ".tmp"))
  writeBin(as.raw(1:10), target)
  .RecoverThinning(dir, "m")
  expect_identical(readRDS(target)[["completedIter"]], 20)
  expect_false(file.exists(paste0(target, ".tmp")))

  # A good target beside a .tmp cut short is left as it was.
  writeBin(as.raw(1:10), paste0(target, ".tmp"))
  .RecoverThinning(dir, "m")
  expect_identical(readRDS(target)[["completedIter"]], 20)
  expect_false(file.exists(paste0(target, ".tmp")))

  # Where both read, the .tmp is the later checkpoint.
  saveRDS(list(completedIter = 30), paste0(target, ".tmp"))
  .RecoverThinning(dir, "m")
  expect_identical(readRDS(target)[["completedIter"]], 30)
  expect_false(file.exists(paste0(target, ".tmp")))
})

test_that("recovery leaves a live writer's in-flight files alone (#2218)", {
  dir <- withr::local_tempdir()
  saveRDS(list(thinGeneration = 0), file.path(dir, "m_mcmc_run_1.rds"))
  inFlight <- file.path(dir, c("m_mcmc_run_1.rds.tmp",
                               "m_samples_run_1.txt.thin1",
                               "m_samples_run_1.txt.thin2.tmp"))
  Reset <- function() {
    saveRDS(list(thinGeneration = 1), inFlight[[1]])
    for (f in inFlight[-1]) writeLines("x", f)
  }
  Reset()
  Mark <- function(pid) {
    writeLines(c(Sys.info()[["nodename"]], pid),
               .WriterMarkerPath(dir, "m"))
  }

  Mark(Sys.getpid() + 1L)
  local_mocked_bindings(.ProcessAlive = function(pid) TRUE)
  expect_message(.RecoverThinning(dir, "m"), "still being written")
  expect_true(all(file.exists(inFlight)))

  # The same marker once its process has gone: an interrupted swap.
  local_mocked_bindings(.ProcessAlive = function(pid) FALSE)
  .RecoverThinning(dir, "m")
  expect_false(any(file.exists(inFlight)))

  # This session's own marker never blocks it.
  Reset()
  Mark(Sys.getpid())
  .RecoverThinning(dir, "m")
  expect_false(any(file.exists(inFlight)))
})

test_that("a writer's marker names a live process while it runs (#2218)", {
  expect_true(.ProcessAlive(Sys.getpid()))
  expect_false(.ProcessAlive(2^30 + 7))

  fx <- Store1RunData()
  dir <- withr::local_tempdir()
  marked <- new.env()
  local_mocked_bindings(.InnerRunMCMC = function(...) {
    marked[["during"]] <- file.exists(.WriterMarkerPath(dir, "marked"))
    NULL
  })
  try(suppressWarnings(RunFinite(fx, nIter = 20, maxStore = 65536L,
                                 modelDir = dir, modelName = "marked")),
      silent = TRUE)
  expect_true(marked[["during"]])
  expect_false(file.exists(.WriterMarkerPath(dir, "marked")))
})

# ── #2217: the live plot's slot lookup ───────────────────────────────────────

test_that("the batched slot lookup matches the per-row scan (#2217)", {
  saveIterUsed <- c(1, seq(4, 400, by = 4))
  indices <- .PlotSampleMatrixUpdateIndices(nRow = 50, saveIter = saveIterUsed)
  rows <- c(1, 2, 3, 4, 8, 9, 200, 399, 400, 404)
  perRow <- vapply(rows, function(r) {
    ui <- indices[r == saveIterUsed]
    if (length(ui) == 1L) ui else NA_real_
  }, numeric(1))
  expect_identical(.PlotSlots(rows, saveIterUsed, indices), perRow)
})

# ── #2304: parallel runs that outnumber the workers ─────────────────────────

test_that("a run in a parallel wave stops on its own diagnostic (#2304)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  realInnerRunMCMC <- .InnerRunMCMC
  captured <- new.env()
  local_mocked_bindings(.InnerRunMCMC = function(...) {
    captured[["args"]] <- list(...)
    NULL
  })
  modelDir <- withr::local_tempdir()
  try(suppressMessages(suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 2e5, nChains = 3, nRun = 3,
    seed = 1:3, nThreads = 1L, visualise = FALSE, quiet = TRUE,
    runParallel = FALSE, modelDir = modelDir, modelName = "waves"
  ))), silent = TRUE)

  # As a first-wave worker sees it: its peers have not started. Before the fix
  # it waited on them to the end of `nIter`.
  args <- captured[["args"]]
  args[["isParallel"]] <- TRUE
  args[["concurrency"]] <- 2L
  suppressMessages(suppressWarnings(do.call(realInnerRunMCMC, args)))
  checkpoint <- readRDS(
    file.path(modelDir, paste0("waves_mcmc_run_", args[["run"]], ".rds"))
  )
  expect_lt(checkpoint[["completedIter"]], 2e5)
})

test_that("parallel runs in waves stop early (#2304)", {
  skip_on_cran()  # spawns worker processes
  skip_if_not_installed("future.apply")
  # Workers load the installed build, not the one `load_all()` put here.
  skip_if(
    !file.exists(
      file.path(find.package("StratoBayes"), "R", "StratoBayes.rdb")
    ),
    "dev session: parallel workers would load the installed build"
  )
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  result <- suppressMessages(suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 2e5, nChains = 3, nRun = 3,
    seed = 1:3, runParallel = TRUE, nCores = 2L, nThreads = 1L,
    visualise = FALSE, quiet = TRUE, modelDir = withr::local_tempdir()
  )))
  completed <- unlist(result[[c("mcmcSummary", "completedIter")]])
  expect_true(all(completed < 2e5))
})
