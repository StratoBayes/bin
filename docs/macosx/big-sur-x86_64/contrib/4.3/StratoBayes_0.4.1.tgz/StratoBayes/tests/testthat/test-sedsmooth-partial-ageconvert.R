# A sedBeta move of formation f re-integrates only f's partitions: the other
# partitions' integrals come from the chain state's SedAgeCache, and every age
# is rebuilt from them by the same additions as a full conversion. So the
# cached conversion must equal a full one bit for bit, whichever side of the
# alpha anchor f lies on, across gaps and ties, and the cache must follow the
# chain through accepted and rejected moves.

PartialConvertEngine <- function(stratData, alphaPosition, nChains = 1L) {
  sModel <- StratModel(
    stratData,
    priors = AutoPrior(stratData, "height", sedModel = "site, partition",
                       alphaPosition = alphaPosition),
    alignmentScale = "height", sedModel = "site, partition",
    alphaPosition = alphaPosition, sedSmooth = TRUE
  )
  td <- tempfile("sedpartial")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = sModel,
    nIter = 10, nChains = nChains, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "partial"
  ))
  model <- result$model
  data <- result$data
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  if (is.null(model$.tiesDispatch))
    model$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(data, model)
  mcmc <- readRDS(file.path(td, "partial_mcmc_run_1.rds"))
  list(
    engine = StratoBayes:::.sb_create_engine(
      data = data, model = model, mcmc = mcmc, state = mcmc$recentState,
      tiesCallback = StratoBayes:::.MakeTiesCallback(data, model)
    ),
    nFormations = model$sedSmoothInfo$nFormations,
    nBasis = model$sedSmoothInfo$nBasis
  )
}

# Four partitions per converted site, with a gap in site 2 that the same
# formation spans, plus ties below and above the middle of each site.
PartitionedStratData <- function() {
  data("stratData1", package = "StratoBayes", envir = environment())
  signal <- stratData1$signal
  tops <- list(site_1 = c(2.5, 5, 7.5, 10), site_2 = c(0.6, 1.1, 1.6, 2.19),
               site_3 = c(1.1, 2.2, 3.3, 4.46))
  parts <- do.call(rbind, lapply(names(tops), function(s) {
    data.frame(site = s, height = tops[[s]],
               partition = paste0(s, "_p", seq_along(tops[[s]])))
  }))
  gap <- data.frame(site = "site_2", height = 1.1, partition = NA)
  parts <- rbind(parts, gap)
  parts$partition[parts$site == "site_2" & parts$height == 1.6] <- "site_2_p2"
  ties <- data.frame(site = c("site_2", "site_2", "site_3", "site_3"),
                     height = c(0.3, 1.9, 0.5, 4.0), arg1 = c(1, 2, 1, 3),
                     arg2 = c(0.5, 0.5, 0.5, 0.5), densityFun = "dnorm")
  StratData(signal = signal, parts = parts, ties = ties,
            signalColumn = "value", zColumn = "height", referenceSite = "site_1",
            maxPointsPerSite = Inf)
}

ExpectPartialMatchesFull <- function(eng, nDraws, scale) {
  state <- StratoBayes:::.sb_extract_state(eng$engine)[[1]]
  sedBeta <- state$gibbs$sedBeta
  nMatched <- 0L
  nTies <- 0L
  for (f in seq_len(eng$nFormations)) {
    idx <- (f - 1L) * eng$nBasis + seq_len(eng$nBasis)
    for (i in seq_len(nDraws)) {
      beta <- sedBeta[idx] + stats::rnorm(eng$nBasis, sd = scale)
      p <- StratoBayes:::.sb_sed_age_cache_probe(eng$engine, 1L, f, beta)
      expect_true(p$cacheValid)
      expect_identical(p$okPartial, p$okFull)
      if (!p$okFull) next
      expect_identical(p$agesPartial, p$agesFull)
      expect_identical(p$tiesPartial, p$tiesFull)
      nTies <- nTies + length(unlist(p$tiesFull))
      expect_identical(p$logPostPartial, p$logPostFull)
      nMatched <- nMatched + 1L
    }
  }
  c(matched = nMatched, ties = nTies)
}

test_that("cached sedBeta age conversion equals a full one", {
  set.seed(2231)
  sd <- PartitionedStratData()
  for (alphaPosition in c("bottom", "middle", "top")) {
    eng <- PartialConvertEngine(sd, alphaPosition)
    # An imported state carries no cache; the first sedBeta step builds one
    probe0 <- StratoBayes:::.sb_sed_age_cache_probe(
      eng$engine, 1L, 1L, numeric(eng$nBasis))
    expect_false(probe0$cacheValid)
    invisible(StratoBayes:::.sb_run_block(eng$engine, 30L))
    checked <- ExpectPartialMatchesFull(eng, nDraws = 3L, scale = 0.3)
    expect_gt(checked[["matched"]], 0L)
    expect_gt(checked[["ties"]], 0L)
  }
})

test_that("cached age conversion handles ties and a formation split by a gap", {
  set.seed(2232)
  data("stratData2", package = "StratoBayes", envir = environment())
  data("stratData4b", package = "StratoBayes", envir = environment())
  for (sd in list(stratData2, stratData4b)) {
    eng <- PartialConvertEngine(sd, "middle")
    invisible(StratoBayes:::.sb_run_block(eng$engine, 30L))
    checked <- ExpectPartialMatchesFull(eng, nDraws = 2L, scale = 0.3)
    expect_gt(checked[["matched"]], 0L)
    expect_gt(checked[["ties"]], 0L)
  }
})

test_that("the age cache follows accepted and rejected sedBeta moves", {
  set.seed(2233)
  eng <- PartialConvertEngine(PartitionedStratData(), "middle")
  invisible(StratoBayes:::.sb_run_block(eng$engine, 5L))
  sedBeta <- StratoBayes:::.sb_extract_state(eng$engine)[[1]]$gibbs$sedBeta
  moved <- 0L
  stayed <- 0L
  for (i in seq_len(60)) {
    invisible(StratoBayes:::.sb_run_block(eng$engine, 1L))
    now <- StratoBayes:::.sb_extract_state(eng$engine)[[1]]$gibbs$sedBeta
    if (identical(now, sedBeta)) stayed <- stayed + 1L else moved <- moved + 1L
    sedBeta <- now
    ExpectPartialMatchesFull(eng, nDraws = 1L, scale = 0.2)
  }
  expect_gt(moved, 0L)
  expect_gt(stayed, 0L)
})

# A move may change more than one formation (a shape-level transfer trades
# duration between neighbours). The cache must notice every formation whose
# coefficients differ from the state it describes, not just the one scanned.
test_that("cached age conversion re-integrates every changed formation", {
  set.seed(2234)
  sd <- PartitionedStratData()
  for (alphaPosition in c("bottom", "middle", "top")) {
    eng <- PartialConvertEngine(sd, alphaPosition)
    invisible(StratoBayes:::.sb_run_block(eng$engine, 30L))
    sedBeta <- StratoBayes:::.sb_extract_state(eng$engine)[[1]]$gibbs$sedBeta
    idx <- function(f) (f - 1L) * eng$nBasis + seq_len(eng$nBasis)
    pairs <- utils::combn(eng$nFormations, 2L)
    nMatched <- 0L
    nCrossSite <- 0L
    for (k in seq_len(ncol(pairs))) {
      fs <- pairs[, k]
      beta <- sedBeta[c(idx(fs[1]), idx(fs[2]))] +
        stats::rnorm(2L * eng$nBasis, sd = 0.2)
      p <- StratoBayes:::.sb_sed_age_cache_probe(eng$engine, 1L, fs, beta)
      expect_true(p$cacheValid)
      expect_identical(p$okPartial, p$okFull)
      if (!p$okFull) next
      expect_identical(p$agesPartial, p$agesFull)
      expect_identical(p$tiesPartial, p$tiesFull)
      expect_identical(p$logPostPartial, p$logPostFull)
      nMatched <- nMatched + 1L
      p1 <- StratoBayes:::.sb_sed_age_cache_probe(
        eng$engine, 1L, fs[1], beta[seq_len(eng$nBasis)])
      if (length(p$formationSites) > length(p1$formationSites))
        nCrossSite <- nCrossSite + 1L
    }
    expect_gt(nMatched, 0L)
    expect_gt(nCrossSite, 0L)
  }
})
