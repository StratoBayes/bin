# #2155: the sedBeta move checked only the knot range, so under
# minSignalOverlap it accepted states whose sites no longer overlap, which the
# main MH kernel treats as outside the support. Every state the chain holds
# after an iteration is a state it can save, so each must pass the check.

test_that("sedBeta move keeps sites connected under minSignalOverlap (#2155)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  sModel <- StratModel(
    stratData1,
    priors = AutoPrior(stratData1, "height"),
    alignmentScale = "height", sedModel = "site, partition",
    sedSmooth = TRUE, flexibleKnots = FALSE, knotRange = c(-5, 12),
    minSignalOverlap = 5
  )
  td <- tempfile("sedoverlap")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "ov"
  ))
  mcmc <- readRDS(file.path(td, "ov_mcmc_run_1.rds"))
  nPerSite <- result$data$signalAttr$N
  siteOf <- rep(seq_along(nPerSite), nPerSite)
  SiteAges <- function(state) split(state$age$signalFlat, siteOf)

  # Tighten the constraint to the largest value the current state meets, so
  # any move that shrinks the narrowest overlap leaves the support.
  startAges <- SiteAges(mcmc$recentState[[1]])
  kBind <- max(which(vapply(
    seq_len(min(nPerSite)),
    function(k) StratoBayes:::.OverlapCheck(startAges, k),
    logical(1)
  )))
  expect_gt(kBind, 0)
  model <- result$model
  model$proposeChecks$overlap <- kBind
  if (is.null(model$.logpost_cpp)) {
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  engine <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
  states <- lapply(seq_len(300), function(i) {
    invisible(StratoBayes:::.sb_run_block(engine, 1L))
    StratoBayes:::.sb_extract_state(engine)[[1]]
  })
  connected <- vapply(
    states,
    function(state) StratoBayes:::.OverlapCheck(SiteAges(state), kBind),
    logical(1)
  )
  expect_true(all(connected))
  # A chain that rejects every sedBeta move would pass vacuously.
  sedBeta <- lapply(states, function(state) state$gibbs$sedBeta)
  expect_gt(length(unique(sedBeta)), 1)
})

# #2123: at x = +Inf, shape 1 gave 0 * Inf and shape 3 gave Inf - Inf, both
# NaN, where R's dgamma() gives -Inf. NaN input stays NaN, as in R.

test_that("native ties dgamma density is -Inf at x = +Inf (#2123)", {
  for (shape in c(0.5, 1, 3)) {
    expect_identical(
      StratoBayes:::.sb_gamma_ties_logdensity(Inf, shape, 2),
      dgamma(Inf, shape = shape, rate = 2, log = TRUE),
      info = paste("shape", shape)
    )
  }
  expect_true(is.nan(StratoBayes:::.sb_gamma_ties_logdensity(NaN, 3, 2)))
})
