# #1595: the native ties dgamma density (compute_logpost, densityType case 4)
# returned -Inf for every x <= 0. R's dgamma() at x = 0 is log(rate) when
# shape == 1 and +Inf when shape < 1, so the engines disagreed for a tie
# landing exactly on zero. Same boundary class as RT-030 for dbeta.

test_that(paste0("native ties dgamma density matches R's dgamma() at and away ",
                 "from x = 0 (#1595)"), {
            cases <- list(
              # dexp at 0: finite (was -Inf)
              c(x = 0,   shape = 1,   rate = 2),
              # diverges at 0: +Inf (was -Inf)
              c(x = 0,   shape = 0.5, rate = 2),
              c(x = 0,   shape = 3,   rate = 2),    # zero density at 0: -Inf
              c(x = 1e-9, shape = 1,  rate = 2),
              c(x = 0.7, shape = 0.5, rate = 3),
              c(x = 2.5, shape = 3,   rate = 1.5),
              c(x = -0.1, shape = 1,  rate = 2),    # outside the support
              c(x = -0.1, shape = 0.5, rate = 2)
            )

            for (cs in cases) {
              expect_equal(
                StratoBayes:::.sb_gamma_ties_logdensity(cs[["x"]],
                                                        cs[["shape"]],
                                                        cs[["rate"]]),
                dgamma(cs[["x"]], shape = cs[["shape"]], rate = cs[["rate"]],
                       log = TRUE),
                info = sprintf("x=%s shape=%s rate=%s",
                               cs[["x"]], cs[["shape"]], cs[["rate"]])
              )
            }
          })
