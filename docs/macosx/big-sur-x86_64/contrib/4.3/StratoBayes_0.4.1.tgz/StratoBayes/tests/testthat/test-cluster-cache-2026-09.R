# Area-11 clustering and posterior-cache findings: #2171, #2172, #1522, #2173,
# #1701.

.CachedPosterior <- function() .WithClusterCache(stratPosterior1, lazy = TRUE)

# ---------------------------------------------------------------------------
# #2171
# ---------------------------------------------------------------------------

test_that("ExtractParameters() rejects an all-TRUE logical selectRows (#2171)", {
  expect_error(ExtractParameters(stratPosterior1, selectRows = TRUE),
               "logical")
  expect_error(.ValidateSelectRows(list(c(TRUE, TRUE)), 1L), "logical")
})

test_that("Cluster() reports the burn-in of the rows `iterations` selected", {
  saveIter <- stratPosterior1[[c("mcmcSummary", "saveIter")]]
  cl <- Cluster(stratPosterior1, iterations = saveIter)
  firstRow <- min(vapply(cl[["rowIndex"]], min, numeric(1)))
  expect_identical(firstRow, 1)
  expect_equal(cl[["burninIndex"]], firstRow - 1)
})

# ---------------------------------------------------------------------------
# #2172, #1522: what the posterior cache is keyed on
# ---------------------------------------------------------------------------

test_that("a cache minted under another algorithm version is not served", {
  x <- .CachedPosterior()
  expect_false(is.null(.PosteriorCache(x)))
  testthat::local_mocked_bindings(
    .ClusterCacheVersion = function() .Machine[["integer.max"]],
    .package = "StratoBayes"
  )
  expect_null(.PosteriorCache(x))
})

test_that("a stratCluster stamp does not depend on the algorithm version", {
  stamp <- .CacheStamp(stratPosterior1[["samples"]], stratPosterior1[["nRun"]])
  testthat::local_mocked_bindings(
    .ClusterCacheVersion = function() .Machine[["integer.max"]],
    .package = "StratoBayes"
  )
  expect_true(.StampMatches(stamp, stratPosterior1[["samples"]],
                            stratPosterior1[["nRun"]]))
})

test_that("a copy with different model$parametersNames disowns the cache", {
  x <- .CachedPosterior()
  y <- x
  y[["model"]][["parametersNames"]][1] <- "notAParameter"
  expect_false(is.null(.PosteriorCache(x)))
  expect_null(.PosteriorCache(y))
})

test_that("the subsample is the same under any ambient RNGkind (#2172)", {
  n <- 60L
  clustDat <- cbind(seq_len(n) + sin(seq_len(n)), cos(seq_len(n)))
  kept <- new.env(parent = emptyenv())
  testthat::local_mocked_bindings(
    .ProtoCluster = function(clustDat, ...) {
      kept[["rows"]] <- clustDat
      rep.int(1L, nrow(clustDat))
    },
    .package = "StratoBayes"
  )
  Subsample <- function() {
    .ProtoClusterSubsample(clustDat, maxClusterSamples = 20L)
    kept[["rows"]]
  }
  original <- RNGkind()
  withr::defer(RNGkind(original[1], original[2], original[3]))

  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  reference <- Subsample()
  suppressWarnings(RNGkind("L'Ecuyer-CMRG", "Box-Muller", "Rounding"))
  withr::local_seed(1)
  seedBefore <- .Random.seed
  kindBefore <- RNGkind()
  expect_identical(Subsample(), reference)
  expect_identical(.Random.seed, seedBefore)
  expect_identical(RNGkind(), kindBefore)
})

test_that("Cluster() memo treats 12L and 12, integer and double rows alike", {
  x <- .CachedPosterior()
  nEntries <- function() length(.subset2(x, ".cache")[["clusterCache"]])

  Cluster(x, clustMax = 12L)
  Cluster(x, clustMax = 12)
  expect_identical(nEntries(), 1L)

  rows <- ExtractIterations(x, "all", burnIn = 0.3)
  Cluster(x, selectRows = rows)
  Cluster(x, selectRows = lapply(rows, as.numeric))
  expect_identical(nEntries(), 2L)
})

# ---------------------------------------------------------------------------
# #2173
# ---------------------------------------------------------------------------

test_that("a column NA in one cluster does not bias assignment towards it", {
  n <- 100L
  clustDat <- cbind(rep(0, n), rep(0, n),
                    c(rep(c(-1, 1), length.out = n - 6L), rep(c(-4.6, 4.6), 3)))
  clustDat[seq_len(20L), 1:2] <- 3
  clustDat[seq_len(20L), 3] <- NA_real_
  # The NA rows are the only cluster whose members lack column 3
  testthat::local_mocked_bindings(
    .ProtoCluster = function(clustDat, ...) 1L + is.na(clustDat[, 3]),
    .package = "StratoBayes"
  )
  labels <- .ProtoClusterSubsample(clustDat, maxClusterSamples = 60L)
  # An off-centre row is ~21 squared units from its own centroid, and 18 from
  # the NA cluster's on columns 1 and 2 alone: nearer unscaled, farther (27)
  # once rescaled for the missing column as dist() does.
  offCentre <- abs(clustDat[, 3]) > 4 & !is.na(clustDat[, 3])
  expect_true(any(offCentre))
  expect_true(all(labels[offCentre] == 1L))
})

test_that("the high silOutlierThreshold warning is issued once, not per k", {
  set.seed(1)
  clustDat <- rbind(matrix(rnorm(60, 0, 0.5), 30), matrix(rnorm(60, 8, 0.5), 30),
                    matrix(rnorm(60, 16, 0.5), 30))
  warned <- new.env(parent = emptyenv())
  warned[["n"]] <- 0L
  withCallingHandlers(
    .ProtoCluster(clustDat, clustMax = 6L, silOutlierThreshold = 10),
    warning = function(w) {
      if (grepl("much higher", conditionMessage(w))) {
        warned[["n"]] <- warned[["n"]] + 1L
      }
      invokeRestart("muffleWarning")
    }
  )
  expect_identical(warned[["n"]], 1L)
})

test_that(".ProtoClusterFast() breaks tied maximal gaps to the smaller k", {
  n <- 10L
  clustMax <- 5L
  # Window heights[5:9] have gaps 2, 0, 2, 0: the first and third are tied.
  heights <- c(0.1, 0.2, 0.3, 0.4, 1, 3, 3, 5, 5)
  testthat::local_mocked_bindings(
    protoclust = function(d) list(height = heights),
    cutree = function(tree, k = NULL, h = NULL) rep.int(as.integer(k), n),
    .package = "StratoBayes"
  )
  got <- .ProtoClusterFast(matrix(seq_len(n * 2), n, 2), clustMax = clustMax)
  expect_identical(as.vector(got), rep.int(3L, n))
})

# ---------------------------------------------------------------------------
# #1701
# ---------------------------------------------------------------------------

test_that(".DeterministicSeed() survives an overflowing accumulator", {
  seed <- .DeterministicSeed(matrix(1e308, 3000, 2))
  expect_false(is.na(seed))
  expect_no_error(set.seed(seed))
})

test_that("returnClusterData column names stay unique when heights round alike",
          {
            x <- stratPosterior1
            site <- x[["model"]][["siteIndices"]][[1]]
            expect_length(x[["model"]][["heightsForClustering"]][[site]], 2L)
            x[["model"]][["heightsForClustering"]][[site]][] <-
              c(1.99, 2.01)
            colNames <- names(Cluster(x, returnClusterData = TRUE)[[
              "clusterData"]])
            expect_false(anyDuplicated(colNames) > 0L)
          })

# ---------------------------------------------------------------------------
# #2253
# ---------------------------------------------------------------------------

test_that("an edit to an NA-padded posterior disowns its cache (#2253)", {
  x <- stratPosterior5b
  samples <- x[["samples"]]
  n <- length(samples)
  probed <- unique(as.integer(seq.int(1, n, length.out = min(n, 32L))))
  expect_true(anyNA(samples))
  target <- setdiff(which(!is.na(samples)), probed)[1]
  y <- x
  y[["samples"]][target] <- y[["samples"]][target] + 1000
  expect_false(.StampMatches(.PosteriorStamp(x), y[["samples"]], y[["nRun"]],
                             y[["model"]], y[["data"]], y[["mcmcSummary"]]))
  expect_true(.StampMatches(.PosteriorStamp(x), x[["samples"]], x[["nRun"]],
                            x[["model"]], x[["data"]], x[["mcmcSummary"]]))
})

test_that("a stratCluster stamp with an NA total from an older release matches",
          {
            samples <- stratPosterior5b[["samples"]]
            stamp <- .CacheStamp(samples, stratPosterior5b[["nRun"]])
            stamp[["total"]] <- NA_real_
            expect_true(.StampMatches(stamp, samples,
                                      stratPosterior5b[["nRun"]]))
          })

# ---------------------------------------------------------------------------
# #2253: infinite cells
# ---------------------------------------------------------------------------

test_that("an edit to a posterior holding an infinite cell disowns its cache", {
  x <- stratPosterior4b
  x[["samples"]][3] <- -Inf
  n <- length(x[["samples"]])
  probed <- unique(as.integer(seq.int(1, n, length.out = min(n, 32L))))
  target <- setdiff(which(is.finite(x[["samples"]])), probed)[1]
  y <- x
  y[["samples"]][target] <- y[["samples"]][target] + 1000
  Matches <- function(a, b) {
    .StampMatches(.PosteriorStamp(a), b[["samples"]], b[["nRun"]],
                  b[["model"]], b[["data"]], b[["mcmcSummary"]])
  }
  expect_true(Matches(x, x))
  expect_false(Matches(x, y))
})
