# A live-plot file that cannot be written costs a frame, never the run (#2333).

test_that("#2333: an unwritable plot-samples file warns and leaves no temp", {
  dir <- withr::local_tempdir()
  dir.create(file.path(dir, "m_plot_samples_run_1_temp.rds"))
  expect_warning(
    .SafeWriteSamplesForPlotting(dir, "m", 1, matrix(1)),
    "Could not write live-plot file"
  )
  expect_false(file.exists(file.path(dir, "m_plot_samples_run_1.rds")))
})

test_that("#2333: an unwritable iteration marker warns and is not published", {
  dir <- withr::local_tempdir()
  marker <- file.path(dir, "m_plotIteration")
  dir.create(paste0(marker, "_1_write.txt"))
  expect_warning(.WritePlotFrame(marker, 1, frame = 1, iterations = 10),
                 "Could not write live-plot file")
  expect_false(file.exists(paste0(marker, "_read.txt")))
})

test_that("#2333: a run with unwritable visualise files keeps plotting", {
  dir <- withr::local_tempdir()
  withr::local_options(StratoBayes.openBrowser = FALSE)
  for (blocked in c("m_results.html", "m_plot_samples_run_1_temp.rds",
                    "m_plotIteration_1_write.txt")) {
    dir.create(file.path(dir, blocked))
  }
  seen <- new.env()
  seen$plotted <- integer(0)
  seen$warnings <- character(0)
  local_mocked_bindings(
    .PlotDuringMCMC = function(data, model, mcmc, modelName,
                               saveVisualiseDir, nRun, run, isParallel,
                               visualise, colourScale, i) {
      seen$plotted <- c(seen$plotted, i)
      list(run = run, iterations = rep(i, nRun), files = list())
    }
  )

  result <- withCallingHandlers(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                  runParallel = TRUE, nCores = 1L, nIter = 100, nChains = 2,
                  nThreads = 1, seed = 1, quiet = TRUE, modelDir = dir,
                  modelName = "m",
                  visualise = list(interval = 20, signal = 1, parameter = 1)),
    warning = function(w) {
      seen$warnings <- c(seen$warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  expect_s3_class(result, "StratPosterior")
  # Every frame after the first needs the plot lock released after the failed
  # html rewrite.
  expect_gt(length(seen$plotted), 2)
  failed <- grep("Could not write live-plot file", seen$warnings, value = TRUE)
  expect_true(any(grepl("m_results.html", failed, fixed = TRUE)))
  expect_true(any(grepl("plot_samples_run_1_temp.rds", failed, fixed = TRUE)))
  expect_true(any(grepl("plotIteration_1_write.txt", failed, fixed = TRUE)))
})

test_that("#2333: visualiseDir resolves to an absolute directory", {
  modelDir <- withr::local_tempdir()
  expect_equal(.ResolveVisualiseDir(NULL, modelDir),
               normalizePath(modelDir, winslash = "/"))

  withr::local_dir(withr::local_tempdir())
  resolved <- .ResolveVisualiseDir(file.path("live", "plots"), modelDir)
  expect_true(dir.exists(resolved))
  expect_equal(resolved,
               normalizePath(file.path(getwd(), "live", "plots"),
                             winslash = "/"))

  expect_error(.ResolveVisualiseDir(c("a", "b"), modelDir), "single path")
  expect_error(.ResolveVisualiseDir(NA_character_, modelDir), "single path")
  expect_error(.ResolveVisualiseDir(1, modelDir), "single path")
})

# Directories where the visualise files would go in `modelDir` make any write
# that still lands there fail with a warning.
BlockVisualiseFiles <- function(dir, modelName, nRun) {
  blocked <- c(
    paste0(modelName, "_results.html"),
    paste0(modelName, "_plot.lock"),
    paste0(modelName, "_plot_inactive.lock"),
    paste0(modelName, "_plotIteration_read.txt"),
    paste0(modelName, "_plot_samples_run_", seq_len(nRun), "_temp.rds"),
    paste0(modelName, "_plotIteration_", seq_len(nRun), "_write.txt")
  )
  for (path in file.path(dir, blocked)) dir.create(path)
}

test_that("#2333: every visualise file goes to visualiseDir", {
  modelDir <- withr::local_tempdir()
  visualiseDir <- file.path(withr::local_tempdir(), "live")
  withr::local_options(StratoBayes.openBrowser = FALSE)
  BlockVisualiseFiles(modelDir, "m", nRun = 1)
  seen <- new.env()
  seen$files <- character(0)
  local_mocked_bindings(
    .PlotDuringMCMC = function(data, model, mcmc, modelName,
                               saveVisualiseDir, nRun, run, isParallel,
                               visualise, colourScale, i) {
      seen$files <- union(seen$files, list.files(saveVisualiseDir))
      list(run = run, iterations = rep(i, nRun), files = list())
    }
  )

  expect_no_warning(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                  runParallel = TRUE, nCores = 1L, nIter = 60, nChains = 2,
                  nThreads = 1, seed = 1, quiet = TRUE, modelDir = modelDir,
                  modelName = "m", visualiseDir = visualiseDir,
                  visualise = list(interval = 20, signal = 1, parameter = 1))
  )
  expect_true(all(c("m_results.html", "m_plot.lock", "m_plot_inactive.lock",
                    "m_plotIteration_read.txt", "m_plot_samples_run_1.rds")
                  %in% seen$files))
})

test_that("#2333: parallel workers share the caller's visualiseDir", {
  skip_on_cran()
  skip_if_not_installed("future")
  skip_if_not_installed("future.apply")
  modelDir <- withr::local_tempdir()
  visualiseDir <- withr::local_tempdir()
  withr::local_options(StratoBayes.openBrowser = FALSE)
  BlockVisualiseFiles(modelDir, "m", nRun = 2)

  result <- expect_no_warning(
    RunStratModel(stratData1, stratModel = stratModel1, nRun = 2,
                  runParallel = TRUE, nCores = 2L, nIter = 60, nChains = 2,
                  nThreads = 1L, seed = 1:2, quiet = TRUE, modelDir = modelDir,
                  modelName = "m", visualiseDir = visualiseDir,
                  visualise = list(interval = 20, signal = 1, parameter = 1))
  )
  expect_s3_class(result, "StratPosterior")
  # The caller collects the frames, so the last one outlives the run.
  expect_true(file.exists(file.path(visualiseDir, "m_results.html")))
  expect_true(all(file.exists(file.path(
    visualiseDir, c("m_plot_run_1_sig_1.png", "m_plot_run_2_sig_1.png",
                    "m_plot_parameter_posterior.png")
  ))))
  expect_false(any(grepl("lock|_plotIteration|_plot_samples",
                         list.files(visualiseDir))))
})

test_that("#2333: the frame manifest is valid JSON with unsanitised names", {
  dir <- withr::local_tempdir()
  files <- list(
    list(file = "m_plot_run_2_sig_1.png", run = 2L, signal = 1L,
         signalName = "d13C"),
    list(file = "m_plot_parameter_alpha_Well_A.png",
         parameter = "alpha_Well A \"q\" \\ \né")
  )
  .WritePlotManifest(dir, "m", frame = 3, iterations = c(1200, NA), files)
  expect_false(file.exists(file.path(dir, "m_plot_frame.json.tmp")))

  manifest <- jsonlite::fromJSON(file.path(dir, "m_plot_frame.json"),
                                 simplifyVector = FALSE)
  expect_equal(manifest$frame, 3)
  expect_equal(manifest$runs[[1]], list(run = 1L, iteration = 1200L))
  expect_null(manifest$runs[[2]]$iteration)
  expect_equal(manifest$files[[1]]$signalName, "d13C")
  expect_equal(manifest$files[[2]]$parameter,
               "alpha_Well A \"q\" \\ \né")
})

test_that("#2333: every run, however late it starts, ends in the last frame", {
  skip_on_cran()
  skip_if_not_installed("future")
  skip_if_not_installed("future.apply")
  visualiseDir <- withr::local_tempdir()
  withr::local_options(StratoBayes.openBrowser = FALSE)

  # Four runs on two cores: the second pair starts once the first has
  # finished, and so behind the furthest iteration any frame has shown.
  RunStratModel(stratData1, stratModel = stratModel1, nRun = 4,
                runParallel = TRUE, nCores = 2L, nIter = 60, nChains = 2,
                nThreads = 1L, seed = 1:4, quiet = TRUE,
                convergenceStop = FALSE,
                modelDir = withr::local_tempdir(), modelName = "m",
                visualiseDir = visualiseDir,
                visualise = list(interval = 20, signal = 1, parameter = 1))

  manifest <- jsonlite::fromJSON(file.path(visualiseDir, "m_plot_frame.json"),
                                 simplifyVector = FALSE)
  expect_gt(manifest$frame, 1)
  expect_equal(vapply(manifest$runs, `[[`, numeric(1), "iteration"),
               rep(60, 4))
  files <- vapply(manifest$files, `[[`, character(1), "file")
  expect_setequal(files, c(paste0("m_plot_run_", 1:4, "_sig_1.png"),
                           "m_plot_parameter_posterior.png",
                           paste0("m_plot_parameter_",
                                  stratModel1[["outputParams"]][1], ".png")))
  expect_true(all(file.exists(file.path(visualiseDir, files))))
})

test_that("#2333: the default visualiseDir leaves no frame files behind", {
  dir <- withr::local_tempdir()
  withr::local_options(StratoBayes.openBrowser = FALSE)
  RunStratModel(stratData1, stratModel = stratModel1, nRun = 1,
                runParallel = TRUE, nCores = 1L, nIter = 40, nChains = 2,
                nThreads = 1, seed = 1, quiet = TRUE, modelDir = dir,
                modelName = "m",
                visualise = list(interval = 20, signal = 1, parameter = 1))
  expect_false(any(grepl("_plot|_results.html", list.files(dir))))
})
