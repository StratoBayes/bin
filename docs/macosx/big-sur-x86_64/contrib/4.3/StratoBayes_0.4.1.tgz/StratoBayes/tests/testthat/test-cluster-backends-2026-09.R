test_that("pam and proto agree when an all-outlier k is scored (#692)", {
  set.seed(1)
  dat <- matrix(c(rnorm(10), rnorm(10, 50)), ncol = 1)
  pam <- Cluster(dat, clusterMethod = "pam", silOutlierThreshold = 1)
  proto <- suppressWarnings(
    Cluster(dat, clusterMethod = "proto", silOutlierThreshold = 1)
  )
  expect_equal(proto, pam)

  floorPam <- Cluster(dat, "pam", silCutOff = -1, silOutlierThreshold = 1)
  expect_false(all(floorPam == 0L))
  floorProto <- suppressWarnings(
    Cluster(dat, "proto", silCutOff = -1, silOutlierThreshold = 1)
  )
  expect_equal(floorProto, floorPam)
})

test_that("Cluster() accepts a numeric vector and rejects a list (#693)", {
  x <- c(1, 2, 3, 8, 9, 2)
  expect_equal(length(Cluster(x, clusterMethod = "pam")), 6L)
  expect_equal(length(Cluster(x, clusterMethod = "proto")), 6L)
  expect_error(Cluster(list(1, 2, 3, 4)), "numeric vector, matrix or data.frame")
})

test_that("Cluster() returns integer storage on every path (#1699)", {
  set.seed(1)
  dat <- matrix(c(rnorm(10), rnorm(10, 50)), ncol = 1)
  for (method in c("pam", "proto")) {
    expect_type(Cluster(dat, clusterMethod = method), "integer")
    expect_type(
      suppressWarnings(
        Cluster(dat, clusterMethod = method, silOutlierThreshold = 1.5)
      ),
      "integer"
    )
    expect_type(
      Cluster(dat, clusterMethod = method, silCutOff = 1),
      "integer"
    )
  }
})

test_that(".SilhouetteFromSums() rejects non-positive labels (#1700)", {
  groupSums <- matrix(1, 4, 2)
  expect_error(
    .SilhouetteFromSums(groupSums, c(2, 2), c(1L, 2L), c(1L, 0L, 2L, 2L)),
    "positive"
  )
})

test_that(".ClustInfo() takes its recent-row count from .RecentRowCount() (#1700)", {
  set.seed(1)
  dat <- matrix(rnorm(40), ncol = 1)
  cl <- rep(1L, 40)
  expected <- .ClustInfo(dat, cl, recentFraction = 0.5)
  testthat::local_mocked_bindings(.RecentRowCount = function(...) 40L)
  expect_false(isTRUE(all.equal(.ClustInfo(dat, cl, recentFraction = 0.5),
                                expected)))
})
