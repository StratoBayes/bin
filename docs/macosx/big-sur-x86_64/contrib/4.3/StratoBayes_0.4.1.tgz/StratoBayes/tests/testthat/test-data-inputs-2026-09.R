test_that("#2113: a site named 'all' does not change bSigma", {
  Build <- function(siteName) {
    d <- signalData1
    d[["value"]] <- d[["value"]] * 0.01
    d[["site"]][d[["site"]] == "site_2"] <- siteName
    parts <- partsData1
    parts[["site"]][parts[["site"]] == "site_2"] <- siteName
    suppressMessages(
      StratModel(StratData(d, parts = parts), alignmentScale = "height",
                 sedModel = "site", nKnots = 15)
    )
  }
  expect_equal(
    Build("all")[["priors"]][["gibbs"]][["bSigma"]],
    Build("renamed")[["priors"]][["gibbs"]][["bSigma"]]
  )
})

test_that("#2113: a signal named 'all' resolves to itself", {
  d <- data.frame(
    site = rep(c("a", "b"), each = 4),
    height = rep(1:4, 2),
    all = c(1, 2, 3, 4, 2, 3, 4, 5),
    other = c(4, 3, 2, 1, 5, 4, 3, 2)
  )
  sd <- StratData(d, signalColumn = c("all", "other"))
  expect_false(.ValidateSignal("all", sd)[["allSignals"]])
  expect_equal(.ValidateSignal("all", sd)[["signal"]], "all")
  expect_equal(SignalLookUp(sd, "value", "a", "all", FALSE), 1:4)
})

test_that("#2117: ThinSignal blocks keep the requested width", {
  d <- data.frame(site = "s1", height = c(seq(0, 1, by = 0.1), 100),
                  value = 1:12)
  expect_equal(nrow(ThinSignal(d, blockLength = 0.1)), 12)
})

test_that("#2117: a tiny blockLength neither errors nor allocates per block", {
  d <- data.frame(site = "s", height = c(0, 0.5, 1e6), value = 1:3)
  expect_equal(nrow(ThinSignal(d, blockLength = 1e-4)), 3)
})
