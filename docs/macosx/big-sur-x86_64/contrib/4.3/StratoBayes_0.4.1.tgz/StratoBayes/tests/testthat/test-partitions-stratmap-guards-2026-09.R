signal <- data.frame(site = "a", height = seq(0, 10, length.out = 11))

test_that("Partitions() rejects a non-scalar `distribute` cleanly (#1613)", {
  expect_error(
    Partitions(signal, nStrata = 2, distribute = c("points", "height")),
    "`distribute` must be a single string"
  )
  expect_error(
    Partitions(signal, nStrata = 2, distribute = NULL),
    "`distribute` must be a single string"
  )
})

test_that("Partitions() rejects an infinite tie age (#1613)", {
  ties <- data.frame(site = "a", height = c(0, 5, 10), densityFun = "dnorm",
                     arg1 = c(10, Inf, 50), arg2 = 1)
  expect_error(
    Partitions(signal, nStrata = 2, ties = ties, distribute = "height"),
    "must be finite, got Inf"
  )
})

test_that("Partitions() rejects an infinite tie height (#1417)", {
  ties <- data.frame(site = "a", height = c(0, Inf, 10), densityFun = "dnorm",
                     arg1 = c(10, 20, 50), arg2 = 1)
  expect_error(
    Partitions(signal, nStrata = 2, ties = ties, distribute = "height"),
    "`ties\\[\\[height\\]\\]` contains infinite"
  )
})

test_that("StratMap() names an infinite height as such (#1708)", {
  expect_error(
    StratMap(stratPosterior1, heights = c(1, Inf), site = "site_2"),
    "heights must be finite"
  )
})

test_that("Partitions() height mode explains its point-count guard (#1708)", {
  expect_error(
    Partitions(data.frame(site = "a", height = c(0, 1)), nStrata = 2,
               distribute = "height"),
    "strata beyond the point count would be empty"
  )
})
