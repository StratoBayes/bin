# Red-team area 11 (Clustering): #1965, #1956, #1859, #1861, #1955.

# ---------------------------------------------------------------------------
# #1965: Cluster.default() validates neither clustMax nor silCutOff
# ---------------------------------------------------------------------------

set.seed(1)
threeGroupsDefault <- rbind(
  cbind(rnorm(60, 0), rnorm(60, 0)),
  cbind(rnorm(60, 30), rnorm(60, 0)),
  cbind(rnorm(60, 0), rnorm(60, 30))
)

test_that("Cluster.default() validates clustMax and silCutOff (#1965)", {
  expect_error(Cluster(threeGroupsDefault, clustMax = 1), "clustMax")
  expect_error(Cluster(threeGroupsDefault, clustMax = NA), "clustMax")
  expect_error(Cluster(threeGroupsDefault, silCutOff = 5), "silCutOff")
  expect_no_error(Cluster(threeGroupsDefault, clustMax = 12, silCutOff = 0.5))
})

test_that(paste0("Cluster.default() with clustMax = 1 no longer silently ",
                 "collapses (#1965)"), {
            # Before the fix, this silently returned one cluster for three
            # well-separated Gaussian groups; now it errors instead.
            expect_error(Cluster(threeGroupsDefault, clustMax = 1))
          })

test_that(paste0("hdbscan-only Cluster.default() calls skip clustMax/",
                 "silCutOff validation (#1965)"), {
            # `minPts`'s own precedent (#1288, #1604): an argument the chosen
            # backend never reads is not validated.
            expect_no_error(Cluster(threeGroupsDefault,
                                    clusterMethod = "hdbscan",
                                    minPts = 5, clustMax = NA, silCutOff = NA))
          })

# ---------------------------------------------------------------------------
# #1859: Cluster.StratPosterior()'s selectRows path silently misattributes
# rows to the wrong run when selectRows isn't a simple positive-index vector
# ---------------------------------------------------------------------------

test_that(paste0("a logical selectRows no longer silently stripes rows across ",
                 "runs (#1859)"), {
            # `TRUE` selects every row of the samples array, not the one row
            # its length implies, so `split()` used to stripe `clusters` across
            # runs with no warning.
            expect_error(Cluster(stratPosterior1, selectRows = TRUE),
                         "logical mask")
          })

test_that("a valid selectRows list still clusters correctly (#1859)", {
  rows <- ExtractIterations(stratPosterior1, "all", burnIn = 0.5)
  expect_no_error(cl <- Cluster(stratPosterior1, selectRows = rows))
  expect_equal(length(cl[["cluster"]]), sum(lengths(rows)))
})

# ---------------------------------------------------------------------------
# #1861: .ClustInfo()'s covariance-repair path leaves a corresponding NA mean
# untouched
# ---------------------------------------------------------------------------

test_that(".ClustInfo() does not leave a repaired cluster's mean as NA (#1861)",
          {
            set.seed(2)
            clustA <- cbind(rnorm(5, 0), rnorm(5, 0))
            clustA[1, 2] <- NA_real_ # poisons this cluster's cov() and mean
            clustB <- cbind(rnorm(5, 10), rnorm(5, 10))
            dat <- rbind(clustA, clustB)
            clusters <- rep(c(1L, 2L), each = 5L)

            info <- StratoBayes:::.ClustInfo(dat, clusters, recentFraction = 1)

            # Cluster 1 (the poisoned one) had its covariance repaired from
            # cluster 2's donor covariance; its mean must not still be NA.
            expect_false(anyNA(info[[1]][[1]]))
            expect_false(anyNA(info[[1]][[2]]))
          })

# ---------------------------------------------------------------------------
# #1956: .RescueAllNoiseClusters has a third, unrescued caller
# ---------------------------------------------------------------------------

.rt1956_make_mcmc <- function(nFree = 2L, histLen = 20L) {
  set.seed(3)
  mkHist <- function(n) matrix(rnorm(n * (nFree + 1L)), n, nFree + 1L)

  list(
    nChains       = 1L,
    currentIter   = 10L,
    endAdapting   = 100L,
    startAdapting = 1L,
    propose       = setNames(vector("list", 1L), "Multivariate"),
    temper        = list(temperatures = c(1.0, NA_real_), tempering = TRUE),
    metro         = list(
      historySize             = histLen,
      historyLength           = histLen,
      historyRingPos          = 1L,
      enableRingBuffer        = FALSE,
      clustWithParametersMCMC = TRUE,
      clustMethodMCMC         = "dbscan",
      clustMinPtsMCMC         = 5L,
      nProposals              = 1L,
      proposalValid           = matrix(FALSE, nrow = 1L, ncol = 1L,
                                       dimnames = list(NULL, "Multivariate")),
      proposalProbability     = matrix(0, nrow = 1L, ncol = 1L,
                                       dimnames = list(NULL, "Multivariate")),
      proposalArgs            = list(chain1 = list(Multivariate = NULL)),
      adaptProposal           = TRUE,
      chainHistory            = list(mkHist(histLen))
    )
  )
}

.rt1956_make_model <- function(nFree) {
  list(
    parametersLength         = nFree,
    parametersLengthNotFixed = nFree,
    ind = list(paramNotFixed = seq_len(nFree))
  )
}

test_that(paste0("the MCMC-adaptation hdbscan call is rescued like the other ",
                 "two entry points (#1956)"), {
            upd <- .GetUpdateProposal()
            nFree <- 2L

            captured <- new.env()
            testthat::local_mocked_bindings(
              .HdbscanCluster = function(clustDat, minPts) rep(0L,
                                                               nrow(clustDat)),
              .ClustInfo = function(clustDat, clusters, ...) {
                assign("clusters", clusters, envir = captured)
                list(list(rep(0, nFree), diag(nFree)))
              },
              .package = "StratoBayes"
            )

            mcmc <- .rt1956_make_mcmc(nFree = nFree)
            model <- .rt1956_make_model(nFree)

            upd(data = list(), model = model, mcmc = mcmc, chain = 1L,
                inLateAdaptation = FALSE)

            # Before the fix: all-noise (all 0L) reached .ClustInfo() unrescued
            # on this path. After the fix: rescued to a single cluster (all 1L),
            # matching Cluster.default() and Cluster.StratPosterior().
            expect_true(all(captured[["clusters"]] == 1L))
          })

# ---------------------------------------------------------------------------
# #1955: clustMinPtsMCMC warning misdescribes the failure as "unavailable"
# ---------------------------------------------------------------------------

test_that(paste0("RT-637's warning describes the actual degraded-proposal ",
                 "behaviour, not unavailability (#1955)"), {
            expect_warning(
              StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                        clustMethodMCMC = "dbscan", clustMinPtsMCMC = 1000),
              "single covariance"
            )
          })
