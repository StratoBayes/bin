test_that("ExtractIterations() does not leak unselected runs via stratCluster (#1448)", {
  clAll <- Cluster(stratPosterior1, burnIn = 0.5, runs = "all")
  rows <- ExtractIterations(stratPosterior1, alignment = 1, runs = 1,
                            stratCluster = clAll)
  expect_gt(length(rows[[1]]), 0)
  expect_equal(lengths(rows)[-1], rep(0L, stratPosterior1[["nRun"]] - 1L),
               ignore_attr = TRUE)
})

test_that("hist() ignores unselected runs of a wider stratCluster (#1448)", {
  pdf(NULL)
  on.exit(dev.off())
  clOne <- Cluster(stratPosterior1, burnIn = 0.5, runs = 1)
  clAll <- Cluster(stratPosterior1, burnIn = 0.5, runs = "all")
  args <- list(stratPosterior1, parameters = "lambda_value", runs = 1,
               alignment = 1)
  expect_identical(do.call(hist, c(args, list(stratCluster = clAll))),
                   do.call(hist, c(args, list(stratCluster = clOne))))
})

test_that("Plot entry points select only the chosen runs from a wider stratCluster (#1448)", {
  clAll <- Cluster(stratPosterior1, burnIn = 0.5, runs = "all")
  rows <- .StratClusterRows(clAll, 2L)
  nRun <- stratPosterior1[["nRun"]]
  expect_length(rows, nRun)
  expect_identical(rows[-2], vector("list", nRun - 1L))
  expect_identical(rows[[2]], clAll[["rowIndex"]][[2]])
})

test_that("ExtractParameters() bounds rows without completedIterIndex (#1161)", {
  sp <- stratPosterior1
  nRow <- dim(sp[["samples"]])[[1]]
  ref <- ExtractParameters(sp, parameters = "posterior", runs = 1)
  sp[["mcmcSummary"]][["completedIterIndex"]] <- NULL
  expect_equal(ExtractParameters(sp, parameters = "posterior", runs = 1), ref)
  expect_error(
    ExtractParameters(sp, parameters = "posterior", runs = 1,
                      selectRows = nRow + 5L),
    "could not be selected"
  )
})

test_that("ExtractParameters() prefix matches saved columns (#1951)", {
  saved <- dimnames(stratPosterior1[["samples"]])[["parameters"]]
  for (p in c("lam", "beta_")) {
    want <- saved[startsWith(saved, p)]
    expect_gt(length(want), 0)
    expect_identical(.ValidateModelParams(stratPosterior1, p), want)
  }
  expect_identical(
    .ValidateModelParams(stratPosterior1, "alp"),
    stratPosterior1[[c("model", "parametersNames")]][
      startsWith(stratPosterior1[[c("model", "parametersNames")]], "alp")]
  )
})

test_that("maxSamples never allocates a remainder row to a zero-row run (#1282)", {
  set.seed(1282)
  for (i in 1:300) {
    counts <- sample(c(0L, 0L, 1:60), sample(2:6, 1), replace = TRUE)
    if (sum(counts) < 2) next
    maxIt <- sample.int(max(1L, sum(counts) - 1L), 1)
    rows <- lapply(counts, seq_len)
    out <- suppressWarnings(.maxSampleDeterministicRows(rows, maxIt))
    expect_identical(lengths(out)[counts == 0], integer(sum(counts == 0)))
    expect_lte(sum(lengths(out)), maxIt)
  }
})

test_that("name-prefix matching leaves the special prior/likelihood names alone (#1951)", {
  expect_identical(.ValidateModelParams(stratPosterior1, "prior"), "prior")
  expect_identical(.ValidateModelParams(stratPosterior1, "likelihood"),
                   "likelihood")
})

test_that(".StratClusterRows passes a non-list rowIndex through (#1448)", {
  expect_identical(.StratClusterRows(list(rowIndex = 1:5), 1L), 1:5)
})
