## ---- #2194: prior mapping checks the StratModel against stratData --------

ThreeRatePartitionData <- function() {
  signal <- data.frame(site = rep(c("1", "2"), each = 12),
                       height = rep(0:11, 2),
                       value = sin(1:24))
  parts <- data.frame(site = rep(c("1", "2"), each = 3),
                      height = rep(c(4, 8, 11), 2),
                      partition = rep(c("a", "b", "c"), 2))
  StratData(signal, parts = parts)
}

test_that("StratMap() refuses a stratData whose gaps the model lacks", {
  # same three sites, but stratData2 has a gap at site 2 that stratModel1
  # has no parameter for
  expect_error(
    StratMap(stratModel1, heights = 1, site = 2, stratData = stratData2,
             maxSamples = 5),
    "does not correspond to `stratObject`: its gaps differ"
  )
})

test_that("StratMap() refuses a stratData with a different site count", {
  expect_error(
    StratMap(stratModel1, heights = 1, site = 2, stratData = stratData3,
             maxSamples = 5),
    "built for 3 site\\(s\\) but `stratData` has 2"
  )
})

test_that("StratMap()/Tops() refuse more rate partitions than the model", {
  data3 <- ThreeRatePartitionData()
  expect_error(
    StratMap(stratModel3, heights = 2, site = 2, stratData = data3,
             maxSamples = 5),
    "does not correspond to `stratObject`: its rate partitions"
  )
  expect_error(
    Tops(stratModel3, refHeights = 2, stratData = data3, maxSamples = 5),
    "does not correspond to `stratObject`: its rate partitions"
  )
})

test_that("StratMap() refuses a stratData with other partition labels", {
  # same structure as stratData3, but its partitions carry other names, so
  # the model's per-partition priors would land on the wrong partitions
  expect_error(
    StratMap(stratModel3, heights = 1, site = 2, stratData = stratData4,
             maxSamples = 5),
    "its site or partition labels differ"
  )
  expect_no_error(
    StratMap(stratModel3, heights = 1, site = 2, stratData = stratData3,
             maxSamples = 5)
  )
})

test_that(".sb_age_convert_batch() refuses a gamma shorter than the data", {
  params <- matrix(0, 2, length(stratModel3[[c("ind", "names")]]))
  shortGamma <- stratModel3[["ind"]]
  shortGamma[["gamma"]] <- shortGamma[["gamma"]][1]
  expect_error(
    .sb_age_convert_batch(stratData3, shortGamma, params, c(1, 2), 2L),
    "the model has 1: the model does not match the data"
  )
  expect_error(
    .sb_age_convert_batch(ThreeRatePartitionData(), stratModel3[["ind"]],
                          params, c(1, 2), 2L),
    "The data have 3 partition\\(s\\) with a sedimentation rate"
  )
})

test_that(".sb_age_convert_batch() refuses gapInd rows short of nBound", {
  params <- matrix(0, 2, length(stratModel3[[c("ind", "names")]]))
  shortGapInd <- stratModel3[["ind"]]
  shortGapInd[["gapInd"]] <- shortGapInd[["gapInd"]][1, , drop = FALSE]
  expect_error(
    .sb_age_convert_batch(stratData3, shortGapInd, params, c(1, 2), 2L),
    "`indices\\$gapInd` has no entry for partition 3 of site 2"
  )
})

test_that(".sb_age_convert_batch() refuses index values out of range", {
  data3 <- .EnsurePreExtracted(stratData3)
  params <- matrix(0, 2, length(stratModel3[[c("ind", "names")]]))
  badAlpha <- stratModel3[["ind"]]
  badAlpha[["alpha"]] <- 99L
  expect_error(
    .sb_age_convert_batch(data3, badAlpha, params, c(1, 2), 2L),
    "`indices\\$alpha` refers to a parameter outside 1 to 4"
  )

  sitePartition <- .CreateIndices(data3, "height", "site, partition", "middle")
  sitePartition[["gammaInd"]][1, 2] <- 99L
  expect_error(
    .sb_age_convert_batch(data3, sitePartition,
                          matrix(0, 2, length(sitePartition[["names"]])),
                          c(1, 2), 2L),
    "`indices\\$gammaInd` for partition 1 of site 2 is outside"
  )

  data2 <- .EnsurePreExtracted(stratData2)
  agePartition <- .CreateIndices(data2, "age", "partition", "middle")
  agePartition[["gamma"]] <- agePartition[["gamma"]][1]
  expect_error(
    .sb_age_convert_batch(data2, agePartition,
                          matrix(0, 2, length(agePartition[["names"]])),
                          data2[[c("partsAttr", "BoundLow")]][1, 2], 2L),
    "`partsAttr\\$sedRatesDF` for partition 1 of site 2 is outside 1 to 1"
  )
})

## ---- #2193: Partitions(distribute = "height", ties =) top boundary --------

test_that("Partitions() ties output ends exactly at the top height", {
  signal <- data.frame(site = rep(c("a", "b"), each = 13),
                       height = rep(0:12, 2), value = 1:26)
  ties <- data.frame(site = rep(c("a", "b"), each = 2), height = c(0, 10),
                     densityFun = "dnorm", arg1 = c(1, 7), arg2 = 0.001)
  parts <- Partitions(signal, nStrata = 3, distribute = "height", ties = ties)
  topHeights <- vapply(split(parts[["height"]], parts[["site"]]), max,
                       numeric(1))
  expect_identical(unname(topHeights), c(12, 12))
  expect_s3_class(StratData(signal, parts = parts), "StratData")
})

test_that("Partitions() ties output inside the tie range ends at the top", {
  signal <- data.frame(site = "a", height = c(0, 0.5, 1), value = 1:3)
  ties <- data.frame(site = "a", height = c(0, 3), densityFun = "dnorm",
                     arg1 = c(1, 3), arg2 = c(0.001, 0.001))
  parts <- Partitions(signal, nStrata = 2, distribute = "height", ties = ties)
  expect_identical(max(parts[["height"]]), 1)
})

## ---- #2195: TopsPlot() default heights for refHeightsSite -----------------

test_that("TopsPlot() default refHeights come from refHeightsSite", {
  bounds <- stratPosterior1[[c("data", "partsAttr", "Bound")]]
  for (k in 2:3) {
    out <- TopsPlot(stratPosterior1, refHeightsSite = k, display = FALSE,
                    maxSamples = 20)
    expect_equal(unique(out[["refHeight"]]), c(0.1, 0.5, 0.9) * bounds[1, k])
  }
})

## ---- #2196: Tops()/StratMap() summaries of empty input --------------------

test_that("Tops() warns on a zero-sample selection", {
  nPar <- stratPosterior1[[c("model", "parametersLength")]]
  local_mocked_bindings(
    ExtractParameters = function(...) matrix(numeric(0), 0, nPar)
  )
  expect_warning(
    out <- Tops(stratPosterior1, refHeights = 1),
    "No mapping samples"
  )
  expect_true(all(is.na(out[["mean"]])))
})

test_that("StratMap() reports NA, not NaN, for an all-NA row", {
  local_mocked_bindings(
    .AgeConversionBatch = function(parameterMatrix, heights, ...) {
      converted <- matrix(1, length(heights), nrow(parameterMatrix))
      converted[1, ] <- NA
      converted
    }
  )
  out <- StratMap(stratPosterior1, heights = c(1, 2), site = 2,
                  maxSamples = 20)
  expect_identical(out[["mean"]], c(NA_real_, 1))
})

test_that("Tops() reports NA, not NaN, for an all-NA row", {
  local_mocked_bindings(
    .CalculateRefHeightToHeights = function(refHeights, ...) {
      c(NA, rep(1, length(refHeights) - 1))
    }
  )
  out <- Tops(stratPosterior1, refHeights = c(1, 2), maxSamples = 20)
  expect_identical(out[["mean"]], c(NA_real_, NA_real_, 1, 1))
})

## ---- #2207: C++ utility wrappers ------------------------------------------

test_that(".MatrixMult()/.MatrixVectorMult() refuse non-real operands", {
  numeric2 <- diag(2)
  expect_error(.MatrixMult(matrix(c("1", "2", "3", "4"), 2), numeric2),
               "`A` must be numeric or logical, not character")
  expect_error(.MatrixMult(numeric2, matrix(1i, 2, 2)),
               "`B` must be numeric or logical, not complex")
  expect_error(.MatrixVectorMult(numeric2, c("1", "2")),
               "`B` must be numeric or logical, not character")
  expect_error(.MatrixVectorMult(numeric2, list(1, 2)), "`B` is not a vector")
  expect_equal(.MatrixMult(numeric2 == 1, numeric2), numeric2 %*% numeric2)
  expect_equal(.MatrixVectorMult(numeric2, c(TRUE, FALSE)), c(1, 0))
})

test_that(".sb_age_convert_batch() accepts a full saved parameter row", {
  ind <- stratModel3[["ind"]]
  params <- matrix(0, 2, length(ind[["names"]]))
  expected <- .sb_age_convert_batch(stratData3, ind, params, c(1, 2), 2L)
  expect_identical(
    .sb_age_convert_batch(stratData3, ind, cbind(params, 99), c(1, 2), 2L),
    expected
  )
  expect_error(
    .sb_age_convert_batch(stratData3, ind, params[, -1, drop = FALSE],
                          c(1, 2), 2L),
    "at least one column per model parameter \\(4\\)"
  )
})
