RunQuiet <- function(...) {
  RunStratModel(
    ..., quiet = TRUE, visualise = FALSE, runParallel = FALSE, nThreads = 1L
  )
}

# Every `StratMCMC()` argument `.BuildContinuationMCMC()` requires, at its
# `StratMCMC()` default, with `...` overriding.
ContinuationArgs <- function(...) {
  defaults <- formals(StratMCMC)
  internal <- c("stratModel", "stratMCMC", "completedIter", "nThreads",
                ".adaptTemperaturesExplicit")
  args <- lapply(defaults[setdiff(names(defaults), internal)], eval)
  overrides <- list(...)
  args[names(overrides)] <- overrides
  args
}

FixedAlphaModel <- function(fixed) {
  priors <- stratModel1[["priors"]][["metro"]]
  priors[names(fixed)] <- lapply(fixed, Fixed)
  StratModel(stratData = stratData1, priors = priors,
             alignmentScale = stratModel1[["alignmentScale"]],
             sedModel = stratModel1[["sedModel"]], alphaPosition = "bottom",
             flexibleKnots = FALSE, knotRange = c(-5, 12))
}

activatedWhenFrozen <- c("Univariate", "ShiftAlphas", "ShiftAlphasRandJoint",
                         "ShiftAlphasRandSeparate")

# ── #2168 item 1: frozen continuation of a never-adapted checkpoint ──────────

test_that("frozen continuation of an unadapted checkpoint activates (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 1000, nChains = 2, nThreads = 1L)
  # Premise: a checkpoint taken before the first adaptation step.
  expect_false(any(old[[c("metro", "proposalValid")]][, "Univariate"]))

  new <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 10,
                   nIter = 100, adaptProposal = FALSE, nThreads = 1L)
  cont <- .UpdateMCMCforContinuedRun(old, new, newRun = FALSE)

  metro <- cont[["metro"]]
  expect_true(all(metro[["proposalValid"]][, activatedWhenFrozen]))
  expect_true(all(metro[["proposalProbability"]][, activatedWhenFrozen] > 0))
  expect_false(is.null(metro[["proposalArgs"]][[1]][["Univariate"]]))
  expect_false(any(metro[["proposalValid"]][, "Multivariate"]))
})

test_that("a frozen continuation leaves an adapted checkpoint alone (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 1000, nChains = 2, nThreads = 1L)
  # As adaptation leaves it: Univariate live, a shift variant switched off.
  old[[c("metro", "proposalValid")]][, "Univariate"] <- TRUE
  old[[c("metro", "proposalProbability")]][, "Univariate"] <- 0.5

  new <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 10,
                   nIter = 100, adaptProposal = FALSE, nThreads = 1L)
  cont <- .UpdateMCMCforContinuedRun(old, new, newRun = FALSE)

  expect_false(any(cont[[c("metro", "proposalValid")]][, "ShiftAlphas"]))
  expect_equal(cont[[c("metro", "proposalProbability")]][, "ShiftAlphas"],
               old[[c("metro", "proposalProbability")]][, "ShiftAlphas"])
})

test_that("unadapted gradient checkpoint runs NUTS untuned, loudly (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 1000, nChains = 2, nThreads = 1L,
                   gradientProposals = "on")
  new <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 10,
                   nIter = 100, adaptProposal = FALSE, nThreads = 1L,
                   gradientProposals = "on")

  expect_warning(
    cont <- .UpdateMCMCforContinuedRun(old, new, newRun = FALSE),
    "runs NUTS untuned"
  )
  metro <- cont[["metro"]]
  expect_true(all(metro[["proposalValid"]][, "NUTS"]))
  nuts <- metro[["proposalArgs"]][[1]][["NUTS"]]
  expect_false(is.null(nuts))
  expect_false(nuts[["adaptStepSize"]])
})

# ── #2168 item 2: inherited writeMCMCfile = FALSE ────────────────────────────

test_that("an inherited writeMCMCfile = FALSE is named as inherited (#2168)", {
  skip_on_cran()
  r1 <- RunQuiet(stratData1, stratModel = stratModel1, nIter = 5,
                 nChains = 2, seed = 1, writeMCMCfile = FALSE,
                 convergenceStop = FALSE, modelDir = withr::local_tempdir())

  expect_error(
    RunQuiet(r1),
    "inherited from the run being continued.*`nIter`.*`writeMCMCfile`"
  )
})

# ── #2168 item 3 / #1549: gradientProposals on a continuation ────────────────

test_that("a sedSmooth run stored as \"on\" continues quietly (#2168)", {
  skip_on_cran()
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10, flexibleKnots = FALSE)
  expect_warning(
    r1 <- RunQuiet(stratData1, stratModel = model, nIter = 5, nChains = 2,
                   seed = 1, gradientProposals = "on",
                   modelDir = withr::local_tempdir()),
    "not available when"
  )

  expect_no_warning(
    r2 <- RunQuiet(r1, nIter = 5, gradientProposals = "on")
  )
  expect_no_warning(RunQuiet(r2, nIter = 5))
})

test_that("the effective gradient setting decides a continuation (#2168)", {
  Check <- .CheckGradientProposalContinuation
  noNUTS <- list(list(propose = list(Prior = NULL, SiteBlock = NULL)))
  expect_no_error(Check("on", noNUTS, sedSmooth = TRUE))
  expect_error(Check("on", noNUTS, sedSmooth = FALSE), "cannot change")
})

test_that("asking a sedSmooth continuation for NUTS says it can't (#2168)", {
  model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                      sedModel = "site, partition", sedSmooth = TRUE,
                      nKnots = 10, flexibleKnots = FALSE)
  old <- StratMCMC(model, nIter = 100, nChains = 2, nThreads = 1L)
  expect_warning(
    StratMCMC(model, stratMCMC = old, completedIter = 100, nIter = 100,
              nThreads = 1L, gradientProposals = "on"),
    "not available when"
  )
})

test_that("continuing an \"on\" run without it gives one message (#1549)", {
  skip_on_cran()
  r1 <- RunQuiet(stratData1, stratModel = stratModel1, nIter = 30,
                 nChains = 2, seed = 1, gradientProposals = "on",
                 modelDir = withr::local_tempdir())

  expect_no_warning(
    expect_error(
      RunQuiet(r1, nIter = 30),
      "Pass `gradientProposals = \"on\"` to continue it"
    )
  )
})

# ── #2168 item 4: derived adaptation settings are re-derived ─────────────────

test_that("derived adaptation settings are re-derived on continuing (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 200, nChains = 3, nThreads = 1L)
  expect_equal(old[[c("metro", "adaptProposalInterval")]], 10)

  new <- .BuildContinuationMCMC(
    stratModel1, old, newRun = FALSE, completedIter = 200,
    providedArgs = c("nIter", "adaptProposal"),
    mcmcArgs = ContinuationArgs(nIter = 1e5, adaptProposal = TRUE)
  )
  window <- new[["endAdapting"]] - new[["startAdapting"]]
  expect_gt(window, 1e4)
  expect_equal(new[[c("metro", "adaptProposalInterval")]],
               max(10, floor(0.05 * window)))
  expect_equal(new[[c("metro", "historyLength")]],
               min(400, max(100, floor(0.05 * window))))
  expect_gt(new[[c("temper", "adaptTemperaturesIntervall")]],
            old[[c("temper", "adaptTemperaturesIntervall")]])
})

test_that("user-set adaptation settings are still inherited (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 200, nChains = 3, nThreads = 1L,
                   adaptProposalInterval = 7, adaptProposalWindow = 150)

  new <- .BuildContinuationMCMC(
    stratModel1, old, newRun = FALSE, completedIter = 200,
    providedArgs = c("nIter", "adaptProposal"),
    mcmcArgs = ContinuationArgs(nIter = 1e5, adaptProposal = TRUE)
  )
  expect_equal(new[[c("metro", "adaptProposalInterval")]], 7)
  expect_equal(new[[c("metro", "historyLength")]], 150)

  # ... and survive a second continuation, whose inherited value arrives
  # as a concrete argument.
  newer <- .BuildContinuationMCMC(
    stratModel1, new, newRun = FALSE, completedIter = 300,
    providedArgs = c("nIter", "adaptProposal"),
    mcmcArgs = ContinuationArgs(nIter = 1e5, adaptProposal = TRUE)
  )
  expect_equal(newer[[c("metro", "adaptProposalInterval")]], 7)
})

test_that("a checkpoint with no record re-derives its settings (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 200, nChains = 3, nThreads = 1L,
                   adaptProposalInterval = 7)
  old[["explicitArgs"]] <- NULL

  new <- .BuildContinuationMCMC(
    stratModel1, old, newRun = FALSE, completedIter = 200,
    providedArgs = c("nIter", "adaptProposal"),
    mcmcArgs = ContinuationArgs(nIter = 1e5, adaptProposal = TRUE)
  )
  expect_gt(new[[c("metro", "adaptProposalInterval")]], 7)
})

test_that("a frozen continuation keeps the history window (#2168)", {
  old <- StratMCMC(stratModel1, nIter = 20000, nChains = 2, nThreads = 1L)
  expect_equal(old[[c("metro", "historyLength")]], 400)

  new <- .BuildContinuationMCMC(
    stratModel1, old, newRun = FALSE, completedIter = 800,
    providedArgs = "nIter", mcmcArgs = ContinuationArgs(nIter = 100)
  )
  expect_false(any(new[[c("metro", "adaptProposal")]]))
  expect_equal(new[[c("metro", "historyLength")]], 400)
  expect_false("adaptProposalWindow" %in% new[["explicitArgs"]])
})

test_that("a continuation keeps the scale its factors were tuned to", {
  old <- StratMCMC(stratModel1, nIter = 100, nChains = 2, nThreads = 1L)
  old[[c("metro", "dimFactor")]] <- 1.23
  new <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 100,
                   nIter = 100, nThreads = 1L)
  cont <- .UpdateMCMCforContinuedRun(old, new, newRun = FALSE)
  expect_equal(cont[[c("metro", "dimFactor")]], 1.23)
})

# ── #1550 / #1553: auto alphaShift and dimFactor over free parameters ────────

test_that("an all-Fixed-alpha model can be continued (#1550)", {
  skip_on_cran()
  model <- FixedAlphaModel(c(alpha_site_2 = 2, alpha_site_3 = 3))
  r1 <- RunQuiet(stratData1, stratModel = model, nIter = 5, nChains = 2,
                 seed = 1, modelDir = withr::local_tempdir())
  expect_no_error(
    RunQuiet(r1, nIter = 5)
  )
})

test_that("auto alphaShift and dimFactor count free parameters only (#1553)", {
  model <- FixedAlphaModel(c(alpha_site_3 = 2))
  mc <- StratMCMC(model, nIter = 10, nChains = 1, nThreads = 1L)
  # One free alpha, uniform on [-6, 12]: its 5-95% range is 0.9 * 18.
  expect_equal(mc[[c("metro", "alphaShift")]], 0.1 * 0.9 * 18,
               tolerance = 0.05)
  expect_equal(mc[[c("metro", "dimFactor")]], 2.38^2 / 3)

  allFixed <- StratMCMC(FixedAlphaModel(c(alpha_site_2 = 2, alpha_site_3 = 3)),
                        nIter = 10, nChains = 1, nThreads = 1L)
  expect_identical(allFixed[[c("metro", "alphaShift")]], 0)
  # Still refused where it would matter.
  expect_error(StratMCMC(model, nIter = 10, alphaShift = 0, nThreads = 1L),
               "alphaShift")
})

# ── #1552: an interrupted, never-adapted run continues uninverted ────────────

test_that("a continuation before startAdapting keeps a valid window (#1552)", {
  old <- StratMCMC(stratModel1, nIter = 1000, nChains = 2, startAdapting = 50,
                   nThreads = 1L)
  new <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 20,
                   nIter = 100, adaptProposal = FALSE, nThreads = 1L)
  expect_lte(new[["startAdapting"]], new[["endAdapting"]])
})

# ── #795 / #1554 / #1644 item 1: already fixed, pinned here ──────────────────

test_that("adaptProposal must be a strict logical (#795)", {
  expect_error(StratMCMC(stratModel1, nIter = 10, adaptProposal = NA),
               "`adaptProposal` must be `TRUE` or `FALSE`")
})

test_that("checkpoint iterations are never duplicated (#1554, #1644)", {
  expect_equal(.IntegerSequence(1, 2, 0.1), c(1, 2))
  expect_false(anyDuplicated(.IntegerSequence(1, 50, 0.001)) > 0)
})

# ── #2169: StratMCMC() argument gaps ─────────────────────────────────────────

test_that("tempering and adaptTemperatures must be strict logicals (#2169)", {
  expect_error(StratMCMC(stratModel1, nIter = 10, tempering = NA), "tempering")
  expect_error(StratMCMC(stratModel1, nIter = 10, tempering = "TRUE"),
               "tempering")
  expect_error(StratMCMC(stratModel1, nIter = 10, adaptTemperatures = 1),
               "adaptTemperatures")
  expect_error(StratMCMC(stratModel1, nIter = 10, adaptTemperatures = NA),
               "adaptTemperatures")
})

test_that("a named parametersInitial is matched by name (#2169)", {
  init <- c(gammaLog_site_3 = 0.1, gammaLog_site_2 = 0.2,
            alpha_site_3 = 1, alpha_site_2 = 2)
  mc <- StratMCMC(stratModel1, nIter = 10, nChains = 1, nThreads = 1L,
                  parametersInitial = init)
  expect_equal(mc[[c("metro", "parametersInitial")]], c(2, 1, 0.2, 0.1))

  names(init)[1] <- "gammaLog_site_9"
  expect_error(StratMCMC(stratModel1, nIter = 10, parametersInitial = init),
               "\"gammaLog_site_9\"; missing: \"gammaLog_site_3\"")
})

test_that("a character nIter is refused up front (#2169)", {
  expect_error(StratMCMC(stratModel1, nIter = "100"), "`nIter` must be")
  expect_error(StratMCMC(stratModel1, nIter = "Inf"), "`nIter` must be")
})

test_that("an nThin wider than the run warns when it is lowered (#2169)", {
  expect_warning(
    mc <- StratMCMC(stratModel1, nIter = 10, nThin = 20, nThreads = 1L),
    "`nThin` \\(20\\)"
  )
  expect_equal(mc[["nThin"]], 10)
  expect_no_warning(StratMCMC(stratModel1, nIter = 1, nThreads = 1L))
})

test_that("duplicate saveChains are refused (#2169, #1644)", {
  expect_error(StratMCMC(stratModel1, nIter = 10, nChains = 2,
                         saveChains = c(1, 1)),
               "saveChains")
})

test_that("a continuation template prints as one (#2169)", {
  old <- StratMCMC(stratModel1, nIter = 100, nChains = 2, nThreads = 1L)
  template <- StratMCMC(stratModel1, stratMCMC = old, completedIter = 40,
                        nIter = 60, nThreads = 1L)
  printed <- capture_output(print(template))
  expect_no_match(printed, "has been run|of 0 iterations")
  expect_match(printed, "after iteration 40")
  expect_match(printed, "of 60 iterations")
})

test_that("the threading alert gives advice that applies (#2169)", {
  skip_on_cran()
  template <- StratMCMC(stratModel1, nIter = 2, nChains = 2, nThreads = 1L)
  template[["nThreads"]] <- NULL
  template[[".nThreadsUserSet"]] <- NULL
  expect_message(
    RunStratModel(stratData1, stratModel = stratModel1, stratMCMC = template,
                  quiet = TRUE, visualise = FALSE, runParallel = FALSE,
                  modelDir = withr::local_tempdir()),
    "with 1 thread\\b.*nThreads = 2.*RunStratModel"
  )
})
