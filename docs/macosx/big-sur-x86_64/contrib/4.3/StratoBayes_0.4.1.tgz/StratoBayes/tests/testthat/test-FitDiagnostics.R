### Perturb one site's signal values, keeping the cached value vector in step.
CorruptSite <- function(sp, site, fn, signal = "value") {
  sigs <- sp[[c("data", "signalAttr", "sigs")]][[signal]]
  rows <- sigs[["signalIndSite"]][[site]]
  heights <- sp[[c("data", "signal")]][["height"]][rows]
  sp[[c("data", "signal")]][[signal]][rows] <-
    sp[[c("data", "signal")]][[signal]][rows] + fn(heights)
  sp[[c("data", "signalAttr", "signalValuesVec")]][[signal]] <-
    sp[[c("data", "signal")]][[signal]][sigs[["signalInd"]]]

  # Return:
  sp
}

# A common seed gives both sides of a comparison the same `drift` null draws.
Ppp <- function(sp, site, column, ...) {
  sites <- withr::with_seed(1, FitDiagnostics(sp, ...))[["sites"]]

  # Return:
  sites[[column]][match(site, sites[["site"]])]
}

test_that("FitDiagnostics() returns a well-formed object", {
  fd <- FitDiagnostics(stratPosterior1)
  expect_s3_class(fd, "FitDiagnostics")
  expect_equal(nrow(fd[["sites"]]), 3)
  expect_equal(fd[["sites"]][["site"]], c("site_1", "site_2", "site_3"))
  expect_equal(fd[["sites"]][["n"]], c(60L, 30L, 30L))
  expect_true(is.integer(fd[["sites"]][["n"]]))
  expect_equal(nrow(fd[["signals"]]), 1)
  expect_null(fd[["excluded"]])

  ppp <- fd[["sites"]][, c("pppDrift", "pppScatter", "pppOffset")]
  expect_false(anyNA(ppp))
  expect_true(all(ppp > 0 & ppp <= 1))
  expect_equal(fd[[c("general", "nSamples")]], 200L)
})

test_that("FitDiagnostics() advances the RNG and reproduces under a seed", {
  set.seed(1)
  before <- .Random.seed
  first <- FitDiagnostics(stratPosterior1)
  expect_false(identical(.Random.seed, before))
  second <- FitDiagnostics(stratPosterior1)
  expect_false(identical(first[["sites"]][["pppDrift"]],
                         second[["sites"]][["pppDrift"]]))
  # only the simulated `drift` null is random
  expect_identical(first[["sites"]][["pppScatter"]],
                   second[["sites"]][["pppScatter"]])

  set.seed(1)
  expect_identical(FitDiagnostics(stratPosterior1)[["sites"]], first[["sites"]])
})

test_that("a constant offset moves `offset` alone", {
  corrupt <- CorruptSite(stratPosterior1, "site_2",
                         function(h) rep(0.5, length(h)))
  expect_lt(Ppp(corrupt, "site_2", "pppOffset"),
            Ppp(stratPosterior1, "site_2", "pppOffset") / 1000)
  # Mean-centring is what keeps a pure offset out of `drift`.
  expect_equal(Ppp(corrupt, "site_2", "pppDrift"),
               Ppp(stratPosterior1, "site_2", "pppDrift"),
               tolerance = 0.05)
  # Uncorrupted sites are untouched.
  expect_equal(Ppp(corrupt, "site_3", "pppOffset"),
               Ppp(stratPosterior1, "site_3", "pppOffset"))
})

test_that("a smooth ramp moves `drift` and spares `offset`", {
  corrupt <- CorruptSite(
                         stratPosterior1, "site_2",
                         function(h) 0.6 * (h - mean(h)) / diff(range(h)))
  expect_lt(Ppp(corrupt, "site_2", "pppDrift"),
            Ppp(stratPosterior1, "site_2", "pppDrift") / 10)
  expect_equal(Ppp(corrupt, "site_2", "pppOffset"),
               Ppp(stratPosterior1, "site_2", "pppOffset"),
               tolerance = 0.05)
})

test_that("added white noise moves `scatter` and spares `drift`", {
  corrupt <- CorruptSite(stratPosterior1, "site_2", function(h) {
    withr::with_seed(7, rnorm(length(h), 0, 0.3))
  })
  expect_lt(Ppp(corrupt, "site_2", "pppScatter"),
            Ppp(stratPosterior1, "site_2", "pppScatter") / 1000)
  expect_equal(Ppp(corrupt, "site_2", "pppDrift"),
               Ppp(stratPosterior1, "site_2", "pppDrift"),
               tolerance = 0.1)
})

test_that("FitDiagnostics() handles every fixture shape", {
  # stratPosterior3 is the fixture that estimates sigma rather than fixing it
  expect_true(any(grepl("^sigma_", stratPosterior3[["savedParameters"]])))
  expect_true(isFALSE(stratPosterior3[[c("model", "sigmaFixed")]]))
  fd3 <- FitDiagnostics(stratPosterior3)
  expect_equal(nrow(fd3[["sites"]]), 2)
  expect_true(all(is.finite(fd3[["sites"]][["pppScatter"]])))
  # a fixed sigma is constant across draws; an estimated one is not
  expect_gt(stats::sd(.FitDiagnosticsDraws(
    stratPosterior3, "value", "all", 0.5,
    50L, "all",
    NULL
  )[[c("sigma", "value")]]),
  0)

  # two signals
  fd2 <- FitDiagnostics(stratPosterior2)
  expect_equal(nrow(fd2[["signals"]]), 2)
  expect_equal(nrow(fd2[["sites"]]), 6)
  expect_equal(unique(fd2[["sites"]][["signal"]]), c("a", "b"))

  # age-scale alignment
  expect_equal(nrow(FitDiagnostics(stratPosterior4b)[["sites"]]), 2)
})

test_that("`signal` selects signals", {
  expect_equal(unique(FitDiagnostics(
    stratPosterior2,
    signal = "b"
  )[["sites"]][["signal"]]), "b")
  expect_equal(unique(FitDiagnostics(
    stratPosterior2,
    signal = 2
  )[["sites"]][["signal"]]), "b")
})

test_that(".ValidateSignalSelection() validates", {
  sigNames <- c("a", "b")
  expect_equal(.ValidateSignalSelection("all", sigNames), sigNames)
  expect_equal(.ValidateSignalSelection(c(2, 1), sigNames), c("b", "a"))
  expect_equal(.ValidateSignalSelection("b", sigNames), "b")
  expect_error(.ValidateSignalSelection(character(0), sigNames),
               "must not be empty")
  expect_error(.ValidateSignalSelection(NA, sigNames), "must not be empty")
  expect_error(.ValidateSignalSelection(3, sigNames), "between 1 and 2")
  expect_error(.ValidateSignalSelection("z", sigNames), "Unknown signal")
})

test_that("FitDiagnostics() rejects bad input", {
  expect_error(FitDiagnostics(stratData1), "must be a `StratPosterior`")
  expect_error(FitDiagnostics(stratPosterior1, minSiteN = 1), "at least|>= 2")
  expect_error(FitDiagnostics(stratPosterior1, minSiteN = c(3, 4)), ">= 2")
  expect_error(FitDiagnostics(stratPosterior1, minSiteN = NA), ">= 2")
  expect_error(FitDiagnostics(stratPosterior1, burnIn = 0.995, runs = 1),
               "Fewer than two posterior draws")
})

test_that("small sites are excluded rather than returning NaN", {
  fd <- FitDiagnostics(stratPosterior1, minSiteN = 40L)
  expect_equal(nrow(fd[["excluded"]]), 2)
  expect_equal(fd[["excluded"]][["site"]], c("site_2", "site_3"))
  small <- fd[["sites"]][["site"]] %in% c("site_2", "site_3")
  expect_true(all(is.na(fd[["sites"]][["pppDrift"]][small])))
  expect_true(all(is.na(fd[["sites"]][["drift"]][small])))
  # lpd is a per-point quantity and stays available for excluded sites
  expect_false(anyNA(fd[["sites"]][["lpd"]]))
  expect_false(is.na(fd[["sites"]][["pppDrift"]][!small]))
})

test_that("the noise-floor reference is reported when available", {
  bare <- FitDiagnostics(stratPosterior1)[["signals"]]
  expect_true(is.na(bare[["sigmaReference"]]))
  expect_true(is.na(bare[["sigmaRatio"]]))

  withRef <- stratPosterior1
  withRef[[c("model", "sdSpline")]] <- list(value = c(0.1, 0.2, 0.1))
  ref <- FitDiagnostics(withRef)[["signals"]]
  expect_equal(ref[["sigmaReference"]], 0.4 / 3)
  expect_equal(ref[["sigmaRatio"]], ref[["sigma"]] / ref[["sigmaReference"]])
})

test_that("StratModel() stores the per-site independent-spline SDs", {
  skip_on_cran()
  model <- StratModel(stratData1, stratPrior1, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "bottom",
                      nKnots = 15)
  expect_named(model[["sdSpline"]], "value")
  expect_length(model[[c("sdSpline", "value")]], stratData1[["S"]])
  expect_true(all(model[[c("sdSpline", "value")]] > 0))
})

test_that(".FitResidualStatistics() measures what it claims", {
  # alternating residuals are maximally anti-correlated
  expect_lt(.FitResidualStatistics(rep(c(1, -1), 10), 1)[["drift"]], -0.9)
  # two coherent blocks are positively autocorrelated
  expect_gt(.FitResidualStatistics(c(rep(1, 10), rep(-1, 10)), 1)[["drift"]],
            0.8)
  # a constant offset leaves `drift` undefined, not spuriously high
  expect_true(is.na(.FitResidualStatistics(rep(2, 10), 1)[["drift"]]))
  # too few points for a lag-1 statistic
  expect_true(is.na(.FitResidualStatistics(c(1, -1), 1)[["drift"]]))

  r <- c(-2, 0, 2, 1, -1)
  expect_equal(.FitResidualStatistics(r, 2)[["scatter"]], stats::var(r) / 4)
  expect_equal(.FitResidualStatistics(r + 3, 2)[["offset"]], 3 / (2 / sqrt(5)))
  # scatter and offset are orthogonal: shifting r does not change scatter
  expect_equal(.FitResidualStatistics(r + 99, 2)[["scatter"]],
               .FitResidualStatistics(r, 2)[["scatter"]])
})

test_that(".FitTailProbabilities() uses the stated null distributions", {
  nullDraws <- .DriftNullDistribution(10L)
  got <- .FitTailProbabilities(
    c(drift = 0.2, scatter = 1.3, offset = 1.7), 10L,
    nullDraws
  )
  # Pin the exact references: a df off-by-one or a one/two-sided slip in
  # `offset` still leaves every value "middling", so bounds cannot catch either.
  expect_equal(got[["scatter"]],
               stats::pchisq(9 * 1.3, df = 9, lower.tail = FALSE))
  expect_equal(got[["offset"]], 2 * stats::pnorm(1.7, lower.tail = FALSE))
  expect_equal(got[["drift"]],
               (1 + sum(nullDraws >= 0.2)) / (1 + length(nullDraws)))
  # df really is n - 1, not n
  expect_false(isTRUE(all.equal(
    got[["scatter"]],
    stats::pchisq(9 * 1.3, df = 10,
                  lower.tail = FALSE)
  )))

  high <- .FitTailProbabilities(
    c(drift = 0.9, scatter = 10, offset = 6), 10L,
    nullDraws
  )
  expect_true(all(high < 0.01))
  middling <- .FitTailProbabilities(
    c(drift = -1 / 9, scatter = 1, offset = 0),
    10L, nullDraws
  )
  expect_true(all(middling > 0.2))
  # an undefined statistic propagates rather than scoring as extreme
  expect_true(is.na(.FitTailProbabilities(
    c(drift = NA_real_, scatter = 1, offset = 0), 10L,
    nullDraws
  )[["drift"]]))
  # never an unattainable zero
  expect_gt(.FitTailProbabilities(
    c(drift = 1, scatter = 1, offset = 0), 10L,
    nullDraws
  )[["drift"]], 0)
})

test_that(".DriftNullDistribution() is a sorted, correctly centred null", {
  draws <- .DriftNullDistribution(12L, nNull = 999L)
  expect_length(draws, 999L)
  expect_false(is.unsorted(draws))
  # Mean-centring biases the lag-1 statistic slightly negative -- not to the
  # circular case's -1/(n-1), so bound it rather than pinning a closed form.
  expect_lt(mean(draws), 0)
  expect_gt(mean(draws), -2 / 11)
  expect_true(all(abs(draws) <= 1))
  expect_identical(
    withr::with_seed(1, .DriftNullDistribution(12L, nNull = 99L)),
    withr::with_seed(1, .DriftNullDistribution(12L, nNull = 99L))
  )
  # the blocking path: nNull * n exceeds one block
  big <- .DriftNullDistribution(2000L, nNull = 1500L)
  expect_length(big, 1500L)
  # the bias vanishes as n grows
  expect_lt(abs(mean(big)), 0.01)
})

test_that(".FitExtKnots() follows the draw only when knots are flexible", {
  fixed <- list(flexibleKnots = FALSE,
                splineBase = list(ext_knots = c(1, 1, 1, 2, 3, 3, 3)))
  expect_equal(.FitExtKnots(fixed, c(-100, 100)), c(1, 1, 1, 2, 3, 3, 3))

  flexible <- list(flexibleKnots = TRUE,
                   splineBase = list(nKnots = 4L, splineOrder = 4L))
  knots <- .FitExtKnots(flexible, c(0, 3, 1.5))
  expect_equal(knots, c(0, 0, 0, 0, 1, 2, 3, 3, 3, 3))
  # the basis must span the draw's own ages
  expect_equal(range(knots), c(0, 3))
})

test_that(".FitFittedValues() explains an out-of-range basis", {
  expect_error(
    .FitFittedValues(c(0, 0, 0, 0, 1, 1, 1, 1), 5, rep(1, 4), "value"),
    "outside `knotRange`"
  )
})

test_that(".FitFixedSigma() resolves sigma positionally, as the engine does", {
  sp <- stratPosterior2
  sigNames <- sp[[c("data", "signalAttr", "signalNames")]]
  named <- stats::setNames(c(1, 2), sigNames)
  expect_equal(.FitFixedSigma(named, sigNames[[2]], sp), 2)
  expect_equal(.FitFixedSigma(c(1, 2), sigNames[[2]], sp), 2)
  expect_equal(.FitFixedSigma(3, sigNames[[1]], sp), 3)
  expect_error(.FitFixedSigma(c(0, 1), sigNames[[1]], sp), "positive number")
  expect_error(.FitFixedSigma(c(NA, 1), sigNames[[1]], sp), "positive number")

  # The engine strips the names (`as.numeric()` in .GibbsSample) and indexes by
  # position, so a permuted name vector must NOT be honoured here -- doing so
  # would report a different sigma than the one the model was fitted with.
  permuted <- stats::setNames(c(0.9, 0.1), rev(sigNames))
  expect_warning(got <- .FitFixedSigma(permuted, sigNames[[1]], sp),
                 "do not match the signal order")
  expect_equal(got, 0.9)
  expect_silent(.FitFixedSigma(named, sigNames[[1]], sp))
})

test_that(".FitAccumulateDensity() survives an underflowing draw", {
  acc <- list(logDensityMax = rep(-Inf, 3), logDensitySum = rep(0, 3))
  acc <- .FitAccumulateDensity(acc, c(0, 1, 1e160), 1)
  expect_true(all(is.finite(acc[["logDensityMax"]][1:2])))
  # a density that underflows to zero contributes nothing but breaks nothing
  expect_equal(acc[["logDensityMax"]][[3]], -Inf)
  acc <- .FitAccumulateDensity(acc, c(0, 1, 1e160), 1)
  expect_equal(acc[["logDensitySum"]][1:2], c(2, 2))
  expect_false(anyNA(acc[["logDensitySum"]]))
})

test_that(".FitRbind() and .FitMean() handle empty and skipped input", {
  expect_null(.FitRbind(list()))
  expect_equal(nrow(.FitRbind(list(data.frame(a = 1), data.frame(a = 2)))), 2)
  # averaged over contributing draws only; a zero count is NA, not a divide-by-0
  expect_equal(.FitMean(c(4, 6), c(2L, 0L)), c(2, NA))
  expect_equal(.FitMean(c(9, 9), c(3L, 9L)), c(3, 1))
})

test_that("a degenerate draw costs one statistic, not the whole site", {
  # `drift` is undefined when a site's residuals have zero spread. That must not
  # turn the site's average into NA for every draw, and must leave `scatter` and
  # `offset` -- which are still defined -- untouched.
  lay <- list(rows = list(1:5), n = 5L, y = rep(0, 5))
  acc <- .FitAccumulators(list(v = lay), 5L)[["v"]]
  acc <- .FitAccumulate(acc, lay, rep(0.2, 5), 1)     # zero spread: drift NA
  acc <- .FitAccumulate(acc, lay, c(-2, 0, 2, 1, -1), 1)
  expect_equal(acc[["statN"]][1, ], c(drift = 1L, scatter = 2L, offset = 2L))
  expect_false(is.na(.FitMean(acc[["statSum"]][, "drift"],
                              acc[["statN"]][, "drift"])))
  expect_equal(.FitMean(acc[["statSum"]][, "scatter"],
                        acc[["statN"]][, "scatter"]),
               mean(c(0, stats::var(c(-2, 0, 2, 1, -1)))))
})

test_that(".FitAlignmentCount() will not silently disable the pooling gate", {
  expect_identical(.FitAlignmentCount(stratPosterior1), 1L)
  # a stratCluster lacking nClust yields NULL; isTRUE(NULL > 1) is FALSE, which
  # would skip the warning rather than report an unknown count
  noCount <- structure(list(stratCluster = list()), class = "StratPosterior")
  expect_identical(.FitAlignmentCount(noCount), NA_integer_)
  expect_identical(
    .FitAlignmentCount(structure(list(), class = "StratPosterior")),
    NA_integer_
  )
})

test_that(".FitConvergence() degrades gracefully", {
  expect_equal(.FitConvergence(structure(list(), class = "StratPosterior")),
               list(rhatMax = NA_real_, multiESS = NA_real_,
                    nDivergent = NA_integer_))
  real <- .FitConvergence(stratPosterior1)
  expect_true(is.finite(real[["rhatMax"]]))
  expect_true(is.finite(real[["multiESS"]]))
  expect_true(is.na(real[["nDivergent"]]))
})

test_that(".FitConvergenceSummary() reads divergences when HMC ran", {
  expect_equal(.FitConvergenceSummary(NULL),
               list(rhatMax = NA_real_, multiESS = NA_real_,
                    nDivergent = NA_integer_))
  withDivergences <- list(
    alignmentAll = list(multiESS = 321),
    general = list(psrf = c(a = 1.02, b = 1.11),
                   divergences = list(nDivergent = 7))
  )
  got <- .FitConvergenceSummary(withDivergences)
  expect_equal(got[["rhatMax"]], 1.11)
  expect_equal(got[["multiESS"]], 321)
  expect_identical(got[["nDivergent"]], 7L)

  # an empty psrf must not become -Inf via max()
  expect_true(is.na(.FitConvergenceSummary(
    list(alignmentAll = list(multiESS = 1), general = list(psrf = numeric(0)))
  )[["rhatMax"]]))
  # a summary without a usable multiESS slot
  expect_true(is.na(
    .FitConvergenceSummary(list(general = list(psrf = c(a = 1))))[["multiESS"]]
  ))
})

test_that(".FitGateMessages() withholds a verdict for sampler problems", {
  clean <- list(rhatMax = 1.01, multiESS = 500, nDivergent = 0,
                nAlignments = 1, alignment = "all")
  expect_length(.FitGateMessages(clean), 0)

  expect_match(.FitGateMessages(utils::modifyList(clean, list(rhatMax = 1.4))),
               "not converged")
  expect_match(.FitGateMessages(utils::modifyList(clean, list(multiESS = 20))),
               "Multivariate ESS")
  expect_match(.FitGateMessages(utils::modifyList(clean, list(nDivergent = 3))),
               "divergent transition")
  expect_match(
    .FitGateMessages(utils::modifyList(clean, list(nAlignments = 4))),
    "pooled over 4 alignments"
  )
  # conditioning on one alignment clears the pooling warning
  expect_length(.FitGateMessages(
    utils::modifyList(clean, list(nAlignments = 4, alignment = 1))
  ), 0)
  # unknown diagnostics must not fabricate a warning
  expect_length(.FitGateMessages(list(
    rhatMax = NA_real_,
    multiESS = NA_real_,
    nDivergent = NA_integer_,
    nAlignments = NA_integer_,
    alignment = "all"
  )), 0)
})

test_that(".FitReadings() maps each flag pattern to its diagnosis", {
  Row <- function(drift, scatter, offset) {
    data.frame(signal = "value", site = "s", pppDrift = drift,
               pppScatter = scatter, pppOffset = offset)
  }
  ok <- 0.5
  bad <- 1e-6
  expect_length(.FitReadings(Row(ok, ok, ok), 0.01), 0)
  expect_match(.FitReadings(Row(bad, ok, ok), 0.01), "misalignment")
  expect_match(.FitReadings(Row(ok, bad, ok), 0.01), "noisier")
  expect_match(.FitReadings(Row(ok, ok, bad), 0.01), "offset")
  expect_match(.FitReadings(Row(bad, bad, bad), 0.01), "may not correlate")
  expect_match(.FitReadings(Row(ok, bad, bad), 0.01), "several residual")
  expect_match(.FitReadings(Row(bad, ok, bad), 0.01), "several residual")
  # NA statistics never trigger a reading
  expect_length(.FitReadings(Row(NA_real_, NA_real_, NA_real_), 0.01), 0)
  # the threshold is honoured
  expect_length(.FitReadings(Row(0.02, ok, ok), 0.01), 0)
  expect_length(.FitReadings(Row(0.02, ok, ok), 0.05), 1)
})

test_that(".FitFormatTable() leaves labels and counts alone", {
  formatted <- .FitFormatTable(
    data.frame(signal = "value", site = "s", n = 30L, drift = 0.123456), 3
  )
  expect_equal(formatted[["site"]], "s")
  expect_equal(formatted[["n"]], 30L)
  expect_true(is.character(formatted[["drift"]]))
  expect_match(formatted[["drift"]], "^0\\.12")
})

test_that("print.FitDiagnostics() reports the diagnosis", {
  fd <- FitDiagnostics(stratPosterior1)
  expect_output(print(fd), "Posterior predictive fit diagnostics")
  expect_output(print(fd), "Draws used: 200")
  expect_output(print(fd), "pppDrift")
  expect_output(print(fd), "Small ppp values are suspicious")
  expect_invisible(print(fd))

  # the noise-floor line appears only with a reference
  expect_output(print(fd), "mean log predictive density")
  withRef <- stratPosterior1
  withRef[[c("model", "sdSpline")]] <- list(value = c(0.1, 0.2, 0.1))
  expect_output(print(FitDiagnostics(withRef)), "noise floor")

  # a clean bill of health, forced by an unreachable threshold
  expect_output(print(fd, threshold = 0), "No site's residuals depart")
  # and a flagged site at a permissive one
  expect_output(print(fd, threshold = 0.5), "Sites worth re-examining")

  expect_output(print(FitDiagnostics(stratPosterior1, minSiteN = 40L)),
                "Too few points for diagnostics")
  expect_output(print(FitDiagnostics(stratPosterior5a)),
                "pooled over 3 alignments")
})

test_that(".FitSignalLayout() falls back when the cached values are absent", {
  data <- stratPosterior1[["data"]]
  withCache <- .FitSignalLayout(data, "value")
  # legacy StratData objects predate signalValuesVec
  data[[c("signalAttr", "signalValuesVec")]] <- NULL
  expect_equal(.FitSignalLayout(data, "value"), withCache)
})

test_that("the reconstruction reproduces the engine's own signal likelihood", {
  # The decisive oracle. The engine stores `likelihood_spline` as the
  # beta-marginal log-likelihood p(y | a, sigma, lambda), so rebuilding it from
  # the reconstructed basis must reproduce the stored value for the same draw.
  # One number checks ages, extended knots, the basis, sigma, lambda and point
  # ordering jointly -- nothing else in this file would notice if
  # `.FitExtKnots()` or `signalInd` ordering drifted. beta is integrated out,
  # so it is not covered here; it is drawn exactly from its conditional.
  Oracle <- function(sp, nDraw = 5L) {
    sigNames <- sp[[c("data", "signalAttr", "signalNames")]]
    model <- sp[["model"]]
    draws <- .FitDiagnosticsDraws(sp, sigNames, "all", 0.5, nDraw, "all", NULL)
    saved <- ExtractParameters(sp, parameters = c("likelihood_spline",
                                                  paste0("lambda_", sigNames)),
                               alignment = "all", burnIn = 0.5,
                               maxSamples = nDraw, runs = "all")
    layout <-
      lapply(sigNames, function(sig) .FitSignalLayout(sp[["data"]], sig))
    names(layout) <- sigNames
    lp <- .PrepareLogPostArgs(model)

    rebuilt <- vapply(seq_len(nrow(draws[["metro"]])), function(d) {
      x <- as.numeric(draws[["metro"]][d, ])
      ageFlat <-
        unlist(.sb_age_convert(sp[["data"]], model[["ind"]], x)[["signal"]],
               recursive = FALSE, use.names = FALSE)
      extKnots <- .FitExtKnots(model, ageFlat)
      D <- model[[c("splineBase", "D")]]
      flexTerm <- 0
      if (isTRUE(model[["flexibleKnots"]])) {
        scale <- model[[c("splineBase", "ageSpan")]] / diff(range(ageFlat))
        D <- D * scale^3
        flexTerm <- 1.5 * (ncol(D) - 2) * log(scale)
      }
      .sb_logpost(
        x = x, priorTypes = lp[["priorTypes"]], priorArgs = lp[["priorArgs"]],
        rCustomFns = lp[["rCustomFns"]],
        B_list = lapply(layout, function(lay) {
          splineDesign(extKnots, ageFlat[lay[["pointInd"]]], sparse = FALSE)
        }),
        beta_list = lapply(sigNames, function(sig) {
          as.numeric(draws[[c("beta", sig)]][d, ])
        }),
        signalValues = lapply(layout, `[[`, "y"),
        sigma = vapply(sigNames, function(sig) draws[[c("sigma", sig)]][[d]],
                       numeric(1)),
        overlapPenalty = FALSE, signalSectionOverlap = list(),
        adjustments = list(), marginal = TRUE,
        lambda = as.numeric(saved[d, -1]), Dmat = D, flexTerm = flexTerm
      )[[2]]
    }, numeric(1))

    # Return:
    max(abs(rebuilt - as.numeric(saved[, 1])))
  }

  # fixed sigma + flexible knots; two signals; estimated sigma; age scale
  expect_lt(Oracle(stratPosterior1), 1e-8)
  expect_lt(Oracle(stratPosterior2), 1e-8)
  expect_lt(Oracle(stratPosterior3), 1e-8)
  expect_lt(Oracle(stratPosterior4b), 1e-8)
})

test_that("the fixed-knot branch uses a real model's stored basis", {
  skip_on_cran()
  # Every shipped fixture is flexibleKnots = TRUE, so this branch would
  # otherwise be exercised only against a hand-built list().
  model <- StratModel(stratData1, stratPrior1, alignmentScale = "height",
                      sedModel = "site", alphaPosition = "bottom",
                      nKnots = 15, flexibleKnots = FALSE,
                      knotRange = c(-1, 12))
  expect_false(model[["flexibleKnots"]])
  expect_equal(.FitExtKnots(model, c(0, 5, 11)),
               model[[c("splineBase", "ext_knots")]])
  # and it ignores the draw's ages entirely, unlike the flexible branch
  expect_equal(.FitExtKnots(model, c(-999, 999)),
               model[[c("splineBase", "ext_knots")]])
})

test_that("site rows are in stratigraphic order", {
  # `drift` is meaningless unless each site's residuals are height-ordered;
  # `StratData()` guarantees it by sorting, so assert the guarantee directly.
  for (sig in stratPosterior2[[c("data", "signalAttr", "signalNames")]]) {
    layout <- .FitSignalLayout(stratPosterior2[["data"]], sig)
    heights <- stratPosterior2[[c("data",
                                  "signal")]][["height"]][layout[["pointInd"]]]
    for (rows in layout[["rows"]]) {
      expect_false(is.unsorted(heights[rows]))
    }
  }
})

test_that("conditioning on one alignment changes the draws used", {
  pooled <- FitDiagnostics(stratPosterior5a)
  single <- FitDiagnostics(stratPosterior5a, alignment = 1)
  expect_false(any(grepl("pooled over", .FitGateMessages(single[["general"]]))))
  expect_true(any(grepl("pooled over", .FitGateMessages(pooled[["general"]]))))
  expect_false(identical(pooled[["sites"]][["drift"]],
                         single[["sites"]][["drift"]]))
})
