# T-069 / #1763: Ring buffer resize on an overflowing batch
#
# The ring buffer's default capacity is 1000 records (src/MCMCEngine.cpp,
# sb_create_engine). sb_run_block() resizes it up front whenever a requested
# batch (nIter * nChains) exceeds the current capacity, so a fixed-size
# overflow is not reachable through the exported engine API -- the property
# worth pinning is that the resize preserves every record, correctly
# attributed to its chain, rather than silently dropping or mislabelling any.
#
# This calls .sb_create_engine/.sb_run_block/.sb_get_ring_buffer directly:
# RunStratModel's own checkpoint schedule only ever asks for a handful of
# iterations per batch (R/AdaptationWindow.R), nowhere near the 1000-record
# default, so exercising the resize through it would need an implausibly
# long single-checkpoint run.

.RingBufferTestEngine <- function(nChains) {
  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- withr::local_tempdir("ringbuf1763", .local_envir = parent.frame())
  set.seed(1763)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = stratModel1, nIter = 5,
    nChains = nChains, seed = 1, quiet = TRUE, visualise = FALSE,
    nThreads = 1L, modelDir = td, modelName = "e", engine = "R"
  )
  model <- result[["model"]]
  if (is.null(model[[".logpost_cpp"]]))
    model[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "e_mcmc_run_1.rds"))
  StratoBayes:::.sb_create_engine(
                                  data = result[["data"]], model = model,
                                  mcmc = mcmc,
                                  state = mcmc[["recentState"]])
}

test_that(paste0("the ring buffer resizes to hold a batch exceeding its ",
                 "1000-record default, losing nothing (#1763)"), {
            skip_on_cran()
            nChains <- 4L
            # 300 * 4 = 1200 records, above the 1000-record default cap
            nIter <- 300L
            eng <- .RingBufferTestEngine(nChains)
            set.seed(1763)
            StratoBayes:::.sb_run_block(eng, nIter)
            ring <- StratoBayes:::.sb_get_ring_buffer(eng)

            # Every record from the oversized batch must come back, not just the
            # last 1000 -- the old fixed-size buffer would have silently dropped
            # the rest.
            expect_equal(length(ring[["chain"]]), nIter * nChains)
            expect_true(all(ring[["chain"]] %in% seq_len(nChains)))
            for (ch in seq_len(nChains)) {
              expect_equal(sum(ring[["chain"]] == ch), nIter,
                           info = paste("chain", ch))
            }
            expect_true(all(is.finite(ring[["logPost"]])))

            # A second, larger batch (2500 records) must trigger a further
            # resize on top of the first, not merely fit inside whatever the
            # first resize left.
            nIter2 <- 250L
            nChains2 <- 10L
            eng2 <- .RingBufferTestEngine(nChains2)
            set.seed(1763)
            StratoBayes:::.sb_run_block(eng2, nIter2)
            ring2 <- StratoBayes:::.sb_get_ring_buffer(eng2)
            expect_equal(length(ring2[["chain"]]), nIter2 * nChains2)
            expect_true(all(is.finite(ring2[["logPost"]])))
          })
