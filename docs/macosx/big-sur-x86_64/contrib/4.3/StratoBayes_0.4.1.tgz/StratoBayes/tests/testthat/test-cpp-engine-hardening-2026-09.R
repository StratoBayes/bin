# C++ engine hardening: spline order lower bound (#1462) and the gradient's
# custom-prior dispatch (#1122).

# The #1122 case needs a built-in prior whose gradient can be NaN, ahead of two
# custom priors in parameter order. `.PrepareLogPostArgs()` classifies a prior
# as custom by failing to match its density against a built-in, so the density
# must not be `stats::dnorm` itself.
.CustomNormal <- function(mean, sd) {
  Prior(R = function(n, m, s) stats::rnorm(n, m, s),
        D = function(x, m, s, log = FALSE) stats::dnorm(x, m, s, log = log),
        Q = function(p, m, s) stats::qnorm(p, m, s),
        m = mean, s = sd)
}

.HardeningSetup <- function() {
  data(stratData1, package = "StratoBayes", envir = environment())
  priors <- structure(
    list(alpha_site_2 = LogNormalPrior(meanlog = 0, sdlog = 1),
         alpha_site_3 = UniformPrior(min = -6, max = 12),
         gammaLog_site_2 = .CustomNormal(0, 1),
         gammaLog_site_3 = .CustomNormal(0.5, 2)),
    class = c("StratPrior", "list")
  )
  model <- StratModel(stratData = stratData1, priors = priors,
                      alignmentScale = "height", sedModel = "site",
                      flexibleKnots = FALSE, knotRange = c(-10, 20),
                      sigmaFixed = TRUE)
  td <- tempfile("hardening")
  dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  set.seed(1122)
  RunStratModel(stratData1, model, nIter = 10, nChains = 1, seed = 1,
                quiet = TRUE, visualise = FALSE, modelDir = td,
                modelName = "h", engine = "R", nCores = 1L, nThreads = 1L)
  mcmc <- readRDS(file.path(td, "h_mcmc_run_1.rds"))
  if (is.null(model$.logpost_cpp)) {
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  }
  list(data = stratData1, model = model, mcmc = mcmc)
}

.hardeningCache <- new.env(parent = emptyenv())
.Hardening <- function() {
  if (is.null(.hardeningCache$setup)) {
    .hardeningCache$setup <- .HardeningSetup()
  }
  .hardeningCache$setup
}

.HardeningEngine <- function(s, model = s$model) {
  StratoBayes:::.sb_create_engine(s$data, model, s$mcmc, s$mcmc$recentState)
}

test_that("#1122: the fixture has one log-normal and two custom priors", {
  s <- .Hardening()
  types <- s$model$.logpost_cpp$priorTypes
  expect_identical(nzchar(types), c(TRUE, TRUE, FALSE, FALSE))
  expect_s3_class(s$model$priors$metro$alpha_site_2, "LogNormalPrior")
})

test_that("#1122: a NaN built-in gradient does not shift the custom priors", {
  s <- .Hardening()
  eng <- .HardeningEngine(s)
  params <- s$mcmc$recentState[[1]]$metro$parameters

  # The log-normal gradient is NaN below 1/DBL_MAX and +Inf just above it;
  # the ages at both abscissas are the same doubles, so every other gradient
  # component must be too. A NaN taken for the custom sentinel would give each
  # custom slot the next custom prior's finite difference.
  params[1] <- 5.5e-309
  atNaN <- StratoBayes:::.sb_gradient_at(eng, 1L, params)
  params[1] <- 1e-307
  atInf <- StratoBayes:::.sb_gradient_at(eng, 1L, params)

  expect_true(atNaN$ok)
  expect_true(atInf$ok)
  expect_identical(atInf$grad[1], Inf)
  expect_true(is.finite(atNaN$grad[1]))
  expect_identical(atNaN$grad[2:4], atInf$grad[2:4])
})

test_that("#1462: sb_create_engine rejects splineOrder < 1", {
  s <- .Hardening()
  for (ord in c(0L, -1L, NA_integer_)) {
    badModel <- s$model
    badModel$splineBase$splineOrder <- ord
    expect_error(.HardeningEngine(s, badModel), "must be at least 1")
  }
})
