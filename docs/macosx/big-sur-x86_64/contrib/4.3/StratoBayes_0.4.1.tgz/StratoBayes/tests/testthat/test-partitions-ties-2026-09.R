test_that("Partitions() warns when a site falls back to height space (#1614)", {
  signal <- data.frame(site = rep(c("a", "b"), each = 6),
                       height = rep(0:5, 2))
  ties <- data.frame(site = c("a", "a"), height = c(0, 5),
                     densityFun = "dnorm", arg1 = c(10, 20), arg2 = 1)
  expect_warning(
    Partitions(signal, nStrata = 2, distribute = "height", ties = ties),
    "Site 'b'"
  )
})

test_that("Partitions() warns of ties for sites absent from signal (#1614)", {
  signal <- data.frame(site = "a", height = 0:5)
  ties <- data.frame(site = c("a", "a", "typo", "typo"),
                     height = c(0, 5, 0, 5), densityFun = "dnorm",
                     arg1 = c(10, 20, 10, 20), arg2 = 1)
  expect_warning(
    Partitions(signal, nStrata = 2, distribute = "height", ties = ties),
    "absent from `signal`.*typo"
  )
})

test_that(".CollectArgs() truncates surplus args to the density's arity (#1519)", {
  stratData <- list(tiesAttr = list(
    densityFun = matrix("dt", 1, 1), arg1 = matrix(5, 1, 1),
    arg2 = matrix(3, 1, 1)
  ))
  expect_equal(.CollectArgs(stratData, 1, 1), 5)
})
