# A saved parameter named exactly is selected by itself, not by prefix:
# `beta_value_1` is a prefix of `beta_value_10` to `beta_value_19`, so the
# prefix match returned all of them, duplicating names downstream.

test_that("an exact saved parameter name is not expanded by prefix", {
  saved <- c("alpha_site_2", paste0("beta_value_", 1:12), "posterior")
  post <- structure(
    list(
      model = list(parametersNames = "alpha_site_2",
                   splineBase = list(num_basis = 12L)),
      data = list(signalAttr = list(signalNames = "value")),
      samples = array(0, dim = c(1, 1, length(saved)),
                      dimnames = list(NULL, NULL, parameters = saved))
    ),
    class = "StratPosterior"
  )
  expect_identical(.ValidateModelParams(post, "beta_value_1"), "beta_value_1")
  expect_identical(.ValidateModelParams(post, "beta_value_12"), "beta_value_12")
  expect_identical(
    .ValidateModelParams(post, c("beta_value_1", "beta_value_10")),
    c("beta_value_1", "beta_value_10")
  )
})
