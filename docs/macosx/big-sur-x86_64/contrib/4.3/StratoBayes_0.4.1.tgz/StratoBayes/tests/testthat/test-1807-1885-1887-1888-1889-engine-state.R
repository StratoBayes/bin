# C++ engine state that must be right from engine creation onward, and the
# tempering swap ratio at a non-finite swap energy.

# Data/model/state from a short R-engine run, and a C++ engine built from them
# the way RunStratModel does. `Corrupt`, if given, edits the prepared data for
# a second engine, `corrupt`, at the same state.
EngineFixture <- function(sData, sModel, Corrupt = NULL) {
  td <- withr::local_tempdir("enginestate")
  set.seed(1807)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel, nIter = 10, nChains = 2L,
    seed = 1, quiet = TRUE, visualise = FALSE, nThreads = 1L,
    modelDir = td, modelName = "es", engine = "R"
  )
  dataObj <- result[["data"]]
  modelObj <- result[["model"]]
  mcmcObj <- readRDS(file.path(td, "es_mcmc_run_1.rds"))
  stateObj <- mcmcObj[["recentState"]]

  if (is.null(modelObj[[".logpost_cpp"]]))
    modelObj[[".logpost_cpp"]] <- StratoBayes:::.PrepareLogPostArgs(modelObj)
  if (is.null(modelObj[[".tiesDispatch"]]))
    modelObj[[".tiesDispatch"]] <-
      StratoBayes:::.BuildTiesDispatch(dataObj, modelObj)
  Build <- function(engineData) {
    tiesCallback <- if ("ties" %in% names(engineData)) {
      function(parameters) {
        ageResult <- StratoBayes:::.sb_age_convert(engineData,
                                                   modelObj[["ind"]],
                                                   parameters, FALSE)
        StratoBayes:::.LogLikTies(engineData, modelObj,
                                  list(age = list(ties = ageResult[["ties"]])))
      }
    }
    StratoBayes:::.sb_create_engine(
                                    data = engineData, model = modelObj,
                                    mcmc = mcmcObj, state = stateObj,
                                    tiesCallback = tiesCallback)
  }
  out <- list(data = dataObj, model = modelObj, state = stateObj,
              engine = Build(dataObj))
  if (!is.null(Corrupt)) {
    out[["corruptData"]] <- Corrupt(dataObj)
    out[["corrupt"]] <- Build(out[["corruptData"]])
  }
  out
}

TiesFixture <- function(ties, ...) {
  set.seed(1)
  h1 <- seq(0, 10, length.out = 60)
  h2 <- seq(0, 6, length.out = 40)
  d <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(60, 0, 0.1)),
    data.frame(site = "s2", height = h2,
               value = sin(h2 + 1) + rnorm(40, 0, 0.1))
  )
  sData <- StratData(signal = d, ties = ties, siteColumn = "site",
                     zColumn = "height", signalColumn = "value")
  prepared <- StratoBayes:::.EnsurePreExtracted(sData)
  pNames <- StratoBayes:::.CreateIndices(prepared, "age", "site",
                                         "middle")[["names"]]
  priors <- lapply(pNames, function(nm) {
    if (startsWith(nm, "alpha")) UniformPrior(min = -10, max = 20)
    else NormalPrior(mean = 0, sd = 0.5)
  })
  names(priors) <- pNames
  class(priors) <- c("StratPrior", "list")
  modelArgs <- utils::modifyList(
                                 list(flexibleKnots = FALSE,
                                      knotRange = c(-15, 25)), list(...))
  sModel <- do.call(
    StratModel,
    c(
      list(sData, priors, alignmentScale = "age",
           sedModel = "site",
           alphaPosition = "middle", nKnots = 6,
           sigmaFixed = 1),
      modelArgs
    )
  )
  EngineFixture(sData, sModel)
}

PartitionFixture <- function(Prepare = identity, Corrupt = NULL) {
  d <- Prepare(StratoBayes:::.EnsurePreExtracted(stratData2))
  indices <- StratoBayes:::.CreateIndices(d, "age", "site x partition",
                                          "middle")
  priors <- lapply(indices[["names"]], function(nm) {
    if (startsWith(nm, "alpha")) UniformPrior(min = -50, max = 50)
    else if (startsWith(nm, "gap")) ExponentialPrior(rate = 0.1)
    else NormalPrior(mean = 0, sd = 1)
  })
  names(priors) <- indices[["names"]]
  class(priors) <- c("StratPrior", "list")
  model <- StratModel(d, priors, alignmentScale = "age",
                      sedModel = "site x partition", flexibleKnots = FALSE)
  EngineFixture(d, model, Corrupt)
}

test_that(paste0("the engine holds the imported state's tie ages from ",
                 "creation (#1807)"), {
            # dunif(2, 4) is -Inf at an age of 0, which is what an unpopulated
            # tie age reads as.
            ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                               densityFun = c("dnorm", "dunif"),
                               arg1 = c(4, 2), arg2 = c(2, 4))
            fx <- TiesFixture(ties)
            extracted <- StratoBayes:::.sb_extract_state(fx[["engine"]])
            for (ch in seq_along(fx[["state"]])) {
              params <- fx[["state"]][[ch]][["metro"]][["parameters"]]
              expected <- StratoBayes:::.sb_age_convert(fx[["data"]],
                                                        fx[["model"]][["ind"]],
                                                        params, FALSE)[["ties"]]
              got <- extracted[[ch]][["age"]][["ties"]]
              expect_equal(lapply(unname(got), unname),
                           lapply(unname(expected), unname),
                           tolerance = 1e-12, info = sprintf("chain %d", ch))
            }
          })

test_that("a one-sided -Inf swap energy gives a determinate swap ratio (#1885)",
          {
            Ratio <- StratoBayes:::.sb_temper_swap_ratio
            # The -Inf state is on the cold rung: moving it to the hot rung is
            # certain.
            expect_identical(Ratio(-Inf, -1234.5, 1, 2.5), Inf)
            # The -Inf state is on the hot rung: moving it to the cold rung is
            # impossible.
            expect_identical(Ratio(-1234.5, -Inf, 1, 2.5), 0)
            expect_equal(Ratio(-10, -12, 1, 2), exp(-2 * (1 - 1 / 2)))

            # Ladder adaptation scores the link as the engine swaps it.
            energy <- rbind(c(-Inf, -1234.5), c(-1234.5, -Inf), c(-Inf, -Inf))
            expect_identical(StratoBayes:::.LinkSwapRatios(energy,
                                                           c(1, 2.5))[, 1],
                             c(1, 0, 0))
          })

test_that(paste0("a negative non-NA sedRatesDF code is a gap in the engine, ",
                 "as in .sb_age_convert (#1887)"), {
            sdf <- StratoBayes:::.EnsurePreExtracted(stratData2)[["partsAttr"]]
            cells <- which(sdf[["sedRatesDF"]] == 0L, arr.ind = TRUE)
            gapCell <- cells[cells[, "row"] <= sdf[["nBound"]][cells[, "col"]],
                             ,
                             drop = FALSE][1, ]
            expect_false(anyNA(gapCell))
            # StratData() gives a gap boundary zero width, which multiplies its
            # rate away; widen it so the rate is read.
            Widen <- function(dataObj) {
              dataObj[["partsAttr"]][["Bound"]][gapCell[1], gapCell[2]] <-
                dataObj[["partsAttr"]][["BoundLow"]][gapCell[1],
                                                     gapCell[2]] + 10
              dataObj
            }
            fx <- PartitionFixture(Widen, function(dataObj) {
              dataObj[["partsAttr"]][["sedRatesDF"]][gapCell[1],
                                                     gapCell[2]] <- -2L
              dataObj
            })
            ind <- fx[["model"]][["ind"]]

            for (ch in seq_along(fx[["state"]])) {
              params <- fx[["state"]][[ch]][["metro"]][["parameters"]]
              # The R-facing converter reads -2 as a gap: the same ages as 0.
              expect_equal(
                StratoBayes:::.sb_age_convert(fx[["corruptData"]],
                                              ind,
                                              params)[["signal"]],
                StratoBayes:::.sb_age_convert(fx[["data"]], ind,
                                              params)[["signal"]]
              )
              ref <- StratoBayes:::.sb_eval_logpost(fx[["engine"]], ch, params,
                                                    debug = TRUE)
              neg <- StratoBayes:::.sb_eval_logpost(fx[["corrupt"]], ch, params,
                                                    debug = TRUE)
              expect_true(isTRUE(ref[["ok"]]))
              expect_true(isTRUE(neg[["ok"]]), info = sprintf("chain %d", ch))
              expect_equal(neg[["signalFlat"]], ref[["signalFlat"]])
              expect_equal(neg[["logPostSep"]], ref[["logPostSep"]])
              expect_equal(
                StratoBayes:::.sb_gradient_at(fx[["corrupt"]], ch, params),
                StratoBayes:::.sb_gradient_at(fx[["engine"]], ch, params)
              )
            }
          })

test_that(paste0("a signal row no boundary covers is rejected, not scored ",
                 "stale (#1888)"), {
            fx <- PartitionFixture(Corrupt = function(dataObj) {
              bind <- dataObj[["signalAttr"]][["signalBind"]][[1]]
              last <- ncol(bind)
              # Uncover the site's last row; every other row keeps its boundary.
              bind[2, last] <- bind[2, last] - 1L
              dataObj[["signalAttr"]][["signalBind"]][[1]] <- bind
              dataObj
            })
            for (ch in seq_along(fx[["state"]])) {
              params <- fx[["state"]][[ch]][["metro"]][["parameters"]]
              intact <- StratoBayes:::.sb_eval_logpost(fx[["engine"]], ch,
                                                       params,
                                                       debug = TRUE)
              expect_true(isTRUE(intact[["ok"]]))
              out <- StratoBayes:::.sb_eval_logpost(fx[["corrupt"]], ch, params,
                                                    debug = TRUE)
              expect_false(isTRUE(out[["ok"]]), info = sprintf("chain %d", ch))
            }
          })

test_that("a zero-width age range is out of support on every branch (#1889)", {
  # Flexible knots spread over the converted-age range, so a zero-width range
  # has no basis. A near-zero sed rate collapses every age onto its site's
  # alpha, and equal alphas collapse the range; the widened ratesRange admits
  # the rate.
  fx <- TiesFixture(data.frame(height = c(3, 2), site = c("s1", "s2"),
                               mean = c(3, 4), sd = c(1, 2)),
                    flexibleKnots = TRUE, knotRange = NULL,
                    ratesRange = c(-14, 800))
  params <- fx[["state"]][[1]][["metro"]][["parameters"]]
  params[startsWith(names(params), "gammaLog")] <- 700
  params[startsWith(names(params), "alpha")] <- 5
  ages <- StratoBayes:::.sb_age_convert(fx[["data"]], fx[["model"]][["ind"]],
                                        params)[["signal"]]
  expect_identical(diff(range(unlist(ages))), 0)

  engine <- fx[["engine"]]
  marginal <- StratoBayes:::.sb_eval_logpost(engine, 1, params, debug = TRUE,
                                             marginal = TRUE)
  joint <- StratoBayes:::.sb_eval_logpost(engine, 1, params, debug = TRUE)
  hmc <- StratoBayes:::.sb_hmc_eval_logpost(engine, 1, params)
  for (out in list(marginal, joint, hmc)) {
    expect_false(out[["ok"]])
    expect_identical(out[["logPost"]], -Inf)
  }
})
