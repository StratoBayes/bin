# Which rows summary(), Cluster() and ExtractParameters() cluster and
# summarise: the clustering cap (#1774, #1952), `alignment = "none"` case
# folding (#1521), the R-hat row floor (#1692) and an automatic burn-in past
# a selected run's end (#1693).

# `stratPosterior1` tiled to `nRow` saved rows per run: 1000 rows per run
# survive `burnIn = 0.5`, so 3000 in all, above the 2500-row clustering cap.
Tiled1774 <- function(nRow = 2001L) {
  sp <- stratPosterior1
  samples <- .subset2(sp, "samples")
  tiled <- samples[rep_len(seq_len(dim(samples)[[1]]), nRow), , , ,
                   drop = FALSE]
  sp[["samples"]] <- tiled
  saveIter <- c(1, 25 * seq_len(nRow - 1L))
  nRun <- sp[["nRun"]]
  sp[["mcmcSummary"]][["saveIter"]] <- rep(list(saveIter), nRun)
  sp[["mcmcSummary"]][["completedIter"]] <- rep(max(saveIter), nRun)
  sp[["mcmcSummary"]][["completedIterIndex"]] <- rep(nRow, nRun)
  .WithClusterCache(sp, lazy = TRUE)
}

# Run `r` stops at iteration `stopped`, as a `timeLimit` run would.
Truncated1692 <- function(r = 3L, stopped = 2600) {
  sp <- stratPosterior1
  saveIter <- sp[[c("mcmcSummary", "saveIter")]][[r]]
  sp[["mcmcSummary"]][["saveIter"]][[r]] <- saveIter[saveIter <= stopped]
  sp[["mcmcSummary"]][["completedIter"]][[r]] <- stopped
  sp[["mcmcSummary"]][["completedIterIndex"]][[r]] <-
    sum(saveIter <= stopped)
  .WithClusterCache(sp, lazy = TRUE)
}

test_that("Cluster() and ExtractParameters() cluster the same rows (#1774)", {
  sp <- Tiled1774()
  ce <- .subset2(sp, ".cache")

  direct <- Cluster(sp, burnIn = 0.5, maxSamples = 5000)
  expect_equal(sum(lengths(direct[["rowIndex"]])), 2500)

  ExtractIterations(sp, alignment = 1, burnIn = 0.5, maxSamples = 5000)
  expect_length(ce$clusterCache, 1L)
  fromExtract <- ce$clusterCache[[1]][["value"]]
  expect_equal(.StripKeyAttr(fromExtract[["rowIndex"]]),
               .StripKeyAttr(direct[["rowIndex"]]))
  expect_equal(fromExtract[["cluster"]], direct[["cluster"]])
})

test_that("summary() clusters the rows ExtractParameters() does (#1952)", {
  sp <- Tiled1774()
  ce <- .subset2(sp, ".cache")

  sm <- suppressWarnings(summary(sp, burnIn = 0.5, maxSamples = 5000))
  expect_length(ce$clusterCache, 1L)
  clustered <- ce$clusterCache[[1]][["value"]][["rowIndex"]]
  expect_equal(sum(lengths(clustered)), 2500)

  # Every alignment block describes clustered rows, so their shares of the
  # summarised draws add up.
  expect_equal(sm[[c("general", "nSamplesUsed")]], 2500)
  blocks <- setdiff(names(sm), "general")
  expect_equal(sum(vapply(blocks, function(b) {
    sm[[c(b, "proportionAmongAllSamples")]]
  }, numeric(1))), 1)

  ExtractParameters(sp, alignment = 1, burnIn = 0.5, maxSamples = 5000)
  expect_length(ce$clusterCache, 1L)

  # Without clustering, every selected draw is summarised.
  none <- suppressWarnings(summary(sp, burnIn = 0.5, maxSamples = 5000,
                                   alignment = "none"))
  expect_equal(none[[c("general", "nSamplesUsed")]], 3000)
})

test_that("a low maxClusterSamples still subsamples, not truncates (#1774)", {
  sp <- Tiled1774()
  cl <- Cluster(sp, burnIn = 0.5, maxSamples = 5000, maxClusterSamples = 10)
  expect_equal(sum(lengths(cl[["rowIndex"]])), 2500)
})

test_that("the clustering cap keeps a short run in summary() (#1952)", {
  # Run 3 keeps one row past iteration 50000; its proportional share of the
  # 2500 clustered rows rounds to none.
  sp <- Tiled1774(4001L)
  saveIter <- sp[[c("mcmcSummary", "saveIter")]][[3]]
  keep <- saveIter <= 50025
  sp[["mcmcSummary"]][["saveIter"]][[3]] <- saveIter[keep]
  sp[["mcmcSummary"]][["completedIter"]][[3]] <- 50025
  sp[["mcmcSummary"]][["completedIterIndex"]][[3]] <- sum(keep)

  expect_no_warning(sm <- summary(sp, burnIn = 50000, maxSamples = Inf))
  expect_equal(sm[[c("general", "nSamplesUsedPerRun")]][[3]], 1)
})

test_that("summary() folds the case of alignment = 'none' (#1521)", {
  lower <- summary(stratPosterior1, alignment = "none")
  upper <- summary(stratPosterior1, alignment = "None")
  expect_identical(names(upper), names(lower))
  expect_identical(upper[[c("general", "overallAlignments")]], "none")
  expect_error(summary(stratPosterior1, alignment = NULL),
               "`alignment` cannot be NULL")
})

test_that("a run too short for R-hat is left out of it, and said so (#1692)", {
  # Run 3 keeps 4 draws past iteration 2500; R-hat needs 8.
  sp <- Truncated1692()
  sm <- suppressWarnings(summary(sp, burnIn = 2500, alignment = "none"))
  psrf <- sm[[c("general", "psrf")]]
  expect_equal(psrf, suppressWarnings(summary(
    sp, burnIn = 2500, alignment = "none", runs = 1:2
  ))[[c("general", "psrf")]], ignore_attr = TRUE)
  expect_identical(attr(psrf, "runsOmitted"), c("3" = 4L))
  expect_output(print(sm),
                "R-hat omits run 3 \\(4 retained draws\\): at least 8")

  # With every run too short there is nothing to fall back on.
  none <- suppressWarnings(summary(sp, burnIn = 2500, alignment = "none",
                                   runs = 3))
  expect_true(all(is.na(none[[c("general", "psrf")]])))
  expect_null(attr(none[[c("general", "psrf")]], "runsOmitted"))
})

test_that("an automatic burn-in past the selected runs names 'auto' (#1693)", {
  sp <- Truncated1692()
  certified <- list(iteration = 3000, status = "ok")
  local_mocked_bindings(.AutoBurnIn = function(object, ...) certified)
  msg <- "burnIn = \"auto\".*3000.*run 3.*2600"
  expect_error(ExtractParameters(sp, burnIn = "auto", runs = 3), msg)
  expect_error(summary(sp, burnIn = "auto", runs = 3), msg)
  expect_error(Cluster(sp, burnIn = "auto", runs = 3), msg)
  expect_no_error(ExtractParameters(sp, burnIn = "auto", runs = 1:2))
})

test_that("summary() reports the burn-in the supplied rows applied (#2254)", {
  for (sp in list(stratPosterior1, stratPosterior5b)) {
    cl <- Cluster(sp, burnIn = 0.5, nThreads = 2L)
    sm <- summary(sp, stratCluster = cl, burnIn = 0.2)
    expect_equal(sm[[c("general", "burnInPercent")]],
                 rep(50, sp[["nRun"]]), tolerance = 1)

    sm <- summary(sp, stratCluster = cl, burnIn = "auto")
    expect_null(sm[[c("general", "autoBurnIn")]])

    saveIter <- sp[[c("mcmcSummary", "saveIter")]]
    sm <- summary(sp, iterations = saveIter[[1]][1:201], alignment = "none",
                  runs = 1L)
    expect_equal(sm[[c("general", "burnInPercent")]], 0)

    sm <- summary(sp, iterations = saveIter[[1]][101:201], alignment = "none",
                  runs = 1L)
    expect_equal(sm[[c("general", "burnInPercent")]],
                 saveIter[[1]][100] / sp[[c("mcmcSummary", "completedIter")]][[1]] * 100)
  }
})

test_that("a clustering cap overshoot is not reported by summary() (#2279)", {
  sp <- Tiled1774(4001L)
  saveIter <- sp[[c("mcmcSummary", "saveIter")]][[3]]
  keep <- saveIter <= 50025
  sp[["mcmcSummary"]][["saveIter"]][[3]] <- saveIter[keep]
  sp[["mcmcSummary"]][["completedIter"]][[3]] <- 50025
  sp[["mcmcSummary"]][["completedIterIndex"]][[3]] <- sum(keep)
  sm <- summary(sp, burnIn = 50000, maxSamples = Inf)
  expect_lte(sm[[c("general", "nSamplesUsed")]], 2500)
})
