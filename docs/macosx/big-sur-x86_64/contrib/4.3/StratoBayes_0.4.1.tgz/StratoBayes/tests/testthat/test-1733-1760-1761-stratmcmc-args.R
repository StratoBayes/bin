# StratMCMC() argument handling: requests that silently did nothing, and
# arguments whose size drove an unbounded allocation.

data(stratData1, package = "StratoBayes", envir = environment())
data(stratModel1, package = "StratoBayes", envir = environment())

# ── #1760: adaptTemperatures = TRUE with a single chain ─────────────────────

test_that("#1760: explicit adaptTemperatures = TRUE warns with one chain", {
  expect_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 1, adaptTemperatures = TRUE),
    "adaptTemperatures = TRUE.*single chain"
  )
})

test_that("#1760: the default adaptTemperatures does not warn with one chain", {
  expect_no_warning(StratMCMC(stratModel1, nIter = 100, nChains = 1))
})

# ── #1761: size-driving arguments ───────────────────────────────────────────

test_that("#1761: writeMCMCfile schedules at most one checkpoint per iteration",
          {
            mcmc <- StratMCMC(stratModel1, nIter = 1000, nChains = 1,
                              writeMCMCfile = 1e-6)
            writeIter <- mcmc[["writeMCMCiterations"]]
            expect_lte(length(writeIter), 1000L)
            expect_false(anyDuplicated(writeIter) > 0L)
            expect_identical(max(writeIter), 1000)
          })

test_that("#1761: a sub-iteration step leaves the checkpoint set unchanged", {
  expect_equal(.IntegerSequence(1, 5, 0.1), 1:5)
  expect_equal(.IntegerSequence(1, 1000, 1e-6), 1:1000)
  expect_equal(.IntegerSequence(1, 1000, 0.2), c(200, 400, 600, 800, 1000))
})

test_that("#1761: an oversized acceptanceHistoryLength is refused", {
  expect_error(
    StratMCMC(stratModel1, nIter = 100, nChains = 8,
              acceptanceHistoryLength = 1e7),
    "acceptanceHistoryLength"
  )
  expect_no_error(StratMCMC(stratModel1, nIter = 10, nChains = 1))
  expect_no_error(StratMCMC(stratModel1, nIter = 10, nChains = 1,
                            acceptanceHistoryLength = 5000))
})

# ── #1733: gradientProposals = "on" with adaptProposal = FALSE ──────────────

test_that("#1733: NUTS is live from construction without adaptation", {
  expect_warning(
    mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 3,
                      temperatures = c(1, 2, Inf),
                      adaptProposal = FALSE, gradientProposals = "on"),
    "untuned"
  )
  temps <- mcmc[[c("temper", "temperatures")]]
  finite <- is.finite(temps)
  expect_true(any(!finite))

  valid <- mcmc[[c("metro", "proposalValid")]][, "NUTS"]
  prob <- mcmc[[c("metro", "proposalProbability")]][, "NUTS"]
  expect_true(all(valid[finite]))
  expect_true(all(prob[finite] > 0))
  expect_false(any(valid[!finite]))
  expect_true(all(prob[!finite] == 0))

  nutsArgs <- mcmc[[c("metro", "proposalArgs")]][[which(finite)[1]]][["NUTS"]]
  expect_type(nutsArgs, "list")
  # No adaptation window exists, so dual averaging must not run: tuning the
  # step size for the whole run would leave no retained sample on a fixed
  # kernel.
  expect_false(nutsArgs[["adaptStepSize"]])
  expect_true(is.finite(nutsArgs[["stepSize"]]) && nutsArgs[["stepSize"]] > 0)
})

test_that("#1733: NUTS makes gradient transitions without adaptation", {
  td <- withr::local_tempdir()
  post <- suppressWarnings(RunStratModel(
    stratData1, stratModel1, nIter = 60, nChains = 1, nThreads = 1L,
    adaptProposal = FALSE, gradientProposals = "on", seed = 1,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "g"
  ))
  expect_gt(post[[c("mcmcSummary", "nGradientTransitions")]][[1]], 0L)
})
