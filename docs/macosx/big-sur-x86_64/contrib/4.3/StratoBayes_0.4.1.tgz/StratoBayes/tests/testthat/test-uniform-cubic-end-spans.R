# spline_design_uniform_cubic() evaluates every row of the flexible-knot design
# from a per-span cubic, the six clamped end spans included. It must agree with
# the generic Cox-de Boor design to rounding everywhere, including exactly on
# knots and at both ends of the range.

test_that("closed-form uniform cubic design matches Cox-de Boor", {
  probe <- get(".sb_uniform_cubic_design_probe", envir = asNamespace("StratoBayes"))
  set.seed(1)
  for (nk in c(8L, 9L, 12L, 25L, 60L)) {
    lo <- -7315.25; hi <- lo + 1234.5
    knots <- seq(lo, hi, length.out = nk)
    x <- c(runif(4000, lo, hi), knots, lo, hi,
           knots[-1] - 1e-9 * (hi - lo), knots[-nk] + 1e-9 * (hi - lo))
    d <- probe(lo, hi, nk, x)
    expect_equal(dim(d$fast), c(length(x), nk + 2L))
    expect_lt(max(abs(d$fast - d$ref)), 1e-13)
    expect_equal(rowSums(d$fast), rep(1, length(x)), tolerance = 1e-13)
  }
})
