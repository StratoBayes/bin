test_that("StratMap works", {

  expect_error(StratMap(1, 2, 2), "stratObject must be")

  expect_equal(as.numeric(StratMap(stratPosterior1, 2, 2)),
               c(2, 10.3, 0.5, 9.7, 10.3, 11.6), tolerance = 0.1)

  expect_s3_class(StratMap(stratPosterior3, 2, 2), "data.frame")

})

test_that("StratMap works with prior", {
  set.seed(1)
  h1 <- StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1)
  expect_equal(h1$mean, mean(
    unlist(stratModel1$priors$metro$alpha_site_2$args)
  ), tolerance = 0.5)
})

test_that(
  "StratMap works with new cluster object and
          iterations before burnIn",
  {
    clustNew <- Cluster(stratPosterior5a, iterations = 3500:4000)
    expect_true(
      StratMap(stratPosterior5a,
               heights = 1,
               site = 2,
               stratCluster = clustNew,
               alignment = 1)[, "sd"]
      <
        StratMap(stratPosterior5a,
                 heights = 1,
                 site = 2,
                 stratCluster = clustNew,
                 alignment = "all")[, "sd"]

    )
  }
)

test_that(
  "StratMap preserves height-result alignment for unsorted input (T-081)",
  {
    # Sorted and unsorted input must produce the same mapping per height
    sorted   <-
      StratMap(stratPosterior1, heights = c(0.5, 1.0, 1.5), site = "site_2")
    unsorted <-
      StratMap(stratPosterior1, heights = c(1.5, 0.5, 1.0), site = "site_2")

    # Row 1 of unsorted (height 1.5) should match row 3 of sorted (height 1.5)
    expect_equal(unsorted[1, "mean"], sorted[3, "mean"])
    # Row 2 of unsorted (height 0.5) should match row 1 of sorted (height 0.5)
    expect_equal(unsorted[2, "mean"], sorted[1, "mean"])
    # Row 3 of unsorted (height 1.0) should match row 2 of sorted (height 1.0)
    expect_equal(unsorted[3, "mean"], sorted[2, "mean"])
  }
)

test_that("StratMap quantiles = 'samples' works with partial match (T-082)", {
  full <-
    StratMap(stratPosterior1, heights = 2, site = 2, quantiles = "samples")
  partial <- StratMap(stratPosterior1, heights = 2, site = 2, quantiles = "sam")
  expect_equal(full, partial)
  expect_true("height" %in% colnames(full))
  expect_true(ncol(full) > 2)
})

test_that(
  "StratMap(quantiles = NULL) errors clearly instead of crashing (RT-192)",
  {
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2, quantiles = NULL),
      "quantiles must not be NULL"
    )
  }
)

test_that(
  paste0("StratMap(quantiles = numeric(0)) errors clearly instead of crashing ",
         "(RT-193)"),
  {
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2, quantiles = numeric(0)),
      "quantiles must not be empty"
    )
  }
)

test_that(
  "StratMap with a single quantile returns one row per height (RT-041)",
  {
    h <- c(0.5, 1.0, 1.5)
    out1 <- StratMap(stratPosterior1, heights = h, site = 2, quantiles = 0.5)
    # Before the fix, a length-1 `quantiles` collapsed the output to a single
    # garbage row (t() of a vector), so nrow() was 1 instead of length(h).
    expect_equal(nrow(out1), length(h))
    expect_identical(colnames(out1), c("height", "mean", "sd", "50%"))
    expect_equal(out1[["height"]], h)
    # multi-quantile output must remain nHeights x (3 + nQuantiles)
    out3 <- StratMap(stratPosterior1, heights = h, site = 2,
                     quantiles = c(0.025, 0.5, 0.975))
    expect_equal(dim(out3), c(length(h), 6))
  }
)

test_that(
  paste0("StratMap() rejects a multi-element 'quantiles' vector that ",
         "pmatch-shortcircuits to 'samples' (RT-295)"),
  {
    # Regression for RT-295: pmatch()-based "samples" validation only checked
    # matchedValue[[1]], so a multi-element character vector like
    # c("sam", "garbage") silently passed (first element partial-matches
    # "samples") and quantiles was unconditionally overwritten to "samples",
    # ignoring the rest of the input.
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2,
               quantiles = c("sam", "garbage")),
      "quantiles must either be numeric or the character string 'samples'"
    )
    # a genuine single-element partial match must still work (T-082)
    expect_no_error(
      StratMap(stratPosterior1, heights = 2, site = 2, quantiles = "sam")
    )
  }
)

test_that(
  "StratMap(alignment = NA) errors clearly instead of crashing (RT-461)",
  {
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2, alignment = NA),
      "`alignment` must not contain missing values"
    )
  }
)

test_that(
  paste0("StratMap(quantiles containing NA) errors clearly instead of ",
         "silently returning an all-NA column (RT-458)"),
  {
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2, quantiles = NA_real_),
      "quantiles must not contain NA"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 2, site = 2, quantiles = c(0.5, NA)),
      "quantiles must not contain NA"
    )
  }
)

test_that(
  paste0("StratMap(heights = NULL/NA) errors clearly instead of crashing in ",
         "unrelated internals (RT-464)"),
  {
    expect_error(
      StratMap(stratPosterior1, heights = NULL, site = 2),
      "heights must be a numeric vector without NAs"
    )
    expect_error(
      StratMap(stratPosterior1, heights = c(1, NA, 2), site = 2),
      "heights must be a numeric vector without NAs"
    )
    expect_error(StratMap(stratPosterior1, heights = numeric(0), site = 2),
                 "heights must not be empty")
  }
)

test_that(
  paste0("StratMap() prior branch: maxSamples = 1 returns a shape-correct ",
         "single-sample matrix, not a transposed vector (RT-589, #698)"),
  {
    set.seed(1)
    out <- StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
                    maxSamples = 1, quantiles = "samples")
    expect_equal(nrow(out), 1)
    expect_equal(ncol(out), 2)  # height + 1 sample column
    expect_true(all(is.finite(as.matrix(out))))

    # a typical (> 1) maxSamples must still produce nSamples rows worth of
    # columns in the wide "samples" output
    set.seed(1)
    out5 <- StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
                     maxSamples = 5, quantiles = "samples")
    expect_equal(ncol(out5), 6)  # height + 5 sample columns
    expect_true(all(is.finite(as.matrix(out5))))
  }
)

test_that(
  paste0("StratMap() prior branch rejects invalid maxSamples instead of ",
         "silently corrupting/NA-ing output (RT-591, #698)"),
  {
    expect_error(
      StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
               maxSamples = 0),
      "maxSamples` must be a single finite whole number"
    )
    expect_error(
      StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
               maxSamples = -1),
      "maxSamples` must be a single finite whole number"
    )
    expect_error(
      StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
               maxSamples = NA),
      "maxSamples` must be a single finite whole number"
    )
    expect_error(
      StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1,
               maxSamples = 2.5),
      "maxSamples` must be a whole number"
    )
  }
)

test_that(
  paste0("StratMap() validates `site` instead of passing it straight to ",
         ".AgeConversionBatch() (RT-597, #700)"),
  {
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = "not_a_site"),
      "sites` may contain integers"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = NA),
      "sites` must not contain missing values"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = c(2, 3)),
      "site` must identify exactly one site"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 99),
      "sites` may contain integers"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 0),
      "sites` may contain integers"
    )
    # valid site name/index still work
    expect_no_error(StratMap(stratPosterior1, heights = 1, site = "site_2"))
    expect_no_error(StratMap(stratPosterior1, heights = 1, site = 2))
  }
)

test_that(
  paste0("StratMap() resolves a factor `site` by label, not by its underlying ",
         "code (RT-519, #561)"),
  {
    sn <- stratPosterior1$data$sites
    reference <- StratMap(stratPosterior1, heights = c(1, 2), site = "site_2")

    expect_equal(
      StratMap(stratPosterior1, heights = c(1, 2), site = factor("site_2")),
      reference
    )
    expect_equal(
      StratMap(stratPosterior1, heights = c(1, 2),
               site = factor("site_2", levels = sn)),
      reference
    )
  }
)

test_that(
  paste0("StratMap() applies the maxSamples cap on the stratCluster-supplied ",
         "selectRows path (RT-599, #701)"),
  {
    clustNew <- Cluster(stratPosterior3, iterations = 300:400)
    out <-
      StratMap(stratPosterior3, heights = 1, site = 2, stratCluster = clustNew,
               alignment = 1, maxSamples = 10, quantiles = "samples")
    expect_lte(ncol(out) - 1, 10)  # sample columns, excluding the height column
  }
)

test_that(
  paste0("StratMap() prior branch honours `parameters` instead of always ",
         "drawing fresh (RT-717, #909)"),
  {
    set.seed(1)
    a <-
      StratMap(stratModel1, heights = c(1, 2), site = 2, stratData = stratData1,
               parameters = rep(1, stratModel1[["parametersLength"]]))
    set.seed(1)
    b <-
      StratMap(stratModel1, heights = c(1, 2), site = 2, stratData = stratData1,
               parameters = rep(5, stratModel1[["parametersLength"]]))
    # before the fix, both calls drew fresh prior samples and ignored
    # `parameters` entirely, so identical seeds gave identical() output
    # regardless of the (very different) supplied parameter values
    expect_false(identical(a, b))

    # a supplied `parameters` also must not consume the RNG (no prior draw
    # happens at all), so the result is deterministic across seeds
    set.seed(2)
    bAgain <-
      StratMap(stratModel1, heights = c(1, 2), site = 2, stratData = stratData1,
               parameters = rep(5, stratModel1[["parametersLength"]]))
    expect_equal(b, bAgain)
  }
)

test_that(
  paste0("StratMap() prior branch rejects alignment/runs/iterations instead ",
         "of silently ignoring them (RT-717, #909)"),
  {
    expect_error(
      StratMap(stratModel1, heights = 1, site = 2, stratData = stratData1,
               runs = 99),
      "do not apply when `stratObject` is a `StratModel`"
    )
    expect_error(
      StratMap(stratModel1, heights = 1, site = 2, stratData = stratData1,
               alignment = 1),
      "do not apply when `stratObject` is a `StratModel`"
    )
    expect_error(
      StratMap(stratModel1, heights = 1, site = 2, stratData = stratData1,
               iterations = 1:10),
      "do not apply when `stratObject` is a `StratModel`"
    )
    # defaults (i.e. not explicitly supplying these args) still work
    expect_no_error(
      StratMap(stratModel1, heights = 1, site = 2, stratData = stratData1)
    )
  }
)

test_that(
  paste0("StratMap() posterior branch validates maxSamples as strictly as the ",
         "prior branch (RT-720, #912)"),
  {
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = -1),
      "maxSamples"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = NA),
      "maxSamples"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = "2"),
      "maxSamples"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = c(2, 3)),
      "maxSamples"
    )
    # non-integer maxSamples silently truncated on the posterior branch while
    # the prior branch (correctly) rejects it -- now rejected consistently
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = 2.5),
      "maxSamples` must be a whole number"
    )
    # Inf remains a legitimate "no cap" value on the posterior branch
    expect_no_error(
      StratMap(stratPosterior1, heights = 1, site = 2, maxSamples = Inf)
    )
  }
)

test_that(
  "StratMap() quantiles bounds are validated for numeric input (RT-601, #703)",
  {
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2, quantiles = 1.5),
      "quantiles must be numeric values between 0 and 1"
    )
    expect_error(
      StratMap(stratPosterior1, heights = 1, site = 2,
               quantiles = c(-0.1, 0.5)),
      "quantiles must be numeric values between 0 and 1"
    )
  }
)

test_that(
  paste0("StratMap() applies a consistent NA policy across mean/sd/quantile ",
         "summaries (#1538, #1612)"),
  {
    # Before the fix, quantile() had no na.rm while rowMeans()/sd() silently
    # tolerated NA: a converted-height row with some (but not all) NA samples
    # crashed quantile() with "missing values and NaN's not allowed" instead
    # of summarising the finite samples the way rowMeans()/sd() already did.
    fakeConverted <- matrix(c(9, 10, NA, 11, NA, 12), nrow = 1)
    testthat::local_mocked_bindings(
      .AgeConversionBatch = function(...) fakeConverted,
      .package = "StratoBayes"
    )
    out <- StratMap(stratPosterior1, heights = 2, site = 2, quantiles = c(0.5))
    expect_false(is.na(out[["mean"]]))
    expect_false(is.na(out[["sd"]]))
    expect_false(is.na(out[["50%"]]))
    expect_equal(out[["mean"]], mean(fakeConverted, na.rm = TRUE))
  }
)

test_that(
  paste0("StratMap() rejects a row-mismatched `parameters` on a sedSmooth ",
         "posterior instead of silently mispairing sedBeta (#1958)"),
  {
    skip_on_cran()
    data(stratData1, package = "StratoBayes", envir = environment())

    td <- file.path(tempdir(), paste0("sm1958_", sample.int(1e6, 1)))
    dir.create(td, showWarnings = FALSE, recursive = TRUE)
    on.exit(unlink(td, recursive = TRUE), add = TRUE)

    model <- StratModel(stratData1, priors = NULL, alignmentScale = "height",
                        sedModel = "site, partition", sedSmooth = TRUE,
                        nKnots = 10)
    mcmc <- StratMCMC(model, nIter = 5, nChains = 1, nThreads = 1)
    post <- RunStratModel(stratData1, model, mcmc, seed = 1, quiet = TRUE,
                          visualise = FALSE, modelDir = td,
                          modelName = "sm1958")

    # A single-row `parameters` is exactly what Tops()'s own guard already
    # catches (R/Tops.R:243-250) for the SAME `parameters`/`sedBeta` pairing --
    # StratMap() had no equivalent guard at all, so this ran to completion and
    # silently paired a fixed `parameters` row with the varying retained
    # `sedBeta` draws instead of refusing (a matching row count is a separate,
    # narrower gap neither StratMap() nor Tops() closes -- see the issue).
    expect_error(
      StratMap(post, heights = 0, site = 2,
               parameters = rep(1, post[[c("model", "parametersLength")]])),
      "posterior draw\\(s\\) of the spline coefficients .sedBeta."
    )
    # the posterior-draw path (no `parameters` override) is unaffected
    expect_no_error(StratMap(post, heights = 0, site = 2))

    # a `parameters` matrix correctly paired (one row per retained sedBeta
    # draw, mirroring the caller's own selectRows) still works -- mirrors the
    # legitimate usage in test-Tops-sedSmooth.R
    rows <- .maxSampleDeterministicRows(
      ExtractIterations(post, "all", 0.5,
                        NULL, 10,
                        .ValidateRunSelect("all", post[["nRun"]])), 10
    )
    metro <- as.matrix(ExtractParameters(post, "parameters", selectRows = rows))
    expect_no_error(
      StratMap(post, heights = 0, site = 2, maxSamples = 10, parameters = metro)
    )
  }
)

test_that(
  paste0("StratMap() warns rather than silently returning NaN/NA for a ",
         "zero-sample batch (#1632)"),
  {
    # A zero-column convertedHeights (e.g. an empty selectRows) previously
    # flowed through rowMeans()/quantile() as a plausible-looking all-NaN/NA
    # row with no warning; StratMap()'s guard only checked nrow() == 0.
    fakeConverted <- matrix(numeric(0), nrow = 1, ncol = 0)
    testthat::local_mocked_bindings(
      .AgeConversionBatch = function(...) fakeConverted,
      .package = "StratoBayes"
    )
    expect_warning(
      out <-
        StratMap(stratPosterior1, heights = 2, site = 2, quantiles = c(0.5)),
      "No mapping samples"
    )
    expect_true(is.na(out[["mean"]]))
    expect_true(is.na(out[["sd"]]))
    expect_true(is.na(out[["50%"]]))
  }
)
