# #2298: the scale prior-derived proposal SDs are a fraction of.
# #2299 items 2 and 3: a typed prior's density must be its class's density, and
# `StratModelTemplate()` must not emit a gap prior that cannot be built.

data(stratModel1, package = "StratoBayes", envir = environment())

.WithPrior <- function(prior, param = "alpha_site_3") {
  model <- stratModel1
  model[[c("priors", "metro")]][[param]] <- prior
  model
}

.Central99 <- function(prior) {
  diff(vapply(c(0.005, 0.995), function(p) {
    do.call(prior[["Q"]], c(p = p, prior[["args"]]))
  }, numeric(1)))
}

# ── #2298 ────────────────────────────────────────────────────────────────────

test_that("loose bounds do not inflate a truncated normal's scale (#2298)", {
  wide <- .PriorRanges(.WithPrior(TruncNormalPrior(0, log(2), -1000, 1000)))
  narrow <- .PriorRanges(.WithPrior(TruncNormalPrior(0, log(2), -3, 3)))

  # PRE-FIX `wide[[2]]` was 2000, against 6 for the +/-3 version.
  expect_lt(wide[[2]], 2 * narrow[[2]])
  expect_equal(wide[[2]], .Central99(NormalPrior(0, log(2))))
})

test_that("a truncated prior's scale is scale-equivariant (#2298)", {
  # Adversarial: signal x 1e3 / 1e5 with bounds that stay 1000 sd wide.
  for (s in c(1, 1e3, 1e5)) {
    scaled <- .WithPrior(TruncNormalPrior(0, s, -1000 * s, 1000 * s))
    # PRE-FIX 2000 * s.
    expect_equal(.PriorRanges(scaled)[[2]], s * .Central99(NormalPrior(0, 1)))
  }
})

test_that("loose bounds do not inflate a truncated log normal (#2298)", {
  # `TruncLogNormalPrior` names its bounds `min`/`max`, as `UniformPrior` does.
  prior <- TruncLogNormalPrior(0, 0.1, 0, 1e4)
  # PRE-FIX this was 1e4.
  expect_equal(.PriorRanges(.WithPrior(prior))[[2]], .Central99(prior))
  expect_lt(.PriorRanges(.WithPrior(prior))[[2]], 1)
})

test_that("bounds tighter than the central interval still cap it (#2298)", {
  # Near-flat inside its bounds, so its central interval is ~0.99 of them.
  prior <- TruncNormalPrior(0, 100, -1, 1)
  expect_equal(.PriorRanges(.WithPrior(prior))[[2]], .Central99(prior))
  expect_lt(.Central99(prior), 2)
  expect_gt(.Central99(prior), 1.97)
})

test_that("a quantile function that fails falls back to the width (#2298)", {
  prior <- TruncNormalPrior(0, 1, -3, 3)
  prior[["Q"]] <- function(p, ...) stop("no quantiles here")
  expect_equal(.PriorRanges(.WithPrior(prior))[[2]], 6)
  prior[["Q"]] <- function(p, ...) NaN
  expect_equal(.PriorRanges(.WithPrior(prior))[[2]], 6)
})

test_that("a uniform prior keeps its exact width (#2298)", {
  expect_equal(.PriorRanges(.WithPrior(UniformPrior(-7, 11)))[[2]], 18)
  bare <- Prior(runif, dunif, qunif, min = -7, max = 11)
  expect_equal(.PriorRanges(.WithPrior(bare))[[2]], 18)
})

test_that("the initial NeighbourScaled SD follows the narrowed scale (#2298)", {
  model <- .WithPrior(TruncNormalPrior(0, log(2), -1000, 1000),
                      "gammaLog_site_3")
  mcmc <- StratMCMC(model, nIter = 100, nChains = 1, nThreads = 2L)
  idx <- match("gammaLog_site_3", names(model[[c("priors", "metro")]]))
  ns <- mcmc[[c("metro", "proposalArgs")]][[1]][["NeighbourScaled"]][[idx]]
  # PRE-FIX 2000 / 8 = 250.
  expect_equal(ns, .Central99(NormalPrior(0, log(2))) / 8)
})

# ── #2299 item 2 ─────────────────────────────────────────────────────────────

# The C++ log prior, from the same dispatch table the engine reads.
.CppLogPrior <- function(model, x) {
  lp <- .PrepareLogPostArgs(model)
  .sb_logpost(x, lp[["priorTypes"]], lp[["priorArgs"]],
              .SafeCallbacks(lp[["rCustomFns"]], "custom prior density"),
              list(), list(), numeric(), numeric(), FALSE, list(),
              list())[[1]]
}

.Probe <- function(model) {
  vapply(model[[c("priors", "metro")]], function(prior) 0.3, numeric(1))
}

test_that("a typed prior with a replaced density scores it in C++ (#2299)", {
  p <- NormalPrior(0, 1)
  p$D <- function(x, ..., log = FALSE) dunif(x, -5, 5, log = log)
  model <- .WithPrior(p, "gammaLog_site_3")
  x <- .Probe(model)

  # PRE-FIX C++ scored the built-in normal, R scored `p$D`: -0.96 vs -2.30.
  expect_equal(.CppLogPrior(model, x), sum(.MetroPriorLog(model, x)))
  expect_identical(.PrepareLogPostArgs(model)[["priorTypes"]][[4]], "")
})

test_that("a bounded typed prior with a replaced density too (#2299)", {
  # Bounded: as a built-in, the C++ engine also samples it on a transform.
  p <- TruncNormalPrior(0, 1, -2, 2)
  p$D <- function(x, ..., log = FALSE) dunif(x, -2, 2, log = log)
  model <- .WithPrior(p)
  x <- .Probe(model)
  expect_equal(.CppLogPrior(model, x), sum(.MetroPriorLog(model, x)))
  expect_identical(.PrepareLogPostArgs(model)[["priorTypes"]][[2]], "")
})

test_that("a typed prior saved under another density body still runs (#2299)", {
  # A release whose `.dtnorm` body differed: the saved closure keeps its old
  # body but is restored into this namespace, so it is not `identical()`.
  stale <- .dtnorm
  body(stale) <- call("{", quote(invisible(NULL)), body(.dtnorm))
  p <- TruncNormalPrior(0, 1, -2, 2)
  p$D <- stale
  file <- withr::local_tempfile(fileext = ".rds")
  saveRDS(.WithPrior(p), file)
  model <- readRDS(file)
  x <- .Probe(model)

  expect_no_error(lp <- .PrepareLogPostArgs(model))
  expect_identical(lp[["priorTypes"]][[2]], "")
  expect_equal(.CppLogPrior(model, x), sum(.MetroPriorLog(model, x)))
})

test_that("unmutated typed priors in a bundled model stay built in (#2299)", {
  types <- .PrepareLogPostArgs(stratModel1)[["priorTypes"]]
  expect_identical(types,
                   vapply(stratModel1[[c("priors", "metro")]],
                          function(p) class(p)[[1]], character(1),
                          USE.NAMES = FALSE))
})

test_that("a typed prior with a replaced density is announced (#2299)", {
  p <- NormalPrior(0, 1)
  p$D <- function(x, ..., log = FALSE) dunif(x, -5, 5, log = log)
  expect_message(
    .NoteForeignDensityPriors(.WithPrior(p, "gammaLog_site_3")),
    "Custom prior density detected for 'gammaLog_site_3'"
  )
  expect_silent(.NoteForeignDensityPriors(stratModel1))
})

# ── #2299 item 3 ─────────────────────────────────────────────────────────────

test_that("StratModelTemplate() refuses a normal gap prior (#2299)", {
  # stratData2 has a gap, so the template has a gap prior to print.
  # PRE-FIX this printed `"gap_site2_1" = NormalPrior(...)`, which
  # `.CheckGapPriorSupport()` always rejects.
  for (gap in c("normal", "Normal")) {
    expect_error(
      StratModelTemplate(stratData2, alignmentScale = "height",
                         sedModel = "site", gap = gap),
      "`gap`.*negative"
    )
  }
  # Every other family remains a gap option.
  expect_output(
    StratModelTemplate(stratData2, alignmentScale = "height",
                       sedModel = "site", gap = "truncated normal"),
    "\"gap_site2_1\" = TruncNormalPrior"
  )
})
