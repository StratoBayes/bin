# Bounds tens of thousands of SDs from the mean: the truncated normal is then
# an exponential tail of rate |zNear| on top of the nearer bound, so to
# O(1/zNear^2) scale-widths its quantile is zNear - log(1 - p) / zNear (upper
# tail) or its mirror (lower tail).

test_that("qtnorm_std matches the exponential tail far from the mean (#2297)", {
  p <- c(0.001, 0.1, 0.5, 0.9, 0.999)
  for (zL in c(1e4, 2e4, 3e4, 5e4, 1e5)) {
    zU <- 1.2 * zL
    expect_lt(max(abs(.sb_qtnorm(p, zL, zU) - (zL - log1p(-p) / zL)) * zL),
              1e-4)
    expect_lt(max(abs(.sb_qtnorm(p, -zU, -zL) - (-zL + log(p) / zL)) * zL),
              1e-4)
  }
})

test_that("TruncNormalPrior far from its mean has right quantiles (#2297)", {
  prior <- TruncNormalPrior(0, 1e-4, 5, 6)
  p <- c(0.1, 0.5, 0.9)
  q <- do.call(prior$Q, c(list(p = p), prior$args))
  scaleWidth <- 1e-4 / 5e4
  expect_lt(max(abs(q - (5 - 1e-4 * log1p(-p) / 5e4))) / scaleWidth, 1e-4)

  # Same prior on a signal scaled by 1e5: the error in scale-widths must not
  # depend on the units.
  scaled <- TruncNormalPrior(0, 10, 5e5, 6e5)
  qScaled <- do.call(scaled$Q, c(list(p = p), scaled$args))
  expect_lt(max(abs(qScaled - (5e5 - 10 * log1p(-p) / 5e4))) / (10 / 5e4),
            1e-4)
})

test_that("Deep-tail truncated draws stay in support (#2297)", {
  set.seed(2297)
  lower <- -1.008
  upper <- -1.002
  draws <- .rtnorm(500, mean = 5.677, sd = 1.37e-4, lower, upper)
  expect_true(all(draws >= lower & draws <= upper))
  # The support check alone would pass with every draw clamped onto `upper`:
  # the gap below it is exponential with mean sd / |zU|.
  gapMean <- 1.37e-4 / ((5.677 - upper) / 1.37e-4)
  expect_lt(abs(mean(upper - draws) / gapMean - 1), 0.2)

  # mean + sd * zU rounds above `upper` here, so a quantile the core pins to
  # zU (RT-369's clamped p > 1) must still be clamped on the original scale.
  expect_gt(5.677 + 1.37e-4 * ((upper - 5.677) / 1.37e-4), upper)
  expect_lte(.qtnorm(1.5, 5.677, 1.37e-4, lower, upper), upper)
  expect_true(is.nan(.qtnorm(NaN, 5.677, 1.37e-4, lower, upper)))
})

test_that("qtnorm_std stays accurate where |z| <= 500 (#2297)", {
  # Round-trip residual against pnorm(log.p = TRUE), which is accurate on every
  # supported R version, unlike qnorm(log.p = TRUE) this deep in the tail.
  set.seed(500)
  u <- runif(200)
  for (zL in c(-500, -200, -50, -37.5, -36.5, -10, 3, 37.5, 200, 450)) {
    zU <- zL + 5
    z <- .sb_qtnorm(u, zL, zU)
    if (zU < 0) {
      target <- log(u + (1 - u) *
                      exp(pnorm(zL, log.p = TRUE) - pnorm(zU, log.p = TRUE))) +
        pnorm(zU, log.p = TRUE)
      got <- pnorm(z, log.p = TRUE)
    } else {
      target <- log(u * exp(pnorm(zU, lower.tail = FALSE, log.p = TRUE) -
                              pnorm(zL, lower.tail = FALSE, log.p = TRUE)) +
                      (1 - u)) + pnorm(zL, lower.tail = FALSE, log.p = TRUE)
      got <- pnorm(z, lower.tail = FALSE, log.p = TRUE)
    }
    # Residual in log-probability over the slope |d log P / dz| ~ max(|z|, 1)
    # gives the error in z.
    expect_lt(max(abs(got - target) / pmax(abs(z), 1)), 1e-12)
  }
})
