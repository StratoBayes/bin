AlignmentRows <- function(stratCluster, alignment, runs, maxSamples) {
  rows <- lapply(seq_along(stratCluster[["rowIndex"]]), function(r) {
    if (!r %in% runs) {
      return(NULL)
    }
    inAlignment <- stratCluster[["clusterList"]][[r]] %in% alignment
    stratCluster[["rowIndex"]][[r]][inAlignment]
  })

  # Return:
  .maxSampleDeterministicRows(rows, maxSamples)
}

ExpectScoresAlignment <- function(sp, alignment, maxSamples = 200L,
                                  runs = seq_len(sp[["nRun"]]),
                                  stratCluster = NULL, burnIn = 0.5) {
  sc <- stratCluster
  if (is.null(sc)) {
    sc <- Cluster(sp, burnIn = burnIn, runs = runs)
  }
  sigNames <- sp[[c("data", "signalAttr", "signalNames")]]
  draws <- .FitDiagnosticsDraws(sp, sigNames, alignment, burnIn, maxSamples,
                                runs, stratCluster)
  expected <- ExtractParameters(
    sp, parameters = sp[[c("model", "parametersNames")]],
    selectRows = AlignmentRows(sc, alignment, runs, maxSamples)
  )
  expect_equal(unname(draws[["metro"]]), unname(as.matrix(expected)))

  # Return:
  sc
}

test_that("`alignment = k` scores the alignment `summary()` names (#2291)", {
  # Clustering only the 200 thinned draws found a second mode in 4b that the
  # full clustering, and so the convergence gate, does not.
  sp <- stratPosterior4b
  sc <- ExpectScoresAlignment(sp, 1L)
  fit <- FitDiagnostics(sp, alignment = 1L)
  expect_equal(fit[[c("general", "nSamples")]], 200L)
  expect_equal(fit[[c("general", "nAlignments")]], sc[["nClust"]])
  gate <- summary(sp, alignment = 1L)
  expect_equal(fit[[c("general", "multiESS")]],
               as.numeric(gate[[c("alignment1", "multiESS")]]))

  expect_error(FitDiagnostics(sp, alignment = 2L),
               "whole numbers between 1 and 1")
})

test_that("each of several alignments is gated on its own draws (#2291)", {
  sp <- stratPosterior5a
  sc <- ExpectScoresAlignment(sp, 2L)
  fit <- FitDiagnostics(sp, alignment = 2L)
  nInAlignment <- sum(unlist(sc[["clusterList"]]) == 2L)
  expect_lt(nInAlignment, 200L)
  expect_equal(fit[[c("general", "nSamples")]], nInAlignment)
  expect_equal(fit[[c("general", "nAlignments")]], sc[["nClust"]])
  gate <- summary(sp, alignment = 2L)
  expect_true(is.finite(fit[[c("general", "rhatMax")]]))
  expect_equal(fit[[c("general", "multiESS")]],
               as.numeric(gate[[c("alignment2", "multiESS")]]))
})

test_that("`alignment = k` clusters at the caller's burnIn and runs (#2291)", {
  # Unequal runs: run 2 stopped short of the others.
  sp <- stratPosterior5b
  ExpectScoresAlignment(sp, 1L, maxSamples = 40L, runs = c(1L, 2L),
                        burnIn = 0.8)
})

test_that("pooled draws are counted at the caller's burnIn (#2291)", {
  # Late in 4b's runs the draws split into two modes the default burn-in hides.
  sp <- stratPosterior4b
  sc <- Cluster(sp, burnIn = 0.9)
  expect_gt(sc[["nClust"]], 1L)
  fit <- FitDiagnostics(sp, burnIn = 0.9, maxSamples = 50L)
  expect_equal(fit[[c("general", "nAlignments")]], sc[["nClust"]])
  expect_output(print(fit), paste("pooled over", sc[["nClust"]]))
})

test_that("`maxSamples` caps a supplied stratCluster's draws (#2292)", {
  sp <- stratPosterior5a
  sc <- Cluster(sp)
  fit <- FitDiagnostics(sp, alignment = 1L, maxSamples = 50L, burnIn = 0.9,
                        stratCluster = sc)
  expect_equal(fit[[c("general", "nSamples")]], 50L)

  # A truncated run: only run 2's rows are in play, and they must be thinned.
  sp <- stratPosterior5b
  sc <- Cluster(sp)
  ExpectScoresAlignment(sp, 1L, maxSamples = 30L, runs = 2L, stratCluster = sc)
  fit <- FitDiagnostics(sp, alignment = 1L, maxSamples = 30L, runs = 2L,
                        stratCluster = sc)
  expect_equal(fit[[c("general", "nSamples")]], 30L)
})

test_that("print() does not give a clean verdict when nothing was assessed", {
  # 5b: unequal, NA-padded runs.
  for (sp in list(stratPosterior3, stratPosterior5b)) {
    fit <- FitDiagnostics(sp, minSiteN = 1e4, maxSamples = 20L)
    expect_true(all(is.na(fit[["sites"]][["pppDrift"]])))
    printed <- capture.output(print(fit))
    expect_true(any(grepl("No site had enough points", printed)))
    expect_false(any(grepl("No site's residuals depart", printed)))
  }
})

test_that("print() rejects a threshold that is not a probability (#2292)", {
  fit <- FitDiagnostics(stratPosterior1, maxSamples = 20L)
  for (bad in list(NA, NA_real_, NaN, Inf, -Inf, -0.01, 1.5, c(0.01, 0.02),
                   "0.01", numeric(0))) {
    expect_error(print(fit, threshold = bad), "`threshold`")
  }
  expect_output(print(fit, threshold = 0.05), "flagged below 0.05")
  # 0 flags nothing, so it is a legitimate way to ask for no flags.
  expect_output(print(fit, threshold = 0), "flagged below 0)")
})

test_that("a sigmaFixed name mismatch warns once, not once per signal", {
  sp <- stratPosterior2
  names(sp[[c("model", "sigmaFixed")]]) <- c("b", "a")
  warnings <- testthat::capture_warnings(FitDiagnostics(sp, maxSamples = 10L))
  expect_length(grep("sigmaFixed", warnings), 1L)
})

test_that("each draw's beta is paired with that draw's own alignment", {
  # beta | ages, sigma, lambda ~ N(mu, Q^-1) with Q = B'B / sigma^2 + lambda D,
  # so (beta - mu)' Q (beta - mu) is chi-squared on p degrees of freedom.
  # Pairing beta with another draw's ages inflates it wherever the posterior
  # on the ages is wide enough to move the basis.
  Statistic <- function(sp, alignment, mispair = FALSE, nDraw = 40L) {
    sigNames <- sp[[c("data", "signalAttr", "signalNames")]]
    model <- sp[["model"]]
    draws <- .FitDiagnosticsDraws(sp, sigNames, alignment, 0.5, nDraw, "all",
                                  NULL)
    selection <- .FitSelection(sp, alignment, 0.5, nDraw, "all", NULL)
    lambda <- as.matrix(ExtractParameters(
      sp, parameters = paste0("lambda_", sigNames), alignment = alignment,
      burnIn = 0.5, maxSamples = nDraw, runs = "all",
      stratCluster = selection[["stratCluster"]],
      selectRows = selection[["selectRows"]]
    ))
    n <- nrow(draws[["metro"]])
    partner <- seq_len(n)
    if (mispair) {
      partner <- (partner + n %/% 2L - 1L) %% n + 1L
    }
    layout <- lapply(sigNames, .FitSignalLayout, data = sp[["data"]])
    names(layout) <- sigNames
    stat <- vapply(seq_len(n), function(d) {
      ageFlat <- .FitDrawAges(sp[["data"]], model, draws, partner[[d]])
      extKnots <- .FitExtKnots(model, ageFlat)
      D <- model[[c("splineBase", "D")]]
      if (isTRUE(model[["flexibleKnots"]])) {
        D <- D * (model[[c("splineBase", "ageSpan")]] / diff(range(ageFlat)))^3
      }
      sum(vapply(seq_along(sigNames), function(m) {
        sig <- sigNames[[m]]
        lay <- layout[[sig]]
        B <- splineDesign(extKnots, ageFlat[lay[["pointInd"]]], sparse = FALSE)
        sigma2 <- draws[[c("sigma", sig)]][[d]]^2
        Q <- crossprod(B) / sigma2 + lambda[d, m] * D
        mu <- solve(Q, crossprod(B, .FitObserved(lay, draws, d)) / sigma2)
        resid <- draws[[c("beta", sig)]][d, ] - mu
        as.numeric(crossprod(resid, Q %*% resid))
      }, numeric(1)))
    }, numeric(1))

    # Return:
    mean(stat) / (length(sigNames) * model[[c("splineBase", "num_basis")]])
  }

  # 1: fixed sigma, flexible knots; 2: two signals; 3: estimated sigma, read
  # through one alignment's selection.
  cases <- list(list(stratPosterior1, "all"), list(stratPosterior2, "all"),
                list(stratPosterior3, 1L))
  for (case in cases) {
    paired <- Statistic(case[[1]], case[[2]])
    expect_gt(paired, 0.5)
    expect_lt(paired, 1.5)
    expect_gt(Statistic(case[[1]], case[[2]], mispair = TRUE), 1.5)
  }

  # Unequal, NA-padded runs. Their age posterior is too tight for a mispairing
  # to show, so only the pairing itself is checked.
  paired <- Statistic(stratPosterior5b, 1L)
  expect_gt(paired, 0.5)
  expect_lt(paired, 1.5)
})
