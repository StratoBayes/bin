test_that("plot.StratPrior leaves the RNG stream untouched (#1412)", {
  priors <- structure(
    list(
      alpha_site_2 = UniformPrior(min = -60, max = 60),
      gammaLog_site_2 = NormalPrior(mean = 0, sd = log(2))
    ),
    class = c("StratPrior", "list")
  )
  set.seed(1412)
  before <- .Random.seed
  pdf(NULL)
  on.exit(dev.off(), add = TRUE)
  plot(priors, parameters = 1:2)
  expect_identical(.Random.seed, before)
})

test_that(".FindXRange() keeps a non-zero width for heavy tails (#1409)", {
  for (sdlog in c(2, 2.5, 3)) {
    xRange <- .FindXRange(dlnorm, qlnorm,
                          list(meanlog = 0, sdlog = sdlog), 1)
    expect_true(all(is.finite(xRange)))
    expect_gt(diff(xRange), 0)
    covered <- diff(plnorm(xRange, meanlog = 0, sdlog = sdlog))
    expect_gte(covered, 0.98)
  }
})

test_that(".FindXRange() pads a uniform prior by one linear step", {
  xRange <- .FindXRange(dunif, qunif, list(min = 1, max = 100), 1)
  expect_lt(xRange[1], 1)
  expect_gt(xRange[2], 100)
})

test_that(".FindXRange(logX = FALSE) overflow falls back to positive", {
  flat <- function(x, ...) rep(1, length(x))
  infinite <- function(p, ...) rep(Inf, length(p))
  expect_warning(
    xRange <- .FindXRange(flat, infinite, list(), 1, logX = FALSE),
    "finite x-range"
  )
  expect_true(all(is.finite(xRange)))
  expect_gt(xRange[1], 0)
})

test_that("TruncLogNormDensity rejects an empty support (#1690)", {
  expect_error(TruncLogNormDensity(0, min = -Inf, max = 0), "positive")
  expect_error(TruncLogNormDensity(1, min = -1, max = 0), "positive")
})

# Pins #1478, which already made `.qtnorm()` propagate NaN (#1690 item 2).
test_that(".qtnorm() propagates a NaN probability (#1690)", {
  expect_true(is.nan(.qtnorm(NaN, 0, 1, -1, 1)))
  expect_equal(.qtnorm(c(0.5, NaN), 0, 1, -1, 1)[1], 0)
  expect_true(is.nan(.qtnorm(c(0.5, NaN), 0, 1, -1, 1)[2]))
})

test_that("Prior() rejects unnamed and duplicated args (#1264)", {
  expect_error(Prior(runif, dunif, qunif, 5, 2), "named")
  expect_error(Prior(runif, dunif, qunif, min = 0, min = 1), "exactly once")
})
