# Area 13 red-team round 13/14 (2026-08-22 to 2026-09-04): five findings in
# Partitions()'s `distribute`/boundary-count/column-name handling and the
# shared alignment validator.

## ---- #1703: StratoSegment reducing K below nStrata must not pass silently
## ----

test_that(paste0("Partitions(distribute = 'StratoSegment') errors when a site ",
                 "is too sparse for nStrata"), {
            skip_if_not_installed("StratoSegment")
            set.seed(1)
            heightA <- seq(0, 20, length.out = 40)
            signalA <- c(rep(0, 20), rep(5, 20)) + rnorm(40, sd = 0.01)
            heightB <- seq(0, 5, length.out = 6)
            signalB <- rnorm(6, sd = 0.01)
            dat <- data.frame(
              site = c(rep("A", 40), rep("B", 6)),
              height = c(heightA, heightB),
              value = c(signalA, signalB)
            )

            # StratoSegment cannot fit nStrata - 1 = 2 change points on site B's
            # 6 points and reduces K internally; Partitions() must not accept a
            # lopsided result rather than the requested nStrata partitions per
            # site.
            expect_error(
              suppressWarnings(Partitions(dat, nStrata = 3,
                                          distribute = "StratoSegment",
                                          signalColumn = "value")),
              "not the requested"
            )
          })

## ---- #1706: zColumn/siteColumn == 'partition' must not be overwritten -------

test_that(paste0("Partitions() does not overwrite a zColumn literally named ",
                 "'partition'"), {
            signal <- data.frame(
              site = c("A", "A", "A", "B", "B", "B", "B", "B"),
              height = c(1, 1.5, 2, 1, 2, 3, 3.5, 4)
            )
            expected <- Partitions(signal, nStrata = 2, distribute = "height")

            renamed <- signal
            names(renamed)[[2]] <- "partition"
            out <- Partitions(renamed, nStrata = 2, distribute = "partition",
                              zColumn = "partition")
            # The computed boundary heights must survive, not a bare seq_len().
            expect_equal(out[["partition"]], expected[["height"]])
          })

test_that(paste0("Partitions() does not overwrite a siteColumn literally ",
                 "named 'partition'"), {
            signal <- data.frame(
              partition = c("A", "A", "A", "B", "B", "B", "B", "B"),
              height = c(1, 1.5, 2, 1, 2, 3, 3.5, 4)
            )
            out <- Partitions(signal, nStrata = 2, distribute = "points",
                              siteColumn = "partition", zColumn = "height")
            # The site-label column survives; no third "partition" index column
            # is added on top of it.
            expect_equal(out[["partition"]], c("A", "A", "B", "B"))
            expect_equal(colnames(out), c("partition", "height"))
          })

## ---- #1707: surplus alignment elements after "all"/"none" must not be ignored
## ----

test_that(".ValidateAlignment() rejects a surplus NA after 'all'", {
  expect_error(
    StratoBayes:::.ValidateAlignment(c("all", NA), clustUnique = 1:3),
    "must be"
  )
})

test_that(paste0(".ValidateAlignment() rejects a surplus out-of-range element ",
                 "after 'all'"), {
            expect_error(
              StratoBayes:::.ValidateAlignment(c("all", 99), clustUnique = 1:3),
              "must be"
            )
          })

test_that(paste0(".IsAllAlignment() is FALSE for a vector with a surplus ",
                 "element after 'all'"), {
            expect_false(StratoBayes:::.IsAllAlignment(c("all", 99)))
            expect_false(StratoBayes:::.IsAllAlignment(c("all", NA)))
            expect_true(StratoBayes:::.IsAllAlignment("all"))
            expect_true(StratoBayes:::.IsAllAlignment("none"))
          })

## ---- #1785: degenerate-boundary stop() must attribute to the user call -----

test_that("Partitions() height-range error does not attribute to lapply's FUN",
          {
            signal <- data.frame(site = "A", height = c(1, 1, 1))
            err <- tryCatch(
              Partitions(signal, nStrata = 2, distribute = "height"),
              error = function(e) e
            )
            expect_s3_class(err, "simpleError")
            # call. = FALSE means no call is attached at all, so it can never
            # render as the internal "FUN(X[[i]], ...)" frame.
            expect_null(conditionCall(err))
          })

## ---- #1961: distChoices must not duplicate a zColumn literal 'points' ------

test_that(paste0("Partitions() distribute abbreviation is unambiguous when ",
                 "zColumn = 'points'"), {
            signal <- data.frame(site = c("A", "A", "A"), points = c(1, 2, 3))
            expect_error(
              Partitions(signal, nStrata = 5, distribute = "xyz",
                         zColumn = "points"),
              "'StratoSegment', 'points'\\.$"
            )
          })
