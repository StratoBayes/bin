# Tests for C++ age conversion (.sb_age_convert) equivalence with R version.
# For each dataset × sedModel × alignmentScale combination, assert that
# the C++ output matches the R output within tolerance on random parameter
# vectors.

tol <- 1e-10

# Compare R and C++ results, handling NAs
compare_results <- function(r_result, cpp_result, label) {

  # Signal
  for (s in seq_along(r_result[["signal"]])) {
    r_v <- r_result[["signal"]][[s]]
    c_v <- cpp_result[["signal"]][[s]]
    r_na <- is.na(r_v)
    c_na <- is.na(c_v)
    expect_identical(r_na, c_na,
                     label = paste(label, "signal site", s, "NA pattern"))
    non_na <- !r_na
    if (any(non_na)) {
      expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
                   label = paste(label, "signal site", s))
    }
  }

  # Ties
  if ("ties" %in% names(r_result)) {
    for (s in seq_along(r_result[["ties"]])) {
      r_v <- r_result[["ties"]][[s]]
      c_v <- cpp_result[["ties"]][[s]]
      r_na <- is.na(r_v)
      c_na <- is.na(c_v)
      expect_identical(r_na, c_na,
                       label = paste(label, "ties site", s, "NA pattern"))
      non_na <- !r_na
      if (any(non_na)) {
        expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
                     label = paste(label, "ties site", s))
      }
    }
  }

  # Alphas.  Both engines must agree on whether alphas exist at all, and on
  # which boundaries have them: without these two assertions the comparison
  # below is skipped rather than failed when one side is NULL, so the whole
  # block passes with the engines in outright disagreement.
  expect_identical("alphas" %in% names(r_result),
                   "alphas" %in% names(cpp_result),
                   label = paste(label, "alphas element present"))
  if ("alphas" %in% names(r_result)) {
    expect_identical(length(r_result[["alphas"]]),
                     length(cpp_result[["alphas"]]),
                     label = paste(label, "alphas length"))
    for (s in seq_along(r_result[["alphas"]])) {
      r_a <- r_result[["alphas"]][[s]]
      c_a <- cpp_result[["alphas"]][[s]]
      expect_identical(is.null(r_a), is.null(c_a),
                       label = paste(label, "alphas site", s, "nullness"))
      if (!is.null(r_a) && !is.null(c_a)) {
        r_v <- as.numeric(r_a)
        c_v <- as.numeric(c_a)
        r_na <- is.na(r_v)
        c_na <- is.na(c_v)
        expect_identical(r_na, c_na,
                         label = paste(label, "alphas site", s, "NA pattern"))
        non_na <- !r_na
        if (any(non_na)) {
          expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
                       label = paste(label, "alphas site", s))
        }
      }
    }
  }
}

# ---- Tests using bundled data + model objects ----

test_that("C++ matches R for bundled stratData × stratModel pairs", {
  pairs <- list(
    list(data = "stratData0", model = "stratModel0"),
    list(data = "stratData1", model = "stratModel1"),
    list(data = "stratData2", model = "stratModel2"),
    list(data = "stratData3", model = "stratModel3"),
    list(data = "stratData4", model = "stratModel4")
  )

  set.seed(5091)

  for (p in pairs) {
    d <- .EnsurePreExtracted(get(p[["data"]]))
    m <- get(p[["model"]])
    indices <- m[["ind"]]
    nPar <- length(indices[["names"]])

    for (trial in seq_len(5)) {
      params <- rnorm(nPar, sd = 2)
      label <- sprintf("%s + %s trial %d", p[["data"]], p[["model"]], trial)

      r_result <- .AgeConversionStratData(d, indices, params,
                                          returnAlphas = TRUE)
      cpp_result <- .sb_age_convert(d, indices, params, returnAlphas = TRUE)

      compare_results(r_result, cpp_result, label)
    }
  }
})

# ---- Tests across all sedModel × scale combinations ----

test_that("C++ matches R for all sedModel × alignmentScale combos", {
  datasets <- c("stratData0", "stratData1", "stratData2", "stratData3",
                "stratData4", "stratData4b", "stratData5a", "stratData5b")
  sed_models <- c("site", "partition", "site x partition", "site, partition")
  scales <- c("height", "age")

  set.seed(8273)

  # .CreateIndices() legitimately rejects some dataset x sedModel x scale
  # combinations, but if it rejected them all the loop would exit having
  # compared nothing and testthat would report an empty-test skip, not a
  # failure.
  nComparisons <- 0L

  for (dn in datasets) {
    d <- .EnsurePreExtracted(get(dn))
    for (sd in sed_models) {
      for (sc in scales) {
        indices <- tryCatch(
          .CreateIndices(d, sc, sd, "middle"),
          error = function(e) NULL
        )
        if (is.null(indices)) next

        nPar <- length(indices[["names"]])

        for (trial in seq_len(5)) {
          params <- rnorm(nPar, sd = 2)
          label <- sprintf("%s %s/%s trial %d", dn, sd, sc, trial)

          r_result <- .AgeConversionStratData(
            d, indices, params, returnAlphas = TRUE
          )
          cpp_result <- .sb_age_convert(d, indices, params, returnAlphas = TRUE)

          compare_results(r_result, cpp_result, label)
          nComparisons <- nComparisons + 1L
        }
      }
    }
  }

  expect_gt(nComparisons, 0L)
})

# ---- Regression: RT-239, zeta multiplier on a non-zero-width gap boundary ----
# .GetSedRates on a gap/unconformity boundary (sedRatesDF == 0) returns the
# zeta value, because R's prod(parameters[zeta[...]], numeric(0)) == zeta (an
# empty operand is the multiplicative identity, so the zeta term survives).
# The C++ getSedRate previously returned 1.0 at that lookup miss, dropping the
# zeta factor. This is masked in normal use because StratData()'s .FillGaps
# always builds gap boundaries with zero width (Bound == BoundLow), so the raw
# rate is multiplied by a zero interval before it can affect any output. Here
# we relax that invariant (hand-inject a non-zero-width gap, as a wide
# unconformity or upstream boundary corruption would) so the divergence is
# actually exercised, and assert C++ still matches R.
test_that("C++ matches R when a gap boundary has non-zero width (RT-239)", {
  d <- .EnsurePreExtracted(stratData4)
  indices <- .CreateIndices(d, "age", "site x partition", "middle")

  sedRatesDF <- d[["partsAttr"]][["sedRatesDF"]]
  nBound     <- d[["partsAttr"]][["nBound"]]
  zeta       <- indices[["zeta"]]

  # Locate a gap cell (sedRatesDF == 0) that (a) is an in-range boundary for
  # its site and (b) has an in-range zeta factor (age scale uses zeta[s - 1]).
  # Asserting these preconditions guards against the test going vacuous if the
  # fixture ever changes shape.
  gapCells <- which(sedRatesDF == 0, arr.ind = TRUE)
  gapCells <- gapCells[gapCells[, "row"] <= nBound[gapCells[, "col"]] &
                         (gapCells[, "col"] - 1) >= 1 &
                         (gapCells[, "col"] - 1) <= length(zeta), ,
                       drop = FALSE]
  expect_gt(nrow(gapCells), 0)         # a usable gap boundary exists
  expect_gt(length(zeta), 0)           # zeta factor is present

  b <- gapCells[1, "row"]
  s <- gapCells[1, "col"]

  # Relax the zero-width-gap invariant on that boundary.
  d[["partsAttr"]][["Bound"]][b, s] <-
    d[["partsAttr"]][["BoundLow"]][b, s] + 10
  gapWidth <- d[["partsAttr"]][["Bound"]][b, s] -
    d[["partsAttr"]][["BoundLow"]][b, s]
  expect_gt(gapWidth, 0)               # the divergence path is now active

  set.seed(239)
  for (trial in seq_len(5)) {
    params <- rnorm(length(indices[["names"]]), sd = 2)
    r_result   <- .AgeConversionStratData(d, indices, params,
                                          returnAlphas = TRUE)
    cpp_result <- .sb_age_convert(d, indices, params, returnAlphas = TRUE)
    compare_results(r_result, cpp_result,
                    sprintf("RT-239 non-zero-width gap trial %d", trial))
  }
})

# ---- returnAlphas = FALSE ----

test_that("C++ returnAlphas = FALSE omits alphas element", {
  d <- .EnsurePreExtracted(stratData1)
  indices <- stratModel1[["ind"]]
  params <- c(10, 20, 0.5, 0.3)

  result <- .sb_age_convert(d, indices, params, returnAlphas = FALSE)
  expect_null(result[["alphas"]])
  expect_false(is.null(result[["signal"]]))
})

# ---- Ties presence/absence ----

test_that("C++ output includes ties only when data has ties", {
  d_no_ties <- .EnsurePreExtracted(stratData0)
  d_ties    <- .EnsurePreExtracted(stratData2)

  ind0 <- stratModel0[["ind"]]
  ind2 <- stratModel2[["ind"]]

  r0 <- .sb_age_convert(d_no_ties, ind0, rnorm(2), returnAlphas = FALSE)
  r2 <- .sb_age_convert(d_ties, ind2, rnorm(7), returnAlphas = FALSE)

  expect_null(r0[["ties"]])
  expect_false(is.null(r2[["ties"]]))
})

# ---- New-heights mapping: R (.CalculateNewAges) vs C++ (.sb_age_convert_batch)
# ---- The batch / new-heights path is a SECOND, independent implementation of
# the age conversion. Unlike the forward path above (which reuses the data's
# precomputed signalBind), it re-derives the height->boundary binning via
# .SignalsToBind (R) and signalsToBindCpp (C++). Nothing else in the suite pins
# these two against each other, so a future edit to either could silently
# diverge. This mirrors the validated red-team sweep
# dev/red-team/heavy-tests/RT-area5-newages-equiv.R: it sweeps dataset x
# sedModel x scale x site x random params and DELIBERATELY places heights
# exactly on partition boundaries (Bound == next BoundLow), the `<` vs `<=`
# binning edge where the two implementations are most likely to part.
test_that(paste(".sb_age_convert_batch (C++) matches .CalculateNewAges (R)",
                "on the new-heights path, including partition boundaries"), {
            batchTol <- 1e-9
            datasets <- c("stratData1", "stratData2", "stratData3",
                          "stratData4",
                          "stratData4b", "stratData5a", "stratData5b")
            sed_models <- c("site", "partition", "site x partition",
                            "site, partition")
            scales <- c("height", "age")

            set.seed(20260710)
            nComparisons <- 0L

            for (dn in datasets) {
              d <- .EnsurePreExtracted(get(dn))
              S <- d[["S"]]
              for (sd in sed_models) {
                for (sc in scales) {
                  indices <- tryCatch(
                    .CreateIndices(d, sc, sd, "middle"),
                    error = function(e) NULL
                  )
                  if (is.null(indices)) next
                  nPar <- length(indices[["names"]])

                  # height scale aligns sites 2:S to the reference site 1; age
                  # scale uses all sites. seq_len(S)[>= 2] rather than seq(2, S)
                  # so S == 1 yields an empty sequence instead of the descending
                  # c(2, 1).
                  siteSeq <- if (.IsHeightScale(sc, validate = FALSE)) {
                    seq_len(S)[seq_len(S) >= 2L]
                  } else {
                    seq_len(S)
                  }

                  for (site in siteSeq) {
                    nb <- d[[c("partsAttr", "nBound")]][site]
                    bl <- d[[c("partsAttr", "BoundLow")]][seq_len(nb), site]
                    bh <- d[[c("partsAttr", "Bound")]][seq_len(nb), site]
                    # In-bounds heights: every boundary low, every boundary top
                    # (exact partition edges), and the midpoints. sort() is
                    # load-bearing -- signalsToBindCpp assumes contiguous,
                    # sorted input.
                    heights <- sort(unique(c(bl, bh, (bl + bh) / 2)))
                    heights <- heights[is.finite(heights)]
                    if (length(heights) == 0) next

                    for (trial in seq_len(3)) {
                      params <- rnorm(nPar, sd = 2)
                      label <- sprintf("%s %s/%s site %d trial %d", dn, sd, sc,
                                       site, trial)

                      # NB: the two APIs take (site, heights) in OPPOSITE order
                      # -- .CalculateNewAges(..., site, heights) vs
                      # .sb_age_convert_batch(..., heights, site). Do not "tidy"
                      # this.
                      rOut <- .CalculateNewAges(d, indices, params, site,
                                                heights)
                      cOut <- as.numeric(
                        .sb_age_convert_batch(d, indices,
                                              matrix(params, nrow = 1),
                                              heights, site)
                      )

                      expect_identical(is.na(rOut), is.na(cOut),
                                       label = paste(label, "NA pattern"))
                      nonNA <- !is.na(rOut)
                      if (any(nonNA)) {
                        expect_equal(rOut[nonNA], cOut[nonNA],
                                     tolerance = batchTol,
                                     label = label)
                      }
                      nComparisons <- nComparisons + 1L
                    }
                  }
                }
              }
            }

            # Guard against silent vacuity: if a refactor made every combo skip,
            # the loop would emit zero expectations and still "pass". Require
            # real coverage.
            expect_gt(nComparisons, 0L)
          })


# ---- RT-719 (#911): .sb_age_convert_batch validates `site` in its WRAPPER ----
# The impl computes s = site - 1 and immediately reads nBound[s], Bound(b, s)
# and BoundLow(b, s). R's caller-side guard in .AgeConversionBatch cannot stand
# in for one here: `BoundLow[, site]` with a negative `site` is R's *exclusion*
# indexing, so the guard inspects the wrong columns and passes. Against
# origin/main, site = -1 read s = -2 and segfaulted (exit 139).
test_that(".sb_age_convert_batch rejects an out-of-range site (RT-719)", {
  d <- .EnsurePreExtracted(stratData1)
  indices <- .CreateIndices(d, "height", "site", "middle")
  params <- matrix(rnorm(length(indices[["names"]])), nrow = 1)
  nSites <- ncol(d[[c("partsAttr", "Bound")]])
  heights <- d[[c("partsAttr", "BoundLow")]][1, 2]

  for (bad in c(-1L, 0L, as.integer(nSites + 1L))) {
    expect_error(
      .sb_age_convert_batch(d, indices, params, heights, bad),
      "site index between 1 and",
      label = paste("site =", bad)
    )
  }
  expect_no_error(.sb_age_convert_batch(d, indices, params, heights, 2L))
})

test_that(".sb_age_convert_batch rejects a parameterMatrix of the wrong width",
          {
            d <- .EnsurePreExtracted(stratData1)
            indices <- .CreateIndices(d, "height", "site", "middle")
            nPar <- length(indices[["names"]])
            heights <- d[[c("partsAttr", "BoundLow")]][1, 2]

            expect_error(
              .sb_age_convert_batch(d, indices,
                                    matrix(rnorm(nPar - 1L), nrow = 1),
                                    heights, 2L),
              "one column per model parameter"
            )
            expect_no_error(
              .sb_age_convert_batch(d, indices, matrix(rnorm(nPar), nrow = 1),
                                    heights, 2L)
            )
          })

# ---- #1233: alpha anchored in a different partition ----
# Resolving "middle" against the sampled extent rather than the `parts` extent
# can move the anchor across a partition boundary and a gap. The anchor is a
# reparameterisation: alpha re-expressed as the age at the new anchor must give
# identical ages, from both engines.
test_that("ages are invariant to moving the alpha anchor across a gap (#1233)",
          {
            heights <- 0:10
            signal <- data.frame(site = rep(c("s1", "s2"),
                                            each = length(heights)),
                                 height = rep(heights, 2),
                                 x = sin(c(heights, heights + 0.5)))
            parts <- data.frame(site = c("s1", "s2", "s2", "s2"),
                                height = c(10, 6, 6, 30),
                                partition = c("p1", "p2a", NA, "p2b"))
            d <- .EnsurePreExtracted(StratData(signal, parts = parts,
                                               signalColumn = "x"))
            s <- 2L
            boundLow <- d[[c("partsAttr", "BoundLow")]][, s]

            newInd <- .CreateIndices(d, "age", "site", "middle")
            expect_equal(newInd[["alphaPosition"]][[s]], 5)
            oldInd <- newInd
            # midpoint of the parts extent [0, 30]
            oldInd[["alphaPosition"]][[s]] <- 15
            expect_gt(length(newInd[["gap"]]), 0)
            expect_false(findInterval(5, boundLow) == findInterval(15,
                                                                   boundLow))

            alphaIdx <- newInd[["alpha"]][[s]]
            anchorRow <- which(heights == 5)

            set.seed(1233)
            for (trial in seq_len(5)) {
              params <- rnorm(length(newInd[["names"]]), sd = 2)
              for (engine in c("R", "C++")) {
                Convert <- switch(engine, "R" = .AgeConversionStratData,
                                  "C++" = .sb_age_convert)
                old <- Convert(d, oldInd, params, returnAlphas = TRUE)
                moved <- params
                moved[[alphaIdx]] <- old[["signal"]][[s]][[anchorRow]]
                new <- Convert(d, newInd, moved, returnAlphas = TRUE)

                label <- sprintf("%s engine, trial %d", engine, trial)
                expect_equal(new[["signal"]], old[["signal"]],
                             tolerance = 1e-10,
                             label = label)
                expect_equal(as.numeric(new[["alphas"]][[s]]),
                             as.numeric(old[["alphas"]][[s]]),
                             tolerance = 1e-10,
                             label = label)
              }
            }
          })
