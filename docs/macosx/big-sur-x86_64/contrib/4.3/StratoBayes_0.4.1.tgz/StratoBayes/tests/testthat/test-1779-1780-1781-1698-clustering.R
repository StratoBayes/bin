# Area-11 (clustering) findings: #1779, #1780, #1781, #1698.
# #1860 is verified fixed on `main` (documentation now matches behaviour) and
# needs no new test here.

# ---------------------------------------------------------------------------
# #1779: .ProtoClusterSubsample()'s centroid assignment is NA-intolerant
# ---------------------------------------------------------------------------

.Rt1779Data <- function(seed = 42, n1 = 10L, n2 = 10L) {
  set.seed(seed)
  rbind(matrix(rnorm(n1 * 3, 0, 0.3), n1, 3),
        matrix(rnorm(n2 * 3, 20, 0.3), n2, 3))
}

test_that(paste0(".ProtoClusterSubsample() tolerates an all-NA column instead ",
                 "of turning every centroid NA (#1779)"), {
            x <- .Rt1779Data()
            x[, 3] <- NA_real_

            # `maxClusterSamples` below `nrow(x)` forces the
            # subsample-and-assign path;
            # `silCutOff = -Inf`/`silOutlierThreshold = FALSE` keep the 2-group
            # split from being rejected or partly stripped, so the centroid step
            # actually runs across all n rows.
            labels <- .ProtoClusterSubsample(x, maxClusterSamples = 8L,
                                             silCutOff = -Inf,
                                             silOutlierThreshold = FALSE)
            expect_length(labels, nrow(x))
            expect_false(anyNA(labels))
          })

test_that(paste0(".ProtoClusterSubsample() tolerates a single NA cell instead ",
                 "of emitting a silent NA label (#1779)"), {
            x <- .Rt1779Data()
            x[3, 2] <- NA_real_

            labels <- .ProtoClusterSubsample(x, maxClusterSamples = 8L,
                                             silCutOff = -Inf,
                                             silOutlierThreshold = FALSE)
            expect_length(labels, nrow(x))
            expect_false(anyNA(labels))
          })

# ---------------------------------------------------------------------------
# #1780: .ProtoClusterFast()'s degeneracy guard misses a tied-top-merges case
# ---------------------------------------------------------------------------

test_that(paste0(".ProtoClusterFast() treats tied top merges as degenerate, ",
                 "not as the maximal split (#1780)"), {
            n <- 10L
            clustMax <- 5L
            # `protoclust()`/`cutree()` are mocked so the merge heights are
            # exactly controlled: heights[1:4] differ (not a fully flat
            # dendrogram, so the existing `all(diff(heights) == 0)` guard
            # doesn't fire) but the top `clustMax` window heights[5:9] are all
            # tied at 10.
            heights <- c(1, 2, 3, 4, 10, 10, 10, 10, 10)
            clustDat <- matrix(stats::rnorm(n * 2), n, 2)

            # Both are `@importFrom` into StratoBayes's own namespace, so they
            # are mocked the same way as an internally-defined function --
            # `.package = "StratoBayes"` (the importing package), not the
            # package the symbol was imported from, which only patches a
            # namespace `.ProtoClusterFast()` doesn't actually look the binding
            # up in.
            testthat::local_mocked_bindings(
              protoclust = function(d) list(height = heights),
              .package = "StratoBayes"
            )
            testthat::local_mocked_bindings(
              # Bypasses real cutree() entirely (the mocked "tree" has no valid
              # merge structure) and reports back exactly which k
              # .ProtoClusterFast() chose.
              cutree = function(tree, k = NULL, h = NULL) rep.int(as.integer(k),
                                                                  n),
              .package = "StratoBayes"
            )

            got <- as.vector(.ProtoClusterFast(clustDat, clustMax = clustMax))
            # Pre-fix: which.max(diff(merge_h)) ties at 0 everywhere in the
            # window and breaks first, selecting kOpt = clustMax (the maximum
            # split) -- exactly the input with the least evidence for any split.
            # Post-fix: a tied window is degenerate, same as a fully flat
            # dendrogram, so k = 1.
            expect_identical(got, rep.int(1L, n))
          })

# ---------------------------------------------------------------------------
# #1781: .SingleEmpiricalClustInfo() is dead code
# ---------------------------------------------------------------------------

test_that(".SingleEmpiricalClustInfo() has been retired as dead code (#1781)", {
  # Confirmed (grep, independently re-verified) to have zero callers in R/,
  # src/ or tests/, and the live degenerate-covariance fallback in
  # R/mcmcFunctions.R uses the hotter chain's covariance instead -- so the
  # spec's reference to this helper as the *intended* fallback is now stale
  # too (annotated in .agent/specs/mcmc-mixing-investigation/review-phase1-5e.md
  # and -5f.md). Pins the maintainer decision rather than leaving orphaned,
  # unwired code beside a spec that still claims it is the plan.
  expect_false(exists(".SingleEmpiricalClustInfo",
                      where = asNamespace("StratoBayes"),
                      inherits = FALSE))
})

# ---------------------------------------------------------------------------
# #1698: Cluster.StratPosterior() silently drops silOutlierThreshold/
# silOutlierSDFromMean
# ---------------------------------------------------------------------------

test_that(paste0("Cluster.StratPosterior() forwards silOutlierThreshold/",
                 "silOutlierSDFromMean to .ProtoClusterSubsample() (#1698)"), {
            captured <- NULL
            testthat::local_mocked_bindings(
              .ProtoClusterSubsample = function(clustDat, clustMax = 12,
                                                silCutOff = 0.5,
                                                silOutlierThreshold = TRUE,
                                                silOutlierSDFromMean = 3,
                                                maxClusterSamples = 2500) {
                captured <<- list(silOutlierThreshold = silOutlierThreshold,
                                  silOutlierSDFromMean = silOutlierSDFromMean)
                rep.int(1L, nrow(clustDat))
              },
              .package = "StratoBayes"
            )

            Cluster(stratPosterior1, burnIn = 0.75,
                    silOutlierThreshold = FALSE, silOutlierSDFromMean = 99)

            # Pre-fix, Cluster.StratPosterior() never had these as named
            # parameters -- they were swallowed by `...` -- so `captured` would
            # stay at the mock's own defaults (TRUE, 3) regardless of what the
            # caller passed.
            expect_identical(captured, list(silOutlierThreshold = FALSE,
                                            silOutlierSDFromMean = 99))
          })

test_that(paste0("Cluster.StratPosterior() validates silOutlierThreshold/",
                 "silOutlierSDFromMean (#1698)"), {
            expect_error(Cluster(stratPosterior1, burnIn = 0.75,
                                 silOutlierThreshold = NA),
                         "silOutlierThreshold")
            expect_error(Cluster(stratPosterior1, burnIn = 0.75,
                                 silOutlierSDFromMean = "x"),
                         "silOutlierSDFromMean")
          })
