# #1892: a seeded continuation reseeded from `seed`, replaying the stream its
# previous segment had already consumed instead of continuing it.
test_that("a seeded continuation continues its checkpointed RNG stream (#1892)",
          {
            skip_on_cran()

            data(stratData1, package = "StratoBayes", envir = environment())
            data(stratModel1, package = "StratoBayes", envir = environment())
            Run <- function(nIter, modelDir, engine, nChains) {
              suppressWarnings(RunStratModel(
                stratObject = stratData1, stratModel = stratModel1,
                nIter = nIter, nChains = nChains, seed = 7,
                tempering = nChains > 1,
                adaptProposal = FALSE, gradientProposals = "off",
                engine = engine,
                quiet = TRUE, visualise = FALSE, runParallel = FALSE,
                nThreads = 1L,
                modelDir = modelDir,
                modelName = "rng"
              ))
            }

            # R's stream drives the R engine and the C++ engine's tempering
            # swaps; the C++ engine's per-chain streams are checkpointed beside
            # it.
            for (engine in c("R", "cpp")) {
              nChains <- if (engine == "R") 1 else 2
              whole <- Run(20, withr::local_tempdir(), engine, nChains)
              segmented <- suppressWarnings(RunStratModel(
                Run(10, withr::local_tempdir(), engine, nChains), nIter = 10,
                seed = 7,
                engine = engine, quiet = TRUE, visualise = FALSE, nThreads = 1L
              ))

              expect_identical(dim(segmented[["samples"]]),
                               dim(whole[["samples"]]),
                               label = engine)
              expect_equal(unname(segmented[["samples"]]),
                           unname(whole[["samples"]]),
                           label = engine)
            }
          })

test_that(".sb_set_chain_rng() refuses a malformed checkpoint (#1892)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1, nIter = 10,
    nChains = 2, seed = 7, adaptProposal = FALSE, engine = "cpp", quiet = TRUE,
    visualise = FALSE, runParallel = FALSE, nThreads = 1L, modelDir = td,
    modelName = "streams"
  ))
  checkpoint <- readRDS(file.path(td, "streams_mcmc_run_1.rds"))
  streams <- checkpoint[["chainRNG"]]
  expect_length(streams, 2)
  expect_named(streams[[1]], c("gen", "cache", "cacheFull"))

  continued <- checkpoint
  continued[["chainRNG"]] <- streams[1]
  saveRDS(continued, file.path(td, "streams_mcmc_run_1.rds"))
  expect_error(
    suppressWarnings(RunStratModel(modelDir = td, modelName = "streams",
                                   nIter = 5, seed = 7, engine = "cpp",
                                   quiet = TRUE, visualise = FALSE,
                                   nThreads = 1L)),
    "different number of chains"
  )

  continued[["chainRNG"]] <- streams
  continued[["chainRNG"]][[2]][["gen"]] <- "not a stream"
  saveRDS(continued, file.path(td, "streams_mcmc_run_1.rds"))
  expect_error(
    suppressWarnings(RunStratModel(modelDir = td, modelName = "streams",
                                   nIter = 5, seed = 7, engine = "cpp",
                                   quiet = TRUE, visualise = FALSE,
                                   nThreads = 1L)),
    "does not parse"
  )
})

test_that("a seed reproduces a run without proposal adaptation (#1892)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  Run <- function(nThreads, adaptProposal = FALSE) {
    suppressWarnings(RunStratModel(
      stratObject = stratData1, stratModel = stratModel1, nIter = 500,
      nChains = 4, seed = 7, adaptProposal = adaptProposal, quiet = TRUE,
      visualise = FALSE, runParallel = FALSE, nThreads = nThreads,
      modelDir = withr::local_tempdir(.local_envir = parent.frame()),
      modelName = "rep"
    ))
  }

  one <- Run(1L)
  expect_identical(unname(Run(2L)[["samples"]]), unname(one[["samples"]]))
  checkpoint <- readRDS(file.path(one[["modelDir"]], "rep_mcmc_run_1.rds"))
  expect_false(is.null(checkpoint[["rngState"]]))

  # Timed adaptation promises nothing, so there is no stream to resume.
  adapted <- Run(1L, adaptProposal = TRUE)
  checkpoint <- readRDS(file.path(adapted[["modelDir"]], "rep_mcmc_run_1.rds"))
  expect_null(checkpoint[["rngState"]])
})

test_that("an unseeded run checkpoints no RNG stream to resume (#1892)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  td <- withr::local_tempdir()
  suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = stratModel1, nIter = 10,
    nChains = 1, seed = FALSE, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L, modelDir = td, modelName = "free"
  ))
  expect_null(readRDS(file.path(td, "free_mcmc_run_1.rds"))[["rngState"]])
})

test_that(".SeedRun prefers the checkpointed stream to `seed` (#1892)", {
  withr::local_seed(99)
  set.seed(3)
  runif(5)
  saved <- .Random.seed

  .SeedRun(seed = c(1, 2), run = 2, rngState = saved)
  expect_identical(.Random.seed, saved)

  .SeedRun(seed = c(1, 2), run = 2, rngState = NULL)
  expect_identical(runif(1), {set.seed(2); runif(1)})

  set.seed(4)
  before <- .Random.seed
  .SeedRun(seed = FALSE, run = 1, rngState = saved)
  expect_identical(.Random.seed, before)
})
