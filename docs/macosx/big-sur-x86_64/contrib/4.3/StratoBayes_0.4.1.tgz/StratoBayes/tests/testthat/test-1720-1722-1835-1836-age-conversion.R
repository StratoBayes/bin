# Age-conversion hardening: #1720, #1721, #1722, #1835, #1836.

test_that("Tops() refuses a negative gap drawn from the prior (#1720)", {
  set.seed(1)
  td <- .GenerateTestData("multi", "gap-names-3-sites")
  sd <- StratData(td[["signal"]], parts = td[["parts"]],
                  signalColumn = c("a", "b"), zColumn = "Hight",
                  siteColumn = "SIT")
  priors <- AutoPrior(sd, alignmentScale = "height", sedModel = "site",
                      alphaPosition = "middle")
  priors[["gap_site2_1"]] <- ExponentialPrior(1)
  model <- StratModel(sd, priors = priors, sedModel = "site",
                      alignmentScale = "height", alphaPosition = "middle")
  # StratModel() rejects this prior, but nothing stops a later edit, and
  # Tops()'s prior branch never reaches the sampler's own gap check
  model[[c("priors", "metro")]][["gap_site2_1"]] <-
    NormalPrior(mean = -60, sd = 0.001)
  expect_error(Tops(model, stratData = sd, maxSamples = 3),
               "gap_site2_1 of site 2 are negative")
})

test_that("a hand-supplied negative gap is refused, not inverted (#1720)", {
  pars <- ExtractParameters(stratPosterior3)[1, ]
  pars[["gap_2_1"]] <- -1
  expect_error(Tops(stratPosterior3, refHeights = -2.0, parameters = pars),
               "cannot be negative")
  pars[["gap_2_1"]] <- 0
  expect_no_error(Tops(stratPosterior3, refHeights = -2.0, parameters = pars))
})

test_that(".CalculateRefHeightToHeights rejects a multi-row data.frame (#1721)",
          {
            ind <- stratModel3[["ind"]]
            pars <- as.data.frame(ExtractParameters(stratPosterior3)[1:2, ])
            expect_error(
              .CalculateRefHeightToHeights(stratData3, ind, pars, 2, 0),
              "one-row data.frame; got 2 rows"
            )
            expect_equal(
              .CalculateRefHeightToHeights(stratData3, ind, pars[1, ], 2, 0),
              .CalculateRefHeightToHeights(stratData3, ind, unlist(pars[1, ]),
                                           2, 0)
            )
          })

test_that("a missing alphaPosition errors in both engines (#1722)", {
  d <- .EnsurePreExtracted(stratData3)
  ind <- .CreateIndices(d, "age", "partition", "middle")
  ind[["alphaPosition"]][[2]] <- NaN
  pars <- rep(0.5, length(ind[["names"]]))
  expect_error(.AgeConversionStratData(d, ind, pars),
               "`alphaPosition` of site 2 is missing")
  expect_error(.sb_age_convert(d, ind, pars),
               "`alphaPosition` of site 2 is missing")
  expect_error(.sb_age_convert_batch(d, ind, matrix(pars, 1), 0, 2L),
               "`alphaPosition` of site 2 is missing")
})

test_that("a negative sedRatesDF entry is a miss in both engines (#1722)", {
  d <- .EnsurePreExtracted(stratData3)
  ind <- .CreateIndices(d, "age", "partition", "middle")
  set.seed(1722)
  pars <- rnorm(length(ind[["names"]]))
  site <- which(d[[c("partsAttr", "nBound")]] > 1)[[1]]
  miss <- d
  miss[[c("partsAttr", "sedRatesDF")]][1, site] <- 0L
  negative <- d
  negative[[c("partsAttr", "sedRatesDF")]][1, site] <- -1L
  adjusted <- .AdjustParams(pars, ind)
  expect_identical(
    .GetSedRates(negative, ind, adjusted, "age", "partition", site),
    .GetSedRates(miss, ind, adjusted, "age", "partition", site)
  )
  expect_equal(.AgeConversionStratData(negative, ind, pars),
               .sb_age_convert(negative, ind, pars), tolerance = 1e-10)
})

test_that(".GetSedRates never applies a zeta to height-scale site 1 (#1836)", {
  set.seed(0)
  td <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  d <- .EnsurePreExtracted(
    StratData(td[["signal"]], parts = td[["parts"]],
              signalColumn = c("a", "b"), zColumn = "Hight",
              siteColumn = "SIT")
  )
  ind <- .CreateIndices(d, "height", "site x partition", "bottom")
  # a fourth site's zeta: `zeta[s - 2]` at s = 1 would drop the first and
  # keep this one
  ind[["zeta"]] <- c(ind[["zeta"]], ind[["alpha"]][[1]])
  pars <- .AdjustParams(rep(0.5, length(ind[["names"]])), ind)
  perturbed <- pars
  perturbed[ind[["zeta"]]] <- 7
  expect_identical(
    .GetSedRates(d, ind, perturbed, "height", "site x partition", 1),
    .GetSedRates(d, ind, pars, "height", "site x partition", 1)
  )
})

test_that("a shared partition boundary round-trips exactly (#1835)", {
  d <- .EnsurePreExtracted(stratData2)
  site <- 2
  nBound <- d[[c("partsAttr", "nBound")]][[site]]
  bound <- d[[c("partsAttr", "Bound")]][seq_len(nBound - 1), site]
  shared <- bound[
    bound == d[[c("partsAttr", "BoundLow")]][-1, site][seq_len(nBound - 1)]
  ]
  expect_gt(length(shared), 0)
  set.seed(1835)
  for (scale in c("height", "age")) {
    ind <- .CreateIndices(d, scale, "site", "middle")
    for (i in 1:20) {
      pars <- rnorm(length(ind[["names"]]), sd = 2)
      pars[ind[["gap"]]] <- abs(pars[ind[["gap"]]])
      ages <- .CalculateNewAges(d, ind, pars, site, shared)
      expect_identical(
        .CalculateRefHeightToHeights(d, ind, pars, site, ages), shared
      )
    }
  }
})

test_that("Tops() sweeps a valid posterior's whole range without complaint", {
  expect_no_condition(Tops(stratPosterior3, refHeights = seq(-5, 0, by = 0.01)))
})
