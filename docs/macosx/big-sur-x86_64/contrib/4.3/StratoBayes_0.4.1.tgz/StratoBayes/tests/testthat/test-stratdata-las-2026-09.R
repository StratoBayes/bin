WriteLas <- function(dir, name, depthName = "DEPT", nullLine = TRUE,
                     grVals = c(50, 60, -9999, 70)) {
  depth <- seq(100, by = 0.5, length.out = length(grVals))
  lines <- c(
    "~Version Information",
    "VERS.                      2.0: CWLS Log ASCII Standard - VERSION 2.0",
    "WRAP.                       NO: One line per depth step",
    "~Well Information Block",
    "STRT.M               100.0000: ",
    "STOP.M               101.5000: ",
    "STEP.M                 0.5000: ",
    if (nullLine) "NULL.                -999.2500: ",
    "WELL.          TEST: WELL",
    "~Curve Information Block",
    paste0(depthName, ".M                    : Depth"),
    "GR.GAPI                       : Gamma Ray",
    paste("~A", depthName, "GR"),
    sprintf("%.4f %.4f", depth, grVals)
  )
  writeLines(lines, file.path(dir, paste0(name, ".las")))
}

test_that("StratData() accepts a DEPT-only LAS folder for zColumn (#850)", {
  skip_if_not_installed("SDAR")
  dir <- withr::local_tempdir()
  WriteLas(dir, "a")
  WriteLas(dir, "b")
  sd <- suppressMessages(
    StratData(signal = dir, zColumn = "Depth", signalColumn = "GR", zScale = "depth")
  )
  expect_s3_class(sd, "StratData")
})

test_that("ReadLasFiles() reports a guessed NULL sentinel (#851)", {
  skip_if_not_installed("SDAR")
  dir <- withr::local_tempdir()
  WriteLas(dir, "a", nullLine = FALSE)
  expect_message(ReadLasFiles(dir), "guessed sentinel")
})

test_that("summary.StratData() tolerates a site lacking one signal (#853)", {
  df <- data.frame(
    site = rep(c("a", "b", "c"), each = 3),
    z = rep(1:3, 3),
    s1 = c(1, 2, 3, 4, 5, 6, 7, 8, 9),
    s2 = c(1, 2, 3, NA, NA, NA, 7, 8, 9)
  )
  sd <- StratData(signal = df, signalColumn = c("s1", "s2"),
                  siteColumn = "site", zColumn = "z")
  expect_no_error(out <- capture.output(summary(sd)))
  expect_true(any(grepl("Signal top: .*NA", out)))
})

test_that("maxPointsPerSite = -Inf errors rather than disabling (#855)", {
  df <- data.frame(site = rep(c("a", "b"), each = 5), z = rep(1:5, 2),
                   s = rnorm(10))
  expect_error(
    StratData(signal = df, signalColumn = "s", siteColumn = "site",
              zColumn = "z", maxPointsPerSite = -Inf),
    "maxPointsPerSite"
  )
})

test_that("ReadLasFiles() rejects a header one name short (#2317)", {
  skip_if_not_installed("SDAR")
  dir <- withr::local_tempdir()
  lines <- c(
    "~Version Information",
    "VERS.                      2.0: CWLS Log ASCII Standard - VERSION 2.0",
    "WRAP.                       NO: One line per depth step",
    "~Well Information Block",
    "STRT.M               100.0000: ",
    "STOP.M               101.0000: ",
    "STEP.M                 0.5000: ",
    "NULL.                -999.2500: ",
    "~Curve Information Block",
    "DEPT.M                    : Depth",
    "GR.GAPI                   : Gamma Ray",
    "RHOB.G/C3                 : density",
    "~A DEPT GR",
    "100.0 50 2.1", "100.5 60 2.2", "101.0 70 2.3"
  )
  writeLines(lines, file.path(dir, "w.las"))
  expect_error(ReadLasFiles(dir, quiet = FALSE), "column counts differ")
})

test_that("StratData() warns about a site with no data (#2318)", {
  df <- data.frame(
    site = rep(c("a", "b", "c"), each = 3),
    z = rep(1:3, 3),
    s = c(1, 2, 3, 4, 5, 6, NA, NA, NA)
  )
  expect_warning(
    StratData(signal = df, signalColumn = "s", siteColumn = "site",
              zColumn = "z"),
    "no non-NA signal values and no ties.*c"
  )
})
