test_that("a large-valued signal does not lock lambda at its cap (#2274)", {
  skip_on_cran()
  # Count-scale data. A trapped chain sits ~14 decades above lambdaStar with
  # sigma absorbing the signal; an honest one within ~1.5 decades.
  scale <- 1e5
  signal <- signalData1
  signal$value <- signal$value * scale
  data <- suppressMessages(StratData(signal = signal))
  model <- suppressWarnings(suppressMessages(StratModel(
    stratData = data, priors = stratPrior1, alignmentScale = "height",
    sedModel = "site", alphaPosition = "bottom", nKnots = 15,
    overlapPenalty = TRUE, sigmaFixed = FALSE
  )))
  star <- .LambdaStar(model$splineBase, data$signalAttr$signalValuesVec[[1]])
  for (seed in 1:3) {
    mcmc <- suppressMessages(
      StratMCMC(model, nIter = 3000, nChains = 1, nThin = 10)
    )
    posterior <- suppressWarnings(suppressMessages(RunStratModel(
      stratObject = data, stratModel = model, stratMCMC = mcmc, nRun = 1,
      runParallel = FALSE, visualise = FALSE, seed = seed, nThreads = 1L
    )))
    samples <- posterior$samples[, , 1, 1]
    kept <- samples[seq(nrow(samples) %/% 2, nrow(samples)), ]
    expect_lt(median(kept[, "lambda_value"]) / star, 1e4)
    expect_lt(median(kept[, "sigma_value"]) / scale, 0.3)
  }
})

test_that(".UpdateLambda survives beta'D beta rounding below zero (#2275)", {
  # Dense rounding perturbs D by O(eps * |D|), which a large near-linear beta
  # magnifies past zero; a slightly indefinite D models that deterministically.
  knots <- seq(0, 8, length.out = 25)
  D <- .bsplinepen(knots) - 1e-12 * diag(27)
  greville <- vapply(seq_len(27), function(j) {
    mean(c(rep(0, 3), knots, rep(8, 3))[(j + 1):(j + 3)])
  }, numeric(1))
  beta <- 1e6 * greville
  expect_lt(sum(.MatrixVectorMult(D, beta) * beta), -2e-3)
  set.seed(2275)
  lambda <- replicate(20, .UpdateLambda(
    beta = beta, D = D, aLambda = 1, bLambda = 1000, numBasis = 27,
    lambdaMin = 0
  ))
  expect_true(all(is.finite(lambda) & lambda > 0))
})

test_that(".sb_gibbs draws a finite lambda for near-linear beta (#2275)", {
  # beta's conditional mean is betaLin, in null(D). Rounding makes the dense
  # beta'D beta of order eps * |beta|^2 * |D| with either sign; the -1e-15 * I
  # perturbation fixes the sign on every platform while M stays positive
  # definite.
  set.seed(2275)
  p <- 12L
  n <- 60L
  A <- matrix(stats::rnorm(n * p), n, p)
  H <- crossprod(A) * 1e-6
  betaLin <- 1e10 * seq_len(p)
  args <- list(
    H_list = list(H), tBy_list = list(as.numeric(H %*% betaLin)),
    B_list = list(A), signalValuesVec = list(as.numeric(A %*% betaLin)),
    sigma_in = 1, lambda_in = 1e8,
    D_mat = crossprod(diff(diag(p), differences = 2L)) - 1e-15 * diag(p),
    Q_fallback = list(diag(p)), aLambda = 1, bLambda = 1, shapeSigma = 1,
    bSigma_prior = 1, numBasis = p, sigmaIsFixed = TRUE,
    sigmaFixedValues = 1, hasOffsets = FALSE, delta_list = list(),
    tau_in = numeric(0), obsToGroup_list = list(), nGroups = 0L,
    tauFixed = FALSE, tauFixedValue = 0, aTau = 1, bTau = 1,
    lambdaMin = 1e-16
  )
  for (seed in 1:5) {
    set.seed(seed)
    res <- do.call(.sb_gibbs, args)
    beta <- res[["beta"]][[1]]
    expect_lt(sum(.MatrixVectorMult(args$D_mat, beta) * beta), -2)
    expect_true(is.finite(res[["lambda"]][[1]]))
    expect_gte(res[["lambda"]][[1]], args$lambdaMin)
  }
})

test_that("BayesianSpline() survives a vast lambdaInitial (#2275)", {
  # Signal x 1e6 seeded ~8e8 times above lambdaStar, deep in the over-smoothed
  # regime where beta'D beta cancels below zero.
  set.seed(2275)
  x <- sort(stats::runif(200, 0, 8))
  y <- 1e6 * (sin(x) + stats::rnorm(200, 0, 0.2))
  for (seed in 1:5) {
    set.seed(seed)
    fit <- suppressWarnings(BayesianSpline(
      x, y, nKnots = 25, nIter = 1000, bSigma = 0.01, lambdaInitial = 1e-5,
      xMin = 0, xMax = 8
    ))
    expect_true(all(is.finite(fit$lambda)))
  }
})

test_that("fixed-knot .CreateSplineS names a zero-width range (#2268)", {
  local_mocked_bindings(.EnsurePreExtracted = function(data) data)
  constantRef <- list(
    sites = "ref",
    signalAttr = list(siteHeights = list(c(3, 3, 3)))
  )
  expect_error(
    .CreateSplineS(6L, NULL, FALSE, list(), list(alignmentScale = "height"),
                   constantRef),
    "every signal height at reference site 'ref' equals 3.*knotRange"
  )
  local_mocked_bindings(.MedianSignalAges = function(...) c(7, 7))
  expect_error(
    .CreateSplineS(6L, NULL, FALSE, list(), list(alignmentScale = "age"),
                   constantRef),
    "every signal age converted at the prior medians equals 7"
  )
  expect_error(
    .CreateSplineS(6L, c(5, 5), FALSE, list(), list(alignmentScale = "height"),
                   constantRef),
    "two distinct finite values, but is c\\(5, 5\\)"
  )
  expect_error(
    .CreateSplineS(6L, c(-Inf, 5), FALSE, list(),
                   list(alignmentScale = "height"), constantRef),
    "two distinct finite values"
  )
})

test_that(".sb_spline_design refuses non-finite x and knots (#2268)", {
  knots <- c(0, 0, 0, 0, 5, 10, 10, 10, 10)
  expect_equal(dim(.sb_spline_design(knots, c(1, 9), 4L)), c(2L, 5L))
  expect_error(.sb_spline_design(knots, c(1, NaN), 4L), "x\\[2\\] is")
  expect_error(.sb_spline_design(knots, NA_real_, 4L), "x\\[1\\] is")
  expect_error(.sb_spline_design(replace(knots, 5, NaN), 1, 4L),
               "knots\\[5\\] is")
  expect_error(.sb_spline_design(replace(knots, 9, Inf), 1, 4L),
               "knots\\[9\\] is")
})
