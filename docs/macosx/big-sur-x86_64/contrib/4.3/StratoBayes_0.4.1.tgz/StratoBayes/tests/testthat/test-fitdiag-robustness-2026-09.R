test_that("duplicate signals are collapsed, not double-counted", {
  once <- FitDiagnostics(stratPosterior2, signal = "a", maxSamples = 20L)
  twice <- FitDiagnostics(stratPosterior2, signal = c("a", "a"),
                          maxSamples = 20L)
  expect_equal(twice[["sites"]][["lpd"]], once[["sites"]][["lpd"]])
  expect_equal(twice[["signals"]][["lpd"]], once[["signals"]][["lpd"]])
  sigNames <- c("a", "b")
  expect_equal(.ValidateSignalSelection(c(1, 1), sigNames), "a")
  expect_equal(.ValidateSignalSelection(c(1, 1.5), sigNames), "a")
})

test_that("`signal = \"all\"` cannot be mixed with names", {
  sigNames <- c("a", "b")
  expect_error(.ValidateSignalSelection(c("all", "a"), sigNames),
               "cannot be combined")
  expect_error(.ValidateSignalSelection(c("a", "all"), sigNames),
               "cannot be combined")
  expect_equal(.ValidateSignalSelection(c("all", "all"), sigNames), sigNames)
})

test_that("a zero-sigma draw does not crash FitDiagnostics()", {
  sp <- stratPosterior3
  sp[["samples"]][seq(2, 201, 3), "sigma_value", 1, 1] <- 0
  fd <- FitDiagnostics(sp, maxSamples = 60L, burnIn = 0)
  expect_s3_class(fd, "FitDiagnostics")
  expect_true(all(is.finite(fd[["sites"]][["lpd"]])))
  expect_true(all(is.finite(fd[["sites"]][["scatter"]])))
})

test_that("a non-finite log density adds nothing to the lpd accumulator", {
  acc <- list(logDensityMax = rep(-Inf, 3), logDensitySum = rep(0, 3))
  acc <- .FitAccumulateDensity(acc, c(0, NaN, Inf), 0)
  expect_equal(acc[["logDensitySum"]], rep(0, 3))
  expect_equal(acc[["logDensityMax"]], rep(-Inf, 3))
})

test_that("the drift null is shared across signals and skipped for n < 3", {
  calls <- new.env()
  calls[["n"]] <- integer(0)
  local_mocked_bindings(
    .DriftNullDistribution = function(n, nNull = 9999L) {
      calls[["n"]] <- c(calls[["n"]], n)
      seq_len(9L) / 10
    }
  )
  FitDiagnostics(stratPosterior2, maxSamples = 10L, minSiteN = 2L)
  expect_false(anyDuplicated(calls[["n"]]) > 0L)

  cache <- new.env(parent = emptyenv())
  calls[["n"]] <- integer(0)
  expect_length(.CachedDriftNull(cache, 2L), 0L)
  expect_length(calls[["n"]], 0L)
  expect_length(ls(cache), 0L)
})
