RunQuiet <- function(...) {
  RunStratModel(
    ..., quiet = TRUE, visualise = FALSE, runParallel = FALSE, nThreads = 1L
  )
}

test_that("seed = TRUE seeds the model, ladder and StratMCMC build (#2126)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratPrior1, package = "StratoBayes", envir = environment())

  Run <- function(ambient) {
    set.seed(ambient)
    suppressWarnings(RunQuiet(
      stratData1, priors = stratPrior1, alignmentScale = "height",
      sedModel = "site", alphaPosition = "bottom", nKnots = 15,
      individualSplineIter = 200, nIter = 20, nChains = 2, seed = TRUE,
      adaptProposal = FALSE,
      modelDir = withr::local_tempdir(.local_envir = parent.frame()),
      modelName = "seedTrue"
    ))
  }
  one <- Run(1)
  two <- Run(2)

  expect_identical(
    one[[c("model", "sigmaFixed")]], two[[c("model", "sigmaFixed")]]
  )
  expect_identical(unname(one[["samples"]]), unname(two[["samples"]]))
})

test_that("a continuation with no saved stream does not replay seed (#2126)", {
  withr::local_preserve_seed()
  StreamAfter <- function(...) {
    StratoBayes:::.SeedRun(...)
    .Random.seed
  }
  Seeded <- function(s) {
    set.seed(s)
    .Random.seed
  }
  continued <- StreamAfter(c(3, 4), 2L, NULL, 50)

  expect_identical(StreamAfter(c(3, 4), 2L, NULL, 0), Seeded(4))
  expect_false(identical(continued, Seeded(4)))
  expect_identical(continued, StreamAfter(c(3, 4), 2L, NULL, 50))
  expect_false(identical(continued, StreamAfter(c(3, 4), 2L, NULL, 51)))
  # Run 1's continuation must not start on another run's raw seed.
  for (s in 1:3) {
    expect_false(identical(StreamAfter(1:3, 1L, NULL, 1), Seeded(s)))
  }

  # A saved stream is resumed whatever the new segment does.
  saved <- Seeded(3)
  runif(1)
  expect_identical(StreamAfter(c(3, 4), 2L, saved, 50), saved)

  before <- Seeded(9)
  StratoBayes:::.SeedRun(FALSE, 1L, NULL, 50)
  expect_identical(.Random.seed, before)
})

test_that("an adapting seeded run can be continued (#2126)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  first <- suppressWarnings(RunQuiet(
    stratData1, stratModel = stratModel1, nIter = 20, seed = 5,
    modelDir = withr::local_tempdir(), modelName = "adapting"
  ))
  checkpoint <- readRDS(
    file.path(first[["modelDir"]], "adapting_mcmc_run_1.rds")
  )
  expect_null(checkpoint[["rngState"]])

  second <- suppressWarnings(RunStratModel(
    first, nIter = 10, seed = 5, quiet = TRUE, visualise = FALSE,
    runParallel = FALSE, nThreads = 1L
  ))
  expect_s3_class(second, "StratPosterior")
})

test_that("the NA stop, tau and live plot read the cold chain (#2127)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  original <- StratoBayes:::.FirstNaDraw

  NaWarnings <- function(naChain, engine) {
    testthat::local_mocked_bindings(
      .FirstNaDraw = function(mat, coldChain, colNames) {
        mat[mat[, 2L] == naChain, 3L] <- NA
        original(mat, coldChain, colNames)
      }
    )
    warned <- testthat::capture_warnings(RunQuiet(
      stratData1, stratModel = stratModel1, nIter = 20, nChains = 2,
      saveChains = c(2, 1), seed = 1, engine = engine,
      modelDir = withr::local_tempdir(), modelName = "cold"
    ))
    any(grepl("NA/NaN draw", warned, fixed = TRUE))
  }

  for (engine in c("cpp", "R")) {
    expect_true(NaWarnings(1, engine), label = engine)
    expect_false(NaWarnings(2, engine), label = engine)
  }
})

test_that("a continuation refuses a partly unreadable checkpoint (#2128)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  dir <- withr::local_tempdir()
  suppressWarnings(RunQuiet(
    stratData1, stratModel = stratModel1, nRun = 2, nIter = 20, seed = 1:2,
    engine = "cpp", modelDir = dir, modelName = "damaged"
  ))
  bad <- file.path(dir, "damaged_binarysamples_run_2.rds")
  expect_true(file.exists(bad))
  writeBin(as.raw(1:64), bad)

  expect_error(
    suppressWarnings(RunStratModel(
      nIter = 10, modelDir = dir, modelName = "damaged", quiet = TRUE,
      visualise = FALSE, runParallel = FALSE, nThreads = 1L
    )),
    "damaged_binarysamples_run_2.rds"
  )
  expect_true(file.exists(bad))
  expect_true(file.exists(file.path(dir, "damaged_binarysamples_run_1.rds")))
})

test_that("a continuation refuses a checkpoint holding an NA state (#2128)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())

  dir <- withr::local_tempdir()
  suppressWarnings(RunQuiet(
    stratData1, stratModel = stratModel1, nIter = 20, seed = 1,
    modelDir = dir, modelName = "naState"
  ))
  checkpointFile <- file.path(dir, "naState_mcmc_run_1.rds")
  checkpoint <- readRDS(checkpointFile)
  checkpoint[["recentState"]][[1]][[c("metro", "parameters")]][[1]] <- NaN
  saveRDS(checkpoint, checkpointFile)

  expect_error(
    suppressWarnings(RunStratModel(
      nIter = 10, modelDir = dir, modelName = "naState", quiet = TRUE,
      visualise = FALSE, runParallel = FALSE, nThreads = 1L
    )),
    "NA/NaN draw"
  )
})

test_that("a run stopped at an NA draw cannot be continued (#2128)", {
  skip_on_cran()
  data(stratData1, package = "StratoBayes", envir = environment())
  data(stratModel1, package = "StratoBayes", envir = environment())
  original <- StratoBayes:::.FirstNaDraw
  local_mocked_bindings(
    .FirstNaDraw = function(mat, coldChain, colNames) {
      mat[mat[, 2L] == 1, 3L] <- NA
      original(mat, coldChain, colNames)
    }
  )

  dir <- withr::local_tempdir()
  expect_warning(
    RunQuiet(
      stratData1, stratModel = stratModel1, nIter = 20, seed = 1,
      modelDir = dir, modelName = "naStop"
    ),
    "NA/NaN draw"
  )
  expect_error(
    suppressWarnings(RunStratModel(
      nIter = 10, modelDir = dir, modelName = "naStop", quiet = TRUE,
      visualise = FALSE, runParallel = FALSE, nThreads = 1L
    )),
    "stopped at an NA/NaN draw"
  )
})

test_that("a continuation warns on a changed offset prior (#2164)", {
  WithOffsets <- function(tauFixedValue) {
    model <- stratModel1
    model[["offsetConfig"]] <- list(
      active = TRUE, nGroups = 2L, groups = c("a", "b"),
      siteToGroup = c(s1 = 1L, s2 = 2L), tauFixed = TRUE,
      tauFixedValue = tauFixedValue, aTau = 1, bTau = 1
    )
    model
  }
  dir <- withr::local_tempdir()
  saveRDS(WithOffsets(1), file.path(dir, "m_model.rds"))

  expect_silent(
    StratoBayes:::.CheckModelAgainstStored(WithOffsets(1), dir, "m")
  )
  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(WithOffsets(2), dir, "m"),
    "offsetConfig"
  )
  sampled <- WithOffsets(NA_real_)
  sampled[[c("offsetConfig", "tauFixed")]] <- FALSE
  expect_warning(
    StratoBayes:::.CheckModelAgainstStored(sampled, dir, "m"),
    "offsetConfig"
  )

  # A model stored before offsets were recorded is unknown, not different.
  saveRDS(stratModel1, file.path(dir, "m_model.rds"))
  expect_silent(
    StratoBayes:::.CheckModelAgainstStored(WithOffsets(2), dir, "m")
  )
})
