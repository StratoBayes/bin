# #1730: a run interrupted before its first sample checkpoint has metadata but
# no `_binarysamples_run_*.rds`, so the binary fast path returns fewer runs
# than the continuation indexes.
test_that(paste0("continuing with a run's binary samples missing names the ",
                 "run (#1730)"), {
            skip_on_cran()

            data(stratData1, package = "StratoBayes", envir = environment())
            data(stratModel1, package = "StratoBayes", envir = environment())
            td <- withr::local_tempdir()

            suppressWarnings(RunStratModel(
              stratObject = stratData1, stratModel = stratModel1,
              nIter = 20, nChains = 1, nRun = 2, seed = 1:2, quiet = TRUE,
              visualise = FALSE, runParallel = FALSE, nThreads = 1L,
              modelDir = td, modelName = "gap"
            ))
            expect_true(file.exists(file.path(td,
                                              "gap_binarysamples_run_1.rds")))
            unlink(file.path(td, "gap_binarysamples_run_2.rds"))

            expect_error(
              RunStratModel(modelDir = td, modelName = "gap", nIter = 10,
                            quiet = TRUE,
                            visualise = FALSE, nThreads = 1L),
              "samples were found for 1\\..*_binarysamples_run_\\*\\.rds: 1\n"
            )
          })
