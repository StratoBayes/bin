# #2228: sedLambda's density terms all sit in the prior component, so a rung
# that tempers the prior must draw sedLambda from its conditional raised to
# 1/T -- itself a Gamma -- rather than from the untempered conjugate.
#
# Whatever beta the step leaves, lambda * rate_T(beta) ~ Gamma(shape_T, 1), so
# the first two moments of that pivot over many probes test the law directly.

.SedLambdaEngine <- function(mask = NULL) {
  data(stratData1, package = "StratoBayes", envir = environment())
  sModel <- StratModel(stratData1,
                       priors = AutoPrior(stratData1, "height",
                                          sedModel = "site, partition"),
                       alignmentScale = "height", sedModel = "site, partition",
                       sedSmooth = TRUE, flexibleKnots = FALSE,
                       knotRange = c(-5, 12))
  td <- withr::local_tempdir("sedlambda", .local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "sedlambda"
  ))
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  mcmc <- readRDS(file.path(td, "sedlambda_mcmc_run_1.rds"))
  if (!is.null(mask)) mcmc$temper$mask <- mask
  engine <- StratoBayes:::.sb_create_engine(
    data = result$data, model = model, mcmc = mcmc,
    state = mcmc$recentState, tiesCallback = NULL
  )
  list(engine = engine, info = model$sedSmoothInfo)
}

# `nDraw` sedLambda draws for formation 1, each scaled by the rate of the
# law it is drawn from at temperature `temperature` given the beta it was
# drawn with.
.SedLambdaPivot <- function(fx, temperature, nDraw) {
  info <- fx$info
  aSed <- if (is.null(info$aSedLambda)) 1 else info$aSedLambda
  bSed <- if (is.null(info$bSedLambda)) 1000 else info$bSedLambda
  D <- info$formations[[1]]$D
  cols <- info$betaStart[[1]] - 1L + seq_len(info$nBasis)
  vapply(seq_len(nDraw), function(i) {
    invisible(StratoBayes:::.sb_run_block(fx$engine, 1L))
    StratoBayes:::.sb_sed_smooth_gibbs_probe(fx$engine, 1L, i)
    gibbs <- StratoBayes:::.sb_extract_state(fx$engine)[[1]]$gibbs
    beta <- gibbs$sedBeta[cols]
    rate <- 1 / bSed + 0.5 * drop(crossprod(beta, D %*% beta))
    gibbs$sedLambda[[1]] * rate / temperature
  }, double(1))
}

.SedLambdaShape <- function(info, temperature) {
  aSed <- if (is.null(info$aSedLambda)) 1 else info$aSedLambda
  (aSed - 1 + (info$nBasis - 2) / 2) / temperature + 1
}

.ExpectGammaMoments <- function(u, shape) {
  n <- length(u)
  # Gamma(shape, 1): mean and variance are both `shape`; var(var-hat) is
  # approximately (mu4 - shape^2) / n with mu4 = 3 shape^2 + 6 shape.
  expect_lt(abs(mean(u) - shape), 5 * sqrt(shape / n))
  expect_lt(abs(var(u) - shape), 5 * sqrt((2 * shape^2 + 6 * shape) / n))
}

test_that("a prior-tempering hot rung draws sedLambda tempered (#2228)", {
  skip_on_cran()
  fx <- .SedLambdaEngine()
  temperature <- 5
  StratoBayes:::.sb_update_temperatures(fx$engine, temperature)
  u <- .SedLambdaPivot(fx, temperature, 1500)
  shapeT <- .SedLambdaShape(fx$info, temperature)
  .ExpectGammaMoments(u, shapeT)
})

test_that("sedLambda keeps the untempered draw where the prior is held (#2228)", {
  skip_on_cran()
  temperature <- 5
  held <- .SedLambdaEngine(mask = 2L)   # signal only: prior held at T = 1
  StratoBayes:::.sb_update_temperatures(held$engine, temperature)
  .ExpectGammaMoments(.SedLambdaPivot(held, 1, 1500),
                      .SedLambdaShape(held$info, 1))

  cold <- .SedLambdaEngine()
  .ExpectGammaMoments(.SedLambdaPivot(cold, 1, 1500),
                      .SedLambdaShape(cold$info, 1))
})

# #1153: a base-R call from an implementation frame can raise an R error, and
# unwinding one out of a large C++ frame aborts on aarch64-Linux. Coercions
# happen in the exported wrappers; nothing in an impl looks up an R function
# by name. x86-64 cannot tell the difference at run time, so this is static.

.CppBody <- function(text, open) {
  chars <- strsplit(substring(text, open), "", fixed = TRUE)[[1]]
  depth <- cumsum((chars == "{") - (chars == "}"))
  substring(text, open, open + which(depth == 0)[1] - 1L)
}

.ImplFrames <- function(file) {
  text <- paste(readLines(file, warn = FALSE), collapse = "\n")
  text <- gsub("//[^\n]*", "", text)
  defs <- gregexpr(
    "\\bstatic\\b[^;{}]*?\\b([A-Za-z_]\\w*_impl|do_call_r)\\s*\\([^{;]*\\{",
    text, perl = TRUE
  )[[1]]
  bodies <- if (defs[[1]] < 0) character(0) else {
    vapply(defs + attr(defs, "match.length") - 1L,
           function(open) .CppBody(text, open), character(1))
  }
  # The engine's constructor runs inside `new MCMCEngine()` in the impl.
  ctor <- regmatches(text, regexpr("MCMCEngine\\([^)]*\\)\\s*:[^{]*", text))
  list(bodies = bodies, ctor = ctor)
}

test_that("no impl frame looks up or calls base R by name (#1153)", {
  srcDir <- testthat::test_path("..", "..", "src")
  skip_if_not(dir.exists(srcDir), "src/ not found")
  scanned <- lapply(
    file.path(srcDir, c("MCMCEngine.cpp", "LogPost.cpp", "AgeConvert.cpp")),
    .ImplFrames
  )
  frames <- unlist(lapply(scanned, `[[`, "bodies"))
  ctor <- unlist(lapply(scanned, `[[`, "ctor"))
  expect_gt(length(frames), 10L)
  expect_length(ctor, 1L)
  # `as<Function>(x)` converts an object the wrapper has already checked; a
  # name lookup is `Function f("name")`.
  expect_false(any(grepl('Function\\s*\\w*\\s*\\(\\s*"', frames, perl = TRUE)))
  expect_false(any(grepl("sb_ties_as_matrices\\s*\\(", frames)))
  # A member initialised from a name, e.g. `callback("identity")`.
  expect_false(grepl('\\(\\s*"', ctor, perl = TRUE))

  # A custom prior's density is user code: its result is read without
  # throwing (#1144), whichever door calls it.
  logPost <- readLines(file.path(srcDir, "LogPost.cpp"), warn = FALSE)
  calls <- grep("\\bsb_do_call\\s*\\(", logPost)
  expect_length(calls, 1L)
  expect_match(logPost[calls], "RObject\\s+res\\s*=\\s*sb_do_call\\(")
  expect_match(logPost[calls + 1L], "sb_callback_ok\\(res")
})

.TiesEngineFixture <- function() {
  set.seed(1)
  h1 <- seq(0, 10, length.out = 60L)
  h2 <- seq(0, 6, length.out = 40L)
  signal <- rbind(
    data.frame(site = "s1", height = h1, value = sin(h1) + rnorm(60, 0, 0.1)),
    data.frame(site = "s2", height = h2, value = sin(h2 + 1) + rnorm(40, 0, 0.1))
  )
  ties <- data.frame(height = c(3, 2), site = c("s1", "s2"),
                     densityFun = c("dnorm", "dnorm"),
                     arg1 = c(2, 2), arg2 = c(3, 3))
  stratData <- StratData(signal = signal, ties = ties, siteColumn = "site",
                         zColumn = "height", signalColumn = "value")
  priors <- structure(
    list(alpha_s2 = UniformPrior(min = -5, max = 5),
         gammaLog_s2 = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list")
  )
  stratModel <- StratModel(stratData, priors, alignmentScale = "height",
                           sedModel = "site", alphaPosition = "middle",
                           nKnots = 6, sigmaFixed = 1, flexibleKnots = FALSE,
                           knotRange = c(-15, 25))
  td <- withr::local_tempdir("tiesengine", .local_envir = parent.frame())
  result <- suppressWarnings(RunStratModel(
    stratObject = stratData, stratModel = stratModel,
    nIter = 10, nChains = 1L, seed = 1, nThreads = 1L,
    quiet = TRUE, visualise = FALSE, modelDir = td, modelName = "ties"
  ))
  model <- result$model
  if (is.null(model$.logpost_cpp))
    model$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model)
  if (is.null(model$.tiesDispatch))
    model$.tiesDispatch <- StratoBayes:::.BuildTiesDispatch(result$data, model)
  mcmc <- readRDS(file.path(td, "ties_mcmc_run_1.rds"))
  list(data = result$data, model = model, mcmc = mcmc)
}

.FixtureEngine <- function(fx, data = fx$data, model = fx$model) {
  StratoBayes:::.sb_create_engine(
    data = data, model = model, mcmc = fx$mcmc,
    state = fx$mcmc$recentState,
    tiesCallback = StratoBayes:::.MakeTiesCallback(data, model)
  )
}

test_that("data.frame tie tables score as their matrices do (#1153)", {
  skip_on_cran()
  fx <- .TiesEngineFixture()
  fields <- c("tiesH", "densityFun", "arg1", "arg2")
  # StratData() stores them as data frames, so this is the ordinary path.
  framed <- fx$data
  expect_true(all(vapply(framed$tiesAttr[fields], is.data.frame, logical(1))))
  matrixed <- framed
  for (field in fields) {
    matrixed$tiesAttr[[field]] <- as.matrix(matrixed$tiesAttr[[field]])
  }

  params <- fx$mcmc$recentState[[1]]$metro$parameters
  asMatrix <- StratoBayes:::.sb_eval_logpost(.FixtureEngine(fx, matrixed), 1L,
                                             params)
  asFrame <- StratoBayes:::.sb_eval_logpost(.FixtureEngine(fx, framed), 1L,
                                            params)
  expect_true(is.finite(asMatrix))
  expect_identical(asFrame, asMatrix)

  converted <- StratoBayes:::.sb_age_convert(framed, fx$model$ind, params)
  expect_identical(
    converted,
    StratoBayes:::.sb_age_convert(matrixed, fx$model$ind, params)
  )
  expect_length(converted$ties, fx$data$S)
  # Coercing for the impl must not write back into the caller's object.
  expect_true(all(vapply(framed$tiesAttr[fields], is.data.frame, logical(1))))

  unreadable <- framed
  unreadable$tiesAttr$tiesH <- as.data.frame(
    matrix(c("a", "b"), 1L), stringsAsFactors = FALSE
  )
  expect_error(.FixtureEngine(fx, unreadable), "tiesH must be numeric")
  expect_error(
    StratoBayes:::.sb_age_convert(unreadable, fx$model$ind, params),
    "tiesH must be numeric"
  )

  noParts <- framed
  noParts$tiesAttr$tiesPartsB <- NULL
  expect_error(.FixtureEngine(fx, noParts), "has no `tiesPartsB`", fixed = TRUE)
  expect_error(
    StratoBayes:::.sb_age_convert(noParts, fx$model$ind, params),
    "has no `tiesPartsB`", fixed = TRUE
  )
})

# #2160 item 2: the engine wrapper checked only each prior's type, so a typed
# prior whose arguments were edited after StratModel() threw from as<double>()
# inside sb_create_engine_impl.
test_that(".sb_create_engine validates typed prior arguments (#2160)", {
  skip_on_cran()
  fx <- .TiesEngineFixture()
  lp <- fx$model$.logpost_cpp
  normal <- which(lp$priorTypes == "NormalPrior")[[1]]

  mutated <- fx$model
  mutated$.logpost_cpp$priorArgs[[normal]]$sd <- "1"
  expect_error(
    .FixtureEngine(fx, model = mutated),
    paste0("priorArgs[[", normal, "]]$sd must be a single number"),
    fixed = TRUE
  )

  fixedArgless <- fx$model
  fixedArgless$.logpost_cpp$priorTypes[[normal]] <- "Fixed"
  fixedArgless$.logpost_cpp$priorArgs[[normal]] <- list()
  expect_error(.FixtureEngine(fx, model = fixedArgless),
               "is classed `Fixed` but has no `value` argument", fixed = TRUE)

  atomic <- fx$model
  atomic$.logpost_cpp$priorArgs[[normal]] <-
    unlist(lp$priorArgs[[normal]])
  params <- fx$mcmc$recentState[[1]]$metro$parameters
  expect_identical(
    StratoBayes:::.sb_eval_logpost(.FixtureEngine(fx, model = atomic), 1L,
                                   params),
    StratoBayes:::.sb_eval_logpost(.FixtureEngine(fx), 1L, params)
  )
  expect_false(is.list(atomic$.logpost_cpp$priorArgs[[normal]]))

  untyped <- fx$model
  untyped$.logpost_cpp$priorTypes <- factor(lp$priorTypes)
  expect_error(.FixtureEngine(fx, model = untyped),
               "priorTypes must be a character vector")

  short <- fx$model
  short$.logpost_cpp$priorArgs <- lp$priorArgs[-length(lp$priorArgs)]
  expect_error(.FixtureEngine(fx, model = short), "priorArgs has")

  expect_silent(.FixtureEngine(fx))
})
