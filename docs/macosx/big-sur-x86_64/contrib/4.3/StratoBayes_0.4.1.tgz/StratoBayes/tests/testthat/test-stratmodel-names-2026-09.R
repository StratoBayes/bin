.NamesModel <- function(...) {
  StratModel(stratData = stratData2, priors = stratPrior2,
             alignmentScale = "age", sedModel = "site", nKnots = 5, ...)
}

.PenaltyList <- function(a, b) {
  list(a = rep(a, 3), b = rep(b, 3))
}

test_that("named alphaPosition is read by site name (#2199)", {
  ordered <- .NamesModel(alphaPosition = c(site1 = "top", site2 = "middle",
                                           site3 = "bottom"))
  shuffled <- .NamesModel(alphaPosition = c(site3 = "bottom", site1 = "top",
                                            site2 = "middle"))
  expect_equal(attr(shuffled$priors$metro, "alphaPosition"),
               attr(ordered$priors$metro, "alphaPosition"))
})

test_that("named alphaPosition on the height scale may omit site 1 (#2199)", {
  args <- list(stratData = stratData2, alignmentScale = "height",
               sedModel = "site", nKnots = 5, overlapPenalty = FALSE)
  full <- do.call(StratModel, c(args, list(
    alphaPosition = c(site2 = "top", site3 = "bottom"))))
  swapped <- do.call(StratModel, c(args, list(
    alphaPosition = c(site3 = "bottom", site2 = "top"))))
  expect_equal(attr(swapped$priors$metro, "alphaPosition"),
               attr(full$priors$metro, "alphaPosition"))
  expect_error(
    do.call(StratModel, c(args, list(
      alphaPosition = c(site2 = "top", nope = "bottom")))),
    "alphaPosition.*names")
})

test_that("bad alphaPosition names error (#2199)", {
  expect_error(.NamesModel(alphaPosition = c(site1 = "top", site2 = "middle",
                                             nope = "bottom")),
               "alphaPosition.*names")
  expect_error(.NamesModel(alphaPosition = c(site1 = "top", site1 = "middle",
                                             site3 = "bottom")),
               "alphaPosition.*names")
  expect_error(.NamesModel(alphaPosition = c(site1 = "top", "middle",
                                             site3 = "bottom")),
               "partly named")
})

test_that("list overlapPenalty is read by signal name (#2199)", {
  pen <- .PenaltyList(-1, -2)
  ordered <- .NamesModel(overlapPenalty = pen)
  shuffled <- .NamesModel(overlapPenalty = pen[c("b", "a")])
  expect_equal(shuffled$overlapPenalty$adjustments,
               ordered$overlapPenalty$adjustments)
  expect_error(.NamesModel(overlapPenalty = list(a = rep(-1, 3),
                                                 z = rep(-2, 3))),
               "overlapPenalty.*names")
})

test_that("non-finite nKnots and Gibbs hyperparameters error (#2200)", {
  expect_error(.NamesModel(nKnots = Inf), "nKnots")
  expect_error(.MatchGibbsPriors(stratData2, Inf, 1, 1, 1), "aLambda")
  expect_error(.MatchGibbsPriors(stratData2, 1, 1, 1, Inf), "bSigma")
})

test_that("overlapPenalty list entries are validated (#2200)", {
  expect_error(.NamesModel(overlapPenalty = list(a = c("5", "5", "5"),
                                                 b = rep(-1, 3))),
               "Invalid `overlapPenalty`")
  expect_error(.NamesModel(overlapPenalty = list(a = rep(TRUE, 3),
                                                 b = rep(-1, 3))),
               "Invalid `overlapPenalty`")
  expect_error(.NamesModel(overlapPenalty = list(a = c(-1, Inf, -1),
                                                 b = rep(-1, 3))),
               "Invalid `overlapPenalty`")
  expect_error(.NamesModel(overlapPenalty = list(a = c(-1, NA, -1),
                                                 b = rep(-1, 3))),
               "Invalid `overlapPenalty`")
  expect_error(.NamesModel(overlapPenalty = list(a = rep(-1, 3),
                                                 b = c(-1, NA, -1))),
               "Invalid `overlapPenalty`")
})

test_that("list alphaPosition entries must have length one (#2200)", {
  expect_error(
    .NamesModel(alphaPosition = list("top", c("top", "bottom"), "middle")),
    "alphaPosition\\[2\\].*single")
})

test_that("logical overlapPenalty must be a single non-NA value (#869)", {
  expect_error(.NamesModel(overlapPenalty = c(TRUE, FALSE)), "overlapPenalty")
  expect_error(.NamesModel(overlapPenalty = c(FALSE, TRUE)), "overlapPenalty")
  expect_error(.NamesModel(overlapPenalty = NA), "overlapPenalty")
})

test_that("unnamed extra penalty arguments error (#1391)", {
  myPen <- function(...) list(rep(0, 3), rep(0, 3))
  expect_error(.NamesModel(overlapPenalty = list(myPen, 5)),
               "must be named")
})

test_that("sedModel of length > 1 gets a tailored message (#870)", {
  expect_error(.MatchSedModel(c("site", "partition")), "sedModel.*single")
})

test_that("names on a custom penalty function's output stay positional", {
  myPen <- function(...) list(x = rep(-1, 3), y = rep(-2, 3))
  expect_no_error(.NamesModel(overlapPenalty = list(myPen)))
})
