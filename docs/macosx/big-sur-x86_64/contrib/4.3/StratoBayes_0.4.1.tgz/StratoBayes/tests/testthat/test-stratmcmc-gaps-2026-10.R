# StratMCMC(): infinite-nIter docs and print (#2272), silently ignored
# arguments, and a late engine refusal (#2273), and an
# unbounded adaptProposalWindow (#2277).

data(stratModel1, package = "StratoBayes", envir = environment())

# ── #2272: print at nIter = Inf ──────────────────────────────────────────────

test_that("#2272: print at the default nIter = Inf does not claim Inf iterations", {
  mcmc <- StratMCMC(stratModel1, nThreads = 1L)
  out <- paste(capture.output(print(mcmc)), collapse = "\n")
  expect_false(grepl("Inf iterations", out, fixed = TRUE))
  expect_match(out, "until a stopping rule fires \\(schedules planned to ")
  expect_match(out, paste0("iteration ", mcmc[["horizon"]], ")"), fixed = TRUE)
  expect_true(is.finite(mcmc[["horizon"]]))
})

test_that("#2272: print of a finite run is unchanged", {
  mcmc <- StratMCMC(stratModel1, nIter = 100, nChains = 2, nThreads = 1L)
  out <- paste(capture.output(print(mcmc)), collapse = "\n")
  expect_match(out, "with 2 chains \\(1 stored\\) of 100 iterations \\(")
})

# ── #2273 item 1: ignored arguments warn ─────────────────────────────────────

test_that("#2273: a partial tempering mask warns when nothing is tempered", {
  for (components in c("signal", "ties", "signal+ties")) {
    expect_warning(
      StratMCMC(stratModel1, nIter = 100, nChains = 1,
                temperingComponents = components, nThreads = 1L),
      "temperingComponents.*single chain",
      label = components
    )
    expect_warning(
      StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = FALSE,
                temperingComponents = components, nThreads = 1L),
      "temperingComponents.*tempering = FALSE",
      label = components
    )
  }
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 1, nThreads = 1L)
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = FALSE,
              nThreads = 1L)
  )
})

test_that("#2273: explicit adaptTemperatures warns with tempering = FALSE", {
  expect_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 8, tempering = FALSE,
              adaptTemperatures = TRUE, nThreads = 1L),
    "adaptTemperatures = TRUE.*tempering = FALSE"
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 8, tempering = FALSE,
              nThreads = 1L)
  )
})

test_that("#2273: the single-chain warning names the argument the user typed", {
  expect_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 1, adapt = TRUE,
              nThreads = 1L),
    "`adapt = TRUE` has no effect with a single chain"
  )
  expect_warning(
    StratMCMC(stratModel1, nIter = 100, nChains = 1,
              adaptTemperatures = TRUE, nThreads = 1L),
    "`adaptTemperatures = TRUE` has no effect with a single chain"
  )
})

test_that("#2273: adaptation settings warn when adaptation is off", {
  args <- list(
    startAdapting = 10,
    endAdapting = 500,
    adaptProposalWindow = 50,
    adaptProposalInterval = 20,
    onlyMultivariateProposalsAfterAdapt = TRUE
  )
  for (nm in names(args)) {
    for (off in c("adapt", "adaptProposal")) {
      call <- c(list(stratModel1, nIter = 1000, nChains = 2, nThreads = 1L),
                stats::setNames(list(FALSE), off), args[nm])
      expect_warning(
        do.call(StratMCMC, call),
        paste0("`", nm, "` has no effect with `", off, " = FALSE`"),
        label = paste(nm, off)
      )
    }
  }
  expect_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 2, adapt = FALSE,
              endAdapting = 500, adaptProposalWindow = 50, nThreads = 1L),
    "`endAdapting`, `adaptProposalWindow` have no effect"
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 1000, nChains = 2, adapt = FALSE,
              nThreads = 1L)
  )
})

# ── #2273 item 3: ties + gradient refused before any engine is built ────────

test_that("#2273: partial tempering of ties with NUTS errors in StratMCMC()", {
  for (components in c("ties", "signal+ties")) {
    expect_error(
      suppressWarnings(
        StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = TRUE,
                  temperingComponents = components, gradientProposals = "on",
                  nThreads = 1L)
      ),
      "MH-only",
      label = components
    )
  }
  expect_no_error(suppressWarnings(
    StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = TRUE,
              temperingComponents = "signal", gradientProposals = "on",
              nThreads = 1L)
  ))
  expect_no_error(suppressWarnings(
    StratMCMC(stratModel1, nIter = 100, nChains = 4, tempering = TRUE,
              temperingComponents = "ties", gradientProposals = "off",
              nThreads = 1L)
  ))
})

# ── #2277: oversized adaptProposalWindow ─────────────────────────────────────

test_that("#2277: an adaptProposalWindow whose clustering cost explodes warns", {
  expect_warning(
    StratMCMC(stratModel1, nIter = 100000, nChains = 2,
              adaptProposalWindow = 20000, nThreads = 1L),
    "adaptProposalWindow.*20000"
  )
  expect_no_warning(
    StratMCMC(stratModel1, nIter = 100000, nChains = 2,
              adaptProposalWindow = 400, nThreads = 1L)
  )
})
