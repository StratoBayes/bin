# Tests for .ClustInfo — MCMC adaptation helper
# Filed as part of T-076 (sample() single-element trap fix)

test_that(".ClustInfo returns valid covariance matrices for well-separated clusters", {
  set.seed(8174)
  dat <- rbind(
    matrix(rnorm(200, mean = 0), ncol = 2),
    matrix(rnorm(200, mean = 10), ncol = 2)
  )
  clusters <- rep(1:2, each = 100)

  result <- .ClustInfo(dat, clusters)

  expect_length(result, 2)
  # Each element should have a mean vector and a PD covariance matrix

  for (i in seq_along(result)) {
    expect_length(result[[i]][[1]], 2)
    expect_true(.IsPositiveDefinite(result[[i]][[2]]))
    expect_false(any(is.na(result[[i]][[2]])))
  }
})

test_that(".ClustInfo replaces NA covariance with valid one (single-element sample fix)", {
  # Create data where cluster 2 has collinear points → NA covariance
  set.seed(3921)
  dat <- rbind(
    matrix(rnorm(200), ncol = 2),                # cluster 1: 100 points, valid cov
    cbind(1:3, 1:3)                                # cluster 2: 3 collinear points → singular
  )
  clusters <- c(rep(1L, 100), rep(2L, 3))

  result <- .ClustInfo(dat, clusters)

  expect_length(result, 2)
  # Both covariance matrices must be non-NA after replacement
  for (i in seq_along(result)) {
    expect_false(any(is.na(result[[i]][[2]])),
                 info = paste("Cluster", i, "covariance contains NA"))
  }
})

test_that(".ClustInfo replaces non-PD covariance matrices", {
  set.seed(5628)
  dat <- rbind(
    matrix(rnorm(200), ncol = 2),
    # 4 points nearly collinear — cov may be non-PD after regularization
    cbind(c(0, 0, 0, 0.001), c(0, 1, 2, 3))
  )
  clusters <- c(rep(1L, 100), rep(2L, 4))

  result <- .ClustInfo(dat, clusters)
  expect_length(result, 2)

  # Both should now have PD matrices (cluster 2's replaced if non-PD)
  for (i in seq_along(result)) {
    expect_true(.IsPositiveDefinite(result[[i]][[2]]) ||
                  !any(is.na(result[[i]][[2]])),
                info = paste("Cluster", i, "covariance invalid"))
  }
})

test_that(".ClustInfo returns NULL when no clusters have >= 3 members", {
  dat <- matrix(rnorm(10), ncol = 2)
  # All in separate clusters (each has 1 member)
  clusters <- 1:5

  result <- .ClustInfo(dat, clusters)
  expect_null(result)
})

test_that(".ClustInfo excludes cluster 0 (outliers) when other clusters exist", {
  set.seed(7143)
  dat <- rbind(
    matrix(rnorm(200), ncol = 2),
    matrix(rnorm(20, mean = 100), ncol = 2)  # outliers
  )
  clusters <- c(rep(1L, 100), rep(0L, 10))

  result <- .ClustInfo(dat, clusters)

  # Should have 1 cluster (cluster 0 excluded because cluster 1 exists)
  expect_length(result, 1)
})

test_that(".ClustInfo uses cluster 0 when it's the only cluster with >= 3 members", {
  set.seed(2054)
  dat <- matrix(rnorm(60), ncol = 2)
  clusters <- c(rep(0L, 30))

  result <- .ClustInfo(dat, clusters)

  # Cluster 0 should be used as the only option
  expect_length(result, 1)
  expect_false(any(is.na(result[[1]][[2]])))
})
