# Tests for HMC leapfrog proposal (Phase B)
#
# Verifies:
#   1. Leapfrog integrator preserves Hamiltonian (energy conservation)
#   2. .sb_gradient_at() matches .sb_compute_gradient() at current params
#   3. .sb_sync_gibbs() correctly updates engine chain state
#   4. Full HMC proposal runs within MCMC without error
#   5. HMC proposals produce non-degenerate acceptance across datasets

# ── Helper: set up engine + state for HMC testing ───────────────────────────

setup_hmc_engine <- function(sData, sModel, knotRange) {
  if (sModel$flexibleKnots) {
    sModel <- StratoBayes::StratModel(
      stratData = sData,
      priors = sModel$priors$metro,
      alignmentScale = sModel$alignmentScale,
      sedModel = sModel$sedModel,
      flexibleKnots = FALSE,
      knotRange = knotRange
    )
  }
  td <- file.path(tempdir(), paste0("hmc_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)

  set.seed(6418)
  result <- RunStratModel(
    stratObject = sData, stratModel = sModel,
    nIter = 10, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "htest", engine = "R"
  )

  data_obj <- result$data
  model_obj <- result$model
  mcmc_obj <- readRDS(file.path(td, "htest_mcmc_run_1.rds"))
  state <- mcmc_obj$recentState[[1]]

  if (is.null(model_obj$.logpost_cpp))
    model_obj$.logpost_cpp <- StratoBayes:::.PrepareLogPostArgs(model_obj)

  engine <- StratoBayes:::.HMCCreateEngine(data_obj, model_obj, state)

  list(
    engine = engine,
    data_obj = data_obj,
    model_obj = model_obj,
    mcmc_obj = mcmc_obj,
    state = state,
    td = td
  )
}


# ── Test: .sb_gradient_at matches .sb_compute_gradient at current params ─────

test_that(".sb_gradient_at returns same gradient as .sb_compute_gradient", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  params <- setup$state$metro$parameters

  # .sb_gradient_at (the new export)
  result_at <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)
  expect_true(result_at$ok)

  # .sb_compute_gradient (the existing test export)
  tiesCallback <- if ("ties" %in% names(setup$data_obj)) {
    function(parameters) {
      ageResult <- StratoBayes:::.sb_age_convert(
        setup$data_obj, setup$model_obj$ind, parameters, FALSE)
      tmpState <- list(age = list(ties = ageResult$ties))
      StratoBayes:::.LogLikTies(setup$data_obj, setup$model_obj, tmpState)
    }
  }
  test_engine <- StratoBayes:::.sb_create_engine(
    data = setup$data_obj, model = setup$model_obj,
    mcmc = setup$mcmc_obj, state = setup$mcmc_obj$recentState,
    tiesCallback = tiesCallback
  )
  result_cg <- StratoBayes:::.sb_compute_gradient(test_engine, 1L)

  expect_equal(result_at$grad, result_cg$grad, tolerance = 1e-10)
  expect_equal(result_at$logPost, result_cg$logPost, tolerance = 1e-10)
})


# ── Test: leapfrog energy conservation ──────────────────────────────────────

test_that("leapfrog approximately conserves Hamiltonian", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  freeIdx <- setup$model_obj$ind$paramNotFixed
  nFree <- setup$model_obj$parametersLengthNotFixed
  params <- setup$state$metro$parameters
  q <- params[freeIdx]

  # Initial gradient
  gradResult <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)
  expect_true(gradResult$ok)

  # Use small step size for good energy conservation
  massMatInv <- rep(1.0, nFree)
  set.seed(3847)
  p <- rnorm(nFree)
  K_old <- 0.5 * sum(p^2 * massMatInv)
  H_old <- -gradResult$logPost + K_old

  gradFn <- function(full_params)
    StratoBayes:::.sb_gradient_at(setup$engine, 1L, full_params)

  result <- StratoBayes:::.HMCLeapfrog(
    q = q, p = p, grad = gradResult$grad,
    stepSize = 0.001, nSteps = 20L,
    massMatInv = massMatInv, gradFn = gradFn,
    freeIdx = freeIdx, fullParams = params,
    temperature = 1.0
  )

  expect_false(result$divergent)

  # Compute final Hamiltonian
  K_new <- 0.5 * sum(result$p^2 * massMatInv)
  H_new <- -result$logPost + K_new

  # Small step size × short trajectory → energy should be well conserved
  delta_H <- abs(H_new - H_old)
  expect_true(
    delta_H < 1.0,
    info = sprintf("Hamiltonian change = %.4f (should be small)", delta_H)
  )
})


# ── Test: .sb_sync_gibbs updates engine state ───────────────────────────────

test_that(".sb_sync_gibbs correctly updates Gibbs state", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  setup <- setup_hmc_engine(stratData1, stratModel1, c(-5, 12))
  on.exit(unlink(setup$td, recursive = TRUE))

  params <- setup$state$metro$parameters

  # Gradient at original Gibbs state
  grad_before <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)

  # Modify Gibbs state: double all betas
  new_beta <- lapply(setup$state$gibbs$beta, function(b) b * 2)
  new_sigma <- setup$state$gibbs$sigma * 1.5
  new_lambda <- vapply(
    seq_along(setup$state$gibbs$lambda),
    function(m) setup$state$gibbs$lambda[[m]] * 0.5,
    numeric(1)
  )

  StratoBayes:::.sb_sync_gibbs(
    setup$engine, 1L, new_beta, new_sigma, new_lambda)

  # Gradient at modified Gibbs state (same params)
  grad_after <- StratoBayes:::.sb_gradient_at(setup$engine, 1L, params)

  # Gradient should change because the likelihood depends on beta/sigma
  expect_true(grad_after$ok)
  expect_false(isTRUE(all.equal(grad_before$grad, grad_after$grad)),
    info = "Gradient should differ after Gibbs state change")
})


# ── Test: full MCMC with HMC runs without error ────────────────────────────

test_that("RunStratModel with HMC proposal runs without error", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), "hmc_mcmc_test")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(9241)
  result <- expect_no_error(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 100, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_full",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  # Check HMC was registered
  mcmc <- readRDS(file.path(td, "hmc_full_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))
  gradProp <- intersect(c("HMC", "NUTS"), colnames(mcmc$metro$proposalValid))
  expect_true(mcmc$metro$proposalValid[1, gradProp])
})


# ── Test: HMC on age-scale model with ties ──────────────────────────────────

test_that("HMC runs on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- file.path(tempdir(), "hmc_data2")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(3072)
  expect_no_error(RunStratModel(
    stratObject = stratData2, stratModel = sModel,
    nIter = 100, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_d2",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ══════════════════════════════════════════════════════════════════════════════
# Phase C: C++ engine HMC tests
# ══════════════════════════════════════════════════════════════════════════════

# ── Test: C++ engine HMC runs without error (stratData1) ─────────────────────

test_that("C++ engine HMC runs without error (stratData1)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d1"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(5183)
  result <- expect_no_error(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp1",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  # Verify HMC was registered
  mcmc <- readRDS(file.path(td, "hmc_cpp1_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))

  # Verify result has reasonable logPost trajectory (not stuck at one value)
  rds_file <- file.path(td, "hmc_cpp1_binarysamples_run_1.rds")
  tsv_file <- file.path(td, "hmc_cpp1_samples_run_1.txt")
  if (file.exists(rds_file)) {
    samples <- as.data.frame(readRDS(rds_file))
  } else {
    samples <- read.delim(tsv_file, sep = "\t")
  }
  logPost <- samples$posterior
  expect_true(sd(logPost) > 0,
    info = "logPost should vary across samples (not stuck)")
})


# ── Test: C++ engine HMC runs on age-scale model with ties (stratData2) ──────

test_that("C++ engine HMC runs on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d2"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(7642)
  expect_no_error(RunStratModel(
    stratObject = stratData2, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ── Test: C++ engine HMC runs on partition model (stratData3) ─────────────────

test_that("C++ engine HMC runs on partition model (stratData3)", {
  skip_on_cran()

  data(stratData3, package = "StratoBayes")
  data(stratModel3, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData3,
    priors = stratModel3$priors$metro,
    alignmentScale = stratModel3$alignmentScale,
    sedModel = stratModel3$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 20)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_d3"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(2917)
  expect_no_error(RunStratModel(
    stratObject = stratData3, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_cpp3",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))
})


# ── Test: C++ HMC produces HMC-specific acceptances (not all-accept no-op) ───

test_that("C++ engine HMC produces genuine HMC proposals", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_cpp_genuine"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4619)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_gen",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Check that HMC proposals appear in the sample data
  rds_file <- file.path(td, "hmc_gen_binarysamples_run_1.rds")
  tsv_file <- file.path(td, "hmc_gen_samples_run_1.txt")
  if (file.exists(rds_file)) {
    samples <- as.data.frame(readRDS(rds_file))
  } else {
    samples <- read.delim(tsv_file, sep = "\t")
  }
  mcmc <- readRDS(file.path(td, "hmc_gen_mcmc_run_1.rds"))

  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  expect_length(hmcIdx, 1)

  # Gradient-based proposals should be present
  hmc_proposals <- samples$proposal_number == hmcIdx
  expect_true(sum(hmc_proposals) > 0,
    info = "At least some HMC proposals should appear in the sample")

  # Not all HMC proposals should be accepted (that would indicate the
  # Phase B no-op bug where proposed == current)
  if (sum(hmc_proposals) >= 5) {
    hmc_accepts <- samples$proposal_accepted[hmc_proposals]
    expect_true(any(hmc_accepts == 0) || any(hmc_accepts == 1),
      info = "HMC should have both accepted and rejected proposals")
  }
})


# ══════════════════════════════════════════════════════════════════════════════
# Phase D: Dual averaging step size adaptation tests
# ══════════════════════════════════════════════════════════════════════════════

# ── Test: .sb_hmc_get_adapted() returns dual averaging state ──────────────────

test_that(".sb_hmc_get_adapted returns DA state from C++ engine", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_state"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(6731)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Verify HMC was registered and final step size was adapted

  mcmc <- readRDS(file.path(td, "hmc_da_mcmc_run_1.rds"))
  expect_true(any(c("HMC", "NUTS") %in% names(mcmc$propose)))

  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- mcmc$metro$proposalArgs[[1]][[hmcIdx]]

  # After adaptation ends, adaptStepSize should be FALSE
  expect_false(hmcArgs[["adaptStepSize"]])

  # stepSize should have changed from the initial default
  nFree <- sModel$parametersLengthNotFixed
  initialEps <- 0.1 / nFree^0.25
  expect_false(
    isTRUE(all.equal(hmcArgs[["stepSize"]], initialEps, tolerance = 0.01)),
    info = "Step size should differ from initial heuristic after DA"
  )
})


# ── Test: Dual averaging adapts step size toward target acceptance ─────────────

test_that("Dual averaging produces adapted step size (C++ engine)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_adapt"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  # Run with enough iterations for DA to converge
  set.seed(8294)
  result <- RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 500, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  )

  # Check adapted step size is finite and positive (finite-temperature chains only)
  mcmc <- readRDS(file.path(td, "hmc_da2_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  finiteChains <- which(is.finite(mcmc$temper$temperatures))
  for (ch in finiteChains) {
    eps <- mcmc$metro$proposalArgs[[ch]][[hmcIdx]][["stepSize"]]
    expect_true(is.finite(eps) && eps > 0,
      info = sprintf("Chain %d: adapted step size should be finite and positive", ch))
  }
})


# ── Test: R-engine dual averaging ───────────────────────────────────────────

test_that("R-engine HMC with dual averaging runs without error", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), "hmc_da_r")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(4518)
  result <- expect_no_error(RunStratModel(
    stratObject = stratData1, stratModel = sModel,
    nIter = 200, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da_r",
    engine = "R",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  mcmc <- readRDS(file.path(td, "hmc_da_r_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  hmcArgs <- mcmc$metro$proposalArgs[[1]][[hmcIdx]]

  # Step size should be finite and positive after adaptation
  expect_true(is.finite(hmcArgs[["stepSize"]]) && hmcArgs[["stepSize"]] > 0)
  # Adaptation should be turned off after warmup
  expect_false(hmcArgs[["adaptStepSize"]])
})


# ── Test: DA with age-scale model + ties ──────────────────────────────────────

test_that("Dual averaging works on age-scale model with ties (stratData2)", {
  skip_on_cran()

  data(stratData2, package = "StratoBayes")
  data(stratModel2, package = "StratoBayes")
  sModel <- StratoBayes::StratModel(
    stratData = stratData2,
    priors = stratModel2$priors$metro,
    alignmentScale = stratModel2$alignmentScale,
    sedModel = stratModel2$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(0, 100)
  )

  td <- normalizePath(file.path(tempdir(), "hmc_da_d2"), mustWork = FALSE)
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  set.seed(3159)
  expect_no_error(RunStratModel(
    stratObject = stratData2, stratModel = sModel,
    nIter = 300, nChains = 2, seed = 1,
    quiet = TRUE, visualise = FALSE,
    modelDir = td, modelName = "hmc_da_d2",
    engine = "cpp",
    onlyMultivariateProposalsAfterAdapt = FALSE
  ))

  mcmc <- readRDS(file.path(td, "hmc_da_d2_mcmc_run_1.rds"))
  hmcIdx <- which(names(mcmc$propose) %in% c("HMC", "NUTS"))
  eps <- mcmc$metro$proposalArgs[[1]][[hmcIdx]][["stepSize"]]
  expect_true(is.finite(eps) && eps > 0)
})
