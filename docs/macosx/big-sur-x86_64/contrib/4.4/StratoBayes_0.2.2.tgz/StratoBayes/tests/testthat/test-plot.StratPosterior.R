
test_that("plot.StratPosterior throws errors", {
  expect_error(plot(stratPosterior1, alignment = 2),
               "`alignment`.* must consist of whole numbers between 1 and 1")

  expect_error(plot(stratPosterior1, iterations = 15000),
               "No iterations")

  expect_error(plot(stratPosterior1, sites = 4),
               "`sites` may contain")
})

test_that("plot.StratPosterior works - 1", {
  skip_if_not_snapshot_os()

  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 1", function() {
    parOri <- par()
    par(col = "darkgreen", bg = rgb(0.9, 0.8, 0.8, 1), cex = 0.8, lwd = 3,
        mfrow = c(2, 2))
    plot(stratPosterior1, overridePar = FALSE)
    plot(stratPosterior1, separateSites = FALSE, overridePar = FALSE)
    par(parOri[c("col", "bg", "cex", "lwd", "mfrow")])
  })})

test_that("plot.StratPosterior works - 3", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 3", function() {
    plot(stratPosterior2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 4", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 4", function() {
    plot(stratPosterior2, signal = 1:2, alignment = 2,
         colourScale = "Viridis")
  })})

test_that("plot.StratPosterior works - 5", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 5", function() {
    plot(stratPosterior2, signal = 2,
         colourBy =  "partition", col = 1:4)
  })})


test_that("plot.StratPosterior works - 6", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 6", function() {
    plot(stratPosterior2, iterations = 25:125, signal = 1:2)
  })
})

test_that("plot.StratPosterior works with depth data - 7", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior depth", function() {
    plot(stratPosterior3, type = "l", colourBy = "p")
  })
})

test_that("plot.StratPosterior works with custom parameters - 8", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior 8", function() {
    plot(stratPosterior3, type = "l", colourBy = "p",
         parameters = c(-1, 2, -1, 0))
  })
})

test_that("plot.StratPosterior works with multi alignments in one plot - 9", {
  skip_if_not_snapshot_os()
  set.seed(1)

  vdiffr::expect_doppelganger("plot posterior multi", function() {
    plot(stratPosterior2, type = "l", colourBy = "s", alignment = 1:2)
  })
})

test_that("plot.StratPosterior works with overridePar = FALSE", {
  skip_if_not_snapshot_os()
  vdiffr::expect_doppelganger("plot posterior override", function() {
    set.seed(1)
    par(mfrow = c(3, 1))
    plot(stratPosterior1, overridePar = FALSE)
  })
})

test_that(
  "plot.StratPosterior works with new cluster object and iterations before burnIn",
  {
    skip_if_not_snapshot_os()
    set.seed(0)
    clustNew <- Cluster(stratPosterior1, iterations = 100:200)
    vdiffr::expect_doppelganger("plot posterior clustNew", function() {
      plot(stratPosterior1, colourBy = "site",
           stratCluster = clustNew, type = "o")
    })
  }
)

test_that("plot.stratPosterior produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  expect_error({plot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
  unlink(tmpFile)
})

test_that("plot.StratPosterior fixed knots: spline uses model ext_knots (not tight range(ages))", {
  skip_on_cran()
  set.seed(1)

  data(stratData1, stratModel1, package = "StratoBayes")

  model_fix <- StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE,
    knotRange = c(-14, 32),
    nKnots = 8L
  )

  mc <- StratMCMC(
    stratModel = model_fix,
    nIter = 45L,
    nChains = 2L,
    nThin = 5L,
    tempering = FALSE,
    adapt = FALSE
  )

  td <- tempfile("strat_plot_")
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)

  post <- suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = model_fix,
      stratMCMC = mc,
      nRun = 1L,
      quiet = TRUE,
      visualise = FALSE,
      engine = "R",
      modelDir = td,
      modelName = "plot_fix_knot"
    )
  )
  expect_s3_class(post, "StratPosterior")

  pnames <- post$savedParameters
  metro1 <- as.numeric(post$samples[1, pnames, 1, 1])
  names(metro1) <- pnames

  ages <- StratoBayes:::.sb_age_convert(post$data, post$model$ind, metro1)[["signal"]]
  r_ages <- range(vapply(ages, range, numeric(2)))
  kr <- post$model$splineBase$knotRange
  expect_true(diff(kr) > diff(r_ages) * 1.05)

  sig <- 1L
  sn <- post$data$signalAttr$signalNames[sig]
  nb <- post$model$splineBase$num_basis
  betas <- paste0("beta_", sn, "_", seq_len(nb))
  expect_true(all(betas %in% pnames))
  b1 <- as.numeric(post$samples[1, betas, 1, 1])

  yPlot <- seq(r_ages[1], r_ages[2], length.out = 55)
  ext <- post$model$splineBase$ext_knots
  B_ok <- splines::splineDesign(ext, yPlot, sparse = FALSE)
  pred_ok <- as.numeric(StratoBayes:::.MatrixVectorMult(B_ok, b1))

  wrong <- StratoBayes:::.CreateSplineBaseBspline(
    post$data,
    post$model$splineBase$nKnots,
    r_ages[1],
    r_ages[2],
    NULL
  )
  B_bad <- splines::splineDesign(wrong$ext_knots, yPlot, sparse = FALSE)
  pred_bad <- as.numeric(StratoBayes:::.MatrixVectorMult(B_bad, b1))

  expect_gt(max(abs(pred_ok - pred_bad)), 1e-4)

  pl <- suppressMessages(
    suppressWarnings(
      plot(
        post,
        display = FALSE,
        burnIn = 0,
        maxSamples = 30L,
        alignment = 1L,
        signal = sig,
        separateSites = FALSE,
        overridePar = FALSE
      )
    )
  )
  expect_length(pl$spline$x, 300L)
  expect_length(pl$spline$y, 300L)
})
