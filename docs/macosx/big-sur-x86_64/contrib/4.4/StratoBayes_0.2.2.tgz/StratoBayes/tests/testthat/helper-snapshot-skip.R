# Snapshot baselines (vdiffr SVGs + text snapshots) were generated on Windows.
# Font metrics, graphics-device rendering, and BLAS-dependent numerical values
# cause drift on other platforms, so skip snapshot comparisons there.
skip_if_not_snapshot_os <- function() {
  testthat::skip_on_os(c("mac", "linux", "solaris"))
}
