test_that("print.StratData can print a stratData1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratData1))
})

test_that("print.StratData can print a stratData2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratData2))
})

test_that("print.StratModel can print stratModel1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratModel1))
})

test_that("print.StratModel can print stratModel2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratModel2))
})

test_that("print.StratPosterior can print stratPosterior1", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratPosterior1))
})

test_that("print.StratPosterior can print stratPosterior2", {
  skip_if_not_snapshot_os()
  expect_snapshot(print(stratPosterior2))
})
