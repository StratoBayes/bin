# Tests for cost-aware proposal weighting
#
# Verifies that .UpdateProposalProbAndFac() applies a time-cost penalty
# to expensive proposal types and that the ring buffer carries timing data.

test_that("cost-aware weighting downweights expensive proposals", {
  skip_on_cran()

  # Simulate metro structure with 2 proposal types on 1 chain:
  #   Proposal A: mean time 1e6 ns, Proposal B: mean time 100e6 ns (100x)
  nChains <- 1L
  nProp <- 2L
  propNames <- c("Multivariate", "NUTS")

  metro <- list(
    proposalProbability = matrix(0.5, nrow = nChains, ncol = nProp,
                                 dimnames = list("chain1", propNames)),
    proposalProbabilityWeights = matrix(1, nrow = nChains, ncol = nProp,
                                        dimnames = list("chain1", propNames)),
    proposalValid = matrix(TRUE, nrow = nChains, ncol = nProp,
                           dimnames = list("chain1", propNames)),
    proposalFactor = matrix(1, nrow = nChains, ncol = nProp,
                            dimnames = list("chain1", propNames)),
    proposalTimeNs = matrix(c(10e6, 1000e6), nrow = 1,
                            dimnames = list("chain1", propNames)),
    proposalTimeCount = matrix(c(10L, 10L), nrow = 1,
                               dimnames = list("chain1", propNames)),
    nProposals = setNames(nProp, "chain1"),
    acceptance = array(c(rep(0.7, 25), rep(0.7, 25)),
                       dim = c(1, 25, 2),
                       dimnames = list("chain1", NULL, propNames)),
    acceptanceLength = 25L,
    acceptanceIndex = matrix(1L, nrow = 1, ncol = 2,
                             dimnames = list("chain1", propNames)),
    onlyMultivariateProposalsAfterAdapt = FALSE,
    scaleMultivariateProposals = TRUE
  )

  mcmc <- list(
    metro = metro,
    propose = setNames(list(NULL, NULL), propNames),
    temper = list(temperatures = 1),
    currentIter = 100L,
    endAdapting = 200L
  )

  model <- list()

  result <- StratoBayes:::.UpdateProposalProbAndFac(model, mcmc,
                                                    inLateAdaptation = FALSE)

  probMV   <- result[["proposalProbability"]][1, "Multivariate"]
  probNUTS <- result[["proposalProbability"]][1, "NUTS"]

  # Multivariate should have higher probability than NUTS because it's cheaper
  expect_gt(probMV, probNUTS)

  # Both should still be > 0 (not completely killed)
  expect_gt(probNUTS, 0)

  # The ratio should reflect the sqrt penalty: 100x cost -> ~10x penalty
  ratio <- probMV / probNUTS
  expect_gt(ratio, 3)
})


test_that("cost-aware weighting is inactive with insufficient data", {
  skip_on_cran()

  nChains <- 1L
  nProp <- 2L
  propNames <- c("Multivariate", "NUTS")

  metro <- list(
    proposalProbability = matrix(0.5, nrow = nChains, ncol = nProp,
                                 dimnames = list("chain1", propNames)),
    proposalProbabilityWeights = matrix(1, nrow = nChains, ncol = nProp,
                                        dimnames = list("chain1", propNames)),
    proposalValid = matrix(TRUE, nrow = nChains, ncol = nProp,
                           dimnames = list("chain1", propNames)),
    proposalFactor = matrix(1, nrow = nChains, ncol = nProp,
                            dimnames = list("chain1", propNames)),
    # Only 3 observations -- below the threshold of 5
    proposalTimeNs = matrix(c(3e6, 300e6), nrow = 1,
                            dimnames = list("chain1", propNames)),
    proposalTimeCount = matrix(c(3L, 3L), nrow = 1,
                               dimnames = list("chain1", propNames)),
    nProposals = setNames(nProp, "chain1"),
    acceptance = array(c(rep(0.7, 25), rep(0.7, 25)),
                       dim = c(1, 25, 2),
                       dimnames = list("chain1", NULL, propNames)),
    acceptanceLength = 25L,
    acceptanceIndex = matrix(1L, nrow = 1, ncol = 2,
                             dimnames = list("chain1", propNames)),
    onlyMultivariateProposalsAfterAdapt = FALSE,
    scaleMultivariateProposals = TRUE
  )

  mcmc <- list(
    metro = metro,
    propose = setNames(list(NULL, NULL), propNames),
    temper = list(temperatures = 1),
    currentIter = 100L,
    endAdapting = 200L
  )

  model <- list()

  result <- StratoBayes:::.UpdateProposalProbAndFac(model, mcmc,
                                                    inLateAdaptation = FALSE)

  # With insufficient timing data, probabilities should remain equal
  probMV   <- result[["proposalProbability"]][1, "Multivariate"]
  probNUTS <- result[["proposalProbability"]][1, "NUTS"]
  expect_equal(probMV, probNUTS, tolerance = 0.01)
})


test_that("ring buffer includes elapsed timing (C++ engine)", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  td <- file.path(tempdir(), paste0("caw_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  post <- suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = stratModel1,
      nIter = 50, nChains = 2, seed = 4829,
      quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = "caw_test",
      engine = "cpp", nCores = 2L
    )
  )

  expect_s3_class(post, "StratPosterior")
})


test_that("cost-aware weighting applies during NUTS run", {
  skip_on_cran()

  data(stratData1, package = "StratoBayes")
  data(stratModel1, package = "StratoBayes")

  model <- StratoBayes::StratModel(
    stratData = stratData1,
    priors = stratModel1$priors$metro,
    alignmentScale = stratModel1$alignmentScale,
    sedModel = stratModel1$sedModel,
    flexibleKnots = FALSE, knotRange = c(-5, 12)
  )

  td <- file.path(tempdir(), paste0("caw_nuts_", format(Sys.time(), "%H%M%S%OS3")))
  dir.create(td, showWarnings = FALSE, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE))

  post <- suppressWarnings(
    RunStratModel(
      stratObject = stratData1,
      stratModel = model,
      nIter = 200, nChains = 2, seed = 7162,
      quiet = TRUE, visualise = FALSE,
      modelDir = td, modelName = "caw_nuts",
      engine = "cpp", nCores = 2L
    )
  )

  expect_s3_class(post, "StratPosterior")

  # Verify that NUTS proposals were actually attempted (acceptance monitor)
  mcmcRun <- readRDS(
    list.files(td, pattern = "_mcmc_run_", full.names = TRUE)[1]
  )
  nutsProp <- which(names(mcmcRun[["propose"]]) == "NUTS")
  expect_length(nutsProp, 1L)
})


test_that("legacy metro without timing accumulators gets defaults", {
  skip_on_cran()

  # Simulate a legacy metro structure (no proposalTimeNs/proposalTimeCount)
  nChains <- 1L
  nProp <- 2L
  propNames <- c("Prior", "Multivariate")

  metro <- list(
    proposalProbability = matrix(0.5, nrow = nChains, ncol = nProp,
                                 dimnames = list("chain1", propNames)),
    proposalProbabilityWeights = matrix(1, nrow = nChains, ncol = nProp,
                                        dimnames = list("chain1", propNames)),
    proposalValid = matrix(TRUE, nrow = nChains, ncol = nProp,
                           dimnames = list("chain1", propNames)),
    proposalFactor = matrix(1, nrow = nChains, ncol = nProp,
                            dimnames = list("chain1", propNames)),
    nProposals = setNames(nProp, "chain1"),
    acceptance = array(c(rep(0.5, 25), rep(0.5, 25)),
                       dim = c(1, 25, 2),
                       dimnames = list("chain1", NULL, propNames)),
    acceptanceLength = 25L,
    acceptanceIndex = matrix(1L, nrow = 1, ncol = 2,
                             dimnames = list("chain1", propNames)),
    onlyMultivariateProposalsAfterAdapt = FALSE,
    scaleMultivariateProposals = TRUE
  )

  mcmc <- list(
    metro = metro,
    propose = setNames(list(NULL, NULL), propNames),
    temper = list(temperatures = 1),
    currentIter = 100L,
    endAdapting = 200L
  )

  model <- list()

  # Should not error even without timing fields
  result <- expect_no_error(
    StratoBayes:::.UpdateProposalProbAndFac(model, mcmc,
                                            inLateAdaptation = FALSE)
  )
  expect_true(is.matrix(result[["proposalTimeNs"]]))
})
