# Additional tests in test-zzx-StratModel.R

test_that("StratModel() methods work", {
  skip_if_not_snapshot_os()
  expect_snapshot(summary(stratModel2))
  expect_snapshot(summary(stratModel3))
})
