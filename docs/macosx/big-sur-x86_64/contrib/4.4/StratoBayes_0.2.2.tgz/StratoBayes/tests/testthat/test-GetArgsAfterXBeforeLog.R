test_that(".GetArgsAfterXBeforeLog handles standard R density formals", {
  # Standard: x, param1, param2, ..., log
  args <- c("x", "mean", "sd", "log")
  result <- StratoBayes:::.GetArgsAfterXBeforeLog(args)
  expect_equal(result, c("mean", "sd"))
})

test_that(".GetArgsAfterXBeforeLog handles density without log param", {
  # Custom density with no 'log' formal

  args <- c("x", "shape", "rate")
  result <- StratoBayes:::.GetArgsAfterXBeforeLog(args)
  expect_equal(result, c("shape", "rate"))
})

test_that(".GetArgsAfterXBeforeLog handles x-only density", {
  args <- c("x")
  result <- StratoBayes:::.GetArgsAfterXBeforeLog(args)
  expect_length(result, 0)
})

test_that(".GetArgsAfterXBeforeLog handles x and log only", {
  args <- c("x", "log")
  result <- StratoBayes:::.GetArgsAfterXBeforeLog(args)
  expect_length(result, 0)
})
