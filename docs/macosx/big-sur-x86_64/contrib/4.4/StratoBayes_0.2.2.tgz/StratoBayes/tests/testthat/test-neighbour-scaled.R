test_that("NeighbourScaled proposal is registered and valid from start", {
  model <- stratModel1
  mcmc <- StratMCMC(stratModel = model, nIter = 100, nChains = 4)

  expect_true("NeighbourScaled" %in% names(mcmc$propose))

  ns_idx <- which(names(mcmc$propose) == "NeighbourScaled")
  expect_length(ns_idx, 1)


  # Valid for all chains from the start
  for (ch in seq_len(4)) {
    expect_true(mcmc$metro$proposalValid[ch, ns_idx])
  }

  # Fallback SDs should be positive
  fallback <- mcmc$metro$proposalArgs$chain1[[ns_idx]]
  expect_length(fallback, model$parametersLength)
  expect_true(all(fallback > 0))
})

test_that("NeighbourScaled proposal produces valid perturbations", {
  model <- stratModel1
  nParam <- model$parametersLength
  alphaIdx <- model$ind$alpha
  gammaIdx <- model$ind$gamma

  # Create fallback SDs (prior-range based)
  fallbackSD <- rep(0.5, nParam)

  # Starting parameters
  params <- c(10, 20, -0.5, 0.3)

  set.seed(8471)
  proposed <- .ProposeNeighbourScaled(
    n = 1, parameters = params, proposeArg = fallbackSD,
    proposalFactor = 1, dimFactor = 1, model = model
  )

  # Result should differ from input (with high probability)
  expect_length(proposed, nParam)
  expect_false(all(proposed == params))
})

test_that("NeighbourScaled SD scales with alpha spacing", {
  model <- stratModel1

  # Wide alpha spacing -> larger proposals
  params_wide <- c(0, 100, -0.5, 0.3)
  # Narrow alpha spacing -> smaller proposals
  params_narrow <- c(50, 51, -0.5, 0.3)

  fallbackSD <- rep(0.5, model$parametersLength)

  set.seed(3742)
  n <- 500
  diffs_wide <- numeric(n)
  diffs_narrow <- numeric(n)

  for (i in seq_len(n)) {
    proposed_wide <- .ProposeNeighbourScaled(
      n = 1, parameters = params_wide, proposeArg = fallbackSD,
      proposalFactor = 1, dimFactor = 1, model = model
    )
    proposed_narrow <- .ProposeNeighbourScaled(
      n = 1, parameters = params_narrow, proposeArg = fallbackSD,
      proposalFactor = 1, dimFactor = 1, model = model
    )
    # Average absolute alpha perturbation
    diffs_wide[i] <- mean(abs(proposed_wide[model$ind$alpha] -
                               params_wide[model$ind$alpha]))
    diffs_narrow[i] <- mean(abs(proposed_narrow[model$ind$alpha] -
                                 params_narrow[model$ind$alpha]))
  }

  # Wide spacing should produce larger perturbations on average
  expect_gt(mean(diffs_wide), mean(diffs_narrow) * 2)
})

test_that("NeighbourScaled works with single alpha/gamma", {
  # stratModel5a has only 1 alpha and 1 gamma
  model <- stratModel5a
  nParam <- model$parametersLength
  fallbackSD <- rep(0.5, nParam)
  params <- c(10, -0.5)

  set.seed(6129)
  proposed <- .ProposeNeighbourScaled(
    n = 1, parameters = params, proposeArg = fallbackSD,
    proposalFactor = 1, dimFactor = 1, model = model
  )

  expect_length(proposed, nParam)
  # With single alpha/gamma, should use fallback SD (no neighbour scaling)
})

test_that("NeighbourScaled integrates into full model run", {
  skip_on_cran()

  data <- stratData1
  model <- stratModel1
  mcmc <- StratMCMC(stratModel = model, nIter = 200, nChains = 4)

  post <- RunStratModel(data, model, mcmc, quiet = TRUE, nRun = 1)

  # Check that proposal 7 (NeighbourScaled) was used
  prop_nums <- post$samples[, "proposal_number", 1, 1]
  expect_true(7 %in% prop_nums)
})
