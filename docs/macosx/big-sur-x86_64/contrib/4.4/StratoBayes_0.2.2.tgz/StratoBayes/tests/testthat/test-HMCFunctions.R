# ── .NUTSUTurn: U-turn detection ─────────────────────────────────────────

test_that(".NUTSUTurn detects U-turn when trajectory doubles back", {
  # Momentum opposite to displacement => U-turn
  expect_true(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(-1, 0), r_plus = c(1, 0)
  ))
  expect_true(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(1, 0), r_plus = c(-1, 0)
  ))
})

test_that(".NUTSUTurn returns FALSE when trajectory is still expanding", {
  # Both momenta point in direction of displacement => no U-turn
  expect_false(.NUTSUTurn(
    q_minus = c(0, 0), q_plus = c(1, 0),
    r_minus = c(1, 0), r_plus = c(1, 0)
  ))
})

test_that(".NUTSUTurn handles 1D case", {
  expect_false(.NUTSUTurn(q_minus = 0, q_plus = 1, r_minus = 1, r_plus = 1))
  expect_true(.NUTSUTurn(q_minus = 0, q_plus = 1, r_minus = -1, r_plus = 1))
})

# ── .LogSumExp ──────────────────────────────────────────────────────────

test_that(".LogSumExp computes log(exp(a) + exp(b)) accurately", {
  expect_equal(.LogSumExp(0, 0), log(2))
  expect_equal(.LogSumExp(1, 2), log(exp(1) + exp(2)), tolerance = 1e-12)
  # log(1 + 1) = log(2)
  expect_equal(.LogSumExp(log(1), log(1)), log(2), tolerance = 1e-12)
})

test_that(".LogSumExp handles extreme values without overflow", {
  # large values: naive exp(1000) overflows, but LogSumExp should not
  result <- .LogSumExp(1000, 1000)
  expect_equal(result, 1000 + log(2), tolerance = 1e-12)
})

test_that(".LogSumExp handles -Inf", {
  expect_equal(.LogSumExp(-Inf, 0), 0)
  expect_equal(.LogSumExp(0, -Inf), 0)
  expect_equal(.LogSumExp(-Inf, -Inf), -Inf)
})

# ── .HMCLeapfrog: leapfrog integrator ──────────────────────────────────

test_that(".HMCLeapfrog preserves Hamiltonian for simple harmonic oscillator", {
  # q'' = -q (standard harmonic oscillator)
  # gradFn returns gradient of log-posterior = -q (since logpost = -0.5 q^2)
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }

  q0 <- 1.0
  p0 <- 0.0
  grad0 <- -q0

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 0.01, nSteps = 100,
    massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0
  )

  # Hamiltonian should be approximately conserved
  H0 <- 0.5 * q0^2 + 0.5 * p0^2
  H1 <- 0.5 * result$q^2 + 0.5 * result$p^2
  expect_equal(H0, H1, tolerance = 1e-4)
  expect_false(result$divergent)
})

test_that(".HMCLeapfrog flags divergence when gradient fails", {
  gradFn <- function(fullParams) {
    list(ok = FALSE, grad = NA, logPost = NA)
  }

  result <- .HMCLeapfrog(
    q = 1, p = 0, grad = -1,
    stepSize = 0.1, nSteps = 3,
    massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = 1,
    temperature = 1.0
  )

  expect_true(result$divergent)
  expect_equal(result$logPost, -Inf)
})

test_that(".HMCLeapfrog handles multi-dimensional case", {
  gradFn <- function(fullParams) {
    list(ok = TRUE, grad = -fullParams, logPost = -0.5 * sum(fullParams^2))
  }

  q0 <- c(1, 0.5)
  p0 <- c(0, 0)
  grad0 <- -q0

  result <- .HMCLeapfrog(
    q = q0, p = p0, grad = grad0,
    stepSize = 0.01, nSteps = 50,
    massMatInv = c(1, 1),
    gradFn = gradFn,
    freeIdx = 1:2, fullParams = q0,
    temperature = 1.0
  )

  expect_length(result$q, 2)
  expect_length(result$p, 2)
  expect_false(result$divergent)
})

# ── .HMCDefaultArgs ────────────────────────────────────────────────────

test_that(".HMCDefaultArgs creates valid default args", {
  mock_model <- list(parametersLengthNotFixed = 4L)
  args <- .HMCDefaultArgs(mock_model)

  expect_true(is.list(args))
  expect_true("massMatInv" %in% names(args))
  expect_true("stepSize" %in% names(args))
  expect_true("nSteps" %in% names(args))
  expect_true("adaptStepSize" %in% names(args))
  expect_true("targetAccept" %in% names(args))
  expect_true(".hmcDA" %in% names(args))

  expect_length(args$massMatInv, 4)
  expect_equal(args$massMatInv, rep(1.0, 4))
  expect_equal(args$nSteps, 10L)
  expect_true(args$adaptStepSize)
  expect_equal(args$targetAccept, 0.65)
})

test_that(".HMCDefaultArgs scales stepSize with dimension", {
  args2 <- .HMCDefaultArgs(list(parametersLengthNotFixed = 2L))
  args100 <- .HMCDefaultArgs(list(parametersLengthNotFixed = 100L))
  # Larger dimension => smaller initial step size
  expect_true(args2$stepSize > args100$stepSize)
})

test_that(".HMCDefaultArgs dual averaging env has correct initial state", {
  args <- .HMCDefaultArgs(list(parametersLengthNotFixed = 4L))
  da <- args[[".hmcDA"]]
  expect_true(is.environment(da))
  expect_equal(da$daCounter, 0L)
  expect_equal(da$Hbar, 0)
  expect_equal(da$stepSize, args$stepSize)
})

# ── .HMCRestartDualAvg ─────────────────────────────────────────────────

test_that(".HMCRestartDualAvg resets counters", {
  mock_args <- list(
    stepSize = 0.1,
    .hmcDA = new.env(parent = emptyenv())
  )
  da <- mock_args[[".hmcDA"]]
  da$mu <- 5
  da$logEpsBar <- 2
  da$Hbar <- 10
  da$daCounter <- 100L
  da$stepSize <- 0.1

  .HMCRestartDualAvg(mock_args)

  expect_equal(da$daCounter, 0L)
  expect_equal(da$Hbar, 0)
  expect_equal(da$stepSize, 0.1)
  expect_equal(da$mu, log(10 * 0.1))
  expect_equal(da$logEpsBar, log(0.1))
})

test_that(".HMCRestartDualAvg handles NULL .hmcDA gracefully", {
  expect_silent(.HMCRestartDualAvg(list(stepSize = 0.1, .hmcDA = NULL)))
})

# ── .NUTSBuildTree depth-0 (base case) ──────────────────────────────────

test_that(".NUTSBuildTree depth-0 takes one leapfrog step", {
  gradFn <- function(fullParams) {
    q <- fullParams[1]
    list(ok = TRUE, grad = -q, logPost = -0.5 * q^2)
  }

  q0 <- 1.0
  r0 <- 0.5
  grad0 <- -q0
  logPost0 <- -0.5 * q0^2
  H0 <- -logPost0 + 0.5 * r0^2

  result <- .NUTSBuildTree(
    q = q0, r = r0, grad = grad0, logPost = logPost0,
    direction = 1L, depth = 0L,
    stepSize = 0.1, massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = q0,
    temperature = 1.0,
    H0 = H0, divergenceMax = 1000
  )

  expect_equal(result$nLeapfrog, 1L)
  expect_false(result$divergent)
  expect_true(result$valid)
  # q should have moved from initial position
  expect_true(result$q_candidate != q0)
})

test_that(".NUTSBuildTree depth-0 flags divergence on bad gradient", {
  gradFn <- function(fullParams) list(ok = FALSE, grad = NA, logPost = NA)

  result <- .NUTSBuildTree(
    q = 1.0, r = 0.5, grad = -1.0, logPost = -0.5,
    direction = 1L, depth = 0L,
    stepSize = 0.1, massMatInv = 1.0,
    gradFn = gradFn,
    freeIdx = 1, fullParams = 1.0,
    temperature = 1.0,
    H0 = 1.0, divergenceMax = 1000
  )

  expect_true(result$divergent)
  expect_false(result$valid)
  expect_equal(result$sumLogWeight, -Inf)
})
