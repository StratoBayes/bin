# Tests for C++ age conversion (.sb_age_convert) equivalence with R version.
# For each dataset × sedModel × alignmentScale combination, assert that
# the C++ output matches the R output within tolerance on random parameter
# vectors.

tol <- 1e-10

# Compare R and C++ results, handling NAs
compare_results <- function(r_result, cpp_result, label) {

  # Signal
  for (s in seq_along(r_result[["signal"]])) {
    r_v <- r_result[["signal"]][[s]]
    c_v <- cpp_result[["signal"]][[s]]
    r_na <- is.na(r_v)
    c_na <- is.na(c_v)
    expect_identical(r_na, c_na,
      label = paste(label, "signal site", s, "NA pattern"))
    non_na <- !r_na
    if (any(non_na)) {
      expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
        label = paste(label, "signal site", s))
    }
  }

  # Ties
  if ("ties" %in% names(r_result)) {
    for (s in seq_along(r_result[["ties"]])) {
      r_v <- r_result[["ties"]][[s]]
      c_v <- cpp_result[["ties"]][[s]]
      r_na <- is.na(r_v)
      c_na <- is.na(c_v)
      expect_identical(r_na, c_na,
        label = paste(label, "ties site", s, "NA pattern"))
      non_na <- !r_na
      if (any(non_na)) {
        expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
          label = paste(label, "ties site", s))
      }
    }
  }

  # Alphas
  if ("alphas" %in% names(r_result)) {
    for (s in seq_along(r_result[["alphas"]])) {
      r_a <- r_result[["alphas"]][[s]]
      c_a <- cpp_result[["alphas"]][[s]]
      if (!is.null(r_a) && !is.null(c_a)) {
        r_v <- as.numeric(r_a)
        c_v <- as.numeric(c_a)
        r_na <- is.na(r_v)
        c_na <- is.na(c_v)
        expect_identical(r_na, c_na,
          label = paste(label, "alphas site", s, "NA pattern"))
        non_na <- !r_na
        if (any(non_na)) {
          expect_equal(r_v[non_na], c_v[non_na], tolerance = tol,
            label = paste(label, "alphas site", s))
        }
      }
    }
  }
}

# ---- Tests using bundled data + model objects ----

test_that("C++ matches R for bundled stratData × stratModel pairs", {
  pairs <- list(
    list(data = "stratData0", model = "stratModel0"),
    list(data = "stratData1", model = "stratModel1"),
    list(data = "stratData2", model = "stratModel2"),
    list(data = "stratData3", model = "stratModel3"),
    list(data = "stratData4", model = "stratModel4")
  )

  set.seed(5091)

  for (p in pairs) {
    d <- .EnsurePreExtracted(get(p[["data"]]))
    m <- get(p[["model"]])
    indices <- m[["ind"]]
    nPar <- length(indices[["names"]])

    for (trial in seq_len(5)) {
      params <- rnorm(nPar, sd = 2)
      label <- sprintf("%s + %s trial %d", p[["data"]], p[["model"]], trial)

      r_result <- .AgeConversionStratData(d, indices, params, returnAlphas = TRUE)
      cpp_result <- .sb_age_convert(d, indices, params, returnAlphas = TRUE)

      compare_results(r_result, cpp_result, label)
    }
  }
})

# ---- Tests across all sedModel × scale combinations ----

test_that("C++ matches R for all sedModel × alignmentScale combos", {
  datasets <- c("stratData0", "stratData1", "stratData2", "stratData3",
                "stratData4", "stratData4b", "stratData5a", "stratData5b")
  sed_models <- c("site", "partition", "site x partition", "site, partition")
  scales <- c("height", "age")

  set.seed(8273)

  for (dn in datasets) {
    d <- .EnsurePreExtracted(get(dn))
    for (sd in sed_models) {
      for (sc in scales) {
        indices <- tryCatch(
          .CreateIndices(d, sc, sd, "middle"),
          error = function(e) NULL
        )
        if (is.null(indices)) next

        nPar <- length(indices[["names"]])

        for (trial in seq_len(5)) {
          params <- rnorm(nPar, sd = 2)
          label <- sprintf("%s %s/%s trial %d", dn, sd, sc, trial)

          r_result <- .AgeConversionStratData(
            d, indices, params, returnAlphas = TRUE
          )
          cpp_result <- .sb_age_convert(
            d, indices, params, returnAlphas = TRUE
          )

          compare_results(r_result, cpp_result, label)
        }
      }
    }
  }
})

# ---- returnAlphas = FALSE ----

test_that("C++ returnAlphas = FALSE omits alphas element", {
  d <- .EnsurePreExtracted(stratData1)
  indices <- stratModel1[["ind"]]
  params <- c(10, 20, 0.5, 0.3)

  result <- .sb_age_convert(d, indices, params, returnAlphas = FALSE)
  expect_null(result[["alphas"]])
  expect_false(is.null(result[["signal"]]))
})

# ---- Ties presence/absence ----

test_that("C++ output includes ties only when data has ties", {
  d_no_ties <- .EnsurePreExtracted(stratData0)
  d_ties    <- .EnsurePreExtracted(stratData2)

  ind0 <- stratModel0[["ind"]]
  ind2 <- stratModel2[["ind"]]

  r0 <- .sb_age_convert(d_no_ties, ind0, rnorm(2), returnAlphas = FALSE)
  r2 <- .sb_age_convert(d_ties, ind2, rnorm(7), returnAlphas = FALSE)

  expect_null(r0[["ties"]])
  expect_false(is.null(r2[["ties"]]))
})
