## inst/gui/dialog/closeConfirmationModal.R
closeConfirmationModal <- function() {
  modalDialog(
    title = "Discard Current Setup?",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "text-align: center; padding: 20px;",
        tags$h4("Are you sure you want to discard your current setup?"),
        tags$p("Any unsaved changes to your data or model settings will be lost.", 
               style = "font-size: 1em; color: #666; margin-top: 10px;"),
        tags$p("You can continue working on your setup or close and discard changes.", 
               style = "font-size: 0.9em; color: #888; margin-top: 10px;")
      )
    ),
    
    footer = tagList(
      actionButton("continueSetup", "Continue Setup", 
                  class = "btn-primary",
                  style = "float: left;"),
      actionButton("confirmCloseModal", "Close", 
                  class = "btn-danger",
                  style = "float: right;")
    )
  )
}

