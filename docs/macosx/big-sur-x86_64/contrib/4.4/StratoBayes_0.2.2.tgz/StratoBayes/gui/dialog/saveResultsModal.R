## inst/gui/dialog/saveResultsModal.R
saveResultsModal <- function() {
  modalDialog(
    title = "Save Results",
    size = "m",
    fade = FALSE,
    easyClose = FALSE,
    
    fluidPage(
      tags$div(
        style = "padding: 20px;",
        tags$h4("Save current results to session"),
        tags$p("Save the current StratPosterior object to the session for later loading."),
        br(),
        textInput("saveResultsName", "Result name:",
                 value = paste0("result-", format(Sys.time(), "%Y-%m-%d-%H-%M-%S")),
                 placeholder = "Enter a name for this result",
                 width = "100%"),
        helpText("This will save the result in the current session. Use 'Export Results' to save to disk.", 
                style = "font-size: 0.9em; color: #666; margin-top: 5px;")
      )
    ),
    
    footer = tagList(
      actionButton("cancelSaveResults", "Cancel", 
                  class = "btn-secondary",
                  style = "float: left;"),
      actionButton("confirmSaveResults", "Save", 
                  class = "btn-primary",
                  style = "float: right;")
    )
  )
}

