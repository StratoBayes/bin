PlotUniform <- function(ends, xlab = "Value") {
  if (any(is.na(ends)) || is.null(ends)) {
    ends <- c(0, 0)
  }
  mn <- ends[[1]]
  mx <- ends[[2]]
  range <- mx - mn
  extra <- if (range == 0) 1 else range / 5

  plot(c(mn - extra, mx + extra), c(0, 1),
       type = "n", axes = FALSE, frame.plot = FALSE,
       xlab = xlab,
       ylab = "Probability density")
  polygon(c(mn, mn, mx, mx), c(0, 1, 1, 0), col = "#428bca33", lty = 0)
  lines(c(mn - extra, mn, mn, mx, mx, mx + extra),
        c(0, 0, 1, 1, 0, 0), col = "#428bca", lwd = 2)
  abline(v = 0, lty = "dotted", col = 1)
  axis(1)
}

PlotNormal <- function(mean, sd, xlab = "Value") {
  nSD <- 5
  x <- seq(mean - nSD * sd, mean + nSD * sd, length.out = 256)
  y <- dnorm(x, mean, sd)

  plot(x, y,
       type = "n", axes = FALSE, frame.plot = FALSE,
       xlab = xlab,
       ylab = "Density")
  polygon(x, y, col = "#428bca33", lty = 0)
  lines(x, y, col = "#428bca", lwd = 2)
  abline(v = 0, lty = "dotted", col = 1)
  axis(1)
}

PlotGamma <- function(shape, rate, xlab = "Value") {
  if (is.na(shape)) shape <- 1
  if (is.na(rate)) rate <- 1
  x <- seq(0, qgamma(0.999, shape, rate), length.out = 256)
  d <- dgamma(x, shape, rate)

  plot(x, d,
       type = "n", axes = FALSE, frame.plot = FALSE,
       xlab = xlab,
       ylab = "Density")
  polygon(c(0, x, x[[length(x)]], 0), c(0, d, 0, 0), col = "#428bca33", lty = 0)
  lines(x, d, col = "#428bca", lwd = 2)
  abline(v = 1, lty = "dotted", col = 1)
  axis(1)
}

PlotExp <- function(rate, xlab = "Value") {
  if (is.na(rate)) rate <- 1
  x <- seq(0, qexp(0.999, rate), length.out = 256)
  d <- dexp(x, rate)

  plot(x, d,
       type = "n", axes = FALSE, frame.plot = FALSE,
       xlab = xlab,
       ylab = "Density")
  polygon(c(0, x, x[[length(x)]], 0), c(0, d, 0, 0), col = "#428bca33", lty = 0)
  lines(x, d, col = "#428bca", lwd = 2)
  abline(v = 1, lty = "dotted", col = 1)
  axis(1)
}
