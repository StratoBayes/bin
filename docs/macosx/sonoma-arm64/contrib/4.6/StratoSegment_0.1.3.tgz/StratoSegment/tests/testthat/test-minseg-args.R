test_that("totally infeasible minSegDepth stops with clear error", {
  sim <- make_test_sim(n = 50L, p = 1L, changepoints = integer(0), seed = 11L)
  total_span <- sim$depth[50L] - sim$depth[1L]
  # Both K=0 and K>0 should stop, not silently return Inf objective
  expect_error(
    StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2L, minSegDepth = total_span + 1,
                  minSegFrac = NULL),
    "No feasible segmentation"
  )
  expect_error(
    StratoSegment(sim$y, sim$depth, K = 1L, minSegLen = 2L, minSegDepth = total_span + 1,
                  minSegFrac = NULL),
    "No feasible segmentation"
  )
})

test_that("minSegDepth with default minSegFrac does not warn", {
  sim <- make_test_sim(n = 100L, p = 1L, changepoints = integer(0), seed = 11L)
  expect_no_warning(
    StratoSegment(
      sim$y,
      sim$depth,
      K = 0L,
      minSegLen = 3L,
      minObsPerCurve = 2L,
      minSegDepth = 25
    )
  )
})

test_that("explicit minSegDepth and minSegFrac warns", {
  sim <- make_test_sim(n = 100L, p = 1L, changepoints = integer(0), seed = 11L)
  expect_warning(
    StratoSegment(
      sim$y,
      sim$depth,
      K = 0L,
      minSegLen = 3L,
      minObsPerCurve = 2L,
      minSegDepth = 25,
      minSegFrac = 0.1
    ),
    "Both minSegDepth and minSegFrac"
  )
})

test_that("minSegDepth with minSegFrac = NULL does not warn", {
  sim <- make_test_sim(n = 100L, p = 1L, changepoints = integer(0), seed = 11L)
  expect_no_warning(
    StratoSegment(
      sim$y,
      sim$depth,
      K = 0L,
      minSegLen = 3L,
      minObsPerCurve = 2L,
      minSegDepth = 25,
      minSegFrac = NULL
    )
  )
})
