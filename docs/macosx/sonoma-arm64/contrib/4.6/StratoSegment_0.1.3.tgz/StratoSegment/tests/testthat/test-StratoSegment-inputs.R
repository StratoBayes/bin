test_that("invalid y or depth trigger errors", {
  sim <- make_test_sim(n = 30L, p = 1L, changepoints = integer(0), seed = 1L)
  expect_error(StratoSegment(matrix(NA_real_, 10, 1)), "all missing")
  expect_error(StratoSegment(sim$y, depth = sim$depth[-1]), "length nrow")
  expect_error(StratoSegment(sim$y, depth = c(sim$depth[-1], NA)), "no missing")
})

test_that("duplicate depths are allowed after sorting", {
  set.seed(2L)
  y <- matrix(rnorm(8L), nrow = 8L, ncol = 1L)
  d <- c(10, 10, 5, 5, 20, 20, 15, 15)
  fit <- StratoSegment(y, depth = d, K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_equal(fit$depth, sort(d))
  expect_equal(nrow(fit$y), 8L)
})

test_that("explicit depth is sorted by increasing depth in output", {
  sim <- make_test_sim(n = 30L, p = 1L, changepoints = integer(0), seed = 1L)
  fit <- StratoSegment(sim$y, depth = rev(sim$depth), K = 0L, minSegLen = 2L, minObsPerCurve = 2L)
  expect_true(!is.unsorted(fit$depth, strictly = TRUE))
  expect_equal(fit$depth, sim$depth)
  n <- nrow(sim$y)
  expect_equal(fit$y, sim$y[n:1, , drop = FALSE])
})

test_that("minSegFrac bounds are enforced", {
  sim <- make_test_sim(n = 40L, p = 1L, changepoints = integer(0), seed = 1L)
  expect_error(
    StratoSegment(sim$y, sim$depth, K = 0L, minSegDepth = NULL, minSegFrac = 1.5, minSegLen = 2L),
    "minSegFrac"
  )
})

test_that("StratoSegmentData rejects too few columns", {
  expect_error(StratoSegmentData(data.frame(a = 1)), "at least depth")
})

test_that("StratoSegmentData errors on missing depthCol", {
  df <- data.frame(x = 1:5, y = rnorm(5))
  expect_error(StratoSegmentData(df, depthCol = "MISSING"), "not found")
})

test_that("n < minSegLen triggers a clear error", {
  expect_error(
    StratoSegment(matrix(rnorm(3), 3, 1), K = 0L, minSegLen = 5L),
    "no valid segmentation"
  )
})

test_that("Inf depth triggers a clear error", {
  y <- matrix(rnorm(10), 10, 1)
  expect_error(
    StratoSegment(y, depth = c(1:9, Inf), K = 0L, minSegLen = 2L),
    "finite"
  )
})

test_that("StratoSegmentData rejects non-numeric curve columns", {
  df <- data.frame(DEPTH = 1:10, GR = rnorm(10), LITH = letters[1:10],
                   stringsAsFactors = FALSE)
  expect_error(StratoSegmentData(df), "Non-numeric column")
})

test_that("zero-row y gives a clear error (not vacuous all-missing error)", {
  expect_error(StratoSegment(matrix(numeric(0), 0, 1), K = 0L, minSegLen = 2L),
               "at least one row")
})

test_that("minSegFrac vector is silently truncated to first element (no error)", {
  sim <- make_test_sim(n = 40L, p = 1L, changepoints = integer(0), seed = 3L)
  expect_no_error(
    StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2L, minSegFrac = c(0.1, 0.5),
                  minSegDepth = NULL)
  )
})

test_that("fractional K warns about truncation", {
  sim <- make_test_sim(n = 30L, p = 1L, changepoints = integer(0), seed = 4L)
  expect_warning(
    StratoSegment(sim$y, sim$depth, K = 1.5, minSegLen = 2L, minObsPerCurve = 2L),
    "not an integer"
  )
})

test_that("fractional minSegLen warns about truncation", {
  sim <- make_test_sim(n = 30L, p = 1L, changepoints = integer(0), seed = 4L)
  expect_warning(
    StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2.5, minObsPerCurve = 2L),
    "not an integer"
  )
})

test_that("fractional minObsPerCurve warns about truncation", {
  sim <- make_test_sim(n = 30L, p = 1L, changepoints = integer(0), seed = 4L)
  expect_warning(
    StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2L, minObsPerCurve = 3.7),
    "not an integer"
  )
})

test_that("StratoSegmentData rejects non-numeric depth column", {
  df <- data.frame(DEPTH = c("shallow", "mid", "deep"), GR = 1:3,
                   stringsAsFactors = FALSE)
  expect_error(StratoSegmentData(df), "Depth column")
})

test_that("all-NA column is dropped with warning", {
  sim <- make_test_sim(n = 40L, p = 2L, changepoints = integer(0), seed = 1L)
  sim$y[, 2] <- NA_real_
  expect_warning(
    fit <- StratoSegment(sim$y, sim$depth, K = 0L, minSegLen = 2L, minObsPerCurve = 2L),
    "Dropping all-NA"
  )
  expect_equal(fit$p, 1L)
})
